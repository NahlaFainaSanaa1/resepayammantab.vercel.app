---
description: "Cara buat Sempol Ayam tanpa tusukan yang lezat Untuk Jualan"
title: "Cara buat Sempol Ayam tanpa tusukan yang lezat Untuk Jualan"
slug: 162-cara-buat-sempol-ayam-tanpa-tusukan-yang-lezat-untuk-jualan
date: 2021-01-13T10:04:02.459Z
image: https://img-global.cpcdn.com/recipes/d21d8ce6f3c01a0e/680x482cq70/sempol-ayam-tanpa-tusukan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d21d8ce6f3c01a0e/680x482cq70/sempol-ayam-tanpa-tusukan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d21d8ce6f3c01a0e/680x482cq70/sempol-ayam-tanpa-tusukan-foto-resep-utama.jpg
author: Carl Parks
ratingvalue: 4.3
reviewcount: 8
recipeingredient:
- "370-400 gram ayam giling"
- "3 sendok makan tepung tapioka"
- "1 sendok makan tepung terigu"
- "1 butir telur"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "1,5 sendok teh garam"
- "1/4 sendok teh kaldu bubuk"
- " Air untuk merebus"
- " Minyak untuk menggoreng"
- " Pencelup"
- "2 butir telur kocok lepas"
recipeinstructions:
- "Kupas lalu goreng bawang merah dan bawang putij sampai harum. Setelah digoreng, haluskan."
- "Campurkan ayam giling, tepung tapioka, tepung terigu, bawang merah bawang putih halus, telur, garam, kaldu bubuk. Campur rata."
- "Olesi tangan dengan minyak goreng agar tidak lengket. Ambil sesendok adonan dan bentuk memanjang"
- "Panaskan air sampai mendidih. Masukkan sempol ke dalam air tersebut"
- "Tunggu sampai sempol matang. Kalau sudah matang, sempol akan mengapung. Kalau sudah mengampung angkat dan tiriskan. Biarkan hingga dingin"
- "Panaskan minyak goreng, ambil sempol dan celupkan ke dalam kocokan telur. Goreng hingga telur memutih. Angkat"
- "Masukkan kembali sempol yang sudah digoreng tadi ke dalam kocokan telur (jadi dua kali celup agar terbalut tebal), lalu goreng lagi hingga kecoklatan. Angkat dan sajikan dengan saus sambal."
categories:
- Resep
tags:
- sempol
- ayam
- tanpa

katakunci: sempol ayam tanpa 
nutrition: 225 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dessert

---


![Sempol Ayam tanpa tusukan](https://img-global.cpcdn.com/recipes/d21d8ce6f3c01a0e/680x482cq70/sempol-ayam-tanpa-tusukan-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan santapan sedap untuk keluarga adalah hal yang menggembirakan bagi kamu sendiri. Kewajiban seorang ibu Tidak saja mengurus rumah saja, namun kamu juga harus menyediakan keperluan nutrisi terpenuhi dan juga panganan yang disantap anak-anak harus enak.

Di era  saat ini, anda sebenarnya mampu membeli masakan praktis walaupun tidak harus capek membuatnya terlebih dahulu. Tapi banyak juga mereka yang selalu ingin memberikan yang terbaik bagi keluarganya. Sebab, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai selera keluarga. 



Mungkinkah anda merupakan salah satu penggemar sempol ayam tanpa tusukan?. Tahukah kamu, sempol ayam tanpa tusukan adalah makanan khas di Indonesia yang kini disenangi oleh orang-orang dari berbagai daerah di Nusantara. Kalian dapat memasak sempol ayam tanpa tusukan olahan sendiri di rumahmu dan boleh dijadikan hidangan kesenanganmu di hari liburmu.

Anda jangan bingung jika kamu ingin menyantap sempol ayam tanpa tusukan, karena sempol ayam tanpa tusukan sangat mudah untuk didapatkan dan kalian pun bisa menghidangkannya sendiri di tempatmu. sempol ayam tanpa tusukan boleh dimasak dengan beraneka cara. Kini pun ada banyak resep modern yang membuat sempol ayam tanpa tusukan lebih enak.

Resep sempol ayam tanpa tusukan pun gampang untuk dibikin, lho. Kalian tidak usah capek-capek untuk membeli sempol ayam tanpa tusukan, lantaran Anda dapat membuatnya di rumah sendiri. Bagi Kamu yang akan menyajikannya, dibawah ini merupakan resep membuat sempol ayam tanpa tusukan yang enak yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Sempol Ayam tanpa tusukan:

1. Ambil 370-400 gram ayam giling
1. Siapkan 3 sendok makan tepung tapioka
1. Gunakan 1 sendok makan tepung terigu
1. Siapkan 1 butir telur
1. Siapkan 3 siung bawang putih
1. Gunakan 5 siung bawang merah
1. Ambil 1,5 sendok teh garam
1. Gunakan 1/4 sendok teh kaldu bubuk
1. Sediakan  Air untuk merebus
1. Sediakan  Minyak untuk menggoreng
1. Siapkan  Pencelup
1. Sediakan 2 butir telur kocok lepas




<!--inarticleads2-->

##### Cara membuat Sempol Ayam tanpa tusukan:

1. Kupas lalu goreng bawang merah dan bawang putij sampai harum. Setelah digoreng, haluskan.
1. Campurkan ayam giling, tepung tapioka, tepung terigu, bawang merah bawang putih halus, telur, garam, kaldu bubuk. Campur rata.
1. Olesi tangan dengan minyak goreng agar tidak lengket. Ambil sesendok adonan dan bentuk memanjang
1. Panaskan air sampai mendidih. Masukkan sempol ke dalam air tersebut
1. Tunggu sampai sempol matang. Kalau sudah matang, sempol akan mengapung. Kalau sudah mengampung angkat dan tiriskan. Biarkan hingga dingin
1. Panaskan minyak goreng, ambil sempol dan celupkan ke dalam kocokan telur. Goreng hingga telur memutih. Angkat
1. Masukkan kembali sempol yang sudah digoreng tadi ke dalam kocokan telur (jadi dua kali celup agar terbalut tebal), lalu goreng lagi hingga kecoklatan. Angkat dan sajikan dengan saus sambal.




Wah ternyata cara membuat sempol ayam tanpa tusukan yang mantab tidak ribet ini gampang sekali ya! Kalian semua bisa menghidangkannya. Cara Membuat sempol ayam tanpa tusukan Sangat cocok banget untuk kamu yang baru akan belajar memasak maupun juga untuk kalian yang telah hebat memasak.

Tertarik untuk mencoba membuat resep sempol ayam tanpa tusukan enak simple ini? Kalau kamu mau, ayo kamu segera buruan siapkan alat-alat dan bahannya, lantas bikin deh Resep sempol ayam tanpa tusukan yang enak dan simple ini. Benar-benar mudah kan. 

Jadi, ketimbang anda berlama-lama, ayo langsung aja bikin resep sempol ayam tanpa tusukan ini. Pasti anda tak akan nyesel sudah bikin resep sempol ayam tanpa tusukan mantab tidak ribet ini! Selamat berkreasi dengan resep sempol ayam tanpa tusukan mantab tidak rumit ini di rumah sendiri,oke!.

