---
description: "Bahan-bahan Kari ayam simple yang lezat Untuk Jualan"
title: "Bahan-bahan Kari ayam simple yang lezat Untuk Jualan"
slug: 226-bahan-bahan-kari-ayam-simple-yang-lezat-untuk-jualan
date: 2021-02-28T04:01:10.603Z
image: https://img-global.cpcdn.com/recipes/42e0a8530c78718b/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/42e0a8530c78718b/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/42e0a8530c78718b/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg
author: Jeremiah Pearson
ratingvalue: 3.5
reviewcount: 6
recipeingredient:
- "1 ekor ayam potong 12"
- "1 bh kentang potong dadu"
- "1 bh wortel potong"
- "2 lbr daun salam"
- "1 batang sereh"
- "2 bh bawang putih boleh skip aku pakein supaya tambah wangi"
- "2 bh bawang merah boleh skip aku pakein supaya tambah wangi"
- "8-10 gelas Air putih kira"
- "1 sachet Bumbu kare instan merk bamboo"
- "1 sachet santan kara bubukcair"
- "1 sdt garam"
- "1 sdm gula pasir"
- "1 sdt kaldu ayam"
- "1 sdt kunyit bubuk boleh skip"
recipeinstructions:
- "Tumis bawang merah, bawang putih sebentar, lalh masukan bumbu kari sachet bamboo, amsukan salam dan lengkuas, tumis sampai harum."
- "Masukan ayam yang sudah di cuci ongseng sebentar dengan bumbu, lalu masukan air putih sampai smua ayam terendam jadi 1."
- "Masukan santan, kunyit bubuk, garam, gula, kaldu."
- "Jika ayam sudah 20 menit direbus, masukan kentang dan wortel, jika sudah empuk, koreksi rasa. Angkat."
categories:
- Resep
tags:
- kari
- ayam
- simple

katakunci: kari ayam simple 
nutrition: 106 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dessert

---


![Kari ayam simple](https://img-global.cpcdn.com/recipes/42e0a8530c78718b/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg)

Andai kalian seorang wanita, menyuguhkan olahan sedap kepada orang tercinta merupakan suatu hal yang mengasyikan bagi kita sendiri. Tugas seorang  wanita Tidak sekedar menangani rumah saja, tapi kamu pun harus memastikan keperluan gizi tercukupi dan juga olahan yang dimakan orang tercinta harus sedap.

Di masa  sekarang, anda memang dapat membeli hidangan jadi walaupun tidak harus ribet memasaknya dahulu. Namun banyak juga lho mereka yang memang ingin menghidangkan yang terbaik untuk orang yang dicintainya. Lantaran, memasak yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan orang tercinta. 



Apakah anda merupakan salah satu penyuka kari ayam simple?. Tahukah kamu, kari ayam simple merupakan makanan khas di Indonesia yang sekarang digemari oleh kebanyakan orang dari berbagai daerah di Nusantara. Kalian bisa memasak kari ayam simple sendiri di rumah dan boleh dijadikan camilan kegemaranmu di akhir pekanmu.

Kamu tidak usah bingung untuk memakan kari ayam simple, lantaran kari ayam simple tidak sulit untuk dicari dan kamu pun boleh mengolahnya sendiri di rumah. kari ayam simple bisa diolah lewat berbagai cara. Kini telah banyak sekali cara kekinian yang membuat kari ayam simple lebih nikmat.

Resep kari ayam simple pun gampang untuk dibuat, lho. Kita tidak perlu ribet-ribet untuk memesan kari ayam simple, tetapi Kita mampu menyiapkan ditempatmu. Untuk Kalian yang akan membuatnya, di bawah ini adalah cara menyajikan kari ayam simple yang lezat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Kari ayam simple:

1. Siapkan 1 ekor ayam (potong 12)
1. Siapkan 1 bh kentang (potong² dadu)
1. Gunakan 1 bh wortel (potong²)
1. Gunakan 2 lbr daun salam
1. Gunakan 1 batang sereh
1. Siapkan 2 bh bawang putih (boleh skip) aku pakein supaya tambah wangi
1. Gunakan 2 bh bawang merah (boleh skip) aku pakein supaya tambah wangi
1. Ambil 8-10 gelas Air putih kira²
1. Sediakan 1 sachet Bumbu kare instan merk bamboo
1. Gunakan 1 sachet santan kara (bubuk/cair)
1. Gunakan 1 sdt garam
1. Sediakan 1 sdm gula pasir
1. Ambil 1 sdt kaldu ayam
1. Gunakan 1 sdt kunyit bubuk (boleh skip)




<!--inarticleads2-->

##### Langkah-langkah membuat Kari ayam simple:

1. Tumis bawang merah, bawang putih sebentar, lalh masukan bumbu kari sachet bamboo, amsukan salam dan lengkuas, tumis sampai harum.
<img src="https://img-global.cpcdn.com/steps/3aa494cafc609f2b/160x128cq70/kari-ayam-simple-langkah-memasak-1-foto.jpg" alt="Kari ayam simple">1. Masukan ayam yang sudah di cuci ongseng sebentar dengan bumbu, lalu masukan air putih sampai smua ayam terendam jadi 1.
1. Masukan santan, kunyit bubuk, garam, gula, kaldu.
1. Jika ayam sudah 20 menit direbus, masukan kentang dan wortel, jika sudah empuk, koreksi rasa. Angkat.




Ternyata cara buat kari ayam simple yang lezat simple ini gampang banget ya! Semua orang mampu menghidangkannya. Cara Membuat kari ayam simple Sangat sesuai banget untuk kalian yang sedang belajar memasak ataupun juga bagi kamu yang telah lihai dalam memasak.

Apakah kamu mau mulai mencoba bikin resep kari ayam simple lezat sederhana ini? Kalau anda ingin, mending kamu segera buruan siapkan peralatan dan bahannya, lantas bikin deh Resep kari ayam simple yang enak dan sederhana ini. Betul-betul taidak sulit kan. 

Jadi, daripada kamu diam saja, ayo langsung aja sajikan resep kari ayam simple ini. Pasti kamu tiidak akan menyesal sudah bikin resep kari ayam simple mantab tidak rumit ini! Selamat berkreasi dengan resep kari ayam simple nikmat tidak rumit ini di rumah kalian masing-masing,oke!.

