---
description: "Cara buat Buncis Ati Ayam masak Santan yang enak dan Mudah Dibuat"
title: "Cara buat Buncis Ati Ayam masak Santan yang enak dan Mudah Dibuat"
slug: 320-cara-buat-buncis-ati-ayam-masak-santan-yang-enak-dan-mudah-dibuat
date: 2021-04-15T22:52:44.559Z
image: https://img-global.cpcdn.com/recipes/2743336e11f89bc7/680x482cq70/buncis-ati-ayam-masak-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2743336e11f89bc7/680x482cq70/buncis-ati-ayam-masak-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2743336e11f89bc7/680x482cq70/buncis-ati-ayam-masak-santan-foto-resep-utama.jpg
author: Thomas Wilkerson
ratingvalue: 3.1
reviewcount: 12
recipeingredient:
- "200 gr buncis kl sy diresep ini pakai baby buncis potong2"
- "6 buah ati ayam rebus potong2"
- "5 siung bawang merah iris halus"
- "4 siung bawang putih iris halus"
- "10 buah cabai merah potong2"
- "1 buah gula jawa sisir"
- "1 ruas lengkuas"
- "2 lembar daun salam"
- "300 ml santan"
recipeinstructions:
- "Tumis bawang merah, bawang putih, cabai merah, lengkuas, daun salam sampai wangi"
- "Tambahkan ati ayam, aduk2"
- "Masukkan gula jawa"
- "Masukkan santan, masak sampai mendidih, aduk supaya tidak pecah"
- "Masukkan garam dan gula pasir"
- "Setelah kuah agak menyusut, masukkan buncis. Tunggu sampai mendidih sekali lagi. Koreksi rasa dan matikan api"
- "Sajikan dengan tempe goreng, sungguh nikmat tiada tara"
categories:
- Resep
tags:
- buncis
- ati
- ayam

katakunci: buncis ati ayam 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Buncis Ati Ayam masak Santan](https://img-global.cpcdn.com/recipes/2743336e11f89bc7/680x482cq70/buncis-ati-ayam-masak-santan-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan panganan sedap buat orang tercinta merupakan hal yang memuaskan bagi kamu sendiri. Kewajiban seorang ibu bukan sekedar mengurus rumah saja, tapi kamu pun harus menyediakan keperluan nutrisi tercukupi dan juga hidangan yang dimakan keluarga tercinta harus menggugah selera.

Di era  sekarang, kita sebenarnya mampu membeli santapan jadi tanpa harus susah memasaknya terlebih dahulu. Namun banyak juga mereka yang selalu ingin menyajikan yang terenak untuk orang yang dicintainya. Sebab, memasak yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan famili. 



Apakah anda adalah salah satu penggemar buncis ati ayam masak santan?. Tahukah kamu, buncis ati ayam masak santan merupakan sajian khas di Indonesia yang kini digemari oleh kebanyakan orang di hampir setiap daerah di Nusantara. Kamu dapat membuat buncis ati ayam masak santan sendiri di rumahmu dan pasti jadi camilan kegemaranmu di hari liburmu.

Kalian tidak perlu bingung untuk memakan buncis ati ayam masak santan, lantaran buncis ati ayam masak santan tidak sukar untuk didapatkan dan anda pun dapat memasaknya sendiri di tempatmu. buncis ati ayam masak santan dapat dimasak dengan bermacam cara. Kini pun sudah banyak banget resep modern yang membuat buncis ati ayam masak santan semakin lebih nikmat.

Resep buncis ati ayam masak santan juga mudah sekali dihidangkan, lho. Kamu tidak usah capek-capek untuk memesan buncis ati ayam masak santan, tetapi Kita bisa menghidangkan di rumahmu. Untuk Kamu yang hendak mencobanya, berikut ini cara menyajikan buncis ati ayam masak santan yang enak yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Buncis Ati Ayam masak Santan:

1. Ambil 200 gr buncis (kl sy diresep ini pakai baby buncis) potong2
1. Siapkan 6 buah ati ayam, rebus, potong2
1. Ambil 5 siung bawang merah, iris halus
1. Sediakan 4 siung bawang putih, iris halus
1. Gunakan 10 buah cabai merah, potong2
1. Sediakan 1 buah gula jawa, sisir
1. Siapkan 1 ruas lengkuas
1. Sediakan 2 lembar daun salam
1. Siapkan 300 ml santan




<!--inarticleads2-->

##### Cara menyiapkan Buncis Ati Ayam masak Santan:

1. Tumis bawang merah, bawang putih, cabai merah, lengkuas, daun salam sampai wangi
1. Tambahkan ati ayam, aduk2
1. Masukkan gula jawa
1. Masukkan santan, masak sampai mendidih, aduk supaya tidak pecah
1. Masukkan garam dan gula pasir
1. Setelah kuah agak menyusut, masukkan buncis. Tunggu sampai mendidih sekali lagi. Koreksi rasa dan matikan api
1. Sajikan dengan tempe goreng, sungguh nikmat tiada tara




Wah ternyata cara buat buncis ati ayam masak santan yang enak tidak ribet ini gampang banget ya! Semua orang dapat menghidangkannya. Cara Membuat buncis ati ayam masak santan Sangat cocok banget buat kamu yang baru mau belajar memasak atau juga bagi kamu yang telah lihai memasak.

Apakah kamu tertarik mulai mencoba membuat resep buncis ati ayam masak santan mantab sederhana ini? Kalau anda ingin, ayo kamu segera siapkan alat dan bahannya, kemudian buat deh Resep buncis ati ayam masak santan yang enak dan simple ini. Betul-betul mudah kan. 

Maka, daripada anda diam saja, maka kita langsung saja buat resep buncis ati ayam masak santan ini. Pasti anda tak akan menyesal sudah bikin resep buncis ati ayam masak santan lezat simple ini! Selamat berkreasi dengan resep buncis ati ayam masak santan nikmat simple ini di rumah sendiri,ya!.

