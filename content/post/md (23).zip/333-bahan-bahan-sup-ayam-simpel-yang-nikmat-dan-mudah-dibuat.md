---
description: "Bahan-bahan Sup ayam simpel yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Sup ayam simpel yang nikmat dan Mudah Dibuat"
slug: 333-bahan-bahan-sup-ayam-simpel-yang-nikmat-dan-mudah-dibuat
date: 2021-02-18T01:07:02.117Z
image: https://img-global.cpcdn.com/recipes/4e3a8d7bcc70d20e/680x482cq70/sup-ayam-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4e3a8d7bcc70d20e/680x482cq70/sup-ayam-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4e3a8d7bcc70d20e/680x482cq70/sup-ayam-simpel-foto-resep-utama.jpg
author: Willie Cooper
ratingvalue: 4.7
reviewcount: 10
recipeingredient:
- "1/4 kg ayam"
- "1 bungkus sayuran sop"
- "1 buah tomat merah"
- " Bumbu"
- "3 siung bawang putih irisgoreng2 sdm kripik bawang"
- "4 siung bawang merah iris goreng  2 sdm bawang goreng"
- "1/2 sdt lada bubuk"
- "Sedikit pala"
- "1 sdt garam"
- "1 sdt gula"
- "1/2 sdt kaldu bubuk"
- "1500 ml air"
recipeinstructions:
- "Cuci bersih ayam,potong kecil2. Rebus 500 ml air tunggu smp keluar busa tidak usah smp mendidih matikan api.kmd buang air rebusan ayam."
- "Masukan lg 1 liter air untuk merebus ayam.sambil menunggu ayam empuk siapkan bumbu2,dan sayuran."
- "Iris2 sayuran kmd cuci bersih,pisah2kan antara wortel, kol dan daun sop. Goreng bawang putih smp garing (coklat) sisihkan. Kmd goreng bawang merah smp garing (coklat) sisihkan."
- "Setelah air rebusan ayam mendidih masukan bawang putih goreng yg sdh dicincang, dan wortel, tambahkan pala (me diparut),lada bubuk garam gula dan kaldu bubuk. Tunggu smp ayam dan wortel empuk baru kmd masukan kol,daun sop, irisan tomat,aduk sebentar kmd cek rasa,matikan api taburi atasnya dgn bawang merah goreng"
categories:
- Resep
tags:
- sup
- ayam
- simpel

katakunci: sup ayam simpel 
nutrition: 274 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dessert

---


![Sup ayam simpel](https://img-global.cpcdn.com/recipes/4e3a8d7bcc70d20e/680x482cq70/sup-ayam-simpel-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan masakan mantab kepada orang tercinta merupakan suatu hal yang memuaskan untuk kamu sendiri. Peran seorang  wanita bukan cuma mengerjakan pekerjaan rumah saja, tetapi anda pun harus menyediakan keperluan gizi terpenuhi dan juga santapan yang dikonsumsi anak-anak harus sedap.

Di masa  sekarang, kalian memang mampu membeli masakan jadi walaupun tanpa harus susah mengolahnya terlebih dahulu. Namun banyak juga mereka yang memang mau memberikan hidangan yang terbaik bagi keluarganya. Sebab, menyajikan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penyuka sup ayam simpel?. Tahukah kamu, sup ayam simpel adalah sajian khas di Nusantara yang sekarang disukai oleh setiap orang dari berbagai daerah di Indonesia. Kita bisa memasak sup ayam simpel buatan sendiri di rumahmu dan boleh jadi santapan favoritmu di akhir pekan.

Kalian tidak usah bingung jika kamu ingin memakan sup ayam simpel, sebab sup ayam simpel mudah untuk ditemukan dan juga kalian pun dapat memasaknya sendiri di rumah. sup ayam simpel bisa dibuat memalui bermacam cara. Sekarang sudah banyak sekali resep kekinian yang menjadikan sup ayam simpel lebih enak.

Resep sup ayam simpel pun gampang sekali dibikin, lho. Kita tidak usah ribet-ribet untuk membeli sup ayam simpel, tetapi Anda mampu menyajikan sendiri di rumah. Untuk Kita yang akan menghidangkannya, berikut resep menyajikan sup ayam simpel yang lezat yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Sup ayam simpel:

1. Ambil 1/4 kg ayam
1. Siapkan 1 bungkus sayuran sop
1. Siapkan 1 buah tomat merah
1. Ambil  Bumbu
1. Sediakan 3 siung bawang putih (iris,goreng)/2 sdm kripik bawang
1. Ambil 4 siung bawang merah (iris, goreng) / 2 sdm bawang goreng
1. Sediakan 1/2 sdt lada bubuk
1. Ambil Sedikit pala
1. Siapkan 1 sdt garam
1. Ambil 1 sdt gula
1. Ambil 1/2 sdt kaldu bubuk
1. Ambil 1500 ml air




<!--inarticleads2-->

##### Cara menyiapkan Sup ayam simpel:

1. Cuci bersih ayam,potong kecil2. Rebus 500 ml air tunggu smp keluar busa tidak usah smp mendidih matikan api.kmd buang air rebusan ayam.
1. Masukan lg 1 liter air untuk merebus ayam.sambil menunggu ayam empuk siapkan bumbu2,dan sayuran.
1. Iris2 sayuran kmd cuci bersih,pisah2kan antara wortel, kol dan daun sop. Goreng bawang putih smp garing (coklat) sisihkan. Kmd goreng bawang merah smp garing (coklat) sisihkan.
1. Setelah air rebusan ayam mendidih masukan bawang putih goreng yg sdh dicincang, dan wortel, tambahkan pala (me diparut),lada bubuk garam gula dan kaldu bubuk. Tunggu smp ayam dan wortel empuk baru kmd masukan kol,daun sop, irisan tomat,aduk sebentar kmd cek rasa,matikan api taburi atasnya dgn bawang merah goreng




Wah ternyata resep sup ayam simpel yang enak tidak ribet ini mudah banget ya! Kita semua mampu mencobanya. Cara buat sup ayam simpel Sangat sesuai banget buat kita yang baru belajar memasak atau juga bagi kalian yang telah hebat dalam memasak.

Apakah kamu mau mulai mencoba membuat resep sup ayam simpel lezat tidak rumit ini? Kalau kamu ingin, ayo kalian segera buruan siapin peralatan dan bahannya, lalu buat deh Resep sup ayam simpel yang enak dan simple ini. Sungguh taidak sulit kan. 

Oleh karena itu, ketimbang kita diam saja, yuk langsung aja buat resep sup ayam simpel ini. Pasti kamu tiidak akan menyesal bikin resep sup ayam simpel mantab sederhana ini! Selamat mencoba dengan resep sup ayam simpel enak tidak rumit ini di tempat tinggal masing-masing,oke!.

