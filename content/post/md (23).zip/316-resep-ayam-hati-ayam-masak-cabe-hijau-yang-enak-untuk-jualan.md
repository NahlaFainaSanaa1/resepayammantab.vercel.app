---
description: "Resep Ayam + hati ayam masak cabe hijau yang enak Untuk Jualan"
title: "Resep Ayam + hati ayam masak cabe hijau yang enak Untuk Jualan"
slug: 316-resep-ayam-hati-ayam-masak-cabe-hijau-yang-enak-untuk-jualan
date: 2021-06-14T13:04:25.819Z
image: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
author: Virginia Foster
ratingvalue: 4.3
reviewcount: 6
recipeingredient:
- "1/2 ekor ayam"
- "3 hati ayam  ampela"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "8 cabe hijau besar bagusnya sih 15 cabe atau sesuai selera"
- "10 cabe rawit tergantung selera"
- "2 tomat merah ukuran sedang harus tomat hijau 34 buah"
- "2 batang serai geprek"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 lembar daun kunyit"
- "1 cm kunyit"
- "1 cm jahe"
- "1 cm lengkuas"
- "3 biji kemiri"
- "1/2 sdm ketumbar"
- "1/2 sdm merica"
- "2 asam gandis boleh pake air asam jawa"
- " Penyedap"
- " Gula"
- " Minyak goreng"
- " Air bersih"
recipeinstructions:
- "Bersihkan ayam dan jeroannya, lalu potong sesuai selera, saya rebus jeroannya dulu yah biar gak bau amis, bisa direbus langsung atau ditambah garam dan daun jeruk"
- "Haluskan bawang, jahe, lengkuas, kunyit, kemiri, tomat dan cabe lalu tumis hingga wangi lalu masukan serai, daun jeruk, daun salam tumis hingga mateng"
- "Masukan ayam dan jeroan, dan asam aduk hingga bumbu tercampur rata, lalu tambah air secukupnya, masak hingga air berkurang setengah tambahakn penyedap, garam, gula, ketumbar, merica (atau ini ditambah pas lagi numis bumbu juga gpp)"
- "Koreksi rasa, masak hingga matang dan daging ayam empuk, angkat dan sajikan dengan nasi hangat"
categories:
- Resep
tags:
- ayam
- 
- hati

katakunci: ayam  hati 
nutrition: 116 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam + hati ayam masak cabe hijau](https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan hidangan lezat pada keluarga adalah suatu hal yang menggembirakan untuk anda sendiri. Tanggung jawab seorang ibu bukan sekedar mengurus rumah saja, namun anda juga wajib menyediakan keperluan nutrisi tercukupi dan santapan yang dimakan orang tercinta mesti enak.

Di era  saat ini, kalian sebenarnya mampu memesan santapan siap saji tidak harus ribet membuatnya lebih dulu. Namun banyak juga orang yang selalu mau memberikan makanan yang terenak bagi orang yang dicintainya. Sebab, menghidangkan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut berdasarkan selera orang tercinta. 



Mungkinkah anda merupakan salah satu penggemar ayam + hati ayam masak cabe hijau?. Asal kamu tahu, ayam + hati ayam masak cabe hijau adalah makanan khas di Nusantara yang kini disenangi oleh kebanyakan orang dari berbagai tempat di Nusantara. Kalian dapat menghidangkan ayam + hati ayam masak cabe hijau sendiri di rumah dan pasti jadi santapan kegemaranmu di hari libur.

Anda tidak perlu bingung jika kamu ingin menyantap ayam + hati ayam masak cabe hijau, sebab ayam + hati ayam masak cabe hijau mudah untuk didapatkan dan kamu pun boleh memasaknya sendiri di tempatmu. ayam + hati ayam masak cabe hijau dapat dimasak memalui berbagai cara. Saat ini sudah banyak banget cara kekinian yang membuat ayam + hati ayam masak cabe hijau lebih mantap.

Resep ayam + hati ayam masak cabe hijau juga mudah sekali untuk dibuat, lho. Kalian tidak usah capek-capek untuk memesan ayam + hati ayam masak cabe hijau, sebab Anda bisa menghidangkan sendiri di rumah. Untuk Kamu yang mau membuatnya, di bawah ini adalah resep untuk membuat ayam + hati ayam masak cabe hijau yang mantab yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam + hati ayam masak cabe hijau:

1. Gunakan 1/2 ekor ayam
1. Sediakan 3 hati ayam + ampela
1. Sediakan 8 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Gunakan 8 cabe hijau besar (bagusnya sih 15 cabe atau sesuai selera)
1. Sediakan 10 cabe rawit (tergantung selera)
1. Gunakan 2 tomat merah ukuran sedang (harus tomat hijau 3-4 buah)
1. Sediakan 2 batang serai (geprek)
1. Siapkan 3 lembar daun salam
1. Gunakan 5 lembar daun jeruk
1. Gunakan 1 lembar daun kunyit
1. Ambil 1 cm kunyit
1. Siapkan 1 cm jahe
1. Siapkan 1 cm lengkuas
1. Siapkan 3 biji kemiri
1. Ambil 1/2 sdm ketumbar
1. Gunakan 1/2 sdm merica
1. Gunakan 2 asam gandis (boleh pake air asam jawa)
1. Siapkan  Penyedap
1. Ambil  Gula
1. Ambil  Minyak goreng
1. Sediakan  Air bersih




<!--inarticleads2-->

##### Cara membuat Ayam + hati ayam masak cabe hijau:

1. Bersihkan ayam dan jeroannya, lalu potong sesuai selera, saya rebus jeroannya dulu yah biar gak bau amis, bisa direbus langsung atau ditambah garam dan daun jeruk
1. Haluskan bawang, jahe, lengkuas, kunyit, kemiri, tomat dan cabe lalu tumis hingga wangi lalu masukan serai, daun jeruk, daun salam tumis hingga mateng
1. Masukan ayam dan jeroan, dan asam aduk hingga bumbu tercampur rata, lalu tambah air secukupnya, masak hingga air berkurang setengah tambahakn penyedap, garam, gula, ketumbar, merica (atau ini ditambah pas lagi numis bumbu juga gpp)
1. Koreksi rasa, masak hingga matang dan daging ayam empuk, angkat dan sajikan dengan nasi hangat




Ternyata cara buat ayam + hati ayam masak cabe hijau yang mantab sederhana ini enteng sekali ya! Semua orang bisa mencobanya. Resep ayam + hati ayam masak cabe hijau Sesuai banget untuk kalian yang baru akan belajar memasak ataupun bagi kamu yang sudah ahli dalam memasak.

Apakah kamu ingin mulai mencoba bikin resep ayam + hati ayam masak cabe hijau lezat sederhana ini? Kalau tertarik, mending kamu segera menyiapkan alat dan bahannya, lantas buat deh Resep ayam + hati ayam masak cabe hijau yang lezat dan tidak rumit ini. Sangat gampang kan. 

Maka dari itu, daripada kita berfikir lama-lama, ayo kita langsung bikin resep ayam + hati ayam masak cabe hijau ini. Dijamin kamu tiidak akan menyesal sudah buat resep ayam + hati ayam masak cabe hijau lezat tidak rumit ini! Selamat berkreasi dengan resep ayam + hati ayam masak cabe hijau mantab simple ini di rumah masing-masing,ya!.

