---
description: "Resep Kari Ayam Simple yang nikmat dan Mudah Dibuat"
title: "Resep Kari Ayam Simple yang nikmat dan Mudah Dibuat"
slug: 223-resep-kari-ayam-simple-yang-nikmat-dan-mudah-dibuat
date: 2021-03-17T19:48:33.929Z
image: https://img-global.cpcdn.com/recipes/d09d0cf8db10adfc/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d09d0cf8db10adfc/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d09d0cf8db10adfc/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg
author: Martha Hunt
ratingvalue: 4.4
reviewcount: 7
recipeingredient:
- "1 ekor ayam"
- "150 ml santan kental"
- "200 ml air"
- "1 sendok teh garam"
- "1/2 sendok teh kaldu bubuk rasa ayam"
- "4 sendok makan minyak goreng"
- " Bahan Bumbu Halus"
- "10 siung bawang merah"
- "6 siung bawang putih"
- "10 buah cabai merah"
- "1 butir kemiri"
- "1 jari kunyit"
- "1/2 ibu jari jahe"
- "2 batang serai"
- "2 lembar daun jeruk"
- "5 butir kapulaga"
- "3 butir bunga lawang"
- "1/2 sendok teh jinten"
- "1 sendok teh ketumbar"
- "1 sendok teh merica"
recipeinstructions:
- "Siapkan ayam potong-potong seauai selera, cuci bersih kemudian rebus kira-kira 20 menit, lalu angkat dan tiriskan, sisahkan 200 ml air bekas merebus ayam."
- "Kemudian haluskan semua bahan bumbu halus, haluskan menggunakan belender, kemudian panaskan 4 sendok makan minyak, lalu tumis bumbu halus sampai harum."
- "Setelah bumbu tumis harum, masukan 200 ml air bekas merebus ayam, kemudian masukan santan, lalu masukan ayam yang sudah di rebus tadi, tambahkan garam dan kaldu bubuk, aduk rata, kecilkan api masak sampai kuah mengental, koreksi rasa, setelah di rasa cukup matikan api, angkat, taruh dalam wadah dan sajikan."
categories:
- Resep
tags:
- kari
- ayam
- simple

katakunci: kari ayam simple 
nutrition: 265 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner

---


![Kari Ayam Simple](https://img-global.cpcdn.com/recipes/d09d0cf8db10adfc/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyajikan hidangan nikmat untuk orang tercinta merupakan suatu hal yang memuaskan bagi kita sendiri. Kewajiban seorang ibu bukan saja menjaga rumah saja, tapi anda pun harus memastikan kebutuhan nutrisi terpenuhi dan panganan yang dimakan keluarga tercinta harus mantab.

Di zaman  sekarang, kita sebenarnya mampu membeli hidangan jadi tidak harus ribet memasaknya terlebih dahulu. Tapi banyak juga mereka yang memang ingin menghidangkan yang terlezat untuk keluarganya. Sebab, memasak sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga. 



Apakah anda merupakan seorang penyuka kari ayam simple?. Tahukah kamu, kari ayam simple merupakan hidangan khas di Nusantara yang saat ini disenangi oleh kebanyakan orang dari hampir setiap wilayah di Nusantara. Kalian bisa membuat kari ayam simple kreasi sendiri di rumah dan pasti jadi camilan kesenanganmu di akhir pekan.

Anda jangan bingung untuk menyantap kari ayam simple, lantaran kari ayam simple gampang untuk ditemukan dan juga kalian pun bisa memasaknya sendiri di tempatmu. kari ayam simple dapat diolah memalui beragam cara. Saat ini sudah banyak sekali cara modern yang membuat kari ayam simple semakin mantap.

Resep kari ayam simple juga mudah sekali untuk dibuat, lho. Kita jangan capek-capek untuk membeli kari ayam simple, lantaran Kita bisa menyajikan di rumahmu. Untuk Anda yang mau membuatnya, di bawah ini adalah cara untuk menyajikan kari ayam simple yang lezat yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Kari Ayam Simple:

1. Gunakan 1 ekor ayam
1. Ambil 150 ml santan kental
1. Siapkan 200 ml air
1. Sediakan 1 sendok teh garam
1. Siapkan 1/2 sendok teh kaldu bubuk rasa ayam
1. Ambil 4 sendok makan minyak goreng
1. Siapkan  Bahan Bumbu Halus
1. Gunakan 10 siung bawang merah
1. Gunakan 6 siung bawang putih
1. Sediakan 10 buah cabai merah
1. Sediakan 1 butir kemiri
1. Sediakan 1 jari kunyit
1. Gunakan 1/2 ibu jari jahe
1. Ambil 2 batang serai
1. Ambil 2 lembar daun jeruk
1. Ambil 5 butir kapulaga
1. Gunakan 3 butir bunga lawang
1. Gunakan 1/2 sendok teh jinten
1. Sediakan 1 sendok teh ketumbar
1. Sediakan 1 sendok teh merica




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Kari Ayam Simple:

1. Siapkan ayam potong-potong seauai selera, cuci bersih kemudian rebus kira-kira 20 menit, lalu angkat dan tiriskan, sisahkan 200 ml air bekas merebus ayam.
1. Kemudian haluskan semua bahan bumbu halus, haluskan menggunakan belender, kemudian panaskan 4 sendok makan minyak, lalu tumis bumbu halus sampai harum.
1. Setelah bumbu tumis harum, masukan 200 ml air bekas merebus ayam, kemudian masukan santan, lalu masukan ayam yang sudah di rebus tadi, tambahkan garam dan kaldu bubuk, aduk rata, kecilkan api masak sampai kuah mengental, koreksi rasa, setelah di rasa cukup matikan api, angkat, taruh dalam wadah dan sajikan.




Wah ternyata cara buat kari ayam simple yang mantab sederhana ini mudah banget ya! Kita semua bisa membuatnya. Cara buat kari ayam simple Sangat cocok sekali buat kita yang baru belajar memasak ataupun juga bagi anda yang telah hebat dalam memasak.

Tertarik untuk mencoba membikin resep kari ayam simple mantab simple ini? Kalau ingin, ayo kalian segera buruan siapkan alat-alat dan bahannya, maka bikin deh Resep kari ayam simple yang mantab dan sederhana ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kita diam saja, ayo kita langsung saja sajikan resep kari ayam simple ini. Dijamin kamu gak akan nyesel membuat resep kari ayam simple lezat simple ini! Selamat berkreasi dengan resep kari ayam simple mantab tidak ribet ini di rumah masing-masing,oke!.

