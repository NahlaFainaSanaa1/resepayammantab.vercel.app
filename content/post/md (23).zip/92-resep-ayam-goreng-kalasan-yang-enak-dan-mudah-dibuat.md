---
description: "Resep Ayam Goreng Kalasan yang enak dan Mudah Dibuat"
title: "Resep Ayam Goreng Kalasan yang enak dan Mudah Dibuat"
slug: 92-resep-ayam-goreng-kalasan-yang-enak-dan-mudah-dibuat
date: 2021-02-08T22:04:34.411Z
image: https://img-global.cpcdn.com/recipes/685eecdc14608330/680x482cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/685eecdc14608330/680x482cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/685eecdc14608330/680x482cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
author: Tyler Bush
ratingvalue: 3.7
reviewcount: 6
recipeingredient:
- "1/2 kg ayam potong bagian apa saja me sayap"
- "500 ml air kelapa"
- "1/2 buah jeruk nipis"
- "Secukupnya minyak goreng"
- " Bumbu Halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1/2 sdt lada butiran me bubuk"
- "1 ruas lengkuas muda"
- " Bumbu Cemplung"
- "2 lbr daun salam"
- "2 lbr daun jeruk"
- "1 batang sereh"
- " Bumbubumbu Lain"
- "100 gr gula merah"
- "1,5 sdm kecap manis"
- "1 sdm gula pasir"
- "Secukupnya garam dan kaldu jamur"
- " Bahan Pelengkap"
- " Timun Lalap"
- " Sambal tomat terasi matang"
recipeinstructions:
- "Siapkan semua bahan. Cuci bersih ayam, lumuri dg perasan jeruk nipis lalu diamkan selama 15 menit. Cuci kembali hingga bersih."
- "Haluskan bumbu."
- "Lumuri ayam dg bumbu yg telah dihaluskan. Marinasi ayam selama kurleb 30 menit."
- "Didihkan air kelapa dan bumbu cemplung. Masukkan ayam yg telah dimarinasi, masak ayam hingga empuk."
- "Tambahkan gula merah, kecap, garam dan kaldu bubuk. Aduk pelan-pelan. Masak hingga merata dan menyusut airnya. Angkat dan tiriskan."
- "Panaskan minyak, goreng ayam hingga matang kecoklatan (warna sesuai selera ya, kalau saga dan suami suka yg agak gosong), angkat dan tiriskan."
- "Ayam goreng kalasan siap disajikan ditemani lalapan dan sambal. Selamat mencoba dan semoga bermanfaat."
categories:
- Resep
tags:
- ayam
- goreng
- kalasan

katakunci: ayam goreng kalasan 
nutrition: 239 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Kalasan](https://img-global.cpcdn.com/recipes/685eecdc14608330/680x482cq70/ayam-goreng-kalasan-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan panganan sedap untuk keluarga adalah hal yang sangat menyenangkan bagi anda sendiri. Kewajiban seorang istri bukan sekedar menangani rumah saja, tetapi anda juga harus menyediakan keperluan gizi terpenuhi dan juga hidangan yang dimakan keluarga tercinta harus nikmat.

Di masa  saat ini, kita memang mampu membeli santapan praktis tidak harus capek mengolahnya terlebih dahulu. Tapi banyak juga mereka yang memang mau menyajikan yang terenak bagi keluarganya. Lantaran, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga. 



Mungkinkah kamu salah satu penikmat ayam goreng kalasan?. Asal kamu tahu, ayam goreng kalasan merupakan hidangan khas di Nusantara yang saat ini disukai oleh orang-orang dari berbagai wilayah di Indonesia. Kalian bisa menyajikan ayam goreng kalasan sendiri di rumah dan boleh jadi santapan kesenanganmu di hari liburmu.

Kita tidak perlu bingung jika kamu ingin menyantap ayam goreng kalasan, lantaran ayam goreng kalasan tidak sulit untuk ditemukan dan juga kalian pun bisa memasaknya sendiri di rumah. ayam goreng kalasan bisa diolah memalui beragam cara. Kini sudah banyak sekali cara kekinian yang membuat ayam goreng kalasan lebih enak.

Resep ayam goreng kalasan juga gampang sekali untuk dibuat, lho. Anda jangan ribet-ribet untuk membeli ayam goreng kalasan, sebab Kamu dapat menyiapkan ditempatmu. Bagi Kalian yang hendak menghidangkannya, inilah cara untuk menyajikan ayam goreng kalasan yang mantab yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Goreng Kalasan:

1. Siapkan 1/2 kg ayam potong bagian apa saja (me. sayap)
1. Siapkan 500 ml air kelapa
1. Gunakan 1/2 buah jeruk nipis
1. Gunakan Secukupnya minyak goreng
1. Gunakan  Bumbu Halus:
1. Siapkan 6 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Gunakan 1/2 sdt lada butiran (me. bubuk)
1. Sediakan 1 ruas lengkuas muda
1. Ambil  Bumbu Cemplung:
1. Siapkan 2 lbr daun salam
1. Siapkan 2 lbr daun jeruk
1. Sediakan 1 batang sereh
1. Ambil  Bumbu-bumbu Lain:
1. Sediakan 100 gr gula merah
1. Ambil 1,5 sdm kecap manis
1. Sediakan 1 sdm gula pasir
1. Siapkan Secukupnya garam, dan kaldu jamur
1. Ambil  Bahan Pelengkap:
1. Ambil  Timun Lalap
1. Ambil  Sambal tomat terasi matang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Goreng Kalasan:

1. Siapkan semua bahan. - Cuci bersih ayam, lumuri dg perasan jeruk nipis lalu diamkan selama 15 menit. Cuci kembali hingga bersih.
1. Haluskan bumbu.
1. Lumuri ayam dg bumbu yg telah dihaluskan. Marinasi ayam selama kurleb 30 menit.
1. Didihkan air kelapa dan bumbu cemplung. Masukkan ayam yg telah dimarinasi, masak ayam hingga empuk.
1. Tambahkan gula merah, kecap, garam dan kaldu bubuk. Aduk pelan-pelan. Masak hingga merata dan menyusut airnya. Angkat dan tiriskan.
1. Panaskan minyak, goreng ayam hingga matang kecoklatan (warna sesuai selera ya, kalau saga dan suami suka yg agak gosong), angkat dan tiriskan.
1. Ayam goreng kalasan siap disajikan ditemani lalapan dan sambal. Selamat mencoba dan semoga bermanfaat.




Ternyata resep ayam goreng kalasan yang mantab sederhana ini mudah sekali ya! Kita semua mampu membuatnya. Resep ayam goreng kalasan Sangat sesuai banget buat kalian yang baru mau belajar memasak ataupun juga untuk anda yang sudah jago memasak.

Tertarik untuk mencoba buat resep ayam goreng kalasan lezat simple ini? Kalau anda tertarik, ayo kamu segera siapkan alat dan bahan-bahannya, kemudian bikin deh Resep ayam goreng kalasan yang lezat dan simple ini. Betul-betul mudah kan. 

Oleh karena itu, daripada anda berlama-lama, maka langsung aja hidangkan resep ayam goreng kalasan ini. Pasti kamu tiidak akan nyesel sudah buat resep ayam goreng kalasan lezat tidak rumit ini! Selamat mencoba dengan resep ayam goreng kalasan lezat tidak rumit ini di rumah sendiri,ya!.

