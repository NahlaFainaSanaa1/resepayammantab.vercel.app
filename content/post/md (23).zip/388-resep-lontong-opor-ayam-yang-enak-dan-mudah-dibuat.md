---
description: "Resep Lontong Opor Ayam yang enak dan Mudah Dibuat"
title: "Resep Lontong Opor Ayam yang enak dan Mudah Dibuat"
slug: 388-resep-lontong-opor-ayam-yang-enak-dan-mudah-dibuat
date: 2021-04-28T23:22:14.486Z
image: https://img-global.cpcdn.com/recipes/297bda335083d89f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/297bda335083d89f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/297bda335083d89f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
author: James Hamilton
ratingvalue: 3.4
reviewcount: 10
recipeingredient:
- "6 potong daging ayam"
- "1 btg serai"
- "1 lmbr daun jeruk"
- "1 lmbr daun salam"
- "1 bh lontong"
- "Secukupnya kerupuk udang"
- "Secukupnya bawang merah goreng"
- " Bumbu halus "
- "5 siung bamer"
- "2 siung baput"
- "1 bj kemiri"
- "1 cm jahe"
- "1/2 sdt ketumbar"
- "1/2 sdt merica"
- "Secukupnya garam"
recipeinstructions:
- "Rebus ayam yang telah dibersihkan terlebih dahulu. Setelah matang, ambil ayamnya saja. Kalo pakai ayam kampung, kaldu saya pakai. Tapi karena pakai ayam potong jadi tidak pakai kaldunya. Sesuaikan selera saja ya"
- "Haluskan bumbu. Kemudian tumis sampai harum"
- "Siapkan santan di panci. Masukkan ayam yg telah di rebus tadi. Masukkan juga bumbu."
- "Kemudian masak, sebelum mendidih, tes rasa dulu. Angkat setelah kuah mendidih."
- "Siapkan lontong di piring. Siram dg opornya. Taburi dg bawang merah goreng. Sajikan dg sambal dan kerupuk."
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 278 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Lunch

---


![Lontong Opor Ayam](https://img-global.cpcdn.com/recipes/297bda335083d89f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg)

Selaku seorang ibu, menyuguhkan panganan nikmat pada famili adalah suatu hal yang menyenangkan bagi anda sendiri. Peran seorang ibu bukan cuma menjaga rumah saja, tapi kamu pun wajib memastikan keperluan gizi terpenuhi dan santapan yang dimakan anak-anak harus mantab.

Di era  sekarang, anda sebenarnya mampu memesan santapan instan walaupun tanpa harus susah mengolahnya lebih dulu. Tapi banyak juga orang yang memang ingin memberikan makanan yang terlezat bagi orang yang dicintainya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga. 



Mungkinkah kamu salah satu penikmat lontong opor ayam?. Tahukah kamu, lontong opor ayam adalah hidangan khas di Indonesia yang sekarang disukai oleh kebanyakan orang di berbagai daerah di Nusantara. Kalian dapat memasak lontong opor ayam sendiri di rumah dan pasti jadi hidangan favoritmu di akhir pekanmu.

Kita tidak usah bingung jika kamu ingin memakan lontong opor ayam, lantaran lontong opor ayam gampang untuk ditemukan dan juga anda pun dapat mengolahnya sendiri di tempatmu. lontong opor ayam dapat diolah dengan beragam cara. Sekarang telah banyak banget cara modern yang menjadikan lontong opor ayam semakin lebih nikmat.

Resep lontong opor ayam pun gampang sekali untuk dibuat, lho. Kita tidak usah repot-repot untuk membeli lontong opor ayam, lantaran Kalian dapat menghidangkan di rumahmu. Bagi Kita yang hendak mencobanya, berikut cara membuat lontong opor ayam yang lezat yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Lontong Opor Ayam:

1. Siapkan 6 potong daging ayam
1. Siapkan 1 btg serai
1. Siapkan 1 lmbr daun jeruk
1. Gunakan 1 lmbr daun salam
1. Ambil 1 bh lontong
1. Sediakan Secukupnya kerupuk udang
1. Gunakan Secukupnya bawang merah goreng
1. Ambil  Bumbu halus :
1. Ambil 5 siung bamer
1. Siapkan 2 siung baput
1. Siapkan 1 bj kemiri
1. Gunakan 1 cm jahe
1. Gunakan 1/2 sdt ketumbar
1. Siapkan 1/2 sdt merica
1. Ambil Secukupnya garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Lontong Opor Ayam:

1. Rebus ayam yang telah dibersihkan terlebih dahulu. Setelah matang, ambil ayamnya saja. Kalo pakai ayam kampung, kaldu saya pakai. Tapi karena pakai ayam potong jadi tidak pakai kaldunya. Sesuaikan selera saja ya
1. Haluskan bumbu. Kemudian tumis sampai harum
1. Siapkan santan di panci. Masukkan ayam yg telah di rebus tadi. Masukkan juga bumbu.
1. Kemudian masak, sebelum mendidih, tes rasa dulu. Angkat setelah kuah mendidih.
1. Siapkan lontong di piring. Siram dg opornya. Taburi dg bawang merah goreng. Sajikan dg sambal dan kerupuk.




Ternyata resep lontong opor ayam yang mantab tidak rumit ini gampang sekali ya! Kamu semua bisa membuatnya. Resep lontong opor ayam Sangat cocok sekali untuk kamu yang sedang belajar memasak maupun bagi kalian yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba membuat resep lontong opor ayam mantab sederhana ini? Kalau kalian ingin, yuk kita segera buruan menyiapkan alat dan bahan-bahannya, maka buat deh Resep lontong opor ayam yang nikmat dan tidak rumit ini. Benar-benar gampang kan. 

Maka, ketimbang kamu berfikir lama-lama, hayo langsung aja sajikan resep lontong opor ayam ini. Dijamin anda tiidak akan nyesel sudah bikin resep lontong opor ayam nikmat tidak ribet ini! Selamat berkreasi dengan resep lontong opor ayam lezat sederhana ini di tempat tinggal masing-masing,oke!.

