---
description: "Cara membuat 11. Sempol Ayam tanpa Ayam yang lezat dan Mudah Dibuat"
title: "Cara membuat 11. Sempol Ayam tanpa Ayam yang lezat dan Mudah Dibuat"
slug: 170-cara-membuat-11-sempol-ayam-tanpa-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-06-04T20:32:27.505Z
image: https://img-global.cpcdn.com/recipes/a2b0b1f499b3db79/680x482cq70/11-sempol-ayam-tanpa-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a2b0b1f499b3db79/680x482cq70/11-sempol-ayam-tanpa-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a2b0b1f499b3db79/680x482cq70/11-sempol-ayam-tanpa-ayam-foto-resep-utama.jpg
author: Emilie Lewis
ratingvalue: 4
reviewcount: 7
recipeingredient:
- " Bahan A "
- "250 gr Tepung terigu"
- "100 gr Tepung tapioka"
- " Bahan B "
- "4 pcs Bawang merah"
- "3 siung Bawang putih"
- " Garam"
- " Gula"
- " Kaldu jamur"
- " Kaldu ayam bubuk"
- " Lada bubuk"
- " Bahan Tambahan "
- "2 butir Telor"
- " Air"
- " Minyak goreng"
recipeinstructions:
- "Panaskan air sampai mendidih"
- "Goreng bawang merah dan bawang putih, kemudian haluskan."
- "Basukkan bahan A dan bahan B yg sudah halus kedalam baskom. Aduk hingga tercampur rata. Masukkan air hangat sedikit demi sedikit, aduk hingga kalis. Uji rasa"
- "Adonan yg telah kalis di bentuk seperti pada gambar. Dan ditusuk dengan tusuk sate."
- "Didihkan air untuk merebus. Kemudian rebus adonan hingga mengapung (tandanya sempol sudah matang). Angkat dan tiriskan. Ulangi hingga adonan sempol habis."
- "Panaskan minyak. Kemudian goreng sempol di minyak yg telah panas (5 detik saja). Kemudian masukkan ke dalam telur yg sudah di kocok dan diberi sedikit garam dan sedikit air (biar gurih dan sedikit encer). Kemudian goreng lagi hingga coklat keemasan. Angkat dan tiriskan"
- "Telur kocok yg masih sisa bisa digoreng jd telor gulung yaa.. Selamat mencoba.."
categories:
- Resep
tags:
- 11
- sempol
- ayam

katakunci: 11 sempol ayam 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dinner

---


![11. Sempol Ayam tanpa Ayam](https://img-global.cpcdn.com/recipes/a2b0b1f499b3db79/680x482cq70/11-sempol-ayam-tanpa-ayam-foto-resep-utama.jpg)

Jika anda seorang istri, menyuguhkan hidangan sedap pada famili adalah hal yang membahagiakan untuk kamu sendiri. Peran seorang ibu bukan cuman mengatur rumah saja, tetapi kamu pun harus menyediakan kebutuhan gizi tercukupi dan juga panganan yang dikonsumsi orang tercinta wajib nikmat.

Di era  sekarang, kita sebenarnya bisa membeli hidangan instan tanpa harus repot membuatnya dulu. Namun banyak juga lho mereka yang selalu ingin menghidangkan yang terlezat bagi orang tercintanya. Pasalnya, menyajikan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai selera famili. 



Apakah kamu salah satu penggemar 11. sempol ayam tanpa ayam?. Tahukah kamu, 11. sempol ayam tanpa ayam merupakan sajian khas di Nusantara yang kini disenangi oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Anda dapat membuat 11. sempol ayam tanpa ayam hasil sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di hari liburmu.

Anda tak perlu bingung jika kamu ingin menyantap 11. sempol ayam tanpa ayam, lantaran 11. sempol ayam tanpa ayam mudah untuk dicari dan kalian pun bisa membuatnya sendiri di rumah. 11. sempol ayam tanpa ayam boleh dibuat dengan beraneka cara. Saat ini ada banyak resep modern yang membuat 11. sempol ayam tanpa ayam semakin enak.

Resep 11. sempol ayam tanpa ayam pun mudah sekali untuk dibuat, lho. Kamu tidak usah capek-capek untuk memesan 11. sempol ayam tanpa ayam, tetapi Kita dapat menyiapkan sendiri di rumah. Bagi Kamu yang mau menghidangkannya, inilah resep untuk menyajikan 11. sempol ayam tanpa ayam yang lezat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan 11. Sempol Ayam tanpa Ayam:

1. Gunakan  Bahan A :
1. Gunakan 250 gr Tepung terigu
1. Gunakan 100 gr Tepung tapioka
1. Gunakan  Bahan B :
1. Gunakan 4 pcs Bawang merah
1. Sediakan 3 siung Bawang putih
1. Ambil  Garam
1. Ambil  Gula
1. Siapkan  Kaldu jamur
1. Sediakan  Kaldu ayam bubuk
1. Siapkan  Lada bubuk
1. Sediakan  Bahan Tambahan :
1. Sediakan 2 butir Telor
1. Ambil  Air
1. Sediakan  Minyak goreng




<!--inarticleads2-->

##### Cara membuat 11. Sempol Ayam tanpa Ayam:

1. Panaskan air sampai mendidih
1. Goreng bawang merah dan bawang putih, kemudian haluskan.
1. Basukkan bahan A dan bahan B yg sudah halus kedalam baskom. Aduk hingga tercampur rata. Masukkan air hangat sedikit demi sedikit, aduk hingga kalis. Uji rasa
1. Adonan yg telah kalis di bentuk seperti pada gambar. Dan ditusuk dengan tusuk sate.
1. Didihkan air untuk merebus. Kemudian rebus adonan hingga mengapung (tandanya sempol sudah matang). Angkat dan tiriskan. Ulangi hingga adonan sempol habis.
1. Panaskan minyak. Kemudian goreng sempol di minyak yg telah panas (5 detik saja). Kemudian masukkan ke dalam telur yg sudah di kocok dan diberi sedikit garam dan sedikit air (biar gurih dan sedikit encer). Kemudian goreng lagi hingga coklat keemasan. Angkat dan tiriskan
1. Telur kocok yg masih sisa bisa digoreng jd telor gulung yaa.. Selamat mencoba..




Wah ternyata cara membuat 11. sempol ayam tanpa ayam yang mantab sederhana ini enteng banget ya! Kalian semua mampu membuatnya. Cara Membuat 11. sempol ayam tanpa ayam Sangat cocok banget untuk anda yang sedang belajar memasak atau juga untuk kalian yang sudah jago memasak.

Tertarik untuk mencoba bikin resep 11. sempol ayam tanpa ayam lezat simple ini? Kalau kalian ingin, ayo kamu segera buruan menyiapkan alat dan bahannya, kemudian buat deh Resep 11. sempol ayam tanpa ayam yang mantab dan sederhana ini. Sungguh taidak sulit kan. 

Maka, daripada kamu berlama-lama, hayo langsung aja sajikan resep 11. sempol ayam tanpa ayam ini. Dijamin anda tiidak akan menyesal bikin resep 11. sempol ayam tanpa ayam mantab simple ini! Selamat berkreasi dengan resep 11. sempol ayam tanpa ayam enak sederhana ini di rumah kalian masing-masing,ya!.

