---
description: "Cara membuat Kare Ayam khas Solo yang nikmat dan Mudah Dibuat"
title: "Cara membuat Kare Ayam khas Solo yang nikmat dan Mudah Dibuat"
slug: 103-cara-membuat-kare-ayam-khas-solo-yang-nikmat-dan-mudah-dibuat
date: 2021-03-07T07:19:20.739Z
image: https://img-global.cpcdn.com/recipes/11f08e224f0c2817/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/11f08e224f0c2817/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/11f08e224f0c2817/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
author: George Bailey
ratingvalue: 3.9
reviewcount: 5
recipeingredient:
- "1/2 kg ayam fillet dada"
- "3 lembar Daun salam"
- "5 lembar Daun jeruk"
- "3 batang Sereh  geprek"
- "1 ruas jari Laos  geprek"
- " Garem"
- " Gula"
- " Merica bubuk"
- " Santan segitiga bisa pakai santan murni juga"
- " Bumbu Halus"
- "5 siung bawang putih"
- "5 siung bawang merah"
- "1/2 sdt Jinten"
- "1 sdt Ketumbar"
- "1 ruas Kunyit"
- "2 butir Kemiri"
- " Pelengkap"
- " Toge rebusrendam air panas"
- " Daun bawang"
- "1 buah Wortel"
- " Kering kentang parutiris tipis kentang dan goreng hingga kuning kecoklatan"
- "1 buah Jeruk nipis"
- " Sambel"
recipeinstructions:
- "Rebus ayam hingga air mendidih."
- "Blender/uleg bumbu halus, kemudian tumis hingga wangi. Masukkan laos, daun salam, daun sereh, daun jeruk."
- "Setelah wangi, tuang bumbu yang sudah ditumis ke dalam air rebusan ayam dengan ditambah air secukupnya. Koreksi rasa"
- "Setelah mendidih, tuang santan (saya tidak suka terlalu kental)"
- "Siap dihidangkan"
categories:
- Resep
tags:
- kare
- ayam
- khas

katakunci: kare ayam khas 
nutrition: 146 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dinner

---


![Kare Ayam khas Solo](https://img-global.cpcdn.com/recipes/11f08e224f0c2817/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, mempersiapkan hidangan enak kepada keluarga adalah hal yang mengasyikan bagi anda sendiri. Tanggung jawab seorang  wanita bukan saja mengatur rumah saja, namun anda pun harus menyediakan kebutuhan gizi tercukupi dan olahan yang disantap keluarga tercinta mesti lezat.

Di waktu  saat ini, kamu sebenarnya mampu memesan panganan praktis walaupun tanpa harus capek mengolahnya lebih dulu. Tetapi ada juga lho orang yang memang mau memberikan hidangan yang terbaik bagi orang yang dicintainya. Karena, menyajikan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan selera famili. 



Apakah anda merupakan seorang penyuka kare ayam khas solo?. Tahukah kamu, kare ayam khas solo merupakan sajian khas di Indonesia yang sekarang disenangi oleh kebanyakan orang dari berbagai wilayah di Indonesia. Kamu dapat memasak kare ayam khas solo olahan sendiri di rumahmu dan pasti jadi camilan favoritmu di akhir pekanmu.

Kamu jangan bingung jika kamu ingin menyantap kare ayam khas solo, lantaran kare ayam khas solo mudah untuk ditemukan dan kita pun boleh menghidangkannya sendiri di rumah. kare ayam khas solo bisa dimasak memalui berbagai cara. Sekarang ada banyak resep kekinian yang menjadikan kare ayam khas solo semakin nikmat.

Resep kare ayam khas solo juga mudah dibuat, lho. Kalian jangan capek-capek untuk memesan kare ayam khas solo, lantaran Kamu bisa menghidangkan di rumah sendiri. Bagi Anda yang akan menyajikannya, di bawah ini adalah cara untuk membuat kare ayam khas solo yang nikamat yang bisa Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Kare Ayam khas Solo:

1. Sediakan 1/2 kg ayam fillet (dada)
1. Sediakan 3 lembar Daun salam
1. Siapkan 5 lembar Daun jeruk
1. Sediakan 3 batang Sereh  (geprek)
1. Gunakan 1 ruas jari Laos  (geprek)
1. Siapkan  Garem
1. Siapkan  Gula
1. Sediakan  Merica bubuk
1. Sediakan  Santan segitiga (bisa pakai santan murni juga)
1. Sediakan  Bumbu Halus
1. Gunakan 5 siung bawang putih
1. Sediakan 5 siung bawang merah
1. Ambil 1/2 sdt Jinten
1. Ambil 1 sdt Ketumbar
1. Siapkan 1 ruas Kunyit
1. Gunakan 2 butir Kemiri
1. Ambil  Pelengkap
1. Sediakan  Toge (rebus/rendam air panas)
1. Sediakan  Daun bawang
1. Ambil 1 buah Wortel
1. Siapkan  Kering kentang (parut/iris tipis kentang dan goreng hingga kuning kecoklatan)
1. Ambil 1 buah Jeruk nipis
1. Sediakan  Sambel




<!--inarticleads2-->

##### Cara membuat Kare Ayam khas Solo:

1. Rebus ayam hingga air mendidih.
1. Blender/uleg bumbu halus, kemudian tumis hingga wangi. Masukkan laos, daun salam, daun sereh, daun jeruk.
1. Setelah wangi, tuang bumbu yang sudah ditumis ke dalam air rebusan ayam dengan ditambah air secukupnya. Koreksi rasa
1. Setelah mendidih, tuang santan (saya tidak suka terlalu kental)
1. Siap dihidangkan




Wah ternyata cara buat kare ayam khas solo yang nikamt tidak ribet ini enteng banget ya! Kita semua mampu membuatnya. Cara Membuat kare ayam khas solo Sangat sesuai banget untuk anda yang baru akan belajar memasak ataupun juga bagi kalian yang telah pandai dalam memasak.

Tertarik untuk mencoba buat resep kare ayam khas solo enak sederhana ini? Kalau anda mau, ayo kalian segera buruan siapkan peralatan dan bahan-bahannya, maka bikin deh Resep kare ayam khas solo yang nikmat dan sederhana ini. Benar-benar mudah kan. 

Jadi, daripada kalian berfikir lama-lama, maka kita langsung saja bikin resep kare ayam khas solo ini. Dijamin kamu tak akan menyesal bikin resep kare ayam khas solo mantab tidak ribet ini! Selamat berkreasi dengan resep kare ayam khas solo lezat tidak rumit ini di tempat tinggal masing-masing,oke!.

