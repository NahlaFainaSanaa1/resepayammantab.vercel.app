---
description: "Resep Day. 260 Ati Ayam Masak Santan Berempah (14 month+) yang enak dan Mudah Dibuat"
title: "Resep Day. 260 Ati Ayam Masak Santan Berempah (14 month+) yang enak dan Mudah Dibuat"
slug: 310-resep-day-260-ati-ayam-masak-santan-berempah-14-month-yang-enak-dan-mudah-dibuat
date: 2021-03-24T04:03:35.481Z
image: https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg
author: Christina Lawson
ratingvalue: 4
reviewcount: 15
recipeingredient:
- "1 buah ati ayam ungkep           lihat resep"
- "1 batang kacang panjang potong2"
- "1/2 bagian oyong potong2"
- "1 siung bawang putih iris tipis"
- "2 buah bawang merah iris tipis"
- "1 batang serai geprek"
- "1/4 sdt kayumanis bubuk"
- "1/4 sdt pala bubuk"
- "1/4 sdt kunyit bubuk"
- "1/4 sdt ketumbar bubuk"
- "1 sdm minyak samin"
- "1 sdm santan instan"
- "1 batang seledri cincang halus"
- "Sejumput garam"
- "200 ml air"
recipeinstructions:
- "Lelehkan minyak samin. Tumis bawang merah dan bawang putih hingga harum. Masukkan serai, kayumanis bubuk, pala bubuk, kunyit bubuk, ketumbar bubuk dan sedikit air. Masak sekitar 1 menit. Tambahkan sisa air, masak hingga mendidih."
- "Masukkan kacang panjang. Masak hingga air berkurang setengahnya. Masukkan oyong dan ati ayam, masak hingga air hampir habis."
- "Tambahkan santan instan dan seledri. Aduk rata. Masak sebentar, matikan api. Tambahkan garam, aduk rata."
- "Sajikan dengan nasi putih hangat."
categories:
- Resep
tags:
- day
- 260
- ati

katakunci: day 260 ati 
nutrition: 160 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Day. 260 Ati Ayam Masak Santan Berempah (14 month+)](https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg)

Apabila kalian seorang yang hobi masak, menyajikan olahan lezat pada keluarga merupakan hal yang mengasyikan untuk kita sendiri. Tugas seorang ibu bukan cuma mengurus rumah saja, tapi kamu juga wajib memastikan keperluan nutrisi tercukupi dan juga santapan yang disantap orang tercinta harus menggugah selera.

Di era  sekarang, kamu memang mampu mengorder masakan siap saji meski tanpa harus ribet memasaknya dulu. Tapi ada juga lho orang yang memang ingin memberikan hidangan yang terlezat untuk orang tercintanya. Karena, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan masakan kesukaan orang tercinta. 



Apakah anda merupakan seorang penikmat day. 260 ati ayam masak santan berempah (14 month+)?. Tahukah kamu, day. 260 ati ayam masak santan berempah (14 month+) adalah sajian khas di Nusantara yang saat ini disukai oleh banyak orang di hampir setiap daerah di Nusantara. Kita dapat menyajikan day. 260 ati ayam masak santan berempah (14 month+) olahan sendiri di rumahmu dan pasti jadi camilan kesenanganmu di hari libur.

Kamu tak perlu bingung jika kamu ingin mendapatkan day. 260 ati ayam masak santan berempah (14 month+), karena day. 260 ati ayam masak santan berempah (14 month+) tidak sulit untuk dicari dan kamu pun dapat mengolahnya sendiri di tempatmu. day. 260 ati ayam masak santan berempah (14 month+) bisa diolah memalui beraneka cara. Kini pun telah banyak sekali resep kekinian yang membuat day. 260 ati ayam masak santan berempah (14 month+) semakin lebih enak.

Resep day. 260 ati ayam masak santan berempah (14 month+) juga sangat mudah untuk dibikin, lho. Kita tidak usah capek-capek untuk membeli day. 260 ati ayam masak santan berempah (14 month+), karena Kita dapat menyajikan sendiri di rumah. Bagi Kamu yang mau menghidangkannya, berikut cara untuk membuat day. 260 ati ayam masak santan berempah (14 month+) yang enak yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Day. 260 Ati Ayam Masak Santan Berempah (14 month+):

1. Gunakan 1 buah ati ayam ungkep           (lihat resep)
1. Gunakan 1 batang kacang panjang, potong2
1. Sediakan 1/2 bagian oyong, potong2
1. Siapkan 1 siung bawang putih, iris tipis
1. Sediakan 2 buah bawang merah, iris tipis
1. Siapkan 1 batang serai, geprek
1. Sediakan 1/4 sdt kayumanis bubuk
1. Sediakan 1/4 sdt pala bubuk
1. Gunakan 1/4 sdt kunyit bubuk
1. Gunakan 1/4 sdt ketumbar bubuk
1. Ambil 1 sdm minyak samin
1. Gunakan 1 sdm santan instan
1. Siapkan 1 batang seledri, cincang halus
1. Sediakan Sejumput garam
1. Sediakan 200 ml air




<!--inarticleads2-->

##### Langkah-langkah membuat Day. 260 Ati Ayam Masak Santan Berempah (14 month+):

1. Lelehkan minyak samin. Tumis bawang merah dan bawang putih hingga harum. Masukkan serai, kayumanis bubuk, pala bubuk, kunyit bubuk, ketumbar bubuk dan sedikit air. Masak sekitar 1 menit. Tambahkan sisa air, masak hingga mendidih.
1. Masukkan kacang panjang. Masak hingga air berkurang setengahnya. Masukkan oyong dan ati ayam, masak hingga air hampir habis.
1. Tambahkan santan instan dan seledri. Aduk rata. Masak sebentar, matikan api. Tambahkan garam, aduk rata.
1. Sajikan dengan nasi putih hangat.




Wah ternyata resep day. 260 ati ayam masak santan berempah (14 month+) yang nikamt tidak rumit ini mudah sekali ya! Kita semua bisa mencobanya. Cara Membuat day. 260 ati ayam masak santan berempah (14 month+) Sesuai banget buat kamu yang baru belajar memasak ataupun untuk kamu yang telah ahli memasak.

Apakah kamu ingin mencoba buat resep day. 260 ati ayam masak santan berempah (14 month+) nikmat simple ini? Kalau kamu ingin, ayo kamu segera menyiapkan peralatan dan bahannya, maka buat deh Resep day. 260 ati ayam masak santan berempah (14 month+) yang mantab dan sederhana ini. Betul-betul taidak sulit kan. 

Maka dari itu, daripada kamu berfikir lama-lama, ayo kita langsung hidangkan resep day. 260 ati ayam masak santan berempah (14 month+) ini. Pasti anda tiidak akan nyesel sudah bikin resep day. 260 ati ayam masak santan berempah (14 month+) mantab simple ini! Selamat berkreasi dengan resep day. 260 ati ayam masak santan berempah (14 month+) enak tidak rumit ini di tempat tinggal sendiri,oke!.

