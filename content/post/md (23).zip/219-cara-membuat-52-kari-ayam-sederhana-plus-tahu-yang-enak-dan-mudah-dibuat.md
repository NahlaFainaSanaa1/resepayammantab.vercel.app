---
description: "Cara membuat 52. Kari Ayam Sederhana plus Tahu yang enak dan Mudah Dibuat"
title: "Cara membuat 52. Kari Ayam Sederhana plus Tahu yang enak dan Mudah Dibuat"
slug: 219-cara-membuat-52-kari-ayam-sederhana-plus-tahu-yang-enak-dan-mudah-dibuat
date: 2021-04-18T00:14:56.956Z
image: https://img-global.cpcdn.com/recipes/330daa346bab8864/680x482cq70/52-kari-ayam-sederhana-plus-tahu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/330daa346bab8864/680x482cq70/52-kari-ayam-sederhana-plus-tahu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/330daa346bab8864/680x482cq70/52-kari-ayam-sederhana-plus-tahu-foto-resep-utama.jpg
author: Clayton Obrien
ratingvalue: 4.7
reviewcount: 11
recipeingredient:
- "1/2 ekor Ayam"
- "6 potong Tahu Putih"
- "1 bks santan Kara 65ml"
- "4 bh Cabe Merah Keriting"
- "10 bh Cabe Rawit Hijau"
- "10 siung Bawang Merah"
- "5 siung Bawang Putih"
- "Seruas jari Lengkuas"
- "Seruas jari Kunyit"
- "Seruas jari Jahe"
- "5 butir Kemiri"
- "1 sdm ketumbar"
- "1 batang Serai"
- "2 lembar Daun Salam"
- "2 lembar Daun Jeruk"
- "secukupnya Air Garam dan Gula"
recipeinstructions:
- "Siapkan dan bersihkan semua bahan. Ayam dipotong sesuai selera, tahu putih rendam diair garam."
- "Haluskan/blender semua bahan bumbu kecuali serai, daun salam dan daun jeruk"
- "Panaskan minyak dan tumis bumbu halus tadi. Aduk sampai harum, masukkan serai, daun salam dan daun jeruk."
- "Setelah harum. Masukkan potongan ayam. Aduk bolak balik. Lalu masukkan santan dan air secukupnya."
- "Goreng tahu putih dan masukkan ke dalam santan tadi. Aduk sampai santan dan ayam matang. Masukkan garam dan gula secukupnya."
- "Sajikan sebagai santapan bersama keluarga."
categories:
- Resep
tags:
- 52
- kari
- ayam

katakunci: 52 kari ayam 
nutrition: 141 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dessert

---


![52. Kari Ayam Sederhana plus Tahu](https://img-global.cpcdn.com/recipes/330daa346bab8864/680x482cq70/52-kari-ayam-sederhana-plus-tahu-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan hidangan nikmat bagi keluarga tercinta adalah suatu hal yang membahagiakan bagi kita sendiri. Tugas seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, tapi anda juga wajib memastikan kebutuhan gizi terpenuhi dan santapan yang dimakan keluarga tercinta mesti enak.

Di waktu  sekarang, kalian memang dapat mengorder hidangan instan tidak harus repot mengolahnya dahulu. Tetapi ada juga orang yang selalu mau memberikan yang terbaik bagi keluarganya. Pasalnya, menyajikan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penikmat 52. kari ayam sederhana plus tahu?. Tahukah kamu, 52. kari ayam sederhana plus tahu adalah hidangan khas di Nusantara yang sekarang disukai oleh setiap orang di berbagai wilayah di Indonesia. Kamu dapat menyajikan 52. kari ayam sederhana plus tahu olahan sendiri di rumah dan dapat dijadikan camilan favorit di hari libur.

Kita jangan bingung untuk memakan 52. kari ayam sederhana plus tahu, lantaran 52. kari ayam sederhana plus tahu gampang untuk dicari dan kalian pun dapat membuatnya sendiri di tempatmu. 52. kari ayam sederhana plus tahu dapat dimasak dengan beraneka cara. Sekarang ada banyak resep kekinian yang menjadikan 52. kari ayam sederhana plus tahu semakin enak.

Resep 52. kari ayam sederhana plus tahu juga mudah sekali untuk dibuat, lho. Kamu tidak perlu capek-capek untuk memesan 52. kari ayam sederhana plus tahu, sebab Kalian bisa menghidangkan di rumahmu. Untuk Anda yang ingin menyajikannya, berikut ini cara membuat 52. kari ayam sederhana plus tahu yang lezat yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan 52. Kari Ayam Sederhana plus Tahu:

1. Ambil 1/2 ekor Ayam
1. Sediakan 6 potong Tahu Putih
1. Siapkan 1 bks santan Kara 65ml
1. Sediakan 4 bh Cabe Merah Keriting
1. Sediakan 10 bh Cabe Rawit Hijau
1. Sediakan 10 siung Bawang Merah
1. Ambil 5 siung Bawang Putih
1. Sediakan Seruas jari Lengkuas
1. Gunakan Seruas jari Kunyit
1. Sediakan Seruas jari Jahe
1. Sediakan 5 butir Kemiri
1. Ambil 1 sdm ketumbar
1. Gunakan 1 batang Serai
1. Siapkan 2 lembar Daun Salam
1. Sediakan 2 lembar Daun Jeruk
1. Sediakan secukupnya Air, Garam dan Gula




<!--inarticleads2-->

##### Cara membuat 52. Kari Ayam Sederhana plus Tahu:

1. Siapkan dan bersihkan semua bahan. Ayam dipotong sesuai selera, tahu putih rendam diair garam.
1. Haluskan/blender semua bahan bumbu kecuali serai, daun salam dan daun jeruk
1. Panaskan minyak dan tumis bumbu halus tadi. Aduk sampai harum, masukkan serai, daun salam dan daun jeruk.
1. Setelah harum. Masukkan potongan ayam. Aduk bolak balik. Lalu masukkan santan dan air secukupnya.
1. Goreng tahu putih dan masukkan ke dalam santan tadi. Aduk sampai santan dan ayam matang. Masukkan garam dan gula secukupnya.
1. Sajikan sebagai santapan bersama keluarga.




Ternyata cara membuat 52. kari ayam sederhana plus tahu yang mantab tidak rumit ini enteng sekali ya! Anda Semua bisa menghidangkannya. Resep 52. kari ayam sederhana plus tahu Sangat sesuai banget buat kamu yang baru mau belajar memasak maupun juga bagi kalian yang telah hebat dalam memasak.

Apakah kamu tertarik mencoba membuat resep 52. kari ayam sederhana plus tahu mantab tidak rumit ini? Kalau anda mau, ayo kalian segera buruan siapkan alat dan bahannya, maka bikin deh Resep 52. kari ayam sederhana plus tahu yang mantab dan sederhana ini. Sungguh taidak sulit kan. 

Maka dari itu, daripada kamu diam saja, maka kita langsung buat resep 52. kari ayam sederhana plus tahu ini. Dijamin kalian tak akan menyesal membuat resep 52. kari ayam sederhana plus tahu lezat tidak rumit ini! Selamat mencoba dengan resep 52. kari ayam sederhana plus tahu mantab tidak ribet ini di rumah kalian sendiri,oke!.

