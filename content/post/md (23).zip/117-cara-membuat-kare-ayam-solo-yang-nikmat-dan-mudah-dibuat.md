---
description: "Cara membuat Kare Ayam Solo yang nikmat dan Mudah Dibuat"
title: "Cara membuat Kare Ayam Solo yang nikmat dan Mudah Dibuat"
slug: 117-cara-membuat-kare-ayam-solo-yang-nikmat-dan-mudah-dibuat
date: 2021-06-14T20:01:55.870Z
image: https://img-global.cpcdn.com/recipes/cd602235ce7c0707/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cd602235ce7c0707/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cd602235ce7c0707/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Adrian Briggs
ratingvalue: 3.8
reviewcount: 3
recipeingredient:
- "1/4 kg daging ayam"
- "1 Liter air"
- "1 bungkus santan instan"
- "1 batang serai"
- "8 lembar daun jeruk"
- "2 lembar daun salam"
- "1 jempol lengkuas"
- "2 ruas jahe"
- "1 buah tomat merah"
- "1 sdm gula"
- "4 sdm minyak goreng"
- " Bumbu halus"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "1 sdt merica bubuk"
- "1/2 sdt ketumbar bubuk"
- "3 butir kemiri"
- "2 ruas kunyit"
- "2 sdm garam"
- " Pelengkap"
- " Taoge"
- " Kubis"
- " Seledri"
- " Soun skip"
- " Keripik kentang skip"
- " Wortel skip"
- " Bawang goreng"
recipeinstructions:
- "Ulek bumbu hingga halus. Geprek jahe, serai, lengkuas. Panaskan 700ml air dalam panci, rebus daging ayam yg sdh dicuci bersih."
- "Panaskan sedikit minyak dalam wajan, tumis bumbu hingga harum. Masukkan jahe, serai, lengkuas, daun salam dan daun jeruk. Aduk rata. Tambahkan sedikit air, tumis lg hingga bumbu tanak."
- "Masukkan bumbu kedalam panci berisi rebusan daging ayam. Tambahkan gula pasir lalu aduk rata dan tunggu mendidih. Larutkan santan instan dg 300ml air, masukkan kedalam panci. Masukkan irisan tomat, aduk rata dan tunggu hingga mendidih kembali. Koreksi rasa."
- "Panaskan air dalam panci, rebus taoge hingga lunak (kurleb 5 menit), angkat dan tiriskan. Iris tipis2 kol dan daun seledri. Ambil daging ayam didalam panci berisi kuah, tiriskan lalu suwir2."
- "Tata kol, taoge dan suwiran ayam kedalam mangkuk, siram dg kuah kare lalu taburi daun seledri dan bawang goreng. Kare siap disajikan dg nasi hangat dan irisan cabe/sambal rebus jika suka pedas."
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 289 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dinner

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/cd602235ce7c0707/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan hidangan lezat bagi famili merupakan hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang ibu bukan hanya menjaga rumah saja, namun kamu pun harus memastikan kebutuhan nutrisi tercukupi dan hidangan yang dimakan keluarga tercinta wajib nikmat.

Di era  saat ini, kalian memang dapat memesan santapan praktis tidak harus capek membuatnya lebih dulu. Tapi banyak juga lho mereka yang memang ingin memberikan yang terlezat untuk orang tercintanya. Lantaran, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penggemar kare ayam solo?. Tahukah kamu, kare ayam solo merupakan makanan khas di Indonesia yang sekarang digemari oleh banyak orang di berbagai tempat di Indonesia. Kalian dapat memasak kare ayam solo sendiri di rumah dan pasti jadi santapan kesukaanmu di hari libur.

Kamu tidak usah bingung untuk menyantap kare ayam solo, sebab kare ayam solo sangat mudah untuk dicari dan juga kalian pun boleh menghidangkannya sendiri di rumah. kare ayam solo bisa diolah memalui beraneka cara. Saat ini telah banyak resep modern yang membuat kare ayam solo semakin mantap.

Resep kare ayam solo juga mudah dibuat, lho. Kamu tidak usah capek-capek untuk membeli kare ayam solo, sebab Kamu dapat menghidangkan ditempatmu. Untuk Anda yang mau mencobanya, berikut ini cara membuat kare ayam solo yang nikamat yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Kare Ayam Solo:

1. Siapkan 1/4 kg daging ayam
1. Siapkan 1 Liter air
1. Sediakan 1 bungkus santan instan
1. Sediakan 1 batang serai
1. Siapkan 8 lembar daun jeruk
1. Gunakan 2 lembar daun salam
1. Siapkan 1 jempol lengkuas
1. Gunakan 2 ruas jahe
1. Siapkan 1 buah tomat merah
1. Gunakan 1 sdm gula
1. Gunakan 4 sdm minyak goreng
1. Ambil  Bumbu halus:
1. Gunakan 8 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Gunakan 1 sdt merica bubuk
1. Siapkan 1/2 sdt ketumbar bubuk
1. Ambil 3 butir kemiri
1. Ambil 2 ruas kunyit
1. Siapkan 2 sdm garam
1. Siapkan  Pelengkap:
1. Siapkan  Taoge
1. Ambil  Kubis
1. Gunakan  Seledri
1. Sediakan  Soun (skip)
1. Siapkan  Keripik kentang (skip)
1. Siapkan  Wortel (skip)
1. Siapkan  Bawang goreng




<!--inarticleads2-->

##### Cara menyiapkan Kare Ayam Solo:

1. Ulek bumbu hingga halus. Geprek jahe, serai, lengkuas. Panaskan 700ml air dalam panci, rebus daging ayam yg sdh dicuci bersih.
1. Panaskan sedikit minyak dalam wajan, tumis bumbu hingga harum. Masukkan jahe, serai, lengkuas, daun salam dan daun jeruk. Aduk rata. Tambahkan sedikit air, tumis lg hingga bumbu tanak.
1. Masukkan bumbu kedalam panci berisi rebusan daging ayam. Tambahkan gula pasir lalu aduk rata dan tunggu mendidih. Larutkan santan instan dg 300ml air, masukkan kedalam panci. Masukkan irisan tomat, aduk rata dan tunggu hingga mendidih kembali. Koreksi rasa.
1. Panaskan air dalam panci, rebus taoge hingga lunak (kurleb 5 menit), angkat dan tiriskan. Iris tipis2 kol dan daun seledri. Ambil daging ayam didalam panci berisi kuah, tiriskan lalu suwir2.
1. Tata kol, taoge dan suwiran ayam kedalam mangkuk, siram dg kuah kare lalu taburi daun seledri dan bawang goreng. Kare siap disajikan dg nasi hangat dan irisan cabe/sambal rebus jika suka pedas.




Ternyata cara membuat kare ayam solo yang lezat sederhana ini enteng sekali ya! Kalian semua dapat menghidangkannya. Resep kare ayam solo Cocok sekali buat kita yang sedang belajar memasak maupun juga untuk kalian yang sudah hebat dalam memasak.

Tertarik untuk mencoba buat resep kare ayam solo mantab sederhana ini? Kalau tertarik, yuk kita segera buruan siapin peralatan dan bahannya, lalu bikin deh Resep kare ayam solo yang nikmat dan sederhana ini. Sangat taidak sulit kan. 

Jadi, ketimbang kamu diam saja, maka kita langsung sajikan resep kare ayam solo ini. Dijamin kamu tak akan menyesal sudah bikin resep kare ayam solo nikmat tidak rumit ini! Selamat berkreasi dengan resep kare ayam solo enak tidak ribet ini di rumah sendiri,ya!.

