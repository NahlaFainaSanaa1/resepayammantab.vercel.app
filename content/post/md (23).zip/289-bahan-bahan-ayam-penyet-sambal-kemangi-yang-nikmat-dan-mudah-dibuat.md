---
description: "Bahan-bahan Ayam Penyet Sambal Kemangi yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Penyet Sambal Kemangi yang nikmat dan Mudah Dibuat"
slug: 289-bahan-bahan-ayam-penyet-sambal-kemangi-yang-nikmat-dan-mudah-dibuat
date: 2021-07-04T07:24:59.107Z
image: https://img-global.cpcdn.com/recipes/13a62613fb439188/680x482cq70/ayam-penyet-sambal-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/13a62613fb439188/680x482cq70/ayam-penyet-sambal-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/13a62613fb439188/680x482cq70/ayam-penyet-sambal-kemangi-foto-resep-utama.jpg
author: Howard Chavez
ratingvalue: 4.3
reviewcount: 12
recipeingredient:
- "1 kg ayampotong2"
- "secukupnya Minyak goreng"
- " Bahan marinasi"
- "5 siung bawang putihhaluskan"
- "1 sdt lada putih bubuk"
- "2 sdt garam"
- "20 ml air jeruk nipis"
- " Bahan tepung basah liquid"
- "150 ml air kekentalan sesuaikan"
- "5 sdm tepung bumbu ayam saa"
- "1 sdm tepung protein tinggi"
- "1 sdt lada"
- " Bahan tepung kering"
- "15 sdm tepung protein tinggi"
- "7 sdm tepung bumbu ayam saa"
- "2 sdt lada putih bubuk"
- "2 sdt paprika bubuk"
- "1 sdt baking powder"
- " Sambal kemangi"
- "4 buah cabai merah besar"
- "15 buah cabai rawit merah"
- "1 blok terasi ac bakar"
- "secukupnya Garam"
- "secukupnya Gula pasir"
- "1 ikat kecil kemangi"
- "1 sdm minyak panas"
recipeinstructions:
- "Cuci bersih ayam,rendam ayam dgn bumbu marinasi selama 15 menit."
- "Campurkan semua adonan basah,aduk rata &amp; sisihkan.Di wadah berbeda campurkan adonan tepung kering,aduk rata.Panaskan minyak goreng dgn api sedang."
- "Masukan ayam yg SDH di marinasi ke dalam tepung basah,lumuri yg tercampur rata,tiriskan.Masukan ke dalam tepung kering hingga rata.Ulangi 1x lagi.(TDK perlu di cubit2)"
- "Masukan ayam ke dalam minyak tadi,setelah ke 2 sisi nya kecokltan,kecilkan api (untuk menantang kan bagian dalam) angkat &amp; tiriskan.Lakukan hingga ayam habis."
- "Ulek cabai merah besar,cabai rawit,terasi bakar,gula &amp; garam,masukan bawang merah,memarkan.Kemudian masukan kemangi,tekan2 sedikit &amp; siram dgn minyak panas,aduk rata &amp; koreksi rasa. Ambil ayam,letakkan di dalam cobek,pennyet2.Sajikan"
categories:
- Resep
tags:
- ayam
- penyet
- sambal

katakunci: ayam penyet sambal 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Penyet Sambal Kemangi](https://img-global.cpcdn.com/recipes/13a62613fb439188/680x482cq70/ayam-penyet-sambal-kemangi-foto-resep-utama.jpg)

Andai anda seorang wanita, menyuguhkan olahan enak pada orang tercinta merupakan suatu hal yang membahagiakan untuk kita sendiri. Tugas seorang  wanita bukan sekadar menangani rumah saja, tetapi anda juga wajib memastikan kebutuhan nutrisi terpenuhi dan juga olahan yang dimakan orang tercinta harus mantab.

Di masa  saat ini, anda sebenarnya bisa memesan olahan jadi tidak harus capek mengolahnya lebih dulu. Namun ada juga lho mereka yang memang ingin memberikan makanan yang terenak bagi keluarganya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut berdasarkan selera famili. 



Apakah anda adalah salah satu penikmat ayam penyet sambal kemangi?. Asal kamu tahu, ayam penyet sambal kemangi merupakan makanan khas di Nusantara yang sekarang disukai oleh banyak orang di hampir setiap daerah di Indonesia. Kalian dapat menghidangkan ayam penyet sambal kemangi hasil sendiri di rumah dan dapat dijadikan camilan kesenanganmu di hari libur.

Kalian jangan bingung jika kamu ingin mendapatkan ayam penyet sambal kemangi, karena ayam penyet sambal kemangi gampang untuk ditemukan dan juga anda pun boleh membuatnya sendiri di rumah. ayam penyet sambal kemangi boleh diolah memalui beraneka cara. Saat ini sudah banyak banget resep kekinian yang membuat ayam penyet sambal kemangi semakin lebih mantap.

Resep ayam penyet sambal kemangi juga gampang dibuat, lho. Anda tidak usah repot-repot untuk membeli ayam penyet sambal kemangi, lantaran Kamu bisa menyiapkan ditempatmu. Bagi Kita yang ingin menyajikannya, di bawah ini adalah cara untuk menyajikan ayam penyet sambal kemangi yang mantab yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Penyet Sambal Kemangi:

1. Siapkan 1 kg ayam,potong2
1. Ambil secukupnya Minyak goreng
1. Siapkan  Bahan marinasi:
1. Sediakan 5 siung bawang putih,haluskan
1. Siapkan 1 sdt lada putih bubuk
1. Ambil 2 sdt garam
1. Sediakan 20 ml air jeruk nipis
1. Gunakan  Bahan tepung basah (liquid)
1. Gunakan 150 ml air (kekentalan sesuaikan)
1. Gunakan 5 sdm tepung bumbu ayam sa*a
1. Gunakan 1 sdm tepung protein tinggi
1. Gunakan 1 sdt lada
1. Sediakan  Bahan tepung kering
1. Sediakan 15 sdm tepung protein tinggi
1. Ambil 7 sdm tepung bumbu ayam sa*a
1. Ambil 2 sdt lada putih bubuk
1. Siapkan 2 sdt paprika bubuk
1. Gunakan 1 sdt baking powder
1. Siapkan  Sambal kemangi
1. Sediakan 4 buah cabai merah besar
1. Gunakan 15 buah cabai rawit merah
1. Siapkan 1 blok terasi a*c bakar
1. Gunakan secukupnya Garam
1. Sediakan secukupnya Gula pasir
1. Gunakan 1 ikat kecil kemangi
1. Siapkan 1 sdm minyak panas




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Penyet Sambal Kemangi:

1. Cuci bersih ayam,rendam ayam dgn bumbu marinasi selama 15 menit.
1. Campurkan semua adonan basah,aduk rata &amp; sisihkan.Di wadah berbeda campurkan adonan tepung kering,aduk rata.Panaskan minyak goreng dgn api sedang.
1. Masukan ayam yg SDH di marinasi ke dalam tepung basah,lumuri yg tercampur rata,tiriskan.Masukan ke dalam tepung kering hingga rata.Ulangi 1x lagi.(TDK perlu di cubit2)
1. Masukan ayam ke dalam minyak tadi,setelah ke 2 sisi nya kecokltan,kecilkan api (untuk menantang kan bagian dalam) angkat &amp; tiriskan.Lakukan hingga ayam habis.
1. Ulek cabai merah besar,cabai rawit,terasi bakar,gula &amp; garam,masukan bawang merah,memarkan.Kemudian masukan kemangi,tekan2 sedikit &amp; siram dgn minyak panas,aduk rata &amp; koreksi rasa. - Ambil ayam,letakkan di dalam cobek,pennyet2.Sajikan




Ternyata cara buat ayam penyet sambal kemangi yang nikamt sederhana ini gampang sekali ya! Semua orang bisa membuatnya. Resep ayam penyet sambal kemangi Cocok banget untuk kita yang sedang belajar memasak ataupun juga bagi anda yang telah ahli memasak.

Tertarik untuk mencoba membuat resep ayam penyet sambal kemangi nikmat simple ini? Kalau anda ingin, ayo kalian segera buruan siapkan peralatan dan bahan-bahannya, kemudian buat deh Resep ayam penyet sambal kemangi yang mantab dan tidak ribet ini. Betul-betul gampang kan. 

Oleh karena itu, ketimbang kalian berlama-lama, hayo kita langsung saja sajikan resep ayam penyet sambal kemangi ini. Pasti anda tak akan menyesal bikin resep ayam penyet sambal kemangi nikmat sederhana ini! Selamat berkreasi dengan resep ayam penyet sambal kemangi nikmat sederhana ini di rumah kalian masing-masing,oke!.

