---
description: "Cara buat Sup Sop Ayam Makaroni Rumahan Sederhana Untuk Jualan"
title: "Cara buat Sup Sop Ayam Makaroni Rumahan Sederhana Untuk Jualan"
slug: 344-cara-buat-sup-sop-ayam-makaroni-rumahan-sederhana-untuk-jualan
date: 2021-01-24T18:50:59.621Z
image: https://img-global.cpcdn.com/recipes/0ed397958e8ca4b6/680x482cq70/sup-sop-ayam-makaroni-rumahan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ed397958e8ca4b6/680x482cq70/sup-sop-ayam-makaroni-rumahan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ed397958e8ca4b6/680x482cq70/sup-sop-ayam-makaroni-rumahan-foto-resep-utama.jpg
author: Elmer Burke
ratingvalue: 3.2
reviewcount: 5
recipeingredient:
- "4 potong paha atas ayam"
- "20 gr makaroni bentuk bebas Makaroni dimasukkan paling terakhir"
- "1 pcs wortel"
- "1 pcs kentang"
- " Lada bubuk"
- "1/2 sachet kaldu ayam bubuk"
- "1/2 sdm kaldu all purpose seasoning"
- "10 gr kacang polong"
- "1 pcs jagung muda"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1 batang daun bawang"
- "3 lbr sawi putih"
- "500 ml air boleh ditambah karena bahan pasta seperti makaroni dll itu menyerap air"
- " Gula pasir optional"
- "1 sdt ketumbar bubuk"
recipeinstructions:
- "Rebus bahan (bawang merah, bawang putih, kaldu bubuk, ketumbar bubuk) sampai bau harum."
- "Masukkan wortel, kentang, jagung muda."
- "Masukkan ayam (sudah direbus terpisah untuk hilangkan kotoran dan kurangi lemak), kacang polong. Setelah kira2 15 menit baru masukkan sawi putih."
- "5 menit sebelum matang, masukkan makaroni."
categories:
- Resep
tags:
- sup
- sop
- ayam

katakunci: sup sop ayam 
nutrition: 159 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Dinner

---


![Sup Sop Ayam Makaroni Rumahan](https://img-global.cpcdn.com/recipes/0ed397958e8ca4b6/680x482cq70/sup-sop-ayam-makaroni-rumahan-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan hidangan enak untuk famili merupakan suatu hal yang mengasyikan untuk anda sendiri. Tanggung jawab seorang ibu Tidak cuman menjaga rumah saja, tetapi kamu juga harus memastikan keperluan gizi tercukupi dan olahan yang dimakan orang tercinta harus enak.

Di era  sekarang, kalian sebenarnya bisa memesan olahan siap saji meski tidak harus ribet membuatnya lebih dulu. Tetapi ada juga lho orang yang selalu ingin menyajikan yang terlezat untuk orang tercintanya. Lantaran, memasak yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan orang tercinta. 



Mungkinkah kamu seorang penggemar sup sop ayam makaroni rumahan?. Tahukah kamu, sup sop ayam makaroni rumahan adalah hidangan khas di Nusantara yang saat ini disenangi oleh kebanyakan orang di berbagai daerah di Nusantara. Kita bisa menghidangkan sup sop ayam makaroni rumahan sendiri di rumahmu dan boleh jadi santapan favoritmu di akhir pekanmu.

Kalian tidak usah bingung untuk mendapatkan sup sop ayam makaroni rumahan, sebab sup sop ayam makaroni rumahan sangat mudah untuk dicari dan juga kalian pun boleh membuatnya sendiri di tempatmu. sup sop ayam makaroni rumahan dapat diolah dengan berbagai cara. Kini pun telah banyak sekali cara kekinian yang membuat sup sop ayam makaroni rumahan lebih nikmat.

Resep sup sop ayam makaroni rumahan juga sangat gampang untuk dibikin, lho. Kalian jangan repot-repot untuk memesan sup sop ayam makaroni rumahan, tetapi Kamu bisa menyajikan di rumah sendiri. Bagi Kamu yang ingin membuatnya, dibawah ini merupakan cara menyajikan sup sop ayam makaroni rumahan yang nikamat yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Sup Sop Ayam Makaroni Rumahan:

1. Sediakan 4 potong paha atas ayam
1. Siapkan 20 gr makaroni (bentuk bebas). Makaroni dimasukkan paling terakhir
1. Sediakan 1 pcs wortel
1. Siapkan 1 pcs kentang
1. Ambil  Lada bubuk
1. Sediakan 1/2 sachet kaldu ayam bubuk
1. Sediakan 1/2 sdm kaldu all purpose seasoning
1. Siapkan 10 gr kacang polong
1. Ambil 1 pcs jagung muda
1. Ambil 6 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Siapkan 1 batang daun bawang
1. Sediakan 3 lbr sawi putih
1. Ambil 500 ml air (boleh ditambah karena bahan pasta seperti makaroni, dll itu menyerap air)
1. Gunakan  Gula pasir (optional)
1. Gunakan 1 sdt ketumbar bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Sup Sop Ayam Makaroni Rumahan:

1. Rebus bahan (bawang merah, bawang putih, kaldu bubuk, ketumbar bubuk) sampai bau harum.
1. Masukkan wortel, kentang, jagung muda.
1. Masukkan ayam (sudah direbus terpisah untuk hilangkan kotoran dan kurangi lemak), kacang polong. Setelah kira2 15 menit baru masukkan sawi putih.
1. 5 menit sebelum matang, masukkan makaroni.




Ternyata cara membuat sup sop ayam makaroni rumahan yang mantab tidak ribet ini enteng banget ya! Kita semua mampu menghidangkannya. Cara Membuat sup sop ayam makaroni rumahan Cocok sekali untuk kamu yang baru mau belajar memasak maupun bagi anda yang sudah lihai dalam memasak.

Apakah kamu mau mulai mencoba bikin resep sup sop ayam makaroni rumahan nikmat tidak ribet ini? Kalau anda tertarik, ayo kamu segera buruan siapkan alat-alat dan bahan-bahannya, maka buat deh Resep sup sop ayam makaroni rumahan yang lezat dan simple ini. Benar-benar gampang kan. 

Jadi, daripada kamu berlama-lama, ayo kita langsung bikin resep sup sop ayam makaroni rumahan ini. Dijamin kalian tak akan nyesel sudah bikin resep sup sop ayam makaroni rumahan mantab tidak ribet ini! Selamat berkreasi dengan resep sup sop ayam makaroni rumahan mantab tidak ribet ini di rumah kalian masing-masing,ya!.

