---
description: "Bahan-bahan Lontong Opor Ayam yang nikmat Untuk Jualan"
title: "Bahan-bahan Lontong Opor Ayam yang nikmat Untuk Jualan"
slug: 403-bahan-bahan-lontong-opor-ayam-yang-nikmat-untuk-jualan
date: 2021-02-13T12:29:13.399Z
image: https://img-global.cpcdn.com/recipes/6201aa7d59fbc9e2/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6201aa7d59fbc9e2/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6201aa7d59fbc9e2/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
author: Tyler Ramos
ratingvalue: 4
reviewcount: 13
recipeingredient:
- "500 gram ayam"
- "1 liter santan"
- "2 gelas air"
- "2 lembar daun salam"
- "1 batang sereh geprek"
- "1 ruas lengkuas geprek"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya kaldu bubuk"
- " Bumbu halus"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "2 butir kemiri"
- "1 sdt ketumbar"
- "1 sdt merica"
- " Bahan pelengkap"
- " Lontong"
- " Sambal"
- " Kerupuk"
- " Bawang goreng untuk taburan"
recipeinstructions:
- "Potong-potong ayam, cuci bersih lalu tiriskan."
- "Rebus ayam dalam panci. Sambil merebus ayam, tumis bumbu halus dalam wajan sampai harum. Lalu masukkan kedalam rebusan ayam, tambahkan daun salam, lengkuas, sereh. Masak sampai ayam empuk."
- "Masukkan santan. Tambahkan garam, gula pasir dan kaldu bubuk. Masak sampai Mendidih, sambil di aduk-aduk supaya santan tidak pecah."
- "Penyajian: Tata lontong dalam mangkuk, lalu tambahkan opor ayamnya. Beri taburan bawang goreng. Sajikan bersama kerupuk dan sambal bila suka pedas."
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 206 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Lunch

---


![Lontong Opor Ayam](https://img-global.cpcdn.com/recipes/6201aa7d59fbc9e2/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg)

Andai kalian seorang istri, menyediakan santapan nikmat pada keluarga merupakan suatu hal yang memuaskan bagi kita sendiri. Tanggung jawab seorang  wanita Tidak sekadar mengerjakan pekerjaan rumah saja, tetapi anda juga wajib menyediakan keperluan gizi tercukupi dan hidangan yang dimakan orang tercinta harus enak.

Di masa  sekarang, kita sebenarnya bisa memesan panganan yang sudah jadi tanpa harus susah mengolahnya dahulu. Tapi banyak juga lho orang yang memang ingin menghidangkan yang terlezat untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera orang tercinta. 



Apakah anda merupakan salah satu penggemar lontong opor ayam?. Tahukah kamu, lontong opor ayam adalah makanan khas di Nusantara yang kini disukai oleh orang-orang dari berbagai daerah di Nusantara. Anda dapat membuat lontong opor ayam sendiri di rumahmu dan pasti jadi hidangan favoritmu di akhir pekan.

Kalian tak perlu bingung jika kamu ingin menyantap lontong opor ayam, karena lontong opor ayam tidak sukar untuk didapatkan dan juga kita pun bisa memasaknya sendiri di rumah. lontong opor ayam bisa diolah dengan beraneka cara. Kini telah banyak sekali cara kekinian yang membuat lontong opor ayam semakin lebih lezat.

Resep lontong opor ayam juga gampang sekali dibikin, lho. Kita jangan capek-capek untuk memesan lontong opor ayam, lantaran Kamu mampu menyajikan di rumah sendiri. Bagi Kita yang mau menyajikannya, di bawah ini adalah cara membuat lontong opor ayam yang mantab yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Lontong Opor Ayam:

1. Gunakan 500 gram ayam
1. Siapkan 1 liter santan
1. Gunakan 2 gelas air
1. Gunakan 2 lembar daun salam
1. Siapkan 1 batang sereh, geprek
1. Siapkan 1 ruas lengkuas, geprek
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya gula pasir
1. Sediakan Secukupnya kaldu bubuk
1. Ambil  Bumbu halus:
1. Sediakan 4 siung bawang merah
1. Sediakan 2 siung bawang putih
1. Gunakan 1 ruas kunyit
1. Gunakan 1 ruas jahe
1. Sediakan 2 butir kemiri
1. Ambil 1 sdt ketumbar
1. Gunakan 1 sdt merica
1. Gunakan  Bahan pelengkap:
1. Sediakan  Lontong
1. Siapkan  Sambal
1. Siapkan  Kerupuk
1. Gunakan  Bawang goreng untuk taburan




<!--inarticleads2-->

##### Cara membuat Lontong Opor Ayam:

1. Potong-potong ayam, cuci bersih lalu tiriskan.
1. Rebus ayam dalam panci. Sambil merebus ayam, tumis bumbu halus dalam wajan sampai harum. Lalu masukkan kedalam rebusan ayam, tambahkan daun salam, lengkuas, sereh. Masak sampai ayam empuk.
1. Masukkan santan. Tambahkan garam, gula pasir dan kaldu bubuk. Masak sampai Mendidih, sambil di aduk-aduk supaya santan tidak pecah.
1. Penyajian: Tata lontong dalam mangkuk, lalu tambahkan opor ayamnya. Beri taburan bawang goreng. Sajikan bersama kerupuk dan sambal bila suka pedas.




Ternyata resep lontong opor ayam yang mantab sederhana ini enteng sekali ya! Anda Semua dapat menghidangkannya. Cara Membuat lontong opor ayam Cocok sekali untuk kita yang baru akan belajar memasak maupun juga untuk kalian yang telah lihai dalam memasak.

Apakah kamu mau mulai mencoba bikin resep lontong opor ayam nikmat tidak ribet ini? Kalau kamu mau, mending kamu segera buruan siapin alat-alat dan bahannya, setelah itu bikin deh Resep lontong opor ayam yang mantab dan sederhana ini. Sungguh mudah kan. 

Jadi, ketimbang kalian diam saja, hayo kita langsung saja hidangkan resep lontong opor ayam ini. Pasti kamu tiidak akan menyesal membuat resep lontong opor ayam nikmat sederhana ini! Selamat mencoba dengan resep lontong opor ayam enak simple ini di rumah kalian masing-masing,ya!.

