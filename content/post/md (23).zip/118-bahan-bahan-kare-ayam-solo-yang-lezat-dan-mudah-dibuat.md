---
description: "Bahan-bahan Kare Ayam Solo yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Kare Ayam Solo yang lezat dan Mudah Dibuat"
slug: 118-bahan-bahan-kare-ayam-solo-yang-lezat-dan-mudah-dibuat
date: 2021-04-28T21:35:25.649Z
image: https://img-global.cpcdn.com/recipes/acbac7466299598c/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/acbac7466299598c/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/acbac7466299598c/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: George Doyle
ratingvalue: 4.1
reviewcount: 4
recipeingredient:
- "1/4 kg dada ayam"
- "700 ml air"
- "150 ml santan"
- "secukupnya minyak untuk menggoreng dan menumis"
- " Bumbu Halus"
- "5 siung bawang putih"
- "4 siung bawang merah"
- "1/4 sdt merica bubuk"
- "1/2 sdt kunyit bubuk"
- "seujung sdt ketumbar bubuk"
- "3 butir kemiri"
- "seujung sdt jinten"
- "seujung sdt pala bubuk"
- "1 1/2 sdt garam"
- "1/2 sdt gula pasir"
- "sedikit penyedap rasa bs skip"
- " Bumbu Lainnya"
- "2 lembar daun salam sobek"
- "1 lembar daun jeruk sobek"
- "3 ruas lengkuas geprek"
- "2 ruas jahe geprek"
- "1 batang serai geprek"
- "2 buah cengkeh"
- "3 butir kapulaga"
- " Bahan Pelengkap"
- "secukupnya kol iris halus rebus"
- "secukupnya wortel iris korek api rebus"
- "secukupnya tauge rebus"
- "secukupnya bihun kaca rebus"
- "secukupnya keripik kentang goreng"
- "secukupnya seledri iris tipis"
- "secukupnya bawang goreng"
recipeinstructions:
- "Siapkan bumbu halus, kemudian tumis bumbu halus dengan 3 sdm minyak sayur. tambahkan &#34;bumbu lainnya&#34; lalu tumis sampai harum."
- "Masukkan air ke dalam tumisan bumbu. tambahkan dada ayam yg sdh di cuci bersih. rebus dgn api sedang hingga mendidih kemudian kecilkan api."
- "Tambahkan santan, aduk2 sampai mendidih agar santan tidak pecah. tes rasa. apabila sudah pas biarkan sebentar agar mendidih kembali. matikan api"
- "Tiriskan ayam dr kuah, kemudian goreng sebentar. sisihkan untuk bahan pelengkap (nantinya di suwir2 ya)"
- "Penyajian : siapkan mangkuk, beri nasi lalu tambahkan kol, tauge, wortel, bihun, seledri, dan ayam suwir. siram dengan kuah kare. lalu beri taburan bawang goreng."
- "Kare Ayam Solo siap disajikan. bs di santap bersama sambap kecap bila suka 😊"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 293 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dinner

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/acbac7466299598c/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan olahan menggugah selera untuk orang tercinta merupakan hal yang menyenangkan bagi kamu sendiri. Peran seorang ibu Tidak cuma mengerjakan pekerjaan rumah saja, tapi kamu pun harus memastikan kebutuhan gizi tercukupi dan juga santapan yang dikonsumsi keluarga tercinta wajib lezat.

Di era  sekarang, kalian sebenarnya dapat membeli santapan jadi meski tanpa harus susah mengolahnya dahulu. Tetapi banyak juga mereka yang selalu mau memberikan hidangan yang terenak untuk orang tercintanya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan masakan kesukaan famili. 



Apakah kamu seorang penyuka kare ayam solo?. Tahukah kamu, kare ayam solo merupakan makanan khas di Nusantara yang kini digemari oleh banyak orang di berbagai wilayah di Nusantara. Anda bisa menyajikan kare ayam solo sendiri di rumah dan boleh dijadikan camilan kesukaanmu di akhir pekanmu.

Kita tidak perlu bingung untuk memakan kare ayam solo, sebab kare ayam solo tidak sukar untuk didapatkan dan juga kamu pun bisa menghidangkannya sendiri di tempatmu. kare ayam solo boleh dibuat dengan bermacam cara. Kini sudah banyak sekali resep modern yang menjadikan kare ayam solo lebih enak.

Resep kare ayam solo juga gampang sekali dibuat, lho. Kita tidak perlu ribet-ribet untuk memesan kare ayam solo, sebab Kamu dapat menghidangkan sendiri di rumah. Bagi Kita yang mau menghidangkannya, dibawah ini merupakan resep menyajikan kare ayam solo yang lezat yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Kare Ayam Solo:

1. Ambil 1/4 kg dada ayam
1. Gunakan 700 ml air
1. Gunakan 150 ml santan
1. Gunakan secukupnya minyak untuk menggoreng dan menumis
1. Ambil  Bumbu Halus
1. Siapkan 5 siung bawang putih
1. Ambil 4 siung bawang merah
1. Sediakan 1/4 sdt merica bubuk
1. Gunakan 1/2 sdt kunyit bubuk
1. Ambil seujung sdt ketumbar bubuk
1. Siapkan 3 butir kemiri
1. Siapkan seujung sdt jinten
1. Sediakan seujung sdt pala bubuk
1. Siapkan 1 1/2 sdt garam
1. Sediakan 1/2 sdt gula pasir
1. Gunakan sedikit penyedap rasa (bs skip)
1. Sediakan  Bumbu Lainnya
1. Sediakan 2 lembar daun salam sobek
1. Siapkan 1 lembar daun jeruk sobek
1. Ambil 3 ruas lengkuas geprek
1. Ambil 2 ruas jahe geprek
1. Ambil 1 batang serai geprek
1. Ambil 2 buah cengkeh
1. Sediakan 3 butir kapulaga
1. Sediakan  Bahan Pelengkap
1. Ambil secukupnya kol iris halus, rebus
1. Gunakan secukupnya wortel iris korek api, rebus
1. Siapkan secukupnya tauge, rebus
1. Sediakan secukupnya bihun kaca, rebus
1. Siapkan secukupnya keripik kentang goreng
1. Siapkan secukupnya seledri iris tipis
1. Ambil secukupnya bawang goreng




<!--inarticleads2-->

##### Cara membuat Kare Ayam Solo:

1. Siapkan bumbu halus, kemudian tumis bumbu halus dengan 3 sdm minyak sayur. tambahkan &#34;bumbu lainnya&#34; lalu tumis sampai harum.
1. Masukkan air ke dalam tumisan bumbu. tambahkan dada ayam yg sdh di cuci bersih. rebus dgn api sedang hingga mendidih kemudian kecilkan api.
1. Tambahkan santan, aduk2 sampai mendidih agar santan tidak pecah. tes rasa. apabila sudah pas biarkan sebentar agar mendidih kembali. matikan api
1. Tiriskan ayam dr kuah, kemudian goreng sebentar. sisihkan untuk bahan pelengkap (nantinya di suwir2 ya)
1. Penyajian : siapkan mangkuk, beri nasi lalu tambahkan kol, tauge, wortel, bihun, seledri, dan ayam suwir. siram dengan kuah kare. lalu beri taburan bawang goreng.
1. Kare Ayam Solo siap disajikan. bs di santap bersama sambap kecap bila suka 😊




Ternyata resep kare ayam solo yang nikamt tidak rumit ini mudah sekali ya! Anda Semua mampu membuatnya. Resep kare ayam solo Sangat cocok sekali buat kita yang baru akan belajar memasak maupun untuk anda yang telah pandai dalam memasak.

Tertarik untuk mencoba membikin resep kare ayam solo enak tidak ribet ini? Kalau anda tertarik, ayo kamu segera siapin alat-alat dan bahan-bahannya, setelah itu buat deh Resep kare ayam solo yang enak dan sederhana ini. Sangat gampang kan. 

Maka, daripada kalian berlama-lama, hayo langsung aja hidangkan resep kare ayam solo ini. Pasti kamu tak akan menyesal membuat resep kare ayam solo lezat simple ini! Selamat mencoba dengan resep kare ayam solo nikmat simple ini di tempat tinggal masing-masing,ya!.

