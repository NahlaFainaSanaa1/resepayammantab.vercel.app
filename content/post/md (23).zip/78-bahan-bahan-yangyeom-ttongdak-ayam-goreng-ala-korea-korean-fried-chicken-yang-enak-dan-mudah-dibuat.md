---
description: "Bahan-bahan Yangyeom Ttongdak / Ayam Goreng ala Korea / Korean Fried Chicken yang enak dan Mudah Dibuat"
title: "Bahan-bahan Yangyeom Ttongdak / Ayam Goreng ala Korea / Korean Fried Chicken yang enak dan Mudah Dibuat"
slug: 78-bahan-bahan-yangyeom-ttongdak-ayam-goreng-ala-korea-korean-fried-chicken-yang-enak-dan-mudah-dibuat
date: 2021-04-19T11:59:26.214Z
image: https://img-global.cpcdn.com/recipes/8a8a23b1ca8a54ed/680x482cq70/yangyeom-ttongdak-ayam-goreng-ala-korea-korean-fried-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8a8a23b1ca8a54ed/680x482cq70/yangyeom-ttongdak-ayam-goreng-ala-korea-korean-fried-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8a8a23b1ca8a54ed/680x482cq70/yangyeom-ttongdak-ayam-goreng-ala-korea-korean-fried-chicken-foto-resep-utama.jpg
author: Verna Cruz
ratingvalue: 3.6
reviewcount: 9
recipeingredient:
- "1/2 kg sayap ayam minta potong jadi dua"
- " TEPUNG bisa jg pakai tepung instan basah"
- "2 sdm tepung cakra"
- "2 sdm tepung tapioka"
- "1 sdm maizena"
- "1 sdm bubuk bawang tdk muntuk"
- "1 sdt merica"
- "1 sdt kaldu jamur"
- "1/2 sdt garam"
- "secukupnya air"
- " TEPUNG bisa jg pakai tepung instan kering"
- "3 sdm tepung cakra"
- "3 sdm tepung tapioka"
- "1 sdm tepung maizena"
- "1 sdm bubuk bawang"
- "1 sdt merica"
- "1/2 sdt garam"
- " bumbu korea"
- "2 sdm gochujang bs dibeli di superindosupermarket lainnya"
- "3 sdm saos tomat"
- "2 sdm madu bisa diganti 2 sdm gula"
- "1 sdm minyak pedas opsional"
- "sedikit cuka"
- "secukupnya air"
- " WIJEN untuk hiasan"
recipeinstructions:
- "Rendam ayam di tepung basah dan tunggu selama kurang lebih 15-45 menit (opsional, langsung juga bisa)"
- "Gulingkan di tepung kering dengan dicubit-cubit, gulingkan, cubit-cubit, gulingkan, sampai ayam tertutupi dengan tepung."
- "Deep fry ayam hingga setengah matang, lalu angkat"
- "Tunggu sampai kira2 15 menit, bisa disambi nggoreng lagi"
- "Ayam setengah matang kemudian digoreng lagi. Jika benar, bunyinya akan nyess dan ayam seperti mengeluarkan air sehingga ada asap-asapnya. Goreng hingga berwarna cokelat cantik keemasan, tiriskan"
- "Pembuatan bumbu korea: semua bahan bumbu korea dimasukkan di wajan yang berbeda tentunya, lalu beri air dan campurkan sampai tercampur dengan baik"
- "Panaskan bumbu sampai airnya menguap. Tingkat kegelapan saus bisa sesukanya, kalau mau makin gelap ya ditambahi air lagi, dan ditunggu sampai air menguap lagi."
- "Ayam krispi dimasukkan ke bumbu korea dan dicampur dengan baik"
- "Taburi wijen"
- "Nikmati selagi panas"
categories:
- Resep
tags:
- yangyeom
- ttongdak
- 

katakunci: yangyeom ttongdak  
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Yangyeom Ttongdak / Ayam Goreng ala Korea / Korean Fried Chicken](https://img-global.cpcdn.com/recipes/8a8a23b1ca8a54ed/680x482cq70/yangyeom-ttongdak-ayam-goreng-ala-korea-korean-fried-chicken-foto-resep-utama.jpg)

Sebagai seorang ibu, mempersiapkan olahan lezat kepada orang tercinta adalah suatu hal yang menyenangkan untuk kamu sendiri. Kewajiban seorang  wanita bukan cuma menangani rumah saja, namun kamu juga wajib memastikan kebutuhan gizi terpenuhi dan juga masakan yang dikonsumsi keluarga tercinta mesti mantab.

Di zaman  saat ini, kita sebenarnya bisa mengorder santapan instan meski tidak harus susah mengolahnya lebih dulu. Tapi banyak juga orang yang memang mau memberikan yang terbaik bagi keluarganya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai masakan kesukaan keluarga. 



Apakah anda salah satu penggemar yangyeom ttongdak / ayam goreng ala korea / korean fried chicken?. Tahukah kamu, yangyeom ttongdak / ayam goreng ala korea / korean fried chicken adalah sajian khas di Nusantara yang kini digemari oleh banyak orang di berbagai tempat di Nusantara. Kita bisa menghidangkan yangyeom ttongdak / ayam goreng ala korea / korean fried chicken kreasi sendiri di rumahmu dan boleh dijadikan camilan kesenanganmu di akhir pekan.

Anda tak perlu bingung untuk menyantap yangyeom ttongdak / ayam goreng ala korea / korean fried chicken, lantaran yangyeom ttongdak / ayam goreng ala korea / korean fried chicken tidak sulit untuk ditemukan dan juga anda pun boleh mengolahnya sendiri di rumah. yangyeom ttongdak / ayam goreng ala korea / korean fried chicken dapat dibuat lewat beraneka cara. Sekarang sudah banyak resep kekinian yang menjadikan yangyeom ttongdak / ayam goreng ala korea / korean fried chicken semakin lebih enak.

Resep yangyeom ttongdak / ayam goreng ala korea / korean fried chicken pun sangat mudah dibikin, lho. Kalian tidak usah repot-repot untuk membeli yangyeom ttongdak / ayam goreng ala korea / korean fried chicken, sebab Anda bisa menyiapkan di rumah sendiri. Bagi Anda yang ingin membuatnya, di bawah ini adalah cara untuk membuat yangyeom ttongdak / ayam goreng ala korea / korean fried chicken yang enak yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Yangyeom Ttongdak / Ayam Goreng ala Korea / Korean Fried Chicken:

1. Gunakan 1/2 kg sayap ayam, minta potong jadi dua
1. Gunakan  TEPUNG (bisa jg pakai tepung instan) basah:
1. Sediakan 2 sdm tepung cakra
1. Sediakan 2 sdm tepung tapioka
1. Sediakan 1 sdm maizena
1. Siapkan 1 sdm bubuk bawang (tdk muntuk)
1. Ambil 1 sdt merica
1. Gunakan 1 sdt kaldu jamur
1. Ambil 1/2 sdt garam
1. Ambil secukupnya air
1. Gunakan  TEPUNG (bisa jg pakai tepung instan) kering:
1. Gunakan 3 sdm tepung cakra
1. Gunakan 3 sdm tepung tapioka
1. Gunakan 1 sdm tepung maizena
1. Ambil 1 sdm bubuk bawang
1. Siapkan 1 sdt merica
1. Ambil 1/2 sdt garam
1. Siapkan  bumbu korea:
1. Siapkan 2 sdm gochujang (bs dibeli di superindo/supermarket lainnya)
1. Siapkan 3 sdm saos tomat
1. Gunakan 2 sdm madu bisa diganti 2 sdm gula
1. Siapkan 1 sdm minyak pedas (opsional)
1. Ambil sedikit cuka
1. Gunakan secukupnya air
1. Gunakan  WIJEN untuk hiasan




<!--inarticleads2-->

##### Langkah-langkah membuat Yangyeom Ttongdak / Ayam Goreng ala Korea / Korean Fried Chicken:

1. Rendam ayam di tepung basah dan tunggu selama kurang lebih 15-45 menit (opsional, langsung juga bisa)
1. Gulingkan di tepung kering dengan dicubit-cubit, gulingkan, cubit-cubit, gulingkan, sampai ayam tertutupi dengan tepung.
1. Deep fry ayam hingga setengah matang, lalu angkat
1. Tunggu sampai kira2 15 menit, bisa disambi nggoreng lagi
1. Ayam setengah matang kemudian digoreng lagi. Jika benar, bunyinya akan nyess dan ayam seperti mengeluarkan air sehingga ada asap-asapnya. Goreng hingga berwarna cokelat cantik keemasan, tiriskan
1. Pembuatan bumbu korea: semua bahan bumbu korea dimasukkan di wajan yang berbeda tentunya, lalu beri air dan campurkan sampai tercampur dengan baik
1. Panaskan bumbu sampai airnya menguap. Tingkat kegelapan saus bisa sesukanya, kalau mau makin gelap ya ditambahi air lagi, dan ditunggu sampai air menguap lagi.
1. Ayam krispi dimasukkan ke bumbu korea dan dicampur dengan baik
1. Taburi wijen
1. Nikmati selagi panas




Wah ternyata resep yangyeom ttongdak / ayam goreng ala korea / korean fried chicken yang lezat tidak ribet ini mudah sekali ya! Semua orang bisa membuatnya. Cara Membuat yangyeom ttongdak / ayam goreng ala korea / korean fried chicken Cocok sekali untuk kalian yang baru belajar memasak maupun untuk anda yang telah lihai dalam memasak.

Apakah kamu tertarik mencoba membuat resep yangyeom ttongdak / ayam goreng ala korea / korean fried chicken mantab simple ini? Kalau kalian mau, yuk kita segera buruan siapin alat dan bahan-bahannya, maka buat deh Resep yangyeom ttongdak / ayam goreng ala korea / korean fried chicken yang lezat dan sederhana ini. Sungguh mudah kan. 

Oleh karena itu, daripada kamu diam saja, maka kita langsung saja bikin resep yangyeom ttongdak / ayam goreng ala korea / korean fried chicken ini. Pasti kalian gak akan nyesel sudah membuat resep yangyeom ttongdak / ayam goreng ala korea / korean fried chicken lezat tidak rumit ini! Selamat mencoba dengan resep yangyeom ttongdak / ayam goreng ala korea / korean fried chicken mantab tidak rumit ini di rumah kalian masing-masing,oke!.

