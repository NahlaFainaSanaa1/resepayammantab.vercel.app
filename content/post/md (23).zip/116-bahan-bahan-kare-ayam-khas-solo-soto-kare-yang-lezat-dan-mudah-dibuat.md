---
description: "Bahan-bahan Kare ayam khas solo (Soto kare) yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Kare ayam khas solo (Soto kare) yang lezat dan Mudah Dibuat"
slug: 116-bahan-bahan-kare-ayam-khas-solo-soto-kare-yang-lezat-dan-mudah-dibuat
date: 2021-06-11T18:34:50.834Z
image: https://img-global.cpcdn.com/recipes/760e5ff8ef9504f6/680x482cq70/kare-ayam-khas-solo-soto-kare-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/760e5ff8ef9504f6/680x482cq70/kare-ayam-khas-solo-soto-kare-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/760e5ff8ef9504f6/680x482cq70/kare-ayam-khas-solo-soto-kare-foto-resep-utama.jpg
author: Craig Ford
ratingvalue: 3.3
reviewcount: 14
recipeingredient:
- "250 gr dada ayam filed"
- "500 gr ceker ayam"
- " Bumbu halus"
- "16 siung bawang merah"
- "8 siung bawang putih"
- "6 buah kemiri sangrai"
- "2 ruas kunyit bakar"
- " Bumbu cemplung"
- "5 lembar daun jeruk"
- " lengkuas geprek"
- "3 buah serai geprek"
- "secukupnya gulagarampenyedapkaldu ayam bubuk"
- " santan kara 65ml 3bks"
- "3 liter air kurleb"
- " Bahan pelengkap"
- " bihun jagung"
- " wortel rebus"
- " tauge rebus"
- " emping mlinjo"
- " bawang goreng"
- " seledri"
recipeinstructions:
- "Cuci bersih ceker dan dada ayam...buang air rebusan pertama..kembali panaskan air 3liter,setelah mendidih masukan ayam dan dada ayam.."
- "Uleg bumbu halus lalu tumis bersama daun salam dan serai...tambahkan tumisan bumbu halus ke air rebusan ayam..masak sampai ayam empuk..masak kurleb 30menit"
- "Tambahkan santan..aduk terus jgn sampai santan pecah..tambahkan gula,garam,penyedap,kaldu ayam bubuk..koreksi rasa dan angkat"
- "Tata di mangkok bihun jagung,touge,wortel,dan suwiran ayam..lalu tuangkan kuah soto karenya..taburi bawang goreng dan sajikan selagi hangat..Selamat mencoba"
categories:
- Resep
tags:
- kare
- ayam
- khas

katakunci: kare ayam khas 
nutrition: 292 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dessert

---


![Kare ayam khas solo (Soto kare)](https://img-global.cpcdn.com/recipes/760e5ff8ef9504f6/680x482cq70/kare-ayam-khas-solo-soto-kare-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan panganan menggugah selera bagi keluarga merupakan hal yang mengasyikan untuk kita sendiri. Tugas seorang ibu bukan cuman mengurus rumah saja, namun kamu pun wajib menyediakan keperluan nutrisi tercukupi dan masakan yang dikonsumsi keluarga tercinta wajib nikmat.

Di zaman  sekarang, kamu memang dapat membeli santapan yang sudah jadi meski tanpa harus capek mengolahnya dulu. Namun ada juga orang yang selalu ingin memberikan hidangan yang terenak bagi keluarganya. Karena, menghidangkan masakan sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga. 



Mungkinkah anda adalah salah satu penggemar kare ayam khas solo (soto kare)?. Tahukah kamu, kare ayam khas solo (soto kare) adalah makanan khas di Indonesia yang saat ini digemari oleh banyak orang di berbagai wilayah di Nusantara. Kamu dapat memasak kare ayam khas solo (soto kare) sendiri di rumah dan pasti jadi makanan kegemaranmu di akhir pekan.

Kita tak perlu bingung untuk memakan kare ayam khas solo (soto kare), sebab kare ayam khas solo (soto kare) gampang untuk didapatkan dan kalian pun bisa memasaknya sendiri di rumah. kare ayam khas solo (soto kare) bisa diolah memalui bermacam cara. Saat ini ada banyak resep modern yang membuat kare ayam khas solo (soto kare) semakin lebih enak.

Resep kare ayam khas solo (soto kare) juga sangat gampang untuk dibikin, lho. Kamu tidak usah ribet-ribet untuk membeli kare ayam khas solo (soto kare), karena Anda bisa menyajikan ditempatmu. Untuk Anda yang mau menghidangkannya, dibawah ini merupakan cara untuk menyajikan kare ayam khas solo (soto kare) yang enak yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Kare ayam khas solo (Soto kare):

1. Sediakan 250 gr dada ayam filed
1. Sediakan 500 gr ceker ayam
1. Gunakan  Bumbu halus
1. Siapkan 16 siung bawang merah
1. Sediakan 8 siung bawang putih
1. Sediakan 6 buah kemiri sangrai
1. Gunakan 2 ruas kunyit bakar
1. Gunakan  Bumbu cemplung
1. Siapkan 5 lembar daun jeruk
1. Ambil  lengkuas geprek
1. Gunakan 3 buah serai geprek
1. Siapkan secukupnya gula,garam,penyedap,kaldu ayam bubuk
1. Gunakan  santan kara 65ml 3bks
1. Sediakan 3 liter air kurleb
1. Gunakan  Bahan pelengkap
1. Siapkan  bihun jagung
1. Gunakan  wortel rebus
1. Ambil  tauge rebus
1. Sediakan  emping mlinjo
1. Sediakan  bawang goreng
1. Sediakan  seledri




<!--inarticleads2-->

##### Langkah-langkah membuat Kare ayam khas solo (Soto kare):

1. Cuci bersih ceker dan dada ayam...buang air rebusan pertama..kembali panaskan air 3liter,setelah mendidih masukan ayam dan dada ayam..
1. Uleg bumbu halus lalu tumis bersama daun salam dan serai...tambahkan tumisan bumbu halus ke air rebusan ayam..masak sampai ayam empuk..masak kurleb 30menit
1. Tambahkan santan..aduk terus jgn sampai santan pecah..tambahkan gula,garam,penyedap,kaldu ayam bubuk..koreksi rasa dan angkat
1. Tata di mangkok bihun jagung,touge,wortel,dan suwiran ayam..lalu tuangkan kuah soto karenya..taburi bawang goreng dan sajikan selagi hangat..Selamat mencoba




Wah ternyata resep kare ayam khas solo (soto kare) yang enak simple ini gampang banget ya! Kita semua mampu menghidangkannya. Cara Membuat kare ayam khas solo (soto kare) Sesuai banget untuk anda yang baru belajar memasak ataupun juga bagi kamu yang telah hebat dalam memasak.

Tertarik untuk mencoba membikin resep kare ayam khas solo (soto kare) nikmat sederhana ini? Kalau tertarik, yuk kita segera siapin alat dan bahan-bahannya, lantas bikin deh Resep kare ayam khas solo (soto kare) yang mantab dan simple ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kalian berlama-lama, yuk kita langsung buat resep kare ayam khas solo (soto kare) ini. Dijamin kamu tiidak akan nyesel sudah bikin resep kare ayam khas solo (soto kare) lezat simple ini! Selamat berkreasi dengan resep kare ayam khas solo (soto kare) enak tidak ribet ini di tempat tinggal sendiri,ya!.

