---
description: "Cara membuat Kare ayam solo Sederhana Untuk Jualan"
title: "Cara membuat Kare ayam solo Sederhana Untuk Jualan"
slug: 109-cara-membuat-kare-ayam-solo-sederhana-untuk-jualan
date: 2021-01-23T20:57:32.371Z
image: https://img-global.cpcdn.com/recipes/04b3b3a88b6a7d58/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/04b3b3a88b6a7d58/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/04b3b3a88b6a7d58/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Lou Harper
ratingvalue: 4.4
reviewcount: 10
recipeingredient:
- "500 gr ayam"
- "150 ml santan kental"
- "1000 ml air"
- "1 batang serehgeprek"
- "7 lbr Daun jeruk"
- "2 lbr Daun salam"
- "5 btr Kapulaga"
- "3 cm Kayumanis"
- "2 btr sisir Pekakbunga"
- "3 btr Cengkeh"
- " Bumbu halus"
- "7 siung bawang merah"
- "17 siung bawang putih"
- "3 butir kemirisangrai"
- "1 sdm ketumbar"
- "1/2 sdm jintan"
- "1 sdt merica"
- "1 ruas kunyitjahe"
- " Gulagaramkaldu jamur"
- " Pelengkap"
- "Irisan wortel"
- " Keripik kentang"
- " Soun"
- " Bawang goreng"
- " Daun sop"
- " Cabe"
- " Jeruk nipis"
recipeinstructions:
- "Siapkan bahan"
- "Haluskan bumbu"
- "Tumis rempah dan daun-daun"
- "Setelah wangi masukkan bumbu halus"
- "Tumis hingga wangi lalu masukkan ayam tambahkan sedikit air lalu tutup wajan hingga ayam mengeluarkan kaldu"
- "Setelah itu tambahkan air masak hingga air menyusut"
- "Setelah air menyusut tambahkan santan kental"
- "Masak dengan api kecil agar santan tidak pecah setelah santan matang angkat&amp;sajikan"
- "Tata dipiring taburi bawang goreng tambahkan cabe&amp;jeruk"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 153 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Kare ayam solo](https://img-global.cpcdn.com/recipes/04b3b3a88b6a7d58/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan santapan enak kepada keluarga adalah suatu hal yang sangat menyenangkan untuk kamu sendiri. Kewajiban seorang ibu bukan sekedar menangani rumah saja, tapi anda juga wajib memastikan keperluan nutrisi tercukupi dan panganan yang dimakan keluarga tercinta mesti mantab.

Di zaman  sekarang, anda sebenarnya mampu memesan olahan yang sudah jadi meski tanpa harus capek mengolahnya dahulu. Namun banyak juga lho mereka yang memang ingin memberikan makanan yang terbaik bagi orang yang dicintainya. Karena, memasak sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan selera famili. 



Mungkinkah anda adalah salah satu penyuka kare ayam solo?. Asal kamu tahu, kare ayam solo adalah sajian khas di Indonesia yang saat ini disukai oleh kebanyakan orang di berbagai daerah di Indonesia. Kalian dapat menghidangkan kare ayam solo kreasi sendiri di rumah dan boleh dijadikan hidangan kesukaanmu di hari libur.

Kalian tak perlu bingung untuk memakan kare ayam solo, sebab kare ayam solo tidak sukar untuk didapatkan dan kamu pun bisa menghidangkannya sendiri di rumah. kare ayam solo dapat dimasak memalui bermacam cara. Kini ada banyak banget cara modern yang menjadikan kare ayam solo semakin mantap.

Resep kare ayam solo pun mudah sekali dibuat, lho. Anda tidak usah repot-repot untuk memesan kare ayam solo, tetapi Anda dapat menyajikan sendiri di rumah. Untuk Kalian yang ingin membuatnya, inilah cara membuat kare ayam solo yang lezat yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Kare ayam solo:

1. Gunakan 500 gr ayam
1. Gunakan 150 ml santan kental
1. Ambil 1000 ml air
1. Siapkan 1 batang sereh(geprek)
1. Sediakan 7 lbr Daun jeruk
1. Gunakan 2 lbr Daun salam
1. Ambil 5 btr Kapulaga
1. Ambil 3 cm Kayumanis
1. Gunakan 2 btr sisir Pekak/bunga
1. Gunakan 3 btr Cengkeh
1. Ambil  Bumbu halus
1. Gunakan 7 siung bawang merah
1. Sediakan 17 siung bawang putih
1. Sediakan 3 butir kemiri(sangrai)
1. Sediakan 1 sdm ketumbar
1. Siapkan 1/2 sdm jintan
1. Sediakan 1 sdt merica
1. Ambil 1 ruas kunyit&amp;jahe
1. Siapkan  Gula,garam,kaldu jamur
1. Sediakan  Pelengkap
1. Gunakan Irisan wortel
1. Siapkan  Keripik kentang
1. Sediakan  Soun
1. Siapkan  Bawang goreng
1. Gunakan  Daun sop
1. Sediakan  Cabe
1. Sediakan  Jeruk nipis




<!--inarticleads2-->

##### Cara membuat Kare ayam solo:

1. Siapkan bahan
1. Haluskan bumbu
1. Tumis rempah dan daun-daun
1. Setelah wangi masukkan bumbu halus
1. Tumis hingga wangi lalu masukkan ayam tambahkan sedikit air lalu tutup wajan hingga ayam mengeluarkan kaldu
1. Setelah itu tambahkan air masak hingga air menyusut
1. Setelah air menyusut tambahkan santan kental
1. Masak dengan api kecil agar santan tidak pecah setelah santan matang angkat&amp;sajikan
1. Tata dipiring taburi bawang goreng tambahkan cabe&amp;jeruk




Ternyata cara membuat kare ayam solo yang nikamt tidak ribet ini mudah banget ya! Anda Semua dapat membuatnya. Resep kare ayam solo Cocok banget buat kamu yang baru belajar memasak maupun juga bagi kalian yang sudah ahli dalam memasak.

Apakah kamu tertarik mencoba buat resep kare ayam solo lezat tidak rumit ini? Kalau mau, ayo kalian segera buruan siapkan alat dan bahannya, lantas bikin deh Resep kare ayam solo yang nikmat dan sederhana ini. Betul-betul gampang kan. 

Maka, ketimbang anda berlama-lama, maka kita langsung buat resep kare ayam solo ini. Pasti kamu tiidak akan menyesal sudah buat resep kare ayam solo nikmat simple ini! Selamat berkreasi dengan resep kare ayam solo lezat tidak rumit ini di tempat tinggal kalian sendiri,oke!.

