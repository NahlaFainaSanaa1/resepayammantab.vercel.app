---
description: "Cara membuat Kare Ayam Solo yang lezat dan Mudah Dibuat"
title: "Cara membuat Kare Ayam Solo yang lezat dan Mudah Dibuat"
slug: 107-cara-membuat-kare-ayam-solo-yang-lezat-dan-mudah-dibuat
date: 2021-03-19T08:19:08.107Z
image: https://img-global.cpcdn.com/recipes/496033d2873eaf3d/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/496033d2873eaf3d/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/496033d2873eaf3d/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Luke Maldonado
ratingvalue: 4.5
reviewcount: 15
recipeingredient:
- "1/2 kg ayam potong 2 me dada buang kulit"
- "1 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "1 liter air"
- "1 sachet santan instan 65 ml"
- "1 sdt munjung gulpas"
- "1/2 sdt kaldu bubuk"
- " Garam"
- " Bumbu Halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "1/2 sdt kunyit bubuk"
- "1 sdt ketumbar bubuk"
- "1/4 sdt Lada bubuk"
- "1/4 sdt jinten"
- "1 cm jahe"
- " Pelengkap "
- "2 buah wortel potong2 lalu rebus"
- " Tauge seduh air panas saya skip"
- "2 batang daun bawang iris"
recipeinstructions:
- "Cuci bersih ayam, lumuri dengan garam. Diamkan 10 menit, lalu bilas hingga bersih. Rebus ayam dalam air mendidih, sampai berubah warna. (saya sampai benar2 matang). Angkat, buang air rebusan."
- "Panaskan minyak, tumis bumbu Halus, masukkan serai, daun Jeruk, daun salam, lengkuas. Masak hingga wangi dan matang. Masukkan ayam, aduk rata."
- "Tuang air, didihkan. Bumbui dengan garam, gula pasir, kaldu bubuk, merica. Masukkan santan. Masak hingga ayam empuk, koreksi rasa."
- "Masukkan wortel dan daun bawang, aduk sebentar. Matikan kompor. Note :sebetulnya cara penyajian, wortel dan tauge ditata di piring saji, masukkan ayam, siram dengan kuah. Kalau saya pakai cara praktis saja."
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 138 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/496033d2873eaf3d/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan santapan nikmat buat orang tercinta adalah hal yang membahagiakan bagi kamu sendiri. Kewajiban seorang istri bukan cuma menjaga rumah saja, namun anda pun wajib memastikan keperluan gizi terpenuhi dan santapan yang disantap anak-anak harus sedap.

Di era  sekarang, kita memang bisa memesan olahan praktis meski tanpa harus ribet memasaknya terlebih dahulu. Namun banyak juga lho orang yang selalu mau menyajikan yang terenak bagi orang tercintanya. Sebab, memasak yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan selera orang tercinta. 



Apakah anda merupakan seorang penyuka kare ayam solo?. Asal kamu tahu, kare ayam solo merupakan makanan khas di Indonesia yang sekarang disenangi oleh setiap orang di hampir setiap daerah di Nusantara. Anda dapat menyajikan kare ayam solo sendiri di rumah dan dapat dijadikan santapan kesukaanmu di hari liburmu.

Kita tidak usah bingung untuk menyantap kare ayam solo, sebab kare ayam solo gampang untuk ditemukan dan juga kita pun bisa memasaknya sendiri di tempatmu. kare ayam solo bisa dimasak dengan berbagai cara. Sekarang ada banyak banget cara kekinian yang menjadikan kare ayam solo lebih enak.

Resep kare ayam solo juga sangat gampang dibuat, lho. Kalian tidak perlu repot-repot untuk memesan kare ayam solo, tetapi Kita dapat menghidangkan di rumah sendiri. Bagi Kamu yang akan menghidangkannya, berikut ini cara menyajikan kare ayam solo yang nikamat yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Kare Ayam Solo:

1. Gunakan 1/2 kg ayam, potong 2 (me :dada, buang kulit)
1. Siapkan 1 lembar daun salam
1. Sediakan 3 lembar daun jeruk
1. Sediakan 1 batang serai, geprek
1. Siapkan 1 liter air
1. Gunakan 1 sachet santan instan (65 ml)
1. Siapkan 1 sdt munjung gulpas
1. Gunakan 1/2 sdt kaldu bubuk
1. Gunakan  Garam
1. Ambil  Bumbu Halus :
1. Gunakan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Ambil 3 butir kemiri
1. Sediakan 1/2 sdt kunyit bubuk
1. Sediakan 1 sdt ketumbar bubuk
1. Sediakan 1/4 sdt Lada bubuk
1. Gunakan 1/4 sdt jinten
1. Sediakan 1 cm jahe
1. Ambil  Pelengkap :
1. Siapkan 2 buah wortel, potong2, lalu rebus
1. Gunakan  Tauge, seduh air panas (saya skip)
1. Siapkan 2 batang daun bawang, iris




<!--inarticleads2-->

##### Cara menyiapkan Kare Ayam Solo:

1. Cuci bersih ayam, lumuri dengan garam. Diamkan 10 menit, lalu bilas hingga bersih. Rebus ayam dalam air mendidih, sampai berubah warna. (saya sampai benar2 matang). Angkat, buang air rebusan.
1. Panaskan minyak, tumis bumbu Halus, masukkan serai, daun Jeruk, daun salam, lengkuas. Masak hingga wangi dan matang. Masukkan ayam, aduk rata.
1. Tuang air, didihkan. Bumbui dengan garam, gula pasir, kaldu bubuk, merica. Masukkan santan. Masak hingga ayam empuk, koreksi rasa.
1. Masukkan wortel dan daun bawang, aduk sebentar. Matikan kompor. Note :sebetulnya cara penyajian, wortel dan tauge ditata di piring saji, masukkan ayam, siram dengan kuah. Kalau saya pakai cara praktis saja.




Ternyata resep kare ayam solo yang mantab tidak rumit ini mudah banget ya! Kalian semua mampu membuatnya. Resep kare ayam solo Cocok banget untuk anda yang baru akan belajar memasak maupun bagi kalian yang sudah pandai dalam memasak.

Tertarik untuk mulai mencoba buat resep kare ayam solo mantab sederhana ini? Kalau kamu tertarik, ayo kalian segera menyiapkan alat dan bahannya, lalu buat deh Resep kare ayam solo yang enak dan tidak rumit ini. Sangat mudah kan. 

Jadi, daripada anda berfikir lama-lama, hayo kita langsung bikin resep kare ayam solo ini. Dijamin kamu gak akan nyesel membuat resep kare ayam solo enak tidak ribet ini! Selamat berkreasi dengan resep kare ayam solo enak simple ini di rumah kalian sendiri,ya!.

