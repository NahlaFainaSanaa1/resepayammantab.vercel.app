---
description: "Resep Sup ayam sederhana yang nikmat dan Mudah Dibuat"
title: "Resep Sup ayam sederhana yang nikmat dan Mudah Dibuat"
slug: 335-resep-sup-ayam-sederhana-yang-nikmat-dan-mudah-dibuat
date: 2021-02-24T04:54:26.718Z
image: https://img-global.cpcdn.com/recipes/57939671a76ee043/680x482cq70/sup-ayam-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/57939671a76ee043/680x482cq70/sup-ayam-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/57939671a76ee043/680x482cq70/sup-ayam-sederhana-foto-resep-utama.jpg
author: Iva Franklin
ratingvalue: 3.6
reviewcount: 14
recipeingredient:
- "25 gr ayam saya pakai bagian banyak tulang spt sayap dan ceker"
- "1 buah wortel"
- "1 buah kentang"
- "2 lembar kol"
- "1 batang daun bawang iris besar"
- "1/2 batang seledri"
- " Bumbu"
- "3 sium bwang merah iris"
- "2 sium bawang putih iris"
- "  buah tomat"
- "1 buah cabe keriting iris optional"
- "1 sdt garam"
- "1 sdt penyedap"
- "1/2 sdt lada"
- "  sdt gula"
- "700 ml air"
recipeinstructions:
- "Bersih kan wortel dan kentang, lalu bersihkan dan potong dadu."
- "Rebus ayam sebentar saja ±3 menit, supaya lemak kotornya keluar. Buang air sisa rebusan."
- "Didihkan air. Masukkan seledri, saya cuma di remas utuh saja. Masukkan ayam, wortel dan kentang sampai setengah matang."
- "Tumis bamer dan baput, setelah matang masukkan daun bawang dan tumis sebentar. Masukkan ke dalam kuah sup. Beri bumbu, koreksi rasa."
- "Masukkan kol, masak sebentar lalu masukkan cabe dan tomat sebelum kompor di matikan."
categories:
- Resep
tags:
- sup
- ayam
- sederhana

katakunci: sup ayam sederhana 
nutrition: 145 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dessert

---


![Sup ayam sederhana](https://img-global.cpcdn.com/recipes/57939671a76ee043/680x482cq70/sup-ayam-sederhana-foto-resep-utama.jpg)

Apabila kamu seorang orang tua, menyajikan hidangan nikmat bagi keluarga tercinta merupakan hal yang mengasyikan bagi anda sendiri. Kewajiban seorang istri bukan sekadar menjaga rumah saja, tetapi anda pun harus menyediakan kebutuhan gizi terpenuhi dan hidangan yang dikonsumsi anak-anak mesti nikmat.

Di zaman  sekarang, anda sebenarnya mampu mengorder panganan siap saji meski tidak harus repot memasaknya dulu. Namun ada juga lho orang yang selalu mau menyajikan yang terbaik bagi orang yang dicintainya. Karena, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan orang tercinta. 



Apakah anda seorang penggemar sup ayam sederhana?. Tahukah kamu, sup ayam sederhana adalah makanan khas di Indonesia yang kini digemari oleh orang-orang dari berbagai wilayah di Indonesia. Anda bisa menyajikan sup ayam sederhana buatan sendiri di rumahmu dan dapat dijadikan makanan favoritmu di akhir pekanmu.

Kita tidak perlu bingung jika kamu ingin menyantap sup ayam sederhana, lantaran sup ayam sederhana mudah untuk dicari dan juga kamu pun dapat mengolahnya sendiri di rumah. sup ayam sederhana bisa diolah dengan bermacam cara. Saat ini ada banyak banget cara modern yang membuat sup ayam sederhana lebih mantap.

Resep sup ayam sederhana juga mudah untuk dibikin, lho. Kita tidak usah repot-repot untuk membeli sup ayam sederhana, karena Kamu mampu menyiapkan di rumahmu. Untuk Kamu yang mau menghidangkannya, dibawah ini merupakan cara untuk menyajikan sup ayam sederhana yang lezat yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Sup ayam sederhana:

1. Sediakan 25 gr ayam (saya pakai bagian banyak tulang spt sayap dan ceker)
1. Gunakan 1 buah wortel
1. Sediakan 1 buah kentang
1. Gunakan 2 lembar kol
1. Siapkan 1 batang daun bawang (iris besar)
1. Siapkan 1/2 batang seledri
1. Gunakan  Bumbu
1. Gunakan 3 sium bwang merah (iris)
1. Gunakan 2 sium bawang putih (iris)
1. Ambil  ¹/² buah tomat
1. Sediakan 1 buah cabe keriting (iris) (optional)
1. Gunakan 1 sdt garam
1. Ambil 1 sdt penyedap
1. Ambil 1/2 sdt lada
1. Sediakan  ¹/² sdt gula
1. Gunakan 700 ml air




<!--inarticleads2-->

##### Langkah-langkah membuat Sup ayam sederhana:

1. Bersih kan wortel dan kentang, lalu bersihkan dan potong dadu.
1. Rebus ayam sebentar saja ±3 menit, supaya lemak kotornya keluar. Buang air sisa rebusan.
1. Didihkan air. Masukkan seledri, saya cuma di remas utuh saja. Masukkan ayam, wortel dan kentang sampai setengah matang.
1. Tumis bamer dan baput, setelah matang masukkan daun bawang dan tumis sebentar. Masukkan ke dalam kuah sup. Beri bumbu, koreksi rasa.
1. Masukkan kol, masak sebentar lalu masukkan cabe dan tomat sebelum kompor di matikan.




Wah ternyata resep sup ayam sederhana yang enak tidak ribet ini gampang banget ya! Semua orang mampu menghidangkannya. Cara Membuat sup ayam sederhana Sangat cocok sekali buat kalian yang sedang belajar memasak maupun juga untuk kamu yang sudah pandai memasak.

Tertarik untuk mencoba buat resep sup ayam sederhana mantab tidak ribet ini? Kalau kamu tertarik, ayo kalian segera siapkan peralatan dan bahan-bahannya, setelah itu bikin deh Resep sup ayam sederhana yang nikmat dan tidak ribet ini. Benar-benar mudah kan. 

Maka, ketimbang kalian berfikir lama-lama, maka kita langsung hidangkan resep sup ayam sederhana ini. Dijamin kalian tiidak akan menyesal bikin resep sup ayam sederhana lezat sederhana ini! Selamat berkreasi dengan resep sup ayam sederhana mantab simple ini di rumah kalian masing-masing,oke!.

