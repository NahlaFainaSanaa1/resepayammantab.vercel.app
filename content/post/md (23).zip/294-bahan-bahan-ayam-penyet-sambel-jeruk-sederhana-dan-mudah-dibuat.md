---
description: "Bahan-bahan Ayam penyet sambel jeruk Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Ayam penyet sambel jeruk Sederhana dan Mudah Dibuat"
slug: 294-bahan-bahan-ayam-penyet-sambel-jeruk-sederhana-dan-mudah-dibuat
date: 2021-03-06T10:18:55.844Z
image: https://img-global.cpcdn.com/recipes/6af060571873e3ac/680x482cq70/ayam-penyet-sambel-jeruk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6af060571873e3ac/680x482cq70/ayam-penyet-sambel-jeruk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6af060571873e3ac/680x482cq70/ayam-penyet-sambel-jeruk-foto-resep-utama.jpg
author: Ethel Meyer
ratingvalue: 4.7
reviewcount: 14
recipeingredient:
- "1 ekor ayam berat 12 kg potong 12"
- "Segenggam kemangi"
- "2 bh terong potong2 goreng"
- " Bumbu ayam ungkep "
- "1 ruas kunyit"
- " 1 ruas jahe"
- "1 sdm ketumbar butiran"
- "4 siung bawang putih"
- "Secukupnya garam gula dan kaldu bubuk ayam"
- " Bahan sambel jeruk "
- "30 bh cabe rawit"
- "2 bh tomat"
- "1 sdt terasi"
- "2 siung bawang merah"
- "1 siung bawang putih"
- "2 bh jeruk limau potong2"
recipeinstructions:
- "Haluskan bumbu ayam, kemudian tumis dgn sedikit minyak, masukan ayam aduk rata,tambahkan air hingga ayam terendam, laku masukan garam, gula dan kaldu bubuk,Ungkep sampai ayam empuk dan bumbu meresap. Angkat kemudian goreng hingga kekuningan. Sisihkan"
- "Untuk sambel jeruknya, semua bahan udh di cuci bersih kecuali terasi. Kemudian goreng, ulek, koreksi rasa. Terakhir tambahkan potongan jeruk."
- "Ambil 1 potongan ayam, penyet diatas sambel, kemudian tambahkan terong goreng dan kemangi. Jika punya tambahan lalapan yg lain bisa ditambahkan sesuai selera ☺️"
categories:
- Resep
tags:
- ayam
- penyet
- sambel

katakunci: ayam penyet sambel 
nutrition: 237 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam penyet sambel jeruk](https://img-global.cpcdn.com/recipes/6af060571873e3ac/680x482cq70/ayam-penyet-sambel-jeruk-foto-resep-utama.jpg)

Andai anda seorang orang tua, menyuguhkan olahan sedap bagi famili adalah hal yang memuaskan bagi anda sendiri. Tanggung jawab seorang ibu Tidak sekadar menjaga rumah saja, namun kamu juga harus menyediakan kebutuhan nutrisi tercukupi dan santapan yang disantap keluarga tercinta mesti mantab.

Di zaman  sekarang, kalian memang mampu membeli hidangan jadi walaupun tanpa harus ribet mengolahnya dahulu. Namun banyak juga lho orang yang memang mau memberikan hidangan yang terbaik bagi orang yang dicintainya. Pasalnya, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan keluarga. 



Mungkinkah anda adalah salah satu penikmat ayam penyet sambel jeruk?. Asal kamu tahu, ayam penyet sambel jeruk merupakan sajian khas di Nusantara yang kini disenangi oleh kebanyakan orang di berbagai daerah di Indonesia. Kalian dapat membuat ayam penyet sambel jeruk kreasi sendiri di rumah dan boleh dijadikan makanan kesukaanmu di akhir pekan.

Kamu tidak usah bingung untuk mendapatkan ayam penyet sambel jeruk, karena ayam penyet sambel jeruk mudah untuk ditemukan dan juga kamu pun bisa mengolahnya sendiri di tempatmu. ayam penyet sambel jeruk dapat dibuat lewat bermacam cara. Kini pun sudah banyak cara kekinian yang menjadikan ayam penyet sambel jeruk semakin lebih enak.

Resep ayam penyet sambel jeruk juga gampang sekali dibikin, lho. Kamu tidak usah ribet-ribet untuk memesan ayam penyet sambel jeruk, karena Kalian dapat menyajikan ditempatmu. Untuk Kita yang hendak menyajikannya, berikut cara untuk membuat ayam penyet sambel jeruk yang nikamat yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam penyet sambel jeruk:

1. Ambil 1 ekor ayam berat 1,2 kg (potong 12)
1. Siapkan Segenggam kemangi
1. Siapkan 2 bh terong (potong2, goreng)
1. Ambil  Bumbu ayam ungkep :
1. Siapkan 1 ruas kunyit
1. Ambil  1 ruas jahe
1. Gunakan 1 sdm ketumbar butiran
1. Siapkan 4 siung bawang putih
1. Ambil Secukupnya garam, gula dan kaldu bubuk ayam
1. Ambil  Bahan sambel jeruk :
1. Siapkan 30 bh cabe rawit
1. Ambil 2 bh tomat
1. Sediakan 1 sdt terasi
1. Siapkan 2 siung bawang merah
1. Sediakan 1 siung bawang putih
1. Sediakan 2 bh jeruk limau (potong2)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam penyet sambel jeruk:

1. Haluskan bumbu ayam, kemudian tumis dgn sedikit minyak, masukan ayam aduk rata,tambahkan air hingga ayam terendam, laku masukan garam, gula dan kaldu bubuk,Ungkep sampai ayam empuk dan bumbu meresap. Angkat kemudian goreng hingga kekuningan. Sisihkan
1. Untuk sambel jeruknya, semua bahan udh di cuci bersih kecuali terasi. Kemudian goreng, ulek, koreksi rasa. Terakhir tambahkan potongan jeruk.
1. Ambil 1 potongan ayam, penyet diatas sambel, kemudian tambahkan terong goreng dan kemangi. Jika punya tambahan lalapan yg lain bisa ditambahkan sesuai selera ☺️




Wah ternyata resep ayam penyet sambel jeruk yang enak sederhana ini gampang sekali ya! Kalian semua dapat memasaknya. Cara Membuat ayam penyet sambel jeruk Sangat cocok sekali untuk kita yang baru mau belajar memasak maupun juga untuk anda yang sudah pandai memasak.

Apakah kamu tertarik mencoba membuat resep ayam penyet sambel jeruk lezat tidak rumit ini? Kalau kalian ingin, ayo kamu segera buruan siapkan alat dan bahan-bahannya, lalu bikin deh Resep ayam penyet sambel jeruk yang enak dan sederhana ini. Sangat gampang kan. 

Oleh karena itu, ketimbang kita berfikir lama-lama, yuk kita langsung saja bikin resep ayam penyet sambel jeruk ini. Dijamin kamu tiidak akan nyesel bikin resep ayam penyet sambel jeruk mantab tidak rumit ini! Selamat mencoba dengan resep ayam penyet sambel jeruk nikmat sederhana ini di rumah kalian masing-masing,ya!.

