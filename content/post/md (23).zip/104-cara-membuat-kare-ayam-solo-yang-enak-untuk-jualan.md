---
description: "Cara membuat Kare Ayam Solo yang enak Untuk Jualan"
title: "Cara membuat Kare Ayam Solo yang enak Untuk Jualan"
slug: 104-cara-membuat-kare-ayam-solo-yang-enak-untuk-jualan
date: 2021-01-25T00:44:54.561Z
image: https://img-global.cpcdn.com/recipes/26f27d315689d0bb/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/26f27d315689d0bb/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/26f27d315689d0bb/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Lora Smith
ratingvalue: 3.3
reviewcount: 9
recipeingredient:
- "250 gr dada ayam"
- "1.5 liter air"
- "1 lembar daun salam"
- "1 batang seraigeprek"
- "1 ruas lengkuasgeprek"
- "2 lembar daunjeruk"
- "Secukupnya kapulagakayu manis"
- "Secukupnya kaldu bubuk"
- "Secukupnya gulagaram"
- "2 bungkus santan kara 65ml"
- " Bumbu halus"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "2 butir kemiri"
- "Sejumput jintendikit aja"
- "1/2 sdt ketumbar bubuk"
- "1/4 sdt lada bubuk"
- "1 sdt kunyit bubuk"
- " Bahan pelengkap"
- " Toge rebus"
- " Bihun rebus"
- " Wortel rebus"
- " Keripik kentang"
- " Sambal bawang rebus           lihat resep"
recipeinstructions:
- "Rebus ayam,rebus bahan sambal,goreng keripik kentang sisihkan"
- "Uleg bumbu halus lalu tumis hingga harum.tambahkan sere,daun salam,daun jeruk,lengkuas,kapulaga,kayumanis.masukkan ayam yg sudah direbus,tambahkan air.Masukkan gula garam kaldu bubuk.koreksi rasa,jika sudah pas,masukkan santan,sering diaduk ya agar santan Tdk pecah.diidihkan kembali"
- "Siapkan semua bahan pelengkap"
- "Penyajian:tata dlm mangkok toge rebus,bihun rebus,wortel rebus,siram kuah kare,beri suwiran ayam diatasnya.taburi seledri dan bawang goreng.sajikan dgn sambal bawang rebus"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 262 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dinner

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/26f27d315689d0bb/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan santapan mantab pada keluarga adalah hal yang membahagiakan untuk anda sendiri. Kewajiban seorang istri bukan sekadar mengatur rumah saja, namun kamu pun harus memastikan kebutuhan nutrisi tercukupi dan santapan yang dimakan keluarga tercinta mesti nikmat.

Di zaman  saat ini, kalian sebenarnya bisa mengorder masakan siap saji tidak harus ribet memasaknya lebih dulu. Tetapi banyak juga lho orang yang memang mau memberikan makanan yang terbaik untuk keluarganya. Sebab, menyajikan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan orang tercinta. 



Mungkinkah anda salah satu penikmat kare ayam solo?. Asal kamu tahu, kare ayam solo adalah sajian khas di Nusantara yang saat ini digemari oleh banyak orang dari hampir setiap tempat di Nusantara. Anda dapat menghidangkan kare ayam solo buatan sendiri di rumahmu dan dapat dijadikan hidangan favoritmu di hari libur.

Anda tak perlu bingung untuk menyantap kare ayam solo, sebab kare ayam solo gampang untuk ditemukan dan anda pun boleh memasaknya sendiri di tempatmu. kare ayam solo bisa dibuat dengan beraneka cara. Saat ini telah banyak cara modern yang membuat kare ayam solo semakin lebih nikmat.

Resep kare ayam solo pun mudah sekali dibuat, lho. Kita jangan ribet-ribet untuk memesan kare ayam solo, karena Kita mampu menyajikan di rumahmu. Bagi Kita yang akan menyajikannya, dibawah ini merupakan resep membuat kare ayam solo yang nikamat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Kare Ayam Solo:

1. Sediakan 250 gr dada ayam
1. Gunakan 1.5 liter air
1. Sediakan 1 lembar daun salam
1. Ambil 1 batang serai,geprek
1. Gunakan 1 ruas lengkuas,geprek
1. Gunakan 2 lembar daunjeruk
1. Sediakan Secukupnya kapulaga,kayu manis
1. Sediakan Secukupnya kaldu bubuk
1. Siapkan Secukupnya gula,garam
1. Siapkan 2 bungkus santan kara (@65ml)
1. Sediakan  Bumbu halus:
1. Gunakan 5 siung bawang merah
1. Ambil 5 siung bawang putih
1. Gunakan 2 butir kemiri
1. Siapkan Sejumput jinten(dikit aja)
1. Sediakan 1/2 sdt ketumbar bubuk
1. Gunakan 1/4 sdt lada bubuk
1. Sediakan 1 sdt kunyit bubuk
1. Sediakan  Bahan pelengkap:
1. Siapkan  Toge rebus
1. Sediakan  Bihun rebus
1. Sediakan  Wortel rebus
1. Ambil  Keripik kentang
1. Gunakan  Sambal bawang rebus           (lihat resep)




<!--inarticleads2-->

##### Cara membuat Kare Ayam Solo:

1. Rebus ayam,rebus bahan sambal,goreng keripik kentang sisihkan
1. Uleg bumbu halus lalu tumis hingga harum.tambahkan sere,daun salam,daun jeruk,lengkuas,kapulaga,kayumanis.masukkan ayam yg sudah direbus,tambahkan air.Masukkan gula garam kaldu bubuk.koreksi rasa,jika sudah pas,masukkan santan,sering diaduk ya agar santan Tdk pecah.diidihkan kembali
1. Siapkan semua bahan pelengkap
1. Penyajian:tata dlm mangkok toge rebus,bihun rebus,wortel rebus,siram kuah kare,beri suwiran ayam diatasnya.taburi seledri dan bawang goreng.sajikan dgn sambal bawang rebus




Wah ternyata cara buat kare ayam solo yang lezat tidak rumit ini mudah banget ya! Kita semua dapat memasaknya. Resep kare ayam solo Sangat cocok sekali untuk kalian yang sedang belajar memasak ataupun juga bagi kamu yang sudah pandai dalam memasak.

Tertarik untuk mencoba buat resep kare ayam solo mantab sederhana ini? Kalau kalian ingin, mending kamu segera buruan siapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep kare ayam solo yang lezat dan tidak rumit ini. Sungguh mudah kan. 

Oleh karena itu, daripada kita berfikir lama-lama, hayo langsung aja hidangkan resep kare ayam solo ini. Pasti anda tiidak akan menyesal membuat resep kare ayam solo nikmat tidak ribet ini! Selamat mencoba dengan resep kare ayam solo lezat tidak ribet ini di rumah masing-masing,ya!.

