---
description: "Cara buat Kari Ayam Sederhana yang nikmat dan Mudah Dibuat"
title: "Cara buat Kari Ayam Sederhana yang nikmat dan Mudah Dibuat"
slug: 225-cara-buat-kari-ayam-sederhana-yang-nikmat-dan-mudah-dibuat
date: 2021-05-27T16:49:24.805Z
image: https://img-global.cpcdn.com/recipes/2bfe508fbc17cd24/680x482cq70/kari-ayam-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2bfe508fbc17cd24/680x482cq70/kari-ayam-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2bfe508fbc17cd24/680x482cq70/kari-ayam-sederhana-foto-resep-utama.jpg
author: Maud Lyons
ratingvalue: 4.3
reviewcount: 8
recipeingredient:
- "900 gr ayam kampung potong kecil2"
- "10 butir bawang merah"
- "5 butir bawang putih"
- "4 butir kemiri"
- "2 ruas jari lengkuas digeprek"
- "2 ruas jari jahe digeprek"
- "3 ruas jari kunyit"
- "3 batang sereh digeprek"
- "5 lbr daun jeruk"
- "3 lbr daun salam"
- "5 cabe merah besar"
- "5 cabe rawit selera ya bunda"
- "2 santan kara 60ml"
- "1 sdt ketumbar"
- "1/2 sdt merica butiran"
- "1/2 sdt jinten"
- "3000 ml air"
- "secukupnya Garam gula dan kayu manis"
recipeinstructions:
- "Bersihkan ayam dan potong agak kecil2."
- "Didihkan air, masukkan ayam beserta jahe dan lengkuas"
- "Sambil menunggu ayam empuk, haluskan Bamer, baput, merica, ketumbar, jinten, cabe merah, cabe rawit dan kemiri."
- "Panaskan minyak, tumis bumbu halus dan masukkan daun jeruk dan daun salam"
- "Setelah bumbu matang, masukkan ke dalam rebusan ayam lalu dan tuangi santan sambil terus diaduk agar santan tidak pecah. Koreksi rasa, jika sudah mendidih. Angkat."
categories:
- Resep
tags:
- kari
- ayam
- sederhana

katakunci: kari ayam sederhana 
nutrition: 139 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Lunch

---


![Kari Ayam Sederhana](https://img-global.cpcdn.com/recipes/2bfe508fbc17cd24/680x482cq70/kari-ayam-sederhana-foto-resep-utama.jpg)

Andai kita seorang yang hobi memasak, menyajikan masakan sedap bagi keluarga merupakan suatu hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang ibu bukan hanya mengatur rumah saja, namun anda juga harus menyediakan kebutuhan nutrisi terpenuhi dan juga olahan yang disantap anak-anak harus sedap.

Di era  sekarang, kamu memang bisa membeli santapan praktis walaupun tidak harus susah memasaknya terlebih dahulu. Tapi banyak juga mereka yang selalu ingin memberikan hidangan yang terenak untuk keluarganya. Pasalnya, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga tercinta. 



Apakah kamu salah satu penyuka kari ayam sederhana?. Tahukah kamu, kari ayam sederhana merupakan sajian khas di Nusantara yang sekarang disenangi oleh kebanyakan orang dari hampir setiap wilayah di Indonesia. Kalian bisa menyajikan kari ayam sederhana sendiri di rumahmu dan pasti jadi hidangan favoritmu di hari libur.

Kita tidak perlu bingung jika kamu ingin memakan kari ayam sederhana, sebab kari ayam sederhana tidak sulit untuk ditemukan dan juga anda pun dapat membuatnya sendiri di rumah. kari ayam sederhana bisa dimasak memalui beraneka cara. Kini pun ada banyak banget cara modern yang membuat kari ayam sederhana semakin enak.

Resep kari ayam sederhana pun sangat mudah dibikin, lho. Anda jangan ribet-ribet untuk memesan kari ayam sederhana, tetapi Kamu dapat menghidangkan ditempatmu. Untuk Kamu yang mau menghidangkannya, berikut ini resep untuk menyajikan kari ayam sederhana yang mantab yang bisa Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Kari Ayam Sederhana:

1. Siapkan 900 gr ayam kampung, potong kecil2
1. Sediakan 10 butir bawang merah
1. Sediakan 5 butir bawang putih
1. Sediakan 4 butir kemiri
1. Gunakan 2 ruas jari lengkuas, digeprek
1. Sediakan 2 ruas jari jahe, digeprek
1. Sediakan 3 ruas jari kunyit
1. Sediakan 3 batang sereh, digeprek
1. Gunakan 5 lbr daun jeruk
1. Gunakan 3 lbr daun salam
1. Siapkan 5 cabe merah besar
1. Gunakan 5 cabe rawit (selera ya bunda)
1. Siapkan 2 santan kara 60ml
1. Ambil 1 sdt ketumbar
1. Sediakan 1/2 sdt merica butiran
1. Gunakan 1/2 sdt jinten
1. Gunakan 3000 ml air
1. Gunakan secukupnya Garam, gula dan kayu manis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Kari Ayam Sederhana:

1. Bersihkan ayam dan potong agak kecil2.
1. Didihkan air, masukkan ayam beserta jahe dan lengkuas
1. Sambil menunggu ayam empuk, haluskan Bamer, baput, merica, ketumbar, jinten, cabe merah, cabe rawit dan kemiri.
1. Panaskan minyak, tumis bumbu halus dan masukkan daun jeruk dan daun salam
1. Setelah bumbu matang, masukkan ke dalam rebusan ayam lalu dan tuangi santan sambil terus diaduk agar santan tidak pecah. Koreksi rasa, jika sudah mendidih. Angkat.




Ternyata resep kari ayam sederhana yang lezat simple ini mudah banget ya! Anda Semua bisa membuatnya. Cara buat kari ayam sederhana Sangat cocok sekali buat kamu yang sedang belajar memasak atau juga untuk kamu yang telah pandai dalam memasak.

Apakah kamu mau mencoba bikin resep kari ayam sederhana nikmat tidak ribet ini? Kalau kalian ingin, ayo kalian segera siapkan alat-alat dan bahannya, setelah itu bikin deh Resep kari ayam sederhana yang enak dan tidak rumit ini. Benar-benar mudah kan. 

Maka, daripada anda diam saja, ayo kita langsung hidangkan resep kari ayam sederhana ini. Pasti kamu tak akan nyesel membuat resep kari ayam sederhana lezat tidak rumit ini! Selamat mencoba dengan resep kari ayam sederhana mantab tidak rumit ini di rumah masing-masing,oke!.

