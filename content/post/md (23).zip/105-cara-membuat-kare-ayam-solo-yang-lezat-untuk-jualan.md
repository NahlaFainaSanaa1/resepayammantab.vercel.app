---
description: "Cara membuat Kare Ayam Solo yang lezat Untuk Jualan"
title: "Cara membuat Kare Ayam Solo yang lezat Untuk Jualan"
slug: 105-cara-membuat-kare-ayam-solo-yang-lezat-untuk-jualan
date: 2021-05-29T11:51:55.988Z
image: https://img-global.cpcdn.com/recipes/73c44ee4979ff875/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/73c44ee4979ff875/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/73c44ee4979ff875/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Ryan Hopkins
ratingvalue: 4.4
reviewcount: 9
recipeingredient:
- "800 gram ayam broilersekitar 8 potongan"
- "500 ml santan kekentalan sedang"
- "1 batang daun bawang"
- "1 ikat kecil daun seledri"
- "2 buah tomat"
- "sesuai selera Cabe rawit"
- "1 buah wortel ukuran sedang"
- "1/2 lingkaran kol"
- "secukupnya Air"
- " Minyak untuk menumis"
- " Bahan pelengkap"
- " Keripik kentang"
- " Bihun  sohun"
- " Bumbu halus"
- "10 butir bawang merah"
- "5 butir bawang putih"
- "1/2 sdt jinten"
- "1 sdt ketumbar bubuk"
- "1 sdt kunyit halus"
- "3 butir kemiri sangrai"
- " Bumbu cemplung"
- "1 jempol lengkuas geprek"
- "3 lbr daun salam"
- "1 btg sereh geprek simpulkan"
- "1-2 sdt garam"
- "1 sdt kaldu bubuk"
- "2 sdt gula pasir"
recipeinstructions:
- "Siapkan semua bahan. Cuci cuci bersih."
- "Iris2 tomat, wortel, kol daun bawang dan seledri. Cabe rawit biarkan wutuhan. Siapkan santan kekentalan sedang."
- "Rebus ayam, buang dulu air rebusan pertama. Kemudian rebus lagi hingga keluar kaldu/minyaknya. Sisihkan"
- "Haluskan bumbu halus. Panaskan 2 sdm minyak goreng di api sedang. Tumis bumbu halus, osreng sebentar, masukkan daun salam, lengkuas, sereh, kayu manis. Tumis hingga harum dan tanak."
- "Kemudian masukkan ayam yg telah direbus beserta air rebusannya. Tambahkan garam, gula pasir, kaldu bubuk. Masak hingga mendidih."
- "Lalu masukkan air santan, masak hingga mendidih dengan terus diaduk ya agar santan tidak pecah. Jika dirasa terlalu kental kuahnya bisa ditambahkan sedikit air lagi."
- "Setelah mendidih, masukkan potongan kol, wortel, tomat, daun bawang. Bolak balik. Sambil cek rasa ya. Terakhir masukkan daun seledri dan cabe rawit. Masak hingga kekentalan kuah yg diinginkan. Siap disajikan."
- "Jangan lupa pelengkapnya bihun (sohun) dan keripik kentang. Jika ada taburi juga bawang goreng agar tambah sedeeep. Happy cooking..."
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 171 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/73c44ee4979ff875/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Apabila kita seorang orang tua, menyajikan olahan enak pada famili merupakan suatu hal yang memuaskan bagi anda sendiri. Tugas seorang  wanita bukan cuman menjaga rumah saja, tapi anda pun wajib memastikan kebutuhan gizi terpenuhi dan olahan yang dimakan keluarga tercinta harus menggugah selera.

Di era  saat ini, anda sebenarnya mampu membeli masakan praktis tanpa harus repot memasaknya lebih dulu. Namun banyak juga lho orang yang selalu ingin memberikan makanan yang terenak bagi orang yang dicintainya. Lantaran, memasak yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut berdasarkan selera orang tercinta. 



Apakah anda adalah seorang penggemar kare ayam solo?. Asal kamu tahu, kare ayam solo adalah sajian khas di Indonesia yang sekarang disukai oleh orang-orang di berbagai wilayah di Indonesia. Kita bisa menyajikan kare ayam solo hasil sendiri di rumah dan pasti jadi makanan favorit di hari liburmu.

Anda tak perlu bingung jika kamu ingin menyantap kare ayam solo, lantaran kare ayam solo gampang untuk dicari dan anda pun dapat mengolahnya sendiri di tempatmu. kare ayam solo boleh dibuat dengan beraneka cara. Kini ada banyak cara modern yang menjadikan kare ayam solo semakin lebih nikmat.

Resep kare ayam solo pun sangat mudah untuk dibikin, lho. Kamu tidak usah capek-capek untuk memesan kare ayam solo, karena Anda mampu membuatnya di rumah sendiri. Bagi Anda yang hendak menghidangkannya, berikut resep untuk membuat kare ayam solo yang enak yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Kare Ayam Solo:

1. Siapkan 800 gram ayam broiler/sekitar 8 potongan
1. Ambil 500 ml santan kekentalan sedang
1. Siapkan 1 batang daun bawang
1. Sediakan 1 ikat kecil daun seledri
1. Gunakan 2 buah tomat
1. Ambil sesuai selera Cabe rawit
1. Siapkan 1 buah wortel ukuran sedang
1. Sediakan 1/2 lingkaran kol
1. Gunakan secukupnya Air
1. Siapkan  Minyak untuk menumis
1. Ambil  Bahan pelengkap
1. Ambil  Keripik kentang
1. Sediakan  Bihun / sohun
1. Siapkan  Bumbu halus
1. Siapkan 10 butir bawang merah
1. Gunakan 5 butir bawang putih
1. Sediakan 1/2 sdt jinten
1. Sediakan 1 sdt ketumbar bubuk
1. Sediakan 1 sdt kunyit halus
1. Siapkan 3 butir kemiri sangrai
1. Ambil  Bumbu cemplung
1. Gunakan 1 jempol lengkuas, geprek
1. Sediakan 3 lbr daun salam
1. Gunakan 1 btg sereh, geprek, simpulkan
1. Siapkan 1-2 sdt garam
1. Ambil 1 sdt kaldu bubuk
1. Ambil 2 sdt gula pasir




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Kare Ayam Solo:

1. Siapkan semua bahan. Cuci cuci bersih.
1. Iris2 tomat, wortel, kol daun bawang dan seledri. Cabe rawit biarkan wutuhan. Siapkan santan kekentalan sedang.
1. Rebus ayam, buang dulu air rebusan pertama. Kemudian rebus lagi hingga keluar kaldu/minyaknya. Sisihkan
1. Haluskan bumbu halus. Panaskan 2 sdm minyak goreng di api sedang. Tumis bumbu halus, osreng sebentar, masukkan daun salam, lengkuas, sereh, kayu manis. Tumis hingga harum dan tanak.
1. Kemudian masukkan ayam yg telah direbus beserta air rebusannya. Tambahkan garam, gula pasir, kaldu bubuk. Masak hingga mendidih.
1. Lalu masukkan air santan, masak hingga mendidih dengan terus diaduk ya agar santan tidak pecah. Jika dirasa terlalu kental kuahnya bisa ditambahkan sedikit air lagi.
1. Setelah mendidih, masukkan potongan kol, wortel, tomat, daun bawang. Bolak balik. Sambil cek rasa ya. Terakhir masukkan daun seledri dan cabe rawit. Masak hingga kekentalan kuah yg diinginkan. Siap disajikan.
1. Jangan lupa pelengkapnya bihun (sohun) dan keripik kentang. Jika ada taburi juga bawang goreng agar tambah sedeeep. Happy cooking...




Wah ternyata resep kare ayam solo yang mantab tidak ribet ini mudah sekali ya! Anda Semua dapat mencobanya. Cara buat kare ayam solo Cocok sekali buat kamu yang baru mau belajar memasak maupun juga untuk anda yang sudah ahli memasak.

Apakah kamu tertarik mulai mencoba membikin resep kare ayam solo mantab simple ini? Kalau kamu ingin, ayo kamu segera buruan siapkan alat dan bahannya, lantas buat deh Resep kare ayam solo yang nikmat dan tidak ribet ini. Sungguh mudah kan. 

Oleh karena itu, daripada anda diam saja, ayo kita langsung saja buat resep kare ayam solo ini. Dijamin kalian tak akan nyesel bikin resep kare ayam solo nikmat simple ini! Selamat berkreasi dengan resep kare ayam solo nikmat sederhana ini di tempat tinggal masing-masing,oke!.

