---
description: "Resep Kare Ayam khas Solo yang lezat Untuk Jualan"
title: "Resep Kare Ayam khas Solo yang lezat Untuk Jualan"
slug: 102-resep-kare-ayam-khas-solo-yang-lezat-untuk-jualan
date: 2021-06-29T20:33:33.646Z
image: https://img-global.cpcdn.com/recipes/ff17a8d3a097dcfc/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff17a8d3a097dcfc/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff17a8d3a097dcfc/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
author: Lucinda Drake
ratingvalue: 3.9
reviewcount: 3
recipeingredient:
- "1 ekor ayam"
- "2 batang sereh memarkan"
- "3 lbr Daun salam"
- "3 lbrbDaun jeruk"
- "2 rj Laos"
- "200 ml Kara"
- " Air"
- "1 jari kayu manis"
- "1 bks kapulaga 1k"
- " Kaldu bubuk"
- " Bumbu halus "
- "10 siung Bawang merah"
- "6 siung Bawang putih"
- "1 bks Jinten 1k"
- "1/2 sdt Ketumbar bubuk"
- "1/2 sdt lada bubuk"
- "1 sdt kunyit bubuk"
- "1/4 sdt Paladisisir"
- "3 buah Kemiridibakar dulu yaa"
- "1 sdm Garam"
- "1 sdt Gula"
- " Pelengkap "
- " Wortel rebusdipotongbulat tipisyg td direbus dikaldu"
- " Bihunrendam air hangatdigunting"
- " Keripik kentang           lihat resep"
- " Sambal dari cabe  bawang putih yg direbus           lihat resep"
- "1 bks kecambahdibilas air anget yaa"
- " Suiran ayam"
- " Bawang goreng           lihat resep"
recipeinstructions:
- "Siapkan semua bahan. Cuci bersih ayam dan bahan yang lain."
- "Didihkan air. Rebus ayam hingga berubah warna/setengah matang. Tiriskan ayam. Buang air rebusan nya.(diblansir) Rebus kembali ayam dengan air yang baru,tambahkan kayu manis, kapulaga dan 1 sdt garam. Tambahan diresepku : Tambahkan wortel utuh ya..rebus kembali sampai mendidih.saat merebus jika dirasa wotel udah masak angkat yaa dan sisihkan untuk topping.sementara rebus ayam kita menghaluskan dan menumis bumbu yaa."
- "Tumis bumbu yang sudah dihaluskan, tambahkan daun salam, daun jeruk, lengkuas, serai hingga harum dan matang.tambahkan ke dalam air kaldu.           (lihat tips)"
- "Tambahkan santan. Aduk rata, beri gula, garam, kaldu bubuk. Tunggu sampai mendidih, Koreksi rasa"
- "Aduk perlahan. Masak hingga ayam matang(ambil ayam,lalu disuir). Tambahkan santan,cek rasa. Siapkan bahan pelengkap yaa... Untuk sambal soto bisa liat disini yaa...           (lihat resep)"
- "Cara penyajian : Tata di piring saji nasi,wortel,keripik kentang,soun, suiran/potongan kecil ayam lalu disiram kuah karenya."
categories:
- Resep
tags:
- kare
- ayam
- khas

katakunci: kare ayam khas 
nutrition: 178 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dessert

---


![Kare Ayam khas Solo](https://img-global.cpcdn.com/recipes/ff17a8d3a097dcfc/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan panganan menggugah selera bagi famili adalah suatu hal yang mengasyikan untuk kamu sendiri. Tanggung jawab seorang istri Tidak saja mengatur rumah saja, namun kamu pun harus menyediakan keperluan nutrisi terpenuhi dan juga santapan yang disantap anak-anak harus nikmat.

Di masa  sekarang, anda sebenarnya mampu mengorder panganan instan meski tidak harus ribet mengolahnya dulu. Tetapi ada juga lho orang yang memang ingin memberikan makanan yang terlezat bagi orang yang dicintainya. Pasalnya, menyajikan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan keluarga. 



Apakah kamu seorang penyuka kare ayam khas solo?. Asal kamu tahu, kare ayam khas solo adalah sajian khas di Indonesia yang sekarang disenangi oleh kebanyakan orang dari berbagai daerah di Indonesia. Kalian bisa menyajikan kare ayam khas solo buatan sendiri di rumah dan pasti jadi camilan kesukaanmu di hari libur.

Anda jangan bingung jika kamu ingin menyantap kare ayam khas solo, lantaran kare ayam khas solo sangat mudah untuk ditemukan dan juga kamu pun dapat mengolahnya sendiri di rumah. kare ayam khas solo boleh dibuat dengan berbagai cara. Kini telah banyak cara modern yang menjadikan kare ayam khas solo semakin enak.

Resep kare ayam khas solo pun sangat gampang dibuat, lho. Kita tidak perlu repot-repot untuk memesan kare ayam khas solo, tetapi Kita dapat membuatnya ditempatmu. Untuk Kita yang hendak mencobanya, berikut ini cara menyajikan kare ayam khas solo yang nikamat yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Kare Ayam khas Solo:

1. Siapkan 1 ekor ayam
1. Gunakan 2 batang sereh, memarkan
1. Gunakan 3 lbr Daun salam
1. Siapkan 3 lbrbDaun jeruk
1. Siapkan 2 rj Laos
1. Ambil 200 ml Kara
1. Sediakan  Air
1. Siapkan 1 jari kayu manis
1. Siapkan 1 bks kapulaga @1k
1. Ambil  Kaldu bubuk
1. Sediakan  Bumbu halus :
1. Ambil 10 siung Bawang merah
1. Siapkan 6 siung Bawang putih
1. Siapkan 1 bks Jinten @1k
1. Gunakan 1/2 sdt Ketumbar bubuk
1. Ambil 1/2 sdt lada bubuk
1. Sediakan 1 sdt kunyit bubuk
1. Gunakan 1/4 sdt Pala,disisir
1. Sediakan 3 buah Kemiri,dibakar dulu yaa
1. Gunakan 1 sdm Garam
1. Siapkan 1 sdt Gula
1. Ambil  Pelengkap :
1. Gunakan  Wortel rebus,dipotong&#34;bulat tipis(yg td direbus dikaldu)
1. Siapkan  Bihun,rendam air hangat,digunting&#34;
1. Siapkan  Keripik kentang           (lihat resep)
1. Gunakan  Sambal dari cabe &amp; bawang putih yg direbus           (lihat resep)
1. Ambil 1 bks kecambah,dibilas air anget yaa
1. Gunakan  Suiran ayam
1. Gunakan  Bawang goreng           (lihat resep)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Kare Ayam khas Solo:

1. Siapkan semua bahan. Cuci bersih ayam dan bahan yang lain.
1. Didihkan air. Rebus ayam hingga berubah warna/setengah matang. Tiriskan ayam. Buang air rebusan nya.(diblansir) Rebus kembali ayam dengan air yang baru,tambahkan kayu manis, kapulaga dan 1 sdt garam. - Tambahan diresepku : Tambahkan wortel utuh ya..rebus kembali sampai mendidih.saat merebus jika dirasa wotel udah masak angkat yaa dan sisihkan untuk topping.sementara rebus ayam kita menghaluskan dan menumis bumbu yaa.
1. Tumis bumbu yang sudah dihaluskan, tambahkan daun salam, daun jeruk, lengkuas, serai hingga harum dan matang.tambahkan ke dalam air kaldu. -           (lihat tips)
1. Tambahkan santan. Aduk rata, beri gula, garam, kaldu bubuk. Tunggu sampai mendidih, Koreksi rasa
1. Aduk perlahan. Masak hingga ayam matang(ambil ayam,lalu disuir). Tambahkan santan,cek rasa. - Siapkan bahan pelengkap yaa... - Untuk sambal soto bisa liat disini yaa... -           (lihat resep)
1. Cara penyajian : - Tata di piring saji nasi,wortel,keripik kentang,soun, suiran/potongan kecil ayam lalu disiram kuah karenya.




Wah ternyata cara buat kare ayam khas solo yang lezat tidak ribet ini mudah banget ya! Semua orang mampu mencobanya. Cara buat kare ayam khas solo Sangat cocok banget buat kamu yang baru mau belajar memasak atau juga bagi anda yang telah hebat memasak.

Tertarik untuk mulai mencoba membikin resep kare ayam khas solo nikmat sederhana ini? Kalau kalian ingin, ayo kalian segera buruan siapin alat-alat dan bahannya, setelah itu buat deh Resep kare ayam khas solo yang nikmat dan simple ini. Sangat gampang kan. 

Maka, daripada kalian berfikir lama-lama, hayo kita langsung buat resep kare ayam khas solo ini. Dijamin kamu tak akan menyesal sudah membuat resep kare ayam khas solo enak tidak rumit ini! Selamat berkreasi dengan resep kare ayam khas solo lezat sederhana ini di tempat tinggal kalian sendiri,oke!.

