---
description: "Resep Sup Ayam Simple Sederhana dan Mudah Dibuat"
title: "Resep Sup Ayam Simple Sederhana dan Mudah Dibuat"
slug: 342-resep-sup-ayam-simple-sederhana-dan-mudah-dibuat
date: 2021-05-04T16:36:35.931Z
image: https://img-global.cpcdn.com/recipes/8c6a3cb5642da86d/680x482cq70/sup-ayam-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c6a3cb5642da86d/680x482cq70/sup-ayam-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c6a3cb5642da86d/680x482cq70/sup-ayam-simple-foto-resep-utama.jpg
author: Juan Tucker
ratingvalue: 3.2
reviewcount: 11
recipeingredient:
- "3 siung bawang putih geprek"
- "1/4 ayam"
- "1 buah wortel"
- "1 buah kentang ukuran besar"
- "1 kuntum bunga kol"
- "secukupnya Daun bawang daun sup"
- "secukupnya Garam"
- "secukupnya Kaldu bubuk"
- "secukupnya Merica bubuk"
recipeinstructions:
- "Cuci bersih ayam, beri jeruk nipis. Diamkan sebentar. Cuci kembali. Potong2 ayam sesuai selera."
- "Kupas kentang dan wortel, potong2.kemudian cuci bersih.cuci bersih juga bunga kol, daun bawang daun sup dan bawang putih."
- "Tumis bawang putih geprek, tumis hingga harum. Masukkan ayam. Tumis ayam hingga berubah warna."
- "Masukkan air.setelah ayam matang, masukkan wortel, kentang daun bawang daun sup. Didihkan air. Rebus selama 3 menit. Angkat dan tiriskan. Cuci bersih kembali, buang ulat jika nampak. Masukkan brokoli ke dalam sup."
- "Masukkan garam, kaldu bubuk dan merica bubuk. Tes rasa dan siap disajikan."
categories:
- Resep
tags:
- sup
- ayam
- simple

katakunci: sup ayam simple 
nutrition: 187 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Lunch

---


![Sup Ayam Simple](https://img-global.cpcdn.com/recipes/8c6a3cb5642da86d/680x482cq70/sup-ayam-simple-foto-resep-utama.jpg)

Jika kalian seorang ibu, mempersiapkan santapan menggugah selera buat keluarga tercinta merupakan suatu hal yang memuaskan bagi kamu sendiri. Kewajiban seorang ibu Tidak cuman mengurus rumah saja, tetapi kamu pun harus menyediakan kebutuhan nutrisi terpenuhi dan juga hidangan yang disantap anak-anak harus menggugah selera.

Di masa  sekarang, anda memang mampu memesan panganan praktis meski tidak harus susah mengolahnya lebih dulu. Tapi banyak juga lho mereka yang selalu ingin menghidangkan yang terenak untuk keluarganya. Lantaran, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai masakan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penyuka sup ayam simple?. Asal kamu tahu, sup ayam simple adalah makanan khas di Indonesia yang kini digemari oleh kebanyakan orang di hampir setiap daerah di Indonesia. Kamu bisa menyajikan sup ayam simple sendiri di rumahmu dan dapat dijadikan santapan favorit di hari libur.

Anda tak perlu bingung jika kamu ingin mendapatkan sup ayam simple, karena sup ayam simple tidak sukar untuk dicari dan juga kalian pun boleh memasaknya sendiri di rumah. sup ayam simple dapat dibuat memalui berbagai cara. Sekarang ada banyak cara kekinian yang membuat sup ayam simple semakin lebih mantap.

Resep sup ayam simple pun mudah dibuat, lho. Kalian tidak perlu repot-repot untuk membeli sup ayam simple, sebab Kamu bisa membuatnya di rumahmu. Bagi Kita yang hendak menghidangkannya, berikut ini cara untuk menyajikan sup ayam simple yang enak yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Sup Ayam Simple:

1. Sediakan 3 siung bawang putih geprek
1. Siapkan 1/4 ayam
1. Ambil 1 buah wortel
1. Sediakan 1 buah kentang ukuran besar
1. Siapkan 1 kuntum bunga kol
1. Ambil secukupnya Daun bawang daun sup
1. Sediakan secukupnya Garam
1. Siapkan secukupnya Kaldu bubuk
1. Ambil secukupnya Merica bubuk




<!--inarticleads2-->

##### Cara menyiapkan Sup Ayam Simple:

1. Cuci bersih ayam, beri jeruk nipis. Diamkan sebentar. Cuci kembali. Potong2 ayam sesuai selera.
<img src="https://img-global.cpcdn.com/steps/ad3279ae91da80f0/160x128cq70/sup-ayam-simple-langkah-memasak-1-foto.jpg" alt="Sup Ayam Simple"><img src="https://img-global.cpcdn.com/steps/f79ac91e5b8200b6/160x128cq70/sup-ayam-simple-langkah-memasak-1-foto.jpg" alt="Sup Ayam Simple">1. Kupas kentang dan wortel, potong2.kemudian cuci bersih.cuci bersih juga bunga kol, daun bawang daun sup dan bawang putih.
<img src="https://img-global.cpcdn.com/steps/b9b25e36b69ad7c3/160x128cq70/sup-ayam-simple-langkah-memasak-2-foto.jpg" alt="Sup Ayam Simple"><img src="https://img-global.cpcdn.com/steps/75610a2a1f0c616b/160x128cq70/sup-ayam-simple-langkah-memasak-2-foto.jpg" alt="Sup Ayam Simple">1. Tumis bawang putih geprek, tumis hingga harum. Masukkan ayam. Tumis ayam hingga berubah warna.
1. Masukkan air.setelah ayam matang, masukkan wortel, kentang daun bawang daun sup. Didihkan air. Rebus selama 3 menit. Angkat dan tiriskan. Cuci bersih kembali, buang ulat jika nampak. Masukkan brokoli ke dalam sup.
1. Masukkan garam, kaldu bubuk dan merica bubuk. Tes rasa dan siap disajikan.




Wah ternyata cara buat sup ayam simple yang nikamt tidak rumit ini mudah banget ya! Kalian semua mampu memasaknya. Cara Membuat sup ayam simple Sangat cocok banget buat kalian yang baru mau belajar memasak atau juga bagi kamu yang sudah jago dalam memasak.

Tertarik untuk mencoba membikin resep sup ayam simple enak simple ini? Kalau kalian ingin, mending kamu segera menyiapkan alat-alat dan bahannya, setelah itu bikin deh Resep sup ayam simple yang lezat dan simple ini. Sangat mudah kan. 

Jadi, ketimbang anda berlama-lama, maka kita langsung bikin resep sup ayam simple ini. Pasti kalian gak akan nyesel sudah bikin resep sup ayam simple nikmat sederhana ini! Selamat berkreasi dengan resep sup ayam simple enak tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

