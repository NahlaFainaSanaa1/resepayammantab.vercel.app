---
description: "Cara membuat Tahu dan Ati Ayam Masak Sambal yang lezat dan Mudah Dibuat"
title: "Cara membuat Tahu dan Ati Ayam Masak Sambal yang lezat dan Mudah Dibuat"
slug: 309-cara-membuat-tahu-dan-ati-ayam-masak-sambal-yang-lezat-dan-mudah-dibuat
date: 2021-04-18T10:28:23.368Z
image: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
author: Marc Walker
ratingvalue: 3.1
reviewcount: 14
recipeingredient:
- "4 buah Tahu ukuran sedang goreng"
- "250 gram Hati ayam rebus lalu goreng"
- "2 cm lengkuas geprek"
- "2 lembar daun salam"
- "1 sdt Garam"
- "1 sdt Gula"
- "1/2 sdt Merica"
- "2 sdm Kecap manis jika suka"
- " Kaldu udang 1 sdt bisa juga kaldu jamur atau lainnya           lihat resep"
- " Bumbu halus "
- "6 buah Bawang merah"
- "3 siung Bawang putih"
- "3 buah Cabe merah besar"
- "15 buah cabe rawit sesuai selera"
recipeinstructions:
- "Siapkan bahan : Goreng tahu. Rebus dan goreng hati sapi. Haluskan bumbu."
- "Tumis bumbu dengan sedikit minyak, masukkan Lengkuas dan daun salam. Aduk rata biarkan hingga harum, selagi menunggu, potong² hati sapi. Setelah bumbu harum masukkan kedua bahan utama. Aduk rata."
- "Beri sedikit air, masukkan, gula, garam, merica, kaldu udang, kecap. Aduk rata. Test rasa. Masak hingga air menyusut dan bumbu meresap."
- "Tahu dan Ati Ayam masak sambal, siap di sajikan dengan nasi hangat. Selamat mencoba. Praktis dan enak."
categories:
- Resep
tags:
- tahu
- dan
- ati

katakunci: tahu dan ati 
nutrition: 285 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dessert

---


![Tahu dan Ati Ayam Masak Sambal](https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyuguhkan masakan lezat kepada orang tercinta adalah hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang  wanita Tidak saja menangani rumah saja, tetapi anda pun harus menyediakan keperluan gizi tercukupi dan juga panganan yang dimakan keluarga tercinta wajib nikmat.

Di zaman  saat ini, kalian memang dapat memesan santapan jadi tidak harus ribet membuatnya dahulu. Tetapi banyak juga lho mereka yang selalu ingin menghidangkan yang terlezat bagi keluarganya. Lantaran, menghidangkan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai selera orang tercinta. 



Apakah anda merupakan salah satu penggemar tahu dan ati ayam masak sambal?. Asal kamu tahu, tahu dan ati ayam masak sambal merupakan hidangan khas di Indonesia yang sekarang digemari oleh orang-orang di hampir setiap daerah di Indonesia. Kalian dapat membuat tahu dan ati ayam masak sambal kreasi sendiri di rumah dan boleh jadi camilan favorit di akhir pekanmu.

Kita tidak usah bingung untuk memakan tahu dan ati ayam masak sambal, lantaran tahu dan ati ayam masak sambal mudah untuk dicari dan juga kalian pun boleh mengolahnya sendiri di rumah. tahu dan ati ayam masak sambal dapat diolah dengan berbagai cara. Sekarang ada banyak banget cara kekinian yang menjadikan tahu dan ati ayam masak sambal semakin lebih mantap.

Resep tahu dan ati ayam masak sambal pun gampang dibikin, lho. Kamu tidak usah capek-capek untuk membeli tahu dan ati ayam masak sambal, tetapi Kita bisa membuatnya di rumah sendiri. Untuk Kalian yang mau menghidangkannya, dibawah ini merupakan resep untuk menyajikan tahu dan ati ayam masak sambal yang nikamat yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Tahu dan Ati Ayam Masak Sambal:

1. Gunakan 4 buah Tahu ukuran sedang (goreng)
1. Gunakan 250 gram Hati ayam (rebus lalu goreng)
1. Siapkan 2 cm lengkuas geprek
1. Ambil 2 lembar daun salam
1. Sediakan 1 sdt Garam
1. Gunakan 1 sdt Gula
1. Sediakan 1/2 sdt Merica
1. Ambil 2 sdm Kecap manis (jika suka)
1. Sediakan  Kaldu udang 1 sdt (bisa juga kaldu jamur atau lainnya)           (lihat resep)
1. Ambil  Bumbu halus :
1. Siapkan 6 buah Bawang merah
1. Siapkan 3 siung Bawang putih
1. Sediakan 3 buah Cabe merah besar
1. Sediakan 15 buah cabe rawit (sesuai selera)




<!--inarticleads2-->

##### Langkah-langkah membuat Tahu dan Ati Ayam Masak Sambal:

1. Siapkan bahan : Goreng tahu. Rebus dan goreng hati sapi. Haluskan bumbu.
1. Tumis bumbu dengan sedikit minyak, masukkan Lengkuas dan daun salam. Aduk rata biarkan hingga harum, selagi menunggu, potong² hati sapi. Setelah bumbu harum masukkan kedua bahan utama. Aduk rata.
1. Beri sedikit air, masukkan, gula, garam, merica, kaldu udang, kecap. Aduk rata. Test rasa. Masak hingga air menyusut dan bumbu meresap.
1. Tahu dan Ati Ayam masak sambal, siap di sajikan dengan nasi hangat. Selamat mencoba. Praktis dan enak.




Wah ternyata cara buat tahu dan ati ayam masak sambal yang mantab sederhana ini enteng sekali ya! Kita semua bisa membuatnya. Cara buat tahu dan ati ayam masak sambal Sangat sesuai sekali buat kita yang baru akan belajar memasak ataupun juga bagi kalian yang telah jago memasak.

Apakah kamu mau mencoba bikin resep tahu dan ati ayam masak sambal lezat tidak ribet ini? Kalau mau, mending kamu segera menyiapkan peralatan dan bahannya, setelah itu bikin deh Resep tahu dan ati ayam masak sambal yang lezat dan tidak ribet ini. Benar-benar mudah kan. 

Maka, daripada anda berfikir lama-lama, ayo kita langsung hidangkan resep tahu dan ati ayam masak sambal ini. Pasti anda tiidak akan nyesel membuat resep tahu dan ati ayam masak sambal mantab sederhana ini! Selamat berkreasi dengan resep tahu dan ati ayam masak sambal nikmat tidak ribet ini di tempat tinggal sendiri,ya!.

