---
description: "Resep Hati ayam masak pedas yang nikmat dan Mudah Dibuat"
title: "Resep Hati ayam masak pedas yang nikmat dan Mudah Dibuat"
slug: 324-resep-hati-ayam-masak-pedas-yang-nikmat-dan-mudah-dibuat
date: 2021-01-11T14:30:55.364Z
image: https://img-global.cpcdn.com/recipes/9b4264ebe46b4dfe/680x482cq70/hati-ayam-masak-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9b4264ebe46b4dfe/680x482cq70/hati-ayam-masak-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9b4264ebe46b4dfe/680x482cq70/hati-ayam-masak-pedas-foto-resep-utama.jpg
author: Ella Wheeler
ratingvalue: 3.1
reviewcount: 7
recipeingredient:
- "1/2 kg hati ayam"
- " Bumbu "
- "3 siung bawang putih"
- "4 siung bawang merah"
- "1/2 SDt ketumbar"
- "1 ruas kunyit"
- "1/4 sdt merica bubuk"
- "1 sdt gula merah"
- "1 sdt gula pasir"
- "10 biji cabe rawit"
- " Dauh jeruk"
- " Garam dan penyedap rasa"
recipeinstructions:
- "Rebus hati ayam 10 menit,angkt tiriskan,sisihkan"
- "Haluskan semua bumbu,setelah bumbu halus,terus tumis bumbu sampai harum,lalu masukkan hati ayam td,beri air segelas masukkan daun jeruk tambahkan garam dan penyedap rasa,masak sampai air menyusut,sajikan"
categories:
- Resep
tags:
- hati
- ayam
- masak

katakunci: hati ayam masak 
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dinner

---


![Hati ayam masak pedas](https://img-global.cpcdn.com/recipes/9b4264ebe46b4dfe/680x482cq70/hati-ayam-masak-pedas-foto-resep-utama.jpg)

Andai anda seorang yang hobi memasak, menyuguhkan olahan mantab buat keluarga adalah suatu hal yang sangat menyenangkan untuk kamu sendiri. Tugas seorang istri bukan cuman menjaga rumah saja, tapi anda pun wajib menyediakan kebutuhan nutrisi terpenuhi dan juga santapan yang dimakan orang tercinta mesti nikmat.

Di era  sekarang, kalian memang mampu membeli olahan jadi meski tanpa harus capek mengolahnya terlebih dahulu. Tetapi ada juga lho mereka yang memang ingin memberikan hidangan yang terbaik untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan sesuai dengan masakan kesukaan keluarga. 



Mungkinkah anda merupakan salah satu penggemar hati ayam masak pedas?. Asal kamu tahu, hati ayam masak pedas merupakan sajian khas di Nusantara yang sekarang digemari oleh banyak orang dari hampir setiap tempat di Nusantara. Kita bisa membuat hati ayam masak pedas olahan sendiri di rumahmu dan pasti jadi santapan favorit di hari liburmu.

Kalian tidak perlu bingung untuk mendapatkan hati ayam masak pedas, sebab hati ayam masak pedas gampang untuk dicari dan kamu pun bisa membuatnya sendiri di rumah. hati ayam masak pedas boleh diolah lewat berbagai cara. Sekarang sudah banyak resep kekinian yang menjadikan hati ayam masak pedas semakin nikmat.

Resep hati ayam masak pedas pun gampang untuk dibikin, lho. Kamu jangan capek-capek untuk memesan hati ayam masak pedas, lantaran Anda dapat menyiapkan ditempatmu. Untuk Kita yang ingin menyajikannya, di bawah ini adalah resep untuk membuat hati ayam masak pedas yang lezat yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Hati ayam masak pedas:

1. Gunakan 1/2 kg hati ayam
1. Siapkan  Bumbu :
1. Siapkan 3 siung bawang putih
1. Ambil 4 siung bawang merah
1. Gunakan 1/2 SDt ketumbar
1. Sediakan 1 ruas kunyit
1. Sediakan 1/4 sdt merica bubuk
1. Gunakan 1 sdt gula merah
1. Siapkan 1 sdt gula pasir
1. Ambil 10 biji cabe rawit
1. Ambil  Dauh jeruk
1. Siapkan  Garam dan penyedap rasa




<!--inarticleads2-->

##### Langkah-langkah membuat Hati ayam masak pedas:

1. Rebus hati ayam 10 menit,angkt tiriskan,sisihkan
1. Haluskan semua bumbu,setelah bumbu halus,terus tumis bumbu sampai harum,lalu masukkan hati ayam td,beri air segelas masukkan daun jeruk tambahkan garam dan penyedap rasa,masak sampai air menyusut,sajikan




Wah ternyata cara membuat hati ayam masak pedas yang nikamt simple ini gampang banget ya! Semua orang mampu memasaknya. Cara Membuat hati ayam masak pedas Sangat sesuai sekali untuk kalian yang baru belajar memasak atau juga bagi kalian yang sudah ahli memasak.

Tertarik untuk mulai mencoba membikin resep hati ayam masak pedas lezat sederhana ini? Kalau tertarik, mending kamu segera buruan siapkan alat dan bahan-bahannya, kemudian bikin deh Resep hati ayam masak pedas yang enak dan tidak rumit ini. Sangat gampang kan. 

Oleh karena itu, daripada kalian diam saja, hayo kita langsung sajikan resep hati ayam masak pedas ini. Dijamin anda tiidak akan nyesel membuat resep hati ayam masak pedas enak sederhana ini! Selamat berkreasi dengan resep hati ayam masak pedas nikmat simple ini di tempat tinggal sendiri,ya!.

