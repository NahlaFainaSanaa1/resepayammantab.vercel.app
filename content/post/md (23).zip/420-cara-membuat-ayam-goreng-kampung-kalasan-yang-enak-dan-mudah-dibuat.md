---
description: "Cara membuat Ayam Goreng Kampung Kalasan yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam Goreng Kampung Kalasan yang enak dan Mudah Dibuat"
slug: 420-cara-membuat-ayam-goreng-kampung-kalasan-yang-enak-dan-mudah-dibuat
date: 2021-03-27T06:56:35.324Z
image: https://img-global.cpcdn.com/recipes/75eaada8fccf92b9/680x482cq70/ayam-goreng-kampung-kalasan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/75eaada8fccf92b9/680x482cq70/ayam-goreng-kampung-kalasan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/75eaada8fccf92b9/680x482cq70/ayam-goreng-kampung-kalasan-foto-resep-utama.jpg
author: Phoebe Bailey
ratingvalue: 4
reviewcount: 8
recipeingredient:
- "2 ekor Ayam Kampung"
- "2 liter Air Kelapa"
- "20 siung bawang merah"
- "10 siung bawang putih"
- "2 sdm Ketumbar bubuk"
- "4 bh kemiri"
- " Gula merah ukuran sesuai selera diiris tipis"
- "secukupnya Garam"
- "secukupnya Penyedap"
- "4 lbr Daun salam"
- "1 ruas jari Lengkuas"
recipeinstructions:
- "Potong ayam ukuran sesuai selera dan bersihkan"
- "Haluskan bumbu, kecuali daun salam, lengkuas gula merah, penyedap"
- "Siapkan wajan..masukan ayam potong dan balurkan bumbu halus dengan rata..nyalakan api"
- "Masukan Air Kelapa, daun salam, lengkuas..aduk hingga rata dan air mendidih"
- "Setelah mendidih, masukan gula merah..aduk hingga rata"
- "Masukan penyedap, aduk rata..kecilkan api..masak hingga ayam empuk dan air menyusut dan aduk sesekali agar tidak gosong dibawah"
- "Koreksi rasa..setelah empuk dan air menyusut.matikan api..angkat"
- "Panas minyak goreng diatas wajan, goreng ayam kalasan, masak sebentar saja krn cepat gosong."
- "Sajikan dengan Nasi Panas, Lalapan dan Sambal goreng lebih enak (resep sambal goreng di resep berikutnya)"
categories:
- Resep
tags:
- ayam
- goreng
- kampung

katakunci: ayam goreng kampung 
nutrition: 233 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Kampung Kalasan](https://img-global.cpcdn.com/recipes/75eaada8fccf92b9/680x482cq70/ayam-goreng-kampung-kalasan-foto-resep-utama.jpg)

Selaku seorang ibu, menyajikan olahan nikmat bagi famili adalah suatu hal yang menggembirakan bagi kamu sendiri. Kewajiban seorang ibu bukan cuman mengatur rumah saja, tapi anda pun wajib menyediakan keperluan gizi tercukupi dan juga panganan yang dikonsumsi keluarga tercinta harus sedap.

Di zaman  sekarang, kamu memang dapat mengorder santapan instan meski tidak harus repot mengolahnya terlebih dahulu. Tetapi ada juga orang yang selalu mau memberikan makanan yang terbaik bagi orang yang dicintainya. Karena, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai makanan kesukaan keluarga. 



Apakah anda adalah seorang penikmat ayam goreng kampung kalasan?. Tahukah kamu, ayam goreng kampung kalasan adalah sajian khas di Nusantara yang sekarang disukai oleh kebanyakan orang di hampir setiap wilayah di Indonesia. Kalian dapat menghidangkan ayam goreng kampung kalasan sendiri di rumahmu dan boleh jadi hidangan favoritmu di akhir pekan.

Kita jangan bingung untuk memakan ayam goreng kampung kalasan, karena ayam goreng kampung kalasan tidak sulit untuk didapatkan dan juga kita pun dapat mengolahnya sendiri di rumah. ayam goreng kampung kalasan bisa dibuat memalui berbagai cara. Kini ada banyak banget resep modern yang menjadikan ayam goreng kampung kalasan semakin enak.

Resep ayam goreng kampung kalasan juga gampang untuk dibikin, lho. Kita tidak perlu ribet-ribet untuk membeli ayam goreng kampung kalasan, tetapi Kamu dapat menyajikan di rumah sendiri. Bagi Anda yang akan menyajikannya, di bawah ini adalah resep untuk membuat ayam goreng kampung kalasan yang lezat yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Goreng Kampung Kalasan:

1. Ambil 2 ekor Ayam Kampung
1. Gunakan 2 liter Air Kelapa
1. Ambil 20 siung bawang merah
1. Siapkan 10 siung bawang putih
1. Gunakan 2 sdm Ketumbar bubuk
1. Siapkan 4 bh kemiri
1. Siapkan  Gula merah (ukuran sesuai selera) diiris tipis
1. Sediakan secukupnya Garam
1. Siapkan secukupnya Penyedap
1. Siapkan 4 lbr Daun salam
1. Siapkan 1 ruas jari Lengkuas




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Kampung Kalasan:

1. Potong ayam ukuran sesuai selera dan bersihkan
<img src="https://img-global.cpcdn.com/steps/8a37b2f495e32e9a/160x128cq70/ayam-goreng-kampung-kalasan-langkah-memasak-1-foto.jpg" alt="Ayam Goreng Kampung Kalasan"><img src="https://img-global.cpcdn.com/steps/747e160a01a8c489/160x128cq70/ayam-goreng-kampung-kalasan-langkah-memasak-1-foto.jpg" alt="Ayam Goreng Kampung Kalasan">1. Haluskan bumbu, kecuali daun salam, lengkuas gula merah, penyedap
1. Siapkan wajan..masukan ayam potong dan balurkan bumbu halus dengan rata..nyalakan api
1. Masukan Air Kelapa, daun salam, lengkuas..aduk hingga rata dan air mendidih
1. Setelah mendidih, masukan gula merah..aduk hingga rata
1. Masukan penyedap, aduk rata..kecilkan api..masak hingga ayam empuk dan air menyusut dan aduk sesekali agar tidak gosong dibawah
1. Koreksi rasa..setelah empuk dan air menyusut.matikan api..angkat
1. Panas minyak goreng diatas wajan, goreng ayam kalasan, masak sebentar saja krn cepat gosong.
1. Sajikan dengan Nasi Panas, Lalapan dan Sambal goreng lebih enak (resep sambal goreng di resep berikutnya)




Wah ternyata cara buat ayam goreng kampung kalasan yang mantab simple ini enteng banget ya! Anda Semua dapat membuatnya. Resep ayam goreng kampung kalasan Sesuai banget buat kita yang baru akan belajar memasak atau juga untuk kamu yang telah hebat memasak.

Tertarik untuk mulai mencoba membikin resep ayam goreng kampung kalasan enak simple ini? Kalau anda ingin, yuk kita segera buruan menyiapkan peralatan dan bahannya, lantas buat deh Resep ayam goreng kampung kalasan yang lezat dan simple ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang anda berfikir lama-lama, yuk kita langsung bikin resep ayam goreng kampung kalasan ini. Pasti kalian tak akan menyesal bikin resep ayam goreng kampung kalasan mantab sederhana ini! Selamat mencoba dengan resep ayam goreng kampung kalasan lezat tidak rumit ini di rumah kalian masing-masing,ya!.

