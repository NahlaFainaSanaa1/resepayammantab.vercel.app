---
description: "Bahan-bahan Sop Ayam Klaten yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Sop Ayam Klaten yang nikmat dan Mudah Dibuat"
slug: 200-bahan-bahan-sop-ayam-klaten-yang-nikmat-dan-mudah-dibuat
date: 2021-02-22T15:58:55.095Z
image: https://img-global.cpcdn.com/recipes/6995dd302691f6db/680x482cq70/sop-ayam-klaten-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6995dd302691f6db/680x482cq70/sop-ayam-klaten-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6995dd302691f6db/680x482cq70/sop-ayam-klaten-foto-resep-utama.jpg
author: Marguerite Barber
ratingvalue: 4.3
reviewcount: 6
recipeingredient:
- "1 ekor ayam pejantan"
- "2 liter air"
- "2 buah wortel"
- "2 batang daun seledri"
- "2 batang daun bawang"
- " Bawang merah goreng"
- "1 buah jeruk nipis"
- " Bumbu Halus"
- "4 siung bawang putih"
- "4 cm jahe"
- "1 sdt merica"
- "1/2 butir pala"
- "Secukupnya garam gula dan kaldu bubuk"
- " Bumbu Lain"
- "2 batang serai"
- "2 cm lengkuas digeprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "2 butir kapulaga"
- "4 cm kayu manis"
- "3 butir cengkeh"
- "1 buah bunga lawang"
recipeinstructions:
- "Cuci bersih ayam dan rebus. Buang air rebusan pertama. Didihkan 2 liter air. Masukkan ayam, rebus hingga empuk (Boleh dipresto selama 20 menit)."
- "Siapkan wajan dan tuangkan minyak goreng. Tumis bumbu halus bersama semua bumbu lain hingga matang."
- "Masukkan tumisan bumbu ke dalam panci. Masak hingga mendidih."
- "Masukkan wortel. Masak hingga matang. Tambahkan garam, gula dan kaldu bubuk. Koreksi rasa."
- "Siapkan mangkuk. Sajikan dengan taburan seledri, daun bawang, bawang merah goreng dan jeruk nipis."
categories:
- Resep
tags:
- sop
- ayam
- klaten

katakunci: sop ayam klaten 
nutrition: 106 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Sop Ayam Klaten](https://img-global.cpcdn.com/recipes/6995dd302691f6db/680x482cq70/sop-ayam-klaten-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan panganan menggugah selera buat keluarga tercinta adalah hal yang memuaskan untuk anda sendiri. Peran seorang istri bukan sekedar mengatur rumah saja, tetapi kamu juga wajib memastikan kebutuhan nutrisi tercukupi dan juga santapan yang disantap orang tercinta wajib mantab.

Di masa  saat ini, anda memang dapat mengorder hidangan jadi meski tidak harus ribet memasaknya terlebih dahulu. Tetapi ada juga lho orang yang selalu mau memberikan yang terbaik bagi orang yang dicintainya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Apakah kamu salah satu penyuka sop ayam klaten?. Asal kamu tahu, sop ayam klaten adalah makanan khas di Indonesia yang sekarang digemari oleh banyak orang dari hampir setiap tempat di Nusantara. Anda dapat membuat sop ayam klaten olahan sendiri di rumahmu dan boleh jadi santapan kegemaranmu di akhir pekanmu.

Anda tidak usah bingung jika kamu ingin mendapatkan sop ayam klaten, sebab sop ayam klaten mudah untuk ditemukan dan kamu pun dapat menghidangkannya sendiri di tempatmu. sop ayam klaten boleh dimasak dengan beragam cara. Kini pun telah banyak banget cara kekinian yang menjadikan sop ayam klaten semakin mantap.

Resep sop ayam klaten juga gampang dibuat, lho. Anda tidak perlu repot-repot untuk membeli sop ayam klaten, karena Kita mampu menghidangkan ditempatmu. Untuk Kita yang akan membuatnya, dibawah ini merupakan resep menyajikan sop ayam klaten yang nikamat yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Sop Ayam Klaten:

1. Ambil 1 ekor ayam pejantan
1. Sediakan 2 liter air
1. Gunakan 2 buah wortel
1. Sediakan 2 batang daun seledri
1. Ambil 2 batang daun bawang
1. Siapkan  Bawang merah goreng
1. Ambil 1 buah jeruk nipis
1. Siapkan  Bumbu Halus:
1. Sediakan 4 siung bawang putih
1. Siapkan 4 cm jahe
1. Sediakan 1 sdt merica
1. Siapkan 1/2 butir pala
1. Gunakan Secukupnya garam, gula dan kaldu bubuk
1. Ambil  Bumbu Lain:
1. Siapkan 2 batang serai
1. Sediakan 2 cm lengkuas, digeprek
1. Siapkan 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Sediakan 2 butir kapulaga
1. Ambil 4 cm kayu manis
1. Gunakan 3 butir cengkeh
1. Ambil 1 buah bunga lawang




<!--inarticleads2-->

##### Langkah-langkah membuat Sop Ayam Klaten:

1. Cuci bersih ayam dan rebus. Buang air rebusan pertama. Didihkan 2 liter air. Masukkan ayam, rebus hingga empuk (Boleh dipresto selama 20 menit).
1. Siapkan wajan dan tuangkan minyak goreng. Tumis bumbu halus bersama semua bumbu lain hingga matang.
1. Masukkan tumisan bumbu ke dalam panci. Masak hingga mendidih.
1. Masukkan wortel. Masak hingga matang. Tambahkan garam, gula dan kaldu bubuk. Koreksi rasa.
1. Siapkan mangkuk. Sajikan dengan taburan seledri, daun bawang, bawang merah goreng dan jeruk nipis.




Ternyata cara membuat sop ayam klaten yang enak sederhana ini gampang sekali ya! Kamu semua dapat mencobanya. Cara Membuat sop ayam klaten Sesuai banget buat anda yang baru akan belajar memasak ataupun juga bagi kalian yang telah ahli memasak.

Apakah kamu ingin mencoba membikin resep sop ayam klaten lezat tidak ribet ini? Kalau kamu tertarik, mending kamu segera buruan siapin peralatan dan bahan-bahannya, kemudian buat deh Resep sop ayam klaten yang lezat dan sederhana ini. Sangat taidak sulit kan. 

Maka, daripada kalian diam saja, hayo kita langsung saja sajikan resep sop ayam klaten ini. Dijamin kamu tiidak akan nyesel bikin resep sop ayam klaten enak tidak rumit ini! Selamat mencoba dengan resep sop ayam klaten mantab tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

