---
description: "Cara membuat Lontong Opor Ayam ala aQyu yang lezat dan Mudah Dibuat"
title: "Cara membuat Lontong Opor Ayam ala aQyu yang lezat dan Mudah Dibuat"
slug: 391-cara-membuat-lontong-opor-ayam-ala-aqyu-yang-lezat-dan-mudah-dibuat
date: 2021-03-05T04:10:58.604Z
image: https://img-global.cpcdn.com/recipes/4d8fe9f69778530c/680x482cq70/lontong-opor-ayam-ala-aqyu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4d8fe9f69778530c/680x482cq70/lontong-opor-ayam-ala-aqyu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4d8fe9f69778530c/680x482cq70/lontong-opor-ayam-ala-aqyu-foto-resep-utama.jpg
author: Millie Sullivan
ratingvalue: 3.9
reviewcount: 13
recipeingredient:
- " lontong"
- "1 1/2 cup beras"
- " tumis buncis balado"
- "5 bh cabe keriting"
- "2 bawang putih"
- "1 bawang merah"
- " kentang mustopacrispy potato"
- "3 buah kentang"
- " opor ayam"
- "1/2 ekor ayam"
- "1/2 sdt ketumbar"
- "1/2 sdt jintan"
- "3 bawang merah"
- "3 bawang putih"
- "4 pcs kemiri"
- "1 cm kunyit"
- " salam sereh jahe lengkuas kayumanis secukupnya yaaa aku stgh ekor ayam jd yaaa seimut mgkn deh"
- "2 pcs santan kara Powder"
- "600-700 ml air kurleb"
- " opt merica bubuk"
- " opt gula merah"
recipeinstructions:
- "1 1/2 cup beras cuci bersih krna ini cuman untuk dua porsi ya bikin nya juga cuman 2. tadinya mau coba pake daun pisang. tp alhamdulillah jadi juga. bikin lontong emang tricky bgt. aku pk plastik, trus sumpelin pake tusuk gigi, biar padat. trus tusukin juga d plastik dan rebus kurleb 30mntan,liat kondisi lontong nyaa"
- "Iris dan cuci buncis, aku bikin cuman sekapal tangan doang ini buncis nya mgkn 100-200gr. (lg lg porsi mini) uleg cabe keriting, bawang putih dan bawang merah. tumis, hingga wangi yesssh. masukin deh buncis, jan lupa di ulekan kan masih sisa bumbu kasih air dikit masukin ketumisan. oiyaaaaaaaa seasoning jan lupa cicip cicip rasa"
- "Kupas kentang, cuci lalu parut. (boleh dideimin dulu trus kasih garam, boleh ga). goreng deh sampe crispy. 3buah kentang jadi 100-200gr keknya."
- "Cuci bersih ayam. aku rebus bentar sampe air mendidih matiin. sampe darahny ilang deh. tiriskan dulu."
- "Bumbu halus : uleg ketumbar, jinten, bawang putih, bawang merah, (oiya tadi aku kemirinya agak disangrai dulu, krna emg ga suka bau kemiri yg di tumis bau langu gt:&#39;() kunyit, peprek deh sereh, lengkuas, jahe nya. daun salam. tumis sampe wangi. masukin air kurleb 300ml dulu, masukin kayu manis dan kapulaga sebiji. diamkan slma 15menitan (klo aku pake api kecil) biar agak meresap k ayam. masukin gula merah aku sedikit bgt sih, 2irisan pisau doang."
- "Sisanya ambil air panas dari dispenser seduh deh 300ml air ke santan Powder nya. (baca petunjuk santan Powder nya) klo aku sih disesuaikan. masukin ke kuahnya. seasoning nya jan lupa pake merica bubuk jg. tgu sampe mendidih. sampe dia pekat. klo santan kental pasti creamy ya, itu disesuaikan selera aja ya moms. ambil ayamnya, saring deh kuahnya. (ga bikin bawang gr, jd di ganti kentang mustopa aja) yuks, makan pake krupuk udangg!!!"
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Lontong Opor Ayam ala aQyu](https://img-global.cpcdn.com/recipes/4d8fe9f69778530c/680x482cq70/lontong-opor-ayam-ala-aqyu-foto-resep-utama.jpg)

Jika kamu seorang ibu, menyediakan masakan lezat pada keluarga merupakan suatu hal yang memuaskan untuk kita sendiri. Peran seorang ibu bukan cuman menangani rumah saja, tetapi anda pun wajib menyediakan kebutuhan gizi terpenuhi dan juga masakan yang dimakan orang tercinta wajib menggugah selera.

Di masa  sekarang, anda memang mampu membeli santapan instan walaupun tanpa harus capek memasaknya lebih dulu. Tapi ada juga lho orang yang memang mau memberikan makanan yang terbaik bagi keluarganya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera orang tercinta. 



Mungkinkah anda merupakan seorang penyuka lontong opor ayam ala aqyu?. Tahukah kamu, lontong opor ayam ala aqyu merupakan sajian khas di Nusantara yang kini disenangi oleh banyak orang di berbagai daerah di Nusantara. Kita bisa memasak lontong opor ayam ala aqyu sendiri di rumah dan pasti jadi makanan favorit di hari liburmu.

Anda tidak usah bingung jika kamu ingin mendapatkan lontong opor ayam ala aqyu, sebab lontong opor ayam ala aqyu tidak sulit untuk didapatkan dan anda pun bisa menghidangkannya sendiri di tempatmu. lontong opor ayam ala aqyu boleh diolah lewat bermacam cara. Saat ini sudah banyak banget resep kekinian yang menjadikan lontong opor ayam ala aqyu semakin lebih enak.

Resep lontong opor ayam ala aqyu pun gampang sekali untuk dibikin, lho. Kalian tidak usah ribet-ribet untuk membeli lontong opor ayam ala aqyu, lantaran Kita dapat membuatnya di rumahmu. Untuk Kalian yang mau menyajikannya, dibawah ini merupakan resep menyajikan lontong opor ayam ala aqyu yang mantab yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Lontong Opor Ayam ala aQyu:

1. Siapkan  lontong
1. Gunakan 1 1/2 cup beras
1. Siapkan  tumis buncis balado
1. Ambil 5 bh cabe keriting
1. Gunakan 2 bawang putih
1. Ambil 1 bawang merah
1. Sediakan  kentang mustopa/crispy potato
1. Sediakan 3 buah kentang
1. Siapkan  opor ayam
1. Gunakan 1/2 ekor ayam
1. Ambil 1/2 sdt ketumbar
1. Sediakan 1/2 sdt jintan
1. Gunakan 3 bawang merah
1. Gunakan 3 bawang putih
1. Siapkan 4 pcs kemiri
1. Ambil 1 cm kunyit
1. Sediakan  salam, sereh, jahe, lengkuas, kayumanis, (secukupnya yaaa aku stgh ekor ayam jd yaaa seimut mgkn deh)
1. Sediakan 2 pcs santan kara Powder
1. Ambil 600-700 ml air kurleb
1. Siapkan  opt. merica bubuk
1. Gunakan  opt. gula merah




<!--inarticleads2-->

##### Cara membuat Lontong Opor Ayam ala aQyu:

1. 1 1/2 cup beras cuci bersih krna ini cuman untuk dua porsi ya bikin nya juga cuman 2. tadinya mau coba pake daun pisang. tp alhamdulillah jadi juga. bikin lontong emang tricky bgt. aku pk plastik, trus sumpelin pake tusuk gigi, biar padat. trus tusukin juga d plastik dan rebus kurleb 30mntan,liat kondisi lontong nyaa
1. Iris dan cuci buncis, aku bikin cuman sekapal tangan doang ini buncis nya mgkn 100-200gr. (lg lg porsi mini) uleg cabe keriting, bawang putih dan bawang merah. tumis, hingga wangi yesssh. masukin deh buncis, jan lupa di ulekan kan masih sisa bumbu kasih air dikit masukin ketumisan. oiyaaaaaaaa seasoning jan lupa cicip cicip rasa
1. Kupas kentang, cuci lalu parut. (boleh dideimin dulu trus kasih garam, boleh ga). goreng deh sampe crispy. 3buah kentang jadi 100-200gr keknya.
1. Cuci bersih ayam. aku rebus bentar sampe air mendidih matiin. sampe darahny ilang deh. tiriskan dulu.
1. Bumbu halus : uleg ketumbar, jinten, bawang putih, bawang merah, (oiya tadi aku kemirinya agak disangrai dulu, krna emg ga suka bau kemiri yg di tumis bau langu gt:&#39;() kunyit, peprek deh sereh, lengkuas, jahe nya. daun salam. tumis sampe wangi. masukin air kurleb 300ml dulu, masukin kayu manis dan kapulaga sebiji. diamkan slma 15menitan (klo aku pake api kecil) biar agak meresap k ayam. masukin gula merah aku sedikit bgt sih, 2irisan pisau doang.
1. Sisanya ambil air panas dari dispenser seduh deh 300ml air ke santan Powder nya. (baca petunjuk santan Powder nya) klo aku sih disesuaikan. masukin ke kuahnya. seasoning nya jan lupa pake merica bubuk jg. tgu sampe mendidih. sampe dia pekat. klo santan kental pasti creamy ya, itu disesuaikan selera aja ya moms. ambil ayamnya, saring deh kuahnya. (ga bikin bawang gr, jd di ganti kentang mustopa aja) yuks, makan pake krupuk udangg!!!




Wah ternyata cara buat lontong opor ayam ala aqyu yang enak tidak rumit ini gampang sekali ya! Semua orang bisa membuatnya. Resep lontong opor ayam ala aqyu Sesuai sekali buat kamu yang baru akan belajar memasak maupun juga untuk kalian yang sudah hebat memasak.

Apakah kamu mau mencoba buat resep lontong opor ayam ala aqyu mantab sederhana ini? Kalau kamu tertarik, yuk kita segera siapin alat-alat dan bahan-bahannya, lantas bikin deh Resep lontong opor ayam ala aqyu yang enak dan tidak ribet ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kalian berfikir lama-lama, yuk kita langsung saja buat resep lontong opor ayam ala aqyu ini. Pasti kamu tak akan menyesal sudah bikin resep lontong opor ayam ala aqyu nikmat tidak ribet ini! Selamat mencoba dengan resep lontong opor ayam ala aqyu lezat tidak rumit ini di tempat tinggal masing-masing,oke!.

