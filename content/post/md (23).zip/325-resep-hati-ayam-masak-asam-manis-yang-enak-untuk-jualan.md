---
description: "Resep Hati Ayam Masak Asam Manis yang enak Untuk Jualan"
title: "Resep Hati Ayam Masak Asam Manis yang enak Untuk Jualan"
slug: 325-resep-hati-ayam-masak-asam-manis-yang-enak-untuk-jualan
date: 2021-01-09T20:40:43.136Z
image: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
author: Mattie Frank
ratingvalue: 4.1
reviewcount: 6
recipeingredient:
- "3 bh Hati Ayam Kampung"
- "5 siung Bawang merah"
- "4 siung Bawang putih"
- "1 bh Bawang merah besar"
- "4 bh Cabe Hijau besar"
- "1 bh Tomat"
- "2 papan petai kupas"
- "1 bks Terasi larutkan dengan air"
- "1 sdm Gula merah serut"
- " Garam"
- " Gula pasir"
- " Penyedap rasa"
recipeinstructions:
- "Bersihkan hati ayam, potong persegi kecil. Beri perasan air jeruk nipis dan garam. Diamkan sebentar. Cuci bersih."
- "Rebus hati ayam sebentar, tiriskan. Sisihkan."
- "Siapkan bahan-bahan lainnya, iris bawang, cabe merah, cabe hijau, tomat, petai."
- "Tumis bumbu iris sampai harum dan layu"
- "Masukkan hati ayam, aduk rata. Tumis sebentar. Masukkan air terasi."
- "Masukkan petai dan Tambahkan sedikit air, beri garam, gula pasir, gula merah, dan penyedap. Aduk rata."
- "Masak sampai kuah menyusut dan hati matang, cek rasa, bila sudah pas, angkat. Sajikan."
categories:
- Resep
tags:
- hati
- ayam
- masak

katakunci: hati ayam masak 
nutrition: 107 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Dinner

---


![Hati Ayam Masak Asam Manis](https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg)

Jika kalian seorang orang tua, menyajikan olahan nikmat pada famili merupakan hal yang menggembirakan bagi kita sendiri. Tanggung jawab seorang istri Tidak sekedar mengatur rumah saja, namun anda pun harus menyediakan kebutuhan nutrisi tercukupi dan masakan yang dimakan anak-anak mesti enak.

Di masa  saat ini, kalian memang bisa membeli santapan praktis meski tanpa harus repot mengolahnya dulu. Tapi ada juga lho orang yang selalu mau memberikan yang terlezat untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan keluarga. 



Mungkinkah anda merupakan seorang penikmat hati ayam masak asam manis?. Asal kamu tahu, hati ayam masak asam manis merupakan sajian khas di Indonesia yang sekarang disukai oleh setiap orang di berbagai tempat di Indonesia. Kamu bisa menghidangkan hati ayam masak asam manis sendiri di rumah dan boleh dijadikan makanan kegemaranmu di hari liburmu.

Kalian tak perlu bingung jika kamu ingin mendapatkan hati ayam masak asam manis, karena hati ayam masak asam manis mudah untuk dicari dan juga kamu pun bisa mengolahnya sendiri di rumah. hati ayam masak asam manis boleh dibuat dengan beraneka cara. Sekarang sudah banyak banget resep kekinian yang membuat hati ayam masak asam manis semakin lebih enak.

Resep hati ayam masak asam manis pun sangat mudah untuk dibikin, lho. Anda jangan ribet-ribet untuk membeli hati ayam masak asam manis, sebab Kamu bisa menyajikan di rumahmu. Untuk Kita yang mau mencobanya, dibawah ini merupakan resep menyajikan hati ayam masak asam manis yang nikamat yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Hati Ayam Masak Asam Manis:

1. Siapkan 3 bh Hati Ayam Kampung
1. Gunakan 5 siung Bawang merah
1. Gunakan 4 siung Bawang putih
1. Gunakan 1 bh Bawang merah besar
1. Siapkan 4 bh Cabe Hijau besar
1. Ambil 1 bh Tomat
1. Siapkan 2 papan petai, kupas
1. Siapkan 1 bks Terasi, larutkan dengan air
1. Siapkan 1 sdm Gula merah, serut
1. Sediakan  Garam
1. Siapkan  Gula pasir
1. Siapkan  Penyedap rasa




<!--inarticleads2-->

##### Cara membuat Hati Ayam Masak Asam Manis:

1. Bersihkan hati ayam, potong persegi kecil. Beri perasan air jeruk nipis dan garam. Diamkan sebentar. Cuci bersih.
1. Rebus hati ayam sebentar, tiriskan. Sisihkan.
1. Siapkan bahan-bahan lainnya, iris bawang, cabe merah, cabe hijau, tomat, petai.
1. Tumis bumbu iris sampai harum dan layu
1. Masukkan hati ayam, aduk rata. Tumis sebentar. Masukkan air terasi.
1. Masukkan petai dan Tambahkan sedikit air, beri garam, gula pasir, gula merah, dan penyedap. Aduk rata.
1. Masak sampai kuah menyusut dan hati matang, cek rasa, bila sudah pas, angkat. Sajikan.




Wah ternyata cara buat hati ayam masak asam manis yang mantab sederhana ini enteng sekali ya! Kalian semua mampu memasaknya. Resep hati ayam masak asam manis Sangat cocok banget buat anda yang sedang belajar memasak maupun bagi anda yang telah hebat memasak.

Tertarik untuk mulai mencoba bikin resep hati ayam masak asam manis enak sederhana ini? Kalau kalian tertarik, ayo kamu segera menyiapkan peralatan dan bahan-bahannya, lantas buat deh Resep hati ayam masak asam manis yang lezat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kalian diam saja, ayo kita langsung bikin resep hati ayam masak asam manis ini. Dijamin kalian gak akan nyesel sudah membuat resep hati ayam masak asam manis nikmat simple ini! Selamat berkreasi dengan resep hati ayam masak asam manis enak tidak ribet ini di tempat tinggal sendiri,oke!.

