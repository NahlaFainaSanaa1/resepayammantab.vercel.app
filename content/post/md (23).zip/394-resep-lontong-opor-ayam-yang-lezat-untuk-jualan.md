---
description: "Resep Lontong Opor Ayam yang lezat Untuk Jualan"
title: "Resep Lontong Opor Ayam yang lezat Untuk Jualan"
slug: 394-resep-lontong-opor-ayam-yang-lezat-untuk-jualan
date: 2021-05-03T06:24:37.673Z
image: https://img-global.cpcdn.com/recipes/b8d01768f013f25f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b8d01768f013f25f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b8d01768f013f25f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
author: Lois Castillo
ratingvalue: 4.8
reviewcount: 9
recipeingredient:
- " Bahan Opor Ayam"
- "1 ekor ayam ukuran 1 kg"
- "8 butir telur ayam"
- "100 ml santan kental pasta santan"
- " Bumbu Opor ayam"
- "1 bungkus bumbu opor ayam putih dari bamboo"
- "3 butir kemiri"
- "1/2 buah bawang bombai merah"
- "3 butir bawang putih"
- "1 batang serai"
- "2 cm lengkuas"
- "4 lembar daun salam"
- "4 lembar daun jeruk buang tulang daunnya"
- "1 sdt ketumbar bubuk"
- "1/2 sdt kunyit bubuk"
- " Lontong Nasi"
- "8 cup beras"
- " Pelengkap"
- " Sambal teri"
- " Teri goreng dan kacang tanah goreng untuk anakanak"
- " Bawang merah goreng"
- " Kerupuk Udang"
recipeinstructions:
- "Cara membuat opor: -Haluskan bawang putih, bombai merah, dan kemiri lalu tumis dengan bumbu lainnya sampai harum."
- "Masukkan ayam yang sudah di potong menjadi 16 bagian, tumis dengan bumbu."
- "Dipanci lain didihkan air 1,5 liter. Setelah mendidih masukkan ayam berbumbu tadi, dan tambahkan santan aduk jangan sampai pecah santannya."
- "Masukkan telur rebus yang sudah di kupas masak sebentar saja asal mendidih lagi. Opor siap dinikmati."
- "Lontong: Cuci beras kemudian tiriskan. Masukkan beras kedalam plastik. Karena berasnya ga mekar jadi saya isi 1/2 lebih dikit. Kalau berasnya mekar di isi 1/2 sudah cukup. Masukkan kebanci dengam cara disusun berjejer lalu isi dengan air sampai terendam. Masak di api sedang sampai mendidih setelah mendidih kecilkan api sampai 4 jam. Saya merebusnya pakai pemenas ruangan karena sekalian menghabiskan sisa minyak tanah🤭."
- "Setelah lontong matang angkat dan tiriskan, ikatkan dengam kuat bagian kosong dengam cara diputar-putar agar lontong padat. Tata dengan posisi terbalik. Tunggu sampai dingin agar lontong menjadi padat. Setelah padat iris sesuai selera. Si lontong jadi padet dan lembut."
- "Penyajian: Tata lontong dibagian bawah piring, Beri bawang merah goreng tuang, ayam dan telur lalu tuang kuah opor. Tambahkan sambal teri dan kerupuk di atasnya. Nikmat😋😋."
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 154 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch

---


![Lontong Opor Ayam](https://img-global.cpcdn.com/recipes/b8d01768f013f25f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyajikan panganan sedap untuk keluarga adalah hal yang mengasyikan bagi kamu sendiri. Tugas seorang istri Tidak hanya menangani rumah saja, tetapi kamu pun harus memastikan kebutuhan gizi terpenuhi dan juga hidangan yang dimakan anak-anak mesti lezat.

Di masa  sekarang, kamu memang dapat memesan olahan jadi walaupun tanpa harus repot membuatnya dulu. Tapi ada juga mereka yang selalu mau menghidangkan yang terbaik untuk orang tercintanya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan masakan kesukaan keluarga. 



Apakah anda merupakan seorang penggemar lontong opor ayam?. Asal kamu tahu, lontong opor ayam merupakan makanan khas di Indonesia yang kini disenangi oleh banyak orang dari berbagai tempat di Indonesia. Kalian bisa memasak lontong opor ayam sendiri di rumahmu dan pasti jadi camilan kesukaanmu di hari libur.

Kamu tidak perlu bingung untuk memakan lontong opor ayam, sebab lontong opor ayam tidak sulit untuk ditemukan dan juga kita pun boleh menghidangkannya sendiri di tempatmu. lontong opor ayam bisa dimasak dengan bermacam cara. Saat ini telah banyak sekali cara modern yang menjadikan lontong opor ayam lebih mantap.

Resep lontong opor ayam juga mudah dihidangkan, lho. Kalian tidak usah ribet-ribet untuk membeli lontong opor ayam, sebab Kamu bisa menghidangkan sendiri di rumah. Untuk Kamu yang hendak menghidangkannya, berikut resep untuk membuat lontong opor ayam yang mantab yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Lontong Opor Ayam:

1. Siapkan  Bahan Opor Ayam
1. Gunakan 1 ekor ayam ukuran 1 kg
1. Gunakan 8 butir telur ayam
1. Gunakan 100 ml santan kental (pasta santan)
1. Sediakan  Bumbu Opor ayam
1. Ambil 1 bungkus bumbu opor ayam putih dari bamboo
1. Gunakan 3 butir kemiri
1. Siapkan 1/2 buah bawang bombai merah
1. Gunakan 3 butir bawang putih
1. Siapkan 1 batang serai
1. Ambil 2 cm lengkuas
1. Ambil 4 lembar daun salam
1. Gunakan 4 lembar daun jeruk buang tulang daunnya
1. Ambil 1 sdt ketumbar bubuk
1. Ambil 1/2 sdt kunyit bubuk
1. Gunakan  Lontong Nasi
1. Siapkan 8 cup beras
1. Siapkan  Pelengkap:
1. Sediakan  Sambal teri
1. Ambil  Teri goreng dan kacang tanah goreng untuk anak-anak
1. Ambil  Bawang merah goreng
1. Gunakan  Kerupuk Udang




<!--inarticleads2-->

##### Cara membuat Lontong Opor Ayam:

1. Cara membuat opor: -Haluskan bawang putih, bombai merah, dan kemiri lalu tumis dengan bumbu lainnya sampai harum.
1. Masukkan ayam yang sudah di potong menjadi 16 bagian, tumis dengan bumbu.
1. Dipanci lain didihkan air 1,5 liter. Setelah mendidih masukkan ayam berbumbu tadi, dan tambahkan santan aduk jangan sampai pecah santannya.
1. Masukkan telur rebus yang sudah di kupas masak sebentar saja asal mendidih lagi. Opor siap dinikmati.
1. Lontong: Cuci beras kemudian tiriskan. Masukkan beras kedalam plastik. Karena berasnya ga mekar jadi saya isi 1/2 lebih dikit. Kalau berasnya mekar di isi 1/2 sudah cukup. Masukkan kebanci dengam cara disusun berjejer lalu isi dengan air sampai terendam. Masak di api sedang sampai mendidih setelah mendidih kecilkan api sampai 4 jam. Saya merebusnya pakai pemenas ruangan karena sekalian menghabiskan sisa minyak tanah🤭.
1. Setelah lontong matang angkat dan tiriskan, ikatkan dengam kuat bagian kosong dengam cara diputar-putar agar lontong padat. Tata dengan posisi terbalik. Tunggu sampai dingin agar lontong menjadi padat. Setelah padat iris sesuai selera. Si lontong jadi padet dan lembut.
1. Penyajian: Tata lontong dibagian bawah piring, Beri bawang merah goreng tuang, ayam dan telur lalu tuang kuah opor. Tambahkan sambal teri dan kerupuk di atasnya. Nikmat😋😋.




Ternyata cara membuat lontong opor ayam yang mantab simple ini gampang banget ya! Kita semua mampu mencobanya. Cara Membuat lontong opor ayam Sangat cocok banget untuk kamu yang sedang belajar memasak ataupun juga untuk kamu yang sudah pandai dalam memasak.

Apakah kamu tertarik mencoba buat resep lontong opor ayam mantab tidak ribet ini? Kalau kalian mau, ayo kalian segera siapkan alat dan bahan-bahannya, lalu buat deh Resep lontong opor ayam yang nikmat dan tidak rumit ini. Sangat mudah kan. 

Oleh karena itu, ketimbang kalian berlama-lama, ayo kita langsung sajikan resep lontong opor ayam ini. Pasti kamu tiidak akan menyesal membuat resep lontong opor ayam mantab sederhana ini! Selamat mencoba dengan resep lontong opor ayam enak sederhana ini di rumah sendiri,oke!.

