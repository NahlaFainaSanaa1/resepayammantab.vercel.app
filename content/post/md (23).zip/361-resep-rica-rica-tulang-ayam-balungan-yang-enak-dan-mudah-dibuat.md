---
description: "Resep Rica-rica Tulang Ayam (Balungan) yang enak dan Mudah Dibuat"
title: "Resep Rica-rica Tulang Ayam (Balungan) yang enak dan Mudah Dibuat"
slug: 361-resep-rica-rica-tulang-ayam-balungan-yang-enak-dan-mudah-dibuat
date: 2021-06-17T19:59:55.984Z
image: https://img-global.cpcdn.com/recipes/78fb5b89d1c56b47/680x482cq70/rica-rica-tulang-ayam-balungan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/78fb5b89d1c56b47/680x482cq70/rica-rica-tulang-ayam-balungan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/78fb5b89d1c56b47/680x482cq70/rica-rica-tulang-ayam-balungan-foto-resep-utama.jpg
author: Mabel Hunt
ratingvalue: 4.7
reviewcount: 10
recipeingredient:
- "400 gr balungan tulang ayam"
- "500 ml air"
- "40 gr gula merah"
- "2 sdm kecap manis boleh skip atau dikurangi ya"
- "1 sdm gula pasir"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 buah cabe merah besar"
- "7 buah cabe rawit"
- "2 btr kemiri"
- "2 cm kunyit"
- "1 sdm garam"
- "1 sdt ketumbar bubuk"
- "1 sdt lada bubuk"
- "1 sdt kaldu bubuk"
- " Bumbu Cemplung"
- "5 cm lengkuas"
- "2 cm jahe geprek"
- "1 btng sereh"
- "2 lbr daun jeruk"
- "1 lbr daun salam"
recipeinstructions:
- "Siapkan semua bahan. Campurkan bahan bumbu halus, haluskan bisa pakai ulekan manual atau chopper."
- "Tumis bumbu halus dan bumbu cemplung hingga harum. Masukkan tulang aduk rata, tumis sebentar."
- "Tambahkan air, kecap, gula pasir dan gula merah. Aduk rata, masak hingga matang, bumbu meresap, dan air menyusut. Koreksi rasa."
- "Rica-rica tulang/ balungan siap disajikan. Selamat mencoba dan semoga bermanfaat."
categories:
- Resep
tags:
- ricarica
- tulang
- ayam

katakunci: ricarica tulang ayam 
nutrition: 187 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dinner

---


![Rica-rica Tulang Ayam (Balungan)](https://img-global.cpcdn.com/recipes/78fb5b89d1c56b47/680x482cq70/rica-rica-tulang-ayam-balungan-foto-resep-utama.jpg)

Apabila kita seorang yang hobi masak, menyuguhkan hidangan lezat kepada famili merupakan hal yang membahagiakan bagi kita sendiri. Kewajiban seorang ibu Tidak hanya menjaga rumah saja, namun kamu pun harus menyediakan keperluan nutrisi terpenuhi dan juga hidangan yang disantap anak-anak harus lezat.

Di era  saat ini, kita memang bisa memesan masakan instan walaupun tidak harus capek membuatnya dulu. Tapi ada juga orang yang memang mau memberikan yang terlezat untuk keluarganya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai selera orang tercinta. 



Apakah anda salah satu penyuka rica-rica tulang ayam (balungan)?. Tahukah kamu, rica-rica tulang ayam (balungan) merupakan sajian khas di Indonesia yang saat ini disukai oleh kebanyakan orang dari berbagai tempat di Indonesia. Kalian bisa memasak rica-rica tulang ayam (balungan) hasil sendiri di rumah dan boleh dijadikan makanan favorit di hari liburmu.

Anda tidak perlu bingung jika kamu ingin menyantap rica-rica tulang ayam (balungan), sebab rica-rica tulang ayam (balungan) tidak sukar untuk didapatkan dan kita pun boleh membuatnya sendiri di tempatmu. rica-rica tulang ayam (balungan) bisa diolah dengan bermacam cara. Kini ada banyak banget cara modern yang membuat rica-rica tulang ayam (balungan) lebih nikmat.

Resep rica-rica tulang ayam (balungan) juga sangat gampang dihidangkan, lho. Kamu tidak perlu capek-capek untuk memesan rica-rica tulang ayam (balungan), karena Kalian mampu membuatnya sendiri di rumah. Untuk Kita yang mau menghidangkannya, dibawah ini merupakan cara membuat rica-rica tulang ayam (balungan) yang enak yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Rica-rica Tulang Ayam (Balungan):

1. Gunakan 400 gr balungan/ tulang ayam
1. Siapkan 500 ml air
1. Sediakan 40 gr gula merah
1. Ambil 2 sdm kecap manis (boleh skip atau dikurangi ya)
1. Sediakan 1 sdm gula pasir
1. Ambil  Bumbu halus:
1. Gunakan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Ambil 2 buah cabe merah besar
1. Ambil 7 buah cabe rawit
1. Sediakan 2 btr kemiri
1. Gunakan 2 cm kunyit
1. Sediakan 1 sdm garam
1. Siapkan 1 sdt ketumbar bubuk
1. Siapkan 1 sdt lada bubuk
1. Sediakan 1 sdt kaldu bubuk
1. Siapkan  Bumbu Cemplung:
1. Gunakan 5 cm lengkuas
1. Gunakan 2 cm jahe geprek
1. Sediakan 1 btng sereh
1. Gunakan 2 lbr daun jeruk
1. Sediakan 1 lbr daun salam




<!--inarticleads2-->

##### Langkah-langkah membuat Rica-rica Tulang Ayam (Balungan):

1. Siapkan semua bahan. Campurkan bahan bumbu halus, haluskan bisa pakai ulekan manual atau chopper.
1. Tumis bumbu halus dan bumbu cemplung hingga harum. Masukkan tulang aduk rata, tumis sebentar.
1. Tambahkan air, kecap, gula pasir dan gula merah. Aduk rata, masak hingga matang, bumbu meresap, dan air menyusut. Koreksi rasa.
1. Rica-rica tulang/ balungan siap disajikan. Selamat mencoba dan semoga bermanfaat.




Wah ternyata cara membuat rica-rica tulang ayam (balungan) yang mantab tidak ribet ini mudah sekali ya! Kamu semua mampu memasaknya. Cara buat rica-rica tulang ayam (balungan) Sangat cocok sekali buat kamu yang baru akan belajar memasak maupun untuk anda yang sudah hebat dalam memasak.

Apakah kamu tertarik mencoba bikin resep rica-rica tulang ayam (balungan) lezat sederhana ini? Kalau anda mau, yuk kita segera buruan menyiapkan alat dan bahannya, setelah itu buat deh Resep rica-rica tulang ayam (balungan) yang lezat dan sederhana ini. Betul-betul taidak sulit kan. 

Oleh karena itu, daripada anda berfikir lama-lama, hayo langsung aja bikin resep rica-rica tulang ayam (balungan) ini. Dijamin kamu tak akan menyesal sudah buat resep rica-rica tulang ayam (balungan) nikmat tidak ribet ini! Selamat berkreasi dengan resep rica-rica tulang ayam (balungan) lezat tidak rumit ini di rumah masing-masing,oke!.

