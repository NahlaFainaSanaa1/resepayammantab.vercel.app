---
description: "Cara membuat Sempol ayam wortel tanpa tusuk yang nikmat dan Mudah Dibuat"
title: "Cara membuat Sempol ayam wortel tanpa tusuk yang nikmat dan Mudah Dibuat"
slug: 166-cara-membuat-sempol-ayam-wortel-tanpa-tusuk-yang-nikmat-dan-mudah-dibuat
date: 2021-03-11T13:34:52.130Z
image: https://img-global.cpcdn.com/recipes/a9de8dff4beb4890/680x482cq70/sempol-ayam-wortel-tanpa-tusuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a9de8dff4beb4890/680x482cq70/sempol-ayam-wortel-tanpa-tusuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a9de8dff4beb4890/680x482cq70/sempol-ayam-wortel-tanpa-tusuk-foto-resep-utama.jpg
author: Adeline Gonzalez
ratingvalue: 3.2
reviewcount: 8
recipeingredient:
- "150 gram ayam giling"
- "500 gram tepung tapioka"
- "10 sendok makan tepung terigu"
- "2 wortel besar"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "2 batang daun bawang iris tipis"
- "2 sdm bawang putih bubuk"
- "1 sdt merica bubuk"
- "2,5 sdm garam"
- "Sejumput gula"
recipeinstructions:
- "Parut wortel, bawang merah dan bawang putih."
- "Campur semua bahan, tambahkan air sedikit demi sedikit sambil diuleni. Jangan terlalu lembek, asal bisa dibentuk saja (aq kurang lebih 200ml)"
- "Bentuk bulat bulat lalu panjangkan"
- "Masukkan pada air mendidih, biarkan sampai mengambang (tunggu beberapa saat baru diangkat). Tiriskan"
- "Lakukan sampai adonan habis. Bisa langsung digoreng atau disimpan beku."
- "Jika akan digoreng, masukkan dulu ke dalam telur yg telah diaduk, goreng sampai kecoklatan"
categories:
- Resep
tags:
- sempol
- ayam
- wortel

katakunci: sempol ayam wortel 
nutrition: 121 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dessert

---


![Sempol ayam wortel tanpa tusuk](https://img-global.cpcdn.com/recipes/a9de8dff4beb4890/680x482cq70/sempol-ayam-wortel-tanpa-tusuk-foto-resep-utama.jpg)

Selaku seorang wanita, menyajikan olahan enak pada orang tercinta adalah hal yang sangat menyenangkan untuk kamu sendiri. Kewajiban seorang ibu bukan sekedar mengatur rumah saja, tapi anda juga harus memastikan kebutuhan gizi tercukupi dan hidangan yang disantap anak-anak mesti enak.

Di era  saat ini, kalian memang dapat mengorder hidangan instan meski tidak harus repot memasaknya terlebih dahulu. Tetapi banyak juga lho mereka yang selalu ingin menyajikan yang terlezat untuk orang yang dicintainya. Lantaran, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan selera orang tercinta. 



Apakah anda adalah salah satu penikmat sempol ayam wortel tanpa tusuk?. Asal kamu tahu, sempol ayam wortel tanpa tusuk merupakan makanan khas di Nusantara yang saat ini disukai oleh banyak orang di hampir setiap tempat di Nusantara. Kita dapat membuat sempol ayam wortel tanpa tusuk sendiri di rumah dan boleh dijadikan makanan kegemaranmu di akhir pekanmu.

Kamu jangan bingung jika kamu ingin menyantap sempol ayam wortel tanpa tusuk, sebab sempol ayam wortel tanpa tusuk gampang untuk dicari dan anda pun dapat membuatnya sendiri di rumah. sempol ayam wortel tanpa tusuk boleh dimasak lewat bermacam cara. Kini pun sudah banyak banget resep modern yang menjadikan sempol ayam wortel tanpa tusuk semakin lebih lezat.

Resep sempol ayam wortel tanpa tusuk juga mudah sekali dibikin, lho. Anda jangan capek-capek untuk membeli sempol ayam wortel tanpa tusuk, karena Kalian bisa membuatnya di rumah sendiri. Bagi Anda yang akan menghidangkannya, inilah resep menyajikan sempol ayam wortel tanpa tusuk yang mantab yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Sempol ayam wortel tanpa tusuk:

1. Sediakan 150 gram ayam giling
1. Ambil 500 gram tepung tapioka
1. Gunakan 10 sendok makan tepung terigu
1. Gunakan 2 wortel besar
1. Ambil 5 siung bawang merah
1. Ambil 5 siung bawang putih
1. Ambil 2 batang daun bawang iris tipis
1. Ambil 2 sdm bawang putih bubuk
1. Siapkan 1 sdt merica bubuk
1. Sediakan 2,5 sdm garam
1. Siapkan Sejumput gula




<!--inarticleads2-->

##### Cara menyiapkan Sempol ayam wortel tanpa tusuk:

1. Parut wortel, bawang merah dan bawang putih.
1. Campur semua bahan, tambahkan air sedikit demi sedikit sambil diuleni. Jangan terlalu lembek, asal bisa dibentuk saja (aq kurang lebih 200ml)
1. Bentuk bulat bulat lalu panjangkan
1. Masukkan pada air mendidih, biarkan sampai mengambang (tunggu beberapa saat baru diangkat). Tiriskan
1. Lakukan sampai adonan habis. Bisa langsung digoreng atau disimpan beku.
1. Jika akan digoreng, masukkan dulu ke dalam telur yg telah diaduk, goreng sampai kecoklatan




Ternyata cara buat sempol ayam wortel tanpa tusuk yang mantab tidak rumit ini enteng banget ya! Kalian semua mampu menghidangkannya. Resep sempol ayam wortel tanpa tusuk Cocok banget untuk kamu yang baru akan belajar memasak ataupun untuk kalian yang sudah lihai dalam memasak.

Tertarik untuk mulai mencoba buat resep sempol ayam wortel tanpa tusuk mantab simple ini? Kalau anda tertarik, mending kamu segera buruan siapkan peralatan dan bahannya, kemudian bikin deh Resep sempol ayam wortel tanpa tusuk yang enak dan simple ini. Sungguh taidak sulit kan. 

Jadi, daripada anda diam saja, ayo kita langsung saja buat resep sempol ayam wortel tanpa tusuk ini. Dijamin kalian gak akan menyesal bikin resep sempol ayam wortel tanpa tusuk enak sederhana ini! Selamat berkreasi dengan resep sempol ayam wortel tanpa tusuk mantab tidak ribet ini di tempat tinggal sendiri,oke!.

