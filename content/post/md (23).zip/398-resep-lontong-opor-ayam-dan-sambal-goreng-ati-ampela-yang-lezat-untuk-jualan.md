---
description: "Resep Lontong Opor Ayam dan Sambal Goreng Ati Ampela yang lezat Untuk Jualan"
title: "Resep Lontong Opor Ayam dan Sambal Goreng Ati Ampela yang lezat Untuk Jualan"
slug: 398-resep-lontong-opor-ayam-dan-sambal-goreng-ati-ampela-yang-lezat-untuk-jualan
date: 2021-02-20T22:04:44.490Z
image: https://img-global.cpcdn.com/recipes/896180bc7c86fc47/680x482cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/896180bc7c86fc47/680x482cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/896180bc7c86fc47/680x482cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-foto-resep-utama.jpg
author: Samuel Barrett
ratingvalue: 3.5
reviewcount: 9
recipeingredient:
- "500 gr beras"
- "1 lbr daun pandan"
- "10 pcs cetakan lontong"
- "10 lbr daun pisangpotong sesuai cetakan"
- "3-4 ltr air"
- " Pelengkap Resep Opor Ayam            lihat resep"
- "2 bh santan instan tambahkan pada Opor"
- " Pelengkap Resep Sambal Goreng Ati Ampela Kentang Tahu           lihat resep"
recipeinstructions:
- "Cuci bersih beras. Rendam beras sebentar."
- "Bentuk pola pada daun mengikuti cetakan. Terdiri dari pola persegi panjang (untuk badan) dan pola lingkaran (untuk tutup). Kemudian masukkan daun pada cetakan. Masukkan beras sekitar 3/4 cetakan (untuk beras biasa/pulen) dan 1/2 cetakan (untuk beras pera)."
- "Panaskan air dalam pressure cooker, masukkan cetakan lontong berisi beras tadi hingga terendam semua. Lalu tutup rapat, dan lanjutkan memasak lontong hingga 30 menit. Matikan api, biarkan hingga pressure cooker tidak mengeluarkan uap lagi. Baru tutup dibuka dan keluarkan lontong dari dalam panci."
- "Setelah agak hangat, keluarkan lontong dari cetakan. Lontong siap dinikmati dengan sayur kesukaan."
- "Sajikan lontong bersama Opor Ayam (yang sudah ditambahkan santan kali ini).           (lihat resep)"
- "Tambahkan sambal goreng ati ampela kentang tahu.           (lihat resep)"
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 246 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Lontong Opor Ayam dan Sambal Goreng Ati Ampela](https://img-global.cpcdn.com/recipes/896180bc7c86fc47/680x482cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan santapan sedap untuk famili merupakan hal yang menyenangkan bagi kamu sendiri. Tanggung jawab seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, tetapi kamu pun wajib memastikan keperluan nutrisi terpenuhi dan juga masakan yang disantap keluarga tercinta mesti menggugah selera.

Di masa  sekarang, kita memang bisa membeli olahan jadi meski tidak harus ribet mengolahnya dahulu. Tapi ada juga mereka yang memang ingin memberikan yang terenak bagi keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera keluarga. 



Mungkinkah anda salah satu penyuka lontong opor ayam dan sambal goreng ati ampela?. Tahukah kamu, lontong opor ayam dan sambal goreng ati ampela merupakan hidangan khas di Indonesia yang sekarang digemari oleh orang-orang dari hampir setiap tempat di Indonesia. Kita bisa membuat lontong opor ayam dan sambal goreng ati ampela olahan sendiri di rumahmu dan dapat dijadikan hidangan kegemaranmu di akhir pekan.

Anda tidak perlu bingung untuk menyantap lontong opor ayam dan sambal goreng ati ampela, lantaran lontong opor ayam dan sambal goreng ati ampela gampang untuk didapatkan dan juga kamu pun bisa mengolahnya sendiri di rumah. lontong opor ayam dan sambal goreng ati ampela dapat dibuat memalui beraneka cara. Saat ini telah banyak banget cara modern yang membuat lontong opor ayam dan sambal goreng ati ampela lebih enak.

Resep lontong opor ayam dan sambal goreng ati ampela juga gampang untuk dibikin, lho. Kamu tidak usah ribet-ribet untuk membeli lontong opor ayam dan sambal goreng ati ampela, tetapi Kita bisa menyiapkan ditempatmu. Untuk Kita yang hendak menyajikannya, di bawah ini adalah cara untuk menyajikan lontong opor ayam dan sambal goreng ati ampela yang nikamat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Lontong Opor Ayam dan Sambal Goreng Ati Ampela:

1. Gunakan 500 gr beras
1. Siapkan 1 lbr daun pandan
1. Sediakan 10 pcs cetakan lontong
1. Gunakan 10 lbr daun pisang,potong sesuai cetakan
1. Gunakan 3-4 ltr air
1. Sediakan  Pelengkap Resep Opor Ayam :           (lihat resep)
1. Siapkan 2 bh santan instan (tambahkan pada Opor)
1. Gunakan  Pelengkap Resep Sambal Goreng Ati Ampela Kentang Tahu:           (lihat resep)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Lontong Opor Ayam dan Sambal Goreng Ati Ampela:

1. Cuci bersih beras. Rendam beras sebentar.
<img src="https://img-global.cpcdn.com/steps/d8c4b4dd4a08816d/160x128cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-langkah-memasak-1-foto.jpg" alt="Lontong Opor Ayam dan Sambal Goreng Ati Ampela">1. Bentuk pola pada daun mengikuti cetakan. Terdiri dari pola persegi panjang (untuk badan) dan pola lingkaran (untuk tutup). Kemudian masukkan daun pada cetakan. Masukkan beras sekitar 3/4 cetakan (untuk beras biasa/pulen) dan 1/2 cetakan (untuk beras pera).
<img src="https://img-global.cpcdn.com/steps/ea538d60adf88879/160x128cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-langkah-memasak-2-foto.jpg" alt="Lontong Opor Ayam dan Sambal Goreng Ati Ampela">1. Panaskan air dalam pressure cooker, masukkan cetakan lontong berisi beras tadi hingga terendam semua. Lalu tutup rapat, dan lanjutkan memasak lontong hingga 30 menit. Matikan api, biarkan hingga pressure cooker tidak mengeluarkan uap lagi. Baru tutup dibuka dan keluarkan lontong dari dalam panci.
1. Setelah agak hangat, keluarkan lontong dari cetakan. Lontong siap dinikmati dengan sayur kesukaan.
1. Sajikan lontong bersama Opor Ayam (yang sudah ditambahkan santan kali ini). -           (lihat resep)
1. Tambahkan sambal goreng ati ampela kentang tahu. -           (lihat resep)




Wah ternyata resep lontong opor ayam dan sambal goreng ati ampela yang nikamt simple ini gampang banget ya! Kita semua mampu membuatnya. Resep lontong opor ayam dan sambal goreng ati ampela Sesuai banget untuk kalian yang baru mau belajar memasak ataupun bagi anda yang telah lihai dalam memasak.

Tertarik untuk mencoba membuat resep lontong opor ayam dan sambal goreng ati ampela enak tidak rumit ini? Kalau anda ingin, mending kamu segera siapkan alat-alat dan bahan-bahannya, lalu buat deh Resep lontong opor ayam dan sambal goreng ati ampela yang mantab dan tidak rumit ini. Sangat gampang kan. 

Maka, daripada kamu diam saja, yuk kita langsung buat resep lontong opor ayam dan sambal goreng ati ampela ini. Dijamin kalian gak akan menyesal sudah bikin resep lontong opor ayam dan sambal goreng ati ampela mantab simple ini! Selamat mencoba dengan resep lontong opor ayam dan sambal goreng ati ampela enak tidak ribet ini di tempat tinggal sendiri,oke!.

