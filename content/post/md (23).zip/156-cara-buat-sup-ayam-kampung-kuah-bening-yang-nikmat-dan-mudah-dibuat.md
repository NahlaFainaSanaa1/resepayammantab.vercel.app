---
description: "Cara buat Sup ayam kampung kuah bening yang nikmat dan Mudah Dibuat"
title: "Cara buat Sup ayam kampung kuah bening yang nikmat dan Mudah Dibuat"
slug: 156-cara-buat-sup-ayam-kampung-kuah-bening-yang-nikmat-dan-mudah-dibuat
date: 2021-06-06T07:13:45.569Z
image: https://img-global.cpcdn.com/recipes/8ea7d33a75e5ceb7/680x482cq70/sup-ayam-kampung-kuah-bening-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8ea7d33a75e5ceb7/680x482cq70/sup-ayam-kampung-kuah-bening-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8ea7d33a75e5ceb7/680x482cq70/sup-ayam-kampung-kuah-bening-foto-resep-utama.jpg
author: Arthur Harper
ratingvalue: 4
reviewcount: 12
recipeingredient:
- "1/2 ekor ayam kampung"
- " Daun bawang"
- " Daun seledri"
- " Bawang goreng"
- "6 siung bawang putih"
- " Garam"
- " Lada bubuk"
- " Penyedap rasa magic"
- "Sedikit micin"
- "Sedikit pala bubuk"
- "Sedikit gula"
- "1 ruas jahe"
recipeinstructions:
- "Siapkan setengah ekor ayam kampung yang sudah direbus. Jadi buat catatan ya bunda biar kuah nya ga terlalu pekat dan amis, jadi untuk kuah sop nya aku pake air rebusan ayam yang kedua."
- "Haluskan 3 buah siung bawang putih, sisa 3 buah siung bawang putih yang lain aku iris tipis lalu aku goreng ya bund."
- "Siapkan wajan dan panaskan sedikit minyak goreng, lalu tumis bawang putih yang sudah di haluskan tadi sampai harum."
- "Setelah itu masukkan potongan ayam dan tambahkan air secukupnya, dan masukkan jahe yang sudah d geprek ya bund."
- "Setelah mendidih kita bisa masukkan bumbu2 nya bund, garam, lada, pala, gula pasir, sedikit micin dan penyedap dan jangan lupa masukkan bawang putih yang sudah di goreng tadi ya bund."
- "Koreksi rasa bunda, jika dirasa sudah pas bisa kita tutup sebentar agar bumbunya meresap dan ayam tambah empuk."
- "Setelah matang bisa kita sajikan dengan tambahan daun bawang, daun seledri dan bawang goreng sesuai selera ya bund."
- "Ehhmm pasti yummy ya bun, selamat mencoba bunda..."
categories:
- Resep
tags:
- sup
- ayam
- kampung

katakunci: sup ayam kampung 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Lunch

---


![Sup ayam kampung kuah bening](https://img-global.cpcdn.com/recipes/8ea7d33a75e5ceb7/680x482cq70/sup-ayam-kampung-kuah-bening-foto-resep-utama.jpg)

Andai kamu seorang orang tua, menyuguhkan santapan lezat pada keluarga adalah suatu hal yang membahagiakan bagi kita sendiri. Peran seorang ibu bukan cuman mengurus rumah saja, tetapi kamu juga wajib memastikan keperluan nutrisi terpenuhi dan juga hidangan yang dimakan keluarga tercinta harus menggugah selera.

Di zaman  saat ini, kalian memang bisa membeli masakan jadi tanpa harus capek membuatnya dulu. Tapi banyak juga mereka yang selalu ingin menghidangkan yang terbaik untuk orang yang dicintainya. Karena, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga. 



Apakah anda adalah salah satu penikmat sup ayam kampung kuah bening?. Asal kamu tahu, sup ayam kampung kuah bening adalah sajian khas di Nusantara yang saat ini digemari oleh orang-orang di berbagai tempat di Nusantara. Kalian bisa menyajikan sup ayam kampung kuah bening sendiri di rumahmu dan dapat dijadikan hidangan favorit di hari liburmu.

Kita tidak perlu bingung untuk memakan sup ayam kampung kuah bening, karena sup ayam kampung kuah bening mudah untuk didapatkan dan juga anda pun boleh memasaknya sendiri di rumah. sup ayam kampung kuah bening boleh dimasak dengan bermacam cara. Kini pun ada banyak cara modern yang membuat sup ayam kampung kuah bening lebih enak.

Resep sup ayam kampung kuah bening pun mudah sekali untuk dibikin, lho. Kita tidak perlu capek-capek untuk memesan sup ayam kampung kuah bening, lantaran Kalian bisa menyiapkan di rumah sendiri. Untuk Anda yang mau mencobanya, inilah cara untuk menyajikan sup ayam kampung kuah bening yang enak yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Sup ayam kampung kuah bening:

1. Ambil 1/2 ekor ayam kampung
1. Sediakan  Daun bawang
1. Sediakan  Daun seledri
1. Gunakan  Bawang goreng
1. Siapkan 6 siung bawang putih
1. Siapkan  Garam
1. Siapkan  Lada bubuk
1. Ambil  Penyedap rasa magic
1. Ambil Sedikit micin
1. Ambil Sedikit pala bubuk
1. Siapkan Sedikit gula
1. Sediakan 1 ruas jahe




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Sup ayam kampung kuah bening:

1. Siapkan setengah ekor ayam kampung yang sudah direbus. Jadi buat catatan ya bunda biar kuah nya ga terlalu pekat dan amis, jadi untuk kuah sop nya aku pake air rebusan ayam yang kedua.
1. Haluskan 3 buah siung bawang putih, sisa 3 buah siung bawang putih yang lain aku iris tipis lalu aku goreng ya bund.
1. Siapkan wajan dan panaskan sedikit minyak goreng, lalu tumis bawang putih yang sudah di haluskan tadi sampai harum.
1. Setelah itu masukkan potongan ayam dan tambahkan air secukupnya, dan masukkan jahe yang sudah d geprek ya bund.
1. Setelah mendidih kita bisa masukkan bumbu2 nya bund, garam, lada, pala, gula pasir, sedikit micin dan penyedap dan jangan lupa masukkan bawang putih yang sudah di goreng tadi ya bund.
1. Koreksi rasa bunda, jika dirasa sudah pas bisa kita tutup sebentar agar bumbunya meresap dan ayam tambah empuk.
1. Setelah matang bisa kita sajikan dengan tambahan daun bawang, daun seledri dan bawang goreng sesuai selera ya bund.
1. Ehhmm pasti yummy ya bun, selamat mencoba bunda...




Ternyata cara buat sup ayam kampung kuah bening yang mantab tidak ribet ini enteng banget ya! Kita semua mampu membuatnya. Cara Membuat sup ayam kampung kuah bening Sangat cocok banget buat kalian yang baru akan belajar memasak maupun juga untuk anda yang sudah lihai dalam memasak.

Tertarik untuk mencoba buat resep sup ayam kampung kuah bening lezat tidak ribet ini? Kalau tertarik, ayo kamu segera siapkan alat dan bahannya, kemudian bikin deh Resep sup ayam kampung kuah bening yang enak dan simple ini. Sangat gampang kan. 

Maka dari itu, daripada kita berfikir lama-lama, ayo kita langsung saja bikin resep sup ayam kampung kuah bening ini. Pasti kamu gak akan nyesel bikin resep sup ayam kampung kuah bening nikmat tidak rumit ini! Selamat mencoba dengan resep sup ayam kampung kuah bening nikmat tidak rumit ini di tempat tinggal sendiri,oke!.

