---
description: "Cara membuat Opor ayam (untuk lontong cap go meh) Sederhana dan Mudah Dibuat"
title: "Cara membuat Opor ayam (untuk lontong cap go meh) Sederhana dan Mudah Dibuat"
slug: 396-cara-membuat-opor-ayam-untuk-lontong-cap-go-meh-sederhana-dan-mudah-dibuat
date: 2021-05-12T07:18:30.039Z
image: https://img-global.cpcdn.com/recipes/a64dab9a61a16f09/680x482cq70/opor-ayam-untuk-lontong-cap-go-meh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a64dab9a61a16f09/680x482cq70/opor-ayam-untuk-lontong-cap-go-meh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a64dab9a61a16f09/680x482cq70/opor-ayam-untuk-lontong-cap-go-meh-foto-resep-utama.jpg
author: Ina Morris
ratingvalue: 3.1
reviewcount: 10
recipeingredient:
- "1 ekor ayam kurang lebih 1 kg potong sesuai selera aku potong 14 bagian"
- "1 sachet santan kara"
- "secukupnya Bawang goreng"
- "secukupnya Garam gula lada totole"
- "secukupnya Minyak untuk menumis"
- " Bumbu dihaluskan"
- "10 siung bawang merah"
- "8 siung bawang putih"
- "4 buah kemiri"
- "5 cm jahe"
- "1 cm kunyit"
- " Bumbu disangrai lalu dihaluskan jadi bubuk"
- "1/2 sdm ketumbar"
- "1/4 sdm merica"
- "1/4 sdm jinten"
- "1/4 biji pala"
- "3 biji cengkeh"
- " Bumbu cemplung"
- "2 biji bunga lawang"
- "3 biji kapulaga"
- "3 cm kayu manis"
- "5 cm lengkuas digeprek"
- "5 lembar daun jeruk"
- "2 lembar daun salam"
- "1 buah sereh digeprek"
recipeinstructions:
- "Tumis bumbu yang telah dihaluskan dengan minyak, masukkan juga bumbu bubuk dan bumbu cemplung. Tumis hingga airnya habis dan mengeluarkan minyak, hingga bumbu sudah tidak mentah lagi."
- "Masukkan ayam, ratakan bumbu hingga semua ayam tercampur. Masukkan air kurang lebih 1 L, beri garam, gula, lada dan totole secukupnya dan rebus hingga mendidih dan ayam matang. Jika ayam sudah matang, rebus hingga volume kuah sesuai yang diinginkan, jika ingin kental artinya sisakan air sekitar 500 mL."
- "Masukkan santan dan bawang goreng, aduk2 agar santan ga pecah, tunggu hingga mendidih sekali lagi, koreksi rasa juga hingga pas. Jika sudah pas semua, matikan api, opor siap dihidangkan. Selesai"
categories:
- Resep
tags:
- opor
- ayam
- untuk

katakunci: opor ayam untuk 
nutrition: 207 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Opor ayam (untuk lontong cap go meh)](https://img-global.cpcdn.com/recipes/a64dab9a61a16f09/680x482cq70/opor-ayam-untuk-lontong-cap-go-meh-foto-resep-utama.jpg)

Andai kalian seorang istri, menyajikan panganan lezat pada orang tercinta merupakan suatu hal yang menggembirakan bagi kamu sendiri. Tugas seorang ibu Tidak sekedar menangani rumah saja, tetapi anda juga wajib menyediakan kebutuhan nutrisi terpenuhi dan masakan yang dikonsumsi anak-anak mesti enak.

Di era  sekarang, anda memang bisa memesan santapan siap saji tidak harus susah memasaknya dulu. Tapi ada juga mereka yang memang ingin menyajikan yang terenak untuk orang tercintanya. Karena, memasak yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Apakah anda adalah seorang penikmat opor ayam (untuk lontong cap go meh)?. Asal kamu tahu, opor ayam (untuk lontong cap go meh) merupakan hidangan khas di Indonesia yang saat ini disenangi oleh orang-orang dari hampir setiap wilayah di Indonesia. Kamu bisa menyajikan opor ayam (untuk lontong cap go meh) sendiri di rumahmu dan boleh jadi makanan kesenanganmu di akhir pekan.

Anda tidak usah bingung untuk menyantap opor ayam (untuk lontong cap go meh), karena opor ayam (untuk lontong cap go meh) tidak sukar untuk didapatkan dan juga kalian pun bisa mengolahnya sendiri di tempatmu. opor ayam (untuk lontong cap go meh) dapat dibuat dengan beragam cara. Sekarang telah banyak banget cara kekinian yang membuat opor ayam (untuk lontong cap go meh) lebih lezat.

Resep opor ayam (untuk lontong cap go meh) juga sangat mudah untuk dibuat, lho. Kita jangan capek-capek untuk membeli opor ayam (untuk lontong cap go meh), tetapi Kalian dapat menghidangkan di rumahmu. Untuk Kamu yang hendak mencobanya, berikut cara membuat opor ayam (untuk lontong cap go meh) yang lezat yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Opor ayam (untuk lontong cap go meh):

1. Siapkan 1 ekor ayam (kurang lebih 1 kg, potong sesuai selera, aku potong 14 bagian)
1. Gunakan 1 sachet santan kara
1. Sediakan secukupnya Bawang goreng
1. Sediakan secukupnya Garam, gula, lada, totole
1. Ambil secukupnya Minyak untuk menumis
1. Sediakan  Bumbu dihaluskan
1. Ambil 10 siung bawang merah
1. Sediakan 8 siung bawang putih
1. Ambil 4 buah kemiri
1. Sediakan 5 cm jahe
1. Ambil 1 cm kunyit
1. Siapkan  Bumbu disangrai lalu dihaluskan (jadi bubuk)
1. Ambil 1/2 sdm ketumbar
1. Ambil 1/4 sdm merica
1. Ambil 1/4 sdm jinten
1. Ambil 1/4 biji pala
1. Siapkan 3 biji cengkeh
1. Sediakan  Bumbu cemplung
1. Ambil 2 biji bunga lawang
1. Siapkan 3 biji kapulaga
1. Ambil 3 cm kayu manis
1. Ambil 5 cm lengkuas digeprek
1. Sediakan 5 lembar daun jeruk
1. Gunakan 2 lembar daun salam
1. Sediakan 1 buah sereh digeprek




<!--inarticleads2-->

##### Langkah-langkah membuat Opor ayam (untuk lontong cap go meh):

1. Tumis bumbu yang telah dihaluskan dengan minyak, masukkan juga bumbu bubuk dan bumbu cemplung. Tumis hingga airnya habis dan mengeluarkan minyak, hingga bumbu sudah tidak mentah lagi.
1. Masukkan ayam, ratakan bumbu hingga semua ayam tercampur. Masukkan air kurang lebih 1 L, beri garam, gula, lada dan totole secukupnya dan rebus hingga mendidih dan ayam matang. Jika ayam sudah matang, rebus hingga volume kuah sesuai yang diinginkan, jika ingin kental artinya sisakan air sekitar 500 mL.
1. Masukkan santan dan bawang goreng, aduk2 agar santan ga pecah, tunggu hingga mendidih sekali lagi, koreksi rasa juga hingga pas. Jika sudah pas semua, matikan api, opor siap dihidangkan. Selesai




Ternyata cara buat opor ayam (untuk lontong cap go meh) yang nikamt sederhana ini enteng banget ya! Anda Semua mampu mencobanya. Cara buat opor ayam (untuk lontong cap go meh) Cocok sekali buat kamu yang baru akan belajar memasak ataupun untuk kalian yang telah ahli memasak.

Apakah kamu mau mulai mencoba buat resep opor ayam (untuk lontong cap go meh) mantab sederhana ini? Kalau anda tertarik, mending kamu segera buruan siapkan peralatan dan bahan-bahannya, setelah itu buat deh Resep opor ayam (untuk lontong cap go meh) yang mantab dan simple ini. Sungguh taidak sulit kan. 

Jadi, ketimbang anda berlama-lama, maka langsung aja sajikan resep opor ayam (untuk lontong cap go meh) ini. Pasti kalian gak akan menyesal bikin resep opor ayam (untuk lontong cap go meh) lezat simple ini! Selamat berkreasi dengan resep opor ayam (untuk lontong cap go meh) enak tidak rumit ini di rumah kalian sendiri,oke!.

