---
description: "Resep Kare Ayam Solo yang enak dan Mudah Dibuat"
title: "Resep Kare Ayam Solo yang enak dan Mudah Dibuat"
slug: 111-resep-kare-ayam-solo-yang-enak-dan-mudah-dibuat
date: 2021-06-11T02:44:54.897Z
image: https://img-global.cpcdn.com/recipes/74a6593e37bad594/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/74a6593e37bad594/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/74a6593e37bad594/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Stephen Myers
ratingvalue: 4.2
reviewcount: 4
recipeingredient:
- " Bahan A"
- "1 kg daging ayam"
- "1500 ml air"
- "300 ml santan kental"
- "2 batang sereh geprek"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang kayu manis"
- "5 butir kapulaga geprek"
- "2 butir pekakbunga lawang"
- "3 butir cengkeh"
- "Secukupnya minyak"
- "Secukupnya garam"
- "1 sdt gula pasir atau sesuaikan selera"
- "Secukupnya penyedap"
- " B bumbu halus"
- "9 siung bawang putih"
- "5 siung bawang merah"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 butir kemiri sangrai sebentar dulu"
- "1/2 sdt jintan"
- "1 sdt ketumbar"
- "1/2 sdt merica butir"
- " C Pelengkap"
- "Secukupnya irisan wortel rebus"
- "Secukupnya keripik kentangkentang iris tipis lalu goreng"
- "Secukupnya Soun atau bihun jagung"
- "Secukupnya irisan daun bawang"
- "Secukupnya irisan daun seledri saya gak pakai"
- "Secukupnya bawang goreng"
- " Toge saya ga pakai"
recipeinstructions:
- "Dalam panci, panaskan minyak sekitar 4.sdm masukkan bumbu halus, tumis hingga harum, masukkan sereh, daun jeruk, daun salam, kayu manis, pekak, cengkeh, kapulaga, aduk tumis lagi hingga rempah harum, masukkan potong ayam, garam dan penyedap, aduk rata dan tumis beberapa saat, lalu Tutup pancinya biarkan ayam berubah warna dan sedikit mengeluarkan air kaldu dengan sendirinya (gunakan api kecil agar tidak gosong)"
- "Masukkan air, masak dengan api besar, biarkan hingga mendidih, setelah mendidih, tutup pancinya, kecilkan api biarkan terus masak hingga ayam empuk."
- "Setelah ayam empuk, masukkan santan kental, masak sambil diaduk ya agar santan tidak pecah, masak hingga dirasa santan matang, dan kuah menyusut, test rasa tambahkan gula pasir, aduk rata, jika kurang asin bisa ditambah garam sesuai selera. Angkat ayamnya, goreng, lalu suwir suwir untuk penyajian nanti"
- "Penyajian = dalam mangkuk, tata nasi, lalu soun/bihun, lalu toge, suwiran ayam goreng, irisan wortel rebus, keripik kentang, siram dengan kuah Kare, taburi dengan irisan daun bawang, daun seledri dan juga bawang goreng, sajikan dengan sambal, jika suka kucuri dengan perasan jeruk nipis. Syegerrr 🍲 😍"
- "Jika ada sisa kuah Kare jangan dibuang ya, bisa disaring lalu dibikin kremesan yang gurih (resep kremesan sudah ada)"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 231 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dinner

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/74a6593e37bad594/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Andai kita seorang wanita, menyediakan hidangan sedap kepada orang tercinta merupakan hal yang memuaskan untuk anda sendiri. Peran seorang istri bukan cuman mengatur rumah saja, tapi kamu juga harus menyediakan keperluan nutrisi terpenuhi dan juga masakan yang disantap anak-anak mesti nikmat.

Di masa  sekarang, kamu memang bisa memesan panganan jadi walaupun tidak harus repot membuatnya dulu. Tetapi banyak juga orang yang selalu ingin memberikan hidangan yang terlezat bagi keluarganya. Pasalnya, memasak yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai masakan kesukaan orang tercinta. 



Mungkinkah kamu seorang penyuka kare ayam solo?. Tahukah kamu, kare ayam solo merupakan sajian khas di Indonesia yang sekarang disukai oleh setiap orang di hampir setiap tempat di Nusantara. Kalian bisa menyajikan kare ayam solo sendiri di rumahmu dan pasti jadi hidangan kesukaanmu di akhir pekanmu.

Kalian tidak perlu bingung jika kamu ingin mendapatkan kare ayam solo, lantaran kare ayam solo tidak sukar untuk dicari dan anda pun bisa menghidangkannya sendiri di rumah. kare ayam solo boleh diolah dengan beragam cara. Sekarang sudah banyak cara modern yang menjadikan kare ayam solo semakin enak.

Resep kare ayam solo juga sangat gampang dihidangkan, lho. Kalian tidak perlu repot-repot untuk memesan kare ayam solo, karena Kita dapat menghidangkan di rumahmu. Bagi Kalian yang mau menyajikannya, berikut resep untuk menyajikan kare ayam solo yang lezat yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Kare Ayam Solo:

1. Siapkan  Bahan= A)
1. Gunakan 1 .kg. daging ayam
1. Siapkan 1500 .ml. air
1. Gunakan 300 .ml. santan kental
1. Siapkan 2 .batang. sereh geprek
1. Siapkan 4 .lembar. daun jeruk
1. Gunakan 2 .lembar. daun salam
1. Ambil 1 .batang. kayu manis
1. Ambil 5 .butir. kapulaga geprek
1. Ambil 2 .butir. pekak/bunga lawang
1. Sediakan 3 .butir. cengkeh
1. Ambil Secukupnya minyak
1. Gunakan Secukupnya garam
1. Sediakan 1 .sdt gula pasir atau sesuaikan selera
1. Sediakan Secukupnya penyedap
1. Sediakan  B). bumbu halus=
1. Ambil 9 .siung. bawang putih
1. Ambil 5 .siung. bawang merah
1. Sediakan 1 .ruas. kunyit
1. Ambil 1 .ruas. jahe
1. Gunakan 3 .butir. kemiri (sangrai sebentar dulu)
1. Ambil 1/2 .sdt. jintan
1. Siapkan 1 .sdt. ketumbar
1. Ambil 1/2 .sdt. merica butir
1. Gunakan  C). Pelengkap=
1. Siapkan Secukupnya irisan wortel rebus
1. Sediakan Secukupnya keripik kentang/kentang iris tipis lalu goreng
1. Sediakan Secukupnya Soun (atau bihun jagung)
1. Ambil Secukupnya irisan daun bawang
1. Sediakan Secukupnya irisan daun seledri (saya gak pakai)
1. Siapkan Secukupnya bawang goreng
1. Sediakan  Toge (saya ga pakai)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Kare Ayam Solo:

1. Dalam panci, panaskan minyak sekitar 4.sdm masukkan bumbu halus, tumis hingga harum, masukkan sereh, daun jeruk, daun salam, kayu manis, pekak, cengkeh, kapulaga, aduk tumis lagi hingga rempah harum, masukkan potong ayam, garam dan penyedap, aduk rata dan tumis beberapa saat, lalu Tutup pancinya biarkan ayam berubah warna dan sedikit mengeluarkan air kaldu dengan sendirinya (gunakan api kecil agar tidak gosong)
1. Masukkan air, masak dengan api besar, biarkan hingga mendidih, setelah mendidih, tutup pancinya, kecilkan api biarkan terus masak hingga ayam empuk.
1. Setelah ayam empuk, masukkan santan kental, masak sambil diaduk ya agar santan tidak pecah, masak hingga dirasa santan matang, dan kuah menyusut, test rasa tambahkan gula pasir, aduk rata, jika kurang asin bisa ditambah garam sesuai selera. Angkat ayamnya, goreng, lalu suwir suwir untuk penyajian nanti
1. Penyajian = dalam mangkuk, tata nasi, lalu soun/bihun, lalu toge, suwiran ayam goreng, irisan wortel rebus, keripik kentang, siram dengan kuah Kare, taburi dengan irisan daun bawang, daun seledri dan juga bawang goreng, sajikan dengan sambal, jika suka kucuri dengan perasan jeruk nipis. Syegerrr 🍲 😍
1. Jika ada sisa kuah Kare jangan dibuang ya, bisa disaring lalu dibikin kremesan yang gurih (resep kremesan sudah ada)




Ternyata resep kare ayam solo yang mantab tidak ribet ini gampang sekali ya! Kalian semua mampu mencobanya. Cara buat kare ayam solo Sangat cocok sekali untuk anda yang sedang belajar memasak atau juga untuk anda yang telah jago memasak.

Tertarik untuk mencoba membikin resep kare ayam solo mantab simple ini? Kalau mau, ayo kamu segera buruan siapin alat dan bahan-bahannya, kemudian bikin deh Resep kare ayam solo yang mantab dan tidak ribet ini. Sangat mudah kan. 

Maka dari itu, daripada kalian berlama-lama, yuk kita langsung saja hidangkan resep kare ayam solo ini. Dijamin kamu tak akan menyesal bikin resep kare ayam solo mantab sederhana ini! Selamat berkreasi dengan resep kare ayam solo enak sederhana ini di tempat tinggal masing-masing,ya!.

