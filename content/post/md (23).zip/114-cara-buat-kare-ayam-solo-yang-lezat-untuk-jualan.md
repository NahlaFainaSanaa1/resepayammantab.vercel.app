---
description: "Cara buat Kare ayam solo yang lezat Untuk Jualan"
title: "Cara buat Kare ayam solo yang lezat Untuk Jualan"
slug: 114-cara-buat-kare-ayam-solo-yang-lezat-untuk-jualan
date: 2021-01-09T21:45:37.633Z
image: https://img-global.cpcdn.com/recipes/726f6fc360af8f93/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/726f6fc360af8f93/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/726f6fc360af8f93/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Lillie Brooks
ratingvalue: 4.9
reviewcount: 6
recipeingredient:
- "250 gr ayamaku dada"
- "1 bgkus kecambah"
- "1 bgks bihun jagung"
- "250 gr wortel"
- " Daun bawangseledri"
- "250 gr kentang goreng"
- " Bumbu halus"
- "10 bawang putih"
- "8 bawang merah"
- "2 biji kemiri"
- "1/2 biji pala"
- "1 sdt ketumbar"
- "1 sdt merica"
- " Ditambah bumbu racik kare kering disangrai"
- " Bumbu pelengkap"
- " Garamkaldu bubuk"
- " Gula pasirselera"
- "2 buah tomat"
- "800 ml santan dr setengah kelapa parut"
- " Daun salam daun jeruk"
- " Jaheserai dan lengkuas memarkan"
- " Bawang merah goreng"
- " Bumbu sambal"
- "1 bawang putih"
- "15 cabe rawit"
recipeinstructions:
- "Rebus ayam dg air mendidih hingga empuk,tiriskan,lalu buang airnya,disihkan"
- "Siapkan bumbu halusnya,bumbu racik disangrai,bawang putih bawang merah,kemiri,pala,kunyit digoreng,lalu haluskan semua,kemudian ditumis hingga harum"
- "Rebus air,mendidih masukan ayam utuh,bumbu,ditambah bumbu pelengkap kecuali tomat dan santan,biarkan mendidih dulu,baru masukan santan,garam dll tambahkan daun bawang&amp;seledri 1 batang,diaduk tipis&#34;ya,cek rasa,tomat paling akhir,keluarkan ayam lalu suir&#34;,tunggu mendidih lagi baru matikan kompor"
- "Dilain tempat,rebus air,rebus wortel yg sudah dipotong&#34;,bgtu juga dg bihun dan kecambah bergatian,one by one,daun bawang&amp; seledri iris mentah,ayam suir digongso sebentar(skip)"
- "Sisa air untuk merebus cabe&amp;bawang untuk sambel karenya"
- "Goreng kentang yg sdh diiris tipis untuk pemanis/pelengkap kare solo(aku:kentang iris aku rebus dg garam mendidih angkat dinginkan baru digoreng,biar renyah dan awet)"
- "Selesai sajikan dg sambal dan kecap plus kerupuk atau tempe goreng"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Lunch

---


![Kare ayam solo](https://img-global.cpcdn.com/recipes/726f6fc360af8f93/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Apabila anda seorang istri, menyajikan panganan menggugah selera pada famili merupakan hal yang sangat menyenangkan untuk kita sendiri. Tanggung jawab seorang ibu bukan cuman menangani rumah saja, tapi anda juga harus menyediakan keperluan nutrisi tercukupi dan masakan yang disantap orang tercinta harus enak.

Di waktu  sekarang, kamu sebenarnya bisa memesan santapan jadi tanpa harus capek membuatnya lebih dulu. Tapi banyak juga mereka yang selalu mau memberikan makanan yang terlezat untuk orang yang dicintainya. Pasalnya, memasak yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai kesukaan famili. 



Apakah anda salah satu penggemar kare ayam solo?. Asal kamu tahu, kare ayam solo adalah makanan khas di Indonesia yang kini digemari oleh kebanyakan orang di berbagai daerah di Indonesia. Anda dapat membuat kare ayam solo buatan sendiri di rumah dan boleh jadi hidangan kesenanganmu di hari liburmu.

Anda jangan bingung jika kamu ingin mendapatkan kare ayam solo, sebab kare ayam solo sangat mudah untuk ditemukan dan juga kamu pun boleh memasaknya sendiri di rumah. kare ayam solo dapat dibuat lewat berbagai cara. Sekarang telah banyak sekali cara kekinian yang membuat kare ayam solo semakin enak.

Resep kare ayam solo pun gampang dihidangkan, lho. Anda tidak usah capek-capek untuk membeli kare ayam solo, sebab Kalian dapat membuatnya di rumahmu. Untuk Kita yang akan mencobanya, di bawah ini adalah cara membuat kare ayam solo yang mantab yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Kare ayam solo:

1. Ambil 250 gr ayam(aku dada)
1. Gunakan 1 bgkus kecambah
1. Sediakan 1 bgks bihun jagung
1. Gunakan 250 gr wortel
1. Ambil  Daun bawang&amp;seledri
1. Sediakan 250 gr kentang goreng
1. Siapkan  Bumbu halus🍾
1. Sediakan 10 bawang putih
1. Siapkan 8 bawang merah
1. Siapkan 2 biji kemiri
1. Ambil 1/2 biji pala
1. Siapkan 1 sdt ketumbar
1. Sediakan 1 sdt merica
1. Siapkan  Ditambah bumbu racik kare kering disangrai
1. Sediakan  Bumbu pelengkap🥥
1. Ambil  Garam,kaldu bubuk
1. Ambil  Gula pasir(selera)
1. Ambil 2 buah tomat
1. Ambil 800 ml santan dr setengah kelapa parut
1. Gunakan  Daun salam&amp; daun jeruk
1. Ambil  Jahe,serai dan lengkuas memarkan
1. Ambil  Bawang merah goreng
1. Gunakan  Bumbu sambal🌶
1. Siapkan 1 bawang putih
1. Sediakan 15 cabe rawit




<!--inarticleads2-->

##### Cara membuat Kare ayam solo:

1. Rebus ayam dg air mendidih hingga empuk,tiriskan,lalu buang airnya,disihkan
1. Siapkan bumbu halusnya,bumbu racik disangrai,bawang putih bawang merah,kemiri,pala,kunyit digoreng,lalu haluskan semua,kemudian ditumis hingga harum
1. Rebus air,mendidih masukan ayam utuh,bumbu,ditambah bumbu pelengkap kecuali tomat dan santan,biarkan mendidih dulu,baru masukan santan,garam dll tambahkan daun bawang&amp;seledri 1 batang,diaduk tipis&#34;ya,cek rasa,tomat paling akhir,keluarkan ayam lalu suir&#34;,tunggu mendidih lagi baru matikan kompor
1. Dilain tempat,rebus air,rebus wortel yg sudah dipotong&#34;,bgtu juga dg bihun dan kecambah bergatian,one by one,daun bawang&amp; seledri iris mentah,ayam suir digongso sebentar(skip)
1. Sisa air untuk merebus cabe&amp;bawang untuk sambel karenya
1. Goreng kentang yg sdh diiris tipis untuk pemanis/pelengkap kare solo(aku:kentang iris aku rebus dg garam mendidih angkat dinginkan baru digoreng,biar renyah dan awet)
1. Selesai sajikan dg sambal dan kecap plus kerupuk atau tempe goreng




Ternyata cara buat kare ayam solo yang enak tidak ribet ini enteng sekali ya! Kita semua bisa menghidangkannya. Cara buat kare ayam solo Sangat cocok banget untuk kita yang baru mau belajar memasak maupun untuk kalian yang telah jago dalam memasak.

Tertarik untuk mulai mencoba buat resep kare ayam solo nikmat tidak rumit ini? Kalau kalian tertarik, yuk kita segera buruan menyiapkan peralatan dan bahan-bahannya, lalu buat deh Resep kare ayam solo yang mantab dan sederhana ini. Benar-benar gampang kan. 

Maka dari itu, daripada anda diam saja, ayo kita langsung saja buat resep kare ayam solo ini. Dijamin kamu tiidak akan menyesal membuat resep kare ayam solo nikmat tidak rumit ini! Selamat mencoba dengan resep kare ayam solo enak sederhana ini di rumah masing-masing,ya!.

