---
description: "Cara membuat Hati ayam kentang masak kecap Sederhana Untuk Jualan"
title: "Cara membuat Hati ayam kentang masak kecap Sederhana Untuk Jualan"
slug: 322-cara-membuat-hati-ayam-kentang-masak-kecap-sederhana-untuk-jualan
date: 2021-02-18T05:23:52.404Z
image: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
author: Christina Hanson
ratingvalue: 4.9
reviewcount: 14
recipeingredient:
- "4 bh hati ayam"
- "4 bh kentang"
- "3 bh bawang merah  1 bh bombay"
- "2 bh bawang putih"
- "secukupnya Merica"
- "2 helai daun bawang iris"
- "1 bh tomat besar iris"
- "1 ruas jahe"
- "2 sdm kecap manis"
- "1 sdt saori saus tiram"
- "secukupnya Garampenyedap"
- "secukupnya Air"
recipeinstructions:
- "Rebus hati ayam,stlh masak potong dan sisihkan"
- "Kupas dan potong kentang sesuai selera,lalu digoreng"
- "Iris bawang merah,geprek bawang putih dan jahe"
- "Tumis bawang,jahe dan merica hingga harum"
- "Tambahkan garam,penyedap dan air"
- "Lalu masukkan saori,dan kecap manis"
- "Masukkan hati ayam dan kentang,aduk rata dan diamkan sejenak sampai seluruh bumbu meresap."
- "Terakhir masukkan irisan daun bawang dan tomat sbg pelengkap,aduk rata"
- "Siap dihidangkan🤗"
categories:
- Resep
tags:
- hati
- ayam
- kentang

katakunci: hati ayam kentang 
nutrition: 270 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dinner

---


![Hati ayam kentang masak kecap](https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg)

Andai kita seorang wanita, mempersiapkan masakan mantab kepada keluarga tercinta merupakan suatu hal yang sangat menyenangkan bagi kita sendiri. Tanggung jawab seorang istri bukan sekedar menjaga rumah saja, tetapi anda juga wajib menyediakan kebutuhan nutrisi tercukupi dan panganan yang disantap anak-anak mesti nikmat.

Di era  sekarang, kita memang bisa membeli masakan jadi meski tanpa harus repot memasaknya terlebih dahulu. Tapi ada juga lho orang yang memang mau memberikan hidangan yang terlezat bagi keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penyuka hati ayam kentang masak kecap?. Tahukah kamu, hati ayam kentang masak kecap merupakan sajian khas di Indonesia yang saat ini disenangi oleh banyak orang dari berbagai daerah di Indonesia. Anda bisa memasak hati ayam kentang masak kecap olahan sendiri di rumahmu dan pasti jadi makanan kesukaanmu di hari libur.

Kamu tidak usah bingung untuk memakan hati ayam kentang masak kecap, lantaran hati ayam kentang masak kecap sangat mudah untuk dicari dan juga kamu pun boleh mengolahnya sendiri di rumah. hati ayam kentang masak kecap dapat dibuat memalui beraneka cara. Kini pun ada banyak cara kekinian yang membuat hati ayam kentang masak kecap semakin mantap.

Resep hati ayam kentang masak kecap juga mudah sekali dibikin, lho. Kita jangan repot-repot untuk memesan hati ayam kentang masak kecap, karena Kalian bisa membuatnya ditempatmu. Untuk Kalian yang ingin menyajikannya, di bawah ini adalah resep menyajikan hati ayam kentang masak kecap yang enak yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Hati ayam kentang masak kecap:

1. Gunakan 4 bh hati ayam
1. Siapkan 4 bh kentang
1. Siapkan 3 bh bawang merah / 1 bh bombay
1. Siapkan 2 bh bawang putih
1. Siapkan secukupnya Merica
1. Siapkan 2 helai daun bawang, iris
1. Ambil 1 bh tomat besar, iris
1. Siapkan 1 ruas jahe
1. Siapkan 2 sdm kecap manis
1. Gunakan 1 sdt saori saus tiram
1. Gunakan secukupnya Garam,penyedap
1. Siapkan secukupnya Air




<!--inarticleads2-->

##### Cara membuat Hati ayam kentang masak kecap:

1. Rebus hati ayam,stlh masak potong dan sisihkan
1. Kupas dan potong kentang sesuai selera,lalu digoreng
1. Iris bawang merah,geprek bawang putih dan jahe
1. Tumis bawang,jahe dan merica hingga harum
1. Tambahkan garam,penyedap dan air
1. Lalu masukkan saori,dan kecap manis
1. Masukkan hati ayam dan kentang,aduk rata dan diamkan sejenak sampai seluruh bumbu meresap.
1. Terakhir masukkan irisan daun bawang dan tomat sbg pelengkap,aduk rata
1. Siap dihidangkan🤗




Wah ternyata cara membuat hati ayam kentang masak kecap yang enak sederhana ini enteng banget ya! Kamu semua dapat menghidangkannya. Cara buat hati ayam kentang masak kecap Cocok banget untuk kamu yang sedang belajar memasak atau juga bagi kamu yang telah lihai dalam memasak.

Apakah kamu mau mulai mencoba bikin resep hati ayam kentang masak kecap mantab tidak rumit ini? Kalau anda tertarik, yuk kita segera buruan menyiapkan alat-alat dan bahannya, setelah itu bikin deh Resep hati ayam kentang masak kecap yang lezat dan sederhana ini. Betul-betul gampang kan. 

Maka, daripada kita diam saja, ayo kita langsung saja buat resep hati ayam kentang masak kecap ini. Dijamin anda gak akan nyesel sudah bikin resep hati ayam kentang masak kecap lezat tidak ribet ini! Selamat berkreasi dengan resep hati ayam kentang masak kecap mantab simple ini di tempat tinggal kalian sendiri,oke!.

