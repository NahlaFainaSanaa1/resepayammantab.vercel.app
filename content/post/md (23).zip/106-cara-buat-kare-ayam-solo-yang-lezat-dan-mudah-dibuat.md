---
description: "Cara buat Kare Ayam Solo yang lezat dan Mudah Dibuat"
title: "Cara buat Kare Ayam Solo yang lezat dan Mudah Dibuat"
slug: 106-cara-buat-kare-ayam-solo-yang-lezat-dan-mudah-dibuat
date: 2021-06-01T18:07:33.969Z
image: https://img-global.cpcdn.com/recipes/a5fc6aceb2e2f1cf/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a5fc6aceb2e2f1cf/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a5fc6aceb2e2f1cf/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Thomas Townsend
ratingvalue: 4.1
reviewcount: 10
recipeingredient:
- "1/2 kg ayam potong2"
- "1 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "1 ruas lengkuas geprek"
- "65 ml santan instan"
- "secukupnya Garam gula dan kaldu bubuk"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "1 sdt ketumbar bubuk"
- "1/4 sdt jintan"
- "1/4 sdt lada bubuk"
- "2 cm kunyit"
- " Bahan pelengkap"
- " Wortel diiris rebus"
- " Toge diseduh dengan air panas tiriskan"
- " Daun bawang"
- " Bawang goreng"
recipeinstructions:
- "Didihkan air. Rebus ayam hingga berubah warna/setengah matang. Tiriskan ayam. Buang air rebusan nya. Didihkan kembali ayam dengan air yang baru.."
- "Tumis bumbu halus dan rempah2 sampai harum"
- "Tuang tumisan ke rebusan ayam. Beri garam gula dan kaldu bubuk. Test rasa. Masukkan santan. Aduk2, test rasa"
- "Siapkan sayuran"
- "Tata sayuran di mangkok/piring. Tuang ayam dan kuahnya. Beri taburan daun bawang dan bawang goreng. Sajikan hangat 😋"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Lunch

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/a5fc6aceb2e2f1cf/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Sebagai seorang istri, menyuguhkan santapan nikmat bagi keluarga tercinta adalah hal yang menyenangkan bagi kamu sendiri. Peran seorang ibu bukan sekedar mengurus rumah saja, tapi kamu pun harus menyediakan keperluan nutrisi terpenuhi dan panganan yang dikonsumsi anak-anak harus menggugah selera.

Di masa  saat ini, kamu memang bisa membeli santapan siap saji meski tanpa harus susah memasaknya terlebih dahulu. Tetapi banyak juga mereka yang selalu mau memberikan hidangan yang terlezat untuk orang tercintanya. Pasalnya, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan berdasarkan kesukaan keluarga tercinta. 



Apakah anda seorang penyuka kare ayam solo?. Tahukah kamu, kare ayam solo merupakan sajian khas di Indonesia yang saat ini disenangi oleh setiap orang di berbagai wilayah di Indonesia. Kalian dapat membuat kare ayam solo kreasi sendiri di rumah dan boleh jadi hidangan favoritmu di hari liburmu.

Kalian tak perlu bingung jika kamu ingin menyantap kare ayam solo, lantaran kare ayam solo gampang untuk ditemukan dan juga anda pun boleh menghidangkannya sendiri di rumah. kare ayam solo dapat dimasak dengan berbagai cara. Kini pun sudah banyak cara modern yang membuat kare ayam solo semakin lebih nikmat.

Resep kare ayam solo juga mudah sekali dibuat, lho. Kalian tidak usah repot-repot untuk membeli kare ayam solo, karena Kamu mampu menyiapkan di rumahmu. Untuk Kamu yang ingin menghidangkannya, berikut resep untuk membuat kare ayam solo yang lezat yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Kare Ayam Solo:

1. Gunakan 1/2 kg ayam, potong2
1. Sediakan 1 lembar daun salam
1. Gunakan 3 lembar daun jeruk
1. Ambil 1 batang serai, geprek
1. Gunakan 1 ruas lengkuas, geprek
1. Sediakan 65 ml santan instan
1. Sediakan secukupnya Garam gula dan kaldu bubuk
1. Sediakan  Bumbu halus
1. Gunakan 5 siung bawang merah
1. Ambil 3 siung bawang putih
1. Sediakan 3 butir kemiri
1. Gunakan 1 sdt ketumbar bubuk
1. Ambil 1/4 sdt jintan
1. Ambil 1/4 sdt lada bubuk
1. Ambil 2 cm kunyit
1. Gunakan  Bahan pelengkap
1. Sediakan  Wortel, diiris, rebus
1. Siapkan  Toge, diseduh dengan air panas, tiriskan
1. Siapkan  Daun bawang
1. Sediakan  Bawang goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Kare Ayam Solo:

1. Didihkan air. Rebus ayam hingga berubah warna/setengah matang. Tiriskan ayam. Buang air rebusan nya. Didihkan kembali ayam dengan air yang baru..
1. Tumis bumbu halus dan rempah2 sampai harum
1. Tuang tumisan ke rebusan ayam. Beri garam gula dan kaldu bubuk. Test rasa. Masukkan santan. Aduk2, test rasa
1. Siapkan sayuran
1. Tata sayuran di mangkok/piring. Tuang ayam dan kuahnya. Beri taburan daun bawang dan bawang goreng. Sajikan hangat 😋




Wah ternyata cara buat kare ayam solo yang mantab simple ini gampang banget ya! Anda Semua bisa memasaknya. Cara Membuat kare ayam solo Sangat sesuai sekali buat kita yang baru akan belajar memasak ataupun untuk anda yang telah pandai memasak.

Tertarik untuk mulai mencoba bikin resep kare ayam solo nikmat tidak ribet ini? Kalau anda tertarik, ayo kamu segera siapkan peralatan dan bahannya, maka buat deh Resep kare ayam solo yang enak dan simple ini. Sungguh gampang kan. 

Maka, ketimbang kita berlama-lama, ayo kita langsung hidangkan resep kare ayam solo ini. Dijamin kamu tak akan menyesal sudah membuat resep kare ayam solo mantab sederhana ini! Selamat mencoba dengan resep kare ayam solo enak tidak ribet ini di rumah sendiri,oke!.

