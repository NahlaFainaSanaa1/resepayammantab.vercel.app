---
description: "Cara buat Sempol tanpa ayam Sederhana Untuk Jualan"
title: "Cara buat Sempol tanpa ayam Sederhana Untuk Jualan"
slug: 175-cara-buat-sempol-tanpa-ayam-sederhana-untuk-jualan
date: 2021-03-31T03:29:13.799Z
image: https://img-global.cpcdn.com/recipes/096306ffd9caa1c6/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/096306ffd9caa1c6/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/096306ffd9caa1c6/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
author: Tom Zimmerman
ratingvalue: 4.4
reviewcount: 8
recipeingredient:
- "10 sdm terigu"
- "6 sdm kanji"
- "3 siung bawang putih  gorenghancurkan"
- "3 siung bawang merah  gorenghancurkan"
- "1 batang daun bawang  iris tipis"
- "secukupnya garampenyedap"
- "100 ml air  kira2 aja smpai bisa di bulatkan"
- "1 buah wortel parut tambahan bisa dikasih"
- "1 buah telur ayamkocok lepas"
recipeinstructions:
- "Campur semua bahan kecuali air sampai rata"
- "Tambahan air sedikit demi sedikit,uleni kalis(ga lengket ditangan)"
- "Bentuk bulat atau sesuai selera,me lonjong gini..."
- "Rebus di air mendidih sampai ngapung,angkat,dinginkan"
- "Baru di tusuk pake lidi"
- "Masukan ke kocokan telur,goreng Kalau mau telurnya lebih tebal,masukan lagi ke kocokan telur dan goreng smp warna kecoklatan"
categories:
- Resep
tags:
- sempol
- tanpa
- ayam

katakunci: sempol tanpa ayam 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dinner

---


![Sempol tanpa ayam](https://img-global.cpcdn.com/recipes/096306ffd9caa1c6/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, mempersiapkan hidangan nikmat pada keluarga tercinta adalah suatu hal yang menggembirakan untuk kita sendiri. Kewajiban seorang  wanita Tidak sekadar mengatur rumah saja, namun kamu juga wajib memastikan keperluan gizi terpenuhi dan hidangan yang dikonsumsi anak-anak wajib lezat.

Di era  sekarang, anda sebenarnya mampu mengorder hidangan yang sudah jadi tanpa harus ribet mengolahnya terlebih dahulu. Tetapi banyak juga lho mereka yang memang mau menghidangkan yang terbaik untuk keluarganya. Lantaran, menyajikan masakan sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan orang tercinta. 



Mungkinkah kamu salah satu penggemar sempol tanpa ayam?. Asal kamu tahu, sempol tanpa ayam merupakan sajian khas di Nusantara yang kini digemari oleh kebanyakan orang dari hampir setiap daerah di Indonesia. Kalian bisa menyajikan sempol tanpa ayam hasil sendiri di rumahmu dan dapat dijadikan santapan kegemaranmu di akhir pekan.

Anda tidak perlu bingung untuk memakan sempol tanpa ayam, lantaran sempol tanpa ayam mudah untuk ditemukan dan juga kita pun bisa membuatnya sendiri di tempatmu. sempol tanpa ayam dapat dimasak dengan berbagai cara. Kini telah banyak resep modern yang menjadikan sempol tanpa ayam semakin mantap.

Resep sempol tanpa ayam pun mudah sekali untuk dibuat, lho. Kamu jangan capek-capek untuk membeli sempol tanpa ayam, lantaran Anda dapat menghidangkan di rumah sendiri. Untuk Kita yang akan membuatnya, berikut cara menyajikan sempol tanpa ayam yang enak yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Sempol tanpa ayam:

1. Siapkan 10 sdm terigu
1. Gunakan 6 sdm kanji
1. Sediakan 3 siung bawang putih  goreng,hancurkan
1. Ambil 3 siung bawang merah  goreng,hancurkan
1. Sediakan 1 batang daun bawang  iris tipis
1. Ambil secukupnya garam,penyedap
1. Gunakan 100 ml air  (kira2 aja smpai bisa di bulatkan)
1. Sediakan 1 buah wortel parut tambahan bisa dikasih
1. Siapkan 1 buah telur ayam,kocok lepas




<!--inarticleads2-->

##### Langkah-langkah membuat Sempol tanpa ayam:

1. Campur semua bahan kecuali air sampai rata
1. Tambahan air sedikit demi sedikit,uleni kalis(ga lengket ditangan)
1. Bentuk bulat atau sesuai selera,me lonjong gini...
<img src="https://img-global.cpcdn.com/steps/cb649b3e7d91f866/160x128cq70/sempol-tanpa-ayam-langkah-memasak-3-foto.jpg" alt="Sempol tanpa ayam">1. Rebus di air mendidih sampai ngapung,angkat,dinginkan
1. Baru di tusuk pake lidi
1. Masukan ke kocokan telur,goreng Kalau mau telurnya lebih tebal,masukan lagi ke kocokan telur dan goreng smp warna kecoklatan




Ternyata cara membuat sempol tanpa ayam yang enak simple ini gampang sekali ya! Kamu semua mampu mencobanya. Resep sempol tanpa ayam Sangat sesuai banget buat kamu yang baru akan belajar memasak maupun untuk kalian yang sudah ahli dalam memasak.

Tertarik untuk mulai mencoba membikin resep sempol tanpa ayam enak simple ini? Kalau kalian mau, mending kamu segera siapkan alat dan bahannya, setelah itu bikin deh Resep sempol tanpa ayam yang lezat dan simple ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada anda berfikir lama-lama, maka langsung aja hidangkan resep sempol tanpa ayam ini. Dijamin kamu tak akan menyesal sudah buat resep sempol tanpa ayam nikmat simple ini! Selamat mencoba dengan resep sempol tanpa ayam mantab tidak ribet ini di rumah sendiri,ya!.

