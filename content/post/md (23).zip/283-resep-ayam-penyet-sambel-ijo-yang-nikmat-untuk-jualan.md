---
description: "Resep *Ayam Penyet Sambel Ijo* yang nikmat Untuk Jualan"
title: "Resep *Ayam Penyet Sambel Ijo* yang nikmat Untuk Jualan"
slug: 283-resep-ayam-penyet-sambel-ijo-yang-nikmat-untuk-jualan
date: 2021-02-13T20:50:40.595Z
image: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
author: Leroy Hicks
ratingvalue: 3.4
reviewcount: 15
recipeingredient:
- "1/2 ekor ayam"
- "1 btg sereh"
- "2 lbr daun jeruk"
- " Bumbu ungkep ayam "
- "4 siung bwg merah Sy skip"
- "3 siung bwg putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt ketumbar"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya kaldu jamur sy skip"
- "Secukupnya air"
- " Bumbu sambel ijo "
- "8 cabe ijo keriting"
- "2 cabe ijo besar"
- "10 cabe rawit ijo"
- "1 buah tomat ijo"
- "3 siung bwg merah"
- "3 siung bwg putih"
- "2 sdm bumbu dasar cabe ijo tambahan sy           lihat resep"
recipeinstructions:
- "Cuci bersih ayam rebus hingga mendidih, angkat lalu rebus lagi bersama bumbu lainnya hingga bumbu meyerap dan airnya mengering. Lalu goreng hingga matang (sy, tidak terlalu kering), angkat sisihkan."
- "Cuci bahan sambal, potong2 lalu goreng hingga matang. Kemudian ulek kasar saja"
- "Tambahkan bumbu dasar cabe ijo, beri garam dan gula. Ulek hingga tercampur rata"
- "Taruh ayam goreng diatas.sambal lalu penyet dengan ulekan dan pindahkan dalam wadah saji"
- "Daan ayam penyet sambal ijo siap disajikan, ditambah perasan air jeruk nipis lebih enak"
categories:
- Resep
tags:
- ayam
- penyet
- sambel

katakunci: ayam penyet sambel 
nutrition: 252 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![*Ayam Penyet Sambel Ijo*](https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg)

Selaku seorang ibu, menyajikan masakan menggugah selera bagi famili adalah hal yang menyenangkan bagi anda sendiri. Tanggung jawab seorang ibu Tidak sekedar mengurus rumah saja, tapi kamu juga wajib memastikan keperluan gizi tercukupi dan juga santapan yang disantap anak-anak mesti menggugah selera.

Di zaman  saat ini, anda sebenarnya dapat memesan olahan instan walaupun tanpa harus capek membuatnya dulu. Tapi ada juga mereka yang selalu mau memberikan hidangan yang terenak bagi orang yang dicintainya. Sebab, menyajikan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan seorang penyuka *ayam penyet sambel ijo*?. Tahukah kamu, *ayam penyet sambel ijo* merupakan hidangan khas di Nusantara yang kini disukai oleh setiap orang dari hampir setiap daerah di Indonesia. Kalian bisa membuat *ayam penyet sambel ijo* sendiri di rumah dan boleh jadi santapan favorit di hari libur.

Kamu tak perlu bingung jika kamu ingin mendapatkan *ayam penyet sambel ijo*, sebab *ayam penyet sambel ijo* mudah untuk dicari dan kalian pun boleh menghidangkannya sendiri di tempatmu. *ayam penyet sambel ijo* dapat dimasak memalui beragam cara. Kini pun telah banyak banget cara kekinian yang membuat *ayam penyet sambel ijo* lebih lezat.

Resep *ayam penyet sambel ijo* pun mudah dihidangkan, lho. Kamu jangan repot-repot untuk memesan *ayam penyet sambel ijo*, tetapi Kalian bisa menghidangkan di rumahmu. Untuk Kalian yang hendak mencobanya, di bawah ini adalah resep untuk menyajikan *ayam penyet sambel ijo* yang mantab yang bisa Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan *Ayam Penyet Sambel Ijo*:

1. Ambil 1/2 ekor ayam
1. Siapkan 1 btg sereh
1. Gunakan 2 lbr daun jeruk
1. Gunakan  Bumbu ungkep ayam :
1. Ambil 4 siung bwg merah (Sy, skip)
1. Sediakan 3 siung bwg putih
1. Sediakan 1 ruas jahe
1. Gunakan 1 ruas kunyit
1. Siapkan 1 sdt ketumbar
1. Sediakan Secukupnya garam
1. Gunakan Secukupnya gula
1. Ambil Secukupnya kaldu jamur (sy, skip)
1. Gunakan Secukupnya air
1. Ambil  Bumbu sambel ijo :
1. Sediakan 8 cabe ijo keriting
1. Siapkan 2 cabe ijo besar
1. Gunakan 10 cabe rawit ijo
1. Sediakan 1 buah tomat ijo
1. Gunakan 3 siung bwg merah
1. Gunakan 3 siung bwg putih
1. Sediakan 2 sdm bumbu dasar cabe ijo (tambahan sy)           (lihat resep)




<!--inarticleads2-->

##### Cara membuat *Ayam Penyet Sambel Ijo*:

1. Cuci bersih ayam rebus hingga mendidih, angkat lalu rebus lagi bersama bumbu lainnya hingga bumbu meyerap dan airnya mengering. Lalu goreng hingga matang (sy, tidak terlalu kering), angkat sisihkan.
1. Cuci bahan sambal, potong2 lalu goreng hingga matang. Kemudian ulek kasar saja
1. Tambahkan bumbu dasar cabe ijo, beri garam dan gula. Ulek hingga tercampur rata
1. Taruh ayam goreng diatas.sambal lalu penyet dengan ulekan dan pindahkan dalam wadah saji
1. Daan ayam penyet sambal ijo siap disajikan, ditambah perasan air jeruk nipis lebih enak




Ternyata resep *ayam penyet sambel ijo* yang mantab sederhana ini mudah sekali ya! Kamu semua dapat membuatnya. Cara Membuat *ayam penyet sambel ijo* Cocok banget untuk kalian yang baru akan belajar memasak maupun untuk kalian yang sudah hebat memasak.

Tertarik untuk mulai mencoba membikin resep *ayam penyet sambel ijo* enak tidak rumit ini? Kalau kamu mau, mending kamu segera buruan menyiapkan peralatan dan bahan-bahannya, lantas buat deh Resep *ayam penyet sambel ijo* yang enak dan tidak rumit ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kamu diam saja, yuk kita langsung saja bikin resep *ayam penyet sambel ijo* ini. Dijamin kamu tiidak akan menyesal sudah bikin resep *ayam penyet sambel ijo* enak simple ini! Selamat mencoba dengan resep *ayam penyet sambel ijo* lezat tidak rumit ini di rumah kalian sendiri,ya!.

