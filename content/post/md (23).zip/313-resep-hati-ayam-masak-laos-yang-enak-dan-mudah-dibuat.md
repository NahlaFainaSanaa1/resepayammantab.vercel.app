---
description: "Resep Hati Ayam Masak Laos yang enak dan Mudah Dibuat"
title: "Resep Hati Ayam Masak Laos yang enak dan Mudah Dibuat"
slug: 313-resep-hati-ayam-masak-laos-yang-enak-dan-mudah-dibuat
date: 2021-04-11T23:43:50.513Z
image: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
author: Ryan Munoz
ratingvalue: 3.5
reviewcount: 15
recipeingredient:
- "300 gr Hati Ayam"
- "1 buah jeruk nipis"
- "2 lembar daun salam"
- "2 batang sereh keprek"
- "Secukupnya garamgulakaldu bubuk"
- "50 g laos  lengkuas diblender"
- "Secukupnya air dan minyak goreng"
- " Bumbu halus"
- "5 bawang merah"
- "3 bawang putih"
- "3 buah kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "Sejumput jinten"
- "1 sdm ketumbar"
recipeinstructions:
- "Cuci bersih hati ayam, beri air jeruk nipis, ratakan dan diamkan 5 menit, kemudian bilas hingga bersih."
- "Blender laos atau diparut. Ukek atau proses bumbu halusnya."
- "Panaskan minyak dan tumis bumbu halus hingga tercium aroma yang harum, lalu masukkan serai dan daun salam, dan laos parut."
- "Masukkan hati ayam, aduk perlahan jingga hati ayam berubah warna dan kaku. Setelah itu beri air, garam, gula dan kaldu bubuk. Cek rasa.. Masak hingga airnya sat."
- "Kemudian goreng hati ayam hingga kecoklatan dan bumbu laosnya mengering. Jadi deh🥰"
categories:
- Resep
tags:
- hati
- ayam
- masak

katakunci: hati ayam masak 
nutrition: 122 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dinner

---


![Hati Ayam Masak Laos](https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan hidangan mantab bagi famili merupakan hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang istri Tidak hanya menjaga rumah saja, namun anda juga harus memastikan kebutuhan gizi tercukupi dan juga santapan yang dikonsumsi anak-anak wajib sedap.

Di era  saat ini, kalian sebenarnya mampu memesan olahan yang sudah jadi meski tanpa harus capek mengolahnya lebih dulu. Tapi banyak juga mereka yang selalu ingin memberikan yang terbaik bagi keluarganya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan selera keluarga. 



Mungkinkah anda adalah salah satu penikmat hati ayam masak laos?. Asal kamu tahu, hati ayam masak laos adalah makanan khas di Nusantara yang kini disenangi oleh setiap orang di berbagai wilayah di Indonesia. Anda bisa menyajikan hati ayam masak laos sendiri di rumahmu dan boleh dijadikan makanan favoritmu di hari liburmu.

Anda tidak perlu bingung untuk mendapatkan hati ayam masak laos, karena hati ayam masak laos gampang untuk didapatkan dan juga anda pun boleh mengolahnya sendiri di rumah. hati ayam masak laos bisa diolah memalui beraneka cara. Kini telah banyak resep kekinian yang menjadikan hati ayam masak laos semakin lebih nikmat.

Resep hati ayam masak laos pun sangat gampang untuk dibikin, lho. Kita jangan ribet-ribet untuk memesan hati ayam masak laos, sebab Kalian dapat menghidangkan di rumah sendiri. Untuk Kamu yang hendak membuatnya, berikut ini resep menyajikan hati ayam masak laos yang mantab yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Hati Ayam Masak Laos:

1. Ambil 300 gr Hati Ayam
1. Ambil 1 buah jeruk nipis
1. Ambil 2 lembar daun salam
1. Gunakan 2 batang sereh keprek
1. Siapkan Secukupnya garam,gula,kaldu bubuk
1. Gunakan 50 g laos / lengkuas diblender
1. Ambil Secukupnya air dan minyak goreng
1. Sediakan  Bumbu halus:
1. Ambil 5 bawang merah
1. Sediakan 3 bawang putih
1. Gunakan 3 buah kemiri
1. Ambil 1 ruas jahe
1. Sediakan 1 ruas kunyit
1. Ambil Sejumput jinten
1. Sediakan 1 sdm ketumbar




<!--inarticleads2-->

##### Langkah-langkah membuat Hati Ayam Masak Laos:

1. Cuci bersih hati ayam, beri air jeruk nipis, ratakan dan diamkan 5 menit, kemudian bilas hingga bersih.
1. Blender laos atau diparut. Ukek atau proses bumbu halusnya.
1. Panaskan minyak dan tumis bumbu halus hingga tercium aroma yang harum, lalu masukkan serai dan daun salam, dan laos parut.
1. Masukkan hati ayam, aduk perlahan jingga hati ayam berubah warna dan kaku. Setelah itu beri air, garam, gula dan kaldu bubuk. Cek rasa.. Masak hingga airnya sat.
1. Kemudian goreng hati ayam hingga kecoklatan dan bumbu laosnya mengering. Jadi deh🥰




Wah ternyata cara buat hati ayam masak laos yang mantab tidak rumit ini gampang banget ya! Anda Semua dapat mencobanya. Cara buat hati ayam masak laos Sangat sesuai banget buat anda yang baru belajar memasak maupun juga bagi anda yang telah hebat dalam memasak.

Tertarik untuk mulai mencoba membuat resep hati ayam masak laos enak tidak ribet ini? Kalau kalian ingin, ayo kamu segera buruan siapin alat-alat dan bahannya, maka buat deh Resep hati ayam masak laos yang nikmat dan tidak rumit ini. Betul-betul mudah kan. 

Jadi, ketimbang kita diam saja, ayo kita langsung saja hidangkan resep hati ayam masak laos ini. Pasti anda tiidak akan nyesel membuat resep hati ayam masak laos lezat tidak rumit ini! Selamat berkreasi dengan resep hati ayam masak laos nikmat tidak ribet ini di tempat tinggal sendiri,ya!.

