---
description: "Resep Sop Ayam Rumah Sederhana yang nikmat Untuk Jualan"
title: "Resep Sop Ayam Rumah Sederhana yang nikmat Untuk Jualan"
slug: 338-resep-sop-ayam-rumah-sederhana-yang-nikmat-untuk-jualan
date: 2021-03-26T07:40:13.051Z
image: https://img-global.cpcdn.com/recipes/0020aeecb3497e3d/680x482cq70/sop-ayam-rumah-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0020aeecb3497e3d/680x482cq70/sop-ayam-rumah-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0020aeecb3497e3d/680x482cq70/sop-ayam-rumah-sederhana-foto-resep-utama.jpg
author: Roy Sanchez
ratingvalue: 4.3
reviewcount: 10
recipeingredient:
- "1/2 ekor ayam"
- "1 buah wortel"
- "2 lembar kol tambahan saya sendiri"
- "1 buah kentang tambahan saya sendiri"
- "Secukupnya daun seledri"
- "700 ml air"
- " Bumbu halus"
- "4 butir bawang merah"
- "2 siung bawang putih"
- "5 butir lada"
- "Secukupnya jahe"
- "Secukupnya kaskas"
- "Secukupnya pala"
- "  Bumbu Cemplung"
- "3 buah cengkeh"
- "2 kelopak bunga lawang"
- "1 buah kapulaga"
- "1/2 ruas kayu manis"
- "1/2 sdt garam secukupnya"
- "1/2 sdm gula pasir secukupnya"
- "Secukupnya penyedap rasa saya kaldu jamur"
- " Pelengkap"
- " Jeruk nipis"
- " Cabe rawit"
recipeinstructions:
- "Didihkan air, rebus ayam yang sudah dibersihkan dan dipotong-potong. Rebus sampai kotoran dan lemak-lemak nya keluar, lalu buang air rebusannya."
- "Tambahkan air yang baru kurleb 700ml, rebus."
- "Sambil menunggu ayam mendidih haluskan bumbu dan siapkan bumbu cemplung nya."
- "Setelah bumbu halus sudah jadi, tumis bumbu halus hingga harum dengan secukupnya minyak goreng."
- "Masukkan bumbu halus, bumbu cemplung, gula, garam dan kaldu jamur, aduk rata dan test rasa."
- "Terakhir masukkan kentang, wortel dan kol, masak hingga ayam empuk dan kentang wortel kol matang."
- "Sajikan dengan nasi hangat dan pelengkap."
categories:
- Resep
tags:
- sop
- ayam
- rumah

katakunci: sop ayam rumah 
nutrition: 182 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dinner

---


![Sop Ayam Rumah Sederhana](https://img-global.cpcdn.com/recipes/0020aeecb3497e3d/680x482cq70/sop-ayam-rumah-sederhana-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan santapan mantab buat keluarga merupakan hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang ibu Tidak cuma menjaga rumah saja, tetapi kamu pun wajib menyediakan kebutuhan nutrisi terpenuhi dan juga hidangan yang disantap orang tercinta wajib menggugah selera.

Di waktu  sekarang, anda memang mampu mengorder olahan praktis meski tidak harus ribet mengolahnya lebih dulu. Tapi banyak juga lho orang yang selalu ingin memberikan yang terenak bagi orang tercintanya. Karena, memasak sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan orang tercinta. 



Apakah anda seorang penikmat sop ayam rumah sederhana?. Tahukah kamu, sop ayam rumah sederhana adalah makanan khas di Indonesia yang sekarang disukai oleh orang-orang dari berbagai wilayah di Indonesia. Kalian dapat memasak sop ayam rumah sederhana buatan sendiri di rumahmu dan dapat dijadikan makanan favorit di hari libur.

Kalian tak perlu bingung jika kamu ingin menyantap sop ayam rumah sederhana, lantaran sop ayam rumah sederhana mudah untuk dicari dan juga kamu pun dapat memasaknya sendiri di tempatmu. sop ayam rumah sederhana dapat dimasak dengan bermacam cara. Saat ini ada banyak cara modern yang membuat sop ayam rumah sederhana lebih mantap.

Resep sop ayam rumah sederhana pun mudah dibikin, lho. Anda jangan repot-repot untuk memesan sop ayam rumah sederhana, sebab Kalian bisa menghidangkan di rumahmu. Untuk Anda yang hendak menyajikannya, di bawah ini adalah cara untuk membuat sop ayam rumah sederhana yang enak yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Sop Ayam Rumah Sederhana:

1. Siapkan 1/2 ekor ayam
1. Gunakan 1 buah wortel
1. Ambil 2 lembar kol (tambahan saya sendiri)
1. Gunakan 1 buah kentang (tambahan saya sendiri)
1. Sediakan Secukupnya daun seledri
1. Gunakan 700 ml air
1. Sediakan  🧅Bumbu halus:
1. Gunakan 4 butir bawang merah
1. Gunakan 2 siung bawang putih
1. Siapkan 5 butir lada
1. Gunakan Secukupnya jahe
1. Sediakan Secukupnya kas-kas
1. Sediakan Secukupnya pala
1. Ambil  🧅 Bumbu Cemplung:
1. Sediakan 3 buah cengkeh
1. Sediakan 2 kelopak bunga lawang
1. Sediakan 1 buah kapulaga
1. Sediakan 1/2 ruas kayu manis
1. Ambil 1/2 sdt garam (secukupnya)
1. Ambil 1/2 sdm gula pasir (secukupnya)
1. Sediakan Secukupnya penyedap rasa (saya: kaldu jamur)
1. Sediakan  Pelengkap:
1. Ambil  Jeruk nipis
1. Siapkan  Cabe rawit




<!--inarticleads2-->

##### Langkah-langkah membuat Sop Ayam Rumah Sederhana:

1. Didihkan air, rebus ayam yang sudah dibersihkan dan dipotong-potong. Rebus sampai kotoran dan lemak-lemak nya keluar, lalu buang air rebusannya.
1. Tambahkan air yang baru kurleb 700ml, rebus.
1. Sambil menunggu ayam mendidih haluskan bumbu dan siapkan bumbu cemplung nya.
1. Setelah bumbu halus sudah jadi, tumis bumbu halus hingga harum dengan secukupnya minyak goreng.
1. Masukkan bumbu halus, bumbu cemplung, gula, garam dan kaldu jamur, aduk rata dan test rasa.
1. Terakhir masukkan kentang, wortel dan kol, masak hingga ayam empuk dan kentang wortel kol matang.
1. Sajikan dengan nasi hangat dan pelengkap.




Wah ternyata cara buat sop ayam rumah sederhana yang lezat simple ini enteng banget ya! Kalian semua bisa membuatnya. Cara buat sop ayam rumah sederhana Sangat cocok banget buat kalian yang baru belajar memasak maupun juga bagi kalian yang telah hebat memasak.

Apakah kamu tertarik mencoba bikin resep sop ayam rumah sederhana lezat sederhana ini? Kalau anda ingin, ayo kamu segera siapkan peralatan dan bahan-bahannya, setelah itu buat deh Resep sop ayam rumah sederhana yang nikmat dan tidak ribet ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang anda diam saja, hayo langsung aja bikin resep sop ayam rumah sederhana ini. Pasti kalian tak akan nyesel bikin resep sop ayam rumah sederhana enak simple ini! Selamat berkreasi dengan resep sop ayam rumah sederhana lezat sederhana ini di tempat tinggal masing-masing,oke!.

