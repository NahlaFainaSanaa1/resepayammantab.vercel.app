---
description: "Resep Lontong Opor Ayam yang lezat Untuk Jualan"
title: "Resep Lontong Opor Ayam yang lezat Untuk Jualan"
slug: 392-resep-lontong-opor-ayam-yang-lezat-untuk-jualan
date: 2021-04-03T12:48:27.469Z
image: https://img-global.cpcdn.com/recipes/0aef541c86847900/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0aef541c86847900/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0aef541c86847900/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
author: Timothy Ball
ratingvalue: 4.4
reviewcount: 11
recipeingredient:
- " Lontong           lihat resep"
- "1 ekor ayam potong2 jadi 12 potong"
- "6 butir telur rebus lalu goreng sebentar"
- "6 potong tahu putih potong dadu goreng"
- "2 batang sereh memarkan"
- "2 lembar daun salam"
- "1 biji bunga lawang"
- "3 biji kapulaga"
- "1 ruas kayumanis"
- "1 pala geprek"
- "3 lembar daun jeruk purut"
- "400 ml santan kental"
- "200 ml air"
- " bawang merah goreng secukupnya untuk taburan"
- " Bumbu Halus"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "4 buah kemiri"
- "1-2 cabe merah tergantung selera"
- "1 sdt ketumbar bubuk"
- "1 sdt jinten"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt merica"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "Sedikit kaldu jamur skip"
- "secukupnya garam"
- "25 g gula merah menurut selera"
recipeinstructions:
- "Bersihkan ayam, tumis bumbu halus, sereh, daun jeruk purut dan daun salam sampai harum."
- "Masukkan ayam tuangi air, tutup panci, didihkan."
- "Kemudian masukkan santan kental, kembali didihkan sambil dididihkan masukkan tahu, telur kemudian beri garam, kaldu jamur, gula, koreksi rasa."
- "Tata lontong dalam mangkuk, siram dengan kuah opor tambahkan dgn taburan bawang merah goreng."
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 213 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dinner

---


![Lontong Opor Ayam](https://img-global.cpcdn.com/recipes/0aef541c86847900/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan masakan nikmat buat keluarga tercinta adalah hal yang sangat menyenangkan bagi kita sendiri. Tanggung jawab seorang  wanita bukan sekedar menjaga rumah saja, namun anda juga wajib memastikan keperluan gizi tercukupi dan hidangan yang dimakan orang tercinta harus mantab.

Di zaman  saat ini, kalian sebenarnya mampu membeli santapan yang sudah jadi walaupun tidak harus repot membuatnya terlebih dahulu. Tapi ada juga lho orang yang selalu ingin memberikan makanan yang terbaik untuk orang tercintanya. Karena, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan seorang penggemar lontong opor ayam?. Tahukah kamu, lontong opor ayam merupakan makanan khas di Indonesia yang sekarang digemari oleh kebanyakan orang di hampir setiap tempat di Nusantara. Kita dapat menghidangkan lontong opor ayam sendiri di rumah dan boleh dijadikan makanan favorit di akhir pekan.

Kamu jangan bingung untuk memakan lontong opor ayam, sebab lontong opor ayam sangat mudah untuk dicari dan juga kalian pun dapat membuatnya sendiri di rumah. lontong opor ayam dapat dibuat lewat bermacam cara. Kini pun ada banyak cara modern yang membuat lontong opor ayam semakin lebih nikmat.

Resep lontong opor ayam juga sangat mudah dibikin, lho. Kamu tidak usah capek-capek untuk membeli lontong opor ayam, karena Kalian dapat membuatnya di rumahmu. Bagi Kita yang mau menghidangkannya, di bawah ini adalah cara menyajikan lontong opor ayam yang mantab yang bisa Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Lontong Opor Ayam:

1. Siapkan  Lontong           (lihat resep)
1. Sediakan 1 ekor ayam potong2 jadi 12 potong
1. Ambil 6 butir telur rebus lalu goreng sebentar
1. Ambil 6 potong tahu putih potong dadu goreng
1. Ambil 2 batang sereh memarkan
1. Ambil 2 lembar daun salam
1. Siapkan 1 biji bunga lawang
1. Gunakan 3 biji kapulaga
1. Gunakan 1 ruas kayumanis
1. Gunakan 1 pala geprek
1. Siapkan 3 lembar daun jeruk purut
1. Ambil 400 ml santan kental
1. Sediakan 200 ml air
1. Gunakan  bawang merah goreng secukupnya untuk taburan
1. Gunakan  Bumbu Halus
1. Siapkan 7 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Gunakan 4 buah kemiri
1. Gunakan 1-2 cabe merah/ tergantung selera
1. Gunakan 1 sdt ketumbar bubuk
1. Siapkan 1 sdt jinten
1. Gunakan 1/2 sdt kunyit bubuk
1. Sediakan 1/2 sdt merica
1. Siapkan 1 ruas jahe
1. Siapkan 1 ruas lengkuas
1. Siapkan Sedikit kaldu jamur (skip)
1. Ambil secukupnya garam
1. Siapkan 25 g gula merah/ menurut selera




<!--inarticleads2-->

##### Cara menyiapkan Lontong Opor Ayam:

1. Bersihkan ayam, tumis bumbu halus, sereh, daun jeruk purut dan daun salam sampai harum.
1. Masukkan ayam tuangi air, tutup panci, didihkan.
1. Kemudian masukkan santan kental, kembali didihkan sambil dididihkan masukkan tahu, telur kemudian beri garam, kaldu jamur, gula, koreksi rasa.
1. Tata lontong dalam mangkuk, siram dengan kuah opor tambahkan dgn taburan bawang merah goreng.




Ternyata cara buat lontong opor ayam yang enak tidak rumit ini gampang sekali ya! Semua orang dapat menghidangkannya. Resep lontong opor ayam Sangat sesuai sekali untuk kamu yang baru akan belajar memasak ataupun juga bagi kalian yang sudah ahli memasak.

Tertarik untuk mencoba membuat resep lontong opor ayam mantab tidak rumit ini? Kalau kalian ingin, yuk kita segera menyiapkan alat dan bahan-bahannya, maka buat deh Resep lontong opor ayam yang mantab dan simple ini. Sangat gampang kan. 

Maka, ketimbang kamu berfikir lama-lama, hayo langsung aja buat resep lontong opor ayam ini. Pasti kamu tak akan nyesel membuat resep lontong opor ayam enak tidak ribet ini! Selamat berkreasi dengan resep lontong opor ayam enak tidak ribet ini di rumah sendiri,oke!.

