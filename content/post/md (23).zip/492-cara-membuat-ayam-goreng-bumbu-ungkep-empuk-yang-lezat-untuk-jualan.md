---
description: "Cara membuat Ayam Goreng Bumbu ungkep empuk yang lezat Untuk Jualan"
title: "Cara membuat Ayam Goreng Bumbu ungkep empuk yang lezat Untuk Jualan"
slug: 492-cara-membuat-ayam-goreng-bumbu-ungkep-empuk-yang-lezat-untuk-jualan
date: 2021-01-17T01:03:29.290Z
image: https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg
author: Evelyn Mack
ratingvalue: 4.4
reviewcount: 7
recipeingredient:
- "2 kilo ayam biasa"
- "1 kilo dipotong 12 potong"
- "2 buah jeruk nipis"
- "4 batang sereh geprek"
- "4 lembar daun salam"
- "6 lembar daun jeruk"
- "Secukupnya garam"
- "Secukupnya penyedap rasa ayam  kaldu Jamur"
- "300 ml air"
- " Bumbu halus "
- "20 siung bawang merah"
- "10 siung bawang putih"
- "1 jempol jahe"
- "1 jempol kunyit"
- "1 jmpol lengkuas"
- "2 sdm ketumbar bubuk"
- "1 sdm ladabubuk"
recipeinstructions:
- "Cuci bersih ayam,Marinasi dngan jeruk nipis diamkan 15 mnt,lalu Cuci bersih ayam tiriskan"
- "Haluskan bumbu lalu balurkan bumbu halus ke potongan ayam. Tambahkan sereh, daun salam, daun jeruk, garam dan penyedap rasa ayam. Aduk rata. Lalu beri air."
- "Masak atau ungkep ayam dengan api kecil sampai ayam matang. Jangan lupa ditutup agar matang sempurna. Angkat."
- ""
- "Goreng ayam sampai berwarna coklat keemasan."
- "Sajikan dengan nasi panas Dan sambal goreng nikmat alhamdulillh 😍🥰❤️💋"
categories:
- Resep
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Goreng Bumbu ungkep empuk](https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan masakan menggugah selera pada famili merupakan hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang  wanita Tidak cuma mengerjakan pekerjaan rumah saja, tapi kamu pun harus menyediakan keperluan gizi terpenuhi dan santapan yang disantap orang tercinta harus nikmat.

Di era  saat ini, kita memang mampu mengorder olahan jadi walaupun tidak harus susah membuatnya dulu. Tapi ada juga mereka yang memang ingin memberikan yang terbaik bagi orang yang dicintainya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai selera orang tercinta. 



Mungkinkah anda seorang penggemar ayam goreng bumbu ungkep empuk?. Asal kamu tahu, ayam goreng bumbu ungkep empuk merupakan hidangan khas di Indonesia yang kini disenangi oleh orang-orang dari hampir setiap tempat di Nusantara. Kita dapat memasak ayam goreng bumbu ungkep empuk olahan sendiri di rumah dan pasti jadi makanan favorit di akhir pekan.

Kalian jangan bingung jika kamu ingin menyantap ayam goreng bumbu ungkep empuk, karena ayam goreng bumbu ungkep empuk tidak sukar untuk didapatkan dan anda pun boleh menghidangkannya sendiri di tempatmu. ayam goreng bumbu ungkep empuk bisa dimasak memalui beraneka cara. Sekarang sudah banyak banget resep modern yang membuat ayam goreng bumbu ungkep empuk lebih nikmat.

Resep ayam goreng bumbu ungkep empuk juga gampang sekali untuk dibuat, lho. Anda jangan ribet-ribet untuk memesan ayam goreng bumbu ungkep empuk, sebab Kita dapat menghidangkan ditempatmu. Untuk Anda yang hendak mencobanya, berikut resep untuk menyajikan ayam goreng bumbu ungkep empuk yang lezat yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Goreng Bumbu ungkep empuk:

1. Siapkan 2 kilo ayam biasa
1. Gunakan 1 kilo dipotong 12 potong
1. Siapkan 2 buah jeruk nipis
1. Sediakan 4 batang sereh, geprek
1. Sediakan 4 lembar daun salam
1. Sediakan 6 lembar daun jeruk
1. Sediakan Secukupnya garam
1. Sediakan Secukupnya penyedap rasa ayam / kaldu Jamur
1. Gunakan 300 ml air
1. Gunakan  Bumbu halus :
1. Ambil 20 siung bawang merah
1. Gunakan 10 siung bawang putih
1. Ambil 1 jempol jahe
1. Siapkan 1 jempol kunyit
1. Ambil 1 jmpol lengkuas
1. Siapkan 2 sdm ketumbar bubuk
1. Gunakan 1 sdm ladabubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Bumbu ungkep empuk:

1. Cuci bersih ayam,Marinasi dngan jeruk nipis diamkan 15 mnt,lalu Cuci bersih ayam tiriskan
1. Haluskan bumbu lalu balurkan bumbu halus ke potongan ayam. Tambahkan sereh, daun salam, daun jeruk, garam dan penyedap rasa ayam. Aduk rata. Lalu beri air.
1. Masak atau ungkep ayam dengan api kecil sampai ayam matang. Jangan lupa ditutup agar matang sempurna. Angkat.
1. 
1. Goreng ayam sampai berwarna coklat keemasan.
1. Sajikan dengan nasi panas Dan sambal goreng nikmat alhamdulillh 😍🥰❤️💋




Ternyata cara membuat ayam goreng bumbu ungkep empuk yang enak sederhana ini mudah banget ya! Kalian semua dapat membuatnya. Resep ayam goreng bumbu ungkep empuk Sangat cocok sekali buat anda yang sedang belajar memasak ataupun bagi kalian yang sudah ahli memasak.

Apakah kamu ingin mencoba membikin resep ayam goreng bumbu ungkep empuk mantab tidak ribet ini? Kalau mau, ayo kalian segera buruan siapin alat-alat dan bahan-bahannya, lantas buat deh Resep ayam goreng bumbu ungkep empuk yang nikmat dan sederhana ini. Sungguh gampang kan. 

Oleh karena itu, daripada kita berlama-lama, hayo langsung aja hidangkan resep ayam goreng bumbu ungkep empuk ini. Dijamin kalian gak akan menyesal sudah buat resep ayam goreng bumbu ungkep empuk lezat sederhana ini! Selamat mencoba dengan resep ayam goreng bumbu ungkep empuk lezat sederhana ini di rumah kalian masing-masing,ya!.

