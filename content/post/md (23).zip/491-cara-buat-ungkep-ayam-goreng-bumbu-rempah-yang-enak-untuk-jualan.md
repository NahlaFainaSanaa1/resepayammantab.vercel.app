---
description: "Cara buat Ungkep ayam goreng bumbu rempah yang enak Untuk Jualan"
title: "Cara buat Ungkep ayam goreng bumbu rempah yang enak Untuk Jualan"
slug: 491-cara-buat-ungkep-ayam-goreng-bumbu-rempah-yang-enak-untuk-jualan
date: 2021-05-20T10:05:58.980Z
image: https://img-global.cpcdn.com/recipes/9d63e12ddd391432/680x482cq70/ungkep-ayam-goreng-bumbu-rempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d63e12ddd391432/680x482cq70/ungkep-ayam-goreng-bumbu-rempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d63e12ddd391432/680x482cq70/ungkep-ayam-goreng-bumbu-rempah-foto-resep-utama.jpg
author: Willie Fuller
ratingvalue: 3.3
reviewcount: 15
recipeingredient:
- "1 ekor ayam potong 8 bagian"
- "1 buah jeruk nipis"
- "1/2 sdm garam"
- "500 ml air kelapa aku ganti dg 65 ml santan instan  400 ml air"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "2 sdm air asam jawa"
- "2-3 sdt garam"
- " Bumbu halus"
- "1 bonggol lengkuas"
- "3 batang serai ambil bagian putihnya"
- "1/2 cm jahe"
- "3 cm kunyit"
- "1 sdm ketumbar sangrai"
- "5 butir kemiri sangrai"
- "6 siung bawang merah"
- "4 siung bawang putih"
recipeinstructions:
- "Siapkan ayam, remas dengan garam dan air perasan jeruk nipis. Diamkan 15 menit lalu cuci bersih."
- "Haluskan semua bumbu."
- "Siapkan wajan. Masukan potongan ayam dan beri bumbu halus, remas dan aduk ayam bersama bumbu. Diamkan selama 15 menit."
- "Tuangkan santan instan dan 400 ml air kedalam wajan, tuang semua bumbu lainnya. Kemudian rebus ayam dengan api sedang. Aduk sesekali masak hingga matang, air habis dan kering. *tambahkan air jika ayam belum matang."
- "Goreng ayam atau bisa sebagai stok lauk dikulkas pindahkan dalam wadah kedap udara utk disimpan."
categories:
- Resep
tags:
- ungkep
- ayam
- goreng

katakunci: ungkep ayam goreng 
nutrition: 226 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Ungkep ayam goreng bumbu rempah](https://img-global.cpcdn.com/recipes/9d63e12ddd391432/680x482cq70/ungkep-ayam-goreng-bumbu-rempah-foto-resep-utama.jpg)

Andai kalian seorang yang hobi masak, mempersiapkan masakan nikmat bagi keluarga merupakan suatu hal yang memuaskan bagi anda sendiri. Tanggung jawab seorang ibu bukan saja menangani rumah saja, namun anda juga harus memastikan keperluan nutrisi terpenuhi dan juga olahan yang disantap keluarga tercinta harus lezat.

Di zaman  sekarang, kita memang dapat membeli santapan praktis walaupun tidak harus ribet memasaknya terlebih dahulu. Tapi banyak juga lho mereka yang memang ingin memberikan makanan yang terbaik untuk orang tercintanya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera keluarga. 



Mungkinkah anda merupakan seorang penggemar ungkep ayam goreng bumbu rempah?. Tahukah kamu, ungkep ayam goreng bumbu rempah adalah makanan khas di Indonesia yang sekarang disukai oleh kebanyakan orang di hampir setiap tempat di Indonesia. Kita dapat membuat ungkep ayam goreng bumbu rempah olahan sendiri di rumahmu dan boleh jadi santapan favoritmu di hari liburmu.

Kalian tidak usah bingung untuk memakan ungkep ayam goreng bumbu rempah, sebab ungkep ayam goreng bumbu rempah tidak sukar untuk ditemukan dan juga anda pun dapat menghidangkannya sendiri di rumah. ungkep ayam goreng bumbu rempah boleh diolah dengan beraneka cara. Saat ini telah banyak resep modern yang menjadikan ungkep ayam goreng bumbu rempah semakin lezat.

Resep ungkep ayam goreng bumbu rempah juga mudah sekali dibikin, lho. Kalian tidak perlu ribet-ribet untuk membeli ungkep ayam goreng bumbu rempah, sebab Kita mampu membuatnya di rumahmu. Bagi Kamu yang mau mencobanya, di bawah ini adalah cara menyajikan ungkep ayam goreng bumbu rempah yang nikamat yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ungkep ayam goreng bumbu rempah:

1. Gunakan 1 ekor ayam, potong 8 bagian
1. Gunakan 1 buah jeruk nipis
1. Sediakan 1/2 sdm garam
1. Ambil 500 ml air kelapa *aku ganti dg 65 ml santan instan + 400 ml air
1. Gunakan 3 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Gunakan 2 sdm air asam jawa
1. Ambil 2-3 sdt garam
1. Gunakan  Bumbu halus
1. Ambil 1 bonggol lengkuas
1. Ambil 3 batang serai, ambil bagian putihnya
1. Sediakan 1/2 cm jahe
1. Sediakan 3 cm kunyit
1. Ambil 1 sdm ketumbar, sangrai
1. Siapkan 5 butir kemiri, sangrai
1. Ambil 6 siung bawang merah
1. Gunakan 4 siung bawang putih




<!--inarticleads2-->

##### Cara menyiapkan Ungkep ayam goreng bumbu rempah:

1. Siapkan ayam, remas dengan garam dan air perasan jeruk nipis. Diamkan 15 menit lalu cuci bersih.
1. Haluskan semua bumbu.
1. Siapkan wajan. Masukan potongan ayam dan beri bumbu halus, remas dan aduk ayam bersama bumbu. Diamkan selama 15 menit.
1. Tuangkan santan instan dan 400 ml air kedalam wajan, tuang semua bumbu lainnya. Kemudian rebus ayam dengan api sedang. Aduk sesekali masak hingga matang, air habis dan kering. *tambahkan air jika ayam belum matang.
1. Goreng ayam atau bisa sebagai stok lauk dikulkas pindahkan dalam wadah kedap udara utk disimpan.




Ternyata resep ungkep ayam goreng bumbu rempah yang lezat simple ini enteng sekali ya! Kita semua mampu mencobanya. Resep ungkep ayam goreng bumbu rempah Sangat cocok banget buat kita yang baru mau belajar memasak ataupun untuk anda yang sudah jago dalam memasak.

Apakah kamu ingin mulai mencoba membuat resep ungkep ayam goreng bumbu rempah mantab tidak ribet ini? Kalau anda ingin, ayo kalian segera buruan menyiapkan alat-alat dan bahannya, lalu bikin deh Resep ungkep ayam goreng bumbu rempah yang lezat dan tidak rumit ini. Sungguh gampang kan. 

Oleh karena itu, ketimbang kalian berfikir lama-lama, hayo kita langsung saja buat resep ungkep ayam goreng bumbu rempah ini. Dijamin anda tiidak akan nyesel sudah membuat resep ungkep ayam goreng bumbu rempah lezat simple ini! Selamat mencoba dengan resep ungkep ayam goreng bumbu rempah mantab tidak rumit ini di rumah kalian masing-masing,oke!.

