---
description: "Bahan-bahan Ayam masak saos teriyaki yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Ayam masak saos teriyaki yang nikmat dan Mudah Dibuat"
slug: 0-bahan-bahan-ayam-masak-saos-teriyaki-yang-nikmat-dan-mudah-dibuat
date: 2021-07-07T13:22:54.671Z
image: https://img-global.cpcdn.com/recipes/c03fde69b9e21930/680x482cq70/ayam-masak-saos-teriyaki-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c03fde69b9e21930/680x482cq70/ayam-masak-saos-teriyaki-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c03fde69b9e21930/680x482cq70/ayam-masak-saos-teriyaki-foto-resep-utama.jpg
author: Lloyd Terry
ratingvalue: 3.5
reviewcount: 10
recipeingredient:
- "3/4 dada ayam fillet potong dadu"
- "3 buah tahu potong dadu"
- "1 buah tomat potong dadu"
- "1 sch saori saos teriyaki"
- "3 sdm kecap"
- "1/2 sdt garam"
- "1 sdm kaldu jamur"
- "1 butir telur ayam kampung"
- "5 sdm tepung terigu"
- "400 cc air"
- "secukupnya minyak goreng"
- " marinasi"
- "1 siung bawang putih dihaluskan"
- "1/2 sdt merica bubuk"
- "1 sdt garam"
- " bumbu tumis"
- "3 siung bawang putih"
- "3 siung bawang merah"
- "1/2 siung bawang bombay"
- "7 buah cabai merah keriting"
- "sedikit jahe"
- "2 lembar daun salam"
- "1 lembar daun jeruk"
recipeinstructions:
- "Cuci bersih daging ayam lalu potong dadu sesuai selera. marinasi dengan bumbu marinasi. diamkan ± 1 jam."
- "Setelah itu masukkan telur ayam kampung dan tepung terigu ke dalam ayam yg telah dimarinasi. aduk hingga tercampur rata."
- "Panaskan minyak dan goreng ayam serta tahu hingga matang. sisihkan"
- "Tumis bumbu tumisan yg telah diiris2 hingga harum."
- "Masukkan ayam dan tahu yg telah digoreng, aduk2. lalu tambahkan air, saori saos teriyaki, kecap manis, garam dan kaldu jamur. aduk rata"
- "Masukkan tomat yg telah dipotong dadu, aduk2. masak hingga air surut. koreksi rasa dan sajikan"
categories:
- Resep
tags:
- ayam
- masak
- saos

katakunci: ayam masak saos 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam masak saos teriyaki](https://img-global.cpcdn.com/recipes/c03fde69b9e21930/680x482cq70/ayam-masak-saos-teriyaki-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan olahan mantab bagi orang tercinta merupakan hal yang membahagiakan untuk kita sendiri. Peran seorang ibu Tidak hanya menjaga rumah saja, tetapi anda juga wajib memastikan keperluan gizi terpenuhi dan masakan yang dimakan keluarga tercinta mesti mantab.

Di era  saat ini, kamu sebenarnya bisa membeli santapan jadi walaupun tidak harus susah membuatnya dahulu. Tetapi banyak juga mereka yang memang ingin menghidangkan yang terbaik bagi orang yang dicintainya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan orang tercinta. 

Iris serong cabai merah dan cabai hijau, potong bawang bombay, potong ayam bentuk dadu. Panaskan minyak goreng, tumis bawang bombay, cabai merah, dan cabai hijau. Lihat juga resep Ayam Jamur Saus Teriyaki enak lainnya.

Apakah anda merupakan seorang penggemar ayam masak saos teriyaki?. Asal kamu tahu, ayam masak saos teriyaki merupakan hidangan khas di Indonesia yang saat ini digemari oleh orang-orang di berbagai daerah di Nusantara. Kamu dapat menyajikan ayam masak saos teriyaki sendiri di rumahmu dan boleh dijadikan camilan favorit di akhir pekanmu.

Kita tidak usah bingung jika kamu ingin memakan ayam masak saos teriyaki, karena ayam masak saos teriyaki tidak sukar untuk didapatkan dan kalian pun dapat menghidangkannya sendiri di rumah. ayam masak saos teriyaki boleh dimasak lewat beragam cara. Sekarang telah banyak banget resep modern yang membuat ayam masak saos teriyaki semakin enak.

Resep ayam masak saos teriyaki juga sangat mudah dihidangkan, lho. Anda tidak usah capek-capek untuk memesan ayam masak saos teriyaki, lantaran Anda mampu menyajikan ditempatmu. Untuk Kita yang ingin mencobanya, berikut ini cara membuat ayam masak saos teriyaki yang mantab yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam masak saos teriyaki:

1. Sediakan 3/4 dada ayam fillet potong dadu
1. Sediakan 3 buah tahu potong dadu
1. Siapkan 1 buah tomat potong dadu
1. Ambil 1 sch saori saos teriyaki
1. Siapkan 3 sdm kecap
1. Ambil 1/2 sdt garam
1. Siapkan 1 sdm kaldu jamur
1. Ambil 1 butir telur ayam kampung
1. Gunakan 5 sdm tepung terigu
1. Siapkan 400 cc air
1. Gunakan secukupnya minyak goreng
1. Ambil  marinasi:
1. Siapkan 1 siung bawang putih dihaluskan
1. Gunakan 1/2 sdt merica bubuk
1. Gunakan 1 sdt garam
1. Ambil  bumbu tumis:
1. Sediakan 3 siung bawang putih
1. Gunakan 3 siung bawang merah
1. Siapkan 1/2 siung bawang bombay
1. Gunakan 7 buah cabai merah keriting
1. Gunakan sedikit jahe
1. Siapkan 2 lembar daun salam
1. Ambil 1 lembar daun jeruk


Selanjutnya goreng ayam yang sudah dimarinasi dengan sedikit minyak. Jika sudah kecoklatan, masukkan air kemudian steam ayam. Masukkan sisa saus teriyaki dalam wadah. Tambahkan tepung maizena yang sudah dilarutkan dalam air. 

<!--inarticleads2-->

##### Cara menyiapkan Ayam masak saos teriyaki:

1. Cuci bersih daging ayam lalu potong dadu sesuai selera. marinasi dengan bumbu marinasi. diamkan ± 1 jam.
1. Setelah itu masukkan telur ayam kampung dan tepung terigu ke dalam ayam yg telah dimarinasi. aduk hingga tercampur rata.
1. Panaskan minyak dan goreng ayam serta tahu hingga matang. sisihkan
1. Tumis bumbu tumisan yg telah diiris2 hingga harum.
1. Masukkan ayam dan tahu yg telah digoreng, aduk2. lalu tambahkan air, saori saos teriyaki, kecap manis, garam dan kaldu jamur. aduk rata
1. Masukkan tomat yg telah dipotong dadu, aduk2. masak hingga air surut. koreksi rasa dan sajikan


Semasa sedang membuat teriyaki, bahan-bahan makanan yang akan dipanggang dicelup dan diperap dengan sos teriyaki beberapa kali sehingga betul-betul masak. Di Jepun, bahan yang banyak digunakan dalam masakan teriyaki merupakan ikan yang yang banyak daging seperti tongkol, makarel, trout dan marlin. Campur semua bumbu teriyaki dan ayam. Masak sambil diaduk hingga meletup-letup dan kental. Panggang ayam di atas pan bersama satu sendok makan minyak hingga kecokelatakn. 

Wah ternyata resep ayam masak saos teriyaki yang nikamt sederhana ini gampang banget ya! Kamu semua dapat menghidangkannya. Cara buat ayam masak saos teriyaki Sesuai banget buat anda yang baru mau belajar memasak maupun juga bagi kalian yang telah jago memasak.

Tertarik untuk mencoba bikin resep ayam masak saos teriyaki nikmat tidak rumit ini? Kalau kamu mau, ayo kamu segera menyiapkan alat dan bahannya, maka buat deh Resep ayam masak saos teriyaki yang mantab dan tidak ribet ini. Sungguh mudah kan. 

Jadi, daripada kamu berlama-lama, hayo kita langsung saja bikin resep ayam masak saos teriyaki ini. Dijamin anda gak akan menyesal sudah bikin resep ayam masak saos teriyaki nikmat tidak ribet ini! Selamat berkreasi dengan resep ayam masak saos teriyaki lezat tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

