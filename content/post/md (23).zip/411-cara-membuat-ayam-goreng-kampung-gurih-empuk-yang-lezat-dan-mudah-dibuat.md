---
description: "Cara membuat Ayam goreng kampung gurih empuk yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam goreng kampung gurih empuk yang lezat dan Mudah Dibuat"
slug: 411-cara-membuat-ayam-goreng-kampung-gurih-empuk-yang-lezat-dan-mudah-dibuat
date: 2021-04-09T09:31:30.959Z
image: https://img-global.cpcdn.com/recipes/15295214dd55ea22/680x482cq70/ayam-goreng-kampung-gurih-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/15295214dd55ea22/680x482cq70/ayam-goreng-kampung-gurih-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/15295214dd55ea22/680x482cq70/ayam-goreng-kampung-gurih-empuk-foto-resep-utama.jpg
author: Lettie Ford
ratingvalue: 4.4
reviewcount: 10
recipeingredient:
- "1 ekor ayam kampung muda"
- "1 buah jeruk nipis"
- "1 ruas lengkuas geprek"
- "2 batang serai geprek"
- "3 lembar daun salam"
- "2 lembar daun jeruk"
- "Secukupnya air"
- "Secukupnya garam gula dan kaldu bubuk"
- " Minyak goreng"
- " Bumbu halus"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "2 ruas kunyit"
- "4 butir kemiri sangrai"
- "Sejempol jahe"
- "1 sdt ketumar bubuk"
recipeinstructions:
- "Cuci bersih ayam kemudian beri perasan air jeruk nipis. Diamkan 10 menit. Lalu bilas kembali, tiriskan"
- "Panaskan sedikit minyak. Tumis bumbu halus, serai, lengkuas, daun salam dan daun jeruk hingga wangi. Tambahkan air secukupnya. Beri garam, gula dan kaldu bubuk. Aduk hingga rata"
- "Masukan ayam kampung. Aduk rata. Ungkep ayam hingga air menyusut dan ayam empuk (bisa pakai panci presto juga)"
- "Jika air sudah menyusut banyak dan ayam empuk. Angkat ayam dan saring bumbu"
- "Panaskan minyak agak banyak. Goreng ayam berserta bumbu sampai kuning kecoklatan. Angkat, tiriskan ayam dan bumbu. Sajikan. Enak dan gurih"
categories:
- Resep
tags:
- ayam
- goreng
- kampung

katakunci: ayam goreng kampung 
nutrition: 178 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam goreng kampung gurih empuk](https://img-global.cpcdn.com/recipes/15295214dd55ea22/680x482cq70/ayam-goreng-kampung-gurih-empuk-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan panganan enak buat famili merupakan suatu hal yang menggembirakan bagi kamu sendiri. Tugas seorang  wanita Tidak saja menangani rumah saja, tapi kamu juga wajib menyediakan kebutuhan gizi tercukupi dan juga panganan yang disantap orang tercinta harus sedap.

Di era  sekarang, kita memang dapat membeli olahan siap saji walaupun tidak harus susah mengolahnya dulu. Tetapi ada juga orang yang selalu ingin memberikan makanan yang terenak bagi keluarganya. Karena, memasak yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai selera famili. 



Apakah anda adalah seorang penggemar ayam goreng kampung gurih empuk?. Asal kamu tahu, ayam goreng kampung gurih empuk merupakan makanan khas di Nusantara yang kini digemari oleh banyak orang dari hampir setiap daerah di Nusantara. Anda bisa membuat ayam goreng kampung gurih empuk sendiri di rumah dan boleh jadi santapan favorit di akhir pekan.

Anda tidak usah bingung jika kamu ingin memakan ayam goreng kampung gurih empuk, lantaran ayam goreng kampung gurih empuk gampang untuk ditemukan dan kalian pun bisa mengolahnya sendiri di tempatmu. ayam goreng kampung gurih empuk bisa diolah lewat beragam cara. Sekarang telah banyak resep modern yang menjadikan ayam goreng kampung gurih empuk semakin lebih nikmat.

Resep ayam goreng kampung gurih empuk juga gampang untuk dibuat, lho. Kamu jangan ribet-ribet untuk membeli ayam goreng kampung gurih empuk, karena Kamu dapat menghidangkan ditempatmu. Bagi Anda yang akan membuatnya, berikut resep untuk menyajikan ayam goreng kampung gurih empuk yang mantab yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam goreng kampung gurih empuk:

1. Gunakan 1 ekor ayam kampung muda
1. Sediakan 1 buah jeruk nipis
1. Sediakan 1 ruas lengkuas (geprek)
1. Ambil 2 batang serai (geprek)
1. Ambil 3 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Ambil Secukupnya air
1. Sediakan Secukupnya garam, gula dan kaldu bubuk
1. Sediakan  Minyak goreng
1. Sediakan  Bumbu halus:
1. Ambil 8 siung bawang merah
1. Ambil 5 siung bawang putih
1. Sediakan 2 ruas kunyit
1. Ambil 4 butir kemiri sangrai
1. Sediakan Sejempol jahe
1. Gunakan 1 sdt ketumar bubuk




<!--inarticleads2-->

##### Cara membuat Ayam goreng kampung gurih empuk:

1. Cuci bersih ayam kemudian beri perasan air jeruk nipis. Diamkan 10 menit. Lalu bilas kembali, tiriskan
1. Panaskan sedikit minyak. Tumis bumbu halus, serai, lengkuas, daun salam dan daun jeruk hingga wangi. Tambahkan air secukupnya. Beri garam, gula dan kaldu bubuk. Aduk hingga rata
1. Masukan ayam kampung. Aduk rata. Ungkep ayam hingga air menyusut dan ayam empuk (bisa pakai panci presto juga)
1. Jika air sudah menyusut banyak dan ayam empuk. Angkat ayam dan saring bumbu
1. Panaskan minyak agak banyak. Goreng ayam berserta bumbu sampai kuning kecoklatan. Angkat, tiriskan ayam dan bumbu. Sajikan. Enak dan gurih




Wah ternyata cara buat ayam goreng kampung gurih empuk yang lezat tidak rumit ini gampang sekali ya! Semua orang dapat mencobanya. Cara buat ayam goreng kampung gurih empuk Cocok sekali untuk kamu yang baru mau belajar memasak ataupun juga bagi kalian yang telah pandai dalam memasak.

Apakah kamu ingin mulai mencoba membikin resep ayam goreng kampung gurih empuk nikmat tidak ribet ini? Kalau ingin, mending kamu segera buruan siapin alat dan bahannya, setelah itu bikin deh Resep ayam goreng kampung gurih empuk yang mantab dan simple ini. Sangat taidak sulit kan. 

Maka, ketimbang anda berfikir lama-lama, ayo langsung aja sajikan resep ayam goreng kampung gurih empuk ini. Pasti kamu gak akan nyesel sudah buat resep ayam goreng kampung gurih empuk mantab sederhana ini! Selamat berkreasi dengan resep ayam goreng kampung gurih empuk mantab sederhana ini di tempat tinggal kalian masing-masing,ya!.

