---
description: "Resep Sup ayam klaten yang lezat dan Mudah Dibuat"
title: "Resep Sup ayam klaten yang lezat dan Mudah Dibuat"
slug: 201-resep-sup-ayam-klaten-yang-lezat-dan-mudah-dibuat
date: 2021-02-07T19:43:21.615Z
image: https://img-global.cpcdn.com/recipes/a492cc44d482c074/680x482cq70/sup-ayam-klaten-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a492cc44d482c074/680x482cq70/sup-ayam-klaten-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a492cc44d482c074/680x482cq70/sup-ayam-klaten-foto-resep-utama.jpg
author: Bill Hunt
ratingvalue: 3.5
reviewcount: 4
recipeingredient:
- "1/2 kg ceker ayam"
- "1/4 kg kepala sapi"
- "2 buah wortel potong kotak"
- "2 buah kentang potong kotak"
- "1/4 butir kubis"
- "2 batang bawang pre iris kasar"
- "1 batang seledri iris kasar"
- " Bahan bumbu "
- "5 butir bawang putih geprek"
- "2 ruas jahe geprek"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "2 batang serai geprek"
- " Bahan tambahan "
- "1 sendok teh pala bubuk"
- "1 sendok teh lada putih bubuk"
- "1 bungkus penyedap rasa"
recipeinstructions:
- "Cuci bersih kepala dan ceker ayam, lalu masukkan ke dalam air yang telah mendidih. Biarkan hingga ayam empuk"
- "Tumis bawang putih, bawang pre, jahe, daun salam, serai, daun jeruk hingga layu dan harum, lalu masukkan ke panci yang berisi ayam tadi"
- "Tambahkan lada, pala bubuk, dan penyedap rasa. Koreksi rasa"
- "Setelah rasa pas, masukkan seledri dan tambahkan bawang goreng jika suka"
- "Selamat menikmati"
categories:
- Resep
tags:
- sup
- ayam
- klaten

katakunci: sup ayam klaten 
nutrition: 132 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dinner

---


![Sup ayam klaten](https://img-global.cpcdn.com/recipes/a492cc44d482c074/680x482cq70/sup-ayam-klaten-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan hidangan sedap untuk keluarga adalah hal yang membahagiakan untuk anda sendiri. Kewajiban seorang istri bukan sekedar menangani rumah saja, tapi kamu juga wajib menyediakan keperluan nutrisi terpenuhi dan masakan yang dikonsumsi keluarga tercinta mesti sedap.

Di era  saat ini, kita memang dapat memesan hidangan siap saji meski tanpa harus repot mengolahnya lebih dulu. Namun banyak juga mereka yang selalu mau memberikan hidangan yang terbaik bagi orang tercintanya. Sebab, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut berdasarkan kesukaan famili. 



Apakah anda salah satu penggemar sup ayam klaten?. Asal kamu tahu, sup ayam klaten merupakan makanan khas di Indonesia yang saat ini disukai oleh banyak orang di berbagai daerah di Nusantara. Kalian dapat memasak sup ayam klaten buatan sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di hari liburmu.

Anda tidak usah bingung jika kamu ingin mendapatkan sup ayam klaten, lantaran sup ayam klaten sangat mudah untuk dicari dan kamu pun bisa menghidangkannya sendiri di rumah. sup ayam klaten boleh dibuat dengan bermacam cara. Sekarang sudah banyak resep kekinian yang membuat sup ayam klaten semakin lebih mantap.

Resep sup ayam klaten pun sangat gampang untuk dibuat, lho. Kalian jangan ribet-ribet untuk memesan sup ayam klaten, karena Kita bisa menyiapkan di rumah sendiri. Untuk Anda yang mau membuatnya, berikut resep untuk menyajikan sup ayam klaten yang nikamat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Sup ayam klaten:

1. Sediakan 1/2 kg ceker ayam
1. Gunakan 1/4 kg kepala sapi
1. Sediakan 2 buah wortel, potong kotak
1. Gunakan 2 buah kentang, potong kotak
1. Gunakan 1/4 butir kubis
1. Siapkan 2 batang bawang pre, iris kasar
1. Sediakan 1 batang seledri, iris kasar
1. Sediakan  Bahan bumbu :
1. Sediakan 5 butir bawang putih, geprek
1. Gunakan 2 ruas jahe, geprek
1. Ambil 2 lembar daun salam
1. Sediakan 4 lembar daun jeruk
1. Siapkan 2 batang serai, geprek
1. Siapkan  Bahan tambahan :
1. Ambil 1 sendok teh pala bubuk
1. Sediakan 1 sendok teh lada putih bubuk
1. Ambil 1 bungkus penyedap rasa




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Sup ayam klaten:

1. Cuci bersih kepala dan ceker ayam, lalu masukkan ke dalam air yang telah mendidih. Biarkan hingga ayam empuk
1. Tumis bawang putih, bawang pre, jahe, daun salam, serai, daun jeruk hingga layu dan harum, lalu masukkan ke panci yang berisi ayam tadi
1. Tambahkan lada, pala bubuk, dan penyedap rasa. Koreksi rasa
1. Setelah rasa pas, masukkan seledri dan tambahkan bawang goreng jika suka
1. Selamat menikmati




Wah ternyata resep sup ayam klaten yang nikamt sederhana ini enteng banget ya! Semua orang dapat mencobanya. Cara buat sup ayam klaten Sangat cocok sekali untuk kamu yang sedang belajar memasak ataupun untuk kalian yang sudah jago memasak.

Apakah kamu mau mencoba membikin resep sup ayam klaten lezat tidak ribet ini? Kalau kalian mau, mending kamu segera buruan siapin peralatan dan bahannya, kemudian buat deh Resep sup ayam klaten yang nikmat dan simple ini. Benar-benar gampang kan. 

Oleh karena itu, daripada kamu berlama-lama, ayo kita langsung saja buat resep sup ayam klaten ini. Pasti kalian tiidak akan menyesal sudah buat resep sup ayam klaten enak tidak rumit ini! Selamat mencoba dengan resep sup ayam klaten mantab simple ini di tempat tinggal sendiri,ya!.

