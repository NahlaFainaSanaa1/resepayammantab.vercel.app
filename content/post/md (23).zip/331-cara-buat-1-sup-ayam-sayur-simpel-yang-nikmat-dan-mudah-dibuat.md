---
description: "Cara buat #1 Sup Ayam Sayur Simpel yang nikmat dan Mudah Dibuat"
title: "Cara buat #1 Sup Ayam Sayur Simpel yang nikmat dan Mudah Dibuat"
slug: 331-cara-buat-1-sup-ayam-sayur-simpel-yang-nikmat-dan-mudah-dibuat
date: 2021-05-07T17:18:09.662Z
image: https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg
author: Stanley Fox
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- " Isi Sup"
- "1 buah wortel irisiris"
- "12 buah buncis potong memanjang"
- "2 buah kentang kecil kalau besar 1 aja potong dadu"
- "potong dadu Daging dada ayam secukupnya"
- " Kol  dibuka lembarannya robek sebesar selera masing2"
- " Bawang putih 8 siung kalau ga suka boleh kurangi"
- "1,5 L Air"
- " Bumbu"
- " Daun bawang"
- "sesuai selera Garam"
- "sesuai selera Lada"
- " Royco ayam sesuai selera ga pakai juga ok"
- " Opsional"
- "Iris bawang merah dan buat bawang goreng makin enak"
recipeinstructions:
- "Siapkan semua bahan dulu."
- "Didihkan air di panci."
- "Masukan potongan ayam, rebus hingga putih dan mulai matang sekitar 2-3 menit."
- "Masukkan bawang putih, kentang, dan wortel. Biarkan sekitar 5-8 menit."
- "Masukkan buncis dan ketika terlihat sudah mulai matang (agak mengembang dan mengambang), masukkan kol."
- "Tambahkan garam sampai asinnya pas."
- "Masukkan daun bawang, aduk sebentar sekitar 30 detik, lalu matikan kompor."
- "Masukkan Royco dan lada di sendok sayur, cairkan dengan sedikit air di panci lalu aduk merata di sup."
- "Siap disajikan dengan bawang goreng, resep menyusul."
categories:
- Resep
tags:
- 1
- sup
- ayam

katakunci: 1 sup ayam 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![#1 Sup Ayam Sayur Simpel](https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan hidangan lezat buat famili merupakan suatu hal yang mengasyikan bagi kamu sendiri. Tanggung jawab seorang istri Tidak saja menangani rumah saja, tetapi kamu pun wajib memastikan keperluan gizi terpenuhi dan hidangan yang disantap orang tercinta mesti menggugah selera.

Di masa  sekarang, kamu sebenarnya mampu memesan hidangan yang sudah jadi meski tanpa harus ribet mengolahnya dulu. Tetapi ada juga lho orang yang selalu mau menghidangkan yang terlezat untuk keluarganya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan keluarga. 



Mungkinkah anda adalah seorang penggemar #1 sup ayam sayur simpel?. Tahukah kamu, #1 sup ayam sayur simpel merupakan sajian khas di Indonesia yang sekarang disenangi oleh setiap orang di berbagai daerah di Nusantara. Kalian bisa memasak #1 sup ayam sayur simpel sendiri di rumahmu dan boleh dijadikan hidangan kesenanganmu di akhir pekan.

Kita tak perlu bingung jika kamu ingin mendapatkan #1 sup ayam sayur simpel, karena #1 sup ayam sayur simpel tidak sulit untuk didapatkan dan kita pun boleh memasaknya sendiri di rumah. #1 sup ayam sayur simpel dapat dimasak lewat beraneka cara. Kini telah banyak banget resep modern yang menjadikan #1 sup ayam sayur simpel semakin lebih enak.

Resep #1 sup ayam sayur simpel juga gampang dibuat, lho. Kalian tidak perlu capek-capek untuk memesan #1 sup ayam sayur simpel, lantaran Kalian mampu menyiapkan sendiri di rumah. Bagi Kamu yang akan menyajikannya, dibawah ini merupakan cara membuat #1 sup ayam sayur simpel yang enak yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan #1 Sup Ayam Sayur Simpel:

1. Gunakan  Isi Sup
1. Gunakan 1 buah wortel, iris-iris
1. Sediakan 12 buah buncis, potong memanjang
1. Ambil 2 buah kentang kecil (kalau besar 1 aja), potong dadu
1. Siapkan potong dadu Daging dada ayam secukupnya,
1. Gunakan  Kol ¼, dibuka lembarannya, robek sebesar selera masing2
1. Ambil  Bawang putih 8 siung (kalau ga suka boleh kurangi)
1. Ambil 1,5 L Air
1. Sediakan  Bumbu
1. Siapkan  Daun bawang
1. Gunakan sesuai selera Garam
1. Siapkan sesuai selera Lada
1. Sediakan  Royco ayam sesuai selera, ga pakai juga ok
1. Sediakan  Opsional
1. Sediakan Iris bawang merah dan buat bawang goreng, makin enak




<!--inarticleads2-->

##### Cara membuat #1 Sup Ayam Sayur Simpel:

1. Siapkan semua bahan dulu.
1. Didihkan air di panci.
1. Masukan potongan ayam, rebus hingga putih dan mulai matang sekitar 2-3 menit.
1. Masukkan bawang putih, kentang, dan wortel. Biarkan sekitar 5-8 menit.
1. Masukkan buncis dan ketika terlihat sudah mulai matang (agak mengembang dan mengambang), masukkan kol.
1. Tambahkan garam sampai asinnya pas.
1. Masukkan daun bawang, aduk sebentar sekitar 30 detik, lalu matikan kompor.
1. Masukkan Royco dan lada di sendok sayur, cairkan dengan sedikit air di panci lalu aduk merata di sup.
1. Siap disajikan dengan bawang goreng, resep menyusul.




Ternyata cara buat #1 sup ayam sayur simpel yang lezat tidak rumit ini enteng sekali ya! Anda Semua bisa memasaknya. Cara buat #1 sup ayam sayur simpel Sangat cocok sekali buat kita yang baru akan belajar memasak maupun bagi kamu yang sudah hebat memasak.

Tertarik untuk mencoba membikin resep #1 sup ayam sayur simpel enak simple ini? Kalau anda mau, mending kamu segera siapin alat-alat dan bahan-bahannya, maka buat deh Resep #1 sup ayam sayur simpel yang mantab dan tidak ribet ini. Sungguh mudah kan. 

Jadi, daripada kita diam saja, maka langsung aja hidangkan resep #1 sup ayam sayur simpel ini. Dijamin kamu gak akan menyesal membuat resep #1 sup ayam sayur simpel mantab sederhana ini! Selamat berkreasi dengan resep #1 sup ayam sayur simpel nikmat tidak ribet ini di rumah kalian sendiri,ya!.

