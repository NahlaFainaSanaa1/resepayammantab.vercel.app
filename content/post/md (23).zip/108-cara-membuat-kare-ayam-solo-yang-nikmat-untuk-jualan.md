---
description: "Cara membuat Kare Ayam Solo yang nikmat Untuk Jualan"
title: "Cara membuat Kare Ayam Solo yang nikmat Untuk Jualan"
slug: 108-cara-membuat-kare-ayam-solo-yang-nikmat-untuk-jualan
date: 2021-01-29T12:13:10.315Z
image: https://img-global.cpcdn.com/recipes/2c03d5469091e736/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2c03d5469091e736/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2c03d5469091e736/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Franklin Rodgers
ratingvalue: 3.3
reviewcount: 4
recipeingredient:
- "1/2 kg daging ayampotong"
- "1 lmbr daun salam"
- "3 lmbr daun jerukbuang tulang tengahnyasobek"
- "1 jempol lengkuasgeprek"
- "1 btng seraigeprek"
- "1 liter air"
- "1 sachet santan instan 65 ml"
- "1 sdt munjung gula pasir"
- "1/2 sdt kaldu bubuk"
- "secukupnya garam"
- "secukupnya minyak goreng"
- " Bumbu halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "2 cm kunyit"
- "1 sdt ketumbar bubuk"
- "1/4 sdt lada bubuk"
- "1/4 sdt jinten sy skip"
- "2 cm jahe tambahan sy"
- " Pelengkap "
- "2 bh wortelpotongrebus"
- "1 mangkuk taugeseduh dengan air panas"
- "1 btng daun bawangiris halus"
- "2 sdm bawang merah goreng"
recipeinstructions:
- "Cuci bersih ayam,lumuri garam,diamkan 10 menit,bilas kembali. Lalu rebus dlm air mendidih sampai berubah warna saja,angkat &amp; tiriskan. Buang air rebusannya."
- "Panaskan minyak goreng,tumis bumbu halus sampai matang &amp; harum,tambahkan serai,lengkuas,daun salam &amp; daun jeruk,aduk rata. Masukkan juga ayam yg telah direbus,aduk rata."
- "Tuang air,didihkan. Bumbui garam,gula pasir &amp; kaldu bubuk. Masukkan santan instan,aduk kembali sampai mendidih. Masak sampai ayam empuk &amp; bumbu menyatu. Jgn lupa koreksi rasanya."
- "Siapkan bahan pelengkapnya."
- "Tata sayuran di piring saji,masukkan potongan ayam,siram dgn kuah,taburi bawang goreng &amp; sajikan."
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 178 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dessert

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/2c03d5469091e736/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Selaku seorang orang tua, menyajikan panganan sedap untuk orang tercinta merupakan suatu hal yang menyenangkan bagi kita sendiri. Tanggung jawab seorang  wanita bukan sekadar mengurus rumah saja, tapi anda juga wajib memastikan keperluan gizi terpenuhi dan juga santapan yang disantap orang tercinta wajib enak.

Di era  saat ini, kita memang dapat mengorder panganan praktis tidak harus ribet memasaknya terlebih dahulu. Namun ada juga lho mereka yang memang ingin memberikan yang terenak bagi orang tercintanya. Lantaran, memasak sendiri akan jauh lebih bersih dan bisa menyesuaikan sesuai kesukaan keluarga. 



Mungkinkah anda adalah seorang penyuka kare ayam solo?. Tahukah kamu, kare ayam solo merupakan makanan khas di Nusantara yang saat ini disenangi oleh kebanyakan orang dari hampir setiap wilayah di Indonesia. Kalian dapat menyajikan kare ayam solo buatan sendiri di rumah dan pasti jadi hidangan kegemaranmu di hari liburmu.

Kalian tak perlu bingung jika kamu ingin menyantap kare ayam solo, lantaran kare ayam solo mudah untuk didapatkan dan kita pun dapat menghidangkannya sendiri di rumah. kare ayam solo dapat diolah memalui bermacam cara. Kini pun telah banyak banget cara modern yang membuat kare ayam solo semakin enak.

Resep kare ayam solo pun gampang sekali dibikin, lho. Kalian jangan repot-repot untuk memesan kare ayam solo, tetapi Kamu bisa menyiapkan di rumah sendiri. Bagi Kalian yang hendak menghidangkannya, dibawah ini merupakan resep untuk menyajikan kare ayam solo yang lezat yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Kare Ayam Solo:

1. Sediakan 1/2 kg daging ayam,potong²
1. Ambil 1 lmbr daun salam
1. Ambil 3 lmbr daun jeruk,buang tulang tengahnya,sobek²
1. Ambil 1 jempol lengkuas,geprek
1. Siapkan 1 btng serai,geprek
1. Gunakan 1 liter air
1. Gunakan 1 sachet santan instan (65 ml)
1. Ambil 1 sdt munjung gula pasir
1. Siapkan 1/2 sdt kaldu bubuk
1. Gunakan secukupnya garam
1. Ambil secukupnya minyak goreng
1. Sediakan  Bumbu halus :
1. Ambil 5 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Siapkan 3 butir kemiri
1. Siapkan 2 cm kunyit
1. Ambil 1 sdt ketumbar bubuk
1. Siapkan 1/4 sdt lada bubuk
1. Gunakan 1/4 sdt jinten (sy skip)
1. Siapkan 2 cm jahe (tambahan sy)
1. Gunakan  Pelengkap :
1. Siapkan 2 bh wortel,potong²,rebus
1. Gunakan 1 mangkuk tauge,seduh dengan air panas
1. Ambil 1 btng daun bawang,iris halus
1. Ambil 2 sdm bawang merah goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Kare Ayam Solo:

1. Cuci bersih ayam,lumuri garam,diamkan 10 menit,bilas kembali. Lalu rebus dlm air mendidih sampai berubah warna saja,angkat &amp; tiriskan. Buang air rebusannya.
1. Panaskan minyak goreng,tumis bumbu halus sampai matang &amp; harum,tambahkan serai,lengkuas,daun salam &amp; daun jeruk,aduk rata. Masukkan juga ayam yg telah direbus,aduk rata.
1. Tuang air,didihkan. Bumbui garam,gula pasir &amp; kaldu bubuk. Masukkan santan instan,aduk kembali sampai mendidih. Masak sampai ayam empuk &amp; bumbu menyatu. Jgn lupa koreksi rasanya.
1. Siapkan bahan pelengkapnya.
1. Tata sayuran di piring saji,masukkan potongan ayam,siram dgn kuah,taburi bawang goreng &amp; sajikan.




Wah ternyata cara membuat kare ayam solo yang nikamt sederhana ini gampang sekali ya! Kita semua dapat menghidangkannya. Resep kare ayam solo Cocok banget buat anda yang baru akan belajar memasak maupun bagi anda yang sudah jago memasak.

Apakah kamu tertarik mulai mencoba buat resep kare ayam solo enak sederhana ini? Kalau anda tertarik, ayo kalian segera menyiapkan alat-alat dan bahan-bahannya, lantas buat deh Resep kare ayam solo yang nikmat dan simple ini. Betul-betul taidak sulit kan. 

Maka, daripada kalian diam saja, ayo langsung aja sajikan resep kare ayam solo ini. Pasti kamu tak akan nyesel sudah membuat resep kare ayam solo nikmat tidak ribet ini! Selamat mencoba dengan resep kare ayam solo nikmat simple ini di rumah kalian masing-masing,oke!.

