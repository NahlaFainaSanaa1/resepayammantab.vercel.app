---
description: "Resep Ayam Kecap ala Simple Rudy yang nikmat dan Mudah Dibuat"
title: "Resep Ayam Kecap ala Simple Rudy yang nikmat dan Mudah Dibuat"
slug: 121-resep-ayam-kecap-ala-simple-rudy-yang-nikmat-dan-mudah-dibuat
date: 2021-02-28T08:21:38.833Z
image: https://img-global.cpcdn.com/recipes/7d03a5b02589a374/680x482cq70/ayam-kecap-ala-simple-rudy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7d03a5b02589a374/680x482cq70/ayam-kecap-ala-simple-rudy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7d03a5b02589a374/680x482cq70/ayam-kecap-ala-simple-rudy-foto-resep-utama.jpg
author: Amy Maxwell
ratingvalue: 3.8
reviewcount: 6
recipeingredient:
- "500 gr ayam aku filet"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "3 cm jahe"
- "2 lembar daun salam"
- "1/2 bawang bombay tambahan saya sendiri"
- "secukupnya Air"
- " Campur dalam mangkok"
- "6 sdm kecap manis"
- "1 sdm kecap asin"
- "1 sdt gula"
- "1 sdt garam"
- "1 sdt lada"
recipeinstructions:
- "Tumis bawang merah dan bawang putih yang sudah diiris tipis hingga harum. Kemudian masukkan jahe geprek dan daun salam. Masak hingga harum dan layu"
- "Masukan ayam (jika pakai ayam bertulang lebih baik digoreng setengah matang dulu agar tidak terlihat putih mulus nanti saat ketemu kecap). Aduk-aduk hingga ayam setengah matang"
- "Masukkan pasukan kecap yang sudah dicampur dalam satu mangkok. Aduk rata tunggu hingga kecap berbuih."
- "Setelah berbuih tambahkan air sesuai selera dan bawang bombay. Tutup hingga air menyusut sesuai selera."
- "Ayam kecap siap disajikan"
categories:
- Resep
tags:
- ayam
- kecap
- ala

katakunci: ayam kecap ala 
nutrition: 109 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Kecap ala Simple Rudy](https://img-global.cpcdn.com/recipes/7d03a5b02589a374/680x482cq70/ayam-kecap-ala-simple-rudy-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan panganan sedap untuk keluarga merupakan hal yang menyenangkan bagi kamu sendiri. Tugas seorang istri bukan hanya mengatur rumah saja, namun anda juga wajib memastikan keperluan gizi terpenuhi dan juga panganan yang disantap anak-anak mesti lezat.

Di era  saat ini, anda sebenarnya dapat membeli hidangan jadi tanpa harus repot membuatnya lebih dulu. Tetapi ada juga orang yang memang mau menghidangkan yang terbaik untuk keluarganya. Lantaran, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan orang tercinta. 



Apakah anda seorang penyuka ayam kecap ala simple rudy?. Tahukah kamu, ayam kecap ala simple rudy merupakan hidangan khas di Nusantara yang saat ini disenangi oleh banyak orang di hampir setiap daerah di Indonesia. Kita dapat menyajikan ayam kecap ala simple rudy sendiri di rumah dan pasti jadi hidangan favorit di hari libur.

Kita tak perlu bingung jika kamu ingin menyantap ayam kecap ala simple rudy, sebab ayam kecap ala simple rudy mudah untuk ditemukan dan anda pun boleh memasaknya sendiri di tempatmu. ayam kecap ala simple rudy boleh dimasak lewat beragam cara. Kini telah banyak cara modern yang membuat ayam kecap ala simple rudy semakin enak.

Resep ayam kecap ala simple rudy juga gampang sekali dibuat, lho. Kalian tidak usah repot-repot untuk memesan ayam kecap ala simple rudy, karena Kalian dapat menghidangkan di rumahmu. Untuk Kita yang akan mencobanya, berikut ini cara membuat ayam kecap ala simple rudy yang lezat yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Kecap ala Simple Rudy:

1. Gunakan 500 gr ayam (aku filet)
1. Sediakan 5 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Sediakan 3 cm jahe
1. Siapkan 2 lembar daun salam
1. Siapkan 1/2 bawang bombay (tambahan saya sendiri)
1. Ambil secukupnya Air
1. Siapkan  Campur dalam mangkok
1. Gunakan 6 sdm kecap manis
1. Gunakan 1 sdm kecap asin
1. Sediakan 1 sdt gula
1. Siapkan 1 sdt garam
1. Siapkan 1 sdt lada




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Kecap ala Simple Rudy:

1. Tumis bawang merah dan bawang putih yang sudah diiris tipis hingga harum. Kemudian masukkan jahe geprek dan daun salam. Masak hingga harum dan layu
1. Masukan ayam (jika pakai ayam bertulang lebih baik digoreng setengah matang dulu agar tidak terlihat putih mulus nanti saat ketemu kecap). Aduk-aduk hingga ayam setengah matang
1. Masukkan pasukan kecap yang sudah dicampur dalam satu mangkok. Aduk rata tunggu hingga kecap berbuih.
1. Setelah berbuih tambahkan air sesuai selera dan bawang bombay. Tutup hingga air menyusut sesuai selera.
1. Ayam kecap siap disajikan




Wah ternyata cara membuat ayam kecap ala simple rudy yang nikamt simple ini enteng sekali ya! Kita semua mampu membuatnya. Cara Membuat ayam kecap ala simple rudy Sangat sesuai sekali buat kita yang baru belajar memasak ataupun juga untuk kamu yang telah pandai dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep ayam kecap ala simple rudy nikmat simple ini? Kalau kamu tertarik, mending kamu segera buruan siapin alat-alat dan bahan-bahannya, setelah itu bikin deh Resep ayam kecap ala simple rudy yang nikmat dan tidak rumit ini. Betul-betul taidak sulit kan. 

Jadi, ketimbang kamu berlama-lama, yuk langsung aja buat resep ayam kecap ala simple rudy ini. Dijamin kamu gak akan nyesel membuat resep ayam kecap ala simple rudy mantab simple ini! Selamat berkreasi dengan resep ayam kecap ala simple rudy lezat tidak ribet ini di tempat tinggal sendiri,ya!.

