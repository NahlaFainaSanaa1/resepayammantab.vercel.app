---
description: "Cara membuat Kare Ayam Solo Sederhana Untuk Jualan"
title: "Cara membuat Kare Ayam Solo Sederhana Untuk Jualan"
slug: 100-cara-membuat-kare-ayam-solo-sederhana-untuk-jualan
date: 2021-04-27T14:38:20.531Z
image: https://img-global.cpcdn.com/recipes/e43b53776f6d643e/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e43b53776f6d643e/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e43b53776f6d643e/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Jeffrey Lambert
ratingvalue: 3.9
reviewcount: 6
recipeingredient:
- "1/2 kg dada ayam rebus  daun salam sisihkan"
- "3 lembar daun salam"
- "2 batang sereh geprek"
- "3 lembar daun jeruk"
- "500 ml air"
- "500 ml santan yg diperas pakai air matang hangat"
- "1 sdt gula pasir"
- "1/2 sdt kaldu jamur"
- "secukupnya Garam"
- " Bumbu halus "
- "1/2 sdt merica"
- "1/2 sdt ketumbar"
- "3 butir kemiri"
- "3 siung baput"
- "5 siung bamer"
- "1 ruas jempol jahe"
- "1 ruas kelingking kunyit"
- " Bahan sayur rebusan "
- "1 buah wortel besar iris"
- "100 gr kecambah"
- "1/4 kubis iris tipis"
- "1 daun sledri cincang"
recipeinstructions:
- "Rebus dada ayam dalam air mendidih sampai matang sisihkan"
- "Blender/uleg semua bumbu halus, lalu tumis menggunakan sedikit santan sampai harum"
- "Masukkan air beserta kaldu jamur, garam, gula serta bumbu² cemplung lainya"
- "Koreksi rasa, lalu matikan kompor kemudian masukkan santan yg sdh diperas pakai air matang hangat dan koreksi rasa lagi, kl dirasa ada yg kurang boleh ditambah"
- "Tata diatas piring semua sayuran rebus tadi dan tambahkan dada ayam suwir² diatasnya, tuang kuah kare diatasnya dan taburi bawang goreng dan seledri cincang"
- "Selamat mencoba 😘"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Lunch

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/e43b53776f6d643e/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyediakan hidangan mantab pada keluarga adalah suatu hal yang membahagiakan untuk kamu sendiri. Peran seorang ibu Tidak hanya mengatur rumah saja, tapi kamu juga harus memastikan kebutuhan gizi terpenuhi dan hidangan yang dimakan keluarga tercinta harus mantab.

Di era  sekarang, anda sebenarnya bisa membeli santapan jadi walaupun tidak harus susah membuatnya dahulu. Namun ada juga mereka yang selalu ingin memberikan makanan yang terlezat untuk keluarganya. Sebab, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan makanan kesukaan famili. 



Apakah anda adalah seorang penyuka kare ayam solo?. Tahukah kamu, kare ayam solo merupakan hidangan khas di Indonesia yang kini disenangi oleh setiap orang dari hampir setiap daerah di Nusantara. Kamu bisa membuat kare ayam solo sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di akhir pekan.

Kamu tidak usah bingung jika kamu ingin memakan kare ayam solo, lantaran kare ayam solo mudah untuk didapatkan dan kalian pun dapat mengolahnya sendiri di tempatmu. kare ayam solo bisa dibuat lewat bermacam cara. Sekarang telah banyak resep kekinian yang membuat kare ayam solo semakin nikmat.

Resep kare ayam solo juga sangat mudah untuk dibuat, lho. Kamu jangan capek-capek untuk memesan kare ayam solo, sebab Anda mampu menyiapkan di rumahmu. Bagi Anda yang hendak mencobanya, di bawah ini adalah resep menyajikan kare ayam solo yang lezat yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Kare Ayam Solo:

1. Siapkan 1/2 kg dada ayam, rebus + daun salam, sisihkan
1. Ambil 3 lembar daun salam
1. Ambil 2 batang sereh geprek
1. Sediakan 3 lembar daun jeruk
1. Ambil 500 ml air
1. Gunakan 500 ml santan yg diperas pakai air matang hangat
1. Ambil 1 sdt gula pasir
1. Sediakan 1/2 sdt kaldu jamur
1. Ambil secukupnya Garam
1. Siapkan  Bumbu halus :
1. Ambil 1/2 sdt merica
1. Sediakan 1/2 sdt ketumbar
1. Ambil 3 butir kemiri
1. Siapkan 3 siung baput
1. Siapkan 5 siung bamer
1. Ambil 1 ruas jempol jahe
1. Gunakan 1 ruas kelingking kunyit
1. Ambil  Bahan sayur rebusan :
1. Sediakan 1 buah wortel besar iris²
1. Ambil 100 gr kecambah
1. Siapkan 1/4 kubis iris tipis²
1. Ambil 1 daun sledri cincang




<!--inarticleads2-->

##### Langkah-langkah membuat Kare Ayam Solo:

1. Rebus dada ayam dalam air mendidih sampai matang sisihkan
1. Blender/uleg semua bumbu halus, lalu tumis menggunakan sedikit santan sampai harum
1. Masukkan air beserta kaldu jamur, garam, gula serta bumbu² cemplung lainya
1. Koreksi rasa, lalu matikan kompor kemudian masukkan santan yg sdh diperas pakai air matang hangat dan koreksi rasa lagi, kl dirasa ada yg kurang boleh ditambah
1. Tata diatas piring semua sayuran rebus tadi dan tambahkan dada ayam suwir² diatasnya, tuang kuah kare diatasnya dan taburi bawang goreng dan seledri cincang
1. Selamat mencoba 😘




Ternyata cara membuat kare ayam solo yang lezat tidak rumit ini enteng sekali ya! Kita semua bisa memasaknya. Resep kare ayam solo Cocok banget buat kamu yang sedang belajar memasak maupun juga untuk anda yang telah jago memasak.

Apakah kamu tertarik mulai mencoba membuat resep kare ayam solo enak simple ini? Kalau kalian tertarik, ayo kamu segera siapin alat-alat dan bahan-bahannya, lantas bikin deh Resep kare ayam solo yang nikmat dan simple ini. Betul-betul taidak sulit kan. 

Oleh karena itu, ketimbang kita berfikir lama-lama, hayo kita langsung saja bikin resep kare ayam solo ini. Dijamin anda gak akan nyesel membuat resep kare ayam solo nikmat sederhana ini! Selamat berkreasi dengan resep kare ayam solo lezat sederhana ini di rumah kalian sendiri,ya!.

