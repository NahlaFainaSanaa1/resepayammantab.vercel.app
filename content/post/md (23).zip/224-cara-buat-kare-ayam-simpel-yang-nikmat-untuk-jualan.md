---
description: "Cara buat Kare ayam Simpel yang nikmat Untuk Jualan"
title: "Cara buat Kare ayam Simpel yang nikmat Untuk Jualan"
slug: 224-cara-buat-kare-ayam-simpel-yang-nikmat-untuk-jualan
date: 2021-06-08T21:13:29.040Z
image: https://img-global.cpcdn.com/recipes/beb488fcb130fb98/680x482cq70/kare-ayam-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/beb488fcb130fb98/680x482cq70/kare-ayam-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/beb488fcb130fb98/680x482cq70/kare-ayam-simpel-foto-resep-utama.jpg
author: Ola Burke
ratingvalue: 4.7
reviewcount: 4
recipeingredient:
- "1/4 kg daging ayam  6 bh ceker ayam"
- "1 bks santan instan bubuk"
- " Bumbu cemplung "
- "1 lbr daun salam"
- "1 btng serai"
- "Sejempol lengkuas"
- "3 lbr daun jeruk"
- "1/4 sdt merica bubuk"
- " Garam gula kaldu bubuk bisa di skip"
- " Bumbu halus "
- "5 siung bawang merah"
- "2 siung bawang putih"
- "1/2 bh cabe merah besar"
- "3 btr kemiri"
- "1 sdt ketumbar"
- "1 cm kunyit"
- "2 cm jahe"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian sesuai selera. Cuci bersih."
- "Didihkan air dalam panci, setelah mendidih rebus ayam bersama daun salam sekitar 10 menit untuk menghilangkan bau amisnya. Buang airnya. Cuci kembali hingga bersih"
- "Ganti kembali airnya kemudian rebus lagi menggunakan api kecil."
- "Haluskan bumbu halus. Kemudian tumis hingga harum. Masukkan bumbu cemplungnya. Tumis lagi hingga bau langunya hilang."
- "Masukkan bumbu dalam rebusan ayam. Biarkan sebentar hingga bumbu meresap."
- "Tambahkan santan bubuk, aduk rata. Jangan lupa beri garam, gula dan merica bubuk. Tes rasa. Biarkan hingga kuah sedikit berkurang dan agak mengental."
categories:
- Resep
tags:
- kare
- ayam
- simpel

katakunci: kare ayam simpel 
nutrition: 220 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dessert

---


![Kare ayam Simpel](https://img-global.cpcdn.com/recipes/beb488fcb130fb98/680x482cq70/kare-ayam-simpel-foto-resep-utama.jpg)

Selaku seorang wanita, menyajikan masakan nikmat buat keluarga merupakan suatu hal yang memuaskan bagi kamu sendiri. Peran seorang ibu Tidak cuma menjaga rumah saja, namun anda pun harus memastikan kebutuhan gizi terpenuhi dan juga olahan yang dimakan orang tercinta wajib lezat.

Di waktu  sekarang, kalian sebenarnya mampu mengorder olahan instan walaupun tidak harus ribet membuatnya dahulu. Tetapi ada juga lho orang yang selalu ingin memberikan makanan yang terlezat bagi keluarganya. Lantaran, menghidangkan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan selera famili. 



Mungkinkah anda merupakan seorang penggemar kare ayam simpel?. Asal kamu tahu, kare ayam simpel merupakan sajian khas di Nusantara yang kini disenangi oleh banyak orang di hampir setiap daerah di Nusantara. Kita dapat menyajikan kare ayam simpel sendiri di rumah dan boleh dijadikan makanan kesenanganmu di hari libur.

Kita tak perlu bingung jika kamu ingin mendapatkan kare ayam simpel, sebab kare ayam simpel tidak sukar untuk didapatkan dan juga kita pun boleh menghidangkannya sendiri di tempatmu. kare ayam simpel bisa dimasak memalui beraneka cara. Sekarang sudah banyak banget cara kekinian yang menjadikan kare ayam simpel semakin lebih nikmat.

Resep kare ayam simpel pun mudah dibuat, lho. Kalian tidak usah capek-capek untuk membeli kare ayam simpel, lantaran Anda bisa menyiapkan di rumahmu. Bagi Kamu yang akan membuatnya, inilah resep untuk menyajikan kare ayam simpel yang mantab yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Kare ayam Simpel:

1. Sediakan 1/4 kg daging ayam + 6 bh ceker ayam
1. Gunakan 1 bks santan instan bubuk
1. Siapkan  Bumbu cemplung :
1. Ambil 1 lbr daun salam
1. Gunakan 1 btng serai
1. Siapkan Sejempol lengkuas
1. Sediakan 3 lbr daun jeruk
1. Gunakan 1/4 sdt merica bubuk
1. Ambil  Garam, gula, kaldu bubuk (bisa di skip)
1. Ambil  Bumbu halus :
1. Sediakan 5 siung bawang merah
1. Sediakan 2 siung bawang putih
1. Sediakan 1/2 bh cabe merah besar
1. Gunakan 3 btr kemiri
1. Gunakan 1 sdt ketumbar
1. Siapkan 1 cm kunyit
1. Gunakan 2 cm jahe




<!--inarticleads2-->

##### Cara membuat Kare ayam Simpel:

1. Potong ayam menjadi beberapa bagian sesuai selera. Cuci bersih.
1. Didihkan air dalam panci, setelah mendidih rebus ayam bersama daun salam sekitar 10 menit untuk menghilangkan bau amisnya. Buang airnya. Cuci kembali hingga bersih
1. Ganti kembali airnya kemudian rebus lagi menggunakan api kecil.
1. Haluskan bumbu halus. Kemudian tumis hingga harum. Masukkan bumbu cemplungnya. Tumis lagi hingga bau langunya hilang.
1. Masukkan bumbu dalam rebusan ayam. Biarkan sebentar hingga bumbu meresap.
1. Tambahkan santan bubuk, aduk rata. Jangan lupa beri garam, gula dan merica bubuk. Tes rasa. Biarkan hingga kuah sedikit berkurang dan agak mengental.




Ternyata cara buat kare ayam simpel yang lezat simple ini gampang sekali ya! Kalian semua bisa mencobanya. Cara Membuat kare ayam simpel Sangat cocok banget untuk kamu yang baru belajar memasak maupun juga untuk anda yang sudah pandai memasak.

Apakah kamu ingin mencoba membikin resep kare ayam simpel nikmat tidak ribet ini? Kalau kalian mau, yuk kita segera buruan siapin alat dan bahan-bahannya, setelah itu bikin deh Resep kare ayam simpel yang mantab dan sederhana ini. Benar-benar taidak sulit kan. 

Maka dari itu, ketimbang kalian berlama-lama, yuk langsung aja sajikan resep kare ayam simpel ini. Pasti kamu gak akan nyesel sudah buat resep kare ayam simpel nikmat simple ini! Selamat berkreasi dengan resep kare ayam simpel lezat tidak ribet ini di rumah masing-masing,oke!.

