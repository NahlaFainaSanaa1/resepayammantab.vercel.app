---
description: "Cara buat Lontong Opor Ayam &amp;amp; Hati yang lezat Untuk Jualan"
title: "Cara buat Lontong Opor Ayam &amp;amp; Hati yang lezat Untuk Jualan"
slug: 390-cara-buat-lontong-opor-ayam-and-amp-hati-yang-lezat-untuk-jualan
date: 2021-03-05T23:39:57.338Z
image: https://img-global.cpcdn.com/recipes/07aa4f7c193c2933/680x482cq70/lontong-opor-ayam-hati-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/07aa4f7c193c2933/680x482cq70/lontong-opor-ayam-hati-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/07aa4f7c193c2933/680x482cq70/lontong-opor-ayam-hati-foto-resep-utama.jpg
author: Tyler Greer
ratingvalue: 3.2
reviewcount: 10
recipeingredient:
- "1/2 kg ayam"
- "5 buah hati ayam"
- "1 liter santan"
- "2 sdmgl pasir"
- " Garam sckp"
- " Kaldu jamur"
- "1/2 sdt lada bubuk"
- " Bumbu halus"
- "6 siung bamer"
- "3 siung baput"
- "Seruas jahe"
- "3 ruas kunyit"
- "1/2 sdt ketumbar"
- "5 biji kemiri"
- " Empon2"
- "1 batang serai"
- "4 daun salam"
- "3 ruas lengkuas"
- " Sambel kentang"
- "1/4 kg kentang goreng"
- "4 buah Rempola hati ayam potong"
- "4 bamer"
- "3 baput"
- " Garamgulakaldu sckp"
- "2 kemiri"
- "3 cabe merah"
- "5 cabe rawit"
- "Seruas loas"
- "Selembar daun salam"
- "2 daun jeruk"
- " Bahan pelengkap"
- " Lontong"
- " Bawang goreng"
recipeinstructions:
- "Sebelumnya rebus ayam dan hati ayam dgn daun salam selama 20 menit. Angkat tiriskan."
- "Tumis bumbu yg sdh dihaluskan tambahkan empon2..tumis sampaj harum dan agak kering. Masukan ayam dan hati ayam. Tambahkan santan, gula pasir, kaldu jamur dan garam. Cek rasa."
- "Sambel goreng kentang, tumis smua bumbunya yg sdh dihaluskan. Masukan kentang dan rempelo atinya..tambahkan bumbu2 lainya, cek rasa.angkat."
- "Sajikan di piring taruh potongan lontong, tambahkan sambel gorwng kentang dan hatinya, sambel goreng, masukan kuah opor dan taburi bawang goreng. Siap di nikmatii.. Hmm manttulll😍🤤"
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 160 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dinner

---


![Lontong Opor Ayam &amp; Hati](https://img-global.cpcdn.com/recipes/07aa4f7c193c2933/680x482cq70/lontong-opor-ayam-hati-foto-resep-utama.jpg)

Jika anda seorang ibu, menyajikan santapan enak untuk keluarga tercinta merupakan hal yang membahagiakan bagi kamu sendiri. Peran seorang  wanita Tidak saja mengerjakan pekerjaan rumah saja, tetapi anda juga harus menyediakan kebutuhan nutrisi terpenuhi dan masakan yang dimakan orang tercinta harus menggugah selera.

Di masa  sekarang, anda sebenarnya bisa mengorder hidangan jadi walaupun tidak harus ribet membuatnya terlebih dahulu. Namun ada juga orang yang selalu mau menghidangkan yang terlezat untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan masakan kesukaan orang tercinta. 



Mungkinkah anda adalah salah satu penggemar lontong opor ayam &amp; hati?. Tahukah kamu, lontong opor ayam &amp; hati adalah sajian khas di Nusantara yang sekarang disukai oleh orang-orang dari hampir setiap tempat di Indonesia. Kita bisa memasak lontong opor ayam &amp; hati sendiri di rumah dan boleh jadi makanan favorit di hari liburmu.

Kalian jangan bingung untuk memakan lontong opor ayam &amp; hati, karena lontong opor ayam &amp; hati mudah untuk ditemukan dan juga kalian pun bisa mengolahnya sendiri di tempatmu. lontong opor ayam &amp; hati boleh dibuat lewat beraneka cara. Sekarang telah banyak resep modern yang menjadikan lontong opor ayam &amp; hati lebih mantap.

Resep lontong opor ayam &amp; hati juga mudah dibikin, lho. Anda tidak usah capek-capek untuk membeli lontong opor ayam &amp; hati, lantaran Kalian mampu menghidangkan di rumahmu. Untuk Kita yang mau membuatnya, di bawah ini adalah cara untuk menyajikan lontong opor ayam &amp; hati yang lezat yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Lontong Opor Ayam &amp; Hati:

1. Sediakan 1/2 kg ayam
1. Ambil 5 buah hati ayam
1. Siapkan 1 liter santan
1. Ambil 2 sdmgl pasir
1. Gunakan  Garam sckp
1. Siapkan  Kaldu jamur
1. Sediakan 1/2 sdt lada bubuk
1. Sediakan  Bumbu halus:
1. Ambil 6 siung bamer
1. Siapkan 3 siung baput
1. Ambil Seruas jahe
1. Siapkan 3 ruas kunyit
1. Ambil 1/2 sdt ketumbar
1. Siapkan 5 biji kemiri
1. Gunakan  Empon2:
1. Gunakan 1 batang serai
1. Gunakan 4 daun salam
1. Ambil 3 ruas lengkuas
1. Siapkan  Sambel kentang:
1. Sediakan 1/4 kg kentang goreng
1. Sediakan 4 buah Rempola hati ayam potong
1. Sediakan 4 bamer
1. Ambil 3 baput
1. Sediakan  Garam,gula,kaldu sckp
1. Gunakan 2 kemiri
1. Siapkan 3 cabe merah
1. Sediakan 5 cabe rawit
1. Gunakan Seruas loas
1. Gunakan Selembar daun salam
1. Siapkan 2 daun jeruk
1. Ambil  Bahan pelengkap:
1. Sediakan  Lontong
1. Ambil  Bawang goreng




<!--inarticleads2-->

##### Cara membuat Lontong Opor Ayam &amp; Hati:

1. Sebelumnya rebus ayam dan hati ayam dgn daun salam selama 20 menit. Angkat tiriskan.
1. Tumis bumbu yg sdh dihaluskan tambahkan empon2..tumis sampaj harum dan agak kering. Masukan ayam dan hati ayam. Tambahkan santan, gula pasir, kaldu jamur dan garam. Cek rasa.
1. Sambel goreng kentang, tumis smua bumbunya yg sdh dihaluskan. Masukan kentang dan rempelo atinya..tambahkan bumbu2 lainya, cek rasa.angkat.
1. Sajikan di piring taruh potongan lontong, tambahkan sambel gorwng kentang dan hatinya, sambel goreng, masukan kuah opor dan taburi bawang goreng. Siap di nikmatii.. Hmm manttulll😍🤤




Wah ternyata cara membuat lontong opor ayam &amp; hati yang enak tidak ribet ini enteng sekali ya! Kita semua mampu membuatnya. Cara buat lontong opor ayam &amp; hati Cocok sekali untuk kamu yang baru akan belajar memasak ataupun juga bagi kalian yang telah ahli memasak.

Tertarik untuk mencoba membikin resep lontong opor ayam &amp; hati mantab tidak ribet ini? Kalau mau, yuk kita segera menyiapkan alat dan bahan-bahannya, lalu bikin deh Resep lontong opor ayam &amp; hati yang nikmat dan simple ini. Benar-benar mudah kan. 

Maka dari itu, ketimbang kalian berlama-lama, hayo langsung aja sajikan resep lontong opor ayam &amp; hati ini. Dijamin anda tiidak akan menyesal sudah bikin resep lontong opor ayam &amp; hati mantab sederhana ini! Selamat mencoba dengan resep lontong opor ayam &amp; hati nikmat sederhana ini di tempat tinggal kalian sendiri,oke!.

