---
description: "Cara membuat Ayam goreng krispi saus madu Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam goreng krispi saus madu Sederhana dan Mudah Dibuat"
slug: 76-cara-membuat-ayam-goreng-krispi-saus-madu-sederhana-dan-mudah-dibuat
date: 2021-05-04T13:10:13.012Z
image: https://img-global.cpcdn.com/recipes/0846ca80b04e8549/680x482cq70/ayam-goreng-krispi-saus-madu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0846ca80b04e8549/680x482cq70/ayam-goreng-krispi-saus-madu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0846ca80b04e8549/680x482cq70/ayam-goreng-krispi-saus-madu-foto-resep-utama.jpg
author: Bess Lindsey
ratingvalue: 3.4
reviewcount: 9
recipeingredient:
- "1/2 kg dada ayam"
- "secukupnya Air perasan lemon"
- "secukupnya Garam"
- "secukupnya Lada"
- "200 gr tepung terigu"
- "50 gr tepung beras"
- "1 sdt cabe bubuk"
- "secukupnya Air"
- "1/2 buah bawang bombay"
- "3 siung bawang putih"
- "2 sdm saus cabai"
- "2 sdm saus tomat"
- "2 sdm kecap manis"
- "1 sdt lada"
- "1 sdt garam"
- "2 sdm madu"
- "1 sdm air perasan lemon"
- "200 ml air kaldu ayam atau bisa pakai air biasa aja"
- " Wijen sangrai untuk taburan"
recipeinstructions:
- "Ayam dimarinasi dengan air perasan lemon, lada dan garam, diamkan 10- 15 menit"
- "Campurkan tepung terigu, tepung beras, cabai bubuk dan beri air. Celupkan ayam yang telah dimarinasi tadi, goreng hingga keemasan."
- "Untuk saus, tumis bawang bombay sampai layu, selanjutnya tumis bawang putih sampai harum"
- "Masukkan air kaldu, saus tomat, saus cabai, madu, kecap, dan lada. Aduk sampai mendidih."
- "Masukkan ayam yang telah digoreng tadi, aduk lagi sampai tercampur. Gunakan api kecil. Jangan lupa beri garam. Koreksi rasa."
- "Setelah selesai, sajikan dalam piring dan taburi wijen"
categories:
- Resep
tags:
- ayam
- goreng
- krispi

katakunci: ayam goreng krispi 
nutrition: 171 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam goreng krispi saus madu](https://img-global.cpcdn.com/recipes/0846ca80b04e8549/680x482cq70/ayam-goreng-krispi-saus-madu-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyuguhkan santapan menggugah selera buat keluarga adalah hal yang menyenangkan untuk anda sendiri. Tanggung jawab seorang ibu bukan sekadar mengerjakan pekerjaan rumah saja, tapi kamu pun harus menyediakan keperluan nutrisi terpenuhi dan hidangan yang dikonsumsi keluarga tercinta wajib nikmat.

Di waktu  saat ini, kita sebenarnya bisa memesan panganan instan meski tidak harus capek memasaknya terlebih dahulu. Tapi banyak juga lho mereka yang selalu ingin memberikan hidangan yang terbaik untuk keluarganya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penggemar ayam goreng krispi saus madu?. Tahukah kamu, ayam goreng krispi saus madu merupakan hidangan khas di Nusantara yang saat ini digemari oleh setiap orang di hampir setiap tempat di Indonesia. Kita dapat menyajikan ayam goreng krispi saus madu sendiri di rumahmu dan dapat dijadikan hidangan favorit di akhir pekanmu.

Kita tidak perlu bingung jika kamu ingin menyantap ayam goreng krispi saus madu, lantaran ayam goreng krispi saus madu gampang untuk dicari dan juga anda pun dapat mengolahnya sendiri di tempatmu. ayam goreng krispi saus madu bisa dimasak dengan berbagai cara. Sekarang telah banyak banget cara modern yang membuat ayam goreng krispi saus madu lebih mantap.

Resep ayam goreng krispi saus madu juga gampang dibuat, lho. Anda tidak usah capek-capek untuk memesan ayam goreng krispi saus madu, sebab Anda dapat menyiapkan di rumahmu. Untuk Kamu yang hendak menghidangkannya, berikut cara untuk membuat ayam goreng krispi saus madu yang lezat yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam goreng krispi saus madu:

1. Gunakan 1/2 kg dada ayam
1. Siapkan secukupnya Air perasan lemon
1. Siapkan secukupnya Garam
1. Gunakan secukupnya Lada
1. Gunakan 200 gr tepung terigu
1. Siapkan 50 gr tepung beras
1. Sediakan 1 sdt cabe bubuk
1. Sediakan secukupnya Air
1. Ambil 1/2 buah bawang bombay
1. Ambil 3 siung bawang putih
1. Ambil 2 sdm saus cabai
1. Sediakan 2 sdm saus tomat
1. Sediakan 2 sdm kecap manis
1. Siapkan 1 sdt lada
1. Gunakan 1 sdt garam
1. Siapkan 2 sdm madu
1. Siapkan 1 sdm air perasan lemon
1. Ambil 200 ml air kaldu ayam atau bisa pakai air biasa aja
1. Gunakan  Wijen sangrai untuk taburan




<!--inarticleads2-->

##### Cara membuat Ayam goreng krispi saus madu:

1. Ayam dimarinasi dengan air perasan lemon, lada dan garam, diamkan 10- 15 menit
1. Campurkan tepung terigu, tepung beras, cabai bubuk dan beri air. Celupkan ayam yang telah dimarinasi tadi, goreng hingga keemasan.
1. Untuk saus, tumis bawang bombay sampai layu, selanjutnya tumis bawang putih sampai harum
1. Masukkan air kaldu, saus tomat, saus cabai, madu, kecap, dan lada. Aduk sampai mendidih.
1. Masukkan ayam yang telah digoreng tadi, aduk lagi sampai tercampur. Gunakan api kecil. Jangan lupa beri garam. Koreksi rasa.
1. Setelah selesai, sajikan dalam piring dan taburi wijen




Ternyata resep ayam goreng krispi saus madu yang lezat tidak rumit ini enteng sekali ya! Kita semua mampu memasaknya. Resep ayam goreng krispi saus madu Sangat sesuai sekali buat kita yang sedang belajar memasak ataupun bagi kamu yang sudah lihai memasak.

Tertarik untuk mulai mencoba membikin resep ayam goreng krispi saus madu nikmat tidak ribet ini? Kalau ingin, mending kamu segera menyiapkan peralatan dan bahannya, kemudian buat deh Resep ayam goreng krispi saus madu yang mantab dan simple ini. Benar-benar mudah kan. 

Jadi, daripada kalian berfikir lama-lama, ayo kita langsung saja sajikan resep ayam goreng krispi saus madu ini. Pasti kamu gak akan menyesal sudah bikin resep ayam goreng krispi saus madu mantab simple ini! Selamat berkreasi dengan resep ayam goreng krispi saus madu mantab tidak rumit ini di tempat tinggal masing-masing,oke!.

