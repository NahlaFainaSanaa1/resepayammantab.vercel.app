---
description: "Bahan-bahan Kare Ayam Solo yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Kare Ayam Solo yang lezat dan Mudah Dibuat"
slug: 113-bahan-bahan-kare-ayam-solo-yang-lezat-dan-mudah-dibuat
date: 2021-06-21T14:11:30.426Z
image: https://img-global.cpcdn.com/recipes/1112e81b430b9867/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1112e81b430b9867/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1112e81b430b9867/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Bertha Perkins
ratingvalue: 3.3
reviewcount: 6
recipeingredient:
- " Bumbu Utama "
- "500 gram dada ayam  fillet"
- "1 bungkus soun cap mangkok"
- "500 ml santan kara"
- "3 kentang  5 wortel"
- " Bumbu Halus "
- "5 butir bawang merah"
- "5 butir bawang putih"
- "2 butir kemiri"
- "1 sdm kunyit bubuk"
- "1 sdm ketumbar bubuk"
- "1/2 sdt merica bubuk"
- "1 sachet kecil bumbu campur kayu manis jinten pala  2 lembar daun jeruk 1 lembar salam 1 batang serai"
- " Bahan Pelengkap "
- "1 bungkus soun di rendam air panas 3menit"
- "5 wortel direbus"
- "3 kentang di iris tipis lalu goreng"
- " daun bawang  sledri"
- " bawang goreng"
recipeinstructions:
- "Siapkan bahan utama. Lalu, rebus ayam (kaldu jangan dibuang)"
- "Siapkan bumbu halus, karena sedikit bumbu ini aku uleg aja moms terus ditumis sampai harum ya!"
- "Sekira udah cukup numisnya, masukin 500ml santan kara dan masukin tumisan bumbu + santan tadi ke kuah ayam yg sudah mendidih sambil tambah garam, penyedap secukupnya ya. Sembari nunggu, goreng kentang, rebus wortelnya, dan rendam soun di air panas selama 3 menit lalu tiriskan."
- "Voila beres deh.. ready to serve. Makan nya pake pendamping potongan rebusan wortel dan kentang tipis yg udh di goreng sama soun yg udah ditiriskan. Potongan ayam di dalem kuah jangan lupa diangkat (dagingnya suwirin buat makan) kasih irisan daun bawang sledri dan bawang goreng!! enak deh. yakin. Selamat mencoba ya😉"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 196 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/1112e81b430b9867/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Selaku seorang orang tua, menyajikan hidangan sedap bagi keluarga adalah hal yang sangat menyenangkan untuk anda sendiri. Peran seorang istri bukan hanya menangani rumah saja, tapi kamu juga wajib menyediakan keperluan nutrisi tercukupi dan juga santapan yang disantap orang tercinta wajib lezat.

Di masa  saat ini, kalian memang dapat memesan santapan jadi walaupun tanpa harus susah memasaknya dahulu. Tetapi banyak juga orang yang memang mau menghidangkan yang terlezat bagi orang tercintanya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan keluarga. 



Mungkinkah kamu salah satu penikmat kare ayam solo?. Asal kamu tahu, kare ayam solo adalah hidangan khas di Nusantara yang kini disenangi oleh orang-orang di berbagai tempat di Indonesia. Kita bisa menghidangkan kare ayam solo sendiri di rumah dan dapat dijadikan hidangan favorit di hari liburmu.

Anda jangan bingung untuk memakan kare ayam solo, karena kare ayam solo tidak sulit untuk didapatkan dan kalian pun dapat menghidangkannya sendiri di tempatmu. kare ayam solo boleh diolah dengan beraneka cara. Saat ini sudah banyak sekali resep kekinian yang membuat kare ayam solo semakin lebih nikmat.

Resep kare ayam solo juga gampang sekali dibuat, lho. Kita jangan repot-repot untuk membeli kare ayam solo, sebab Kalian dapat menyiapkan ditempatmu. Untuk Anda yang mau membuatnya, berikut resep menyajikan kare ayam solo yang lezat yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Kare Ayam Solo:

1. Ambil  Bumbu Utama :
1. Siapkan 500 gram dada ayam / fillet
1. Ambil 1 bungkus soun cap “mangkok”
1. Ambil 500 ml santan kara
1. Gunakan 3 kentang &amp; 5 wortel
1. Sediakan  Bumbu Halus :
1. Ambil 5 butir bawang merah
1. Gunakan 5 butir bawang putih
1. Siapkan 2 butir kemiri
1. Siapkan 1 sdm kunyit bubuk
1. Siapkan 1 sdm ketumbar bubuk
1. Siapkan 1/2 sdt merica bubuk
1. Ambil 1 sachet kecil bumbu campur (kayu manis, jinten, pala) &amp; 2 lembar daun jeruk, 1 lembar salam, 1 batang serai
1. Sediakan  Bahan Pelengkap :
1. Ambil 1 bungkus soun di rendam air panas (3menit)
1. Ambil 5 wortel direbus
1. Siapkan 3 kentang di iris tipis lalu goreng
1. Siapkan  daun bawang &amp; sledri
1. Sediakan  bawang goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Kare Ayam Solo:

1. Siapkan bahan utama. Lalu, rebus ayam (kaldu jangan dibuang)
<img src="https://img-global.cpcdn.com/steps/f403ea905efae21c/160x128cq70/kare-ayam-solo-langkah-memasak-1-foto.jpg" alt="Kare Ayam Solo"><img src="https://img-global.cpcdn.com/steps/41c1b3d5ea2989e9/160x128cq70/kare-ayam-solo-langkah-memasak-1-foto.jpg" alt="Kare Ayam Solo"><img src="https://img-global.cpcdn.com/steps/cb8cfb8d2a277177/160x128cq70/kare-ayam-solo-langkah-memasak-1-foto.jpg" alt="Kare Ayam Solo">1. Siapkan bumbu halus, karena sedikit bumbu ini aku uleg aja moms terus ditumis sampai harum ya!
1. Sekira udah cukup numisnya, masukin 500ml santan kara dan masukin tumisan bumbu + santan tadi ke kuah ayam yg sudah mendidih sambil tambah garam, penyedap secukupnya ya. Sembari nunggu, goreng kentang, rebus wortelnya, dan rendam soun di air panas selama 3 menit lalu tiriskan.
1. Voila beres deh.. ready to serve. Makan nya pake pendamping potongan rebusan wortel dan kentang tipis yg udh di goreng sama soun yg udah ditiriskan. Potongan ayam di dalem kuah jangan lupa diangkat (dagingnya suwirin buat makan) kasih irisan daun bawang sledri dan bawang goreng!! enak deh. yakin. Selamat mencoba ya😉




Ternyata cara buat kare ayam solo yang enak sederhana ini gampang sekali ya! Semua orang dapat membuatnya. Resep kare ayam solo Sesuai sekali untuk anda yang baru belajar memasak atau juga untuk anda yang telah hebat dalam memasak.

Tertarik untuk mencoba membuat resep kare ayam solo mantab tidak ribet ini? Kalau anda ingin, yuk kita segera menyiapkan alat dan bahannya, lalu buat deh Resep kare ayam solo yang enak dan tidak ribet ini. Betul-betul taidak sulit kan. 

Maka, daripada kalian diam saja, ayo kita langsung buat resep kare ayam solo ini. Dijamin kalian tiidak akan nyesel bikin resep kare ayam solo mantab simple ini! Selamat mencoba dengan resep kare ayam solo nikmat simple ini di tempat tinggal masing-masing,ya!.

