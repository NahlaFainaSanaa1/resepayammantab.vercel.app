---
description: "Bahan-bahan Sempol Tanpa Ayam yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Sempol Tanpa Ayam yang nikmat dan Mudah Dibuat"
slug: 169-bahan-bahan-sempol-tanpa-ayam-yang-nikmat-dan-mudah-dibuat
date: 2021-01-30T09:04:20.204Z
image: https://img-global.cpcdn.com/recipes/df643940b18b891b/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df643940b18b891b/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df643940b18b891b/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
author: Mark Norman
ratingvalue: 4.6
reviewcount: 15
recipeingredient:
- "8 sdm munjung tepung terigu"
- "5 sdm munjung tepung tapioka"
- "2 siung kecil bawang putih haluskan"
- "secukupnya Garam"
- "secukupnya Lada bubuk"
- "secukupnya Kaldu ayam"
- "secukupnya Air panas"
- "1 butir telur ayam"
- " Bahan cocolan "
- " Saus sambal optional"
recipeinstructions:
- "Campurkan tepung terigu, tepung tapioka, bawang putih yang dihaluskan, garam, lada dan kaldu bubuk. Aduk hingga rata"
- "Panaskan air, lalu masukan sedikit demi sedikit hingga terbentuk adonan"
- "Bentuk adonan bulat memanjang, lalu tusukan dengan tusuk sate."
- "Panaskan air yang banyak untuk merebus sempol(beri minyak sedikit ya bun)."
- "Rebus sempol sampai terapung, angkat tiriskan."
- "Kocok telur sampai agak berbusa. Tambahkan sedikit garam dan lada"
- "Panaskan wajan berisi minyak yang banyak"
- "Goreng sempol tanpa telur(30 detik saja biar dalemnya matang)"
- "Celupkan sempol pada telur, lalu gulung (Gunakan api sedang)"
- "Tunggu hingga sempol berwarna kecoklatan. Angkat dan tiriskan :)"
- "Sajikan dengan sambal atau bahan cocolan lainnya :)"
categories:
- Resep
tags:
- sempol
- tanpa
- ayam

katakunci: sempol tanpa ayam 
nutrition: 294 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dessert

---


![Sempol Tanpa Ayam](https://img-global.cpcdn.com/recipes/df643940b18b891b/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan hidangan menggugah selera pada keluarga tercinta merupakan suatu hal yang sangat menyenangkan bagi anda sendiri. Tanggung jawab seorang ibu bukan cuman menjaga rumah saja, namun anda pun wajib memastikan kebutuhan nutrisi terpenuhi dan hidangan yang dimakan keluarga tercinta harus nikmat.

Di zaman  saat ini, anda sebenarnya dapat mengorder panganan yang sudah jadi meski tidak harus repot membuatnya lebih dulu. Tapi ada juga lho orang yang memang mau menghidangkan yang terlezat untuk orang yang dicintainya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan keluarga. 



Apakah anda adalah salah satu penggemar sempol tanpa ayam?. Tahukah kamu, sempol tanpa ayam adalah sajian khas di Nusantara yang sekarang disukai oleh orang-orang di hampir setiap wilayah di Nusantara. Anda dapat menyajikan sempol tanpa ayam kreasi sendiri di rumahmu dan boleh jadi hidangan kesenanganmu di hari liburmu.

Kalian jangan bingung untuk mendapatkan sempol tanpa ayam, sebab sempol tanpa ayam mudah untuk didapatkan dan kita pun dapat membuatnya sendiri di rumah. sempol tanpa ayam bisa dibuat memalui beragam cara. Sekarang ada banyak sekali cara modern yang menjadikan sempol tanpa ayam semakin enak.

Resep sempol tanpa ayam pun mudah untuk dibuat, lho. Kamu tidak perlu ribet-ribet untuk memesan sempol tanpa ayam, sebab Kita bisa menghidangkan di rumahmu. Untuk Anda yang hendak membuatnya, berikut resep menyajikan sempol tanpa ayam yang mantab yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Sempol Tanpa Ayam:

1. Sediakan 8 sdm munjung tepung terigu
1. Gunakan 5 sdm munjung tepung tapioka
1. Sediakan 2 siung kecil bawang putih (haluskan)
1. Ambil secukupnya Garam
1. Sediakan secukupnya Lada bubuk
1. Ambil secukupnya Kaldu ayam
1. Sediakan secukupnya Air panas
1. Siapkan 1 butir telur ayam
1. Siapkan  Bahan cocolan :
1. Sediakan  Saus sambal (optional)




<!--inarticleads2-->

##### Langkah-langkah membuat Sempol Tanpa Ayam:

1. Campurkan tepung terigu, tepung tapioka, bawang putih yang dihaluskan, garam, lada dan kaldu bubuk. Aduk hingga rata
1. Panaskan air, lalu masukan sedikit demi sedikit hingga terbentuk adonan
1. Bentuk adonan bulat memanjang, lalu tusukan dengan tusuk sate.
1. Panaskan air yang banyak untuk merebus sempol(beri minyak sedikit ya bun).
1. Rebus sempol sampai terapung, angkat tiriskan.
1. Kocok telur sampai agak berbusa. Tambahkan sedikit garam dan lada
1. Panaskan wajan berisi minyak yang banyak
1. Goreng sempol tanpa telur(30 detik saja biar dalemnya matang)
1. Celupkan sempol pada telur, lalu gulung (Gunakan api sedang)
1. Tunggu hingga sempol berwarna kecoklatan. Angkat dan tiriskan :)
1. Sajikan dengan sambal atau bahan cocolan lainnya :)




Wah ternyata cara membuat sempol tanpa ayam yang mantab tidak rumit ini mudah sekali ya! Kamu semua bisa membuatnya. Resep sempol tanpa ayam Sangat cocok banget untuk anda yang baru akan belajar memasak ataupun juga untuk anda yang sudah ahli memasak.

Tertarik untuk mencoba membuat resep sempol tanpa ayam mantab sederhana ini? Kalau kalian tertarik, yuk kita segera siapin alat-alat dan bahan-bahannya, maka bikin deh Resep sempol tanpa ayam yang lezat dan tidak ribet ini. Benar-benar mudah kan. 

Maka, ketimbang anda berlama-lama, ayo langsung aja bikin resep sempol tanpa ayam ini. Dijamin kamu tak akan menyesal sudah bikin resep sempol tanpa ayam mantab simple ini! Selamat mencoba dengan resep sempol tanpa ayam nikmat sederhana ini di tempat tinggal kalian sendiri,ya!.

