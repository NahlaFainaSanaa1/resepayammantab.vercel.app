---
description: "Cara membuat Ayam kecap (masakan rumahan sederhana) yang enak Untuk Jualan"
title: "Cara membuat Ayam kecap (masakan rumahan sederhana) yang enak Untuk Jualan"
slug: 135-cara-membuat-ayam-kecap-masakan-rumahan-sederhana-yang-enak-untuk-jualan
date: 2021-05-11T17:26:38.452Z
image: https://img-global.cpcdn.com/recipes/08f99ed5717b6803/680x482cq70/ayam-kecap-masakan-rumahan-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/08f99ed5717b6803/680x482cq70/ayam-kecap-masakan-rumahan-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/08f99ed5717b6803/680x482cq70/ayam-kecap-masakan-rumahan-sederhana-foto-resep-utama.jpg
author: Rena Sanchez
ratingvalue: 3.5
reviewcount: 3
recipeingredient:
- "1/2 kg ayam potong menjadi beberapa bagian"
- " Minyak goreng"
- " air bersih"
- " Bumbu A "
- "4 siung bawang merah"
- "3 siung bawang putih"
- "1 sdt ketumbar"
- "1 sdt merica"
- "1 buah kemiri"
- " Bumbu B "
- "3 sdm makan gula merah yg telah disisir"
- "2 sdm kecap manis"
- " Royco"
- " Rempah "
- "2 ruas lengkuas geprek"
- "1 batang serai memarkan"
- "2 helai daun salam"
- "Sedikit asam jawa"
recipeinstructions:
- "Goreng setengah matang ayam, tiriskan (supaya bumbu menyerap sampai ke dalam daging dan tekstur daging lembut)"
- "Ulek halus bawang2, merica dan ketumbar. Lalu oseng bumbu dengan menggunakan 4 sdm minyak goreng"
- "Masukkan lengkuas, salam dan serai. Oseng bumbu sampai harum"
- "Setelah bumbu harum, tambahkan 3 gelas air putih bersih. Tunggu mendidih sambil di aduk"
- "Setelah mendidih, masukkan ayam. Tambahkan juga gula merah dan royco juga asam jawa"
- "Aduk lagi lalu tutup wajan supaya ayamnya makin empuk dan aroma mya tidak kabur. Kecilkan nyala api nya."
- "Setelah 5 menit, balikkan ayam agar bumbu nya merata ke bagian ayam yang lain."
- "Koreksi rasa lalu tambahkan kecap. tunggu sampai air nya surut"
- "Ketika air nya surut dan mengental, aduk sebentar. Lalu matikan kompor dan ayam kecap siap di nikmati ^^"
categories:
- Resep
tags:
- ayam
- kecap
- masakan

katakunci: ayam kecap masakan 
nutrition: 261 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam kecap (masakan rumahan sederhana)](https://img-global.cpcdn.com/recipes/08f99ed5717b6803/680x482cq70/ayam-kecap-masakan-rumahan-sederhana-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan olahan lezat kepada keluarga adalah suatu hal yang memuaskan bagi anda sendiri. Kewajiban seorang istri bukan saja menangani rumah saja, tetapi anda juga harus menyediakan keperluan gizi tercukupi dan santapan yang dikonsumsi anak-anak wajib mantab.

Di masa  sekarang, kita sebenarnya dapat membeli santapan jadi walaupun tanpa harus capek membuatnya terlebih dahulu. Tetapi ada juga mereka yang memang mau memberikan makanan yang terbaik bagi orang yang dicintainya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai kesukaan famili. 

Hay semua. jd hari ini saya akan memasak ayam kecap yang simpel dan cepat. resep sederhana sehari hari masakan rumahan yang sederhana.trimakasih semoga. Masakan ayam suwir pas untuk sajian keluarga sederhana. Menu masakan daging ayam rumahan murah bahan bumbunya.

Mungkinkah anda merupakan seorang penggemar ayam kecap (masakan rumahan sederhana)?. Asal kamu tahu, ayam kecap (masakan rumahan sederhana) adalah hidangan khas di Nusantara yang saat ini disenangi oleh kebanyakan orang di berbagai daerah di Nusantara. Kita bisa membuat ayam kecap (masakan rumahan sederhana) buatan sendiri di rumahmu dan boleh dijadikan hidangan kesenanganmu di hari libur.

Kamu tak perlu bingung jika kamu ingin menyantap ayam kecap (masakan rumahan sederhana), karena ayam kecap (masakan rumahan sederhana) mudah untuk didapatkan dan kita pun boleh memasaknya sendiri di tempatmu. ayam kecap (masakan rumahan sederhana) bisa dimasak memalui bermacam cara. Sekarang ada banyak sekali cara kekinian yang menjadikan ayam kecap (masakan rumahan sederhana) semakin lebih enak.

Resep ayam kecap (masakan rumahan sederhana) juga mudah untuk dibuat, lho. Kamu jangan capek-capek untuk membeli ayam kecap (masakan rumahan sederhana), karena Kamu bisa menghidangkan di rumah sendiri. Untuk Kalian yang ingin menghidangkannya, berikut cara menyajikan ayam kecap (masakan rumahan sederhana) yang nikamat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam kecap (masakan rumahan sederhana):

1. Siapkan 1/2 kg ayam (potong menjadi beberapa bagian)
1. Sediakan  Minyak goreng
1. Gunakan  air bersih
1. Ambil  Bumbu A :
1. Gunakan 4 siung bawang merah
1. Ambil 3 siung bawang putih
1. Ambil 1 sdt ketumbar
1. Sediakan 1 sdt merica
1. Ambil 1 buah kemiri
1. Gunakan  Bumbu B :
1. Gunakan 3 sdm makan gula merah yg telah disisir
1. Gunakan 2 sdm kecap manis
1. Siapkan  Royco
1. Ambil  Rempah :
1. Gunakan 2 ruas lengkuas (geprek)
1. Ambil 1 batang serai (memarkan)
1. Siapkan 2 helai daun salam
1. Ambil Sedikit asam jawa


Daging sendiri terdiri dari berbagai jenis hewan, mulai dari daging sapi, kambing, ayam, dan lainnya. Resep ayam kecap spesial ini istimewa karena menggunakan mentega atau margarin untuk menumis. Setelah ayam digoreng terlebih dahulu, kita buat campuran saus berupa mentega, bawang, cabai, tomat, dan Bango Kecap Manis. Begitu semuanya siap, cukup aduk semua dan tambahkan sedikit air. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kecap (masakan rumahan sederhana):

1. Goreng setengah matang ayam, tiriskan (supaya bumbu menyerap sampai ke dalam daging dan tekstur daging lembut)
1. Ulek halus bawang2, merica dan ketumbar. Lalu oseng bumbu dengan menggunakan 4 sdm minyak goreng
1. Masukkan lengkuas, salam dan serai. Oseng bumbu sampai harum
1. Setelah bumbu harum, tambahkan 3 gelas air putih bersih. Tunggu mendidih sambil di aduk
1. Setelah mendidih, masukkan ayam. Tambahkan juga gula merah dan royco juga asam jawa
1. Aduk lagi lalu tutup wajan supaya ayamnya makin empuk dan aroma mya tidak kabur. Kecilkan nyala api nya.
1. Setelah 5 menit, balikkan ayam agar bumbu nya merata ke bagian ayam yang lain.
1. Koreksi rasa lalu tambahkan kecap. tunggu sampai air nya surut
1. Ketika air nya surut dan mengental, aduk sebentar. Lalu matikan kompor dan ayam kecap siap di nikmati ^^


Inilah resep ayam kecap yang nikmat, gurih dan bikin susah move on. Lengkap dengan cara membuat serta tips memasaknya untuk dicoba. Hampir setiap ibu menjadikan resep ayam kecap sebagai salah satu masakan andalannya, karena anak-anak pasti suka. Disebut ayam kecap, karena ayam yang dimasak dibumbui dengan kecap manis yang pekat sehingga warnanya berubah menjadi agak kecoklatan. Ayam goreng menjadi salah satu masakan rumahan yang sangat sederhana namun memiliki rasa yang lezat. 

Wah ternyata resep ayam kecap (masakan rumahan sederhana) yang lezat tidak rumit ini enteng banget ya! Semua orang dapat membuatnya. Cara buat ayam kecap (masakan rumahan sederhana) Sesuai banget untuk anda yang sedang belajar memasak ataupun untuk kalian yang sudah jago memasak.

Apakah kamu tertarik mencoba membikin resep ayam kecap (masakan rumahan sederhana) enak simple ini? Kalau kamu ingin, ayo kalian segera siapkan peralatan dan bahan-bahannya, lantas buat deh Resep ayam kecap (masakan rumahan sederhana) yang enak dan sederhana ini. Betul-betul mudah kan. 

Maka dari itu, ketimbang anda berfikir lama-lama, ayo kita langsung buat resep ayam kecap (masakan rumahan sederhana) ini. Pasti anda gak akan menyesal sudah bikin resep ayam kecap (masakan rumahan sederhana) mantab sederhana ini! Selamat berkreasi dengan resep ayam kecap (masakan rumahan sederhana) lezat tidak rumit ini di rumah kalian masing-masing,oke!.

