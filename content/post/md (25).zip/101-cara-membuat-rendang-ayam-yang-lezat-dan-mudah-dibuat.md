---
description: "Cara membuat Rendang Ayam yang lezat dan Mudah Dibuat"
title: "Cara membuat Rendang Ayam yang lezat dan Mudah Dibuat"
slug: 101-cara-membuat-rendang-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-02-22T22:06:46.833Z
image: https://img-global.cpcdn.com/recipes/d7de74cf3863ccb7/680x482cq70/rendang-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d7de74cf3863ccb7/680x482cq70/rendang-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d7de74cf3863ccb7/680x482cq70/rendang-ayam-foto-resep-utama.jpg
author: Violet Norris
ratingvalue: 4.6
reviewcount: 8
recipeingredient:
- "2 kg ayam potong sesuai selera"
- "500 ml Santan kental"
- "750 ml santan cair"
- "4 sdm bumbu dasar merah resep sebelumnya"
- "3 sdm bumbu dasar kuning resep sebelumnya"
- "1 sachet bumbu rendang indofood"
- "3 batang sereh geprek"
- "1 sdm bubuk ketumbar"
- "3 helai daun salam"
- "3 helai daun jeruk"
- "1 buah gula merah"
- "1 sachet Royco ayam"
- "secukupnya Garam"
recipeinstructions:
- "Potong dan cuci bersih ayam lalu tiriskan."
- "Tumis bumbu merah, bumbu kuning, bubuk ketumbar dan sereh sampai harum. Lalu masukan potongan ayam. Dan kemudian masukan santan.cair, aduk terus sampai mendidih agar santan tidak pecah."
- "Setelah mendidih, bisa didiamkan sampai santan agak menyusut. Lalu masukan daun salam, daun jeruk, gula merah, royco ayam dan garam. Masukan juga bumbu rendang indofood."
- "Lalu tambahkan santan kental, aduk sampai mendidih dengan api sedang. Jika sudah mendidih, diamkan sampai santan agak menyusut dan berubah warna. Koreksi rasa. Jika sudah mulai menyusut, bisa segera dimatikan. Jika ingin rendang yang agak garing, biarkan bumbu sampai benar&#34; menyusut."
categories:
- Resep
tags:
- rendang
- ayam

katakunci: rendang ayam 
nutrition: 188 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner

---


![Rendang Ayam](https://img-global.cpcdn.com/recipes/d7de74cf3863ccb7/680x482cq70/rendang-ayam-foto-resep-utama.jpg)

Jika anda seorang orang tua, menyajikan olahan enak bagi orang tercinta adalah suatu hal yang sangat menyenangkan bagi anda sendiri. Tugas seorang  wanita Tidak sekadar mengerjakan pekerjaan rumah saja, namun anda pun wajib menyediakan keperluan gizi terpenuhi dan olahan yang disantap keluarga tercinta mesti lezat.

Di zaman  sekarang, kita sebenarnya bisa mengorder masakan instan meski tidak harus repot memasaknya terlebih dahulu. Tetapi banyak juga orang yang selalu mau menyajikan yang terbaik untuk orang yang dicintainya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan kesukaan orang tercinta. 



Apakah anda salah satu penyuka rendang ayam?. Tahukah kamu, rendang ayam merupakan hidangan khas di Nusantara yang kini digemari oleh kebanyakan orang dari berbagai daerah di Nusantara. Kalian dapat membuat rendang ayam olahan sendiri di rumah dan dapat dijadikan hidangan kegemaranmu di akhir pekan.

Kita jangan bingung untuk memakan rendang ayam, lantaran rendang ayam sangat mudah untuk ditemukan dan juga kalian pun boleh mengolahnya sendiri di rumah. rendang ayam bisa diolah lewat berbagai cara. Kini pun telah banyak banget resep modern yang menjadikan rendang ayam semakin nikmat.

Resep rendang ayam pun mudah sekali untuk dibikin, lho. Kamu tidak perlu capek-capek untuk memesan rendang ayam, lantaran Kalian bisa membuatnya di rumah sendiri. Bagi Anda yang hendak menghidangkannya, di bawah ini adalah resep membuat rendang ayam yang nikamat yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Rendang Ayam:

1. Ambil 2 kg ayam potong sesuai selera
1. Ambil 500 ml Santan kental
1. Sediakan 750 ml santan cair
1. Ambil 4 sdm bumbu dasar merah (resep sebelumnya)
1. Sediakan 3 sdm bumbu dasar kuning (resep sebelumnya)
1. Siapkan 1 sachet bumbu rendang indofood
1. Sediakan 3 batang sereh geprek
1. Siapkan 1 sdm bubuk ketumbar
1. Sediakan 3 helai daun salam
1. Ambil 3 helai daun jeruk
1. Ambil 1 buah gula merah
1. Gunakan 1 sachet Royco ayam
1. Ambil secukupnya Garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Rendang Ayam:

1. Potong dan cuci bersih ayam lalu tiriskan.
1. Tumis bumbu merah, bumbu kuning, bubuk ketumbar dan sereh sampai harum. Lalu masukan potongan ayam. Dan kemudian masukan santan.cair, aduk terus sampai mendidih agar santan tidak pecah.
1. Setelah mendidih, bisa didiamkan sampai santan agak menyusut. Lalu masukan daun salam, daun jeruk, gula merah, royco ayam dan garam. Masukan juga bumbu rendang indofood.
1. Lalu tambahkan santan kental, aduk sampai mendidih dengan api sedang. Jika sudah mendidih, diamkan sampai santan agak menyusut dan berubah warna. Koreksi rasa. Jika sudah mulai menyusut, bisa segera dimatikan. Jika ingin rendang yang agak garing, biarkan bumbu sampai benar&#34; menyusut.




Wah ternyata resep rendang ayam yang lezat tidak rumit ini gampang sekali ya! Kamu semua mampu mencobanya. Resep rendang ayam Sangat sesuai banget buat kalian yang baru mau belajar memasak maupun juga untuk anda yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba buat resep rendang ayam lezat tidak rumit ini? Kalau tertarik, yuk kita segera buruan menyiapkan alat dan bahannya, lantas buat deh Resep rendang ayam yang mantab dan simple ini. Betul-betul mudah kan. 

Jadi, ketimbang anda berlama-lama, yuk langsung aja bikin resep rendang ayam ini. Pasti anda tiidak akan nyesel bikin resep rendang ayam lezat simple ini! Selamat mencoba dengan resep rendang ayam enak tidak ribet ini di tempat tinggal kalian sendiri,ya!.

