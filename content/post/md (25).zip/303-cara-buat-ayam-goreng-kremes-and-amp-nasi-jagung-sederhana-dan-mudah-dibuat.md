---
description: "Cara buat Ayam Goreng Kremes&amp;amp;Nasi Jagung Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam Goreng Kremes&amp;amp;Nasi Jagung Sederhana dan Mudah Dibuat"
slug: 303-cara-buat-ayam-goreng-kremes-and-amp-nasi-jagung-sederhana-dan-mudah-dibuat
date: 2021-03-26T22:50:40.064Z
image: https://img-global.cpcdn.com/recipes/c1644f5e7cbe1dde/680x482cq70/ayam-goreng-kremesnasi-jagung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c1644f5e7cbe1dde/680x482cq70/ayam-goreng-kremesnasi-jagung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c1644f5e7cbe1dde/680x482cq70/ayam-goreng-kremesnasi-jagung-foto-resep-utama.jpg
author: Verna Craig
ratingvalue: 4.3
reviewcount: 11
recipeingredient:
- "2 buah paha ayam"
- "2 siung bawang putih parut"
- "1 cm jahe parut"
- "1/4 sdt garam"
- "1 butir telur kocok"
- "secukupnya Minyak goreng"
- " Tepung bumbu"
- "4 sdm tepung beras"
- "1 sdm tepung kanji"
- "secukupnya merica bubuk"
- "1/4 sdt garam"
- "1/4 sdt kaldu bubuk optional"
- " Adonan kremes"
- "3 sdm tepung beras"
- "1 sdm tepung kanji"
- "200 ml air"
- " Bumbu halus"
- "5 siung bawang putih"
- "2 cm kunyit saya skip"
- "1 cm jahe"
- "3 butir kemiri"
- "2 cm lengkuas"
- "2 lembar daun jeruksobeksobek"
- "1 batang serehambil pangkalnyairis tipis"
- "1/2 sdt garam"
- "1/4 sdt kaldu bubuk optional"
- " Bahan Nasi Jagung"
- "1 porsi nasi putih panas"
- "1 sdm jagung rebusserut"
- "1 sdm kecap manis"
recipeinstructions:
- "Cuci bersih ayam dan lumuri dengan air jeruk nipis/lemon. Tusuk-tusuk ayam dengan garpu. Campur dengan bawang putih,jahe,dan garam. Diamkan hingga 20 menit agar bumbu meresap."
- "Buat adonan kremes: campur rata bumbu halus dengan tepung beras, tepung kanji, dan air."
- "Gulingkan paha ayam ke tepung bumbu hingga rata,celup ke telur kocok,gulingkan lagi ke tepung bumbu. Ulangi jika perlu. Simpan dalam lemari es +/- 1 jam."
- "Goreng ayam dalam minyak banyak(deep frying). Caranya,dengan menggoreng dalam panci. Goreng hingga matang kecoklatan. Angkat dan tiriskan."
- "Tuang adonan kremes memakai sendok sayur dengan api besar. Goreng hingga renyah. Angkat. Tiriskan."
- "Nasi Jagung: campur nasi panas dengan jagung serut, tambahkan kecap manis/saos teriyaki jika suka. Aduk rata. Sajikan bersama ayam kremes."
categories:
- Resep
tags:
- ayam
- goreng
- kremesnasi

katakunci: ayam goreng kremesnasi 
nutrition: 209 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Goreng Kremes&amp;Nasi Jagung](https://img-global.cpcdn.com/recipes/c1644f5e7cbe1dde/680x482cq70/ayam-goreng-kremesnasi-jagung-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan santapan sedap buat keluarga merupakan hal yang membahagiakan bagi kita sendiri. Peran seorang  wanita bukan sekadar mengurus rumah saja, tapi kamu juga harus menyediakan keperluan nutrisi terpenuhi dan juga hidangan yang dimakan anak-anak wajib sedap.

Di masa  sekarang, anda memang bisa memesan hidangan praktis walaupun tidak harus susah membuatnya terlebih dahulu. Namun ada juga lho orang yang selalu ingin menyajikan yang terbaik bagi orang yang dicintainya. Sebab, menyajikan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan berdasarkan kesukaan keluarga tercinta. 



Apakah anda adalah seorang penikmat ayam goreng kremes&amp;nasi jagung?. Asal kamu tahu, ayam goreng kremes&amp;nasi jagung adalah sajian khas di Indonesia yang sekarang digemari oleh orang-orang dari hampir setiap wilayah di Indonesia. Kamu dapat menyajikan ayam goreng kremes&amp;nasi jagung sendiri di rumahmu dan pasti jadi santapan kesenanganmu di hari libur.

Kamu tidak perlu bingung untuk menyantap ayam goreng kremes&amp;nasi jagung, lantaran ayam goreng kremes&amp;nasi jagung sangat mudah untuk ditemukan dan kamu pun bisa menghidangkannya sendiri di rumah. ayam goreng kremes&amp;nasi jagung bisa dibuat dengan bermacam cara. Kini pun sudah banyak cara kekinian yang membuat ayam goreng kremes&amp;nasi jagung semakin lezat.

Resep ayam goreng kremes&amp;nasi jagung pun mudah sekali dibikin, lho. Kamu tidak usah repot-repot untuk membeli ayam goreng kremes&amp;nasi jagung, tetapi Kita mampu menghidangkan di rumah sendiri. Untuk Anda yang hendak mencobanya, dibawah ini merupakan resep membuat ayam goreng kremes&amp;nasi jagung yang lezat yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Goreng Kremes&amp;Nasi Jagung:

1. Ambil 2 buah paha ayam
1. Sediakan 2 siung bawang putih parut
1. Ambil 1 cm jahe parut
1. Siapkan 1/4 sdt garam
1. Gunakan 1 butir telur kocok
1. Siapkan secukupnya Minyak goreng
1. Sediakan  Tepung bumbu:
1. Gunakan 4 sdm tepung beras
1. Ambil 1 sdm tepung kanji
1. Sediakan secukupnya merica bubuk
1. Siapkan 1/4 sdt garam
1. Sediakan 1/4 sdt kaldu bubuk (optional)
1. Siapkan  Adonan kremes:
1. Sediakan 3 sdm tepung beras
1. Sediakan 1 sdm tepung kanji
1. Gunakan 200 ml air
1. Ambil  Bumbu halus:
1. Sediakan 5 siung bawang putih
1. Sediakan 2 cm kunyit (saya skip)
1. Siapkan 1 cm jahe
1. Siapkan 3 butir kemiri
1. Ambil 2 cm lengkuas
1. Siapkan 2 lembar daun jeruk,sobek-sobek
1. Siapkan 1 batang sereh,ambil pangkalnya,iris tipis
1. Sediakan 1/2 sdt garam
1. Sediakan 1/4 sdt kaldu bubuk (optional)
1. Siapkan  Bahan Nasi Jagung:
1. Siapkan 1 porsi nasi putih panas
1. Ambil 1 sdm jagung rebus,serut
1. Sediakan 1 sdm kecap manis




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Kremes&amp;Nasi Jagung:

1. Cuci bersih ayam dan lumuri dengan air jeruk nipis/lemon. Tusuk-tusuk ayam dengan garpu. Campur dengan bawang putih,jahe,dan garam. Diamkan hingga 20 menit agar bumbu meresap.
1. Buat adonan kremes: campur rata bumbu halus dengan tepung beras, tepung kanji, dan air.
1. Gulingkan paha ayam ke tepung bumbu hingga rata,celup ke telur kocok,gulingkan lagi ke tepung bumbu. Ulangi jika perlu. Simpan dalam lemari es +/- 1 jam.
1. Goreng ayam dalam minyak banyak(deep frying). Caranya,dengan menggoreng dalam panci. Goreng hingga matang kecoklatan. Angkat dan tiriskan.
1. Tuang adonan kremes memakai sendok sayur dengan api besar. Goreng hingga renyah. Angkat. Tiriskan.
1. Nasi Jagung: campur nasi panas dengan jagung serut, tambahkan kecap manis/saos teriyaki jika suka. Aduk rata. Sajikan bersama ayam kremes.




Ternyata cara membuat ayam goreng kremes&amp;nasi jagung yang enak tidak ribet ini mudah banget ya! Kita semua bisa membuatnya. Cara Membuat ayam goreng kremes&amp;nasi jagung Cocok banget untuk anda yang baru akan belajar memasak atau juga untuk kalian yang telah hebat dalam memasak.

Apakah kamu ingin mencoba membikin resep ayam goreng kremes&amp;nasi jagung lezat simple ini? Kalau kalian mau, mending kamu segera menyiapkan alat dan bahannya, setelah itu bikin deh Resep ayam goreng kremes&amp;nasi jagung yang enak dan simple ini. Benar-benar mudah kan. 

Oleh karena itu, daripada kalian berlama-lama, ayo langsung aja hidangkan resep ayam goreng kremes&amp;nasi jagung ini. Pasti anda tiidak akan menyesal membuat resep ayam goreng kremes&amp;nasi jagung nikmat tidak rumit ini! Selamat berkreasi dengan resep ayam goreng kremes&amp;nasi jagung mantab simple ini di tempat tinggal masing-masing,ya!.

