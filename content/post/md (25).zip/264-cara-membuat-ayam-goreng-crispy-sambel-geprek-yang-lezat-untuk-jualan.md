---
description: "Cara membuat Ayam goreng crispy sambel geprek yang lezat Untuk Jualan"
title: "Cara membuat Ayam goreng crispy sambel geprek yang lezat Untuk Jualan"
slug: 264-cara-membuat-ayam-goreng-crispy-sambel-geprek-yang-lezat-untuk-jualan
date: 2021-03-23T15:54:18.974Z
image: https://img-global.cpcdn.com/recipes/af85ca5bb743225c/680x482cq70/ayam-goreng-crispy-sambel-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/af85ca5bb743225c/680x482cq70/ayam-goreng-crispy-sambel-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/af85ca5bb743225c/680x482cq70/ayam-goreng-crispy-sambel-geprek-foto-resep-utama.jpg
author: Matilda Erickson
ratingvalue: 4
reviewcount: 6
recipeingredient:
- "800 gram ayam"
- " Bumbu marinasi "
- " Jeruk nipis"
- " Bawang merah"
- " Bawang putih"
- " Kemiri"
- " Ketumbar"
- " Garam"
- " Adonan basah "
- " Tepung serba guna"
- " Terigu"
- " Adonan kering "
- "10 sdm tepung terigu"
- "2 sdm tepung maizena"
- "1 sdt baking powder"
- " Air es"
- " Sambel geprek"
- "30 biji Cabe rawit kira kira"
- "4 Cabe merah"
- "4 Cabe hijau"
- "3 Bawang putih"
recipeinstructions:
- "Bersihkan ayam dan beri perasan jeruk nipis"
- "Ulek bumbu marinasi dan campur ke ayam aduk rata diamkan kira kira 15 menit"
- "Lalu masukkan ayam ke adonan basah kemudian adonan kering lalu air es terakhir adonan kering lagi sambil dicubit cubit ayamnya ya😊"
- "Panaskan minyak agak banyak setelah panas,api kompor nya kecilkan ya biar ayamnya matang di dalam dan tidak gosong"
- "Setelah agak coklat angkat dan siap dihidangkan bersama sambel geprek dan tempe crispy"
- "Untuk sambelnya goreng semua bahan lalu ulek tambah garam"
categories:
- Resep
tags:
- ayam
- goreng
- crispy

katakunci: ayam goreng crispy 
nutrition: 192 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam goreng crispy sambel geprek](https://img-global.cpcdn.com/recipes/af85ca5bb743225c/680x482cq70/ayam-goreng-crispy-sambel-geprek-foto-resep-utama.jpg)

Sebagai seorang istri, menyuguhkan olahan sedap kepada orang tercinta merupakan hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang  wanita bukan saja mengerjakan pekerjaan rumah saja, namun kamu juga wajib menyediakan keperluan nutrisi tercukupi dan panganan yang dimakan orang tercinta wajib menggugah selera.

Di masa  saat ini, anda sebenarnya bisa membeli santapan yang sudah jadi meski tidak harus capek memasaknya dulu. Namun banyak juga lho mereka yang memang ingin memberikan yang terenak bagi orang yang dicintainya. Sebab, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera keluarga. 

Ayam geprek krispy sambel mata,perpaduan dari ayam krispy ala KFC dan sambel bawang membuat sensasi yang unik. Tepung yang krispy garing diluar ayam yang. Mukbang tok-poki keju mozzarela super pedas + ayam goreng kriuk super nikmat.

Mungkinkah anda adalah seorang penyuka ayam goreng crispy sambel geprek?. Tahukah kamu, ayam goreng crispy sambel geprek adalah hidangan khas di Nusantara yang sekarang disukai oleh banyak orang di hampir setiap daerah di Nusantara. Kamu bisa memasak ayam goreng crispy sambel geprek kreasi sendiri di rumahmu dan boleh jadi camilan kegemaranmu di akhir pekanmu.

Kalian tidak usah bingung untuk menyantap ayam goreng crispy sambel geprek, sebab ayam goreng crispy sambel geprek mudah untuk ditemukan dan juga kita pun dapat menghidangkannya sendiri di rumah. ayam goreng crispy sambel geprek dapat diolah memalui beragam cara. Sekarang telah banyak banget cara kekinian yang menjadikan ayam goreng crispy sambel geprek semakin lezat.

Resep ayam goreng crispy sambel geprek juga mudah sekali dihidangkan, lho. Anda tidak usah capek-capek untuk memesan ayam goreng crispy sambel geprek, tetapi Kalian mampu membuatnya ditempatmu. Untuk Kalian yang akan menyajikannya, di bawah ini adalah cara membuat ayam goreng crispy sambel geprek yang mantab yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam goreng crispy sambel geprek:

1. Gunakan 800 gram ayam
1. Ambil  Bumbu marinasi :
1. Siapkan  Jeruk nipis
1. Ambil  Bawang merah
1. Sediakan  Bawang putih
1. Siapkan  Kemiri
1. Gunakan  Ketumbar
1. Gunakan  Garam
1. Gunakan  Adonan basah :
1. Ambil  Tepung serba guna
1. Sediakan  Terigu
1. Ambil  Adonan kering :
1. Ambil 10 sdm tepung terigu
1. Sediakan 2 sdm tepung maizena
1. Ambil 1 sdt baking powder
1. Ambil  Air es
1. Siapkan  Sambel geprek:
1. Sediakan 30 biji Cabe rawit kira kira
1. Ambil 4 Cabe merah
1. Ambil 4 Cabe hijau
1. Siapkan 3 Bawang putih


Kamu hanya perlu membumbui ayam, lalu balutkan dengan tepung, goreng dan geprek. Ayam geprek adalah makanan ayam goreng tepung khas Indonesia yang diulek atau dilumatkan bersama sambal bajak. Cubit-cubit ayam dan tepung untuk menghasilkan ayam yang crispy lakukan hingga adonan ayam habis. Panaskan minyak goreng dengan api kecil. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam goreng crispy sambel geprek:

1. Bersihkan ayam dan beri perasan jeruk nipis
1. Ulek bumbu marinasi dan campur ke ayam aduk rata diamkan kira kira 15 menit
1. Lalu masukkan ayam ke adonan basah kemudian adonan kering lalu air es terakhir adonan kering lagi sambil dicubit cubit ayamnya ya😊
1. Panaskan minyak agak banyak setelah panas,api kompor nya kecilkan ya biar ayamnya matang di dalam dan tidak gosong
1. Setelah agak coklat angkat dan siap dihidangkan bersama sambel geprek dan tempe crispy
1. Untuk sambelnya goreng semua bahan lalu ulek tambah garam


Ayam geprek, ayam goreng tepung yang digeprek lalu disajikan pakai sambal bawang. Ayam harus dibaluri adonan tepung beberapa kali sebelum Membuat ayam geprek membutuhkan sedikit usaha untuk pembuatan ayam goreng tepungnya agar renyah. Meski begitu ayam geprek tetap bisa. Ayam goreng crispy: marinate ayam dengan bawang putih halus, garam, merica, kaldu jamur. Balur ayam dengan bahan pelapis sembari dicubit-cubit agar tepung keriting saat digoreng. 

Ternyata cara buat ayam goreng crispy sambel geprek yang nikamt tidak ribet ini enteng banget ya! Kalian semua mampu memasaknya. Cara Membuat ayam goreng crispy sambel geprek Sangat cocok sekali buat anda yang baru belajar memasak ataupun bagi kalian yang sudah ahli dalam memasak.

Tertarik untuk mencoba bikin resep ayam goreng crispy sambel geprek lezat sederhana ini? Kalau ingin, ayo kamu segera menyiapkan peralatan dan bahan-bahannya, setelah itu bikin deh Resep ayam goreng crispy sambel geprek yang nikmat dan tidak rumit ini. Betul-betul mudah kan. 

Oleh karena itu, daripada kita diam saja, ayo kita langsung buat resep ayam goreng crispy sambel geprek ini. Pasti anda gak akan nyesel sudah membuat resep ayam goreng crispy sambel geprek enak sederhana ini! Selamat berkreasi dengan resep ayam goreng crispy sambel geprek lezat tidak ribet ini di rumah kalian sendiri,oke!.

