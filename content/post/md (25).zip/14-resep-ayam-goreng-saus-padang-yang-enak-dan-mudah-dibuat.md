---
description: "Resep Ayam Goreng Saus Padang yang enak dan Mudah Dibuat"
title: "Resep Ayam Goreng Saus Padang yang enak dan Mudah Dibuat"
slug: 14-resep-ayam-goreng-saus-padang-yang-enak-dan-mudah-dibuat
date: 2021-06-01T08:29:33.470Z
image: https://img-global.cpcdn.com/recipes/28ae3563e143a504/680x482cq70/ayam-goreng-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/28ae3563e143a504/680x482cq70/ayam-goreng-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/28ae3563e143a504/680x482cq70/ayam-goreng-saus-padang-foto-resep-utama.jpg
author: Owen Page
ratingvalue: 3.5
reviewcount: 13
recipeingredient:
- "1/2 kg ayam"
- " Bumbu rebus ayam"
- "1 btg sereh geprek"
- "2 lbr daun salam"
- "1/2 sdt garam"
- " Bumbu halus "
- "6 btr bawang merah"
- "5 btr bawang putih"
- "5 btr kemiri"
- "1 buah cabe merah besar"
- "3 buah cabe merah keriting"
- "2 buah tomat"
- "1/2 ruas jahe"
- "1/2 ruas kunyit"
- " Bumbu pelengkap "
- "3 lbr daun salam"
- "3 lbr daun jeruk"
- "2 sdm saus tiram"
- "4 sdm saus sambal"
- "1 sdm gula"
- "1/2 sdt kaldu jamur"
- "1 btr telur kocok lepas"
- "secukupnya Air"
recipeinstructions:
- "Siapkan bahan. Cuci bersih ayam lalu rebus dg bumbu rebusnya sampai setengah matang. Tiriskan lalu goreng"
- "Tumis bumbu halus bersama daun salam, daun jeruk. Tumis hingga harum lalu tambahkan air dan biarkan sampai meletup-letup"
- "Masukkan kocokan telur, penyedap, saos tiram, saos sambal, gula dan garam. Aduk rata kemudian masukkan ayam yang sudah digoreng tadi. Koreksi rasa. Masak hingga kuah mengental dan sajikan. Untuk kuahnya sesuaikan selera ya."
categories:
- Resep
tags:
- ayam
- goreng
- saus

katakunci: ayam goreng saus 
nutrition: 296 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Goreng Saus Padang](https://img-global.cpcdn.com/recipes/28ae3563e143a504/680x482cq70/ayam-goreng-saus-padang-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, mempersiapkan hidangan enak bagi orang tercinta merupakan hal yang membahagiakan bagi anda sendiri. Kewajiban seorang  wanita bukan saja mengatur rumah saja, namun kamu juga harus menyediakan keperluan gizi tercukupi dan juga panganan yang dikonsumsi orang tercinta mesti nikmat.

Di era  saat ini, kita sebenarnya mampu mengorder olahan yang sudah jadi walaupun tanpa harus repot mengolahnya dahulu. Namun banyak juga mereka yang memang mau memberikan makanan yang terenak untuk keluarganya. Sebab, memasak yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut berdasarkan selera orang tercinta. 



Apakah anda adalah salah satu penggemar ayam goreng saus padang?. Tahukah kamu, ayam goreng saus padang merupakan sajian khas di Indonesia yang sekarang disukai oleh setiap orang dari berbagai wilayah di Nusantara. Anda bisa memasak ayam goreng saus padang sendiri di rumah dan pasti jadi hidangan kegemaranmu di akhir pekanmu.

Kamu tidak usah bingung jika kamu ingin menyantap ayam goreng saus padang, lantaran ayam goreng saus padang gampang untuk dicari dan anda pun boleh memasaknya sendiri di rumah. ayam goreng saus padang boleh dimasak memalui bermacam cara. Kini pun sudah banyak resep kekinian yang membuat ayam goreng saus padang semakin mantap.

Resep ayam goreng saus padang juga gampang untuk dibikin, lho. Kalian tidak usah ribet-ribet untuk membeli ayam goreng saus padang, sebab Kamu bisa membuatnya ditempatmu. Untuk Kalian yang mau membuatnya, di bawah ini adalah cara untuk menyajikan ayam goreng saus padang yang nikamat yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Goreng Saus Padang:

1. Ambil 1/2 kg ayam
1. Gunakan  Bumbu rebus ayam:
1. Sediakan 1 btg sereh geprek
1. Gunakan 2 lbr daun salam
1. Ambil 1/2 sdt garam
1. Siapkan  Bumbu halus :
1. Siapkan 6 btr bawang merah
1. Sediakan 5 btr bawang putih
1. Gunakan 5 btr kemiri
1. Gunakan 1 buah cabe merah besar
1. Sediakan 3 buah cabe merah keriting
1. Ambil 2 buah tomat
1. Sediakan 1/2 ruas jahe
1. Siapkan 1/2 ruas kunyit
1. Siapkan  Bumbu pelengkap :
1. Ambil 3 lbr daun salam
1. Ambil 3 lbr daun jeruk
1. Sediakan 2 sdm saus tiram
1. Sediakan 4 sdm saus sambal
1. Ambil 1 sdm gula
1. Sediakan 1/2 sdt kaldu jamur
1. Sediakan 1 btr telur, kocok lepas
1. Ambil secukupnya Air




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Saus Padang:

1. Siapkan bahan. Cuci bersih ayam lalu rebus dg bumbu rebusnya sampai setengah matang. Tiriskan lalu goreng
1. Tumis bumbu halus bersama daun salam, daun jeruk. Tumis hingga harum lalu tambahkan air dan biarkan sampai meletup-letup
1. Masukkan kocokan telur, penyedap, saos tiram, saos sambal, gula dan garam. Aduk rata kemudian masukkan ayam yang sudah digoreng tadi. Koreksi rasa. Masak hingga kuah mengental dan sajikan. Untuk kuahnya sesuaikan selera ya.




Ternyata cara membuat ayam goreng saus padang yang enak tidak rumit ini gampang banget ya! Kalian semua bisa membuatnya. Cara buat ayam goreng saus padang Sangat sesuai banget buat kita yang sedang belajar memasak maupun bagi kamu yang sudah jago dalam memasak.

Tertarik untuk mencoba membuat resep ayam goreng saus padang nikmat sederhana ini? Kalau kalian mau, ayo kamu segera menyiapkan alat dan bahan-bahannya, maka buat deh Resep ayam goreng saus padang yang mantab dan tidak rumit ini. Sangat taidak sulit kan. 

Maka, daripada kamu diam saja, hayo langsung aja sajikan resep ayam goreng saus padang ini. Pasti anda tiidak akan menyesal membuat resep ayam goreng saus padang enak simple ini! Selamat mencoba dengan resep ayam goreng saus padang lezat simple ini di rumah kalian masing-masing,oke!.

