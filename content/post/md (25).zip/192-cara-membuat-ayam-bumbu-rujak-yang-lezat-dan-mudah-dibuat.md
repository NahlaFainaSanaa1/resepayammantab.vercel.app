---
description: "Cara membuat Ayam Bumbu Rujak yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Bumbu Rujak yang lezat dan Mudah Dibuat"
slug: 192-cara-membuat-ayam-bumbu-rujak-yang-lezat-dan-mudah-dibuat
date: 2021-06-03T11:05:16.730Z
image: https://img-global.cpcdn.com/recipes/c1786aaa5345dc5f/680x482cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c1786aaa5345dc5f/680x482cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c1786aaa5345dc5f/680x482cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
author: Noah Craig
ratingvalue: 4.9
reviewcount: 12
recipeingredient:
- "1 ekor ayam"
- "2 bungkus Kara 65 ml larutkan dengan sedikit air"
- "1000 ml air"
- "1 buah tomat potong kecilkecil"
- " Cabe rawit utuh"
- "2 batang sereh geprek"
- "4 lembar daun salam"
- "6 lembar daun jeruk"
- "1 jempol laos"
- "1 1/2 sdt garam"
- "2 1/2 sdm gula"
- " Bumbu halus "
- "8 siung bawang putih"
- "10 siung bawang merah"
- "2 buah cabe merah besar"
- "2 buah cabe keriting"
- "5 buah cabe rawit"
- "3 biji kemiri"
- "1/2 jempol jahe"
- "1 sdt kunyit bubuk"
- "1/2 sdt garam"
recipeinstructions:
- "Tumis bumbu halus hingga tanek kemudian masukkan aneka rempah daun-daun, tumis sampai harum"
- "Masukkan air, biarkan mendidih. Masukkan santan, aduk-aduk agar tidak pecah kemudian masukkan irisan tomat &amp; cabe rawit utuhan"
- "Bumbui dengan garam &amp; gula kemudian tes rasa"
- "Masukkan ayam. Masak hingga ayam empuk &amp; kuah mengental"
- "Ayam bumbu rujak siap dihidangkan"
categories:
- Resep
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Bumbu Rujak](https://img-global.cpcdn.com/recipes/c1786aaa5345dc5f/680x482cq70/ayam-bumbu-rujak-foto-resep-utama.jpg)

Andai anda seorang ibu, menyuguhkan masakan lezat untuk famili adalah suatu hal yang membahagiakan untuk anda sendiri. Kewajiban seorang  wanita bukan cuman mengatur rumah saja, tapi kamu pun wajib menyediakan kebutuhan gizi terpenuhi dan masakan yang dikonsumsi keluarga tercinta harus mantab.

Di waktu  sekarang, kamu memang bisa mengorder santapan siap saji walaupun tanpa harus capek membuatnya terlebih dahulu. Tetapi banyak juga orang yang selalu mau memberikan hidangan yang terenak bagi keluarganya. Sebab, menghidangkan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan famili. 



Apakah anda adalah seorang penikmat ayam bumbu rujak?. Asal kamu tahu, ayam bumbu rujak adalah hidangan khas di Nusantara yang saat ini disenangi oleh orang-orang di berbagai tempat di Nusantara. Anda bisa membuat ayam bumbu rujak olahan sendiri di rumah dan pasti jadi camilan kesukaanmu di akhir pekan.

Kita tidak perlu bingung untuk menyantap ayam bumbu rujak, lantaran ayam bumbu rujak mudah untuk ditemukan dan juga anda pun dapat membuatnya sendiri di tempatmu. ayam bumbu rujak dapat dimasak memalui beragam cara. Kini pun sudah banyak sekali resep modern yang membuat ayam bumbu rujak lebih nikmat.

Resep ayam bumbu rujak pun gampang dihidangkan, lho. Kamu jangan ribet-ribet untuk memesan ayam bumbu rujak, karena Kalian mampu menyajikan di rumahmu. Untuk Kalian yang akan menghidangkannya, di bawah ini adalah cara menyajikan ayam bumbu rujak yang mantab yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Bumbu Rujak:

1. Sediakan 1 ekor ayam
1. Gunakan 2 bungkus Kara @65 ml, larutkan dengan sedikit air
1. Sediakan 1000 ml air
1. Ambil 1 buah tomat, potong kecil-kecil
1. Ambil  Cabe rawit utuh
1. Gunakan 2 batang sereh, geprek
1. Sediakan 4 lembar daun salam
1. Siapkan 6 lembar daun jeruk
1. Gunakan 1 jempol laos
1. Ambil 1 1/2 sdt garam
1. Ambil 2 1/2 sdm gula
1. Ambil  Bumbu halus :
1. Ambil 8 siung bawang putih
1. Sediakan 10 siung bawang merah
1. Sediakan 2 buah cabe merah besar
1. Ambil 2 buah cabe keriting
1. Ambil 5 buah cabe rawit
1. Siapkan 3 biji kemiri
1. Gunakan 1/2 jempol jahe
1. Ambil 1 sdt kunyit bubuk
1. Siapkan 1/2 sdt garam




<!--inarticleads2-->

##### Cara membuat Ayam Bumbu Rujak:

1. Tumis bumbu halus hingga tanek kemudian masukkan aneka rempah daun-daun, tumis sampai harum
1. Masukkan air, biarkan mendidih. Masukkan santan, aduk-aduk agar tidak pecah kemudian masukkan irisan tomat &amp; cabe rawit utuhan
1. Bumbui dengan garam &amp; gula kemudian tes rasa
1. Masukkan ayam. Masak hingga ayam empuk &amp; kuah mengental
1. Ayam bumbu rujak siap dihidangkan




Wah ternyata cara membuat ayam bumbu rujak yang mantab simple ini mudah banget ya! Kalian semua mampu memasaknya. Resep ayam bumbu rujak Cocok banget untuk anda yang baru akan belajar memasak maupun juga bagi kamu yang sudah hebat dalam memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam bumbu rujak lezat tidak ribet ini? Kalau anda tertarik, ayo kamu segera menyiapkan alat-alat dan bahannya, lalu buat deh Resep ayam bumbu rujak yang mantab dan tidak rumit ini. Sungguh taidak sulit kan. 

Jadi, ketimbang kalian berlama-lama, ayo langsung aja bikin resep ayam bumbu rujak ini. Pasti kamu tak akan menyesal bikin resep ayam bumbu rujak mantab tidak ribet ini! Selamat berkreasi dengan resep ayam bumbu rujak nikmat simple ini di rumah kalian sendiri,ya!.

