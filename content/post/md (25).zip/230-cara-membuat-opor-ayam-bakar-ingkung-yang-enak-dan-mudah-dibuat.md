---
description: "Cara membuat Opor ayam bakar ingkung yang enak dan Mudah Dibuat"
title: "Cara membuat Opor ayam bakar ingkung yang enak dan Mudah Dibuat"
slug: 230-cara-membuat-opor-ayam-bakar-ingkung-yang-enak-dan-mudah-dibuat
date: 2021-05-20T10:41:15.940Z
image: https://img-global.cpcdn.com/recipes/78156f33ac43c27c/680x482cq70/opor-ayam-bakar-ingkung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/78156f33ac43c27c/680x482cq70/opor-ayam-bakar-ingkung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/78156f33ac43c27c/680x482cq70/opor-ayam-bakar-ingkung-foto-resep-utama.jpg
author: Chad Morton
ratingvalue: 4.4
reviewcount: 5
recipeingredient:
- "1 ekor ayam"
- "2 batang sere geprek"
- "3 lembar daun jeruk"
- "3 lembar daun salam"
- "2 potong lengkuas geprek"
- "200 ml santan instan"
- "1300 ml air untuk merebus"
- " Bumbu halus "
- "6 siung bawang merah"
- "8 siung bawang putih"
- "4 butir kemiri"
- "1 sdm ketumbar"
- "1 sdt merica"
- "2 potong jahe"
- "1 potong kunir"
- "1 sdt jintan bubuk"
- "1 potong kepala kepolo"
- "1 sdm garam"
- "2 gempil gula merah"
- "1 sdt ajinomoto"
recipeinstructions:
- "Siapkan semua bumbu cuci ayam belah dadanya, peraskan air lemon sambil remas remas tunggu 3 menit bilas air."
- "Ulek semua bumbu geprek sere dan lengkuas."
- "Masukan setengah bumbu ulek ke dalam perut ayam lalu jait bagian bawah pake lidi dan oles bumbu seluruh ayam dan ikat pake tali biar bumbu meresap ke daging ayam dan tidah ambyar waktu direbus."
- "Didihkan santan masukan salam, sere, lengkuas dan bumbu ulek lalu masukan ayam rebus 45 menit atau sampe matang."
- "Rebus sampe mateng lalu angkat ayamnya dan santanya rebus lagi pake api kecil biar kan sampe santan mengental ayam bisa di masukan rebus lagi biar lebih matang."
- "Setelah matang rebus ayam biarkan dingin dulu lalu di bakar, bisa bakar pake teflon, bisa di bakar oven."
- "Opor ayam bakar sudah mateng aroma sedap, lalu siram pake santan kental dan di hidangkan tabur bawang merah goreng pelengkap cabe hijau. Selamat mencoba 😋😋"
categories:
- Resep
tags:
- opor
- ayam
- bakar

katakunci: opor ayam bakar 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dessert

---


![Opor ayam bakar ingkung](https://img-global.cpcdn.com/recipes/78156f33ac43c27c/680x482cq70/opor-ayam-bakar-ingkung-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, mempersiapkan olahan sedap bagi orang tercinta adalah suatu hal yang mengasyikan untuk kamu sendiri. Peran seorang  wanita Tidak saja menjaga rumah saja, namun kamu pun wajib memastikan keperluan nutrisi terpenuhi dan juga olahan yang dimakan keluarga tercinta mesti enak.

Di waktu  sekarang, kamu memang mampu mengorder santapan jadi walaupun tanpa harus susah memasaknya dahulu. Namun banyak juga orang yang memang mau memberikan hidangan yang terbaik untuk orang tercintanya. Sebab, memasak sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Apakah anda salah satu penikmat opor ayam bakar ingkung?. Asal kamu tahu, opor ayam bakar ingkung adalah makanan khas di Nusantara yang saat ini disenangi oleh banyak orang dari hampir setiap daerah di Indonesia. Kamu bisa menghidangkan opor ayam bakar ingkung sendiri di rumah dan dapat dijadikan santapan favoritmu di akhir pekanmu.

Kita tidak usah bingung untuk mendapatkan opor ayam bakar ingkung, karena opor ayam bakar ingkung mudah untuk ditemukan dan juga kalian pun boleh menghidangkannya sendiri di tempatmu. opor ayam bakar ingkung dapat dibuat lewat beragam cara. Saat ini sudah banyak cara modern yang menjadikan opor ayam bakar ingkung semakin lebih enak.

Resep opor ayam bakar ingkung pun sangat mudah dibikin, lho. Kamu tidak usah capek-capek untuk memesan opor ayam bakar ingkung, tetapi Anda mampu menghidangkan di rumahmu. Bagi Kamu yang mau membuatnya, berikut cara membuat opor ayam bakar ingkung yang nikamat yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Opor ayam bakar ingkung:

1. Ambil 1 ekor ayam
1. Ambil 2 batang sere geprek
1. Ambil 3 lembar daun jeruk
1. Sediakan 3 lembar daun salam
1. Siapkan 2 potong lengkuas geprek
1. Sediakan 200 ml santan instan
1. Siapkan 1300 ml air untuk merebus
1. Sediakan  Bumbu halus :
1. Ambil 6 siung bawang merah
1. Sediakan 8 siung bawang putih
1. Gunakan 4 butir kemiri
1. Ambil 1 sdm ketumbar
1. Gunakan 1 sdt merica
1. Ambil 2 potong jahe
1. Siapkan 1 potong kunir
1. Sediakan 1 sdt jintan bubuk
1. Siapkan 1 potong kepala (kepolo)
1. Sediakan 1 sdm garam
1. Sediakan 2 gempil gula merah
1. Siapkan 1 sdt ajinomoto




<!--inarticleads2-->

##### Cara menyiapkan Opor ayam bakar ingkung:

1. Siapkan semua bumbu cuci ayam belah dadanya, peraskan air lemon sambil remas remas tunggu 3 menit bilas air.
1. Ulek semua bumbu geprek sere dan lengkuas.
1. Masukan setengah bumbu ulek ke dalam perut ayam lalu jait bagian bawah pake lidi dan oles bumbu seluruh ayam dan ikat pake tali biar bumbu meresap ke daging ayam dan tidah ambyar waktu direbus.
1. Didihkan santan masukan salam, sere, lengkuas dan bumbu ulek lalu masukan ayam rebus 45 menit atau sampe matang.
1. Rebus sampe mateng lalu angkat ayamnya dan santanya rebus lagi pake api kecil biar kan sampe santan mengental ayam bisa di masukan rebus lagi biar lebih matang.
1. Setelah matang rebus ayam biarkan dingin dulu lalu di bakar, bisa bakar pake teflon, bisa di bakar oven.
1. Opor ayam bakar sudah mateng aroma sedap, lalu siram pake santan kental dan di hidangkan tabur bawang merah goreng pelengkap cabe hijau. Selamat mencoba 😋😋




Wah ternyata cara buat opor ayam bakar ingkung yang lezat simple ini gampang banget ya! Kalian semua dapat menghidangkannya. Cara buat opor ayam bakar ingkung Sesuai sekali untuk anda yang baru akan belajar memasak atau juga bagi kalian yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba buat resep opor ayam bakar ingkung lezat sederhana ini? Kalau anda mau, mending kamu segera buruan siapin alat dan bahannya, maka bikin deh Resep opor ayam bakar ingkung yang nikmat dan sederhana ini. Sangat mudah kan. 

Maka, daripada kita berfikir lama-lama, yuk kita langsung saja buat resep opor ayam bakar ingkung ini. Pasti anda tiidak akan menyesal membuat resep opor ayam bakar ingkung nikmat tidak rumit ini! Selamat berkreasi dengan resep opor ayam bakar ingkung mantab sederhana ini di rumah sendiri,ya!.

