---
description: "Resep Nasi Daun Jeruk &amp;amp; Ayam Goreng Krispi + Sambal Korek Sederhana dan Mudah Dibuat"
title: "Resep Nasi Daun Jeruk &amp;amp; Ayam Goreng Krispi + Sambal Korek Sederhana dan Mudah Dibuat"
slug: 257-resep-nasi-daun-jeruk-and-amp-ayam-goreng-krispi-sambal-korek-sederhana-dan-mudah-dibuat
date: 2021-05-28T11:21:37.680Z
image: https://img-global.cpcdn.com/recipes/194cafe81f2c0164/680x482cq70/nasi-daun-jeruk-ayam-goreng-krispi-sambal-korek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/194cafe81f2c0164/680x482cq70/nasi-daun-jeruk-ayam-goreng-krispi-sambal-korek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/194cafe81f2c0164/680x482cq70/nasi-daun-jeruk-ayam-goreng-krispi-sambal-korek-foto-resep-utama.jpg
author: Jerry Johnston
ratingvalue: 3.7
reviewcount: 5
recipeingredient:
- " Nasi Daun Jeruk"
- "2 porsi Nasi putih"
- "Secukupnya Bawang putih"
- "Secukupnya daun jeruk"
- "Secukupnya minyak untuk menumis"
- "1 sdt margarin"
- " Ayam Goreng Krispi"
- "1/2 kg Paha ayam fillet"
- " Tepung bumbu serbaguna"
- "1 bowl air untuk dipping"
- "Secukupnya garam lada kecap ikan kecap inggris bawang putih bubuk cabe bubuk untuk marinasi"
- " Sambal Korek"
- "9 buah cabe rawit"
- "4-5 butir bawang merah"
- "1 butir bawang putih"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya penyedap"
recipeinstructions:
- "Panaskan minyak, haluskan bahan untuk sambal, setelah itu tuang minyak panas secukupnya"
- "Marinasi ayam dengan bahan tersebut diatas selama kurang lbh 30 menit, lumuri dengan tepung bumbu, celupkan ke dalam air sebentar menggunakan saringan, kemudian lumuri kembali dengan tepung, goreng sampai golden brown."
- "Panaskan minyak untuk menumis bawang putih cincang, dan daun jeruk yang telah diiris tipis sampai harum, tambahkan margarin, aduk-aduk hingga tercampur rata, matikan kompor, kemudian masukkan nasi putih, aduk hingga tercampur rata."
- "Siapkan bowl, tambahkan nasi daun jeruk, susun rapi ayam goreng, kemudian tambahkan sambal korek diatasnya."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 208 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dinner

---


![Nasi Daun Jeruk &amp; Ayam Goreng Krispi + Sambal Korek](https://img-global.cpcdn.com/recipes/194cafe81f2c0164/680x482cq70/nasi-daun-jeruk-ayam-goreng-krispi-sambal-korek-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan olahan mantab bagi famili adalah suatu hal yang memuaskan bagi anda sendiri. Tugas seorang ibu bukan hanya menjaga rumah saja, namun anda pun wajib menyediakan kebutuhan gizi tercukupi dan panganan yang disantap orang tercinta mesti lezat.

Di zaman  saat ini, kita sebenarnya mampu mengorder masakan jadi meski tidak harus ribet membuatnya dulu. Namun ada juga orang yang selalu mau memberikan makanan yang terenak bagi keluarganya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai makanan kesukaan famili. 



Mungkinkah anda seorang penggemar nasi daun jeruk &amp; ayam goreng krispi + sambal korek?. Asal kamu tahu, nasi daun jeruk &amp; ayam goreng krispi + sambal korek merupakan makanan khas di Indonesia yang saat ini disenangi oleh kebanyakan orang dari berbagai daerah di Nusantara. Anda bisa memasak nasi daun jeruk &amp; ayam goreng krispi + sambal korek buatan sendiri di rumahmu dan pasti jadi camilan favoritmu di hari libur.

Kamu tak perlu bingung jika kamu ingin mendapatkan nasi daun jeruk &amp; ayam goreng krispi + sambal korek, karena nasi daun jeruk &amp; ayam goreng krispi + sambal korek mudah untuk dicari dan anda pun dapat membuatnya sendiri di tempatmu. nasi daun jeruk &amp; ayam goreng krispi + sambal korek boleh diolah memalui beragam cara. Sekarang telah banyak sekali cara modern yang menjadikan nasi daun jeruk &amp; ayam goreng krispi + sambal korek lebih enak.

Resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek juga sangat gampang dibuat, lho. Anda jangan capek-capek untuk memesan nasi daun jeruk &amp; ayam goreng krispi + sambal korek, tetapi Kita dapat membuatnya sendiri di rumah. Bagi Kalian yang akan menyajikannya, berikut resep menyajikan nasi daun jeruk &amp; ayam goreng krispi + sambal korek yang mantab yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Nasi Daun Jeruk &amp; Ayam Goreng Krispi + Sambal Korek:

1. Gunakan  Nasi Daun Jeruk
1. Gunakan 2 porsi Nasi putih
1. Sediakan Secukupnya Bawang putih
1. Sediakan Secukupnya daun jeruk
1. Siapkan Secukupnya minyak untuk menumis
1. Siapkan 1 sdt margarin
1. Ambil  Ayam Goreng Krispi
1. Gunakan 1/2 kg Paha ayam fillet
1. Ambil  Tepung bumbu serbaguna
1. Gunakan 1 bowl air untuk dipping
1. Siapkan Secukupnya garam, lada, kecap ikan, kecap inggris, bawang putih bubuk, cabe bubuk untuk marinasi
1. Gunakan  Sambal Korek
1. Sediakan 9 buah cabe rawit
1. Siapkan 4-5 butir bawang merah
1. Gunakan 1 butir bawang putih
1. Sediakan Secukupnya garam
1. Siapkan Secukupnya gula
1. Sediakan Secukupnya penyedap




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Nasi Daun Jeruk &amp; Ayam Goreng Krispi + Sambal Korek:

1. Panaskan minyak, haluskan bahan untuk sambal, setelah itu tuang minyak panas secukupnya
1. Marinasi ayam dengan bahan tersebut diatas selama kurang lbh 30 menit, lumuri dengan tepung bumbu, celupkan ke dalam air sebentar menggunakan saringan, kemudian lumuri kembali dengan tepung, goreng sampai golden brown.
1. Panaskan minyak untuk menumis bawang putih cincang, dan daun jeruk yang telah diiris tipis sampai harum, tambahkan margarin, aduk-aduk hingga tercampur rata, matikan kompor, kemudian masukkan nasi putih, aduk hingga tercampur rata.
1. Siapkan bowl, tambahkan nasi daun jeruk, susun rapi ayam goreng, kemudian tambahkan sambal korek diatasnya.




Wah ternyata cara buat nasi daun jeruk &amp; ayam goreng krispi + sambal korek yang nikamt tidak rumit ini enteng banget ya! Kamu semua dapat memasaknya. Cara buat nasi daun jeruk &amp; ayam goreng krispi + sambal korek Sangat sesuai sekali buat anda yang baru belajar memasak ataupun untuk kalian yang sudah hebat dalam memasak.

Tertarik untuk mencoba buat resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek enak tidak rumit ini? Kalau anda ingin, ayo kalian segera buruan menyiapkan peralatan dan bahan-bahannya, setelah itu bikin deh Resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek yang enak dan tidak rumit ini. Benar-benar mudah kan. 

Maka, ketimbang kamu diam saja, yuk langsung aja hidangkan resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek ini. Pasti anda tak akan nyesel bikin resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek mantab tidak rumit ini! Selamat berkreasi dengan resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek nikmat simple ini di rumah kalian sendiri,oke!.

