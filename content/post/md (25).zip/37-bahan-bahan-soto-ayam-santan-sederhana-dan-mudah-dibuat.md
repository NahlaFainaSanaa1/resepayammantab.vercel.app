---
description: "Bahan-bahan Soto ayam Santan Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Soto ayam Santan Sederhana dan Mudah Dibuat"
slug: 37-bahan-bahan-soto-ayam-santan-sederhana-dan-mudah-dibuat
date: 2021-02-09T12:43:49.562Z
image: https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Adrian Sandoval
ratingvalue: 3.7
reviewcount: 9
recipeingredient:
- "2 potong ayam"
- "500 ml air"
- "50 gr tauge siangi"
- "1/2 buah kol iris"
- "1 batang daun bawang iris"
- "4 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "500 ml santan"
- "1 buah telur rebus potong 4bagian"
- "2 sdm bawang goreng"
- "1 buah kentang ukuran besarsedang goreng"
- " Bumbu halus "
- "5 siung bawang merah"
- "4 siung bawang putih"
- "2 buah kemiri"
- "2 cm jahe"
- "2 cm kunyit"
- "Secukupnya lada dan merica bubuk"
- "Secukupnya gula"
- "Secukupnya garam"
- "Secukupnya minyak goreng"
recipeinstructions:
- "Siapkan panci dan didihkan air bersama ayam atau tulang ayam untuk membuat kuah kaldu. Tunggu ayam hingga empuk dan kaldu mendidih. Sementara menunggu ayam matang, haluskan bumbu halus kemudian tumis hingga harum dan matang."
- "Angkat ayam dari dalam rebusan jika sudah matang, lalu sisihkan. Kemudian, masukkan bumbu yang sudah di tumis kedalam kaldu aduk-aduk hingga tercampur rata. Masukkan juga gula, garam, lada, serai, daun salam, daun jeruk, dan daun bawang."
- "Aduk lagi hingga tercampur rata, dan terakhir masukkan santan dan aduk-aduk agar santan tidak pecah selama di masak. Kemudian cek rasa. Jika di rasa sudah pas, sisihkan dahulu."
- "Goreng ayam(suwir2) dan kentang bergantian hingga benar-benar matang dan kecoklatan. Terakhir, sajikan soto bersama tauge, kol, kentang goreng, lalu tuangkan kuah soto dan tambahkan telur rebus serta bawang goreng."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto ayam Santan](https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Selaku seorang ibu, menyajikan masakan enak buat keluarga merupakan suatu hal yang mengasyikan untuk kamu sendiri. Peran seorang istri Tidak hanya mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib memastikan kebutuhan gizi tercukupi dan santapan yang dikonsumsi orang tercinta harus sedap.

Di zaman  sekarang, anda sebenarnya bisa membeli masakan instan tanpa harus ribet memasaknya dahulu. Tetapi ada juga mereka yang memang mau memberikan hidangan yang terbaik bagi orang yang dicintainya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan selera famili. 



Mungkinkah kamu salah satu penikmat soto ayam santan?. Asal kamu tahu, soto ayam santan adalah makanan khas di Indonesia yang kini disenangi oleh kebanyakan orang dari berbagai wilayah di Nusantara. Anda dapat memasak soto ayam santan kreasi sendiri di rumahmu dan pasti jadi makanan favorit di akhir pekan.

Kita tidak perlu bingung jika kamu ingin mendapatkan soto ayam santan, lantaran soto ayam santan sangat mudah untuk didapatkan dan kita pun bisa membuatnya sendiri di tempatmu. soto ayam santan bisa dibuat dengan beragam cara. Sekarang telah banyak resep kekinian yang menjadikan soto ayam santan semakin lebih lezat.

Resep soto ayam santan juga sangat mudah dibikin, lho. Anda tidak perlu repot-repot untuk membeli soto ayam santan, sebab Kalian mampu membuatnya di rumahmu. Untuk Kalian yang ingin menyajikannya, di bawah ini adalah cara untuk menyajikan soto ayam santan yang nikamat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Soto ayam Santan:

1. Sediakan 2 potong ayam
1. Siapkan 500 ml air
1. Sediakan 50 gr tauge, siangi
1. Ambil 1/2 buah kol, iris
1. Siapkan 1 batang daun bawang, iris
1. Gunakan 4 lembar daun salam
1. Ambil 3 lembar daun jeruk
1. Ambil 1 batang serai, geprek
1. Ambil 500 ml santan
1. Siapkan 1 buah telur rebus, potong 4bagian
1. Sediakan 2 sdm bawang goreng
1. Sediakan 1 buah kentang ukuran besar/sedang, goreng
1. Siapkan  Bumbu halus :
1. Sediakan 5 siung bawang merah
1. Gunakan 4 siung bawang putih
1. Sediakan 2 buah kemiri
1. Ambil 2 cm jahe
1. Sediakan 2 cm kunyit
1. Siapkan Secukupnya lada dan merica bubuk
1. Siapkan Secukupnya gula
1. Ambil Secukupnya garam
1. Gunakan Secukupnya minyak goreng




<!--inarticleads2-->

##### Cara menyiapkan Soto ayam Santan:

1. Siapkan panci dan didihkan air bersama ayam atau tulang ayam untuk membuat kuah kaldu. Tunggu ayam hingga empuk dan kaldu mendidih. Sementara menunggu ayam matang, haluskan bumbu halus kemudian tumis hingga harum dan matang.
1. Angkat ayam dari dalam rebusan jika sudah matang, lalu sisihkan. Kemudian, masukkan bumbu yang sudah di tumis kedalam kaldu aduk-aduk hingga tercampur rata. Masukkan juga gula, garam, lada, serai, daun salam, daun jeruk, dan daun bawang.
1. Aduk lagi hingga tercampur rata, dan terakhir masukkan santan dan aduk-aduk agar santan tidak pecah selama di masak. Kemudian cek rasa. Jika di rasa sudah pas, sisihkan dahulu.
1. Goreng ayam(suwir2) dan kentang bergantian hingga benar-benar matang dan kecoklatan. Terakhir, sajikan soto bersama tauge, kol, kentang goreng, lalu tuangkan kuah soto dan tambahkan telur rebus serta bawang goreng.




Wah ternyata cara buat soto ayam santan yang mantab sederhana ini gampang banget ya! Kamu semua dapat memasaknya. Resep soto ayam santan Sangat cocok banget untuk anda yang baru akan belajar memasak maupun juga untuk kalian yang telah jago dalam memasak.

Apakah kamu ingin mencoba membikin resep soto ayam santan enak tidak ribet ini? Kalau anda ingin, ayo kalian segera siapin alat dan bahan-bahannya, kemudian buat deh Resep soto ayam santan yang nikmat dan simple ini. Sangat mudah kan. 

Maka, daripada kamu diam saja, yuk langsung aja bikin resep soto ayam santan ini. Dijamin kalian gak akan nyesel membuat resep soto ayam santan enak simple ini! Selamat mencoba dengan resep soto ayam santan lezat sederhana ini di rumah sendiri,oke!.

