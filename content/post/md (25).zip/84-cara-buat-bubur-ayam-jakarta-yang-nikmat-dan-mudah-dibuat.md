---
description: "Cara buat Bubur Ayam Jakarta yang nikmat dan Mudah Dibuat"
title: "Cara buat Bubur Ayam Jakarta yang nikmat dan Mudah Dibuat"
slug: 84-cara-buat-bubur-ayam-jakarta-yang-nikmat-dan-mudah-dibuat
date: 2021-04-28T15:17:59.527Z
image: https://img-global.cpcdn.com/recipes/da849bd661b1fe95/680x482cq70/bubur-ayam-jakarta-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/da849bd661b1fe95/680x482cq70/bubur-ayam-jakarta-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/da849bd661b1fe95/680x482cq70/bubur-ayam-jakarta-foto-resep-utama.jpg
author: Lydia Newton
ratingvalue: 4.4
reviewcount: 5
recipeingredient:
- "2,5 centong nasi"
- "1,5 liter air kaldu"
- "5 siung bawang putih geprek sampai hancur"
- "1,5 sdm santan kara"
- "2 sdm kecap asin"
- "2 sdm kecap ikan"
- "Secukupnya garam lada"
- " Bumbu halus"
- "4 siung bawang merah"
- "3 siung bawang putih"
- " Kuah kuning"
- "1 ruas jahelengkuas geprek"
- "1 bh sere geprek"
- "2 bh daun salam dan daun jeruk"
- "1 sdt kunyit bubuk"
- "1 sdt ketumbar bubuk"
- "3 buah kemiri"
- " ToppingPelengkap"
- " Ayam goreng suwir"
- " Ikan teri skip"
- " kacang goreng"
- " Daun bawang"
- " Bawang goreng           lihat resep"
- " Kerupukemping"
- " Kecap manis dan cabe"
- " Telur rebus tambahan saya"
recipeinstructions:
- "Masak air kaldu dan bawang putih sampai mendidih bagi pisahkan 500 ml untuk kuah kuning sisa nya dipake masak bubur."
- "Masukan nasi masak sampai menjadi bubur. Jika sudah menjadi bubur masukan santan, kecap, lada dan garam aduk rata masak hingga bubur meletup letup. Sisihkan."
- "Kuah kuning : tumis bumbu halus, jahe, lengkuas daun salam daun jeruk dan sereh lalu rebus dengan air kaldu tadi yg disisihkan 500 ml masak hingga mendidih, masukan kaldu ayam dan garam secukupnya icip rasa lalu masukan larutan maizena (saya:skip maizenanya) aduk cepat jika memakai maizena, masak lagi hingga agak mengental jika sudah mengental siap di sajikan"
categories:
- Resep
tags:
- bubur
- ayam
- jakarta

katakunci: bubur ayam jakarta 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Bubur Ayam Jakarta](https://img-global.cpcdn.com/recipes/da849bd661b1fe95/680x482cq70/bubur-ayam-jakarta-foto-resep-utama.jpg)

Apabila anda seorang ibu, menyuguhkan hidangan enak kepada orang tercinta adalah suatu hal yang memuaskan untuk anda sendiri. Kewajiban seorang ibu bukan saja mengatur rumah saja, namun kamu juga harus menyediakan keperluan gizi terpenuhi dan juga masakan yang dikonsumsi orang tercinta mesti mantab.

Di waktu  saat ini, anda sebenarnya mampu membeli masakan jadi meski tanpa harus ribet memasaknya dulu. Namun ada juga mereka yang selalu ingin memberikan makanan yang terlezat untuk keluarganya. Sebab, memasak yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut berdasarkan kesukaan famili. 



Apakah kamu seorang penikmat bubur ayam jakarta?. Asal kamu tahu, bubur ayam jakarta merupakan makanan khas di Nusantara yang sekarang digemari oleh kebanyakan orang di hampir setiap daerah di Indonesia. Anda dapat menghidangkan bubur ayam jakarta sendiri di rumahmu dan boleh jadi makanan favoritmu di akhir pekan.

Kalian tidak perlu bingung jika kamu ingin memakan bubur ayam jakarta, sebab bubur ayam jakarta tidak sulit untuk didapatkan dan juga kamu pun boleh menghidangkannya sendiri di tempatmu. bubur ayam jakarta dapat diolah lewat beraneka cara. Sekarang sudah banyak sekali resep kekinian yang membuat bubur ayam jakarta semakin enak.

Resep bubur ayam jakarta juga mudah sekali untuk dibikin, lho. Kalian tidak usah capek-capek untuk membeli bubur ayam jakarta, sebab Kamu dapat menyiapkan di rumah sendiri. Untuk Kamu yang akan menyajikannya, di bawah ini adalah resep untuk membuat bubur ayam jakarta yang enak yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Bubur Ayam Jakarta:

1. Siapkan 2,5 centong nasi
1. Sediakan 1,5 liter air kaldu
1. Gunakan 5 siung bawang putih geprek sampai hancur
1. Siapkan 1,5 sdm santan kara
1. Siapkan 2 sdm kecap asin
1. Siapkan 2 sdm kecap ikan
1. Siapkan Secukupnya garam, lada
1. Ambil  Bumbu halus
1. Ambil 4 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Gunakan  Kuah kuning
1. Siapkan 1 ruas jahe,lengkuas geprek
1. Ambil 1 bh sere geprek
1. Siapkan 2 bh daun salam dan daun jeruk
1. Siapkan 1 sdt kunyit bubuk
1. Gunakan 1 sdt ketumbar bubuk
1. Siapkan 3 buah kemiri
1. Ambil  Topping/Pelengkap
1. Siapkan  Ayam goreng suwir
1. Gunakan  Ikan teri (skip)
1. Siapkan  kacang goreng
1. Gunakan  Daun bawang
1. Gunakan  Bawang goreng           (lihat resep)
1. Ambil  Kerupuk/emping
1. Sediakan  Kecap manis dan cabe
1. Siapkan  Telur rebus (tambahan saya)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Bubur Ayam Jakarta:

1. Masak air kaldu dan bawang putih sampai mendidih bagi pisahkan 500 ml untuk kuah kuning sisa nya dipake masak bubur.
1. Masukan nasi masak sampai menjadi bubur. Jika sudah menjadi bubur masukan santan, kecap, lada dan garam aduk rata masak hingga bubur meletup letup. Sisihkan.
1. Kuah kuning : tumis bumbu halus, jahe, lengkuas daun salam daun jeruk dan sereh lalu rebus dengan air kaldu tadi yg disisihkan 500 ml masak hingga mendidih, masukan kaldu ayam dan garam secukupnya icip rasa lalu masukan larutan maizena (saya:skip maizenanya) aduk cepat jika memakai maizena, masak lagi hingga agak mengental jika sudah mengental siap di sajikan




Ternyata cara buat bubur ayam jakarta yang enak sederhana ini gampang banget ya! Kamu semua mampu membuatnya. Resep bubur ayam jakarta Sangat sesuai banget buat kita yang baru akan belajar memasak ataupun untuk anda yang telah ahli dalam memasak.

Apakah kamu mau mencoba buat resep bubur ayam jakarta lezat sederhana ini? Kalau kalian ingin, yuk kita segera buruan menyiapkan peralatan dan bahan-bahannya, lalu bikin deh Resep bubur ayam jakarta yang enak dan simple ini. Sungguh taidak sulit kan. 

Maka dari itu, daripada kita berfikir lama-lama, hayo kita langsung buat resep bubur ayam jakarta ini. Dijamin kalian tiidak akan nyesel sudah bikin resep bubur ayam jakarta lezat tidak rumit ini! Selamat mencoba dengan resep bubur ayam jakarta nikmat tidak ribet ini di rumah kalian sendiri,oke!.

