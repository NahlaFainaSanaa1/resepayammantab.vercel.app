---
description: "Cara membuat Ingkung ayam kampung yang lezat Untuk Jualan"
title: "Cara membuat Ingkung ayam kampung yang lezat Untuk Jualan"
slug: 235-cara-membuat-ingkung-ayam-kampung-yang-lezat-untuk-jualan
date: 2021-02-26T13:54:43.213Z
image: https://img-global.cpcdn.com/recipes/4b0f71ce3ed08f56/680x482cq70/ingkung-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4b0f71ce3ed08f56/680x482cq70/ingkung-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4b0f71ce3ed08f56/680x482cq70/ingkung-ayam-kampung-foto-resep-utama.jpg
author: Charlotte Lopez
ratingvalue: 3.4
reviewcount: 4
recipeingredient:
- "1 ekor ayam kampung jantan"
- "2.000 ml santan"
- " bumbu halus"
- "1 sdt merica"
- "1 sdt ketumbar"
- "9 siung bawang putih"
- "7 siung bawang merah"
- "5 buah kemiri"
- "1 ruas kunir"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "2 lmbr daun salam"
- "2 batang sereh"
- "1.5 sdt garam"
- "100 grm gula jawa"
- "2 sdm air asam jawa"
- "3 lmbr daun jeruk"
recipeinstructions:
- "Haluskan semua bumbu kemudian sisihkan"
- "Cuci bersih ayam belah dada nya. Untuk mengikat ayam mulai dari saya kemudian sayap kecil lipat atau masukkan ke ketiak ayam ikat dengan tali."
- "Untuk yang kedua iris bagian ruas paha dan ruas cakar kemudian lipat cakar ayam keatas. Kemudian ikat. Setelah itu tarik mukut kepala ke atas smpai ke belakang agar dapat berdiri tegak."
- "Setelah semua terikat lumuri ayam dengan bumbu halus smp merata. Kemudian masukkan gula jawa garam air asam jawa dan santan masak hingga santan susut. Selama memasak siram2 kan kuah santan ke ayam dan sesekali dibalik. Masak kurng lebih 1.5 jam. Setelah susut ingkung dapat disajikan.."
categories:
- Resep
tags:
- ingkung
- ayam
- kampung

katakunci: ingkung ayam kampung 
nutrition: 164 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert

---


![Ingkung ayam kampung](https://img-global.cpcdn.com/recipes/4b0f71ce3ed08f56/680x482cq70/ingkung-ayam-kampung-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan panganan enak bagi keluarga merupakan hal yang menggembirakan untuk kita sendiri. Kewajiban seorang istri bukan saja mengurus rumah saja, tapi anda pun harus menyediakan kebutuhan gizi terpenuhi dan hidangan yang dikonsumsi orang tercinta harus menggugah selera.

Di zaman  sekarang, anda memang dapat membeli santapan jadi tidak harus capek memasaknya lebih dulu. Tetapi banyak juga lho orang yang memang ingin memberikan hidangan yang terenak untuk orang tercintanya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga. 



Apakah anda seorang penikmat ingkung ayam kampung?. Tahukah kamu, ingkung ayam kampung adalah sajian khas di Nusantara yang sekarang disukai oleh kebanyakan orang di hampir setiap tempat di Nusantara. Kamu bisa membuat ingkung ayam kampung sendiri di rumahmu dan boleh dijadikan makanan favoritmu di akhir pekanmu.

Kalian tidak perlu bingung untuk memakan ingkung ayam kampung, sebab ingkung ayam kampung mudah untuk ditemukan dan kita pun bisa menghidangkannya sendiri di tempatmu. ingkung ayam kampung dapat diolah memalui beragam cara. Kini pun sudah banyak resep kekinian yang membuat ingkung ayam kampung lebih lezat.

Resep ingkung ayam kampung pun gampang dihidangkan, lho. Kalian jangan repot-repot untuk membeli ingkung ayam kampung, karena Kamu mampu menyajikan di rumahmu. Bagi Anda yang hendak menyajikannya, dibawah ini merupakan cara untuk menyajikan ingkung ayam kampung yang enak yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ingkung ayam kampung:

1. Siapkan 1 ekor ayam kampung jantan
1. Ambil 2.000 ml santan
1. Sediakan  bumbu halus
1. Sediakan 1 sdt merica
1. Sediakan 1 sdt ketumbar
1. Sediakan 9 siung bawang putih
1. Gunakan 7 siung bawang merah
1. Gunakan 5 buah kemiri
1. Gunakan 1 ruas kunir
1. Sediakan 1 ruas jahe
1. Sediakan 1 ruas lengkuas
1. Gunakan 2 lmbr daun salam
1. Sediakan 2 batang sereh
1. Gunakan 1.5 sdt garam
1. Gunakan 100 grm gula jawa
1. Siapkan 2 sdm air asam jawa
1. Gunakan 3 lmbr daun jeruk




<!--inarticleads2-->

##### Langkah-langkah membuat Ingkung ayam kampung:

1. Haluskan semua bumbu kemudian sisihkan
1. Cuci bersih ayam belah dada nya. Untuk mengikat ayam mulai dari saya kemudian sayap kecil lipat atau masukkan ke ketiak ayam ikat dengan tali.
1. Untuk yang kedua iris bagian ruas paha dan ruas cakar kemudian lipat cakar ayam keatas. Kemudian ikat. Setelah itu tarik mukut kepala ke atas smpai ke belakang agar dapat berdiri tegak.
1. Setelah semua terikat lumuri ayam dengan bumbu halus smp merata. Kemudian masukkan gula jawa garam air asam jawa dan santan masak hingga santan susut. Selama memasak siram2 kan kuah santan ke ayam dan sesekali dibalik. Masak kurng lebih 1.5 jam. Setelah susut ingkung dapat disajikan..




Ternyata cara membuat ingkung ayam kampung yang mantab simple ini enteng sekali ya! Semua orang dapat menghidangkannya. Cara buat ingkung ayam kampung Sangat sesuai banget buat anda yang baru belajar memasak maupun untuk kalian yang telah pandai memasak.

Apakah kamu tertarik mulai mencoba buat resep ingkung ayam kampung mantab tidak rumit ini? Kalau kamu mau, mending kamu segera menyiapkan alat-alat dan bahannya, lalu bikin deh Resep ingkung ayam kampung yang lezat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kalian diam saja, maka langsung aja bikin resep ingkung ayam kampung ini. Pasti kalian gak akan menyesal sudah bikin resep ingkung ayam kampung enak tidak rumit ini! Selamat mencoba dengan resep ingkung ayam kampung nikmat tidak rumit ini di rumah kalian sendiri,ya!.

