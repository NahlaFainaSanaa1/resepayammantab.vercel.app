---
description: "Cara buat Crispy Chicken Steak with Teriyaki Sauce (Simple yet Tasty!) yang enak dan Mudah Dibuat"
title: "Cara buat Crispy Chicken Steak with Teriyaki Sauce (Simple yet Tasty!) yang enak dan Mudah Dibuat"
slug: 389-cara-buat-crispy-chicken-steak-with-teriyaki-sauce-simple-yet-tasty-yang-enak-dan-mudah-dibuat
date: 2021-05-23T10:04:50.007Z
image: https://img-global.cpcdn.com/recipes/ef02d579ceb727e4/680x482cq70/crispy-chicken-steak-with-teriyaki-sauce-simple-yet-tasty-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ef02d579ceb727e4/680x482cq70/crispy-chicken-steak-with-teriyaki-sauce-simple-yet-tasty-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ef02d579ceb727e4/680x482cq70/crispy-chicken-steak-with-teriyaki-sauce-simple-yet-tasty-foto-resep-utama.jpg
author: Chester Bowman
ratingvalue: 4.9
reviewcount: 9
recipeingredient:
- "1/2 kg dada ayam tanpa tulang"
- "1/2 butir jeruk nipis ambil airnya"
- "1 sdm saus tiram"
- "1/4 sdt lada bubuk"
- "1 sdm bawang putih bubuk"
- "1 sdm kaldu jamur"
- "Secubit garam optional"
- " Bahan Saus"
- "2 siung bawang putih geprek dan cincang"
- "1/2 buah bawang bombay potongpotong"
- "5 sdm saus teriyaki delmonte"
- "1 sdm saus tomat delmonte"
- "1 sdm saus sambal delmonte"
- "2 sdm saus tiram"
- "1 sdm kecap manis"
- "1 sdm margarin"
- "Secukupnya gula pasir"
- "Secukupnya lada bubuk"
- "Secukupnya maizena larutkan dengan 2 sdm air"
- "Sedikit air"
- " Bahan Pelapis"
- "5 sdm terigu pro sedang"
- "1 sdm maizena"
- "2 sdm tepung kobe"
- "1/2 sdt lada bubuk"
- "2 sdm kaldu jamur"
- " Bahan Pencelup"
- "1 butir telur kocok lepas"
- "Secubit lada bubuk"
- " Pelengkap"
- "Secukupnya buncis"
- "Secukupnya wortel"
- "Secukupnya kentang"
- "2 cubit garam"
recipeinstructions:
- "Belah dada ayam jadi dua bagian. Masing-masing iris tipis tapi jangan sampai putus (agar jadi lebih lebar). Lumuri ayam dengan jeruk nipis, diamkan selama 15 menit. Jika sudah, cuci bersih.  - Marinasi dengan saus tiram, lada bubuk, bawang putih, kaldu jamur, dan garam. Simpan di kulkas selama 1 jam."
- "Potong wortel dan buncis sesuai selera. Didihkan air, beri secubit garam, masukkan wortel, kemudian buncis. Jangan rebus terlalu lama, angkat, rendam dalam air es lalu tiriskan.  - Potong kentang berbentuk wedges, rebus sampai matang, kemudian goreng. Taburi dengan secubit garam."
- "Buat sausnya: campur semua saus, kecap, gula, dan lada bubuk ke dalam mangkuk. Panaskan margarin, tumis bawang putih dan bawang bombay hingga harum, kemudian masukkan bahan saus yang sudah dicampur tadi. Beri sedikit air. Aduk-aduk perlahan sampai mendidih. Koreksi rasanya, bila sudah pas, tuangkan larutan maizena. Aduk-aduk kembali hingga mengental, koreksi rasa sekali lagi, sisihkan."
- "Siapkan bahan pelapis dan pencelup, keluarkan ayam dari kulkas. Kocok telur, beri sedikit lada. - Masukkan ayam ke dalam bahan pelapis hingga terbalur rata, gulingkan ke dalam telur, lalu masukkan lagi ke dalam bahan pelapis sambil dicubit-cubit agar keriting saat digoreng."
- "Panaskan minyak dalam wajan, goreng ayam dalam api sedang hingga matang. Angkat, tiriskan. Sajikan bersama saus teriyaki, sayuran, serta potongan kentang. So yumm!"
categories:
- Resep
tags:
- crispy
- chicken
- steak

katakunci: crispy chicken steak 
nutrition: 255 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch

---


![Crispy Chicken Steak with Teriyaki Sauce (Simple yet Tasty!)](https://img-global.cpcdn.com/recipes/ef02d579ceb727e4/680x482cq70/crispy-chicken-steak-with-teriyaki-sauce-simple-yet-tasty-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan hidangan mantab kepada orang tercinta adalah hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang ibu Tidak sekedar menangani rumah saja, tetapi kamu juga wajib menyediakan kebutuhan nutrisi terpenuhi dan juga panganan yang dikonsumsi orang tercinta mesti sedap.

Di era  saat ini, kamu sebenarnya bisa membeli olahan jadi walaupun tidak harus repot membuatnya lebih dulu. Tetapi banyak juga mereka yang memang ingin menghidangkan yang terlezat untuk orang yang dicintainya. Sebab, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan orang tercinta. 



Mungkinkah anda merupakan seorang penyuka crispy chicken steak with teriyaki sauce (simple yet tasty!)?. Tahukah kamu, crispy chicken steak with teriyaki sauce (simple yet tasty!) merupakan sajian khas di Indonesia yang saat ini disenangi oleh orang-orang dari hampir setiap daerah di Nusantara. Anda dapat menghidangkan crispy chicken steak with teriyaki sauce (simple yet tasty!) sendiri di rumah dan dapat dijadikan camilan favorit di akhir pekan.

Kalian jangan bingung untuk memakan crispy chicken steak with teriyaki sauce (simple yet tasty!), sebab crispy chicken steak with teriyaki sauce (simple yet tasty!) gampang untuk didapatkan dan anda pun dapat memasaknya sendiri di rumah. crispy chicken steak with teriyaki sauce (simple yet tasty!) boleh diolah lewat bermacam cara. Sekarang ada banyak banget cara kekinian yang menjadikan crispy chicken steak with teriyaki sauce (simple yet tasty!) semakin nikmat.

Resep crispy chicken steak with teriyaki sauce (simple yet tasty!) pun gampang sekali untuk dibikin, lho. Kalian tidak usah repot-repot untuk membeli crispy chicken steak with teriyaki sauce (simple yet tasty!), karena Anda bisa membuatnya ditempatmu. Bagi Anda yang ingin mencobanya, berikut cara untuk menyajikan crispy chicken steak with teriyaki sauce (simple yet tasty!) yang lezat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Crispy Chicken Steak with Teriyaki Sauce (Simple yet Tasty!):

1. Siapkan 1/2 kg dada ayam tanpa tulang
1. Siapkan 1/2 butir jeruk nipis, ambil airnya
1. Sediakan 1 sdm saus tiram
1. Ambil 1/4 sdt lada bubuk
1. Siapkan 1 sdm bawang putih bubuk
1. Gunakan 1 sdm kaldu jamur
1. Gunakan Secubit garam (optional)
1. Gunakan  Bahan Saus:
1. Siapkan 2 siung bawang putih, geprek dan cincang
1. Gunakan 1/2 buah bawang bombay, potong-potong
1. Sediakan 5 sdm saus teriyaki delmonte
1. Ambil 1 sdm saus tomat delmonte
1. Sediakan 1 sdm saus sambal delmonte
1. Siapkan 2 sdm saus tiram
1. Sediakan 1 sdm kecap manis
1. Siapkan 1 sdm margarin
1. Sediakan Secukupnya gula pasir
1. Gunakan Secukupnya lada bubuk
1. Siapkan Secukupnya maizena (larutkan dengan 2 sdm air)
1. Siapkan Sedikit air
1. Sediakan  Bahan Pelapis:
1. Siapkan 5 sdm terigu pro sedang
1. Gunakan 1 sdm maizena
1. Siapkan 2 sdm tepung kobe
1. Siapkan 1/2 sdt lada bubuk
1. Sediakan 2 sdm kaldu jamur
1. Gunakan  Bahan Pencelup:
1. Gunakan 1 butir telur, kocok lepas
1. Gunakan Secubit lada bubuk
1. Siapkan  Pelengkap:
1. Ambil Secukupnya buncis
1. Siapkan Secukupnya wortel
1. Siapkan Secukupnya kentang
1. Siapkan 2 cubit garam




<!--inarticleads2-->

##### Cara menyiapkan Crispy Chicken Steak with Teriyaki Sauce (Simple yet Tasty!):

1. Belah dada ayam jadi dua bagian. Masing-masing iris tipis tapi jangan sampai putus (agar jadi lebih lebar). Lumuri ayam dengan jeruk nipis, diamkan selama 15 menit. Jika sudah, cuci bersih. -  - - Marinasi dengan saus tiram, lada bubuk, bawang putih, kaldu jamur, dan garam. Simpan di kulkas selama 1 jam.
1. Potong wortel dan buncis sesuai selera. Didihkan air, beri secubit garam, masukkan wortel, kemudian buncis. Jangan rebus terlalu lama, angkat, rendam dalam air es lalu tiriskan. -  - - Potong kentang berbentuk wedges, rebus sampai matang, kemudian goreng. Taburi dengan secubit garam.
1. Buat sausnya: campur semua saus, kecap, gula, dan lada bubuk ke dalam mangkuk. Panaskan margarin, tumis bawang putih dan bawang bombay hingga harum, kemudian masukkan bahan saus yang sudah dicampur tadi. Beri sedikit air. Aduk-aduk perlahan sampai mendidih. Koreksi rasanya, bila sudah pas, tuangkan larutan maizena. Aduk-aduk kembali hingga mengental, koreksi rasa sekali lagi, sisihkan.
1. Siapkan bahan pelapis dan pencelup, keluarkan ayam dari kulkas. Kocok telur, beri sedikit lada. - - Masukkan ayam ke dalam bahan pelapis hingga terbalur rata, gulingkan ke dalam telur, lalu masukkan lagi ke dalam bahan pelapis sambil dicubit-cubit agar keriting saat digoreng.
1. Panaskan minyak dalam wajan, goreng ayam dalam api sedang hingga matang. Angkat, tiriskan. Sajikan bersama saus teriyaki, sayuran, serta potongan kentang. So yumm!




Wah ternyata cara buat crispy chicken steak with teriyaki sauce (simple yet tasty!) yang enak tidak rumit ini mudah banget ya! Kamu semua mampu memasaknya. Resep crispy chicken steak with teriyaki sauce (simple yet tasty!) Sesuai sekali buat kalian yang baru akan belajar memasak maupun untuk kamu yang sudah hebat memasak.

Tertarik untuk mulai mencoba membuat resep crispy chicken steak with teriyaki sauce (simple yet tasty!) enak tidak ribet ini? Kalau kamu ingin, yuk kita segera buruan siapin alat-alat dan bahannya, maka bikin deh Resep crispy chicken steak with teriyaki sauce (simple yet tasty!) yang mantab dan tidak rumit ini. Sungguh taidak sulit kan. 

Oleh karena itu, ketimbang kamu berlama-lama, maka langsung aja buat resep crispy chicken steak with teriyaki sauce (simple yet tasty!) ini. Dijamin kamu tak akan menyesal bikin resep crispy chicken steak with teriyaki sauce (simple yet tasty!) mantab sederhana ini! Selamat berkreasi dengan resep crispy chicken steak with teriyaki sauce (simple yet tasty!) mantab tidak rumit ini di tempat tinggal sendiri,oke!.

