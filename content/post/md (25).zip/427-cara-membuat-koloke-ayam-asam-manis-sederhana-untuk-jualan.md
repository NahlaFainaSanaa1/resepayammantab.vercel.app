---
description: "Cara membuat Koloke ayam asam manis Sederhana Untuk Jualan"
title: "Cara membuat Koloke ayam asam manis Sederhana Untuk Jualan"
slug: 427-cara-membuat-koloke-ayam-asam-manis-sederhana-untuk-jualan
date: 2021-03-03T08:32:02.148Z
image: https://img-global.cpcdn.com/recipes/58da6c99fa45fc18/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/58da6c99fa45fc18/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/58da6c99fa45fc18/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg
author: Nannie Rose
ratingvalue: 3.6
reviewcount: 7
recipeingredient:
- "1 kg ayam filet"
- "1 buah wortel"
- "1 buah timun ukuran kecil"
- "1/3 nanas madu opsional"
- " Bahan marinasi"
- "1 siung bawang putih"
- "1 sdt garam"
- " lada bubuk"
- " Bahan Adonan Kering"
- "200 gram tepung terigu"
- "100 gram tepung beras"
- "100 tepung bumbu me  tepung sasa"
- "1/2 sdt garam"
- "sedikit lada"
- "sedikit masako  royco"
- "1/4 sdt baking powder"
- " Bahan Adonan Basah"
- "1 butir telur kocok lepas"
- "2 sdm bahan adonan kering"
- " Air dingin dikira2 jangan sampai terlalu encer"
- " Bahan Saos"
- "3 siung bawang putih cincang"
- "2 siung bawang merah cincang"
- "1 bawang bombay iris tipis"
- "10 sdm saos tomat me  delmonte"
- "2 sdm saos cabe me  skip"
- "2 sdm gula"
- "1 sdt garam"
- " penyedap me  kaldu jamur"
- "1 sdt kecap asin"
- "1 sdt saos raja rasa"
- "200 ml air"
- "2 sdm tepung maizena larutkan"
- "2 sdm minyak untuk menumis"
recipeinstructions:
- "Potong ayam filet sesuai selera, lalu marinasi dengan bahan marinasi sekitar 15-30 menit."
- "Campur semua bahan adonan kering dan siapkan adonan basahnya juga."
- "Celupkan ayam yang sudah di marinasi ke tepung kering, lalumasukkan ayam ke tepung basah dan lanjut ke tepung kering. Jangan terlalu di tekan agar ayam untuk hasil ayam krispy nya keriting dan pastikan ayam dari adonan kering ke-2 langsung di goreng."
- "Goreng ayam sampai ke emasan lalu tiriskan."
- "Panas kan minyak untuk menumis, masukkan bawang putih dan bawang merah, tumis sampai harum lalu masukkan saos tomat dan saos cabe lalu aduk2 sampai berbuih. Kemudian masukkan wortel dan bawang bombay sampai sedikit layu. Masukkan air dan aduk2, tunggu. air mendidih lalu masukkan nanas, timun, garam, gula, dan penyedap."
- "Tes rasa, lalu tambahkan kecap asin dan saos raja rasa, kemudian masukkan larutan tepung maizena dan aduk sampai mendidih. Hidangkan saos bisa di pisah ataupun di siram langsung ke ayamnya."
categories:
- Resep
tags:
- koloke
- ayam
- asam

katakunci: koloke ayam asam 
nutrition: 153 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert

---


![Koloke ayam asam manis](https://img-global.cpcdn.com/recipes/58da6c99fa45fc18/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan hidangan nikmat pada keluarga tercinta merupakan hal yang memuaskan bagi anda sendiri. Tanggung jawab seorang  wanita Tidak cuma menjaga rumah saja, tapi kamu juga harus menyediakan keperluan gizi terpenuhi dan juga hidangan yang dikonsumsi anak-anak wajib enak.

Di masa  sekarang, kita memang dapat memesan hidangan praktis tanpa harus capek mengolahnya lebih dulu. Tapi banyak juga lho orang yang memang ingin memberikan yang terenak bagi orang tercintanya. Karena, memasak sendiri jauh lebih bersih dan kita juga bisa menyesuaikan berdasarkan masakan kesukaan orang tercinta. 



Mungkinkah anda merupakan seorang penikmat koloke ayam asam manis?. Asal kamu tahu, koloke ayam asam manis adalah makanan khas di Nusantara yang kini disukai oleh orang-orang dari hampir setiap daerah di Indonesia. Kamu dapat membuat koloke ayam asam manis sendiri di rumah dan boleh dijadikan hidangan kesukaanmu di hari liburmu.

Kita tak perlu bingung untuk menyantap koloke ayam asam manis, lantaran koloke ayam asam manis gampang untuk didapatkan dan juga kamu pun boleh menghidangkannya sendiri di rumah. koloke ayam asam manis bisa dimasak dengan bermacam cara. Sekarang ada banyak resep modern yang menjadikan koloke ayam asam manis semakin lezat.

Resep koloke ayam asam manis pun sangat mudah dihidangkan, lho. Kamu jangan repot-repot untuk memesan koloke ayam asam manis, tetapi Kita bisa menyajikan sendiri di rumah. Untuk Anda yang ingin menghidangkannya, dibawah ini merupakan resep untuk menyajikan koloke ayam asam manis yang mantab yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Koloke ayam asam manis:

1. Sediakan 1 kg ayam filet
1. Sediakan 1 buah wortel
1. Siapkan 1 buah timun ukuran kecil
1. Sediakan 1/3 nanas madu (opsional)
1. Sediakan  Bahan marinasi
1. Ambil 1 siung bawang putih
1. Sediakan 1 sdt garam
1. Sediakan  lada bubuk
1. Gunakan  Bahan Adonan Kering
1. Ambil 200 gram tepung terigu
1. Ambil 100 gram tepung beras
1. Sediakan 100 tepung bumbu (me : tepung sasa)
1. Gunakan 1/2 sdt garam
1. Siapkan sedikit lada
1. Ambil sedikit masako / royco
1. Ambil 1/4 sdt baking powder
1. Siapkan  Bahan Adonan Basah
1. Siapkan 1 butir telur, kocok lepas
1. Siapkan 2 sdm bahan adonan kering
1. Ambil  Air dingin (dikira2 jangan sampai terlalu encer)
1. Siapkan  Bahan Saos
1. Sediakan 3 siung bawang putih (cincang)
1. Siapkan 2 siung bawang merah (cincang)
1. Gunakan 1 bawang bombay (iris tipis)
1. Sediakan 10 sdm saos tomat (me : delmonte)
1. Sediakan 2 sdm saos cabe (me : skip)
1. Sediakan 2 sdm gula
1. Sediakan 1 sdt garam
1. Gunakan  penyedap (me : kaldu jamur)
1. Siapkan 1 sdt kecap asin
1. Gunakan 1 sdt saos raja rasa
1. Sediakan 200 ml air
1. Ambil 2 sdm tepung maizena (larutkan)
1. Sediakan 2 sdm minyak untuk menumis




<!--inarticleads2-->

##### Langkah-langkah membuat Koloke ayam asam manis:

1. Potong ayam filet sesuai selera, lalu marinasi dengan bahan marinasi sekitar 15-30 menit.
1. Campur semua bahan adonan kering dan siapkan adonan basahnya juga.
1. Celupkan ayam yang sudah di marinasi ke tepung kering, lalumasukkan ayam ke tepung basah dan lanjut ke tepung kering. Jangan terlalu di tekan agar ayam untuk hasil ayam krispy nya keriting dan pastikan ayam dari adonan kering ke-2 langsung di goreng.
1. Goreng ayam sampai ke emasan lalu tiriskan.
1. Panas kan minyak untuk menumis, masukkan bawang putih dan bawang merah, tumis sampai harum lalu masukkan saos tomat dan saos cabe lalu aduk2 sampai berbuih. Kemudian masukkan wortel dan bawang bombay sampai sedikit layu. Masukkan air dan aduk2, tunggu. air mendidih lalu masukkan nanas, timun, garam, gula, dan penyedap.
1. Tes rasa, lalu tambahkan kecap asin dan saos raja rasa, kemudian masukkan larutan tepung maizena dan aduk sampai mendidih. Hidangkan saos bisa di pisah ataupun di siram langsung ke ayamnya.




Wah ternyata resep koloke ayam asam manis yang lezat simple ini mudah sekali ya! Kalian semua bisa menghidangkannya. Resep koloke ayam asam manis Sangat sesuai banget buat kalian yang baru mau belajar memasak ataupun bagi kalian yang telah hebat memasak.

Tertarik untuk mencoba membuat resep koloke ayam asam manis enak sederhana ini? Kalau anda ingin, ayo kalian segera buruan siapin alat-alat dan bahannya, maka buat deh Resep koloke ayam asam manis yang lezat dan simple ini. Sangat gampang kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, yuk kita langsung saja hidangkan resep koloke ayam asam manis ini. Dijamin kalian tak akan menyesal sudah buat resep koloke ayam asam manis lezat simple ini! Selamat berkreasi dengan resep koloke ayam asam manis mantab sederhana ini di rumah masing-masing,oke!.

