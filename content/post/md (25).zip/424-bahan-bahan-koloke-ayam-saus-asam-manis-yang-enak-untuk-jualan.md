---
description: "Bahan-bahan Koloke Ayam Saus Asam Manis yang enak Untuk Jualan"
title: "Bahan-bahan Koloke Ayam Saus Asam Manis yang enak Untuk Jualan"
slug: 424-bahan-bahan-koloke-ayam-saus-asam-manis-yang-enak-untuk-jualan
date: 2021-06-30T21:53:56.273Z
image: https://img-global.cpcdn.com/recipes/920e5bc05168af75/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/920e5bc05168af75/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/920e5bc05168af75/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
author: Anthony Valdez
ratingvalue: 3.2
reviewcount: 12
recipeingredient:
- " Bahan Marinasi"
- "1/2 kg Fillet Ayam"
- "1/2 sdt lada bubuk"
- "2 sdt bawang putih bubuk"
- "Sedikit Garam"
- " Adonan kering"
- "100 gr Tepung Ayam Krispi"
- "100 gr Tepung Terigu"
- "1/4 sdt Baking Powder Skip"
- "Sedikit kaldu jamur optional"
- " Adonan Basah"
- "1 Butir putih telur putihnya saja"
- "100 air es"
- "1 sdm Adonan kering"
- " Bahan Saus"
- "1 buah Wortel"
- "2 Buah Timun ukuran kecil"
- "1 Pcs Bawang Bombay"
- "1/4 buah nanas skip"
- "2 siung Bawang Putih"
- "1 sdm Kecap Inggris"
- "10 sdm Saus Tomat"
- "2 sdm Saus Sambal skip"
- "1/2 sdt lada bubuk"
- "1 sdt garam"
- "1 sdt gula pasir"
- "200 ml air"
- "Secukupnya cabe skip"
recipeinstructions:
- "Cuci dan potong dadu ayam nya, lalu marinasi dengan bumbu nya. Diamkan dalam kulkas 30 mnt"
- "Selagi menunggu 30 mnt, siapkan bahan untuk sausnya. 1/2 Bawang bombay potong kasar, 1/2 nya lagi iris bulat dan bawang putih di cincang, wortel dan timun di potong korek api, timun buang bijinya"
- "Tumis bawang putih dan bombay hingga harum, lalu masukkan saus tomat, kecap inggris dan air. Masak hingga mendidih"
- "Masukkan timun dan wortel, masak hinnga wortel empuk. Tambahkan bawang bombay yg setengahnya lagi, tambahkan bumbu lainnya, masak hingga mengental. Sisihkan"
- "Buat adonan kering dan adonan basah dalam 2 wadah ya"
- "Setelah 30 mnt ngadem di kulkas, ayam yg sudah di marinasi di balur dengan tepung kering dan basah, dengan step : balur adonan kering &gt; celup ke adonan basah &gt; balur lagi ke adonan kering. Lakukan sampai ayam habis"
- "Panaskan minyak dengan cara nyalakan api kecil saja, jangan diomelin minyaknya biar panas, jangan ya bund 😄 goreng deh ayamnya hingga kecoklatan, sudah matang di tiriskan dulu."
- "Tata ayamnya di piring saji, siram dengan sausnya deh. Siap di santap yuummm"
categories:
- Resep
tags:
- koloke
- ayam
- saus

katakunci: koloke ayam saus 
nutrition: 291 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dinner

---


![Koloke Ayam Saus Asam Manis](https://img-global.cpcdn.com/recipes/920e5bc05168af75/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan olahan lezat kepada orang tercinta adalah hal yang membahagiakan untuk kamu sendiri. Peran seorang ibu Tidak sekedar mengurus rumah saja, tapi kamu juga wajib memastikan kebutuhan gizi terpenuhi dan juga olahan yang disantap orang tercinta mesti lezat.

Di waktu  saat ini, kalian sebenarnya dapat membeli masakan instan tidak harus susah memasaknya dahulu. Tetapi banyak juga lho orang yang selalu mau menghidangkan yang terbaik untuk orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai dengan masakan kesukaan keluarga. 



Apakah anda merupakan salah satu penyuka koloke ayam saus asam manis?. Asal kamu tahu, koloke ayam saus asam manis adalah makanan khas di Indonesia yang kini disenangi oleh orang-orang dari berbagai wilayah di Nusantara. Kita dapat menyajikan koloke ayam saus asam manis sendiri di rumah dan dapat dijadikan santapan kesenanganmu di hari libur.

Kita jangan bingung untuk memakan koloke ayam saus asam manis, lantaran koloke ayam saus asam manis tidak sukar untuk dicari dan juga kita pun boleh memasaknya sendiri di rumah. koloke ayam saus asam manis boleh dimasak dengan bermacam cara. Saat ini telah banyak resep kekinian yang membuat koloke ayam saus asam manis semakin enak.

Resep koloke ayam saus asam manis juga gampang sekali untuk dibikin, lho. Kamu tidak perlu repot-repot untuk membeli koloke ayam saus asam manis, tetapi Kita bisa menyajikan di rumahmu. Untuk Kita yang hendak menghidangkannya, berikut resep untuk membuat koloke ayam saus asam manis yang enak yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Koloke Ayam Saus Asam Manis:

1. Gunakan  Bahan Marinasi
1. Sediakan 1/2 kg Fillet Ayam
1. Siapkan 1/2 sdt lada bubuk
1. Siapkan 2 sdt bawang putih bubuk
1. Gunakan Sedikit Garam
1. Siapkan  Adonan kering
1. Gunakan 100 gr Tepung Ayam Krispi
1. Gunakan 100 gr Tepung Terigu
1. Gunakan 1/4 sdt Baking Powder (Skip)
1. Ambil Sedikit kaldu jamur (optional)
1. Gunakan  Adonan Basah
1. Sediakan 1 Butir putih telur (putihnya saja)
1. Gunakan 100 air es
1. Siapkan 1 sdm Adonan kering
1. Sediakan  Bahan Saus
1. Ambil 1 buah Wortel
1. Ambil 2 Buah Timun (ukuran kecil)
1. Siapkan 1 Pcs Bawang Bombay
1. Gunakan 1/4 buah nanas (skip)
1. Gunakan 2 siung Bawang Putih
1. Gunakan 1 sdm Kecap Inggris
1. Sediakan 10 sdm Saus Tomat
1. Sediakan 2 sdm Saus Sambal (skip)
1. Ambil 1/2 sdt lada bubuk
1. Siapkan 1 sdt garam
1. Siapkan 1 sdt gula pasir
1. Sediakan 200 ml air
1. Gunakan Secukupnya cabe (skip)




<!--inarticleads2-->

##### Langkah-langkah membuat Koloke Ayam Saus Asam Manis:

1. Cuci dan potong dadu ayam nya, lalu marinasi dengan bumbu nya. Diamkan dalam kulkas 30 mnt
1. Selagi menunggu 30 mnt, siapkan bahan untuk sausnya. 1/2 Bawang bombay potong kasar, 1/2 nya lagi iris bulat dan bawang putih di cincang, wortel dan timun di potong korek api, timun buang bijinya
1. Tumis bawang putih dan bombay hingga harum, lalu masukkan saus tomat, kecap inggris dan air. Masak hingga mendidih
1. Masukkan timun dan wortel, masak hinnga wortel empuk. Tambahkan bawang bombay yg setengahnya lagi, tambahkan bumbu lainnya, masak hingga mengental. Sisihkan
1. Buat adonan kering dan adonan basah dalam 2 wadah ya
1. Setelah 30 mnt ngadem di kulkas, ayam yg sudah di marinasi di balur dengan tepung kering dan basah, dengan step : balur adonan kering &gt; celup ke adonan basah &gt; balur lagi ke adonan kering. Lakukan sampai ayam habis
1. Panaskan minyak dengan cara nyalakan api kecil saja, jangan diomelin minyaknya biar panas, jangan ya bund 😄 goreng deh ayamnya hingga kecoklatan, sudah matang di tiriskan dulu.
1. Tata ayamnya di piring saji, siram dengan sausnya deh. Siap di santap yuummm




Wah ternyata resep koloke ayam saus asam manis yang mantab tidak rumit ini gampang sekali ya! Kamu semua mampu mencobanya. Resep koloke ayam saus asam manis Sangat cocok banget untuk kamu yang sedang belajar memasak maupun juga bagi kamu yang telah jago dalam memasak.

Tertarik untuk mencoba membikin resep koloke ayam saus asam manis enak sederhana ini? Kalau anda ingin, ayo kamu segera menyiapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep koloke ayam saus asam manis yang mantab dan simple ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kalian diam saja, maka kita langsung saja buat resep koloke ayam saus asam manis ini. Dijamin kalian gak akan menyesal sudah buat resep koloke ayam saus asam manis enak sederhana ini! Selamat mencoba dengan resep koloke ayam saus asam manis nikmat sederhana ini di tempat tinggal kalian masing-masing,oke!.

