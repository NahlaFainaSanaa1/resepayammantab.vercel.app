---
description: "Bahan-bahan Rendang Ayam yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Rendang Ayam yang lezat dan Mudah Dibuat"
slug: 106-bahan-bahan-rendang-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-03-21T17:09:00.997Z
image: https://img-global.cpcdn.com/recipes/5d96e1bfc90166ab/680x482cq70/rendang-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5d96e1bfc90166ab/680x482cq70/rendang-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5d96e1bfc90166ab/680x482cq70/rendang-ayam-foto-resep-utama.jpg
author: Jared Walker
ratingvalue: 4.5
reviewcount: 13
recipeingredient:
- "500 gr ayam"
- "500 ml santan"
- "300 ml air"
- "75 gr kelapa parut"
- "1 sdt merica bubuk"
- "1,5 sdt garam"
- "65 gr gula merah"
- " Bumbu Aromatik"
- "1 lembar daun jeruk"
- "1 lembar daun salam"
- "1 lembar daun kunyit"
- "1 cm lengkuas geprek"
- "1 batang serai geprek"
- "2 buah cengkeh"
- "1 buah kapulaga"
- "1 buah bunga lawang"
- " Bumbu Halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabai merah sesuai selera"
- "3 buah cabai rawit sesuai selera"
- "1 cm lengkuas"
- "1 cm jahe"
- "1 cm kunyit"
- "2 butir kemiri"
- "1/4 sdt ketumbar"
recipeinstructions:
- "Siapkan semua bahan."
- "Sangrai kelapa parut dengan api kecil lalu tumbuk hingga keluar minyaknya."
- "Sangrai bumbu halus dan kelapa sangrai dengan api kecil hingga harum, kemudian masukkan bumbu aromatik. Aduk kembali hingga harum, lalu tuang air dan bumbui"
- "Ungkep ayam selama 30 menit dengan api sedang. Tutup wajan. Setelah kuah menyusut dan ayam empuk. Tuang santan. Aduk kembali dan koreksi rasa. Masak hingga kuah menyusut."
- "Matikan kompor dan sajikan 😋"
categories:
- Resep
tags:
- rendang
- ayam

katakunci: rendang ayam 
nutrition: 136 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![Rendang Ayam](https://img-global.cpcdn.com/recipes/5d96e1bfc90166ab/680x482cq70/rendang-ayam-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan masakan mantab pada keluarga merupakan hal yang mengasyikan bagi anda sendiri. Tugas seorang istri Tidak hanya mengurus rumah saja, namun kamu pun wajib menyediakan kebutuhan nutrisi terpenuhi dan santapan yang dikonsumsi keluarga tercinta harus menggugah selera.

Di waktu  saat ini, kalian sebenarnya bisa memesan masakan instan tidak harus ribet mengolahnya dulu. Tetapi banyak juga lho mereka yang selalu mau memberikan yang terbaik untuk orang yang dicintainya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan keluarga. 



Mungkinkah anda merupakan salah satu penggemar rendang ayam?. Asal kamu tahu, rendang ayam merupakan sajian khas di Indonesia yang sekarang disukai oleh banyak orang di berbagai daerah di Indonesia. Anda bisa menghidangkan rendang ayam sendiri di rumahmu dan dapat dijadikan camilan favoritmu di hari libur.

Anda jangan bingung untuk mendapatkan rendang ayam, lantaran rendang ayam tidak sulit untuk ditemukan dan juga kamu pun dapat memasaknya sendiri di rumah. rendang ayam bisa dibuat dengan berbagai cara. Sekarang ada banyak sekali cara modern yang menjadikan rendang ayam lebih lezat.

Resep rendang ayam juga gampang sekali untuk dibuat, lho. Anda jangan repot-repot untuk memesan rendang ayam, karena Kita mampu membuatnya ditempatmu. Untuk Kita yang ingin mencobanya, berikut ini resep membuat rendang ayam yang enak yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Rendang Ayam:

1. Gunakan 500 gr ayam
1. Ambil 500 ml santan
1. Sediakan 300 ml air
1. Gunakan 75 gr kelapa (parut)
1. Gunakan 1 sdt merica bubuk
1. Sediakan 1,5 sdt garam
1. Ambil 65 gr gula merah
1. Gunakan  Bumbu Aromatik
1. Gunakan 1 lembar daun jeruk
1. Ambil 1 lembar daun salam
1. Sediakan 1 lembar daun kunyit
1. Sediakan 1 cm lengkuas (geprek)
1. Sediakan 1 batang serai (geprek)
1. Gunakan 2 buah cengkeh
1. Gunakan 1 buah kapulaga
1. Sediakan 1 buah bunga lawang
1. Gunakan  Bumbu Halus
1. Sediakan 5 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Siapkan 5 buah cabai merah (sesuai selera)
1. Ambil 3 buah cabai rawit (sesuai selera)
1. Ambil 1 cm lengkuas
1. Sediakan 1 cm jahe
1. Siapkan 1 cm kunyit
1. Gunakan 2 butir kemiri
1. Siapkan 1/4 sdt ketumbar




<!--inarticleads2-->

##### Cara menyiapkan Rendang Ayam:

1. Siapkan semua bahan.
1. Sangrai kelapa parut dengan api kecil lalu tumbuk hingga keluar minyaknya.
1. Sangrai bumbu halus dan kelapa sangrai dengan api kecil hingga harum, kemudian masukkan bumbu aromatik. Aduk kembali hingga harum, lalu tuang air dan bumbui
1. Ungkep ayam selama 30 menit dengan api sedang. Tutup wajan. Setelah kuah menyusut dan ayam empuk. Tuang santan. Aduk kembali dan koreksi rasa. Masak hingga kuah menyusut.
1. Matikan kompor dan sajikan 😋




Ternyata cara buat rendang ayam yang enak tidak rumit ini gampang banget ya! Kalian semua bisa memasaknya. Resep rendang ayam Sesuai sekali buat kamu yang baru mau belajar memasak maupun bagi kamu yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba bikin resep rendang ayam mantab tidak ribet ini? Kalau tertarik, mending kamu segera buruan siapin peralatan dan bahannya, setelah itu bikin deh Resep rendang ayam yang enak dan tidak ribet ini. Benar-benar gampang kan. 

Maka, daripada kalian berlama-lama, yuk kita langsung saja hidangkan resep rendang ayam ini. Pasti kamu tak akan menyesal bikin resep rendang ayam mantab simple ini! Selamat mencoba dengan resep rendang ayam enak tidak rumit ini di tempat tinggal kalian sendiri,ya!.

