---
description: "Resep Ayam goreng utuh lengkuas yang nikmat dan Mudah Dibuat"
title: "Resep Ayam goreng utuh lengkuas yang nikmat dan Mudah Dibuat"
slug: 146-resep-ayam-goreng-utuh-lengkuas-yang-nikmat-dan-mudah-dibuat
date: 2021-01-08T01:54:24.096Z
image: https://img-global.cpcdn.com/recipes/7c32eb9799412bff/680x482cq70/ayam-goreng-utuh-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7c32eb9799412bff/680x482cq70/ayam-goreng-utuh-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7c32eb9799412bff/680x482cq70/ayam-goreng-utuh-lengkuas-foto-resep-utama.jpg
author: Hunter Hernandez
ratingvalue: 5
reviewcount: 11
recipeingredient:
- "1 ekor Ayam utuh"
- "1,5 ruas kunyit"
- "1 ons lengkuas muda parut  bsa d blender bareng bumbu2 yg lain"
- "8 bawang merah"
- "6 bawang putih"
- "1 sdm ketumbar"
- "4 buah kemiri"
- "1/4 sdt jintan"
- "2 batang sereh geprek"
- "2 daun salam"
- "1/2 bundar kecil gula merah"
- "1 sdm asam jawa"
- "secukupnya Air kelapa kalau TDK adapake air biasa jg boleh"
- "1 sdt garam"
- "1/4 sdt kaldu bubuk"
- "1/2 sdt gula"
recipeinstructions:
- "Cuci bersih ayam,lalu blender smua bumbu2nya,siap kan presto lalu lumuri smua bumbu2nya di ayam tes rasa dan presto kurang Lbh 30 menit"
- "Setelah 30 menit matikan kompor,dan buang uap dlm presto,setelah itu ayam bs di goreng sampai kecoklatan,terakhir saring bumbu nya dan goreng sampai ke coklatan,lalu taburi di atas ayam"
- "Dan ayam goreng lengkuas siap di bawa utk oleh2👏👏..jgn lupa buatkan sambel bawang,dan bs jg di bawa air ungkepanya buat tabur kuah kuningnya,selamat mencoba"
categories:
- Resep
tags:
- ayam
- goreng
- utuh

katakunci: ayam goreng utuh 
nutrition: 181 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam goreng utuh lengkuas](https://img-global.cpcdn.com/recipes/7c32eb9799412bff/680x482cq70/ayam-goreng-utuh-lengkuas-foto-resep-utama.jpg)

Jika kita seorang orang tua, menyuguhkan santapan nikmat buat famili merupakan suatu hal yang sangat menyenangkan untuk anda sendiri. Peran seorang ibu Tidak cuma menjaga rumah saja, tapi anda pun wajib menyediakan kebutuhan gizi tercukupi dan juga hidangan yang dimakan anak-anak wajib menggugah selera.

Di era  sekarang, kamu memang dapat membeli panganan instan tanpa harus ribet memasaknya dulu. Tapi banyak juga mereka yang memang ingin menyajikan yang terlezat untuk keluarganya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan keluarga. 

Nikmati ayam goreng bumbu lengkuas ini dengan nasi hangat lengkap ditambah sambal dan aneka lalaban seperti kol, daun selada, timun, terong dan lain sebagainya untuk menambah nabsu makan anak-anak dan keluarga. Masak ayam goreng di rumah tapi rasa gak kalah sama Resto? Ayam Goreng Lengkuas, resep klasik bagi mereka yang mencari selingan selain serundeng ataupun kremes.

Apakah anda seorang penggemar ayam goreng utuh lengkuas?. Asal kamu tahu, ayam goreng utuh lengkuas adalah hidangan khas di Nusantara yang saat ini digemari oleh orang-orang dari hampir setiap tempat di Nusantara. Anda dapat memasak ayam goreng utuh lengkuas kreasi sendiri di rumahmu dan dapat dijadikan hidangan favoritmu di hari liburmu.

Kita tidak perlu bingung untuk menyantap ayam goreng utuh lengkuas, sebab ayam goreng utuh lengkuas mudah untuk didapatkan dan anda pun boleh menghidangkannya sendiri di tempatmu. ayam goreng utuh lengkuas boleh dimasak memalui berbagai cara. Sekarang sudah banyak resep kekinian yang membuat ayam goreng utuh lengkuas semakin lezat.

Resep ayam goreng utuh lengkuas juga gampang dibuat, lho. Kamu tidak usah ribet-ribet untuk memesan ayam goreng utuh lengkuas, sebab Kamu mampu menghidangkan ditempatmu. Bagi Kita yang akan membuatnya, berikut ini resep untuk membuat ayam goreng utuh lengkuas yang nikamat yang bisa Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam goreng utuh lengkuas:

1. Sediakan 1 ekor Ayam utuh
1. Ambil 1,5 ruas kunyit
1. Ambil 1 ons lengkuas muda parut / bsa d blender bareng bumbu2 yg lain
1. Ambil 8 bawang merah
1. Sediakan 6 bawang putih
1. Gunakan 1 sdm ketumbar
1. Gunakan 4 buah kemiri
1. Ambil 1/4 sdt jintan
1. Siapkan 2 batang sereh geprek
1. Gunakan 2 daun salam
1. Siapkan 1/2 bundar kecil gula merah
1. Siapkan 1 sdm asam jawa
1. Ambil secukupnya Air kelapa (kalau TDK ada,pake air biasa jg boleh)
1. Gunakan 1 sdt garam
1. Sediakan 1/4 sdt kaldu bubuk
1. Ambil 1/2 sdt gula


Haluskan bumbu-bumbu halus seperti yang sudah disebutkan. Salah satu Ikon kuliner Indonesia dari kota Bandung: Ayam Goreng Lengkuas. Sekilas mirip Ayam Goreng ditaburi serundeng dan serundeng ini berasal dari lengkuas yang diparut. Coba saja resep ayam goreng lengkuas yang satu ini. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam goreng utuh lengkuas:

1. Cuci bersih ayam,lalu blender smua bumbu2nya,siap kan presto lalu lumuri smua bumbu2nya di ayam tes rasa dan presto kurang Lbh 30 menit
1. Setelah 30 menit matikan kompor,dan buang uap dlm presto,setelah itu ayam bs di goreng sampai kecoklatan,terakhir saring bumbu nya dan goreng sampai ke coklatan,lalu taburi di atas ayam
1. Dan ayam goreng lengkuas siap di bawa utk oleh2👏👏..jgn lupa buatkan sambel bawang,dan bs jg di bawa air ungkepanya buat tabur kuah kuningnya,selamat mencoba


Bumbu lengkuas yang diparut, lalu dicampurkan dengan bumbu lumuran ayam yang lain dan digoreng bersama dengan daging ayam, akan menghasilkan masakan yang bercita rasa sedap dan gurih dengan aroma khas lengkuas. Ayam goreng lengkuas siap disajikan. instagram.com/tsaniwismono. Nah, itulah dia cara membuat ayam goreng lengkuas yang bisa dijadikan andalan untuk menu sajian harianmu. Selamat memasak ayam goreng lengkuas di rumah! Lihat juga resep Ayam Goreng Laos enak lainnya. 

Wah ternyata cara buat ayam goreng utuh lengkuas yang mantab sederhana ini mudah sekali ya! Semua orang bisa memasaknya. Resep ayam goreng utuh lengkuas Sangat sesuai sekali buat kalian yang sedang belajar memasak maupun untuk anda yang telah jago dalam memasak.

Apakah kamu tertarik mencoba membuat resep ayam goreng utuh lengkuas nikmat sederhana ini? Kalau kalian mau, mending kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, lantas bikin deh Resep ayam goreng utuh lengkuas yang mantab dan sederhana ini. Benar-benar gampang kan. 

Oleh karena itu, ketimbang kalian berfikir lama-lama, yuk kita langsung saja sajikan resep ayam goreng utuh lengkuas ini. Dijamin kalian gak akan nyesel sudah membuat resep ayam goreng utuh lengkuas lezat tidak ribet ini! Selamat mencoba dengan resep ayam goreng utuh lengkuas nikmat tidak ribet ini di rumah kalian masing-masing,oke!.

