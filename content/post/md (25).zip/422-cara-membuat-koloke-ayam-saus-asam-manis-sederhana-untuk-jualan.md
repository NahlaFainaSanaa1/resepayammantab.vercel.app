---
description: "Cara membuat Koloke Ayam Saus Asam Manis Sederhana Untuk Jualan"
title: "Cara membuat Koloke Ayam Saus Asam Manis Sederhana Untuk Jualan"
slug: 422-cara-membuat-koloke-ayam-saus-asam-manis-sederhana-untuk-jualan
date: 2021-02-13T21:21:55.904Z
image: https://img-global.cpcdn.com/recipes/74a830373b873967/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/74a830373b873967/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/74a830373b873967/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
author: Rosetta Hopkins
ratingvalue: 4.5
reviewcount: 9
recipeingredient:
- "300 gram dada filet potong dadu"
- "1 buah jeruk nipis ambil airnya"
- " Bahan marinasi"
- "2 sdm bawang putih bubuk"
- "1 sdt lada bubuk"
- " Bahan kering"
- "100 gram tepung bumbu ayam krispi"
- "100 gram terigu me maizena"
- "1/4 sdt baking powder"
- " Bahan basah"
- "1 buah putih telur"
- "100 ml air es"
- "3 sdm bahan kering"
- " Bahan saus asam manis"
- "2 buah wortel ukuran kecil dipotong korek api"
- "1 buah timun ukuran kecil dibuang isinya dipotong korek api"
- "1 buah tomat dibuang isinya dan di potong dadu"
- "1 buah paprika merah buang isinya dan dipotong dadu"
- "2 siung bawang putih"
- "1/2 siung bawang bombay irisiris"
- "1 siung bawang bombay iris melintang"
- "1 sdm kecap inggris saya ganti kecap asin"
- "10 sdm saus tomat me 2 sdm"
- "1/2 sdt lada bubuk"
- "1 sdt garam"
- "1 sdt gula pasir"
- "2 sdm saus sambal saya skip"
- " Cabai merah iris saya skip"
recipeinstructions:
- "Daging ayam yang sudah bersih, diberi bumbu marinasi. Aduk-aduk sampai rata, kemudian masukan kulkas selama 30 menit."
- "Siapkan bahan kering dan bahan basah."
- "Balurkan bahan kering pada potongan ayam, kemudian masukan ke dalam bahan basah, masukan kembali ke dalam bahan kering sambil dicubit-cubit ayamnya."
- "Goreng daging ayam menggunakan api sedang cenderung kecil. Goreng sampai kuning kecoklatan."
- "Langkah selanjutnya membuat saus asam manis. Irisan bawang putih lokal dan bawang bombay ditumis sampaomi harum."
- "Tambahkan wortel, timun, bawang bombay, paprika, tomat dan air. Aduk sampai rata. Masak sampai mendidih."
- "Cara menyajikan: letakan koloke ayam kemudian siram dengan saus asam manis. Koloke ayam saus asam manis sudah jadi, nikmat banget rasanya👍"
categories:
- Resep
tags:
- koloke
- ayam
- saus

katakunci: koloke ayam saus 
nutrition: 171 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Koloke Ayam Saus Asam Manis](https://img-global.cpcdn.com/recipes/74a830373b873967/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg)

Apabila kamu seorang ibu, menyuguhkan hidangan lezat pada famili merupakan hal yang memuaskan untuk kamu sendiri. Tugas seorang  wanita bukan saja mengerjakan pekerjaan rumah saja, namun anda pun wajib memastikan keperluan nutrisi terpenuhi dan juga santapan yang dimakan orang tercinta wajib mantab.

Di era  sekarang, kamu sebenarnya mampu mengorder olahan yang sudah jadi meski tanpa harus repot membuatnya dulu. Tetapi ada juga mereka yang selalu ingin menghidangkan yang terbaik bagi keluarganya. Karena, memasak yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai makanan kesukaan famili. 



Mungkinkah anda adalah salah satu penikmat koloke ayam saus asam manis?. Tahukah kamu, koloke ayam saus asam manis adalah makanan khas di Indonesia yang saat ini disenangi oleh setiap orang dari berbagai wilayah di Indonesia. Kita bisa membuat koloke ayam saus asam manis sendiri di rumah dan boleh dijadikan makanan kesukaanmu di hari libur.

Anda tidak usah bingung untuk mendapatkan koloke ayam saus asam manis, sebab koloke ayam saus asam manis mudah untuk didapatkan dan juga kamu pun boleh menghidangkannya sendiri di tempatmu. koloke ayam saus asam manis dapat dibuat memalui berbagai cara. Sekarang ada banyak banget resep kekinian yang membuat koloke ayam saus asam manis semakin lebih nikmat.

Resep koloke ayam saus asam manis juga sangat gampang dihidangkan, lho. Kamu jangan repot-repot untuk membeli koloke ayam saus asam manis, lantaran Anda dapat menghidangkan ditempatmu. Untuk Kalian yang mau mencobanya, inilah resep untuk membuat koloke ayam saus asam manis yang nikamat yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Koloke Ayam Saus Asam Manis:

1. Gunakan 300 gram dada filet potong dadu
1. Siapkan 1 buah jeruk nipis ambil airnya
1. Siapkan  Bahan marinasi
1. Sediakan 2 sdm bawang putih bubuk
1. Ambil 1 sdt lada bubuk
1. Sediakan  Bahan kering
1. Ambil 100 gram tepung bumbu ayam krispi
1. Ambil 100 gram terigu (me: maizena)
1. Siapkan 1/4 sdt baking powder
1. Siapkan  Bahan basah
1. Gunakan 1 buah putih telur
1. Sediakan 100 ml air es
1. Sediakan 3 sdm bahan kering
1. Siapkan  Bahan saus asam manis
1. Ambil 2 buah wortel ukuran kecil dipotong korek api
1. Ambil 1 buah timun ukuran kecil dibuang isinya, dipotong korek api
1. Ambil 1 buah tomat dibuang isinya dan di potong dadu
1. Siapkan 1 buah paprika merah buang isinya dan dipotong dadu
1. Ambil 2 siung bawang putih
1. Siapkan 1/2 siung bawang bombay iris-iris
1. Gunakan 1 siung bawang bombay iris melintang
1. Sediakan 1 sdm kecap inggris (saya ganti kecap asin)
1. Gunakan 10 sdm saus tomat (me: 2 sdm)
1. Sediakan 1/2 sdt lada bubuk
1. Siapkan 1 sdt garam
1. Ambil 1 sdt gula pasir
1. Gunakan 2 sdm saus sambal (saya skip)
1. Siapkan  Cabai merah iris (saya skip)




<!--inarticleads2-->

##### Cara membuat Koloke Ayam Saus Asam Manis:

1. Daging ayam yang sudah bersih, diberi bumbu marinasi. Aduk-aduk sampai rata, kemudian masukan kulkas selama 30 menit.
1. Siapkan bahan kering dan bahan basah.
1. Balurkan bahan kering pada potongan ayam, kemudian masukan ke dalam bahan basah, masukan kembali ke dalam bahan kering sambil dicubit-cubit ayamnya.
1. Goreng daging ayam menggunakan api sedang cenderung kecil. Goreng sampai kuning kecoklatan.
1. Langkah selanjutnya membuat saus asam manis. Irisan bawang putih lokal dan bawang bombay ditumis sampaomi harum.
1. Tambahkan wortel, timun, bawang bombay, paprika, tomat dan air. Aduk sampai rata. Masak sampai mendidih.
1. Cara menyajikan: letakan koloke ayam kemudian siram dengan saus asam manis. Koloke ayam saus asam manis sudah jadi, nikmat banget rasanya👍




Wah ternyata resep koloke ayam saus asam manis yang nikamt tidak rumit ini mudah banget ya! Anda Semua bisa memasaknya. Resep koloke ayam saus asam manis Cocok banget buat kamu yang baru akan belajar memasak atau juga untuk kalian yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba membikin resep koloke ayam saus asam manis enak tidak rumit ini? Kalau ingin, ayo kalian segera siapin alat dan bahan-bahannya, lalu buat deh Resep koloke ayam saus asam manis yang nikmat dan tidak rumit ini. Benar-benar gampang kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, hayo langsung aja buat resep koloke ayam saus asam manis ini. Dijamin kamu tiidak akan nyesel bikin resep koloke ayam saus asam manis mantab tidak ribet ini! Selamat mencoba dengan resep koloke ayam saus asam manis nikmat tidak ribet ini di tempat tinggal kalian sendiri,oke!.

