---
description: "Cara membuat Ayam Goreng Lengkuas yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Goreng Lengkuas yang lezat dan Mudah Dibuat"
slug: 152-cara-membuat-ayam-goreng-lengkuas-yang-lezat-dan-mudah-dibuat
date: 2021-01-16T20:36:49.930Z
image: https://img-global.cpcdn.com/recipes/c48f143666d486ec/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c48f143666d486ec/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c48f143666d486ec/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Eliza Martin
ratingvalue: 4.8
reviewcount: 4
recipeingredient:
- "750 gram ayam"
- "secukupnya Lengkuas parut"
- "secukupnya Air"
- "secukupnya Gula"
- "secukupnya Garam"
- "secukupnya Minyak goreng"
- "2 batang sereh geprek"
- "3 lembar daun salam"
- " Bumbu halus"
- "7 buah bawang merah"
- "4 siung bawang putih"
- "2 butir kemiri"
- "1 sdm ketumbar"
- "1/2 sdt kunyit"
- "2 ruas jari jahe"
- " Sambal tomat"
- "7 buah cabe rawit"
- "3 buah cabe keriting"
- "3 buah bawang merah"
- "2 buah bawang putih"
- "1 buah tomat ukuran kecil"
recipeinstructions:
- "Cuci bersih ayam. Siapkan semua bahan bahan. Parut lengkuas sesuai selera, semakin banyak semakin enak. Kira kira saya pakai kurang lebih 5 sdm lengkuas parut."
- "Tumis bumbu halus dan lengkuas parut dengan sedikit minyak. Tambahkan sereh geprek, daun salam, garam dan gula secukupnya. Tumis hingga matang dan tercium wangi."
- "Setelah itu masukkan ayam, aduk aduk sebentar hingga ayam terlumuri bumbu. Kemudian masukkan air untuk memasak ayam hingga matang."
- "Setelah ayam matang, goreng ayam di api yang sedang hingga berwarna kecoklatan. Setelah semua ayam tergoreng, jangan lupa goreng parutan lengkuas yang masih tersisa di bumbu rebusan. Sajikan ayam goreng lengkuas dengan sambal sesuai selera."
- "Sambal tomat : Goreng cabe, bawang merah, dan bawang putih. Setelah sedikit layu masukkan tomat. Aduk aduk dan goreng hingga matang. Kemudian ulek semuanya bersama dengan gula dan garam secukupnya"
categories:
- Resep
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 245 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/c48f143666d486ec/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, mempersiapkan masakan nikmat untuk keluarga tercinta merupakan suatu hal yang menyenangkan bagi kamu sendiri. Tanggung jawab seorang  wanita Tidak sekadar mengurus rumah saja, namun anda pun harus memastikan kebutuhan nutrisi tercukupi dan santapan yang disantap orang tercinta harus sedap.

Di masa  saat ini, kalian sebenarnya mampu membeli masakan yang sudah jadi walaupun tanpa harus repot membuatnya terlebih dahulu. Tapi banyak juga lho orang yang selalu ingin memberikan makanan yang terenak untuk keluarganya. Pasalnya, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga tercinta. 



Apakah anda seorang penikmat ayam goreng lengkuas?. Tahukah kamu, ayam goreng lengkuas adalah makanan khas di Indonesia yang sekarang digemari oleh kebanyakan orang dari berbagai wilayah di Indonesia. Kalian dapat menghidangkan ayam goreng lengkuas hasil sendiri di rumahmu dan dapat dijadikan hidangan favoritmu di akhir pekanmu.

Kita tidak perlu bingung untuk mendapatkan ayam goreng lengkuas, sebab ayam goreng lengkuas mudah untuk dicari dan juga anda pun boleh menghidangkannya sendiri di rumah. ayam goreng lengkuas bisa dibuat dengan berbagai cara. Kini pun sudah banyak banget cara kekinian yang menjadikan ayam goreng lengkuas semakin lebih mantap.

Resep ayam goreng lengkuas juga mudah sekali dihidangkan, lho. Anda tidak usah capek-capek untuk membeli ayam goreng lengkuas, tetapi Anda mampu menyajikan ditempatmu. Untuk Kita yang ingin mencobanya, di bawah ini adalah cara menyajikan ayam goreng lengkuas yang mantab yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Goreng Lengkuas:

1. Gunakan 750 gram ayam
1. Gunakan secukupnya Lengkuas parut
1. Gunakan secukupnya Air
1. Ambil secukupnya Gula
1. Ambil secukupnya Garam
1. Sediakan secukupnya Minyak goreng
1. Siapkan 2 batang sereh geprek
1. Sediakan 3 lembar daun salam
1. Sediakan  Bumbu halus
1. Ambil 7 buah bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 2 butir kemiri
1. Siapkan 1 sdm ketumbar
1. Gunakan 1/2 sdt kunyit
1. Ambil 2 ruas jari jahe
1. Siapkan  Sambal tomat
1. Sediakan 7 buah cabe rawit
1. Ambil 3 buah cabe keriting
1. Gunakan 3 buah bawang merah
1. Siapkan 2 buah bawang putih
1. Siapkan 1 buah tomat ukuran kecil




<!--inarticleads2-->

##### Cara menyiapkan Ayam Goreng Lengkuas:

1. Cuci bersih ayam. Siapkan semua bahan bahan. Parut lengkuas sesuai selera, semakin banyak semakin enak. Kira kira saya pakai kurang lebih 5 sdm lengkuas parut.
1. Tumis bumbu halus dan lengkuas parut dengan sedikit minyak. Tambahkan sereh geprek, daun salam, garam dan gula secukupnya. Tumis hingga matang dan tercium wangi.
1. Setelah itu masukkan ayam, aduk aduk sebentar hingga ayam terlumuri bumbu. Kemudian masukkan air untuk memasak ayam hingga matang.
1. Setelah ayam matang, goreng ayam di api yang sedang hingga berwarna kecoklatan. Setelah semua ayam tergoreng, jangan lupa goreng parutan lengkuas yang masih tersisa di bumbu rebusan. Sajikan ayam goreng lengkuas dengan sambal sesuai selera.
1. Sambal tomat : - Goreng cabe, bawang merah, dan bawang putih. Setelah sedikit layu masukkan tomat. Aduk aduk dan goreng hingga matang. Kemudian ulek semuanya bersama dengan gula dan garam secukupnya




Wah ternyata resep ayam goreng lengkuas yang mantab tidak rumit ini enteng banget ya! Anda Semua dapat menghidangkannya. Resep ayam goreng lengkuas Sangat sesuai banget buat anda yang baru akan belajar memasak ataupun juga untuk kalian yang telah pandai memasak.

Tertarik untuk mencoba membikin resep ayam goreng lengkuas lezat tidak rumit ini? Kalau kamu ingin, ayo kalian segera menyiapkan peralatan dan bahannya, lantas buat deh Resep ayam goreng lengkuas yang enak dan tidak rumit ini. Betul-betul gampang kan. 

Maka dari itu, daripada kita berlama-lama, ayo kita langsung saja sajikan resep ayam goreng lengkuas ini. Dijamin kamu tak akan nyesel membuat resep ayam goreng lengkuas mantab simple ini! Selamat berkreasi dengan resep ayam goreng lengkuas mantab tidak rumit ini di tempat tinggal sendiri,oke!.

