---
description: "Resep Rendang Ayam Sederhana dan Mudah Dibuat"
title: "Resep Rendang Ayam Sederhana dan Mudah Dibuat"
slug: 104-resep-rendang-ayam-sederhana-dan-mudah-dibuat
date: 2021-02-01T11:25:09.919Z
image: https://img-global.cpcdn.com/recipes/a237e1b4896a5917/680x482cq70/rendang-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a237e1b4896a5917/680x482cq70/rendang-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a237e1b4896a5917/680x482cq70/rendang-ayam-foto-resep-utama.jpg
author: Andrew McBride
ratingvalue: 4.4
reviewcount: 14
recipeingredient:
- "1/2 kg ayam"
- "1/2 butir kelapa parut"
- "200 ml santan kental"
- "600 ml santan encer"
- "2 lembar daun salam"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya penyedap rasa"
- "1 batang sereh geprek"
- "Secukupnya minyak utk menumis"
- " Bumbu halus "
- "2 buah cabai besar aku buang biji ya moms krn utk kakak dastan"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1/2 ruas kunyit"
- "2 butir kemiri"
- "1 sdt merica"
- "1 sdt ketumbar"
- "1/2 sdt jinten"
- "1/4 sdt pala"
recipeinstructions:
- "Sangrai kelapa hingga kering dan kecoklatan kemudian blender hingga halus."
- "Tumis bumbu halus, tambahkan daun salam dan sereh, tumis hingga harum."
- "Masukkan santan kental dan santan encer kemudian aduk terus hingga mendidih."
- "Masukkan ayam dan kelapa yg sudah dihaluskan tadi kemudian tambahkan garam, gula dan penyedap rasa. Masak hingga menyusut dan matang. Jgn lupa koreksi rasa."
- "Rendang ayam siap disajikan."
categories:
- Resep
tags:
- rendang
- ayam

katakunci: rendang ayam 
nutrition: 176 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dessert

---


![Rendang Ayam](https://img-global.cpcdn.com/recipes/a237e1b4896a5917/680x482cq70/rendang-ayam-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan olahan enak bagi keluarga tercinta adalah hal yang menyenangkan bagi kita sendiri. Peran seorang  wanita Tidak sekedar menjaga rumah saja, tapi kamu pun harus memastikan keperluan nutrisi tercukupi dan juga santapan yang dimakan keluarga tercinta mesti menggugah selera.

Di zaman  sekarang, kamu memang bisa membeli olahan yang sudah jadi tanpa harus repot mengolahnya dahulu. Tapi banyak juga orang yang selalu mau memberikan makanan yang terlezat untuk orang tercintanya. Sebab, memasak yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai selera keluarga. 



Mungkinkah kamu salah satu penggemar rendang ayam?. Tahukah kamu, rendang ayam adalah sajian khas di Indonesia yang kini disukai oleh orang-orang di hampir setiap daerah di Indonesia. Kalian bisa membuat rendang ayam sendiri di rumah dan boleh dijadikan camilan favorit di hari libur.

Kamu tidak perlu bingung jika kamu ingin menyantap rendang ayam, karena rendang ayam tidak sulit untuk dicari dan kita pun dapat memasaknya sendiri di tempatmu. rendang ayam boleh diolah dengan beragam cara. Kini sudah banyak cara modern yang menjadikan rendang ayam semakin enak.

Resep rendang ayam pun gampang dibuat, lho. Kalian tidak perlu ribet-ribet untuk membeli rendang ayam, lantaran Kamu bisa menyiapkan di rumahmu. Bagi Kita yang hendak menyajikannya, berikut resep untuk menyajikan rendang ayam yang enak yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Rendang Ayam:

1. Sediakan 1/2 kg ayam
1. Ambil 1/2 butir kelapa parut
1. Ambil 200 ml santan kental
1. Siapkan 600 ml santan encer
1. Sediakan 2 lembar daun salam
1. Ambil Secukupnya garam
1. Siapkan Secukupnya gula
1. Siapkan Secukupnya penyedap rasa
1. Ambil 1 batang sereh (geprek)
1. Gunakan Secukupnya minyak utk menumis
1. Ambil  Bumbu halus :
1. Siapkan 2 buah cabai besar (aku buang biji ya moms krn utk kakak dastan)
1. Sediakan 5 siung bawang merah
1. Sediakan 2 siung bawang putih
1. Ambil 1 ruas jahe
1. Sediakan 1 ruas lengkuas
1. Siapkan 1/2 ruas kunyit
1. Sediakan 2 butir kemiri
1. Ambil 1 sdt merica
1. Gunakan 1 sdt ketumbar
1. Ambil 1/2 sdt jinten
1. Ambil 1/4 sdt pala




<!--inarticleads2-->

##### Cara membuat Rendang Ayam:

1. Sangrai kelapa hingga kering dan kecoklatan kemudian blender hingga halus.
1. Tumis bumbu halus, tambahkan daun salam dan sereh, tumis hingga harum.
1. Masukkan santan kental dan santan encer kemudian aduk terus hingga mendidih.
1. Masukkan ayam dan kelapa yg sudah dihaluskan tadi kemudian tambahkan garam, gula dan penyedap rasa. Masak hingga menyusut dan matang. Jgn lupa koreksi rasa.
1. Rendang ayam siap disajikan.




Wah ternyata cara buat rendang ayam yang nikamt sederhana ini enteng sekali ya! Kita semua mampu membuatnya. Cara buat rendang ayam Sesuai sekali buat kamu yang baru akan belajar memasak maupun juga bagi kalian yang telah ahli memasak.

Apakah kamu ingin mencoba membuat resep rendang ayam nikmat sederhana ini? Kalau kalian ingin, mending kamu segera buruan siapkan peralatan dan bahannya, lantas buat deh Resep rendang ayam yang lezat dan tidak ribet ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kamu diam saja, hayo kita langsung sajikan resep rendang ayam ini. Dijamin kamu tak akan nyesel membuat resep rendang ayam enak tidak rumit ini! Selamat mencoba dengan resep rendang ayam enak sederhana ini di tempat tinggal masing-masing,ya!.

