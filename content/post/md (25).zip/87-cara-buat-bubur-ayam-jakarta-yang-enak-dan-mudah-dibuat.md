---
description: "Cara buat Bubur Ayam Jakarta yang enak dan Mudah Dibuat"
title: "Cara buat Bubur Ayam Jakarta yang enak dan Mudah Dibuat"
slug: 87-cara-buat-bubur-ayam-jakarta-yang-enak-dan-mudah-dibuat
date: 2021-05-14T09:16:50.409Z
image: https://img-global.cpcdn.com/recipes/3cfe51eba211f6a2/680x482cq70/bubur-ayam-jakarta-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3cfe51eba211f6a2/680x482cq70/bubur-ayam-jakarta-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3cfe51eba211f6a2/680x482cq70/bubur-ayam-jakarta-foto-resep-utama.jpg
author: Daniel Ross
ratingvalue: 4.9
reviewcount: 7
recipeingredient:
- " Bahan bubur "
- "2 centong nasi"
- "1 1/2 gelas air"
- "1/2 sdt garam"
- "Sedikit penyedap rasa"
- " Bahan kaldu ayam kuah kuning "
- "2 potongan dada ayam"
- "2 batang serai"
- "3 lembar daun jeruk"
- "2 lembar daun salam"
- "Irisan daun bawang"
- " Minyak goreng untuk menumis"
- " Bumbu halus kuah kuning "
- "6 siung bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "1 sdm ketumbar bubuk"
- "1/2 sdm kunyit bubuk"
- " Bahan pelengkap"
- " Kerupuk"
- " Ayam suwir"
- " Kacang kedelai goreng"
- " Bawang goreng"
- "iris Daun bawangseledri"
- " Cakwe"
- " Sambal"
recipeinstructions:
- "Siapkan air (300ml), Masukkan nasi, masak sampai air habis sambil sering2 diaduk. Beri sedikit garam dan sedikit penyedap rasa. Aduk sampai air menyusut."
- "Membuat kuah kuning : tumis bumbu halus, masukkan daun salam, serai, dan daun jeruk. Tumis sampai harum. Masukkan ayam, tumis lagi sebentar, tambahkan air, garam, dan penyedap rasa ayam. Masak sampai ayam matang &amp; empuk. Tiriskan ayam. Ambil daun salam, daun jeruk, dan serainya. Masukkan irisan daun bawang ke dalam kuah kuning."
- "Panaskan wajan. Goreng ayamnya. Lalu suwir-suwir ayamnya."
- "Sambal : rebus beberapa cabai dan 1/2 siung bawang putih, lalu ulek sampai halus. Beri 2 tetes cuka (optional) dan sedikit air."
- "Penyajiannya : ambil beberapa centong bubur, beri kecap asin, kecap manis, tuang kuah kuning, taburi bawang goreng, irisan seledri, kacang kedelai goreng, ayam suwir, irisan cakwe, dan kerupuk. Lengkapi juga dengan sambalnya."
categories:
- Resep
tags:
- bubur
- ayam
- jakarta

katakunci: bubur ayam jakarta 
nutrition: 294 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dinner

---


![Bubur Ayam Jakarta](https://img-global.cpcdn.com/recipes/3cfe51eba211f6a2/680x482cq70/bubur-ayam-jakarta-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan masakan mantab pada orang tercinta merupakan suatu hal yang menyenangkan untuk anda sendiri. Kewajiban seorang istri bukan sekedar mengurus rumah saja, tapi kamu juga wajib menyediakan kebutuhan gizi tercukupi dan olahan yang disantap orang tercinta harus sedap.

Di zaman  sekarang, kalian memang mampu memesan olahan praktis walaupun tidak harus ribet membuatnya lebih dulu. Tapi ada juga orang yang selalu ingin memberikan hidangan yang terenak untuk keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai selera orang tercinta. 



Mungkinkah anda seorang penikmat bubur ayam jakarta?. Tahukah kamu, bubur ayam jakarta merupakan hidangan khas di Nusantara yang sekarang disenangi oleh kebanyakan orang di hampir setiap daerah di Nusantara. Kalian bisa menghidangkan bubur ayam jakarta sendiri di rumah dan boleh jadi santapan favorit di hari liburmu.

Kita tidak perlu bingung jika kamu ingin mendapatkan bubur ayam jakarta, lantaran bubur ayam jakarta gampang untuk didapatkan dan juga kamu pun boleh membuatnya sendiri di rumah. bubur ayam jakarta boleh dibuat memalui beraneka cara. Kini pun ada banyak sekali resep kekinian yang membuat bubur ayam jakarta semakin lebih lezat.

Resep bubur ayam jakarta juga gampang dibuat, lho. Anda jangan repot-repot untuk membeli bubur ayam jakarta, tetapi Kita mampu menyiapkan ditempatmu. Untuk Anda yang hendak menyajikannya, di bawah ini adalah resep untuk menyajikan bubur ayam jakarta yang nikamat yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Bubur Ayam Jakarta:

1. Siapkan  Bahan bubur :
1. Gunakan 2 centong nasi
1. Sediakan 1 1/2 gelas air
1. Sediakan 1/2 sdt garam
1. Ambil Sedikit penyedap rasa
1. Ambil  Bahan kaldu ayam kuah kuning :
1. Sediakan 2 potongan dada ayam
1. Sediakan 2 batang serai
1. Gunakan 3 lembar daun jeruk
1. Ambil 2 lembar daun salam
1. Sediakan Irisan daun bawang
1. Gunakan  Minyak goreng untuk menumis
1. Gunakan  Bumbu halus kuah kuning :
1. Sediakan 6 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Siapkan 2 butir kemiri
1. Sediakan 1 sdm ketumbar bubuk
1. Gunakan 1/2 sdm kunyit bubuk
1. Sediakan  Bahan pelengkap:
1. Ambil  Kerupuk
1. Gunakan  Ayam suwir
1. Siapkan  Kacang kedelai goreng
1. Gunakan  Bawang goreng
1. Gunakan iris Daun bawang/seledri
1. Siapkan  Cakwe
1. Gunakan  Sambal




<!--inarticleads2-->

##### Cara membuat Bubur Ayam Jakarta:

1. Siapkan air (300ml), Masukkan nasi, masak sampai air habis sambil sering2 diaduk. Beri sedikit garam dan sedikit penyedap rasa. Aduk sampai air menyusut.
1. Membuat kuah kuning : tumis bumbu halus, masukkan daun salam, serai, dan daun jeruk. Tumis sampai harum. Masukkan ayam, tumis lagi sebentar, tambahkan air, garam, dan penyedap rasa ayam. Masak sampai ayam matang &amp; empuk. Tiriskan ayam. Ambil daun salam, daun jeruk, dan serainya. Masukkan irisan daun bawang ke dalam kuah kuning.
1. Panaskan wajan. Goreng ayamnya. Lalu suwir-suwir ayamnya.
1. Sambal : rebus beberapa cabai dan 1/2 siung bawang putih, lalu ulek sampai halus. Beri 2 tetes cuka (optional) dan sedikit air.
1. Penyajiannya : ambil beberapa centong bubur, beri kecap asin, kecap manis, tuang kuah kuning, taburi bawang goreng, irisan seledri, kacang kedelai goreng, ayam suwir, irisan cakwe, dan kerupuk. Lengkapi juga dengan sambalnya.




Wah ternyata cara membuat bubur ayam jakarta yang lezat tidak rumit ini enteng sekali ya! Anda Semua mampu memasaknya. Resep bubur ayam jakarta Sangat sesuai banget untuk anda yang sedang belajar memasak ataupun bagi kalian yang sudah lihai dalam memasak.

Apakah kamu ingin mencoba membuat resep bubur ayam jakarta mantab sederhana ini? Kalau kalian ingin, ayo kamu segera siapkan peralatan dan bahan-bahannya, lantas buat deh Resep bubur ayam jakarta yang enak dan simple ini. Betul-betul taidak sulit kan. 

Maka, daripada kita berfikir lama-lama, ayo kita langsung bikin resep bubur ayam jakarta ini. Dijamin kamu tak akan menyesal membuat resep bubur ayam jakarta mantab simple ini! Selamat mencoba dengan resep bubur ayam jakarta enak tidak ribet ini di rumah kalian masing-masing,ya!.

