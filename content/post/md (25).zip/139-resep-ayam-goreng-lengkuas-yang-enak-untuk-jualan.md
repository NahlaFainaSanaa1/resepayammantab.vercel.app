---
description: "Resep Ayam Goreng Lengkuas yang enak Untuk Jualan"
title: "Resep Ayam Goreng Lengkuas yang enak Untuk Jualan"
slug: 139-resep-ayam-goreng-lengkuas-yang-enak-untuk-jualan
date: 2021-05-17T03:02:28.510Z
image: https://img-global.cpcdn.com/recipes/264a5f0587490a18/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/264a5f0587490a18/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/264a5f0587490a18/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Michael Paul
ratingvalue: 4.4
reviewcount: 3
recipeingredient:
- "1 kg ayam potong sesuai selera"
- "1 buah jeruk nipis peras di ayamnya"
- "2 ons lengkuas parut"
- "3 lembar daun jeruk"
- "4 lembar daun salam"
- "1 batang serai memarkan"
- "1 sdm bubuk kaldu ayam me pakai kaldu jamur"
- "1 sdt lada bubuk"
- "600 ml air untuk merebus"
- "Secukupnya garam"
- " Bumbu Halus me blender"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas kunyit"
- "3 cm jahe"
- "2 batang serai ambil bagian putihnya"
- "2 sdm ketumbar sangrai"
- "5 butir kemiri sangrai"
recipeinstructions:
- "Cuci ayam hingga bersih lalu berikan perasan jeruk nipis"
- "Tumis semua bumbu, lalu masukkan lengkuas parut hingga harum"
- "Masukkan ayam, aduk²"
- "Masukkan air ungkep hingga air surut semua. Note: selama diungkep baiknya pakai api kecil dan diaduk beberapa kali. Agar bumbu dapat tambah meresap. Jangan lupa cek rasa"
- "Setelah ungkepan ayam selesai, ayam bisa langsung digoreng atau bisa di simpan di kulkas"
- "Goreng ayam hingga berwarna coklat.  Note: menggoreng ayam dan lengkuasnya dipisah ya. Karna kalau digoreng berbarengan lengkuasnya akan mateng duluan"
- "Selamat mencoba :)"
categories:
- Resep
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 291 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/264a5f0587490a18/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Jika kamu seorang wanita, menyediakan masakan sedap pada keluarga tercinta merupakan suatu hal yang menggembirakan untuk kamu sendiri. Tugas seorang istri bukan sekedar menangani rumah saja, tapi kamu juga harus memastikan kebutuhan nutrisi terpenuhi dan masakan yang disantap anak-anak mesti menggugah selera.

Di zaman  sekarang, kamu sebenarnya mampu mengorder panganan instan tidak harus ribet membuatnya dulu. Namun banyak juga mereka yang memang ingin memberikan hidangan yang terbaik untuk keluarganya. Sebab, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan makanan kesukaan famili. 

Ayam Goreng Lengkuas is a recipe originally from Sumatra region. I really love Padang, food (West Sumatra) and this chicken is one of the lists. And since there is no Padang restaurant here, I decided to make my own Padang menu for our lunch.

Apakah anda merupakan salah satu penikmat ayam goreng lengkuas?. Asal kamu tahu, ayam goreng lengkuas adalah sajian khas di Indonesia yang kini digemari oleh banyak orang dari hampir setiap wilayah di Indonesia. Kalian bisa membuat ayam goreng lengkuas sendiri di rumahmu dan pasti jadi makanan favoritmu di akhir pekanmu.

Anda tidak usah bingung untuk menyantap ayam goreng lengkuas, sebab ayam goreng lengkuas tidak sulit untuk ditemukan dan kamu pun boleh membuatnya sendiri di rumah. ayam goreng lengkuas bisa dimasak dengan berbagai cara. Saat ini telah banyak sekali resep modern yang membuat ayam goreng lengkuas semakin lebih mantap.

Resep ayam goreng lengkuas pun sangat gampang untuk dibikin, lho. Kamu tidak perlu ribet-ribet untuk memesan ayam goreng lengkuas, lantaran Kita bisa membuatnya di rumah sendiri. Untuk Kamu yang akan menyajikannya, di bawah ini adalah cara untuk menyajikan ayam goreng lengkuas yang enak yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Goreng Lengkuas:

1. Gunakan 1 kg ayam (potong sesuai selera)
1. Siapkan 1 buah jeruk nipis (peras di ayamnya)
1. Sediakan 2 ons lengkuas parut
1. Gunakan 3 lembar daun jeruk
1. Sediakan 4 lembar daun salam
1. Ambil 1 batang serai (memarkan)
1. Siapkan 1 sdm bubuk kaldu ayam (me: pakai kaldu jamur)
1. Siapkan 1 sdt lada bubuk
1. Sediakan 600 ml air (untuk merebus)
1. Sediakan Secukupnya garam
1. Siapkan  Bumbu Halus (me: blender)
1. Gunakan 4 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Sediakan 1 ruas kunyit
1. Gunakan 3 cm jahe
1. Siapkan 2 batang serai, ambil bagian putihnya
1. Siapkan 2 sdm ketumbar (sangrai)
1. Gunakan 5 butir kemiri (sangrai)


Asal: Bandung. #ayamgorenglengkuas #resepayamlengkoas #indoculinairehunterVideo tentang cara membuat ayam goreng lengkuas yang gurih banget seperti di rumah makan Padang. Perghh nanti masa kunyah ayam goreng lengkuas tu kita dapat rasa lengkuas yang sedap. Memang sedap di dalam, rangup di luar masakan ni. Sesuai di makan untuk segenap lapisan umur. 

<!--inarticleads2-->

##### Cara membuat Ayam Goreng Lengkuas:

1. Cuci ayam hingga bersih lalu berikan perasan jeruk nipis
1. Tumis semua bumbu, lalu masukkan lengkuas parut hingga harum
1. Masukkan ayam, aduk²
1. Masukkan air ungkep hingga air surut semua. - Note: selama diungkep baiknya pakai api kecil dan diaduk beberapa kali. Agar bumbu dapat tambah meresap. Jangan lupa cek rasa
1. Setelah ungkepan ayam selesai, ayam bisa langsung digoreng atau bisa di simpan di kulkas
1. Goreng ayam hingga berwarna coklat.  - Note: menggoreng ayam dan lengkuasnya dipisah ya. Karna kalau digoreng berbarengan lengkuasnya akan mateng duluan
1. Selamat mencoba :)


Tak kira muda, tua atau kanak-kanak. Pasti akan menggemari ayam yang digoreng dengan lengkuas ni. Kalau tak percaya cuba la dulu baru tahu. Fimela.com, Jakarta Mau menikmati ayam goreng lengkuas yang enak? Dengan bumbu sederhana kita sudah bisa menikmati ayam lengkuas yang sedap. 

Wah ternyata cara buat ayam goreng lengkuas yang mantab sederhana ini mudah sekali ya! Anda Semua bisa mencobanya. Resep ayam goreng lengkuas Sangat cocok banget buat kita yang baru mau belajar memasak ataupun juga untuk anda yang sudah jago dalam memasak.

Apakah kamu mau mulai mencoba membuat resep ayam goreng lengkuas nikmat tidak ribet ini? Kalau mau, mending kamu segera buruan siapin alat dan bahannya, lalu buat deh Resep ayam goreng lengkuas yang mantab dan sederhana ini. Sungguh taidak sulit kan. 

Jadi, daripada kita diam saja, ayo kita langsung sajikan resep ayam goreng lengkuas ini. Dijamin kamu tiidak akan nyesel bikin resep ayam goreng lengkuas mantab sederhana ini! Selamat berkreasi dengan resep ayam goreng lengkuas enak tidak rumit ini di rumah kalian sendiri,ya!.

