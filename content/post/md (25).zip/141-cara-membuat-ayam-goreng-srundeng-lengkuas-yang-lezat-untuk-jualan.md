---
description: "Cara membuat Ayam goreng srundeng lengkuas yang lezat Untuk Jualan"
title: "Cara membuat Ayam goreng srundeng lengkuas yang lezat Untuk Jualan"
slug: 141-cara-membuat-ayam-goreng-srundeng-lengkuas-yang-lezat-untuk-jualan
date: 2021-03-19T18:42:35.263Z
image: https://img-global.cpcdn.com/recipes/adb84bbc24f43e2e/680x482cq70/ayam-goreng-srundeng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/adb84bbc24f43e2e/680x482cq70/ayam-goreng-srundeng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/adb84bbc24f43e2e/680x482cq70/ayam-goreng-srundeng-lengkuas-foto-resep-utama.jpg
author: Bruce Zimmerman
ratingvalue: 4.5
reviewcount: 7
recipeingredient:
- "1/2 kg dada ayam"
- "1/4 kg kelapa parut"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "1 sdt ketumbar bubuk"
- "1/2 sdt kunyit bubuk"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1/2 sdt merica bubuk"
- "100 gr lengkuas di parut"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "2 batang sere"
- "1 sdt garam"
- "1/2 sdt penyedap rasa ayam"
recipeinstructions:
- "Rebus ayam sampai matang, sisihkan"
- "Blender bumbu halus lalu tumis sampai matang masukkan daun salam dan daun jeruk dan batang sere, dan lengkuas yg sudah diparut tambah air sedikit, tambahkan garam dan penyedap. tunggu sampai mendidih"
- "Lalu masukkan ayam tambahkan air sampai ayam terendam, tunggu sampai mendidih"
- "Lalu masukkan parutan kelapa, tunggu sampai air menyerap semua"
- "Pisahkan ayam dan serundeng, goreng ayam sampai matang, lalu masukkan serundeng, goreng sampai serundeng matang."
categories:
- Resep
tags:
- ayam
- goreng
- srundeng

katakunci: ayam goreng srundeng 
nutrition: 111 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam goreng srundeng lengkuas](https://img-global.cpcdn.com/recipes/adb84bbc24f43e2e/680x482cq70/ayam-goreng-srundeng-lengkuas-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan masakan nikmat bagi keluarga tercinta adalah suatu hal yang mengasyikan untuk kita sendiri. Kewajiban seorang ibu bukan cuman mengurus rumah saja, namun anda juga wajib menyediakan keperluan nutrisi tercukupi dan juga panganan yang disantap anak-anak mesti nikmat.

Di era  saat ini, kita sebenarnya mampu membeli santapan jadi tanpa harus repot mengolahnya dahulu. Tapi ada juga mereka yang selalu ingin memberikan hidangan yang terbaik bagi orang tercintanya. Sebab, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan selera keluarga tercinta. 

Kalau biasanya serundeng terbuat dari parutan kelapa, namun pada ayam goreng ini menggunakan lengkuas sebagai serundengnya. Lengkuas diparut seperti kelapa kemudian dicampurkan kedalam bumbu-bumbu rempah lainnya. Tapi siapa sangka, ayam goreng yang bertabur kremesan ini terbuat dari parutan lengkuas yang dimasak sedemikian rupa sehingga memiliki citarasa gurih yang menggoda selera makan.

Apakah kamu seorang penggemar ayam goreng srundeng lengkuas?. Tahukah kamu, ayam goreng srundeng lengkuas adalah sajian khas di Nusantara yang saat ini digemari oleh kebanyakan orang dari berbagai tempat di Nusantara. Anda dapat membuat ayam goreng srundeng lengkuas sendiri di rumahmu dan boleh dijadikan makanan kesukaanmu di hari libur.

Kamu tak perlu bingung jika kamu ingin memakan ayam goreng srundeng lengkuas, karena ayam goreng srundeng lengkuas gampang untuk didapatkan dan anda pun boleh membuatnya sendiri di tempatmu. ayam goreng srundeng lengkuas bisa dibuat memalui beraneka cara. Kini pun sudah banyak sekali cara modern yang menjadikan ayam goreng srundeng lengkuas semakin lezat.

Resep ayam goreng srundeng lengkuas pun gampang dibikin, lho. Anda tidak perlu ribet-ribet untuk membeli ayam goreng srundeng lengkuas, tetapi Kita dapat membuatnya ditempatmu. Bagi Kalian yang mau mencobanya, berikut cara untuk menyajikan ayam goreng srundeng lengkuas yang lezat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam goreng srundeng lengkuas:

1. Ambil 1/2 kg dada ayam
1. Siapkan 1/4 kg kelapa parut
1. Siapkan 8 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Siapkan 1 sdt ketumbar bubuk
1. Siapkan 1/2 sdt kunyit bubuk
1. Ambil 1 ruas jahe
1. Sediakan 1 ruas lengkuas
1. Ambil 1/2 sdt merica bubuk
1. Siapkan 100 gr lengkuas (di parut)
1. Gunakan 2 lembar daun salam
1. Ambil 2 lembar daun jeruk
1. Ambil 2 batang sere
1. Gunakan 1 sdt garam
1. Ambil 1/2 sdt penyedap rasa ayam


Simpan ke bagian favorit Tersimpan di bagian favorit. Ayam goreng memang menjadi salah satu menu hidangan favorit, baik bagi anak-anak maupun orang dewasa. Tidak heran, daging ayam yang kenyal dan nikmat itu memang paling enak disajikan saat masih panas-panas, apalagi kalau ada bumbu kremesannya yang menambah cita rasa. Bernama ayam goreng serundeng, ayam ini di olah dengan bumbu halus rempah ayam goreng sederhana. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam goreng srundeng lengkuas:

1. Rebus ayam sampai matang, sisihkan
1. Blender bumbu halus lalu tumis sampai matang masukkan daun salam dan daun jeruk dan batang sere, dan lengkuas yg sudah diparut tambah air sedikit, tambahkan garam dan penyedap. tunggu sampai mendidih
1. Lalu masukkan ayam tambahkan air sampai ayam terendam, tunggu sampai mendidih
1. Lalu masukkan parutan kelapa, tunggu sampai air menyerap semua
1. Pisahkan ayam dan serundeng, goreng ayam sampai matang, lalu masukkan serundeng, goreng sampai serundeng matang.


Sajikan ayam serundeng kelapa lengkuas dengan taburan kelapa garing di atasnya. RESEP AYAM LAOS/LENGKUAS &amp; SRUNDENG REMPAH. ayam dengan sensasi gurih &amp; taburan srundeng rempah sangat. Masak ayam goreng di rumah tapi rasa gak kalah sama Resto? Cara Membuat Ayam Goreng Serundeng: Cuci paha ayam hingga bersih, lalu tiriskan. Haluskan semua bahan bumbu menggunakan blender hingga halus, jika perlu tambahkan sedikit minyak goreng agar memudahkan proses penghancuran bumbu. 

Wah ternyata cara buat ayam goreng srundeng lengkuas yang mantab simple ini enteng banget ya! Kamu semua dapat mencobanya. Cara buat ayam goreng srundeng lengkuas Cocok sekali untuk anda yang baru belajar memasak maupun juga untuk kamu yang telah pandai dalam memasak.

Apakah kamu ingin mencoba membuat resep ayam goreng srundeng lengkuas lezat tidak ribet ini? Kalau kalian ingin, ayo kamu segera menyiapkan alat-alat dan bahannya, lantas bikin deh Resep ayam goreng srundeng lengkuas yang enak dan tidak ribet ini. Sangat gampang kan. 

Oleh karena itu, ketimbang kalian berlama-lama, ayo kita langsung hidangkan resep ayam goreng srundeng lengkuas ini. Dijamin anda gak akan nyesel sudah bikin resep ayam goreng srundeng lengkuas mantab sederhana ini! Selamat mencoba dengan resep ayam goreng srundeng lengkuas nikmat simple ini di rumah kalian sendiri,oke!.

