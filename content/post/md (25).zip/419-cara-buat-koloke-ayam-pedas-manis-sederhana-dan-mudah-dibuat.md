---
description: "Cara buat Koloke ayam pedas manis Sederhana dan Mudah Dibuat"
title: "Cara buat Koloke ayam pedas manis Sederhana dan Mudah Dibuat"
slug: 419-cara-buat-koloke-ayam-pedas-manis-sederhana-dan-mudah-dibuat
date: 2021-01-08T14:21:54.324Z
image: https://img-global.cpcdn.com/recipes/d195120ad66861d7/680x482cq70/koloke-ayam-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d195120ad66861d7/680x482cq70/koloke-ayam-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d195120ad66861d7/680x482cq70/koloke-ayam-pedas-manis-foto-resep-utama.jpg
author: Wayne Townsend
ratingvalue: 5
reviewcount: 5
recipeingredient:
- "250 gr dada ayam filet"
- " Bumbu marinasi"
- "2 bwg putih"
- "1/2 sdt garam"
- " Bahan kering"
- "120 grm terigu"
- "80 gr tpung bumbu sajiku 1scht"
- "1/4 sdt bking powder"
- " Bahan basah"
- " Putih telur dr 1btr telur"
- "1-2 sdm bhn kering"
- "100 ml air dingin"
- " Bahan saus"
- "2 bwgputih haluskn"
- "2 cabe galak iris"
- "300 ml Air"
- " Saus cabe 1sdk sayursesuai selera"
- "1/2 sdt Gulapasir"
- "1/2 sdt Garam"
- " Lada sckupnya"
- " Bwg bombay"
- " Wortel dan timun iris korek"
recipeinstructions:
- "Cuci brsih aym lalu dibumbui marinasi diamkn d kulkas kira 30mnt"
- "Campur bhn kering. Dan bahan basah."
- "Masukn ayam tdi ke bhan kering lalu celup ke bahan basah lalu masukn ke bhan kering lg smbil sdikit dicubit dan tekan"
- "Goreng smpai keemasan"
- "Siapkan bumbu dan iris bahan pelengkap"
- "Tumis baput lalu masukan cabe iris lalu kasih air. Masukan saus bwg bombay iris lada garam dan gula.koreksi rasa ya. Bru masukan timun wortel. Maaf gak pake nanas"
- "Sajikan"
categories:
- Resep
tags:
- koloke
- ayam
- pedas

katakunci: koloke ayam pedas 
nutrition: 300 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert

---


![Koloke ayam pedas manis](https://img-global.cpcdn.com/recipes/d195120ad66861d7/680x482cq70/koloke-ayam-pedas-manis-foto-resep-utama.jpg)

Apabila kalian seorang ibu, menyuguhkan masakan sedap untuk keluarga adalah hal yang memuaskan bagi kita sendiri. Tugas seorang  wanita Tidak saja menjaga rumah saja, tapi kamu juga wajib menyediakan keperluan nutrisi tercukupi dan santapan yang disantap anak-anak wajib menggugah selera.

Di masa  sekarang, kamu memang dapat membeli masakan siap saji walaupun tanpa harus repot membuatnya terlebih dahulu. Tapi ada juga lho mereka yang selalu ingin menyajikan yang terlezat untuk orang tercintanya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penikmat koloke ayam pedas manis?. Tahukah kamu, koloke ayam pedas manis merupakan sajian khas di Indonesia yang kini disukai oleh orang-orang di hampir setiap daerah di Nusantara. Kita bisa memasak koloke ayam pedas manis sendiri di rumahmu dan boleh dijadikan makanan kegemaranmu di akhir pekanmu.

Kita tidak perlu bingung untuk mendapatkan koloke ayam pedas manis, sebab koloke ayam pedas manis sangat mudah untuk didapatkan dan juga kita pun dapat mengolahnya sendiri di rumah. koloke ayam pedas manis bisa dimasak dengan beraneka cara. Kini pun ada banyak sekali resep kekinian yang menjadikan koloke ayam pedas manis semakin lebih lezat.

Resep koloke ayam pedas manis juga sangat gampang untuk dibuat, lho. Anda jangan ribet-ribet untuk membeli koloke ayam pedas manis, karena Kamu mampu membuatnya di rumah sendiri. Untuk Kita yang ingin menyajikannya, dibawah ini merupakan resep membuat koloke ayam pedas manis yang mantab yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Koloke ayam pedas manis:

1. Ambil 250 gr dada ayam filet
1. Gunakan  Bumbu marinasi
1. Siapkan 2 bwg putih
1. Sediakan 1/2 sdt garam
1. Siapkan  Bahan kering
1. Siapkan 120 grm terigu
1. Sediakan 80 gr tpung bumbu sajiku (1scht)
1. Gunakan 1/4 sdt bking powder
1. Siapkan  Bahan basah
1. Gunakan  Putih telur dr 1btr telur
1. Siapkan 1-2 sdm bhn kering
1. Gunakan 100 ml air dingin
1. Sediakan  Bahan saus
1. Siapkan 2 &#39;bwgputih haluskn
1. Ambil 2 &#39;cabe galak iris
1. Siapkan 300 ml Air
1. Ambil  Saus cabe 1sdk sayur/sesuai selera
1. Siapkan 1/2 sdt Gulapasir
1. Ambil 1/2 sdt Garam
1. Siapkan  Lada sckupnya
1. Sediakan  Bwg bombay
1. Ambil  Wortel dan timun iris korek




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Koloke ayam pedas manis:

1. Cuci brsih aym lalu dibumbui marinasi diamkn d kulkas kira 30mnt
1. Campur bhn kering. Dan bahan basah.
1. Masukn ayam tdi ke bhan kering lalu celup ke bahan basah lalu masukn ke bhan kering lg smbil sdikit dicubit dan tekan
1. Goreng smpai keemasan
1. Siapkan bumbu dan iris bahan pelengkap
1. Tumis baput lalu masukan cabe iris lalu kasih air. Masukan saus bwg bombay iris lada garam dan gula.koreksi rasa ya. Bru masukan timun wortel. Maaf gak pake nanas
1. Sajikan




Ternyata cara buat koloke ayam pedas manis yang lezat sederhana ini mudah banget ya! Anda Semua dapat membuatnya. Cara buat koloke ayam pedas manis Sangat sesuai sekali untuk anda yang baru mau belajar memasak ataupun bagi anda yang sudah lihai dalam memasak.

Tertarik untuk mencoba membuat resep koloke ayam pedas manis enak simple ini? Kalau anda ingin, mending kamu segera buruan menyiapkan peralatan dan bahannya, setelah itu buat deh Resep koloke ayam pedas manis yang lezat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Maka, ketimbang kamu diam saja, ayo kita langsung saja sajikan resep koloke ayam pedas manis ini. Pasti anda tak akan menyesal membuat resep koloke ayam pedas manis enak tidak rumit ini! Selamat berkreasi dengan resep koloke ayam pedas manis enak tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

