---
description: "Resep Rica Rica pedas ayam ras/merah yang nikmat dan Mudah Dibuat"
title: "Resep Rica Rica pedas ayam ras/merah yang nikmat dan Mudah Dibuat"
slug: 338-resep-rica-rica-pedas-ayam-ras-merah-yang-nikmat-dan-mudah-dibuat
date: 2021-03-02T06:42:33.578Z
image: https://img-global.cpcdn.com/recipes/bff348f5960aaecc/680x482cq70/rica-rica-pedas-ayam-rasmerah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bff348f5960aaecc/680x482cq70/rica-rica-pedas-ayam-rasmerah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bff348f5960aaecc/680x482cq70/rica-rica-pedas-ayam-rasmerah-foto-resep-utama.jpg
author: Mamie Fitzgerald
ratingvalue: 3.4
reviewcount: 4
recipeingredient:
- "1 ekor ayam rasmerah"
- " Serai 1batang digeprek"
- "1 lembar Daun salam"
- "4 lembar Daun jeruk"
- " Lengkuas 2ruas jari digeprek"
- "1 sendok teh Lada"
- "2 sendok makan Kecap"
- "1 sendok makan Gula merah"
- "1,5 bungkus Masako"
- " Garam jika kurang asin"
- " Bumbu halus"
- "10 siung Bawang merah"
- "6 siung Bawang putih"
- "5 butir Kemiri"
- "2 genggam tangan Cabe rawit"
recipeinstructions:
- "Rebus ayam yg sudah dipotong, tunggu hingga ayam sedikit melunak, jangan dibuang air bekas rebusan"
- "Tumis bumbu halus dan masukkan serai, daun salam, daun jeruk, lengkuas bersamaan"
- "Setelah wangi, masukan ayam yg sudah direbus. Aduk hingga bumbu menyatu."
- "Masukan air bekas rebusan ayam, lalu masukan gula merah, kecap, lada, dan masako"
- "Aduk2 hingga air agak menyusut sedikit.."
categories:
- Resep
tags:
- rica
- rica
- pedas

katakunci: rica rica pedas 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dessert

---


![Rica Rica pedas ayam ras/merah](https://img-global.cpcdn.com/recipes/bff348f5960aaecc/680x482cq70/rica-rica-pedas-ayam-rasmerah-foto-resep-utama.jpg)

Jika kamu seorang wanita, mempersiapkan santapan mantab pada orang tercinta merupakan hal yang menyenangkan untuk kita sendiri. Kewajiban seorang  wanita bukan cuman mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib menyediakan keperluan gizi terpenuhi dan panganan yang dimakan keluarga tercinta wajib sedap.

Di zaman  saat ini, kita sebenarnya mampu mengorder panganan instan tanpa harus susah memasaknya dulu. Namun ada juga orang yang selalu ingin menyajikan yang terenak untuk keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan famili. 



Apakah kamu seorang penikmat rica rica pedas ayam ras/merah?. Asal kamu tahu, rica rica pedas ayam ras/merah adalah sajian khas di Nusantara yang kini disenangi oleh banyak orang di berbagai wilayah di Indonesia. Kamu dapat menghidangkan rica rica pedas ayam ras/merah olahan sendiri di rumah dan boleh dijadikan camilan kegemaranmu di akhir pekanmu.

Anda jangan bingung jika kamu ingin memakan rica rica pedas ayam ras/merah, lantaran rica rica pedas ayam ras/merah tidak sukar untuk dicari dan juga anda pun bisa menghidangkannya sendiri di rumah. rica rica pedas ayam ras/merah bisa dibuat lewat bermacam cara. Kini pun telah banyak banget cara modern yang membuat rica rica pedas ayam ras/merah semakin lebih mantap.

Resep rica rica pedas ayam ras/merah juga mudah dibikin, lho. Kamu tidak usah ribet-ribet untuk memesan rica rica pedas ayam ras/merah, tetapi Anda dapat membuatnya sendiri di rumah. Bagi Kamu yang akan menyajikannya, di bawah ini adalah resep untuk menyajikan rica rica pedas ayam ras/merah yang lezat yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Rica Rica pedas ayam ras/merah:

1. Gunakan 1 ekor ayam ras/merah
1. Ambil  Serai 1batang digeprek
1. Gunakan 1 lembar Daun salam
1. Siapkan 4 lembar Daun jeruk
1. Siapkan  Lengkuas 2ruas jari digeprek
1. Sediakan 1 sendok teh Lada
1. Siapkan 2 sendok makan Kecap
1. Sediakan 1 sendok makan Gula merah
1. Gunakan 1,5 bungkus Masako
1. Siapkan  Garam (jika kurang asin)
1. Ambil  Bumbu halus
1. Ambil 10 siung Bawang merah
1. Ambil 6 siung Bawang putih
1. Siapkan 5 butir Kemiri
1. Siapkan 2 genggam tangan Cabe rawit




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Rica Rica pedas ayam ras/merah:

1. Rebus ayam yg sudah dipotong, tunggu hingga ayam sedikit melunak, jangan dibuang air bekas rebusan
1. Tumis bumbu halus dan masukkan serai, daun salam, daun jeruk, lengkuas bersamaan
1. Setelah wangi, masukan ayam yg sudah direbus. Aduk hingga bumbu menyatu.
1. Masukan air bekas rebusan ayam, lalu masukan gula merah, kecap, lada, dan masako
1. Aduk2 hingga air agak menyusut sedikit..




Wah ternyata resep rica rica pedas ayam ras/merah yang nikamt simple ini mudah banget ya! Kita semua dapat mencobanya. Cara Membuat rica rica pedas ayam ras/merah Sesuai sekali untuk kita yang baru akan belajar memasak maupun juga untuk kalian yang sudah ahli dalam memasak.

Apakah kamu tertarik mulai mencoba bikin resep rica rica pedas ayam ras/merah nikmat simple ini? Kalau kalian mau, ayo kamu segera siapkan alat-alat dan bahan-bahannya, maka bikin deh Resep rica rica pedas ayam ras/merah yang mantab dan tidak rumit ini. Sangat taidak sulit kan. 

Jadi, ketimbang kamu berlama-lama, hayo kita langsung saja hidangkan resep rica rica pedas ayam ras/merah ini. Pasti kalian tak akan menyesal sudah buat resep rica rica pedas ayam ras/merah nikmat simple ini! Selamat mencoba dengan resep rica rica pedas ayam ras/merah lezat simple ini di rumah kalian sendiri,ya!.

