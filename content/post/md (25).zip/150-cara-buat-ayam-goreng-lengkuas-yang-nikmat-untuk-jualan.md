---
description: "Cara buat Ayam Goreng Lengkuas yang nikmat Untuk Jualan"
title: "Cara buat Ayam Goreng Lengkuas yang nikmat Untuk Jualan"
slug: 150-cara-buat-ayam-goreng-lengkuas-yang-nikmat-untuk-jualan
date: 2021-01-29T05:05:52.792Z
image: https://img-global.cpcdn.com/recipes/bd72e6a23cdac3e5/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bd72e6a23cdac3e5/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bd72e6a23cdac3e5/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Eva Maldonado
ratingvalue: 3.2
reviewcount: 12
recipeingredient:
- " Ayam"
- " 10 potong paha ayam"
- "1 jeruk nipis"
- "1/2 sendok teh garam"
- " Bumbu dihaluskan"
- " 12 butir bawang merah"
- "6 butir bawang putih"
- "7 butir kemiri"
- "2 sendok teh ketumbar"
- "2 cm kunyit"
- "1 sendok makan gula merah"
- "Secukupnya garam kaldu ayam"
- " Bumbu cemplung"
- "3 lembar daun salam"
- "200 gram lengkuas muda parut"
- "1 liter air  air kelapa"
recipeinstructions:
- "Marinasi ayam dengan jeruk nipis dan garam sambil diremas remas selama setengah jam agar tidak amis. Kemudian cuci bersih."
- "Haluskan bumbu, balurkan ke ayam. Masukkan lengkuas parut dan daun salam. Ungkep ayam dengan api kecil dan panci ditutup selama 30 menit. Kemudian buka tutup panci selama 30 menit. Dinginkan sampai benar benar dingin agar bumbu meresap."
- "Goreng ayam dengan api panas sebentar saja sampai ayam berkulit, kemudian angkat dan tiriskan. Dengan api sedang goreng parutan lengkuas sampai emas kecoklatan, kemudian tabur diatas ayam goreng.  Hidangkan dengan sayur asam, tempe goreng dan sambal terasi."
categories:
- Resep
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 111 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/bd72e6a23cdac3e5/680x482cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Apabila kalian seorang ibu, mempersiapkan hidangan enak untuk keluarga adalah suatu hal yang menyenangkan bagi anda sendiri. Kewajiban seorang ibu bukan sekadar mengerjakan pekerjaan rumah saja, tapi anda pun harus menyediakan kebutuhan gizi terpenuhi dan juga panganan yang dimakan anak-anak harus lezat.

Di masa  saat ini, kamu memang bisa mengorder olahan instan meski tanpa harus ribet mengolahnya lebih dulu. Namun ada juga lho orang yang selalu mau memberikan yang terenak bagi orang yang dicintainya. Karena, menyajikan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera orang tercinta. 



Mungkinkah anda seorang penggemar ayam goreng lengkuas?. Tahukah kamu, ayam goreng lengkuas adalah hidangan khas di Nusantara yang saat ini digemari oleh orang-orang dari berbagai tempat di Nusantara. Kamu dapat membuat ayam goreng lengkuas sendiri di rumah dan boleh jadi camilan kesenanganmu di akhir pekanmu.

Anda jangan bingung jika kamu ingin menyantap ayam goreng lengkuas, lantaran ayam goreng lengkuas mudah untuk didapatkan dan kita pun bisa membuatnya sendiri di rumah. ayam goreng lengkuas dapat dibuat lewat bermacam cara. Kini telah banyak banget resep kekinian yang menjadikan ayam goreng lengkuas lebih mantap.

Resep ayam goreng lengkuas juga gampang sekali untuk dibuat, lho. Anda jangan ribet-ribet untuk memesan ayam goreng lengkuas, tetapi Kamu mampu menyiapkan sendiri di rumah. Untuk Kalian yang akan menyajikannya, dibawah ini merupakan resep menyajikan ayam goreng lengkuas yang enak yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Goreng Lengkuas:

1. Siapkan  Ayam
1. Ambil  10 potong paha ayam
1. Sediakan 1 jeruk nipis
1. Ambil 1/2 sendok teh garam
1. Sediakan  Bumbu dihaluskan
1. Ambil  12 butir bawang merah
1. Siapkan 6 butir bawang putih
1. Gunakan 7 butir kemiri
1. Sediakan 2 sendok teh ketumbar
1. Sediakan 2 cm kunyit
1. Sediakan 1 sendok makan gula merah
1. Sediakan Secukupnya garam, kaldu ayam
1. Gunakan  Bumbu cemplung
1. Ambil 3 lembar daun salam
1. Sediakan 200 gram lengkuas muda parut
1. Sediakan 1 liter air / air kelapa




<!--inarticleads2-->

##### Cara menyiapkan Ayam Goreng Lengkuas:

1. Marinasi ayam dengan jeruk nipis dan garam sambil diremas remas selama setengah jam agar tidak amis. Kemudian cuci bersih.
1. Haluskan bumbu, balurkan ke ayam. Masukkan lengkuas parut dan daun salam. Ungkep ayam dengan api kecil dan panci ditutup selama 30 menit. Kemudian buka tutup panci selama 30 menit. Dinginkan sampai benar benar dingin agar bumbu meresap.
1. Goreng ayam dengan api panas sebentar saja sampai ayam berkulit, kemudian angkat dan tiriskan. Dengan api sedang goreng parutan lengkuas sampai emas kecoklatan, kemudian tabur diatas ayam goreng.  - Hidangkan dengan sayur asam, tempe goreng dan sambal terasi.




Ternyata cara membuat ayam goreng lengkuas yang enak simple ini gampang banget ya! Kalian semua dapat membuatnya. Cara buat ayam goreng lengkuas Sesuai banget untuk kita yang baru mau belajar memasak ataupun juga untuk kamu yang telah ahli memasak.

Tertarik untuk mencoba membuat resep ayam goreng lengkuas lezat tidak ribet ini? Kalau kamu mau, yuk kita segera siapin peralatan dan bahan-bahannya, kemudian buat deh Resep ayam goreng lengkuas yang lezat dan tidak ribet ini. Benar-benar taidak sulit kan. 

Maka dari itu, daripada kita berfikir lama-lama, hayo langsung aja buat resep ayam goreng lengkuas ini. Pasti anda tak akan nyesel bikin resep ayam goreng lengkuas nikmat simple ini! Selamat berkreasi dengan resep ayam goreng lengkuas lezat tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

