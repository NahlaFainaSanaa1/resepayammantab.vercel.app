---
description: "Cara membuat Ayam Goreng Lengkuas ala Padang⁣ Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam Goreng Lengkuas ala Padang⁣ Sederhana dan Mudah Dibuat"
slug: 145-cara-membuat-ayam-goreng-lengkuas-ala-padang-sederhana-dan-mudah-dibuat
date: 2021-03-14T19:53:22.220Z
image: https://img-global.cpcdn.com/recipes/30b79dc8acba9f11/680x482cq70/ayam-goreng-lengkuas-ala-padang⁣-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/30b79dc8acba9f11/680x482cq70/ayam-goreng-lengkuas-ala-padang⁣-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/30b79dc8acba9f11/680x482cq70/ayam-goreng-lengkuas-ala-padang⁣-foto-resep-utama.jpg
author: Alejandro Scott
ratingvalue: 3
reviewcount: 14
recipeingredient:
- "1 kg ayam"
- "250 gr lengkuas"
- "3 butir telur"
- "2 btg serai"
- "2 lembar daun salam"
- " 6 lembar Daun jeruk"
- "secukupnya Garam dan bumbu kaldu"
- "secukupnya Air"
- "secukupnya Minyak"
- " Bumbu halus "
- "8 Butir bawang putih"
- "1 ruas Jahe"
- "2 ruas Kunyit"
- "8 keping Kemiri"
- "1 St Merica"
- "1 SM ketumbar"
recipeinstructions:
- "Potong&#34; ayam, cuci bersih tiriskan, siapkan serai dan daun jeruk serta daun salam"
- "Iris&#34; Lengkuas lalu blender kemudian sisihkan"
- "Iris halus daun jeruk satukan dengan lengkuas yang telah dihaluskan, ambil ayam, bubuhi garam dan bumbu kaldu"
- "Cuci bersih semua bumbu halus kemudian blender"
- "Masukan kedalam daging ayam, lalu tuang lengkuas dan daun jeruk aduk rata"
- "Masukan dalam wadah, simpan beberapa saat biar bumbu meresap, kemudian Ungkep ayam tambahkan serai, dan daun salam hingga empuk dan bumbu meresap,"
- "Angkat lalu angkat ayam tiriskan bumbunya, kocok telur"
- "Masukan ayam kedalam kocokan telur lalu goreng sampai kuning kecoklatan, angkat gunakan api kecil lakukan sampai ayam habis"
- "Masukan bumbu yang sudah ditiriskan kedalam sisa telur aduk rata, lalu goreng sampai kuning kecoklatan, setelah kering masukan ayam tadi aduk rata"
- "Angkat..... tiriskan...hidangkan bersama nasi hangat sambal dan lalapan"
categories:
- Resep
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 204 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas ala Padang⁣](https://img-global.cpcdn.com/recipes/30b79dc8acba9f11/680x482cq70/ayam-goreng-lengkuas-ala-padang⁣-foto-resep-utama.jpg)

Selaku seorang ibu, menyuguhkan panganan nikmat pada keluarga tercinta merupakan suatu hal yang mengasyikan untuk anda sendiri. Peran seorang istri Tidak sekadar mengatur rumah saja, tetapi kamu pun harus memastikan kebutuhan gizi terpenuhi dan juga olahan yang dimakan orang tercinta harus nikmat.

Di masa  saat ini, anda sebenarnya dapat memesan panganan yang sudah jadi walaupun tidak harus ribet memasaknya dahulu. Tetapi ada juga mereka yang memang ingin memberikan makanan yang terenak bagi keluarganya. Lantaran, menghidangkan masakan sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan selera famili. 



Apakah anda adalah seorang penyuka ayam goreng lengkuas ala padang⁣?. Tahukah kamu, ayam goreng lengkuas ala padang⁣ adalah makanan khas di Nusantara yang kini disukai oleh banyak orang dari hampir setiap tempat di Nusantara. Kamu bisa menyajikan ayam goreng lengkuas ala padang⁣ kreasi sendiri di rumah dan boleh jadi hidangan kegemaranmu di hari libur.

Kamu tak perlu bingung untuk memakan ayam goreng lengkuas ala padang⁣, karena ayam goreng lengkuas ala padang⁣ sangat mudah untuk ditemukan dan juga kalian pun bisa membuatnya sendiri di rumah. ayam goreng lengkuas ala padang⁣ dapat dibuat dengan bermacam cara. Kini sudah banyak sekali cara modern yang menjadikan ayam goreng lengkuas ala padang⁣ lebih mantap.

Resep ayam goreng lengkuas ala padang⁣ pun sangat gampang dibikin, lho. Kamu jangan repot-repot untuk memesan ayam goreng lengkuas ala padang⁣, lantaran Kamu dapat menyiapkan di rumahmu. Bagi Kita yang mau menghidangkannya, di bawah ini adalah resep untuk menyajikan ayam goreng lengkuas ala padang⁣ yang enak yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Goreng Lengkuas ala Padang⁣:

1. Gunakan 1 kg ayam
1. Siapkan 250 gr lengkuas
1. Ambil 3 butir telur⁣
1. Siapkan 2 btg serai⁣
1. Siapkan 2 lembar daun salam⁣
1. Siapkan  6 lembar Daun jeruk
1. Siapkan secukupnya Garam dan bumbu kaldu
1. Sediakan secukupnya Air
1. Siapkan secukupnya Minyak
1. Gunakan  Bumbu halus :
1. Gunakan 8 Butir bawang putih
1. Sediakan 1 ruas Jahe
1. Siapkan 2 ruas Kunyit
1. Ambil 8 keping Kemiri
1. Sediakan 1 St Merica
1. Siapkan 1 SM ketumbar




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Lengkuas ala Padang⁣:

1. Potong&#34; ayam, cuci bersih tiriskan, siapkan serai dan daun jeruk serta daun salam
1. Iris&#34; Lengkuas lalu blender kemudian sisihkan
1. Iris halus daun jeruk satukan dengan lengkuas yang telah dihaluskan, ambil ayam, bubuhi garam dan bumbu kaldu
1. Cuci bersih semua bumbu halus kemudian blender
1. Masukan kedalam daging ayam, lalu tuang lengkuas dan daun jeruk aduk rata
1. Masukan dalam wadah, simpan beberapa saat biar bumbu meresap, kemudian Ungkep ayam tambahkan serai, dan daun salam hingga empuk dan bumbu meresap,
1. Angkat lalu angkat ayam tiriskan bumbunya, kocok telur
1. Masukan ayam kedalam kocokan telur lalu goreng sampai kuning kecoklatan, angkat gunakan api kecil lakukan sampai ayam habis
1. Masukan bumbu yang sudah ditiriskan kedalam sisa telur aduk rata, lalu goreng sampai kuning kecoklatan, setelah kering masukan ayam tadi aduk rata
1. Angkat..... tiriskan...hidangkan bersama nasi hangat sambal dan lalapan




Ternyata cara membuat ayam goreng lengkuas ala padang⁣ yang mantab simple ini enteng banget ya! Kamu semua bisa membuatnya. Cara buat ayam goreng lengkuas ala padang⁣ Sangat cocok sekali buat kalian yang sedang belajar memasak atau juga untuk kamu yang telah jago memasak.

Tertarik untuk mencoba membikin resep ayam goreng lengkuas ala padang⁣ nikmat tidak ribet ini? Kalau kalian tertarik, ayo kamu segera siapin peralatan dan bahannya, lantas bikin deh Resep ayam goreng lengkuas ala padang⁣ yang mantab dan tidak rumit ini. Sungguh mudah kan. 

Maka, daripada kamu berfikir lama-lama, yuk kita langsung hidangkan resep ayam goreng lengkuas ala padang⁣ ini. Pasti kalian tiidak akan nyesel membuat resep ayam goreng lengkuas ala padang⁣ nikmat tidak ribet ini! Selamat berkreasi dengan resep ayam goreng lengkuas ala padang⁣ nikmat sederhana ini di rumah masing-masing,ya!.

