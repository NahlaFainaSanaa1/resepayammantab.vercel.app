---
description: "Cara buat Ayam goreng suharti yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam goreng suharti yang lezat dan Mudah Dibuat"
slug: 202-cara-buat-ayam-goreng-suharti-yang-lezat-dan-mudah-dibuat
date: 2021-05-12T01:02:58.434Z
image: https://img-global.cpcdn.com/recipes/269ff18c0494807d/680x482cq70/ayam-goreng-suharti-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/269ff18c0494807d/680x482cq70/ayam-goreng-suharti-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/269ff18c0494807d/680x482cq70/ayam-goreng-suharti-foto-resep-utama.jpg
author: Verna Perez
ratingvalue: 3.2
reviewcount: 10
recipeingredient:
- "2 ekor ayam kampung"
- " Air kelapa"
- " Bumbu yg dihaluskan"
- "40 gr bawang putih"
- "20 gr kemiri"
- "15 gr kunyit"
- "8 gr ketumbar"
- "2 gr lada"
- "1 gr jinten"
- "16 gr garam"
- "6 gr vetsin"
- " Adonan pencelup"
- "100 gr tepung sagu tani"
- "20 gr maizena"
- "1 sdt garam"
- "1 sdt vetsin"
- "2 btr telor"
- "150 ml santan kara11air"
- " Bahan kremesan"
- "50 gr kemiri haluskan"
- "40 gr bawang putih haluskan"
- "65 gr tepung sagu tani"
- "10 gr maizena"
- "1 sdm gula pasir"
- "1 sdt vetsin"
- "2 gr lada"
- "2 gr ketumbar haluskan"
- "1 sdt garam"
- "1 btr telur"
- "200 ml santan kental murni"
- "425 ml air"
- " Bahan sambal"
- "50 gr cabe rawit merah"
- "100 gr cabe keriting"
- "150 gr cabe merah besar"
- "30 gr bawang putih"
- "60 gr bawang merah"
- "200 gr tomat"
- "75 vgr gula merah"
- "5 gr asam jawa"
- "25 gr terasi goreng"
- "20 gr garam"
- "4 gr vetsin"
recipeinstructions:
- "Masak air kelapa dan bumbu yg dihaluskan hingga panas. masukan ayam. Didihkan. Masak terus hingga lebih kurang 1 jam"
- "Matikan api kompor. Biarkan ayam dalam panci hingga 1 jam. Kemudian angkat tiriskan"
- "Campur semua bahan pencelup. Hingga rata. Celupkan ayam yg sdh di masak. Lalu goreng dalam minyak panas yg banyak dg api sedang"
- "Langkah membuat kremesan:"
- "Campur semua adonan kremesan aduk rata."
- "Panaskan minyak banyak. Kucurkan adonan kremesan dari tengah2 hingga bolongan mengecil divtengahbpenggorengan. Goreng sambil di bentuk mengumpul hingga mengapung. Angkat dan sajikan."
- "Sambal suharti:"
- "Goreng semua cabe bawang merah bawang putih setengah matang"
- "Masukan ke Blender dan blender semua bahan. Kemudian masak dg api kecil"
- "Video Cara menggoreng kremesan bisa dilihat di youtube jangan lupa klik subscribe ya judulnya : ayam goreng suharti by rsw"
categories:
- Resep
tags:
- ayam
- goreng
- suharti

katakunci: ayam goreng suharti 
nutrition: 173 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam goreng suharti](https://img-global.cpcdn.com/recipes/269ff18c0494807d/680x482cq70/ayam-goreng-suharti-foto-resep-utama.jpg)

Andai kalian seorang ibu, menyediakan masakan enak buat keluarga adalah suatu hal yang memuaskan bagi kita sendiri. Tugas seorang istri bukan sekadar mengatur rumah saja, namun kamu pun wajib menyediakan keperluan nutrisi terpenuhi dan masakan yang dimakan orang tercinta mesti mantab.

Di era  sekarang, kamu memang bisa membeli masakan siap saji meski tidak harus susah mengolahnya terlebih dahulu. Tetapi ada juga lho orang yang memang mau memberikan yang terenak bagi keluarganya. Sebab, memasak sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai masakan kesukaan keluarga. 



Mungkinkah anda merupakan salah satu penggemar ayam goreng suharti?. Asal kamu tahu, ayam goreng suharti adalah makanan khas di Nusantara yang saat ini digemari oleh kebanyakan orang dari hampir setiap wilayah di Indonesia. Anda bisa menghidangkan ayam goreng suharti sendiri di rumahmu dan dapat dijadikan santapan kegemaranmu di akhir pekan.

Kita tidak usah bingung jika kamu ingin mendapatkan ayam goreng suharti, sebab ayam goreng suharti mudah untuk dicari dan kamu pun dapat mengolahnya sendiri di tempatmu. ayam goreng suharti boleh dimasak dengan berbagai cara. Kini pun ada banyak sekali resep kekinian yang menjadikan ayam goreng suharti semakin nikmat.

Resep ayam goreng suharti pun mudah sekali dibuat, lho. Kita tidak usah repot-repot untuk memesan ayam goreng suharti, tetapi Anda bisa membuatnya sendiri di rumah. Untuk Kita yang mau mencobanya, di bawah ini adalah resep untuk menyajikan ayam goreng suharti yang mantab yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam goreng suharti:

1. Gunakan 2 ekor ayam kampung
1. Siapkan  Air kelapa
1. Siapkan  Bumbu yg dihaluskan:
1. Ambil 40 gr bawang putih
1. Siapkan 20 gr kemiri
1. Ambil 15 gr kunyit
1. Ambil 8 gr ketumbar
1. Gunakan 2 gr lada
1. Gunakan 1 gr jinten
1. Siapkan 16 gr garam
1. Sediakan 6 gr vetsin
1. Sediakan  Adonan pencelup:
1. Gunakan 100 gr tepung sagu tani
1. Siapkan 20 gr maizena
1. Gunakan 1 sdt garam
1. Sediakan 1 sdt vetsin
1. Sediakan 2 btr telor
1. Sediakan 150 ml santan (kara1÷1air)
1. Gunakan  Bahan kremesan:
1. Sediakan 50 gr kemiri haluskan
1. Sediakan 40 gr bawang putih haluskan
1. Ambil 65 gr tepung sagu tani
1. Siapkan 10 gr maizena
1. Gunakan 1 sdm gula pasir
1. Ambil 1 sdt vetsin
1. Sediakan 2 gr lada
1. Gunakan 2 gr ketumbar haluskan
1. Ambil 1 sdt garam
1. Gunakan 1 btr telur
1. Sediakan 200 ml santan kental murni
1. Sediakan 425 ml air
1. Siapkan  Bahan sambal:
1. Siapkan 50 gr cabe rawit merah
1. Gunakan 100 gr cabe keriting
1. Sediakan 150 gr cabe merah besar
1. Ambil 30 gr bawang putih
1. Ambil 60 gr bawang merah
1. Siapkan 200 gr tomat
1. Sediakan 75 vgr gula merah
1. Sediakan 5 gr asam jawa
1. Sediakan 25 gr terasi goreng
1. Ambil 20 gr garam
1. Siapkan 4 gr vetsin




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam goreng suharti:

1. Masak air kelapa dan bumbu yg dihaluskan hingga panas. masukan ayam. Didihkan. Masak terus hingga lebih kurang 1 jam
1. Matikan api kompor. Biarkan ayam dalam panci hingga 1 jam. Kemudian angkat tiriskan
1. Campur semua bahan pencelup. Hingga rata. Celupkan ayam yg sdh di masak. Lalu goreng dalam minyak panas yg banyak dg api sedang
1. Langkah membuat kremesan:
1. Campur semua adonan kremesan aduk rata.
1. Panaskan minyak banyak. Kucurkan adonan kremesan dari tengah2 hingga bolongan mengecil divtengahbpenggorengan. Goreng sambil di bentuk mengumpul hingga mengapung. Angkat dan sajikan.
1. Sambal suharti:
1. Goreng semua cabe bawang merah bawang putih setengah matang
1. Masukan ke Blender dan blender semua bahan. Kemudian masak dg api kecil
1. Video Cara menggoreng kremesan bisa dilihat di youtube jangan lupa klik subscribe ya judulnya : ayam goreng suharti by rsw




Wah ternyata resep ayam goreng suharti yang enak simple ini enteng banget ya! Kamu semua dapat menghidangkannya. Cara Membuat ayam goreng suharti Sangat sesuai banget untuk anda yang sedang belajar memasak maupun juga untuk anda yang sudah jago memasak.

Tertarik untuk mencoba buat resep ayam goreng suharti nikmat sederhana ini? Kalau tertarik, mending kamu segera buruan siapin peralatan dan bahannya, kemudian bikin deh Resep ayam goreng suharti yang nikmat dan tidak ribet ini. Betul-betul taidak sulit kan. 

Jadi, daripada anda diam saja, hayo kita langsung saja bikin resep ayam goreng suharti ini. Pasti kamu tak akan menyesal membuat resep ayam goreng suharti lezat tidak rumit ini! Selamat mencoba dengan resep ayam goreng suharti lezat sederhana ini di tempat tinggal kalian sendiri,oke!.

