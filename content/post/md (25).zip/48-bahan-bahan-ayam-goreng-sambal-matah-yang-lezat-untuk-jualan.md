---
description: "Bahan-bahan Ayam Goreng Sambal Matah yang lezat Untuk Jualan"
title: "Bahan-bahan Ayam Goreng Sambal Matah yang lezat Untuk Jualan"
slug: 48-bahan-bahan-ayam-goreng-sambal-matah-yang-lezat-untuk-jualan
date: 2021-04-27T20:37:24.064Z
image: https://img-global.cpcdn.com/recipes/c2199e2eca78dc26/680x482cq70/ayam-goreng-sambal-matah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c2199e2eca78dc26/680x482cq70/ayam-goreng-sambal-matah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c2199e2eca78dc26/680x482cq70/ayam-goreng-sambal-matah-foto-resep-utama.jpg
author: Tony Neal
ratingvalue: 3.1
reviewcount: 7
recipeingredient:
- "250 gr dada fillet potong kotak"
- "1/2 butir jeruk nipis"
- " Minyak goreng"
- " Bumbu marinasi"
- "1 sdt ketumbar bubuk"
- "1/4 sdt garam"
- "1 sdt bawang putih bubuk"
- " Sambal matah"
- "5 butir bawang merah iris"
- "1 buah cabe merah besar potong kecil"
- "3 lembar daun jeruk buang tulang dan iris"
- "1 batang sereh potong kecil"
- "1/4 sdt garam"
- "1/2 sdt gula pasir"
- "1 sdm minyak"
- "1/2 butir jeruk nipis"
recipeinstructions:
- "Cuci bersih ayam dengan jeruk nipis. Beri bumbu marinasi. Diamkan 30menit."
- "Siapkan bahan sambal matah (bawang, cabe, sereh, daun jeruk dan garam). Sisihkan"
- "Goreng ayam hingga kecoklatan. Tiriskan"
- "Panaskan minyak. Oseng sambal matah sebentar hingga layu. Angkat. Beri gula dan jeruk nipis. Aduk rata dan tes rasa. Lalu tuang diatas ayam goreng"
categories:
- Resep
tags:
- ayam
- goreng
- sambal

katakunci: ayam goreng sambal 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Goreng Sambal Matah](https://img-global.cpcdn.com/recipes/c2199e2eca78dc26/680x482cq70/ayam-goreng-sambal-matah-foto-resep-utama.jpg)

Andai anda seorang yang hobi memasak, menyajikan masakan mantab untuk orang tercinta adalah hal yang sangat menyenangkan bagi anda sendiri. Kewajiban seorang ibu Tidak saja mengurus rumah saja, tapi anda juga wajib memastikan keperluan nutrisi tercukupi dan hidangan yang disantap keluarga tercinta wajib sedap.

Di masa  sekarang, kamu sebenarnya dapat mengorder panganan yang sudah jadi meski tanpa harus ribet mengolahnya dahulu. Namun ada juga lho orang yang selalu mau menyajikan yang terenak untuk keluarganya. Lantaran, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai dengan selera famili. 



Mungkinkah anda adalah seorang penyuka ayam goreng sambal matah?. Tahukah kamu, ayam goreng sambal matah merupakan sajian khas di Indonesia yang kini disenangi oleh setiap orang di hampir setiap daerah di Nusantara. Anda bisa memasak ayam goreng sambal matah sendiri di rumah dan dapat dijadikan makanan favoritmu di akhir pekan.

Kita tak perlu bingung jika kamu ingin menyantap ayam goreng sambal matah, karena ayam goreng sambal matah tidak sulit untuk ditemukan dan juga kamu pun bisa menghidangkannya sendiri di rumah. ayam goreng sambal matah boleh dimasak dengan berbagai cara. Kini ada banyak banget resep kekinian yang membuat ayam goreng sambal matah semakin enak.

Resep ayam goreng sambal matah juga sangat gampang dibuat, lho. Kalian tidak usah capek-capek untuk membeli ayam goreng sambal matah, lantaran Kalian bisa menyiapkan di rumah sendiri. Bagi Anda yang ingin mencobanya, di bawah ini adalah resep untuk membuat ayam goreng sambal matah yang nikamat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Goreng Sambal Matah:

1. Ambil 250 gr dada fillet, potong kotak
1. Siapkan 1/2 butir jeruk nipis
1. Gunakan  Minyak goreng
1. Ambil  Bumbu marinasi
1. Sediakan 1 sdt ketumbar bubuk
1. Gunakan 1/4 sdt garam
1. Sediakan 1 sdt bawang putih bubuk
1. Sediakan  Sambal matah
1. Ambil 5 butir bawang merah, iris
1. Sediakan 1 buah cabe merah besar, potong kecil
1. Siapkan 3 lembar daun jeruk, buang tulang dan iris
1. Siapkan 1 batang sereh, potong kecil
1. Gunakan 1/4 sdt garam
1. Sediakan 1/2 sdt gula pasir
1. Gunakan 1 sdm minyak
1. Ambil 1/2 butir jeruk nipis




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Sambal Matah:

1. Cuci bersih ayam dengan jeruk nipis. Beri bumbu marinasi. Diamkan 30menit.
1. Siapkan bahan sambal matah (bawang, cabe, sereh, daun jeruk dan garam). Sisihkan
1. Goreng ayam hingga kecoklatan. Tiriskan
1. Panaskan minyak. Oseng sambal matah sebentar hingga layu. Angkat. Beri gula dan jeruk nipis. Aduk rata dan tes rasa. Lalu tuang diatas ayam goreng




Wah ternyata cara membuat ayam goreng sambal matah yang lezat tidak rumit ini mudah sekali ya! Kita semua dapat memasaknya. Resep ayam goreng sambal matah Cocok banget buat kalian yang baru mau belajar memasak atau juga untuk kalian yang telah jago dalam memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam goreng sambal matah nikmat tidak rumit ini? Kalau tertarik, yuk kita segera buruan siapin peralatan dan bahan-bahannya, setelah itu buat deh Resep ayam goreng sambal matah yang lezat dan sederhana ini. Betul-betul mudah kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, ayo langsung aja bikin resep ayam goreng sambal matah ini. Dijamin kalian tak akan menyesal bikin resep ayam goreng sambal matah enak tidak rumit ini! Selamat berkreasi dengan resep ayam goreng sambal matah mantab tidak ribet ini di tempat tinggal sendiri,ya!.

