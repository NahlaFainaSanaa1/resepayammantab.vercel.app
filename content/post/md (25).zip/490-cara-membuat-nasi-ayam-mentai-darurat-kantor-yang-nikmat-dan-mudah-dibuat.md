---
description: "Cara membuat Nasi Ayam Mentai Darurat Kantor yang nikmat dan Mudah Dibuat"
title: "Cara membuat Nasi Ayam Mentai Darurat Kantor yang nikmat dan Mudah Dibuat"
slug: 490-cara-membuat-nasi-ayam-mentai-darurat-kantor-yang-nikmat-dan-mudah-dibuat
date: 2021-02-20T00:36:18.006Z
image: https://img-global.cpcdn.com/recipes/845b48b3c6dc3662/680x482cq70/nasi-ayam-mentai-darurat-kantor-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/845b48b3c6dc3662/680x482cq70/nasi-ayam-mentai-darurat-kantor-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/845b48b3c6dc3662/680x482cq70/nasi-ayam-mentai-darurat-kantor-foto-resep-utama.jpg
author: Irene Maxwell
ratingvalue: 4.3
reviewcount: 3
recipeingredient:
- "4 potong dada fried chicken terdekat"
- "6 porsi nasi"
- " Bon Cabe  Bon Nori"
- " Nori"
- "400 gr mayonese maestro original"
- "5 sdm minyak wijen"
- "1 sdt bawang putih bubuk"
- "1/2 sdt lada bubuk"
- " Saus sambal"
- " Margarin"
- " Keju Chedar"
- " Wadah alumunium foilopsional"
recipeinstructions:
- "Potong kecil kecil fried chicken, sisihkan."
- "Campur nasi dengan bawang putih bubuk, lada secukupnya, minyak wijen, dan bon nori/ bon cabe sesuai selera."
- "Panaskan campuran nasi di microwave +- 10 menit dengan tingkat panas medium high"
- "Buat saus mentai dengan mencampur mayonese dan saus sambal secukupnya."
- "Balur wadah alumunium dengan margarin."
- "Pada wadah, susun dengan urutan nasi, potongan ayam, saus mentai, keju cheddar, dan nori. Bisa ditambahkan lagi bon cabe sesuai selera. Gunakan penutup alumunium foil"
- "Panaskan dalam microwave +- 2menit dengan tingkat panas high."
- "Sajikan"
categories:
- Resep
tags:
- nasi
- ayam
- mentai

katakunci: nasi ayam mentai 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dessert

---


![Nasi Ayam Mentai Darurat Kantor](https://img-global.cpcdn.com/recipes/845b48b3c6dc3662/680x482cq70/nasi-ayam-mentai-darurat-kantor-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyajikan hidangan enak untuk keluarga adalah suatu hal yang mengasyikan bagi kamu sendiri. Tanggung jawab seorang ibu bukan saja menjaga rumah saja, namun anda pun harus menyediakan kebutuhan gizi tercukupi dan juga panganan yang dikonsumsi anak-anak harus menggugah selera.

Di era  sekarang, kita sebenarnya bisa memesan santapan siap saji walaupun tanpa harus susah memasaknya terlebih dahulu. Namun banyak juga mereka yang selalu ingin memberikan makanan yang terlezat untuk orang tercintanya. Sebab, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan berdasarkan kesukaan keluarga. 



Mungkinkah kamu seorang penggemar nasi ayam mentai darurat kantor?. Asal kamu tahu, nasi ayam mentai darurat kantor adalah hidangan khas di Nusantara yang saat ini digemari oleh kebanyakan orang di hampir setiap tempat di Nusantara. Kita bisa menyajikan nasi ayam mentai darurat kantor sendiri di rumah dan dapat dijadikan hidangan favorit di akhir pekan.

Kamu tidak perlu bingung jika kamu ingin mendapatkan nasi ayam mentai darurat kantor, lantaran nasi ayam mentai darurat kantor mudah untuk didapatkan dan kalian pun dapat memasaknya sendiri di rumah. nasi ayam mentai darurat kantor dapat dibuat lewat bermacam cara. Saat ini telah banyak cara kekinian yang membuat nasi ayam mentai darurat kantor semakin nikmat.

Resep nasi ayam mentai darurat kantor juga mudah sekali untuk dibuat, lho. Anda tidak perlu ribet-ribet untuk membeli nasi ayam mentai darurat kantor, sebab Kita mampu menghidangkan ditempatmu. Untuk Kalian yang akan mencobanya, di bawah ini adalah cara untuk menyajikan nasi ayam mentai darurat kantor yang nikamat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Nasi Ayam Mentai Darurat Kantor:

1. Gunakan 4 potong dada fried chicken terdekat
1. Siapkan 6 porsi nasi
1. Siapkan  Bon Cabe / Bon Nori
1. Gunakan  Nori
1. Siapkan 400 gr mayonese maestro original
1. Siapkan 5 sdm minyak wijen
1. Siapkan 1 sdt bawang putih bubuk
1. Gunakan 1/2 sdt lada bubuk
1. Ambil  Saus sambal
1. Sediakan  Margarin
1. Ambil  Keju Chedar
1. Ambil  Wadah alumunium foil/opsional




<!--inarticleads2-->

##### Cara menyiapkan Nasi Ayam Mentai Darurat Kantor:

1. Potong kecil kecil fried chicken, sisihkan.
1. Campur nasi dengan bawang putih bubuk, lada secukupnya, minyak wijen, dan bon nori/ bon cabe sesuai selera.
1. Panaskan campuran nasi di microwave +- 10 menit dengan tingkat panas medium high
1. Buat saus mentai dengan mencampur mayonese dan saus sambal secukupnya.
1. Balur wadah alumunium dengan margarin.
1. Pada wadah, susun dengan urutan nasi, potongan ayam, saus mentai, keju cheddar, dan nori. Bisa ditambahkan lagi bon cabe sesuai selera. Gunakan penutup alumunium foil
1. Panaskan dalam microwave +- 2menit dengan tingkat panas high.
1. Sajikan




Ternyata cara membuat nasi ayam mentai darurat kantor yang nikamt tidak ribet ini gampang banget ya! Kamu semua dapat menghidangkannya. Cara Membuat nasi ayam mentai darurat kantor Sangat sesuai sekali untuk kita yang sedang belajar memasak ataupun bagi anda yang telah lihai dalam memasak.

Apakah kamu mau mencoba membuat resep nasi ayam mentai darurat kantor enak tidak ribet ini? Kalau anda ingin, yuk kita segera menyiapkan alat dan bahannya, kemudian bikin deh Resep nasi ayam mentai darurat kantor yang lezat dan tidak rumit ini. Sangat gampang kan. 

Oleh karena itu, daripada kita berlama-lama, yuk kita langsung buat resep nasi ayam mentai darurat kantor ini. Pasti kamu gak akan nyesel sudah bikin resep nasi ayam mentai darurat kantor lezat tidak ribet ini! Selamat berkreasi dengan resep nasi ayam mentai darurat kantor nikmat simple ini di rumah sendiri,oke!.

