---
description: "Cara membuat Ayam Masak Merah yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam Masak Merah yang enak dan Mudah Dibuat"
slug: 456-cara-membuat-ayam-masak-merah-yang-enak-dan-mudah-dibuat
date: 2021-06-10T19:51:46.482Z
image: https://img-global.cpcdn.com/recipes/4148367d53c5953b/680x482cq70/ayam-masak-merah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4148367d53c5953b/680x482cq70/ayam-masak-merah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4148367d53c5953b/680x482cq70/ayam-masak-merah-foto-resep-utama.jpg
author: Jeanette Austin
ratingvalue: 3.6
reviewcount: 13
recipeingredient:
- "1 ekor ayam kampung"
- "3 buah kentang"
- "1 buah jeruk nipisperas"
- "1 sdm air asam jawadr 3 butir asam"
- "3 sdm garam"
- "3 sdm kelapa gonsengu nelhe"
- "1 ltr air"
- "500 ml santan sedang"
- " Bumbu Halus"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "15 biji cabe rawit"
- "10 buah cabe merah kering"
- "1 sdm ketumbar"
- "1/4 sdt lada"
- "1/4 sdt adas"
- "1/4 sdt jintan"
- " Bumbu Tambahan"
- "3 siung bawang merah iris tipis"
- "2 siung bawang putih iris tipis"
- "2 btg serai"
- "2 lembar daun pandan"
- "2 tangkai daun karitemerui"
- "4 buah kapulaga"
- "4 buah cengkeh"
- "2 buah bunga lawang"
recipeinstructions:
- "Ayam yg sudah di bersihkan bakar sebentar,kemudian potong sesuai selera,cuci bersih beri perasan jeruk nipis,air asam jawa dan garam,diamkan selama 15 menit,kemudian tiriskan,lalu blender semua bumbu halus,kecuali cabe merah kering,kemudian campurkan bimbu halus ke dalam ayam,diamkan sesaat hingga bumbu meresap."
- "Panaskan sekitar 3 sdm minyak,lalu tumis bahan tambahan hingga harum,dan tumis cabe merah yg udh dihaluskan,kemudian masukkan ayam"
- "Tambahkan kelapa gonseng,masak hingga bumbu meresap kemudian tambahkan air"
- "Tambahkan kentang yg sudah di belah 4 dan terakhir tambahkan santan"
- "Masak hingga matang koreksi rasa..siap dihidangkan"
categories:
- Resep
tags:
- ayam
- masak
- merah

katakunci: ayam masak merah 
nutrition: 234 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Masak Merah](https://img-global.cpcdn.com/recipes/4148367d53c5953b/680x482cq70/ayam-masak-merah-foto-resep-utama.jpg)

Sebagai seorang istri, menyediakan hidangan lezat untuk famili merupakan hal yang mengasyikan untuk kamu sendiri. Peran seorang ibu bukan sekedar menjaga rumah saja, tetapi kamu pun harus memastikan kebutuhan gizi terpenuhi dan hidangan yang dikonsumsi anak-anak mesti lezat.

Di masa  saat ini, kalian memang bisa membeli olahan instan tanpa harus repot membuatnya dulu. Tapi banyak juga mereka yang memang mau memberikan makanan yang terenak untuk keluarganya. Lantaran, memasak sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai masakan kesukaan orang tercinta. 



Mungkinkah anda adalah seorang penikmat ayam masak merah?. Tahukah kamu, ayam masak merah merupakan makanan khas di Nusantara yang saat ini disukai oleh setiap orang dari hampir setiap tempat di Nusantara. Kamu bisa menghidangkan ayam masak merah sendiri di rumah dan boleh jadi hidangan favoritmu di hari libur.

Kalian tak perlu bingung untuk mendapatkan ayam masak merah, lantaran ayam masak merah tidak sukar untuk didapatkan dan kita pun boleh mengolahnya sendiri di rumah. ayam masak merah bisa dibuat dengan bermacam cara. Sekarang telah banyak sekali cara kekinian yang membuat ayam masak merah semakin lezat.

Resep ayam masak merah juga mudah dibuat, lho. Kalian jangan ribet-ribet untuk memesan ayam masak merah, sebab Anda dapat membuatnya di rumah sendiri. Untuk Kita yang mau menyajikannya, berikut resep untuk menyajikan ayam masak merah yang enak yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Masak Merah:

1. Ambil 1 ekor ayam kampung
1. Ambil 3 buah kentang
1. Siapkan 1 buah jeruk nipis,peras
1. Gunakan 1 sdm air asam jawa,dr 3 butir asam
1. Siapkan 3 sdm garam
1. Ambil 3 sdm kelapa gonseng/u nelhe
1. Ambil 1 ltr air
1. Gunakan 500 ml santan sedang
1. Sediakan  Bumbu Halus:
1. Sediakan 8 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Sediakan 1 ruas jahe
1. Ambil 1 ruas kunyit
1. Sediakan 15 biji cabe rawit
1. Siapkan 10 buah cabe merah kering
1. Ambil 1 sdm ketumbar
1. Ambil 1/4 sdt lada
1. Siapkan 1/4 sdt adas
1. Siapkan 1/4 sdt jintan
1. Sediakan  Bumbu Tambahan
1. Ambil 3 siung bawang merah iris tipis
1. Siapkan 2 siung bawang putih iris tipis
1. Siapkan 2 btg serai
1. Ambil 2 lembar daun pandan
1. Sediakan 2 tangkai daun kari/temerui
1. Siapkan 4 buah kapulaga
1. Sediakan 4 buah cengkeh
1. Gunakan 2 buah bunga lawang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Masak Merah:

1. Ayam yg sudah di bersihkan bakar sebentar,kemudian potong sesuai selera,cuci bersih beri perasan jeruk nipis,air asam jawa dan garam,diamkan selama 15 menit,kemudian tiriskan,lalu blender semua bumbu halus,kecuali cabe merah kering,kemudian campurkan bimbu halus ke dalam ayam,diamkan sesaat hingga bumbu meresap.
1. Panaskan sekitar 3 sdm minyak,lalu tumis bahan tambahan hingga harum,dan tumis cabe merah yg udh dihaluskan,kemudian masukkan ayam
1. Tambahkan kelapa gonseng,masak hingga bumbu meresap kemudian tambahkan air
1. Tambahkan kentang yg sudah di belah 4 dan terakhir tambahkan santan
1. Masak hingga matang koreksi rasa..siap dihidangkan




Ternyata cara membuat ayam masak merah yang mantab tidak ribet ini enteng banget ya! Kalian semua mampu membuatnya. Cara Membuat ayam masak merah Cocok sekali untuk kita yang baru akan belajar memasak ataupun juga untuk anda yang telah jago memasak.

Tertarik untuk mulai mencoba membikin resep ayam masak merah lezat simple ini? Kalau anda ingin, ayo kalian segera buruan siapkan alat dan bahan-bahannya, lalu buat deh Resep ayam masak merah yang nikmat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Jadi, daripada kalian diam saja, hayo kita langsung buat resep ayam masak merah ini. Pasti kalian gak akan nyesel sudah buat resep ayam masak merah enak tidak ribet ini! Selamat berkreasi dengan resep ayam masak merah enak simple ini di tempat tinggal kalian masing-masing,oke!.

