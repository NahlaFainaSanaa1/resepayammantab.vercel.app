---
description: "Bahan-bahan Soto Ayam Santan Kara yang enak Untuk Jualan"
title: "Bahan-bahan Soto Ayam Santan Kara yang enak Untuk Jualan"
slug: 20-bahan-bahan-soto-ayam-santan-kara-yang-enak-untuk-jualan
date: 2021-06-15T12:22:32.568Z
image: https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg
author: Sarah Lawson
ratingvalue: 4.4
reviewcount: 8
recipeingredient:
- "1/2 ekor ayam"
- " Isian soto kol tauge tomat kentang jeruk nipis emping"
- " Bumbu halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "3 buah kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 sdt ketumbar"
- "1 sdt lada"
- "1 sdt jinten"
- "1 gelas kecil air"
- " Bumbu Cemplung"
- "1 liter air"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 serai digeprek"
- "1 ruas lengkuas digeprek"
- "1/4 bulatan biji pala"
- "3 buah bunga"
- "secukupnya Daun bawang"
- "1 sachet santan kara kecil"
- "secukupnya Gula msg Royco"
recipeinstructions:
- "Blender semua bumbu halus, kemudian tumis sampai air menyusut dan bumbu keluar minyak dan benar2 matang"
- "Cuci bersih ayam, potong2. Panaskan panci masukkan semua bumbu Cemplung (kecuali santan dan daun bawang) beserta ayam, dan masukkan bumbu halus yg sudah ditumis tadi. Bila ayam sudah setengah matang angkat lalu goreng ayam. Sisihkan suwir2"
- "Masukkan santan ke dalam panci tunggu sampai mendidih sambil diaduk2. Koreksi rasa, masukkan daun bawang dan jadi deh."
- "Potong2 isian soto, rebus tauge, dan goreng kentang (empingnya lupa di foto)"
- "Cara buat sambal: 31 cabe rawit direbus, ulek dengan msg kasih beberapa tetes jeruk nipis. (Ga perlu dikasih garam)"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto Ayam Santan Kara](https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan olahan menggugah selera bagi orang tercinta adalah suatu hal yang membahagiakan bagi anda sendiri. Tugas seorang ibu bukan saja mengurus rumah saja, tetapi anda juga wajib menyediakan kebutuhan gizi tercukupi dan olahan yang disantap keluarga tercinta mesti nikmat.

Di waktu  saat ini, kamu sebenarnya mampu memesan panganan yang sudah jadi meski tidak harus susah memasaknya lebih dulu. Tapi ada juga mereka yang memang ingin memberikan yang terenak untuk keluarganya. Karena, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan selera keluarga. 



Mungkinkah anda merupakan salah satu penikmat soto ayam santan kara?. Asal kamu tahu, soto ayam santan kara merupakan makanan khas di Indonesia yang sekarang digemari oleh kebanyakan orang dari hampir setiap wilayah di Nusantara. Anda bisa membuat soto ayam santan kara kreasi sendiri di rumahmu dan dapat dijadikan hidangan favorit di akhir pekan.

Kalian tidak perlu bingung untuk menyantap soto ayam santan kara, lantaran soto ayam santan kara sangat mudah untuk didapatkan dan juga anda pun boleh mengolahnya sendiri di tempatmu. soto ayam santan kara bisa dimasak lewat beraneka cara. Sekarang telah banyak sekali resep kekinian yang menjadikan soto ayam santan kara semakin lebih nikmat.

Resep soto ayam santan kara pun gampang sekali dibikin, lho. Kalian tidak usah repot-repot untuk membeli soto ayam santan kara, karena Kalian bisa membuatnya ditempatmu. Untuk Kalian yang hendak membuatnya, di bawah ini adalah cara membuat soto ayam santan kara yang nikamat yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Santan Kara:

1. Ambil 1/2 ekor ayam
1. Gunakan  Isian soto: kol, tauge, tomat, kentang, jeruk nipis, emping
1. Siapkan  Bumbu halus:
1. Gunakan 10 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Ambil 3 buah kemiri
1. Siapkan 1 ruas kunyit
1. Sediakan 1 ruas jahe
1. Siapkan 1 sdt ketumbar
1. Siapkan 1 sdt lada
1. Gunakan 1 sdt jinten
1. Ambil 1 gelas kecil air
1. Gunakan  Bumbu Cemplung:
1. Siapkan 1 liter air
1. Gunakan 2 lembar daun salam
1. Ambil 3 lembar daun jeruk
1. Ambil 1 serai digeprek
1. Siapkan 1 ruas lengkuas digeprek
1. Siapkan 1/4 bulatan biji pala
1. Siapkan 3 buah bunga
1. Sediakan secukupnya Daun bawang
1. Sediakan 1 sachet santan kara kecil
1. Gunakan secukupnya Gula, msg, Royco




<!--inarticleads2-->

##### Cara membuat Soto Ayam Santan Kara:

1. Blender semua bumbu halus, kemudian tumis sampai air menyusut dan bumbu keluar minyak dan benar2 matang
1. Cuci bersih ayam, potong2. Panaskan panci masukkan semua bumbu Cemplung (kecuali santan dan daun bawang) beserta ayam, dan masukkan bumbu halus yg sudah ditumis tadi. Bila ayam sudah setengah matang angkat lalu goreng ayam. Sisihkan suwir2
1. Masukkan santan ke dalam panci tunggu sampai mendidih sambil diaduk2. Koreksi rasa, masukkan daun bawang dan jadi deh.
1. Potong2 isian soto, rebus tauge, dan goreng kentang (empingnya lupa di foto)
1. Cara buat sambal: 31 cabe rawit direbus, ulek dengan msg kasih beberapa tetes jeruk nipis. (Ga perlu dikasih garam)




Ternyata cara buat soto ayam santan kara yang lezat simple ini mudah sekali ya! Kamu semua dapat membuatnya. Cara Membuat soto ayam santan kara Sangat cocok sekali buat kalian yang baru akan belajar memasak ataupun untuk anda yang sudah hebat memasak.

Apakah kamu ingin mulai mencoba buat resep soto ayam santan kara mantab sederhana ini? Kalau anda tertarik, mending kamu segera siapin alat dan bahannya, lantas buat deh Resep soto ayam santan kara yang lezat dan simple ini. Benar-benar mudah kan. 

Oleh karena itu, daripada anda diam saja, maka langsung aja hidangkan resep soto ayam santan kara ini. Pasti kalian tiidak akan nyesel sudah membuat resep soto ayam santan kara lezat simple ini! Selamat mencoba dengan resep soto ayam santan kara nikmat tidak rumit ini di tempat tinggal sendiri,ya!.

