---
description: "Bahan-bahan Ayam Saus Padang yang enak Untuk Jualan"
title: "Bahan-bahan Ayam Saus Padang yang enak Untuk Jualan"
slug: 17-bahan-bahan-ayam-saus-padang-yang-enak-untuk-jualan
date: 2021-03-07T14:36:45.251Z
image: https://img-global.cpcdn.com/recipes/9e6dcf40f060aadd/680x482cq70/ayam-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9e6dcf40f060aadd/680x482cq70/ayam-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9e6dcf40f060aadd/680x482cq70/ayam-saus-padang-foto-resep-utama.jpg
author: Harriett McGee
ratingvalue: 4.8
reviewcount: 10
recipeingredient:
- "5 Potong Ayam"
- "1 Buah Jeruk Nipis"
- "1/2 Bawang Bombay uk besar"
- "4 Sdm Saus Sambal"
- "4 Sdm Saus Tomat"
- "2 Batang Daun Bawang"
- "4 Lembar Daun Jeruk"
- "Secukupnya Kaldu Ayam"
- "Secukupnya Garam"
- "Secukupnya Gula"
- "Secukupnya Lada Hitam"
- " Bumbu Halus"
- "4 Siung Bawang Putih"
- "8 Siung Bawang Merah"
- "3 Ruas Jahe"
- "4 Buah Cabe Rawit Merah"
- "4 Buah Cabe Merah Kriting"
recipeinstructions:
- "Bersihkan ayam, cuci hingga bersih kemudian marinasi dengan jeruk nipis dan garam untuk menghilangkan bau amis pada ayam. Diamkan 10 menit"
- "Setelah dimarinasi, tiriskan air yang ada direndaman ayam. Kemudian berikan lada hitam dan garam secukupnya. Diamkan kembali selama 20 menit"
- "Disaat yang bersamaan haluskan bawang merah, bawang putih, jahe, cabai merah &amp; rawit. Sedangkan bawang bombay, daun jeruk dan daun bawang diiris halus"
- "Goreng ayam yang telah dimarinasi dengan lada hitam dan garam hingga setengah matang &amp; tiriskan"
- "Setelah itu sisihkan minyak dari hasil menggoreng ayam untuk menumis bumbu yang sudah dihaluskan. Tumis bumbu hingga harum, kemudian masukan bawang bombay dan daun jeruk. Tunggu sampai aroma bawang bombay dan daun jeruk tercium."
- "Masukan saus sambal, saus tomat dan tambahkan sedikit air. Masukan juga secukupnya garam, kaldu ayam, lada hitam, dan gula. Setelah itu koreksi rasa dan tunggu sampai mendidih. Masukan daun bawang kemudian ayam yang sudah digoreng. Aduk sampai bumbunya rata nutupi ayam. Tunggu sampai bumbunya meresap (masak dengan api sedang)"
- "Setelah matang siap dihidangkan. Selamat makan!"
categories:
- Resep
tags:
- ayam
- saus
- padang

katakunci: ayam saus padang 
nutrition: 124 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Saus Padang](https://img-global.cpcdn.com/recipes/9e6dcf40f060aadd/680x482cq70/ayam-saus-padang-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan hidangan nikmat pada famili merupakan hal yang memuaskan untuk kita sendiri. Peran seorang istri Tidak hanya mengurus rumah saja, namun anda juga wajib memastikan kebutuhan gizi terpenuhi dan juga masakan yang dimakan orang tercinta harus mantab.

Di era  sekarang, kita memang mampu mengorder masakan yang sudah jadi meski tanpa harus ribet memasaknya dahulu. Tapi banyak juga lho mereka yang memang mau memberikan yang terenak bagi orang tercintanya. Pasalnya, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan keluarga tercinta. 



Mungkinkah kamu salah satu penikmat ayam saus padang?. Tahukah kamu, ayam saus padang adalah hidangan khas di Indonesia yang kini digemari oleh banyak orang dari hampir setiap tempat di Indonesia. Kita bisa membuat ayam saus padang buatan sendiri di rumah dan boleh jadi makanan favorit di hari liburmu.

Kita jangan bingung jika kamu ingin menyantap ayam saus padang, karena ayam saus padang mudah untuk ditemukan dan juga kita pun boleh memasaknya sendiri di rumah. ayam saus padang bisa dimasak memalui beraneka cara. Kini pun sudah banyak cara kekinian yang menjadikan ayam saus padang semakin lebih enak.

Resep ayam saus padang juga gampang dihidangkan, lho. Kita tidak usah ribet-ribet untuk memesan ayam saus padang, sebab Anda bisa menyiapkan ditempatmu. Bagi Kita yang mau menyajikannya, di bawah ini adalah resep menyajikan ayam saus padang yang mantab yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Saus Padang:

1. Gunakan 5 Potong Ayam
1. Gunakan 1 Buah Jeruk Nipis
1. Gunakan 1/2 Bawang Bombay (uk. besar)
1. Ambil 4 Sdm Saus Sambal
1. Sediakan 4 Sdm Saus Tomat
1. Ambil 2 Batang Daun Bawang
1. Siapkan 4 Lembar Daun Jeruk
1. Gunakan Secukupnya Kaldu Ayam
1. Siapkan Secukupnya Garam
1. Sediakan Secukupnya Gula
1. Sediakan Secukupnya Lada Hitam
1. Ambil  Bumbu Halus
1. Gunakan 4 Siung Bawang Putih
1. Siapkan 8 Siung Bawang Merah
1. Siapkan 3 Ruas Jahe
1. Ambil 4 Buah Cabe Rawit Merah
1. Sediakan 4 Buah Cabe Merah Kriting




<!--inarticleads2-->

##### Cara menyiapkan Ayam Saus Padang:

1. Bersihkan ayam, cuci hingga bersih kemudian marinasi dengan jeruk nipis dan garam untuk menghilangkan bau amis pada ayam. Diamkan 10 menit
1. Setelah dimarinasi, tiriskan air yang ada direndaman ayam. Kemudian berikan lada hitam dan garam secukupnya. Diamkan kembali selama 20 menit
1. Disaat yang bersamaan haluskan bawang merah, bawang putih, jahe, cabai merah &amp; rawit. Sedangkan bawang bombay, daun jeruk dan daun bawang diiris halus
1. Goreng ayam yang telah dimarinasi dengan lada hitam dan garam hingga setengah matang &amp; tiriskan
1. Setelah itu sisihkan minyak dari hasil menggoreng ayam untuk menumis bumbu yang sudah dihaluskan. Tumis bumbu hingga harum, kemudian masukan bawang bombay dan daun jeruk. Tunggu sampai aroma bawang bombay dan daun jeruk tercium.
1. Masukan saus sambal, saus tomat dan tambahkan sedikit air. Masukan juga secukupnya garam, kaldu ayam, lada hitam, dan gula. Setelah itu koreksi rasa dan tunggu sampai mendidih. Masukan daun bawang kemudian ayam yang sudah digoreng. Aduk sampai bumbunya rata nutupi ayam. Tunggu sampai bumbunya meresap (masak dengan api sedang)
1. Setelah matang siap dihidangkan. Selamat makan!




Wah ternyata cara buat ayam saus padang yang lezat tidak rumit ini gampang sekali ya! Kalian semua bisa memasaknya. Cara buat ayam saus padang Cocok sekali buat kalian yang baru mau belajar memasak ataupun juga bagi kamu yang sudah lihai memasak.

Tertarik untuk mulai mencoba buat resep ayam saus padang nikmat tidak rumit ini? Kalau kamu ingin, ayo kalian segera buruan siapin alat dan bahannya, kemudian buat deh Resep ayam saus padang yang nikmat dan tidak ribet ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kamu berfikir lama-lama, hayo langsung aja buat resep ayam saus padang ini. Pasti anda tak akan menyesal sudah membuat resep ayam saus padang lezat tidak rumit ini! Selamat mencoba dengan resep ayam saus padang lezat sederhana ini di tempat tinggal masing-masing,ya!.

