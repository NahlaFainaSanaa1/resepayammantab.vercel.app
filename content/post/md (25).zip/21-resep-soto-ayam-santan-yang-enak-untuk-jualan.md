---
description: "Resep Soto Ayam Santan yang enak Untuk Jualan"
title: "Resep Soto Ayam Santan yang enak Untuk Jualan"
slug: 21-resep-soto-ayam-santan-yang-enak-untuk-jualan
date: 2021-02-18T17:55:54.882Z
image: https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Ophelia Burns
ratingvalue: 4.4
reviewcount: 9
recipeingredient:
- "1 kg dada ayam bagusnya yg fillet"
- "250 ml Santan kara ukuran"
- " Garam kaldu jamur"
- " Air untuk merebus"
- " Pelengkap"
- " Kentang potong dadu goreng"
- " Toge rebus"
- " Kol optional"
- "iris Daun bawang dan seledri"
- " Telur rebus"
- " Bawang goreng untuk taburan"
- "potong dadu Tomat"
- " Bumbu halus"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "8 buah kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdm ketumbar"
- "Secukupnya lada"
- " Bumbu cemplung"
- "5 lembar daun salam"
- "5 lembar daun jeruk"
- "2 buah serai"
- "1 ruas Laos geprek"
recipeinstructions:
- "Bersihkan ayam. Sisihkan"
- "Didihkan air, beserta daun salam dan serai. Masukan ayam."
- "Sambil merebus ayam. Tumis bumbu halus sampai wangi, tambahkan daun jeruk. Setelah bumbu matang, masukan bumbu kedalam rebusan air yang berisi ayam. Biarkan bumbu meresap dan ayam empuk"
- "Angkat ayam, goreng sebentar lalu suwir kasar (optional..kalo ga mau di goreng bisa langsung di suwir)"
- "Dalam air rebusan ayam tadi, masukan santan kara. Biarkan mendidih. Masukan garam dan kaldu jamur. Test rasa"
- "Sajikan soto bersama pelengkapnya."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 207 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan hidangan mantab bagi orang tercinta adalah suatu hal yang membahagiakan untuk kita sendiri. Kewajiban seorang ibu bukan saja menjaga rumah saja, tetapi anda pun wajib memastikan kebutuhan gizi tercukupi dan santapan yang disantap orang tercinta wajib lezat.

Di zaman  sekarang, kita sebenarnya mampu mengorder santapan siap saji meski tidak harus susah mengolahnya terlebih dahulu. Namun ada juga lho mereka yang memang mau memberikan hidangan yang terlezat bagi orang yang dicintainya. Lantaran, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan selera keluarga tercinta. 



Mungkinkah anda seorang penyuka soto ayam santan?. Asal kamu tahu, soto ayam santan adalah makanan khas di Indonesia yang sekarang disukai oleh kebanyakan orang di hampir setiap tempat di Indonesia. Kalian dapat menghidangkan soto ayam santan sendiri di rumah dan pasti jadi makanan kegemaranmu di akhir pekanmu.

Kamu tak perlu bingung jika kamu ingin menyantap soto ayam santan, karena soto ayam santan tidak sulit untuk ditemukan dan juga kalian pun bisa membuatnya sendiri di tempatmu. soto ayam santan bisa diolah dengan beraneka cara. Kini sudah banyak cara kekinian yang membuat soto ayam santan semakin mantap.

Resep soto ayam santan pun mudah sekali untuk dibikin, lho. Kita jangan ribet-ribet untuk membeli soto ayam santan, sebab Kita dapat menyiapkan ditempatmu. Untuk Kita yang akan mencobanya, berikut ini resep untuk menyajikan soto ayam santan yang enak yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Santan:

1. Siapkan 1 kg dada ayam (bagusnya yg fillet)
1. Gunakan 250 ml Santan kara ukuran
1. Sediakan  Garam, kaldu jamur
1. Sediakan  Air untuk merebus
1. Siapkan  Pelengkap
1. Ambil  Kentang potong dadu, goreng
1. Ambil  Toge rebus
1. Siapkan  Kol (optional)
1. Siapkan iris Daun bawang dan seledri
1. Ambil  Telur rebus
1. Siapkan  Bawang goreng untuk taburan
1. Siapkan potong dadu Tomat
1. Ambil  Bumbu halus
1. Sediakan 4 siung bawang putih
1. Ambil 7 siung bawang merah
1. Siapkan 8 buah kemiri
1. Siapkan 1 ruas jahe
1. Ambil 1 ruas kunyit
1. Sediakan 1 sdm ketumbar
1. Sediakan Secukupnya lada
1. Gunakan  Bumbu cemplung
1. Gunakan 5 lembar daun salam
1. Ambil 5 lembar daun jeruk
1. Sediakan 2 buah serai
1. Ambil 1 ruas Laos geprek




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Santan:

1. Bersihkan ayam. Sisihkan
1. Didihkan air, beserta daun salam dan serai. Masukan ayam.
1. Sambil merebus ayam. Tumis bumbu halus sampai wangi, tambahkan daun jeruk. Setelah bumbu matang, masukan bumbu kedalam rebusan air yang berisi ayam. Biarkan bumbu meresap dan ayam empuk
1. Angkat ayam, goreng sebentar lalu suwir kasar (optional..kalo ga mau di goreng bisa langsung di suwir)
1. Dalam air rebusan ayam tadi, masukan santan kara. Biarkan mendidih. Masukan garam dan kaldu jamur. Test rasa
1. Sajikan soto bersama pelengkapnya.




Ternyata cara buat soto ayam santan yang lezat tidak ribet ini mudah sekali ya! Kita semua dapat menghidangkannya. Resep soto ayam santan Sangat sesuai sekali buat anda yang baru belajar memasak atau juga untuk anda yang sudah lihai dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep soto ayam santan enak sederhana ini? Kalau mau, mending kamu segera siapkan alat-alat dan bahannya, lantas buat deh Resep soto ayam santan yang nikmat dan simple ini. Betul-betul taidak sulit kan. 

Jadi, ketimbang kalian berlama-lama, yuk kita langsung saja hidangkan resep soto ayam santan ini. Dijamin anda gak akan menyesal bikin resep soto ayam santan nikmat sederhana ini! Selamat mencoba dengan resep soto ayam santan lezat tidak ribet ini di tempat tinggal sendiri,ya!.

