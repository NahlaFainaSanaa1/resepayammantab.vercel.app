---
description: "Cara membuat Soto Ayam Kuah Santan yang lezat Untuk Jualan"
title: "Cara membuat Soto Ayam Kuah Santan yang lezat Untuk Jualan"
slug: 39-cara-membuat-soto-ayam-kuah-santan-yang-lezat-untuk-jualan
date: 2021-01-11T19:06:04.405Z
image: https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg
author: Lina Hale
ratingvalue: 4.8
reviewcount: 3
recipeingredient:
- "1/2 kg ayam"
- "1 bks kara santan"
- "1,5 liter air"
- "1 batang sereh"
- "1 ruas lengkuas"
- "2 lembar daun salam"
- "5 lembar daun jeruk"
- "1 tomat"
- "2 daun bawang"
- "Secukupnya bawang goreng"
- "2 jeruk limau"
- "1/2 sdt garam"
- "1 sdm gula"
- " Bumbu halus "
- "5 bawang putih"
- "10 bawang merah"
- "2 ruas kunyit"
- "3 kemiri"
- "1/2 sdt lada"
recipeinstructions:
- "Tumis bumbu halus hingga harum, tambahkan sereh, lengkuas, daun salam, daun jeruk."
- "Masukkan ayam yang telah dicuci bersih dan dipotong*.Tambahkan air, biarkan meresap dan ayam lunak."
- "Masukkan santan, garam, kaldu, gula. Aduk rata, jangan lupa koreksi rasa."
- "Jika sudah, siapkan mangkuk, masukkan kuah, beri potongan tomat, daun bawang, bawang goreng, perasan jeruk limau dan sajikan."
categories:
- Resep
tags:
- soto
- ayam
- kuah

katakunci: soto ayam kuah 
nutrition: 201 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Ayam Kuah Santan](https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan masakan sedap bagi keluarga merupakan suatu hal yang menggembirakan bagi kita sendiri. Tugas seorang istri bukan hanya mengerjakan pekerjaan rumah saja, namun kamu pun harus memastikan keperluan nutrisi terpenuhi dan juga panganan yang disantap orang tercinta harus sedap.

Di masa  sekarang, anda sebenarnya bisa memesan masakan praktis tidak harus susah mengolahnya terlebih dahulu. Tapi ada juga mereka yang memang mau menghidangkan yang terbaik untuk orang tercintanya. Pasalnya, memasak yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai dengan kesukaan famili. 



Apakah kamu seorang penikmat soto ayam kuah santan?. Asal kamu tahu, soto ayam kuah santan adalah hidangan khas di Nusantara yang saat ini disenangi oleh banyak orang dari berbagai wilayah di Indonesia. Anda bisa menyajikan soto ayam kuah santan sendiri di rumahmu dan pasti jadi hidangan favorit di hari liburmu.

Kalian jangan bingung jika kamu ingin mendapatkan soto ayam kuah santan, sebab soto ayam kuah santan mudah untuk didapatkan dan juga kita pun bisa membuatnya sendiri di tempatmu. soto ayam kuah santan bisa diolah dengan beraneka cara. Kini pun sudah banyak cara kekinian yang menjadikan soto ayam kuah santan semakin lebih nikmat.

Resep soto ayam kuah santan pun sangat mudah dihidangkan, lho. Kita jangan repot-repot untuk membeli soto ayam kuah santan, lantaran Kamu mampu membuatnya ditempatmu. Untuk Kita yang hendak menghidangkannya, di bawah ini adalah cara menyajikan soto ayam kuah santan yang enak yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Kuah Santan:

1. Sediakan 1/2 kg ayam
1. Gunakan 1 bks kara santan
1. Ambil 1,5 liter air
1. Sediakan 1 batang sereh
1. Gunakan 1 ruas lengkuas
1. Ambil 2 lembar daun salam
1. Ambil 5 lembar daun jeruk
1. Ambil 1 tomat
1. Siapkan 2 daun bawang
1. Siapkan Secukupnya bawang goreng
1. Gunakan 2 jeruk limau
1. Ambil 1/2 sdt garam
1. Ambil 1 sdm gula
1. Sediakan  Bumbu halus :
1. Sediakan 5 bawang putih
1. Siapkan 10 bawang merah
1. Gunakan 2 ruas kunyit
1. Gunakan 3 kemiri
1. Siapkan 1/2 sdt lada




<!--inarticleads2-->

##### Cara membuat Soto Ayam Kuah Santan:

1. Tumis bumbu halus hingga harum, tambahkan sereh, lengkuas, daun salam, daun jeruk.
1. Masukkan ayam yang telah dicuci bersih dan dipotong*.Tambahkan air, biarkan meresap dan ayam lunak.
1. Masukkan santan, garam, kaldu, gula. Aduk rata, jangan lupa koreksi rasa.
1. Jika sudah, siapkan mangkuk, masukkan kuah, beri potongan tomat, daun bawang, bawang goreng, perasan jeruk limau dan sajikan.




Wah ternyata cara buat soto ayam kuah santan yang lezat tidak ribet ini gampang sekali ya! Kita semua dapat memasaknya. Cara Membuat soto ayam kuah santan Cocok sekali untuk anda yang baru belajar memasak maupun juga bagi anda yang telah ahli memasak.

Apakah kamu tertarik mulai mencoba buat resep soto ayam kuah santan enak sederhana ini? Kalau mau, mending kamu segera buruan siapin alat-alat dan bahannya, kemudian bikin deh Resep soto ayam kuah santan yang lezat dan tidak ribet ini. Benar-benar taidak sulit kan. 

Jadi, daripada anda berlama-lama, maka kita langsung hidangkan resep soto ayam kuah santan ini. Dijamin kalian tiidak akan menyesal sudah membuat resep soto ayam kuah santan nikmat simple ini! Selamat mencoba dengan resep soto ayam kuah santan enak simple ini di tempat tinggal sendiri,ya!.

