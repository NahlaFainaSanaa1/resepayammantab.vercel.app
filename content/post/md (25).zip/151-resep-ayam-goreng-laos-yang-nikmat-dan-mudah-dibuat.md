---
description: "Resep Ayam Goreng Laos yang nikmat dan Mudah Dibuat"
title: "Resep Ayam Goreng Laos yang nikmat dan Mudah Dibuat"
slug: 151-resep-ayam-goreng-laos-yang-nikmat-dan-mudah-dibuat
date: 2021-06-07T17:58:12.195Z
image: https://img-global.cpcdn.com/recipes/0517d172539db14b/680x482cq70/ayam-goreng-laos-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0517d172539db14b/680x482cq70/ayam-goreng-laos-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0517d172539db14b/680x482cq70/ayam-goreng-laos-foto-resep-utama.jpg
author: Edwin Barber
ratingvalue: 3.8
reviewcount: 8
recipeingredient:
- "2 ekor ayam kampung potong2"
- "3 btg serai geprek"
- "8 lbr daun jeruk"
- " Gula"
- " Merica"
- " Garam"
- " Royco"
- "350 gr laos muda di parut kurang lebih"
- "  Bumbu halus "
- "12 btr bwg merah"
- "8 btr bwg putih"
- "1,5 sdm ketumbar"
- "6 btr kemiri"
- "Sejempol jahe"
- "Seruas kunyit"
recipeinstructions:
- "Lumuri ayam dg jeruk nipis, diamkan sebentar, lalu cuci hingga bersih, tiriskan"
- "Taruh ayam dalam wajan, tuang semua bumbu &amp; tambahkan air secukupnya. Ungkep ayam hingga empuk &amp; bumbu meresap. Matikan api, biarkan ayam dalam wajan"
- "Setelah dingin, angkat ayam, pisahkan dari bumbu laosnya. Klo bumbunya masih cukup basah, masak lagi hingga airnya kering menguap sambil di aduk2, dinginkan. Simpan ayam &amp; bumbu dalam kulkas"
- "Cara menggoreng : goreng ayam hingga kuning kecoklatan, angkat, tiriskan, kemudian lanjut goreng bumbu laos hingga kering, angkat, tiriskan, tabur di atas ayam. Sajikan"
categories:
- Resep
tags:
- ayam
- goreng
- laos

katakunci: ayam goreng laos 
nutrition: 285 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Goreng Laos](https://img-global.cpcdn.com/recipes/0517d172539db14b/680x482cq70/ayam-goreng-laos-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan olahan lezat pada orang tercinta adalah hal yang menyenangkan bagi kita sendiri. Kewajiban seorang  wanita bukan cuman menjaga rumah saja, tapi anda juga wajib menyediakan keperluan nutrisi tercukupi dan juga hidangan yang dimakan orang tercinta harus lezat.

Di masa  sekarang, kalian sebenarnya mampu membeli santapan yang sudah jadi walaupun tanpa harus susah membuatnya lebih dulu. Tapi ada juga lho orang yang memang mau menyajikan yang terbaik bagi keluarganya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan keluarga. 



Apakah anda salah satu penggemar ayam goreng laos?. Asal kamu tahu, ayam goreng laos merupakan sajian khas di Nusantara yang saat ini disukai oleh kebanyakan orang di berbagai daerah di Nusantara. Kamu dapat menyajikan ayam goreng laos kreasi sendiri di rumahmu dan dapat dijadikan hidangan kesenanganmu di akhir pekan.

Kalian jangan bingung jika kamu ingin memakan ayam goreng laos, karena ayam goreng laos gampang untuk dicari dan juga kita pun boleh mengolahnya sendiri di rumah. ayam goreng laos bisa dibuat lewat berbagai cara. Sekarang ada banyak sekali resep modern yang membuat ayam goreng laos semakin lebih lezat.

Resep ayam goreng laos pun gampang dibuat, lho. Anda tidak perlu ribet-ribet untuk memesan ayam goreng laos, lantaran Kalian bisa menyajikan sendiri di rumah. Bagi Kamu yang akan menghidangkannya, di bawah ini adalah resep untuk menyajikan ayam goreng laos yang lezat yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Goreng Laos:

1. Sediakan 2 ekor ayam kampung, potong2
1. Siapkan 3 btg serai, geprek
1. Gunakan 8 lbr daun jeruk
1. Siapkan  Gula
1. Siapkan  Merica
1. Ambil  Garam
1. Ambil  Royco
1. Siapkan 350 gr laos muda, di parut (kurang lebih)
1. Sediakan  🌸 Bumbu halus :
1. Siapkan 12 btr bwg merah
1. Siapkan 8 btr bwg putih
1. Siapkan 1,5 sdm ketumbar
1. Ambil 6 btr kemiri
1. Sediakan Sejempol jahe
1. Gunakan Seruas kunyit




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Goreng Laos:

1. Lumuri ayam dg jeruk nipis, diamkan sebentar, lalu cuci hingga bersih, tiriskan
1. Taruh ayam dalam wajan, tuang semua bumbu &amp; tambahkan air secukupnya. Ungkep ayam hingga empuk &amp; bumbu meresap. Matikan api, biarkan ayam dalam wajan
1. Setelah dingin, angkat ayam, pisahkan dari bumbu laosnya. Klo bumbunya masih cukup basah, masak lagi hingga airnya kering menguap sambil di aduk2, dinginkan. Simpan ayam &amp; bumbu dalam kulkas
1. Cara menggoreng : goreng ayam hingga kuning kecoklatan, angkat, tiriskan, kemudian lanjut goreng bumbu laos hingga kering, angkat, tiriskan, tabur di atas ayam. Sajikan




Ternyata cara membuat ayam goreng laos yang enak simple ini enteng sekali ya! Anda Semua dapat membuatnya. Cara buat ayam goreng laos Cocok banget untuk anda yang baru akan belajar memasak ataupun bagi kamu yang telah lihai dalam memasak.

Tertarik untuk mencoba bikin resep ayam goreng laos lezat tidak ribet ini? Kalau kalian mau, mending kamu segera buruan menyiapkan alat dan bahannya, lantas bikin deh Resep ayam goreng laos yang lezat dan simple ini. Benar-benar gampang kan. 

Jadi, daripada anda diam saja, maka langsung aja bikin resep ayam goreng laos ini. Dijamin kamu gak akan nyesel sudah bikin resep ayam goreng laos nikmat tidak ribet ini! Selamat berkreasi dengan resep ayam goreng laos nikmat sederhana ini di tempat tinggal masing-masing,ya!.

