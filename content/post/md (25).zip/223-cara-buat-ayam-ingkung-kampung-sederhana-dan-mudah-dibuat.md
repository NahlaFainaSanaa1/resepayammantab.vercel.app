---
description: "Cara buat Ayam Ingkung Kampung Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam Ingkung Kampung Sederhana dan Mudah Dibuat"
slug: 223-cara-buat-ayam-ingkung-kampung-sederhana-dan-mudah-dibuat
date: 2021-05-10T08:07:24.608Z
image: https://img-global.cpcdn.com/recipes/73c765a3056913bd/680x482cq70/ayam-ingkung-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/73c765a3056913bd/680x482cq70/ayam-ingkung-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/73c765a3056913bd/680x482cq70/ayam-ingkung-kampung-foto-resep-utama.jpg
author: Virginia Daniel
ratingvalue: 3.1
reviewcount: 11
recipeingredient:
- "1 ekor ayam kampung           lihat tips"
- "1 sdt garam"
- "1/2 buah jeruk lemon"
- " "
- "1 ruas jahe geprek"
- "1 ruas lengkuas geprek"
- "2 batang serai geprek"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "1 keping (40 gram) gula merah"
- "1/2 sdm garam"
- "65 ml santan instant"
- "200 ml air"
- "2 sdm minyak untuk menumis"
- " Bumbu halus"
- "10 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas kunyit sangrai"
- "4 biji kemiri sangrai"
- "1 sdm ketumbar"
- " Pelengkap"
- " Sambal           lihat resep"
- " Selada"
- " Timun"
recipeinstructions:
- "Ayam di bersihkan, kemudian lumuri jeruk lemon dan garam, diamkan sebentar kemudian cuci bersihkan. Sangrai kunyit dan kemiri, Haluskan bumbu yg di haluskan.           (lihat tips)"
- "Lengkuas, jahe dan sereh di geprek, sisihkan. Tumis bumbu halus tambahkan daun jeruk, salam, sereh, lengkuas dan jahe, gula merah dan garam"
- "Masukkan ayam, aduk rata, tambahkan air dan santan. Masak hingga air menyusut. Tata diatas loyang, panaskan oven selama 15 menit dengan suhu 180*"
- "Panggang selama 30 menit. Angkat dan siap sajikan dengan sambal dan aneka lalapan😋           (lihat resep)"
categories:
- Resep
tags:
- ayam
- ingkung
- kampung

katakunci: ayam ingkung kampung 
nutrition: 289 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Ingkung Kampung](https://img-global.cpcdn.com/recipes/73c765a3056913bd/680x482cq70/ayam-ingkung-kampung-foto-resep-utama.jpg)

Andai kalian seorang istri, mempersiapkan hidangan mantab buat famili merupakan suatu hal yang memuaskan bagi anda sendiri. Tugas seorang istri bukan saja mengerjakan pekerjaan rumah saja, tetapi anda juga harus menyediakan keperluan gizi tercukupi dan panganan yang dikonsumsi anak-anak harus nikmat.

Di waktu  sekarang, kita sebenarnya dapat membeli masakan instan meski tanpa harus ribet mengolahnya terlebih dahulu. Tetapi ada juga mereka yang selalu ingin memberikan hidangan yang terbaik untuk keluarganya. Sebab, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan famili. 



Mungkinkah anda merupakan salah satu penyuka ayam ingkung kampung?. Tahukah kamu, ayam ingkung kampung adalah makanan khas di Nusantara yang kini disenangi oleh orang-orang di berbagai daerah di Indonesia. Kalian bisa memasak ayam ingkung kampung sendiri di rumahmu dan boleh dijadikan hidangan kegemaranmu di akhir pekanmu.

Kalian tidak usah bingung untuk menyantap ayam ingkung kampung, sebab ayam ingkung kampung sangat mudah untuk ditemukan dan juga kalian pun boleh membuatnya sendiri di rumah. ayam ingkung kampung dapat dimasak lewat bermacam cara. Kini sudah banyak cara modern yang menjadikan ayam ingkung kampung lebih lezat.

Resep ayam ingkung kampung juga gampang untuk dibikin, lho. Kalian jangan ribet-ribet untuk membeli ayam ingkung kampung, tetapi Kalian mampu menghidangkan ditempatmu. Untuk Anda yang mau menyajikannya, inilah cara membuat ayam ingkung kampung yang nikamat yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Ingkung Kampung:

1. Siapkan 1 ekor ayam kampung           (lihat tips)
1. Ambil 1 sdt garam
1. Sediakan 1/2 buah jeruk lemon
1. Siapkan  ——————————————
1. Sediakan 1 ruas jahe geprek
1. Ambil 1 ruas lengkuas geprek
1. Gunakan 2 batang serai geprek
1. Gunakan 2 lembar daun salam
1. Gunakan 4 lembar daun jeruk
1. Gunakan 1 keping (40 gram) gula merah
1. Sediakan 1/2 sdm garam
1. Sediakan 65 ml santan instant
1. Sediakan 200 ml air
1. Ambil 2 sdm minyak untuk menumis
1. Ambil  Bumbu halus
1. Siapkan 10 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Siapkan 1 ruas kunyit sangrai
1. Ambil 4 biji kemiri sangrai
1. Ambil 1 sdm ketumbar
1. Ambil  Pelengkap
1. Gunakan  Sambal           (lihat resep)
1. Ambil  Selada
1. Ambil  Timun




<!--inarticleads2-->

##### Cara membuat Ayam Ingkung Kampung:

1. Ayam di bersihkan, kemudian lumuri jeruk lemon dan garam, diamkan sebentar kemudian cuci bersihkan. Sangrai kunyit dan kemiri, Haluskan bumbu yg di haluskan. -           (lihat tips)
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Ingkung Kampung">1. Lengkuas, jahe dan sereh di geprek, sisihkan. Tumis bumbu halus tambahkan daun jeruk, salam, sereh, lengkuas dan jahe, gula merah dan garam
1. Masukkan ayam, aduk rata, tambahkan air dan santan. Masak hingga air menyusut. Tata diatas loyang, panaskan oven selama 15 menit dengan suhu 180*
1. Panggang selama 30 menit. Angkat dan siap sajikan dengan sambal dan aneka lalapan😋 -           (lihat resep)




Ternyata resep ayam ingkung kampung yang mantab tidak rumit ini enteng banget ya! Anda Semua mampu menghidangkannya. Resep ayam ingkung kampung Sangat sesuai sekali buat kita yang baru belajar memasak maupun juga untuk kamu yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam ingkung kampung mantab simple ini? Kalau kamu ingin, ayo kalian segera siapkan alat-alat dan bahannya, lantas buat deh Resep ayam ingkung kampung yang nikmat dan tidak rumit ini. Benar-benar gampang kan. 

Jadi, ketimbang kamu berfikir lama-lama, hayo kita langsung saja bikin resep ayam ingkung kampung ini. Pasti anda tak akan nyesel sudah buat resep ayam ingkung kampung lezat tidak rumit ini! Selamat berkreasi dengan resep ayam ingkung kampung enak tidak rumit ini di rumah kalian masing-masing,oke!.

