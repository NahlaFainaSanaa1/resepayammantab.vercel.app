---
description: "Cara membuat Ayam goreng laos (lengkuas) yang lezat Untuk Jualan"
title: "Cara membuat Ayam goreng laos (lengkuas) yang lezat Untuk Jualan"
slug: 143-cara-membuat-ayam-goreng-laos-lengkuas-yang-lezat-untuk-jualan
date: 2021-02-28T04:35:37.762Z
image: https://img-global.cpcdn.com/recipes/5ebafef71299c1c5/680x482cq70/ayam-goreng-laos-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5ebafef71299c1c5/680x482cq70/ayam-goreng-laos-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5ebafef71299c1c5/680x482cq70/ayam-goreng-laos-lengkuas-foto-resep-utama.jpg
author: Claudia Perry
ratingvalue: 3
reviewcount: 13
recipeingredient:
- " Ayam bagian dada dan paha"
- " Laos parut beli jadi di pasar 5rb  kurleb 3 laos size sedang"
- " Air"
- " Garam"
- " Lada"
- " Gula"
- " Kaldu jamur totole"
- " Bumbu halus"
- "4 siung bawang putih"
- "6 siung bawang merah"
- "5 buah kemiri"
- "1 ruas kunir ukuran sedang"
- "1 ruas jahe ukuran sedang"
- "1 sdt ketumbar"
- " Bahan pelengkap"
- "3 lembar daun salam"
- "2 lembar daun jeruk"
- "2 batang serai geprek"
- "1 ruas laos geprek"
recipeinstructions:
- "Cuci bersih ayam"
- "Haluskan semua bumbu halus yang tertera"
- "Parut lengkuas kemudian sisihkan (saya beli di pasar yg sudah tinggal pakai)"
- "Panaskan minyak goreng,Tumis bumbu halus &amp; laos hingga sedikit layu kemudian tambahkan bumbu pelengkap tumis hingga harum dan layu"
- "Tambahkan bumbu seperti garam,gula,lada,dan kaldu sesuai selera"
- "Jika di rasa sudah masak masukan ayam yg sudah di cuci bersih kemudian bolak balik hingga ayam mengeluarkan minyak"
- "Tambahkan sedikit air sesuai selera, ungkep hingga air menyusut,sesekali di bolak balik ayam nya"
- "Jika sudah menyusut, matikan api goreng ayam terlebih dahulu sampa kering menggunakan api sedang"
- "Setelah selesai ayam di goreng, kemudain sisa bumbu ungkepan di saring hingga tidak ada air kemudian goreng jgn sampai gosong"
- "Setelah matang tabur gorengan bumbu rempah di atas ayam,cocok di sajika menggunakan nasi liwet,sayur dan sambal padang (sambal hijau)"
categories:
- Resep
tags:
- ayam
- goreng
- laos

katakunci: ayam goreng laos 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam goreng laos (lengkuas)](https://img-global.cpcdn.com/recipes/5ebafef71299c1c5/680x482cq70/ayam-goreng-laos-lengkuas-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan santapan mantab untuk keluarga merupakan suatu hal yang memuaskan bagi kita sendiri. Kewajiban seorang  wanita Tidak cuma menangani rumah saja, tetapi anda juga wajib memastikan kebutuhan nutrisi tercukupi dan santapan yang disantap keluarga tercinta harus lezat.

Di zaman  saat ini, kita sebenarnya bisa mengorder masakan jadi walaupun tidak harus capek membuatnya lebih dulu. Tapi banyak juga lho orang yang memang ingin memberikan hidangan yang terenak untuk orang yang dicintainya. Lantaran, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan orang tercinta. 

Resep Ayam Goreng Lengkuas - Ayam goreng lengkuas merupakan salah satu kuliner khas Indonesia dengan citarasa masakan Sunda yang super enak dan lezat. Penggunaan lengkuas atau laos sangat berperan penting terhadap resep ayam goreng lengkuas yang akan dibuat. Demikian informasi yang dapat kami berikan mengenai salah satu masakan yang sedang trending ini.

Mungkinkah anda seorang penggemar ayam goreng laos (lengkuas)?. Asal kamu tahu, ayam goreng laos (lengkuas) adalah makanan khas di Nusantara yang kini disenangi oleh orang-orang dari hampir setiap daerah di Nusantara. Kamu bisa menyajikan ayam goreng laos (lengkuas) hasil sendiri di rumah dan boleh jadi hidangan kesenanganmu di akhir pekanmu.

Kita tidak usah bingung untuk menyantap ayam goreng laos (lengkuas), lantaran ayam goreng laos (lengkuas) tidak sukar untuk didapatkan dan juga kalian pun boleh memasaknya sendiri di tempatmu. ayam goreng laos (lengkuas) bisa dibuat dengan bermacam cara. Sekarang telah banyak sekali cara modern yang menjadikan ayam goreng laos (lengkuas) semakin nikmat.

Resep ayam goreng laos (lengkuas) juga mudah sekali dibikin, lho. Kalian tidak usah ribet-ribet untuk memesan ayam goreng laos (lengkuas), tetapi Kalian dapat membuatnya sendiri di rumah. Untuk Kita yang akan membuatnya, di bawah ini adalah cara membuat ayam goreng laos (lengkuas) yang mantab yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam goreng laos (lengkuas):

1. Sediakan  Ayam bagian dada dan paha
1. Gunakan  Laos parut (beli jadi di pasar 5rb) / kurleb 3 laos size sedang
1. Gunakan  Air
1. Sediakan  Garam
1. Ambil  Lada
1. Ambil  Gula
1. Ambil  Kaldu jamur totole
1. Gunakan  Bumbu halus
1. Gunakan 4 siung bawang putih
1. Ambil 6 siung bawang merah
1. Siapkan 5 buah kemiri
1. Ambil 1 ruas kunir ukuran sedang
1. Gunakan 1 ruas jahe ukuran sedang
1. Sediakan 1 sdt ketumbar
1. Ambil  Bahan pelengkap
1. Gunakan 3 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Siapkan 2 batang serai geprek
1. Sediakan 1 ruas laos geprek


Ayam Goreng Lengkuas, resep klasik bagi mereka yang mencari selingan selain serundeng ataupun kremes. Yuk, cari tahu cara membuatnya yuk! Resep Ayam Goreng Lengkuas, Tambah Sambal Lebih Nikmat! Simpan ke bagian favorit Tersimpan di bagian favorit. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam goreng laos (lengkuas):

1. Cuci bersih ayam
1. Haluskan semua bumbu halus yang tertera
1. Parut lengkuas kemudian sisihkan (saya beli di pasar yg sudah tinggal pakai)
1. Panaskan minyak goreng,Tumis bumbu halus &amp; laos hingga sedikit layu kemudian tambahkan bumbu pelengkap tumis hingga harum dan layu
1. Tambahkan bumbu seperti garam,gula,lada,dan kaldu sesuai selera
1. Jika di rasa sudah masak masukan ayam yg sudah di cuci bersih kemudian bolak balik hingga ayam mengeluarkan minyak
1. Tambahkan sedikit air sesuai selera, ungkep hingga air menyusut,sesekali di bolak balik ayam nya
1. Jika sudah menyusut, matikan api goreng ayam terlebih dahulu sampa kering menggunakan api sedang
1. Setelah selesai ayam di goreng, kemudain sisa bumbu ungkepan di saring hingga tidak ada air kemudian goreng jgn sampai gosong
1. Setelah matang tabur gorengan bumbu rempah di atas ayam,cocok di sajika menggunakan nasi liwet,sayur dan sambal padang (sambal hijau)


Sajian ayam goreng serundeng lengkuas atau yang sebagian menyebutkan ayam serundeng laos adalah sajian istimewa yang enak. Betapa tidak, rempah khas nusantara yang berkolaborasi dengan nikmatnya parutan lengkuas yang dicampur bersama bumbu lain dan digoreng hingga keriuk. Resep Ayam Goreng Lengkuas/Laos by: ig@mayasefry. Cara membuat ayam goreng lengkuas: Cuci bersih ayam lalu tiriskan. Dalam wadah campur bumbu halus, daun salam, daun jeruk, kaldu ayam bubuk dan garam. 

Ternyata resep ayam goreng laos (lengkuas) yang nikamt simple ini gampang banget ya! Semua orang bisa memasaknya. Cara buat ayam goreng laos (lengkuas) Sangat cocok sekali untuk kalian yang sedang belajar memasak maupun juga untuk anda yang telah lihai memasak.

Apakah kamu tertarik mencoba membuat resep ayam goreng laos (lengkuas) enak sederhana ini? Kalau anda mau, yuk kita segera buruan menyiapkan alat-alat dan bahan-bahannya, lantas bikin deh Resep ayam goreng laos (lengkuas) yang enak dan tidak rumit ini. Sungguh gampang kan. 

Maka dari itu, daripada anda berfikir lama-lama, hayo kita langsung saja hidangkan resep ayam goreng laos (lengkuas) ini. Pasti kalian tiidak akan nyesel sudah membuat resep ayam goreng laos (lengkuas) lezat tidak rumit ini! Selamat mencoba dengan resep ayam goreng laos (lengkuas) nikmat sederhana ini di tempat tinggal sendiri,oke!.

