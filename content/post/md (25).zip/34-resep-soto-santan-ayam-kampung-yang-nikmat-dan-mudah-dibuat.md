---
description: "Resep Soto santan ayam kampung yang nikmat dan Mudah Dibuat"
title: "Resep Soto santan ayam kampung yang nikmat dan Mudah Dibuat"
slug: 34-resep-soto-santan-ayam-kampung-yang-nikmat-dan-mudah-dibuat
date: 2021-06-28T10:34:47.283Z
image: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
author: Rosetta Holloway
ratingvalue: 3.9
reviewcount: 6
recipeingredient:
- "1/2 kg ayam kampung"
- "1 bks santan cair"
- " Bahan tambahan"
- "1/2 ons soun rebus"
- "1 rb toge rebus sbntr"
- "2 rb kol rebus sebentar"
- "4 btr telor ayam rebus 20 menit"
- "1 batang sledri iris kecil"
- "2 buah jeruk limo"
- "1 buah tomat iris kasar"
- "3 batang daun bawangb iris"
- " Bawang goreng untuk taburan"
- " Bumbu halus"
- "7 siung bawang merah"
- "6 siung bawang putih"
- "4 butir kemiri"
- "1 ruas jahe"
- "1/2 ruas kunyit"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt merica biji"
- "1/2 bks ketumbar biji 500 rupiah"
- "1/2 bks jinten 500 rupiah"
- "1/2 sdt pala biji"
- "3 butir cengkeh"
- "2 butir kapulaga"
- " Bumbu cemplung"
- "1 lmbr daun salam"
- "5 lmbr daun jeruk"
- "1 buah bunga lawang"
- "1/2 potong kayu manis"
- "1/2 ruas lengkuas"
- " Sambal nya"
- "10 biji cabe rawit merah"
- " Gulagaram"
- " Dibikin goang aja"
recipeinstructions:
- "Cuci bersih ayam nya potong2 sesuai keinginan"
- "Didihkan air dan klau sdh bersih ayam ny tinggal masukan ke rebusan air tadi geplek diapi sedang slma 20 menit lalu matikan kompor ny"
- "Haluskan bumbunya boleh pkai blender atau manual aja pke coet biar wanginya nampol klo diulek sendiri mah."
- "Kalo sudah halus semua siapkan minyak di ketel tumis2 hingga harum dan klo dah setengah mateng masukan bumbu cemplung nya dan aduk2 sampe mateng dan kalo sudah mateng kasih air sedikit aja segelas misal ny"
- "Lalu hidup kan lg kompor yg ayam tdi lalu masukan si bumbu ke ayam ny bila kurang air nya boleh tambah lg sesuai selera aja dan koreksi rasa ya bun"
- "Kalo sudah siap siapkan mangkok dan masukan soto nya tata semua bahan tambahan nya.maaf aku juga pke suwiran ayam lgi biar enak aj😁"
- "Siap dihidangkan deh bunda2"
categories:
- Resep
tags:
- soto
- santan
- ayam

katakunci: soto santan ayam 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto santan ayam kampung](https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan masakan mantab untuk orang tercinta adalah suatu hal yang memuaskan untuk kamu sendiri. Peran seorang  wanita bukan saja menangani rumah saja, tetapi anda pun harus menyediakan keperluan gizi tercukupi dan juga santapan yang disantap orang tercinta mesti enak.

Di era  sekarang, kamu memang mampu memesan santapan yang sudah jadi tidak harus capek mengolahnya lebih dulu. Namun banyak juga mereka yang memang mau menyajikan yang terlezat untuk keluarganya. Karena, menyajikan masakan yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan berdasarkan kesukaan keluarga tercinta. 



Apakah kamu salah satu penyuka soto santan ayam kampung?. Asal kamu tahu, soto santan ayam kampung adalah hidangan khas di Nusantara yang sekarang disukai oleh orang-orang dari berbagai daerah di Nusantara. Kalian dapat membuat soto santan ayam kampung sendiri di rumah dan boleh dijadikan camilan kegemaranmu di akhir pekanmu.

Kamu tidak perlu bingung jika kamu ingin mendapatkan soto santan ayam kampung, sebab soto santan ayam kampung tidak sulit untuk didapatkan dan juga kalian pun bisa mengolahnya sendiri di rumah. soto santan ayam kampung boleh dimasak dengan beragam cara. Kini pun sudah banyak sekali resep kekinian yang membuat soto santan ayam kampung lebih enak.

Resep soto santan ayam kampung pun gampang sekali untuk dibuat, lho. Anda tidak usah repot-repot untuk memesan soto santan ayam kampung, tetapi Kita dapat membuatnya di rumah sendiri. Bagi Kamu yang mau membuatnya, inilah resep membuat soto santan ayam kampung yang enak yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Soto santan ayam kampung:

1. Gunakan 1/2 kg ayam kampung
1. Siapkan 1 bks santan cair
1. Sediakan  Bahan tambahan
1. Ambil 1/2 ons soun rebus
1. Sediakan 1 rb toge rebus sbntr
1. Sediakan 2 rb kol rebus sebentar
1. Ambil 4 btr telor ayam rebus 20 menit
1. Sediakan 1 batang sledri iris kecil
1. Gunakan 2 buah jeruk limo
1. Siapkan 1 buah tomat iris kasar
1. Sediakan 3 batang daun bawangb iris
1. Gunakan  Bawang goreng untuk taburan
1. Ambil  Bumbu halus
1. Siapkan 7 siung bawang merah
1. Ambil 6 siung bawang putih
1. Sediakan 4 butir kemiri
1. Sediakan 1 ruas jahe
1. Siapkan 1/2 ruas kunyit
1. Gunakan 1/2 sdt kunyit bubuk
1. Siapkan 1/2 sdt merica biji
1. Ambil 1/2 bks ketumbar biji 500 rupiah
1. Gunakan 1/2 bks jinten 500 rupiah
1. Ambil 1/2 sdt pala biji
1. Gunakan 3 butir cengkeh
1. Siapkan 2 butir kapulaga
1. Gunakan  Bumbu cemplung
1. Ambil 1 lmbr daun salam
1. Ambil 5 lmbr daun jeruk
1. Ambil 1 buah bunga lawang
1. Siapkan 1/2 potong kayu manis
1. Gunakan 1/2 ruas lengkuas
1. Gunakan  Sambal nya
1. Siapkan 10 biji cabe rawit merah
1. Siapkan  Gula+garam
1. Ambil  Dibikin goang aja👍🏻




<!--inarticleads2-->

##### Cara membuat Soto santan ayam kampung:

1. Cuci bersih ayam nya potong2 sesuai keinginan
1. Didihkan air dan klau sdh bersih ayam ny tinggal masukan ke rebusan air tadi geplek diapi sedang slma 20 menit lalu matikan kompor ny
1. Haluskan bumbunya boleh pkai blender atau manual aja pke coet biar wanginya nampol klo diulek sendiri mah.
1. Kalo sudah halus semua siapkan minyak di ketel tumis2 hingga harum dan klo dah setengah mateng masukan bumbu cemplung nya dan aduk2 sampe mateng dan kalo sudah mateng kasih air sedikit aja segelas misal ny
1. Lalu hidup kan lg kompor yg ayam tdi lalu masukan si bumbu ke ayam ny bila kurang air nya boleh tambah lg sesuai selera aja dan koreksi rasa ya bun
1. Kalo sudah siap siapkan mangkok dan masukan soto nya tata semua bahan tambahan nya.maaf aku juga pke suwiran ayam lgi biar enak aj😁
1. Siap dihidangkan deh bunda2




Ternyata resep soto santan ayam kampung yang nikamt tidak ribet ini mudah banget ya! Semua orang dapat memasaknya. Cara Membuat soto santan ayam kampung Sangat sesuai banget untuk kalian yang baru mau belajar memasak ataupun juga untuk kalian yang telah lihai memasak.

Tertarik untuk mulai mencoba membuat resep soto santan ayam kampung mantab tidak rumit ini? Kalau mau, ayo kalian segera siapin alat dan bahannya, lalu buat deh Resep soto santan ayam kampung yang nikmat dan tidak ribet ini. Sangat gampang kan. 

Oleh karena itu, ketimbang kamu berfikir lama-lama, ayo kita langsung saja buat resep soto santan ayam kampung ini. Pasti kalian tak akan nyesel bikin resep soto santan ayam kampung mantab simple ini! Selamat mencoba dengan resep soto santan ayam kampung enak tidak rumit ini di tempat tinggal sendiri,oke!.

