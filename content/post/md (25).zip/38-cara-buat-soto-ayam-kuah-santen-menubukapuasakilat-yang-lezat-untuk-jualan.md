---
description: "Cara buat Soto Ayam Kuah Santen #MenuBukaPuasaKilat yang lezat Untuk Jualan"
title: "Cara buat Soto Ayam Kuah Santen #MenuBukaPuasaKilat yang lezat Untuk Jualan"
slug: 38-cara-buat-soto-ayam-kuah-santen-menubukapuasakilat-yang-lezat-untuk-jualan
date: 2021-03-30T09:16:52.136Z
image: https://img-global.cpcdn.com/recipes/28af21f6f489f9a3/680x482cq70/soto-ayam-kuah-santen-menubukapuasakilat-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/28af21f6f489f9a3/680x482cq70/soto-ayam-kuah-santen-menubukapuasakilat-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/28af21f6f489f9a3/680x482cq70/soto-ayam-kuah-santen-menubukapuasakilat-foto-resep-utama.jpg
author: Ray McLaughlin
ratingvalue: 3
reviewcount: 8
recipeingredient:
- " Topping"
- "1/4 kg dada ayam pake paha jg bisa tp saya pakai dada agar matang lebih cepat"
- "1/4 buah kol iris"
- "1 papan bihun jagung rebus"
- "3 buah tomat iris"
- "1 helai daun bawang iris"
- "1 helai seledriiris"
- "Secukupnya bawang goreng"
- "4 butir telur rebus"
- " Bumbu kuah"
- "10 butir bawang putih"
- "6 butir bawang merah"
- "1 ruas jahe"
- "1 ruas lengkuaslaos iris geprek"
- "1 ruas sereh geprek"
- "1 sdt bubuk kemiri3 butir kemiri sangrai"
- "1 sdt ketumbar bubuk"
- "1 sdt kunyit bubuk  1 ruas kunyit"
- "1 sdt lada bubuk"
- "1 batang sereh"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "2 butir bunga lawang"
- "3 buah cengkeh"
- "1/2 sdt garam"
- "1 sdt gula"
- "Secukupnya Kaldu bubuk saya pakai totole"
- " Minyak untuk menumis"
- "1 liter air"
- "65 ml santan kemasan"
- " Bahan sambal"
- "15 butir cabe rawit"
- "2 butir bawang putih"
- "Sedikit garam"
- " Jeruk nipis"
recipeinstructions:
- "Rebus ayam sebentar, lalu ganti airnya (air rebusan kedua), rebus sampai daging cukup empuk. Saring kalo masih ada gelembung2 sisa kotorannya."
- "Blender bawang merah + bawang putih + jahe (kalau gak punya kemiri&amp;kunyit bubuk, blender juga, kalau saya pake yg bubuk jadi masukin nanti). Tumis dengan minyak bersama sereh, lengkuas geprek, daun salam dan daun jeruk. Masukkan ketumbar bubuk, kunyit bubuk, kemiri bubuk, lada bubuk dan gula. Aduk sampai harum + bumbu matang."
- "Masukkan tumisan bumbu ke dalam air rebusan ayam tadi. Masukkan bunga lawang dan cengkeh. Masukkan garam, kaldu bubuk. Kalau sudah mendidih masukkan santan. Tunggu matang, Koreksi rasa. (Kalau lg puasa yaaa kira2 aja yaaa hehe)"
- "Untuk sambal cukup rebus cabe+bawang putih, lalu haluskan. Tambah sedikit garam+jeruk nipis peras."
- "Siapkan topping : rebusan bihun, irisan kol direbus sebentar, irisan tomat, irisan daun bawang + seledri, potongan telur dan suwiran ayam yg sudah “diungkep” bareng kuah tadi. Platting di mangkok lalu guyur dengan kuah yg sudah matang, taburkan bawang goreng. Sajikan bersama sambal+kecap+jeruk nipis dan nasi hangat."
categories:
- Resep
tags:
- soto
- ayam
- kuah

katakunci: soto ayam kuah 
nutrition: 122 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dessert

---


![Soto Ayam Kuah Santen #MenuBukaPuasaKilat](https://img-global.cpcdn.com/recipes/28af21f6f489f9a3/680x482cq70/soto-ayam-kuah-santen-menubukapuasakilat-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan santapan nikmat buat keluarga tercinta merupakan hal yang memuaskan bagi kamu sendiri. Kewajiban seorang  wanita bukan hanya menangani rumah saja, tetapi anda juga harus menyediakan kebutuhan nutrisi tercukupi dan juga masakan yang dimakan anak-anak wajib nikmat.

Di waktu  sekarang, anda memang mampu memesan panganan siap saji tidak harus repot mengolahnya lebih dulu. Tetapi banyak juga lho mereka yang memang mau memberikan hidangan yang terlezat bagi orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan berdasarkan masakan kesukaan keluarga tercinta. 



Apakah kamu seorang penyuka soto ayam kuah santen #menubukapuasakilat?. Asal kamu tahu, soto ayam kuah santen #menubukapuasakilat adalah makanan khas di Nusantara yang saat ini digemari oleh banyak orang dari berbagai tempat di Indonesia. Kita dapat menyajikan soto ayam kuah santen #menubukapuasakilat kreasi sendiri di rumahmu dan boleh dijadikan hidangan kesenanganmu di akhir pekan.

Anda tidak usah bingung jika kamu ingin memakan soto ayam kuah santen #menubukapuasakilat, karena soto ayam kuah santen #menubukapuasakilat gampang untuk ditemukan dan anda pun bisa mengolahnya sendiri di tempatmu. soto ayam kuah santen #menubukapuasakilat bisa diolah dengan beragam cara. Kini pun sudah banyak cara modern yang membuat soto ayam kuah santen #menubukapuasakilat lebih mantap.

Resep soto ayam kuah santen #menubukapuasakilat juga mudah dihidangkan, lho. Kita tidak usah capek-capek untuk memesan soto ayam kuah santen #menubukapuasakilat, lantaran Kita mampu membuatnya di rumahmu. Bagi Kalian yang akan membuatnya, berikut ini resep menyajikan soto ayam kuah santen #menubukapuasakilat yang enak yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Soto Ayam Kuah Santen #MenuBukaPuasaKilat:

1. Ambil  Topping:
1. Sediakan 1/4 kg dada ayam (pake paha jg bisa, tp saya pakai dada agar matang lebih cepat)
1. Gunakan 1/4 buah kol, iris
1. Sediakan 1 papan bihun jagung, rebus
1. Siapkan 3 buah tomat, iris
1. Sediakan 1 helai daun bawang, iris
1. Gunakan 1 helai seledri,iris
1. Siapkan Secukupnya bawang goreng
1. Gunakan 4 butir telur rebus
1. Sediakan  Bumbu kuah:
1. Siapkan 10 butir bawang putih
1. Siapkan 6 butir bawang merah
1. Siapkan 1 ruas jahe
1. Ambil 1 ruas lengkuas/laos, iris geprek
1. Gunakan 1 ruas sereh, geprek
1. Siapkan 1 sdt bubuk kemiri/3 butir kemiri sangrai
1. Sediakan 1 sdt ketumbar bubuk
1. Siapkan 1 sdt kunyit bubuk / 1 ruas kunyit
1. Siapkan 1 sdt lada bubuk
1. Ambil 1 batang sereh
1. Siapkan 2 lembar daun salam
1. Sediakan 4 lembar daun jeruk
1. Siapkan 2 butir bunga lawang
1. Sediakan 3 buah cengkeh
1. Sediakan 1/2 sdt garam
1. Gunakan 1 sdt gula
1. Siapkan Secukupnya Kaldu bubuk (saya pakai totole)
1. Siapkan  Minyak untuk menumis
1. Gunakan 1 liter air
1. Ambil 65 ml santan kemasan
1. Gunakan  Bahan sambal:
1. Siapkan 15 butir cabe rawit
1. Siapkan 2 butir bawang putih
1. Siapkan Sedikit garam
1. Sediakan  Jeruk nipis




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Kuah Santen #MenuBukaPuasaKilat:

1. Rebus ayam sebentar, lalu ganti airnya (air rebusan kedua), rebus sampai daging cukup empuk. Saring kalo masih ada gelembung2 sisa kotorannya.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Soto Ayam Kuah Santen #MenuBukaPuasaKilat">1. Blender bawang merah + bawang putih + jahe (kalau gak punya kemiri&amp;kunyit bubuk, blender juga, kalau saya pake yg bubuk jadi masukin nanti). - Tumis dengan minyak bersama sereh, lengkuas geprek, daun salam dan daun jeruk. Masukkan ketumbar bubuk, kunyit bubuk, kemiri bubuk, lada bubuk dan gula. Aduk sampai harum + bumbu matang.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Soto Ayam Kuah Santen #MenuBukaPuasaKilat">1. Masukkan tumisan bumbu ke dalam air rebusan ayam tadi. Masukkan bunga lawang dan cengkeh. Masukkan garam, kaldu bubuk. Kalau sudah mendidih masukkan santan. Tunggu matang, Koreksi rasa. (Kalau lg puasa yaaa kira2 aja yaaa hehe)
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Soto Ayam Kuah Santen #MenuBukaPuasaKilat">1. Untuk sambal cukup rebus cabe+bawang putih, lalu haluskan. Tambah sedikit garam+jeruk nipis peras.
1. Siapkan topping : rebusan bihun, irisan kol direbus sebentar, irisan tomat, irisan daun bawang + seledri, potongan telur dan suwiran ayam yg sudah “diungkep” bareng kuah tadi. Platting di mangkok lalu guyur dengan kuah yg sudah matang, taburkan bawang goreng. Sajikan bersama sambal+kecap+jeruk nipis dan nasi hangat.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Soto Ayam Kuah Santen #MenuBukaPuasaKilat">



Ternyata cara buat soto ayam kuah santen #menubukapuasakilat yang mantab sederhana ini mudah banget ya! Anda Semua bisa memasaknya. Cara buat soto ayam kuah santen #menubukapuasakilat Cocok sekali untuk anda yang baru mau belajar memasak maupun juga untuk kalian yang telah ahli memasak.

Tertarik untuk mulai mencoba membuat resep soto ayam kuah santen #menubukapuasakilat lezat sederhana ini? Kalau kalian tertarik, ayo kalian segera buruan siapin alat-alat dan bahan-bahannya, lalu bikin deh Resep soto ayam kuah santen #menubukapuasakilat yang lezat dan tidak rumit ini. Sungguh mudah kan. 

Maka dari itu, ketimbang kamu berlama-lama, maka kita langsung buat resep soto ayam kuah santen #menubukapuasakilat ini. Pasti kamu tiidak akan menyesal sudah buat resep soto ayam kuah santen #menubukapuasakilat enak tidak ribet ini! Selamat berkreasi dengan resep soto ayam kuah santen #menubukapuasakilat nikmat sederhana ini di tempat tinggal masing-masing,oke!.

