---
description: "Cara buat 82. Ayam &amp;amp; Hati Masak Merah (Habang) Sederhana dan Mudah Dibuat"
title: "Cara buat 82. Ayam &amp;amp; Hati Masak Merah (Habang) Sederhana dan Mudah Dibuat"
slug: 467-cara-buat-82-ayam-and-amp-hati-masak-merah-habang-sederhana-dan-mudah-dibuat
date: 2021-03-23T08:54:41.806Z
image: https://img-global.cpcdn.com/recipes/e24f8cbb7a4f960b/680x482cq70/82-ayam-hati-masak-merah-habang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e24f8cbb7a4f960b/680x482cq70/82-ayam-hati-masak-merah-habang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e24f8cbb7a4f960b/680x482cq70/82-ayam-hati-masak-merah-habang-foto-resep-utama.jpg
author: Ernest Marsh
ratingvalue: 4.4
reviewcount: 6
recipeingredient:
- "500 gr dada ayam"
- "4 pasang hati empelo"
- " Bumbu marinasi "
- "1 siung besar bawang putih"
- "1 potong kunir"
- "1 sdt garam"
- "Secukupnya minyak goreng"
- " Bumbu masak merah "
- "Secukupnya garam gula pasir gula merah kaldu bubuk royco"
- "200 ml air"
- "200 gr bumbu habang merah Bisa beli           lihat resep"
recipeinstructions:
- "Potong ayam sesuai selera, cuci bersih bersama hati empelo. Sisihkan"
- "Ulek halus bumbunya"
- "Masukkan bumbu halus ke wadah ayam. Aduk rata. Marinasi ayam selama 20 menit"
- "Goreng ayam, hati emplo sampai masak. Jangan sampai kering. Angkat lalu sisihkan"
- "Siapkan ayam dan bumbu habang"
- "Panaskan bumbu habang, masukkan ayam goreng dan hati empelo. Tambahkan air. Masak sampai airnya susut"
- "Jika air sudah susut tambahkan garam, gula pasir, gula merah dan kaldu bubuk. Aduk rata dan lanjutkan memasak"
- "Setelah kuahnya kental, cicipi rasanya. Jika sudah pas rasa asin dan manisnya, matikan kompornya"
- "Angkat. Pindahkan ke mangkok saji. Alhamdulillah ayam &amp; hati masak habang siap disajikan"
categories:
- Resep
tags:
- 82
- ayam
- 

katakunci: 82 ayam  
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dessert

---


![82. Ayam &amp; Hati Masak Merah (Habang)](https://img-global.cpcdn.com/recipes/e24f8cbb7a4f960b/680x482cq70/82-ayam-hati-masak-merah-habang-foto-resep-utama.jpg)

Apabila kita seorang istri, menyuguhkan santapan mantab bagi famili merupakan suatu hal yang menggembirakan untuk kamu sendiri. Tanggung jawab seorang ibu bukan sekadar mengerjakan pekerjaan rumah saja, tapi kamu juga wajib menyediakan keperluan nutrisi tercukupi dan panganan yang dimakan keluarga tercinta wajib enak.

Di waktu  saat ini, kalian memang mampu mengorder hidangan jadi walaupun tidak harus capek membuatnya dahulu. Tetapi ada juga lho orang yang memang mau memberikan hidangan yang terenak untuk orang tercintanya. Karena, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan famili. 



Apakah anda adalah salah satu penyuka 82. ayam &amp; hati masak merah (habang)?. Asal kamu tahu, 82. ayam &amp; hati masak merah (habang) adalah sajian khas di Nusantara yang saat ini digemari oleh banyak orang dari hampir setiap daerah di Indonesia. Kita dapat menghidangkan 82. ayam &amp; hati masak merah (habang) sendiri di rumahmu dan boleh jadi hidangan favoritmu di hari liburmu.

Kamu tak perlu bingung jika kamu ingin memakan 82. ayam &amp; hati masak merah (habang), karena 82. ayam &amp; hati masak merah (habang) sangat mudah untuk ditemukan dan kita pun boleh memasaknya sendiri di rumah. 82. ayam &amp; hati masak merah (habang) bisa diolah dengan beragam cara. Sekarang telah banyak cara kekinian yang menjadikan 82. ayam &amp; hati masak merah (habang) semakin lebih mantap.

Resep 82. ayam &amp; hati masak merah (habang) pun gampang sekali dihidangkan, lho. Anda jangan repot-repot untuk memesan 82. ayam &amp; hati masak merah (habang), sebab Kalian bisa menyiapkan di rumahmu. Untuk Kalian yang hendak menghidangkannya, dibawah ini merupakan cara untuk membuat 82. ayam &amp; hati masak merah (habang) yang nikamat yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan 82. Ayam &amp; Hati Masak Merah (Habang):

1. Siapkan 500 gr dada ayam
1. Sediakan 4 pasang hati empelo
1. Gunakan  Bumbu marinasi :
1. Sediakan 1 siung besar bawang putih
1. Siapkan 1 potong kunir
1. Ambil 1 sdt garam
1. Ambil Secukupnya minyak goreng
1. Sediakan  Bumbu masak merah :
1. Ambil Secukupnya garam, gula pasir, gula merah, kaldu bubuk royco
1. Sediakan 200 ml air
1. Sediakan 200 gr bumbu habang /merah. Bisa beli           (lihat resep)




<!--inarticleads2-->

##### Cara membuat 82. Ayam &amp; Hati Masak Merah (Habang):

1. Potong ayam sesuai selera, cuci bersih bersama hati empelo. Sisihkan
1. Ulek halus bumbunya
1. Masukkan bumbu halus ke wadah ayam. Aduk rata. Marinasi ayam selama 20 menit
1. Goreng ayam, hati emplo sampai masak. Jangan sampai kering. Angkat lalu sisihkan
1. Siapkan ayam dan bumbu habang
1. Panaskan bumbu habang, masukkan ayam goreng dan hati empelo. Tambahkan air. Masak sampai airnya susut
1. Jika air sudah susut tambahkan garam, gula pasir, gula merah dan kaldu bubuk. Aduk rata dan lanjutkan memasak
1. Setelah kuahnya kental, cicipi rasanya. Jika sudah pas rasa asin dan manisnya, matikan kompornya
1. Angkat. Pindahkan ke mangkok saji. Alhamdulillah ayam &amp; hati masak habang siap disajikan




Ternyata cara membuat 82. ayam &amp; hati masak merah (habang) yang enak sederhana ini gampang banget ya! Kamu semua bisa mencobanya. Cara Membuat 82. ayam &amp; hati masak merah (habang) Sangat cocok banget buat kalian yang baru belajar memasak ataupun untuk anda yang sudah jago memasak.

Tertarik untuk mulai mencoba buat resep 82. ayam &amp; hati masak merah (habang) nikmat tidak ribet ini? Kalau kamu mau, mending kamu segera siapin alat-alat dan bahan-bahannya, lantas buat deh Resep 82. ayam &amp; hati masak merah (habang) yang mantab dan tidak rumit ini. Benar-benar taidak sulit kan. 

Jadi, daripada kita diam saja, hayo kita langsung saja sajikan resep 82. ayam &amp; hati masak merah (habang) ini. Dijamin kalian tiidak akan nyesel membuat resep 82. ayam &amp; hati masak merah (habang) mantab tidak rumit ini! Selamat berkreasi dengan resep 82. ayam &amp; hati masak merah (habang) lezat sederhana ini di rumah sendiri,oke!.

