---
description: "Cara membuat Nasi Daun Jeruk &amp;amp; Ayam Goreng Krispi + Sambal Korek yang nikmat dan Mudah Dibuat"
title: "Cara membuat Nasi Daun Jeruk &amp;amp; Ayam Goreng Krispi + Sambal Korek yang nikmat dan Mudah Dibuat"
slug: 297-cara-membuat-nasi-daun-jeruk-and-amp-ayam-goreng-krispi-sambal-korek-yang-nikmat-dan-mudah-dibuat
date: 2021-01-31T23:12:16.118Z
image: https://img-global.cpcdn.com/recipes/194cafe81f2c0164/680x482cq70/nasi-daun-jeruk-ayam-goreng-krispi-sambal-korek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/194cafe81f2c0164/680x482cq70/nasi-daun-jeruk-ayam-goreng-krispi-sambal-korek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/194cafe81f2c0164/680x482cq70/nasi-daun-jeruk-ayam-goreng-krispi-sambal-korek-foto-resep-utama.jpg
author: Celia Rios
ratingvalue: 4.1
reviewcount: 13
recipeingredient:
- " Nasi Daun Jeruk"
- "2 porsi Nasi putih"
- "Secukupnya Bawang putih"
- "Secukupnya daun jeruk"
- "Secukupnya minyak untuk menumis"
- "1 sdt margarin"
- " Ayam Goreng Krispi"
- "1/2 kg Paha ayam fillet"
- " Tepung bumbu serbaguna"
- "1 bowl air untuk dipping"
- "Secukupnya garam lada kecap ikan kecap inggris bawang putih bubuk cabe bubuk untuk marinasi"
- " Sambal Korek"
- "9 buah cabe rawit"
- "4-5 butir bawang merah"
- "1 butir bawang putih"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya penyedap"
recipeinstructions:
- "Panaskan minyak, haluskan bahan untuk sambal, setelah itu tuang minyak panas secukupnya"
- "Marinasi ayam dengan bahan tersebut diatas selama kurang lbh 30 menit, lumuri dengan tepung bumbu, celupkan ke dalam air sebentar menggunakan saringan, kemudian lumuri kembali dengan tepung, goreng sampai golden brown."
- "Panaskan minyak untuk menumis bawang putih cincang, dan daun jeruk yang telah diiris tipis sampai harum, tambahkan margarin, aduk-aduk hingga tercampur rata, matikan kompor, kemudian masukkan nasi putih, aduk hingga tercampur rata."
- "Siapkan bowl, tambahkan nasi daun jeruk, susun rapi ayam goreng, kemudian tambahkan sambal korek diatasnya."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 135 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dessert

---


![Nasi Daun Jeruk &amp; Ayam Goreng Krispi + Sambal Korek](https://img-global.cpcdn.com/recipes/194cafe81f2c0164/680x482cq70/nasi-daun-jeruk-ayam-goreng-krispi-sambal-korek-foto-resep-utama.jpg)

Andai kamu seorang istri, menyuguhkan panganan nikmat kepada famili adalah hal yang memuaskan bagi kita sendiri. Peran seorang ibu Tidak saja mengatur rumah saja, tetapi anda pun harus memastikan keperluan gizi tercukupi dan juga olahan yang dikonsumsi anak-anak harus nikmat.

Di masa  sekarang, kalian sebenarnya dapat mengorder olahan siap saji tidak harus susah mengolahnya dulu. Tapi ada juga mereka yang selalu mau memberikan yang terbaik untuk orang yang dicintainya. Sebab, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut berdasarkan selera keluarga tercinta. 



Apakah kamu seorang penggemar nasi daun jeruk &amp; ayam goreng krispi + sambal korek?. Tahukah kamu, nasi daun jeruk &amp; ayam goreng krispi + sambal korek adalah hidangan khas di Indonesia yang saat ini disukai oleh kebanyakan orang di hampir setiap wilayah di Indonesia. Kita bisa menyajikan nasi daun jeruk &amp; ayam goreng krispi + sambal korek hasil sendiri di rumahmu dan pasti jadi hidangan favoritmu di hari liburmu.

Kalian tidak usah bingung untuk menyantap nasi daun jeruk &amp; ayam goreng krispi + sambal korek, lantaran nasi daun jeruk &amp; ayam goreng krispi + sambal korek sangat mudah untuk ditemukan dan juga kalian pun bisa menghidangkannya sendiri di rumah. nasi daun jeruk &amp; ayam goreng krispi + sambal korek boleh dibuat lewat beragam cara. Saat ini telah banyak sekali cara modern yang menjadikan nasi daun jeruk &amp; ayam goreng krispi + sambal korek semakin enak.

Resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek pun sangat mudah untuk dibuat, lho. Kalian jangan repot-repot untuk membeli nasi daun jeruk &amp; ayam goreng krispi + sambal korek, tetapi Kamu mampu menyiapkan sendiri di rumah. Untuk Kalian yang akan membuatnya, berikut ini cara membuat nasi daun jeruk &amp; ayam goreng krispi + sambal korek yang mantab yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Nasi Daun Jeruk &amp; Ayam Goreng Krispi + Sambal Korek:

1. Ambil  Nasi Daun Jeruk
1. Sediakan 2 porsi Nasi putih
1. Siapkan Secukupnya Bawang putih
1. Siapkan Secukupnya daun jeruk
1. Ambil Secukupnya minyak untuk menumis
1. Ambil 1 sdt margarin
1. Siapkan  Ayam Goreng Krispi
1. Siapkan 1/2 kg Paha ayam fillet
1. Siapkan  Tepung bumbu serbaguna
1. Siapkan 1 bowl air untuk dipping
1. Siapkan Secukupnya garam, lada, kecap ikan, kecap inggris, bawang putih bubuk, cabe bubuk untuk marinasi
1. Ambil  Sambal Korek
1. Siapkan 9 buah cabe rawit
1. Gunakan 4-5 butir bawang merah
1. Sediakan 1 butir bawang putih
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya gula
1. Ambil Secukupnya penyedap




<!--inarticleads2-->

##### Langkah-langkah membuat Nasi Daun Jeruk &amp; Ayam Goreng Krispi + Sambal Korek:

1. Panaskan minyak, haluskan bahan untuk sambal, setelah itu tuang minyak panas secukupnya
1. Marinasi ayam dengan bahan tersebut diatas selama kurang lbh 30 menit, lumuri dengan tepung bumbu, celupkan ke dalam air sebentar menggunakan saringan, kemudian lumuri kembali dengan tepung, goreng sampai golden brown.
1. Panaskan minyak untuk menumis bawang putih cincang, dan daun jeruk yang telah diiris tipis sampai harum, tambahkan margarin, aduk-aduk hingga tercampur rata, matikan kompor, kemudian masukkan nasi putih, aduk hingga tercampur rata.
1. Siapkan bowl, tambahkan nasi daun jeruk, susun rapi ayam goreng, kemudian tambahkan sambal korek diatasnya.




Wah ternyata resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek yang lezat sederhana ini enteng sekali ya! Kita semua mampu membuatnya. Resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek Sesuai banget buat kita yang baru mau belajar memasak ataupun untuk kamu yang telah pandai memasak.

Tertarik untuk mulai mencoba bikin resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek lezat sederhana ini? Kalau ingin, yuk kita segera siapkan alat dan bahannya, lantas bikin deh Resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek yang lezat dan tidak rumit ini. Sangat taidak sulit kan. 

Maka dari itu, ketimbang kita diam saja, hayo kita langsung bikin resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek ini. Pasti kalian tiidak akan nyesel bikin resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek nikmat sederhana ini! Selamat mencoba dengan resep nasi daun jeruk &amp; ayam goreng krispi + sambal korek lezat tidak rumit ini di rumah sendiri,ya!.

