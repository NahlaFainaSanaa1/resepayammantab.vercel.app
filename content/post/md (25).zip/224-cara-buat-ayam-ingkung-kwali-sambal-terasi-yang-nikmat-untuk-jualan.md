---
description: "Cara buat Ayam Ingkung Kwali Sambal Terasi yang nikmat Untuk Jualan"
title: "Cara buat Ayam Ingkung Kwali Sambal Terasi yang nikmat Untuk Jualan"
slug: 224-cara-buat-ayam-ingkung-kwali-sambal-terasi-yang-nikmat-untuk-jualan
date: 2021-07-03T10:38:17.065Z
image: https://img-global.cpcdn.com/recipes/9b06e4b226bbe086/680x482cq70/ayam-ingkung-kwali-sambal-terasi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9b06e4b226bbe086/680x482cq70/ayam-ingkung-kwali-sambal-terasi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9b06e4b226bbe086/680x482cq70/ayam-ingkung-kwali-sambal-terasi-foto-resep-utama.jpg
author: Matilda Freeman
ratingvalue: 4.5
reviewcount: 3
recipeingredient:
- "1 ekor ayam kampung"
- "750 ml santan kental"
- "1 sendok makan gula merah"
- " Bumbu halus "
- "9 buah bawang merah"
- "6 siung bawang putih"
- "6 butir kemiri"
- "1 sendok makan ketumbar"
- "1/2 sendok teh garam sesuaikan"
- " Bahan lainnya dibagi dua untuk perut dan bumbu ayam "
- "10 lembar daun salam"
- "6 lembar daun jeruk"
- "4 batang sereh geprek"
- "4 ruas jahe geprek"
- "4 ruas lengkuas geprek"
- " Bahan areh "
- "200 ml santan kental"
- " Sisa bumbu ayam ingkung"
- "1/4 sendok teh garam sesuaikan"
- " Bahan sambal terasi "
- "10 buah cabe rawit sesuai selera"
- "5 buah cabe keriting"
- "1/2 sendok teh terasi bakar"
- "1/4 sendok teh garam sesuaikan"
recipeinstructions:
- "Bersihkan ayam, baluri ayam dengan bumbu marinasi, diamkan selama 15 menit."
- "Setelah 15 menit, siapkan 5 lembar daun salam, 3 lembar daun jeruk, 2 ruas jahe geprek, 2 ruas lengkuas geprek, 2 batang sereh geprek, garam, masukkan kedalam perut ayam, bersama hati dan ampelanya, ikat ayam dengan benang kasur supaya posisinya menyatu"
- "Haluskan bumbu, kemudian tumis bumbu halus bersama bumbu-bumbu lainnya sampai harum dan berminyak, masukkan santan, aduk-asuk sampai tercampur merata."
- "Masukkan ayam dalam kwali, siram ayam dengan 1/2 bumbu yang telah diberi santan tadi. Tutup kwali sampai bumbu meresap dan ayam matang, lebih kurang masak sampai 30 menit, kemudian balik ayamnya, tuang lagi 1/2 bumbu santannya sampai habis. Tutup kwali, biarkan mendidih dan airnya meresap ke dalam ayam sampai menyusut bumbu santannya. Ayamnya jangan sering-sering dibalik biar tidak hancur dagingnya. Setelah bumbu santan menyusut, angkat ayamnya, sisihkan."
- "Cara membuat areh : sisa kuah bumbu ayam campur dengan 200 ml santan kental, saring, kemudian masak sampai mendidih dan mengental, tambahkan garam jika kurang rasa."
- "Membuat sambal terasi : ulek/haluskan semua bahan sambal terasi."
- "Sajikan ayam ingkung kwali bersama sambal terasi."
categories:
- Resep
tags:
- ayam
- ingkung
- kwali

katakunci: ayam ingkung kwali 
nutrition: 121 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Ingkung Kwali Sambal Terasi](https://img-global.cpcdn.com/recipes/9b06e4b226bbe086/680x482cq70/ayam-ingkung-kwali-sambal-terasi-foto-resep-utama.jpg)

Apabila kalian seorang istri, menyajikan hidangan lezat untuk keluarga adalah suatu hal yang memuaskan bagi kita sendiri. Tanggung jawab seorang istri bukan sekadar mengurus rumah saja, namun kamu juga harus memastikan keperluan gizi terpenuhi dan olahan yang disantap keluarga tercinta wajib sedap.

Di era  sekarang, kalian sebenarnya dapat membeli masakan siap saji walaupun tanpa harus capek mengolahnya lebih dulu. Tetapi banyak juga lho orang yang memang mau memberikan makanan yang terlezat bagi orang tercintanya. Pasalnya, memasak yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai makanan kesukaan keluarga. 



Apakah anda adalah seorang penggemar ayam ingkung kwali sambal terasi?. Asal kamu tahu, ayam ingkung kwali sambal terasi merupakan sajian khas di Indonesia yang saat ini digemari oleh setiap orang di berbagai wilayah di Indonesia. Kalian bisa membuat ayam ingkung kwali sambal terasi sendiri di rumah dan boleh jadi hidangan kesukaanmu di akhir pekan.

Kalian tidak perlu bingung untuk memakan ayam ingkung kwali sambal terasi, sebab ayam ingkung kwali sambal terasi sangat mudah untuk ditemukan dan kamu pun dapat menghidangkannya sendiri di tempatmu. ayam ingkung kwali sambal terasi boleh dibuat lewat beragam cara. Saat ini telah banyak sekali cara kekinian yang menjadikan ayam ingkung kwali sambal terasi semakin lebih lezat.

Resep ayam ingkung kwali sambal terasi juga mudah sekali untuk dibuat, lho. Kalian jangan ribet-ribet untuk membeli ayam ingkung kwali sambal terasi, lantaran Kita dapat menghidangkan sendiri di rumah. Bagi Kamu yang ingin membuatnya, berikut ini resep untuk membuat ayam ingkung kwali sambal terasi yang enak yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Ingkung Kwali Sambal Terasi:

1. Siapkan 1 ekor ayam kampung
1. Gunakan 750 ml santan kental
1. Ambil 1 sendok makan gula merah
1. Gunakan  Bumbu halus :
1. Sediakan 9 buah bawang merah
1. Sediakan 6 siung bawang putih
1. Ambil 6 butir kemiri
1. Sediakan 1 sendok makan ketumbar
1. Ambil 1/2 sendok teh garam (sesuaikan)
1. Siapkan  Bahan lainnya dibagi dua untuk perut dan bumbu ayam :
1. Ambil 10 lembar daun salam
1. Sediakan 6 lembar daun jeruk
1. Siapkan 4 batang sereh geprek
1. Gunakan 4 ruas jahe geprek
1. Gunakan 4 ruas lengkuas geprek
1. Ambil  Bahan areh :
1. Sediakan 200 ml santan kental
1. Sediakan  Sisa bumbu ayam ingkung
1. Sediakan 1/4 sendok teh garam (sesuaikan)
1. Gunakan  Bahan sambal terasi :
1. Ambil 10 buah cabe rawit (sesuai selera)
1. Gunakan 5 buah cabe keriting
1. Sediakan 1/2 sendok teh terasi bakar
1. Gunakan 1/4 sendok teh garam (sesuaikan)




<!--inarticleads2-->

##### Cara menyiapkan Ayam Ingkung Kwali Sambal Terasi:

1. Bersihkan ayam, baluri ayam dengan bumbu marinasi, diamkan selama 15 menit.
1. Setelah 15 menit, siapkan 5 lembar daun salam, 3 lembar daun jeruk, 2 ruas jahe geprek, 2 ruas lengkuas geprek, 2 batang sereh geprek, garam, masukkan kedalam perut ayam, bersama hati dan ampelanya, ikat ayam dengan benang kasur supaya posisinya menyatu
1. Haluskan bumbu, kemudian tumis bumbu halus bersama bumbu-bumbu lainnya sampai harum dan berminyak, masukkan santan, aduk-asuk sampai tercampur merata.
1. Masukkan ayam dalam kwali, siram ayam dengan 1/2 bumbu yang telah diberi santan tadi. Tutup kwali sampai bumbu meresap dan ayam matang, lebih kurang masak sampai 30 menit, kemudian balik ayamnya, tuang lagi 1/2 bumbu santannya sampai habis. Tutup kwali, biarkan mendidih dan airnya meresap ke dalam ayam sampai menyusut bumbu santannya. Ayamnya jangan sering-sering dibalik biar tidak hancur dagingnya. Setelah bumbu santan menyusut, angkat ayamnya, sisihkan.
1. Cara membuat areh : sisa kuah bumbu ayam campur dengan 200 ml santan kental, saring, kemudian masak sampai mendidih dan mengental, tambahkan garam jika kurang rasa.
1. Membuat sambal terasi : ulek/haluskan semua bahan sambal terasi.
1. Sajikan ayam ingkung kwali bersama sambal terasi.




Wah ternyata resep ayam ingkung kwali sambal terasi yang lezat sederhana ini enteng banget ya! Kalian semua mampu menghidangkannya. Cara buat ayam ingkung kwali sambal terasi Cocok sekali untuk kita yang baru mau belajar memasak maupun juga untuk kamu yang sudah jago dalam memasak.

Apakah kamu ingin mulai mencoba membuat resep ayam ingkung kwali sambal terasi nikmat tidak ribet ini? Kalau kamu ingin, ayo kamu segera buruan siapkan alat dan bahan-bahannya, lalu bikin deh Resep ayam ingkung kwali sambal terasi yang mantab dan tidak ribet ini. Sungguh mudah kan. 

Maka, daripada kita diam saja, maka langsung aja sajikan resep ayam ingkung kwali sambal terasi ini. Dijamin anda gak akan menyesal sudah bikin resep ayam ingkung kwali sambal terasi nikmat sederhana ini! Selamat berkreasi dengan resep ayam ingkung kwali sambal terasi enak tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

