---
description: "Cara buat Opor ayam Sederhana dan Mudah Dibuat"
title: "Cara buat Opor ayam Sederhana dan Mudah Dibuat"
slug: 351-cara-buat-opor-ayam-sederhana-dan-mudah-dibuat
date: 2021-05-26T10:39:36.227Z
image: https://img-global.cpcdn.com/recipes/2cd2c045b8ed0c19/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2cd2c045b8ed0c19/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2cd2c045b8ed0c19/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Carrie Oliver
ratingvalue: 3
reviewcount: 3
recipeingredient:
- "1 ekor ayam ras potong 12"
- "1 kelapa buat 2 santan cair sama kental"
- "2 batang sereh geprek"
- "3 lembar daun salam"
- "1 saset penyedap rasa"
- "2 sdm gula pasir"
- " Bumbu halus "
- "13 s bamer"
- "7 s batih"
- "2 sdm ketumbar"
- "1 sdt merica"
- "4 lembar daun jeruk"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "4 butir kemiri"
- "1 saset santan kara"
- "1 gelas air"
recipeinstructions:
- "Siapkan bumbu yang akan di haluskan, bisa di blander atau di uleg, beri air."
- "Blander bumbu sampai halus"
- "Lalu siapkan ayam yang sudah di potong dan di bersihkan, lalu lumuri dengan bumbu, tambahkan sereh dan daun salam"
- "Lalu siapkan wajan, masukan ayam dan tutp hingga mendidih"
- "Setelah mendidih masukkan santan cair ke dalam masakan, tutup kembali tunggu sampai 20 menit dengan api besar."
- "Setelah 20 menit buka tutupnya dan masukkan santan kental, aduk lalu bumbui dengan garam, gula, penyedap rasa. Tutup kembali dan masak selama 15 menit."
- "Setelah itu matikan kompor, diamkan tunggu sampai 15 menit"
- "Setelah itu nyalakan kembali kompor dan masak menggunakan api kecil, cek rasa sekiranya sudah pas dengan lidah kita, kita tutup kembali masak sampai 15 menit."
- "Setelah itu diamkan jangan di buka tutupnya, sampai dingin"
- "Di jamin ayam nya empuk banget bun, ini karena masaknya tidak di presto ya, yee siap deh di santap di jamin mantabbbbbz, selamat mencoba"
- "Catatan aja nie bun"
- "20 menit masak pertama, matikan lalu diamkan 15 menit, masak kembali 15 menit, terahir matikan kompor diamkan jangan di buka tutupnya, di jamin ayam empuk sempurna"
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Opor ayam](https://img-global.cpcdn.com/recipes/2cd2c045b8ed0c19/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan olahan menggugah selera buat keluarga merupakan suatu hal yang membahagiakan untuk anda sendiri. Tugas seorang  wanita bukan sekadar mengerjakan pekerjaan rumah saja, namun kamu pun harus memastikan kebutuhan nutrisi terpenuhi dan olahan yang dikonsumsi keluarga tercinta harus menggugah selera.

Di waktu  saat ini, kamu memang mampu mengorder olahan praktis walaupun tidak harus capek membuatnya dulu. Namun ada juga lho orang yang memang mau memberikan hidangan yang terbaik untuk keluarganya. Lantaran, menghidangkan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai kesukaan famili. 



Apakah anda merupakan seorang penyuka opor ayam?. Tahukah kamu, opor ayam merupakan makanan khas di Indonesia yang saat ini disenangi oleh banyak orang dari berbagai tempat di Nusantara. Kamu dapat menghidangkan opor ayam kreasi sendiri di rumah dan dapat dijadikan makanan favoritmu di akhir pekanmu.

Anda jangan bingung untuk menyantap opor ayam, karena opor ayam tidak sukar untuk dicari dan kita pun boleh menghidangkannya sendiri di tempatmu. opor ayam boleh dimasak lewat beraneka cara. Saat ini sudah banyak banget cara modern yang membuat opor ayam semakin mantap.

Resep opor ayam pun mudah sekali dibuat, lho. Anda tidak usah repot-repot untuk memesan opor ayam, karena Kita mampu menghidangkan sendiri di rumah. Untuk Kalian yang mau mencobanya, dibawah ini merupakan resep membuat opor ayam yang enak yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Opor ayam:

1. Sediakan 1 ekor ayam ras potong 12
1. Siapkan 1 kelapa buat 2 santan cair sama kental
1. Siapkan 2 batang sereh geprek
1. Siapkan 3 lembar daun salam
1. Ambil 1 saset penyedap rasa
1. Siapkan 2 sdm gula pasir
1. Siapkan  Bumbu halus :
1. Gunakan 13 s bamer
1. Gunakan 7 s batih
1. Ambil 2 sdm ketumbar
1. Siapkan 1 sdt merica
1. Ambil 4 lembar daun jeruk
1. Ambil 1 ruas lengkuas
1. Siapkan 1 ruas jahe
1. Sediakan 4 butir kemiri
1. Sediakan 1 saset santan kara
1. Siapkan 1 gelas air




<!--inarticleads2-->

##### Cara membuat Opor ayam:

1. Siapkan bumbu yang akan di haluskan, bisa di blander atau di uleg, beri air.
1. Blander bumbu sampai halus
1. Lalu siapkan ayam yang sudah di potong dan di bersihkan, lalu lumuri dengan bumbu, tambahkan sereh dan daun salam
1. Lalu siapkan wajan, masukan ayam dan tutp hingga mendidih
1. Setelah mendidih masukkan santan cair ke dalam masakan, tutup kembali tunggu sampai 20 menit dengan api besar.
1. Setelah 20 menit buka tutupnya dan masukkan santan kental, aduk lalu bumbui dengan garam, gula, penyedap rasa. Tutup kembali dan masak selama 15 menit.
1. Setelah itu matikan kompor, diamkan tunggu sampai 15 menit
1. Setelah itu nyalakan kembali kompor dan masak menggunakan api kecil, cek rasa sekiranya sudah pas dengan lidah kita, kita tutup kembali masak sampai 15 menit.
1. Setelah itu diamkan jangan di buka tutupnya, sampai dingin
1. Di jamin ayam nya empuk banget bun, ini karena masaknya tidak di presto ya, yee siap deh di santap di jamin mantabbbbbz, selamat mencoba
1. Catatan aja nie bun
1. 20 menit masak pertama, matikan lalu diamkan 15 menit, masak kembali 15 menit, terahir matikan kompor diamkan jangan di buka tutupnya, di jamin ayam empuk sempurna




Ternyata resep opor ayam yang lezat tidak ribet ini mudah banget ya! Kita semua dapat mencobanya. Resep opor ayam Cocok sekali untuk kita yang baru akan belajar memasak ataupun bagi kamu yang telah lihai memasak.

Apakah kamu mau mulai mencoba membuat resep opor ayam lezat tidak ribet ini? Kalau kalian tertarik, ayo kamu segera buruan siapin peralatan dan bahannya, kemudian buat deh Resep opor ayam yang mantab dan tidak ribet ini. Benar-benar taidak sulit kan. 

Maka, daripada kamu berfikir lama-lama, maka kita langsung saja buat resep opor ayam ini. Pasti anda tak akan nyesel sudah buat resep opor ayam mantab simple ini! Selamat berkreasi dengan resep opor ayam mantab sederhana ini di rumah kalian sendiri,oke!.

