---
description: "Cara buat Soto Ayam Santan yang lezat Untuk Jualan"
title: "Cara buat Soto Ayam Santan yang lezat Untuk Jualan"
slug: 36-cara-buat-soto-ayam-santan-yang-lezat-untuk-jualan
date: 2021-04-01T23:53:35.989Z
image: https://img-global.cpcdn.com/recipes/75582be4ef1c543d/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/75582be4ef1c543d/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/75582be4ef1c543d/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Lee Allen
ratingvalue: 4.2
reviewcount: 9
recipeingredient:
- "1/2 kg ayam fillet"
- "2 bh kentang"
- "1 bks santan instant 65ml"
- "1 bh belimbing dewa manis me skip  ganti gula pasir 1 sdm"
- "1/2 sdt garam utk marinasi ayam"
- "1 sdt garam utk kuah soto"
- "1 sdt penyedap rasa"
- "4 gelas belimbing air matang lebih enak pakai air kaldu ayam"
- " Minyak utk menumis bumbu"
- "  Bumbu Halus"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "1 sdt ketumbar bubuk"
- "1/2 sdt jinten"
- "1 ruas jari kencur"
- "  Bumbu Cemplung"
- "2 lbr daun salam"
- "2 batang sereh geprek"
- "5 lbr daun jeruk"
- "2 batang daun bawang potong pendek tambahan saya"
- "  Bahan Pelengkap"
- " Daun seledri"
- " Tomat"
- " Cabai rawit"
- " Jeruk nipis"
- " Kecap"
recipeinstructions:
- "Siapkan bahan. Cuci bersih ayam fillet. Potong dadu. Marinasi ayam dengan garam sisihkan. Kentang, kupas lalu cuci bersih dan goreng setengah kering. Sisishkan."
- "Panaskan sedikit minyak. Tumis bumbu halus bersama daun salam dan sereh. Masak hingga harum dan kecoklatan."
- "Didihkan air lalu masukkan bumbu halus, daun jeruk, daun bawang, kentang dan ayam. Masak hingga air mendidih kembali dan ayam matang."
- "Terakhir tambahkan garam, gula, penyedap rasa dan santan. Aduk rata lalu koreksi rasa."
- "Sajikan hangat bersama bahan pelengkap."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/75582be4ef1c543d/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyajikan panganan enak buat keluarga merupakan hal yang memuaskan bagi kamu sendiri. Peran seorang  wanita bukan cuman menjaga rumah saja, tetapi anda juga wajib memastikan keperluan nutrisi tercukupi dan masakan yang disantap orang tercinta wajib sedap.

Di masa  saat ini, kalian sebenarnya mampu mengorder panganan jadi walaupun tanpa harus repot membuatnya dahulu. Namun banyak juga lho mereka yang selalu ingin menyajikan yang terenak untuk orang tercintanya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan kesukaan famili. 



Mungkinkah kamu salah satu penggemar soto ayam santan?. Asal kamu tahu, soto ayam santan adalah makanan khas di Nusantara yang kini disenangi oleh kebanyakan orang di hampir setiap tempat di Nusantara. Kita dapat memasak soto ayam santan buatan sendiri di rumah dan boleh dijadikan santapan favorit di akhir pekan.

Kita tak perlu bingung untuk menyantap soto ayam santan, sebab soto ayam santan gampang untuk ditemukan dan kita pun bisa membuatnya sendiri di rumah. soto ayam santan dapat dibuat dengan beragam cara. Saat ini sudah banyak sekali cara kekinian yang menjadikan soto ayam santan lebih nikmat.

Resep soto ayam santan pun mudah sekali untuk dibuat, lho. Kalian tidak perlu capek-capek untuk membeli soto ayam santan, lantaran Kita dapat menyajikan di rumahmu. Untuk Kalian yang akan menyajikannya, berikut ini cara menyajikan soto ayam santan yang nikamat yang bisa Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Soto Ayam Santan:

1. Siapkan 1/2 kg ayam fillet
1. Sediakan 2 bh kentang
1. Siapkan 1 bks santan instant 65ml
1. Ambil 1 bh belimbing dewa manis (me: skip 😁 ganti gula pasir 1 sdm)
1. Ambil 1/2 sdt garam utk marinasi ayam
1. Sediakan 1 sdt garam utk kuah soto
1. Siapkan 1 sdt penyedap rasa
1. Siapkan 4 gelas belimbing air matang (lebih enak pakai air kaldu ayam)
1. Siapkan  Minyak utk menumis bumbu
1. Gunakan  ◾ Bumbu Halus
1. Ambil 7 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Gunakan 1 sdt ketumbar bubuk
1. Ambil 1/2 sdt jinten
1. Sediakan 1 ruas jari kencur
1. Gunakan  ◾ Bumbu Cemplung
1. Ambil 2 lbr daun salam
1. Sediakan 2 batang sereh geprek
1. Sediakan 5 lbr daun jeruk
1. Sediakan 2 batang daun bawang potong pendek (tambahan saya)
1. Sediakan  ◾ Bahan Pelengkap
1. Sediakan  Daun seledri
1. Ambil  Tomat
1. Gunakan  Cabai rawit
1. Ambil  Jeruk nipis
1. Ambil  Kecap




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Santan:

1. Siapkan bahan. Cuci bersih ayam fillet. Potong dadu. Marinasi ayam dengan garam sisihkan. Kentang, kupas lalu cuci bersih dan goreng setengah kering. Sisishkan.
1. Panaskan sedikit minyak. Tumis bumbu halus bersama daun salam dan sereh. Masak hingga harum dan kecoklatan.
1. Didihkan air lalu masukkan bumbu halus, daun jeruk, daun bawang, kentang dan ayam. Masak hingga air mendidih kembali dan ayam matang.
1. Terakhir tambahkan garam, gula, penyedap rasa dan santan. Aduk rata lalu koreksi rasa.
1. Sajikan hangat bersama bahan pelengkap.




Ternyata cara buat soto ayam santan yang lezat tidak rumit ini gampang sekali ya! Kita semua dapat memasaknya. Cara buat soto ayam santan Sangat sesuai banget buat kalian yang sedang belajar memasak ataupun bagi kamu yang sudah jago memasak.

Tertarik untuk mencoba membikin resep soto ayam santan nikmat tidak ribet ini? Kalau anda tertarik, ayo kamu segera buruan siapkan alat dan bahan-bahannya, maka buat deh Resep soto ayam santan yang lezat dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka dari itu, daripada kamu berlama-lama, hayo kita langsung saja buat resep soto ayam santan ini. Dijamin kalian tiidak akan nyesel sudah membuat resep soto ayam santan enak tidak rumit ini! Selamat berkreasi dengan resep soto ayam santan mantab simple ini di tempat tinggal masing-masing,ya!.

