---
description: "Cara membuat Ayam Bakar Spesial yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam Bakar Spesial yang enak dan Mudah Dibuat"
slug: 285-cara-membuat-ayam-bakar-spesial-yang-enak-dan-mudah-dibuat
date: 2021-01-23T19:55:09.682Z
image: https://img-global.cpcdn.com/recipes/3d4f4648f4b27e5b/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3d4f4648f4b27e5b/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3d4f4648f4b27e5b/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg
author: Brian Santos
ratingvalue: 5
reviewcount: 12
recipeingredient:
- "1 ekor ayam"
- "1 santan KENTAL dari 1 butir kelapa"
- "1 ons cabai merah"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "1/2 sdm ketumbar"
- "1/2 ruas jari jahe"
- "2 bulatan gula merah secukupnya"
- "1 bgks rogyco"
- "1 ruas jari lengkuas"
- "2 batang serai"
- "3 lembar daun salam"
recipeinstructions:
- "Potong 1 ekor ayam menjadi 4 bagian (sesuai selera), cuci bersih dan tambahkan perasan jeruk nipis serta garam agar tidak amis. Sisihkan"
- "Haluskan bumbu : cabai merah, bawang merah putih, jahe, ketumbar"
- "Tumislah bumbu halus sampai harum. Api sedang"
- "Geprek lengkuas, serai. Dan masukkan ke tumisan barengan sama daun salam, aduk rata"
- "Masukkan gula merah serta Royco secukupnya. cek rasa"
- "Kemudian baru masukkan ayam, aduk dengan bumbu sebentar. Lalu TUTUP kurleb 15 menit agar bumbu meresap"
- "Setelah itu, kita masukkan santan KENTAL (disini kita gak pake santan encer ya)"
- "Aduk rata, JAGA santan jangan sampai pecah dan ayam jangan sampai gosong"
- "Jika sudah, tunggu hingga santan atau bumbu KENTAL dan matang kurang lebih 15-20 menit (tanpa di tutup wadah ya)"
- "Setelah matang hasilnya seperti ini dan siap untuk kita bakar"
- "Btw karena aku ga punya panggangan arang, jadi aku panggang di microwave selama 15 menit"
- "Jadi dehhh... Rasanya sangaaat nikmaat"
categories:
- Resep
tags:
- ayam
- bakar
- spesial

katakunci: ayam bakar spesial 
nutrition: 136 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Bakar Spesial](https://img-global.cpcdn.com/recipes/3d4f4648f4b27e5b/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg)

Andai kita seorang ibu, menyediakan panganan enak pada orang tercinta adalah suatu hal yang memuaskan untuk anda sendiri. Kewajiban seorang istri bukan sekedar mengatur rumah saja, tapi kamu pun wajib menyediakan kebutuhan nutrisi tercukupi dan santapan yang dikonsumsi keluarga tercinta mesti menggugah selera.

Di zaman  sekarang, kita sebenarnya bisa memesan santapan praktis meski tanpa harus repot membuatnya dahulu. Tetapi banyak juga lho mereka yang selalu mau memberikan yang terenak bagi keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan kesukaan famili. 



Apakah kamu salah satu penikmat ayam bakar spesial?. Tahukah kamu, ayam bakar spesial adalah makanan khas di Indonesia yang saat ini digemari oleh setiap orang di hampir setiap daerah di Indonesia. Kamu bisa menghidangkan ayam bakar spesial buatan sendiri di rumah dan dapat dijadikan camilan favoritmu di hari libur.

Kita tak perlu bingung untuk memakan ayam bakar spesial, karena ayam bakar spesial sangat mudah untuk dicari dan juga anda pun bisa mengolahnya sendiri di rumah. ayam bakar spesial boleh diolah lewat beraneka cara. Kini sudah banyak sekali cara kekinian yang menjadikan ayam bakar spesial semakin lebih nikmat.

Resep ayam bakar spesial pun sangat mudah dibuat, lho. Kalian jangan capek-capek untuk membeli ayam bakar spesial, lantaran Kalian mampu menyiapkan sendiri di rumah. Bagi Anda yang ingin mencobanya, berikut ini resep menyajikan ayam bakar spesial yang mantab yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Bakar Spesial:

1. Siapkan 1 ekor ayam
1. Siapkan 1 santan KENTAL dari 1 butir kelapa
1. Gunakan 1 ons cabai merah
1. Ambil 3 siung bawang putih
1. Ambil 5 siung bawang merah
1. Siapkan 1/2 sdm ketumbar
1. Ambil 1/2 ruas jari jahe
1. Siapkan 2 bulatan gula merah (secukupnya)
1. Ambil 1 bgks rogyco
1. Ambil 1 ruas jari lengkuas
1. Gunakan 2 batang serai
1. Siapkan 3 lembar daun salam




<!--inarticleads2-->

##### Cara menyiapkan Ayam Bakar Spesial:

1. Potong 1 ekor ayam menjadi 4 bagian (sesuai selera), cuci bersih dan tambahkan perasan jeruk nipis serta garam agar tidak amis. Sisihkan
<img src="https://img-global.cpcdn.com/steps/6d30d31f140062a2/160x128cq70/ayam-bakar-spesial-langkah-memasak-1-foto.jpg" alt="Ayam Bakar Spesial">1. Haluskan bumbu : cabai merah, bawang merah putih, jahe, ketumbar
1. Tumislah bumbu halus sampai harum. Api sedang
1. Geprek lengkuas, serai. Dan masukkan ke tumisan barengan sama daun salam, aduk rata
1. Masukkan gula merah serta Royco secukupnya. cek rasa
1. Kemudian baru masukkan ayam, aduk dengan bumbu sebentar. Lalu TUTUP kurleb 15 menit agar bumbu meresap
1. Setelah itu, kita masukkan santan KENTAL (disini kita gak pake santan encer ya)
1. Aduk rata, JAGA santan jangan sampai pecah dan ayam jangan sampai gosong
1. Jika sudah, tunggu hingga santan atau bumbu KENTAL dan matang kurang lebih 15-20 menit (tanpa di tutup wadah ya)
1. Setelah matang hasilnya seperti ini dan siap untuk kita bakar
1. Btw karena aku ga punya panggangan arang, jadi aku panggang di microwave selama 15 menit
1. Jadi dehhh... Rasanya sangaaat nikmaat




Ternyata resep ayam bakar spesial yang nikamt tidak ribet ini enteng sekali ya! Kamu semua bisa memasaknya. Resep ayam bakar spesial Sangat sesuai sekali untuk kamu yang baru akan belajar memasak maupun juga untuk anda yang telah jago memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam bakar spesial enak tidak rumit ini? Kalau kamu mau, mending kamu segera buruan siapkan alat dan bahannya, setelah itu buat deh Resep ayam bakar spesial yang lezat dan simple ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kamu berlama-lama, ayo langsung aja bikin resep ayam bakar spesial ini. Dijamin kamu tak akan nyesel membuat resep ayam bakar spesial nikmat sederhana ini! Selamat berkreasi dengan resep ayam bakar spesial enak tidak rumit ini di rumah masing-masing,ya!.

