---
description: "Cara buat Nasi Praktis （Rice cooker）dengan Ayam Goreng Crispy Sederhana Untuk Jualan"
title: "Cara buat Nasi Praktis （Rice cooker）dengan Ayam Goreng Crispy Sederhana Untuk Jualan"
slug: 295-cara-buat-nasi-praktis-rice-cookerdengan-ayam-goreng-crispy-sederhana-untuk-jualan
date: 2021-03-07T22:10:07.970Z
image: https://img-global.cpcdn.com/recipes/1b111b6a73708ab0/680x482cq70/nasi-praktis-rice-cookerdengan-ayam-goreng-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1b111b6a73708ab0/680x482cq70/nasi-praktis-rice-cookerdengan-ayam-goreng-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1b111b6a73708ab0/680x482cq70/nasi-praktis-rice-cookerdengan-ayam-goreng-crispy-foto-resep-utama.jpg
author: Grace Hughes
ratingvalue: 4.1
reviewcount: 9
recipeingredient:
- "1 cup beras sesuaikan dengan porsi masing masing"
- "3-5 buah jamur shitake"
- "1 Batang wortel"
- "1-2 pcs ayam mcd"
- "sedikit kucai daun bawangbawang bombay"
- "secukupnya bumbu nasi goreng indofood optional"
- "  Bahan air "
- "2 sdm minyak wijen"
- "1 sdm kecap inggris"
- "1 sdm kecap asin"
- "1 Sdm Kecap ikan"
- "1 sdt kaldu jamur"
- "1/2 Sdt garam"
- "sedikit lada dan ketumbar bubuk"
- " air rendaman jamur bila adabole ganti air matangair kaldu"
recipeinstructions:
- "Rebus jamur dengan 1 gelas air panas. Setelah jamur lembut, iris tipis. Sebaiknya siapkan 2 jam sebelumnya atau overnight （masuk kulkas）Boleh pakai jamur seger （tidak perlu di rendam）"
- "Cuci beras seperti biasa. Campurkan air jamur dengan bahan saus aduk rata, tes rasa. Kemudian tuang ke rice cooker. Tata ayam di atasnya. Nyalakan rice cooker."
- "Setelah rice cooker mengeluarkan uap （10-15 menit）masukkan wortel dan jamur bole tambah sayur lainnya juga namun yg tekstur keras aja ya. Klo mau tambah dedaunan nanti aja biar ga kelembekan sayurnya."
- "Setelah nasi matang /rice cooker berbunyi, keluarkan ayam, Segera masukkan dedaunan, kucai / bawang bombay/ batang daun bawang. Matikan rice cooker, diamkan 5-7 menit dengan keadaan tertutup （Dedaunan matang dengan uap panas nasi）Sementara menunggu suir suir ayam dengan bantuan garpu."
- "Setelah 5-7 Menit, masukkan ayam suir dan aduk aduk nasi. Tes rasa, apabila kurang rasa tambahkan sedikit bumbu nasi goreng atau bumbu perasa lainnya yg di suka （garam/kecap）"
- "Tata di piring makan, dan santap selagi hangat. Enak dan praktis."
categories:
- Resep
tags:
- nasi
- praktis
- rice

katakunci: nasi praktis rice 
nutrition: 200 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert

---


![Nasi Praktis （Rice cooker）dengan Ayam Goreng Crispy](https://img-global.cpcdn.com/recipes/1b111b6a73708ab0/680x482cq70/nasi-praktis-rice-cookerdengan-ayam-goreng-crispy-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan masakan sedap kepada orang tercinta adalah hal yang menyenangkan untuk anda sendiri. Peran seorang ibu Tidak sekedar menangani rumah saja, namun kamu juga harus memastikan keperluan nutrisi terpenuhi dan panganan yang dimakan keluarga tercinta mesti enak.

Di waktu  sekarang, kamu memang mampu mengorder panganan yang sudah jadi tidak harus susah membuatnya lebih dulu. Tetapi banyak juga lho mereka yang memang mau memberikan makanan yang terlezat untuk orang yang dicintainya. Pasalnya, menyajikan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan sesuai kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penggemar nasi praktis （rice cooker）dengan ayam goreng crispy?. Tahukah kamu, nasi praktis （rice cooker）dengan ayam goreng crispy adalah hidangan khas di Nusantara yang saat ini disukai oleh banyak orang dari berbagai tempat di Indonesia. Kamu dapat menyajikan nasi praktis （rice cooker）dengan ayam goreng crispy hasil sendiri di rumah dan boleh dijadikan hidangan kesenanganmu di hari liburmu.

Kalian tidak usah bingung jika kamu ingin memakan nasi praktis （rice cooker）dengan ayam goreng crispy, karena nasi praktis （rice cooker）dengan ayam goreng crispy gampang untuk ditemukan dan juga kalian pun dapat membuatnya sendiri di rumah. nasi praktis （rice cooker）dengan ayam goreng crispy dapat diolah lewat beragam cara. Saat ini ada banyak sekali resep modern yang membuat nasi praktis （rice cooker）dengan ayam goreng crispy lebih mantap.

Resep nasi praktis （rice cooker）dengan ayam goreng crispy juga sangat mudah dibikin, lho. Anda tidak perlu capek-capek untuk memesan nasi praktis （rice cooker）dengan ayam goreng crispy, karena Kamu bisa membuatnya di rumah sendiri. Untuk Anda yang hendak menghidangkannya, berikut ini resep untuk menyajikan nasi praktis （rice cooker）dengan ayam goreng crispy yang enak yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Nasi Praktis （Rice cooker）dengan Ayam Goreng Crispy:

1. Ambil 1 cup beras （sesuaikan dengan porsi masing masing）
1. Ambil 3-5 buah jamur shitake
1. Siapkan 1 Batang wortel
1. Sediakan 1-2 pcs ayam mcd
1. Gunakan sedikit kucai/ daun bawang/bawang bombay
1. Sediakan secukupnya bumbu nasi goreng indofood （optional）
1. Siapkan  🐥 Bahan air ：
1. Gunakan 2 sdm minyak wijen
1. Siapkan 1 sdm kecap inggris
1. Gunakan 1 sdm kecap asin
1. Siapkan 1 Sdm Kecap ikan
1. Ambil 1 sdt kaldu jamur
1. Sediakan 1/2 Sdt garam
1. Sediakan sedikit lada dan ketumbar bubuk
1. Gunakan  air rendaman jamur （bila ada）bole ganti air matang/air kaldu




<!--inarticleads2-->

##### Cara menyiapkan Nasi Praktis （Rice cooker）dengan Ayam Goreng Crispy:

1. Rebus jamur dengan 1 gelas air panas. Setelah jamur lembut, iris tipis. Sebaiknya siapkan 2 jam sebelumnya atau overnight （masuk kulkas）Boleh pakai jamur seger （tidak perlu di rendam）
1. Cuci beras seperti biasa. Campurkan air jamur dengan bahan saus aduk rata, tes rasa. Kemudian tuang ke rice cooker. Tata ayam di atasnya. Nyalakan rice cooker.
1. Setelah rice cooker mengeluarkan uap （10-15 menit）masukkan wortel dan jamur bole tambah sayur lainnya juga namun yg tekstur keras aja ya. Klo mau tambah dedaunan nanti aja biar ga kelembekan sayurnya.
1. Setelah nasi matang /rice cooker berbunyi, keluarkan ayam, Segera masukkan dedaunan, kucai / bawang bombay/ batang daun bawang. Matikan rice cooker, diamkan 5-7 menit dengan keadaan tertutup （Dedaunan matang dengan uap panas nasi）Sementara menunggu suir suir ayam dengan bantuan garpu.
1. Setelah 5-7 Menit, masukkan ayam suir dan aduk aduk nasi. Tes rasa, apabila kurang rasa tambahkan sedikit bumbu nasi goreng atau bumbu perasa lainnya yg di suka （garam/kecap）
1. Tata di piring makan, dan santap selagi hangat. Enak dan praktis.




Ternyata resep nasi praktis （rice cooker）dengan ayam goreng crispy yang nikamt simple ini enteng sekali ya! Anda Semua mampu menghidangkannya. Resep nasi praktis （rice cooker）dengan ayam goreng crispy Sangat cocok banget untuk kalian yang baru mau belajar memasak maupun bagi kalian yang sudah ahli memasak.

Tertarik untuk mulai mencoba bikin resep nasi praktis （rice cooker）dengan ayam goreng crispy nikmat tidak ribet ini? Kalau kalian ingin, yuk kita segera buruan menyiapkan alat dan bahan-bahannya, lalu bikin deh Resep nasi praktis （rice cooker）dengan ayam goreng crispy yang enak dan sederhana ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang kalian berfikir lama-lama, yuk langsung aja sajikan resep nasi praktis （rice cooker）dengan ayam goreng crispy ini. Dijamin kalian tiidak akan menyesal bikin resep nasi praktis （rice cooker）dengan ayam goreng crispy enak tidak rumit ini! Selamat mencoba dengan resep nasi praktis （rice cooker）dengan ayam goreng crispy nikmat sederhana ini di tempat tinggal kalian sendiri,ya!.

