---
description: "Resep Ingkung Ayam Kampung Sederhana dan Mudah Dibuat"
title: "Resep Ingkung Ayam Kampung Sederhana dan Mudah Dibuat"
slug: 236-resep-ingkung-ayam-kampung-sederhana-dan-mudah-dibuat
date: 2021-05-08T06:45:25.685Z
image: https://img-global.cpcdn.com/recipes/f1ae6eae124e4512/680x482cq70/ingkung-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f1ae6eae124e4512/680x482cq70/ingkung-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f1ae6eae124e4512/680x482cq70/ingkung-ayam-kampung-foto-resep-utama.jpg
author: Shawn Castillo
ratingvalue: 3
reviewcount: 13
recipeingredient:
- "1 ekor ayam kampung"
- "3 buah kelapa tua"
- " bumbu halus"
- "1 bongkah baput 10 butir"
- "8 bamer"
- "2 ruas kunyit tua"
- "5 kemiri"
- "1 buah pala"
- "1 bks tumbar"
- "100 gr cabe merah"
- " bumbu kasar"
- "2 bongkah lengkuas"
- "3 batang serai"
- "6 daun salam"
- "4 daun jeruk"
- "4 bks masako ayam"
- "4 sdm garam Kasar"
- "4 sdm gula"
recipeinstructions:
- "Cuci bersih ayam yang sudah dipotong, belah bagian dada, parut kelapa beri air secukupnya ambil santannya(saya 3x peras) lalu haluskan bumbu"
- "Bumbu yang sudah halus campur 2 bks masako ayam, micin, gula dan bumbu kasar, lalu sebagian bumbu masukan kedalam perut ayam (jangan lupa kebat smua sisi antara kaki, badan dan kepala, supaya bumbu tidak tumpah dan meresap"
- "Lalu masukan ayam kedalam panci besar, lalu tumpahkan santan kedalamnya, jgn lupa tambah garam,dan penyedap, biarkan sampai santan menyusut sesekali diaduk supaya bawah tidak gosong"
- "Setelah menyusut matikan kompor, tiriskan"
categories:
- Resep
tags:
- ingkung
- ayam
- kampung

katakunci: ingkung ayam kampung 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Ingkung Ayam Kampung](https://img-global.cpcdn.com/recipes/f1ae6eae124e4512/680x482cq70/ingkung-ayam-kampung-foto-resep-utama.jpg)

Selaku seorang wanita, menyajikan olahan menggugah selera pada famili adalah hal yang menyenangkan bagi anda sendiri. Kewajiban seorang istri Tidak cuma mengatur rumah saja, namun anda juga wajib memastikan keperluan nutrisi tercukupi dan olahan yang dimakan anak-anak wajib menggugah selera.

Di waktu  saat ini, anda sebenarnya mampu membeli olahan praktis walaupun tanpa harus susah membuatnya terlebih dahulu. Namun banyak juga mereka yang selalu ingin memberikan hidangan yang terenak untuk keluarganya. Sebab, memasak yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Mungkinkah anda merupakan seorang penggemar ingkung ayam kampung?. Tahukah kamu, ingkung ayam kampung merupakan sajian khas di Nusantara yang sekarang digemari oleh orang-orang dari hampir setiap daerah di Nusantara. Kita bisa membuat ingkung ayam kampung kreasi sendiri di rumah dan boleh dijadikan camilan kesenanganmu di hari liburmu.

Kalian tidak perlu bingung untuk memakan ingkung ayam kampung, lantaran ingkung ayam kampung tidak sulit untuk dicari dan kamu pun dapat menghidangkannya sendiri di tempatmu. ingkung ayam kampung dapat diolah memalui beragam cara. Sekarang telah banyak cara modern yang menjadikan ingkung ayam kampung lebih nikmat.

Resep ingkung ayam kampung juga gampang sekali untuk dibuat, lho. Kalian jangan ribet-ribet untuk memesan ingkung ayam kampung, lantaran Kita bisa menyajikan di rumahmu. Bagi Kamu yang ingin menghidangkannya, dibawah ini merupakan resep untuk menyajikan ingkung ayam kampung yang enak yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ingkung Ayam Kampung:

1. Sediakan 1 ekor ayam kampung
1. Gunakan 3 buah kelapa tua
1. Siapkan  bumbu halus
1. Sediakan 1 bongkah baput/ 10 butir
1. Sediakan 8 bamer
1. Gunakan 2 ruas kunyit tua
1. Sediakan 5 kemiri
1. Siapkan 1 buah pala
1. Sediakan 1 bks tumbar
1. Sediakan 100 gr cabe merah
1. Ambil  bumbu kasar
1. Gunakan 2 bongkah lengkuas
1. Ambil 3 batang serai
1. Sediakan 6 daun salam
1. Gunakan 4 daun jeruk
1. Sediakan 4 bks masako ayam
1. Ambil 4 sdm garam Kasar
1. Ambil 4 sdm gula




<!--inarticleads2-->

##### Cara membuat Ingkung Ayam Kampung:

1. Cuci bersih ayam yang sudah dipotong, belah bagian dada, parut kelapa beri air secukupnya ambil santannya(saya 3x peras) lalu haluskan bumbu
1. Bumbu yang sudah halus campur 2 bks masako ayam, micin, gula dan bumbu kasar, lalu sebagian bumbu masukan kedalam perut ayam (jangan lupa kebat smua sisi antara kaki, badan dan kepala, supaya bumbu tidak tumpah dan meresap
1. Lalu masukan ayam kedalam panci besar, lalu tumpahkan santan kedalamnya, jgn lupa tambah garam,dan penyedap, biarkan sampai santan menyusut sesekali diaduk supaya bawah tidak gosong
1. Setelah menyusut matikan kompor, tiriskan




Ternyata cara buat ingkung ayam kampung yang enak sederhana ini enteng sekali ya! Kalian semua mampu memasaknya. Resep ingkung ayam kampung Sesuai banget buat anda yang baru akan belajar memasak maupun juga bagi anda yang telah jago dalam memasak.

Tertarik untuk mulai mencoba membuat resep ingkung ayam kampung mantab simple ini? Kalau kalian ingin, ayo kalian segera siapkan alat dan bahan-bahannya, lalu buat deh Resep ingkung ayam kampung yang nikmat dan tidak ribet ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kita berfikir lama-lama, maka kita langsung saja buat resep ingkung ayam kampung ini. Dijamin kamu tiidak akan menyesal bikin resep ingkung ayam kampung mantab simple ini! Selamat mencoba dengan resep ingkung ayam kampung mantab tidak rumit ini di tempat tinggal masing-masing,oke!.

