---
description: "Bahan-bahan Ayam Goreng Sambel Ungkep yang lezat Untuk Jualan"
title: "Bahan-bahan Ayam Goreng Sambel Ungkep yang lezat Untuk Jualan"
slug: 259-bahan-bahan-ayam-goreng-sambel-ungkep-yang-lezat-untuk-jualan
date: 2021-04-22T14:32:34.361Z
image: https://img-global.cpcdn.com/recipes/bb9ed726590e323e/680x482cq70/ayam-goreng-sambel-ungkep-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bb9ed726590e323e/680x482cq70/ayam-goreng-sambel-ungkep-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bb9ed726590e323e/680x482cq70/ayam-goreng-sambel-ungkep-foto-resep-utama.jpg
author: Jorge Nash
ratingvalue: 4.8
reviewcount: 3
recipeingredient:
- "1 kg ayam"
- "1 batang sereh geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- " Bumbu halus "
- "5 siung bawang putih"
- "5 siung bawang merah"
- "1 sdm ketumbar"
- "2 butir kemiri"
- "2 ruas kunyit"
- "2 ruas jahe"
- "2 jempol lengkuas"
- "Secukupnya garam gula dan penyedap rasa"
- " Bahan sambal ungkep "
- "30 gr cabe rawit merahsesuai selera banyaknya"
- "5 siung bawang putih"
- "8 siung bawang merah"
- "1 sdt terasi"
- "Secukupnya garam gula dan penyedap rasa"
recipeinstructions:
- "Potong2 ayam, cuci bersih lalu beri perasan air jeruk nipis (spy tdk amis). Tumis bumbu halus, sereh, daun salam dan daun jeruk smp harum."
- "Masukan ayam, tambahkan secukupnya air, masak sampai bumbu meresap dan agak kering berminyak (sambil sesekali di aduk spy tdk gosong) jgn lupa tes rasa lalu angkat."
- "Goreng ayam (tidak usah terlalu kering/smp kering sesuai selera ya) lalu tiriskan."
- "💥Cara membuat sambal : 1. Goreng cabe dan duo bawang smp layu, lalu tiriskan. 2. Tambahkan terasi, garam, gula dan penyedao rasa kemudian haluskan. 3. Masukan sisa bumbu ungkep dengan sedikit minyak nya, campur rata."
categories:
- Resep
tags:
- ayam
- goreng
- sambel

katakunci: ayam goreng sambel 
nutrition: 282 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Sambel Ungkep](https://img-global.cpcdn.com/recipes/bb9ed726590e323e/680x482cq70/ayam-goreng-sambel-ungkep-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan olahan mantab bagi keluarga tercinta merupakan suatu hal yang mengasyikan bagi kamu sendiri. Tugas seorang  wanita bukan cuma menangani rumah saja, tapi kamu pun harus menyediakan kebutuhan gizi terpenuhi dan santapan yang dikonsumsi orang tercinta wajib nikmat.

Di era  saat ini, anda memang bisa memesan olahan jadi walaupun tidak harus capek memasaknya dahulu. Namun banyak juga lho orang yang selalu ingin memberikan yang terlezat untuk orang tercintanya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan kesukaan keluarga. 



Mungkinkah anda adalah salah satu penikmat ayam goreng sambel ungkep?. Tahukah kamu, ayam goreng sambel ungkep adalah hidangan khas di Nusantara yang sekarang disenangi oleh orang-orang di berbagai daerah di Indonesia. Kita bisa memasak ayam goreng sambel ungkep kreasi sendiri di rumahmu dan boleh dijadikan santapan kesenanganmu di akhir pekan.

Kita tidak usah bingung jika kamu ingin menyantap ayam goreng sambel ungkep, sebab ayam goreng sambel ungkep sangat mudah untuk dicari dan anda pun dapat membuatnya sendiri di rumah. ayam goreng sambel ungkep bisa dibuat memalui beragam cara. Kini ada banyak banget resep kekinian yang menjadikan ayam goreng sambel ungkep semakin enak.

Resep ayam goreng sambel ungkep juga sangat gampang dibikin, lho. Anda jangan repot-repot untuk memesan ayam goreng sambel ungkep, tetapi Kalian mampu menyiapkan sendiri di rumah. Untuk Kalian yang ingin menghidangkannya, di bawah ini adalah cara menyajikan ayam goreng sambel ungkep yang mantab yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Goreng Sambel Ungkep:

1. Sediakan 1 kg ayam
1. Siapkan 1 batang sereh, geprek
1. Siapkan 2 lembar daun salam
1. Gunakan 2 lembar daun jeruk
1. Ambil  Bumbu halus :
1. Gunakan 5 siung bawang putih
1. Sediakan 5 siung bawang merah
1. Siapkan 1 sdm ketumbar
1. Sediakan 2 butir kemiri
1. Ambil 2 ruas kunyit
1. Gunakan 2 ruas jahe
1. Sediakan 2 jempol lengkuas
1. Sediakan Secukupnya garam, gula dan penyedap rasa
1. Ambil  Bahan sambal ungkep :
1. Ambil 30 gr cabe rawit merah/sesuai selera banyaknya
1. Ambil 5 siung bawang putih
1. Ambil 8 siung bawang merah
1. Gunakan 1 sdt terasi
1. Gunakan Secukupnya garam, gula dan penyedap rasa




<!--inarticleads2-->

##### Cara menyiapkan Ayam Goreng Sambel Ungkep:

1. Potong2 ayam, cuci bersih lalu beri perasan air jeruk nipis (spy tdk amis). - Tumis bumbu halus, sereh, daun salam dan daun jeruk smp harum.
1. Masukan ayam, tambahkan secukupnya air, masak sampai bumbu meresap dan agak kering berminyak (sambil sesekali di aduk spy tdk gosong) jgn lupa tes rasa lalu angkat.
1. Goreng ayam (tidak usah terlalu kering/smp kering sesuai selera ya) lalu tiriskan.
1. 💥Cara membuat sambal : - 1. Goreng cabe dan duo bawang smp layu, lalu tiriskan. - 2. Tambahkan terasi, garam, gula dan penyedao rasa kemudian haluskan. - 3. Masukan sisa bumbu ungkep dengan sedikit minyak nya, campur rata.




Wah ternyata cara buat ayam goreng sambel ungkep yang nikamt tidak ribet ini gampang banget ya! Kamu semua mampu membuatnya. Resep ayam goreng sambel ungkep Cocok sekali buat kita yang baru mau belajar memasak maupun untuk kamu yang sudah lihai dalam memasak.

Tertarik untuk mencoba bikin resep ayam goreng sambel ungkep enak tidak ribet ini? Kalau kalian tertarik, mending kamu segera siapkan alat dan bahannya, maka bikin deh Resep ayam goreng sambel ungkep yang mantab dan simple ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kalian berlama-lama, ayo kita langsung bikin resep ayam goreng sambel ungkep ini. Dijamin kalian gak akan menyesal bikin resep ayam goreng sambel ungkep lezat tidak rumit ini! Selamat mencoba dengan resep ayam goreng sambel ungkep mantab tidak rumit ini di rumah kalian sendiri,oke!.

