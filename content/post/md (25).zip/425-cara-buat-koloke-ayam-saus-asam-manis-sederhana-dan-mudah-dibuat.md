---
description: "Cara buat Koloke Ayam Saus Asam Manis Sederhana dan Mudah Dibuat"
title: "Cara buat Koloke Ayam Saus Asam Manis Sederhana dan Mudah Dibuat"
slug: 425-cara-buat-koloke-ayam-saus-asam-manis-sederhana-dan-mudah-dibuat
date: 2021-02-19T02:11:49.902Z
image: https://img-global.cpcdn.com/recipes/8f58e59825d147d0/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8f58e59825d147d0/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8f58e59825d147d0/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
author: Steven Meyer
ratingvalue: 3.7
reviewcount: 14
recipeingredient:
- "  Bahan Utama"
- "300 gr daging ayam fillet"
- "  Bumbu Marinasi"
- "2 sdt bawang putih bubuk me 1 sdt"
- "1/2 sdt lada bubuk"
- "Secukupnya garam me  14 sdt"
- "  Bahan Kering"
- "100 gr tepung ayam krispi me tep ayam KoBe 70gr"
- "100 gr tepung terigu me 70 gr"
- "1/4 sdt baking powder"
- "  Bahan Basah"
- "1 butir telur ayam ambil dan gunakan putihnya saja"
- "1 SDM Bahan Kering"
- "100 ml air es me 50 ml"
- "  Bahan Saus"
- "1 buah wortel potong korek api"
- "1 buah timun potong korek api"
- "1/4 buah nanas potong kecil"
- "1 siung bawang Bombay 12nya pot panjng sisanya cincang kasar"
- "2 siung bawang putih cincang halus"
- "1 SDM kecap inggris me 2 SDM"
- "10 SDM saus tomat"
- "2 SDM saus sambal"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- "1 sdt gula pasir"
- "200 ml air"
- "Irisan cabe optional"
- "Secukupnya minyak goreng untuk menumis dan menggoreng"
recipeinstructions:
- "Siapkan ayam dan bumbu marinasi. Cuci ayam lalu potong-potong. Tambahkan bumbu Marinasi, campur rata. Biarkan +/- 30 menit dalam lemari es."
- "Cincang halus bawang putih. Cincang kasar 1/2 bag bawang Bombay dan potong memanjang sisanya. Iris serong cabai. Potong-potong nanas. Potong korek api wortel dan timun."
- "Buat bahan kering dan bahan basah. Campur semua bahan kering, adukrata, Buat juga bahan basah, aduk rata. Sisihkan bahan kering dan bahan basah."
- "Keluarkan potongan daging ayam yg telah dimarinasi dari lemari es. Gulingkan kedalam bahan kering, lalu celupkan ke bahan basah, kemudian gulingkan kembali ke bahan kering. Ratakan agar bahan kering menutup seluruh permukaan ayam dan tidak menempel satu sama lain."
- "Panaskan minyak goreng (agak banyak). Goreng ayam dgn api sedang sampai golden brown, Tiriskan."
- "Buat sausnya. Tumis bawang putih dan bawang Bombay cincang. Tumis sampai harum, masukkan irisan cabe. Lalu masukkan saus tomat, saus sambal, kecap Inggris, dan air. Tambahkan lada bubuk, garam, dan gula. Masukan wortel, timun, nanas &amp; sisa bawang bombay. Koreksi rasa."
- "Penyajian. Tata ayam di wadah lalu siram dengn saus. Hhmmm..yuummyhh..😋😍"
categories:
- Resep
tags:
- koloke
- ayam
- saus

katakunci: koloke ayam saus 
nutrition: 214 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Koloke Ayam Saus Asam Manis](https://img-global.cpcdn.com/recipes/8f58e59825d147d0/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg)

Andai kamu seorang orang tua, menyajikan olahan nikmat bagi keluarga tercinta adalah suatu hal yang membahagiakan untuk kita sendiri. Peran seorang ibu Tidak sekadar mengurus rumah saja, namun kamu pun wajib menyediakan kebutuhan nutrisi terpenuhi dan hidangan yang dikonsumsi keluarga tercinta mesti nikmat.

Di zaman  saat ini, kalian memang mampu memesan hidangan yang sudah jadi meski tidak harus repot membuatnya dulu. Namun ada juga mereka yang memang ingin memberikan makanan yang terlezat bagi orang yang dicintainya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai selera keluarga tercinta. 



Apakah kamu seorang penikmat koloke ayam saus asam manis?. Tahukah kamu, koloke ayam saus asam manis merupakan hidangan khas di Nusantara yang kini disukai oleh orang-orang dari berbagai wilayah di Nusantara. Kita dapat memasak koloke ayam saus asam manis olahan sendiri di rumahmu dan boleh jadi camilan kesukaanmu di hari liburmu.

Anda tak perlu bingung untuk memakan koloke ayam saus asam manis, sebab koloke ayam saus asam manis mudah untuk dicari dan kita pun dapat menghidangkannya sendiri di rumah. koloke ayam saus asam manis dapat dimasak memalui berbagai cara. Sekarang ada banyak sekali cara kekinian yang membuat koloke ayam saus asam manis lebih lezat.

Resep koloke ayam saus asam manis pun gampang sekali untuk dibuat, lho. Kita jangan ribet-ribet untuk memesan koloke ayam saus asam manis, sebab Anda mampu menghidangkan sendiri di rumah. Untuk Kita yang mau membuatnya, inilah resep menyajikan koloke ayam saus asam manis yang lezat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Koloke Ayam Saus Asam Manis:

1. Sediakan  🍗 Bahan Utama
1. Ambil 300 gr daging ayam fillet
1. Siapkan  🍗 Bumbu Marinasi
1. Ambil 2 sdt bawang putih bubuk (me: 1 sdt)
1. Gunakan 1/2 sdt lada bubuk
1. Gunakan Secukupnya garam (me: +/- 1/4 sdt)
1. Gunakan  🍗 Bahan Kering
1. Sediakan 100 gr tepung ayam krispi (me: tep ayam KoBe 70gr)
1. Gunakan 100 gr tepung terigu (me: 70 gr)
1. Ambil 1/4 sdt baking powder
1. Gunakan  🍗 Bahan Basah
1. Siapkan 1 butir telur ayam, ambil dan gunakan putihnya saja
1. Sediakan 1 SDM Bahan Kering
1. Sediakan 100 ml air es (me: 50 ml)
1. Ambil  🍗 Bahan Saus
1. Ambil 1 buah wortel, potong korek api
1. Sediakan 1 buah timun, potong korek api
1. Gunakan 1/4 buah nanas, potong kecil
1. Gunakan 1 siung bawang Bombay (1/2nya pot panjng, sisanya cincang kasar)
1. Ambil 2 siung bawang putih, cincang halus
1. Sediakan 1 SDM kecap inggris (me: 2 SDM)
1. Sediakan 10 SDM saus tomat
1. Gunakan 2 SDM saus sambal
1. Gunakan 1/2 sdt lada bubuk
1. Siapkan 1/2 sdt garam
1. Siapkan 1 sdt gula pasir
1. Ambil 200 ml air
1. Gunakan Irisan cabe (optional)
1. Gunakan Secukupnya minyak goreng untuk menumis dan menggoreng




<!--inarticleads2-->

##### Cara menyiapkan Koloke Ayam Saus Asam Manis:

1. Siapkan ayam dan bumbu marinasi. Cuci ayam lalu potong-potong. Tambahkan bumbu Marinasi, campur rata. Biarkan +/- 30 menit dalam lemari es.
1. Cincang halus bawang putih. Cincang kasar 1/2 bag bawang Bombay dan potong memanjang sisanya. Iris serong cabai. Potong-potong nanas. Potong korek api wortel dan timun.
1. Buat bahan kering dan bahan basah. Campur semua bahan kering, adukrata, Buat juga bahan basah, aduk rata. Sisihkan bahan kering dan bahan basah.
1. Keluarkan potongan daging ayam yg telah dimarinasi dari lemari es. Gulingkan kedalam bahan kering, lalu celupkan ke bahan basah, kemudian gulingkan kembali ke bahan kering. Ratakan agar bahan kering menutup seluruh permukaan ayam dan tidak menempel satu sama lain.
1. Panaskan minyak goreng (agak banyak). Goreng ayam dgn api sedang sampai golden brown, Tiriskan.
1. Buat sausnya. Tumis bawang putih dan bawang Bombay cincang. Tumis sampai harum, masukkan irisan cabe. Lalu masukkan saus tomat, saus sambal, kecap Inggris, dan air. Tambahkan lada bubuk, garam, dan gula. Masukan wortel, timun, nanas &amp; sisa bawang bombay. Koreksi rasa.
1. Penyajian. Tata ayam di wadah lalu siram dengn saus. Hhmmm..yuummyhh..😋😍




Wah ternyata resep koloke ayam saus asam manis yang enak sederhana ini gampang banget ya! Anda Semua mampu mencobanya. Cara buat koloke ayam saus asam manis Sesuai banget untuk anda yang baru akan belajar memasak ataupun juga bagi anda yang sudah lihai dalam memasak.

Apakah kamu mau mencoba membikin resep koloke ayam saus asam manis mantab sederhana ini? Kalau anda tertarik, yuk kita segera buruan siapkan alat-alat dan bahan-bahannya, lantas buat deh Resep koloke ayam saus asam manis yang mantab dan tidak ribet ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kamu diam saja, yuk kita langsung buat resep koloke ayam saus asam manis ini. Pasti anda gak akan nyesel membuat resep koloke ayam saus asam manis mantab tidak ribet ini! Selamat berkreasi dengan resep koloke ayam saus asam manis mantab tidak rumit ini di rumah kalian sendiri,oke!.

