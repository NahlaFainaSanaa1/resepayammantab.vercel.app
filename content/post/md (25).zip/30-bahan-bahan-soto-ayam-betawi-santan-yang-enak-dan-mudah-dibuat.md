---
description: "Bahan-bahan Soto Ayam Betawi (Santan) yang enak dan Mudah Dibuat"
title: "Bahan-bahan Soto Ayam Betawi (Santan) yang enak dan Mudah Dibuat"
slug: 30-bahan-bahan-soto-ayam-betawi-santan-yang-enak-dan-mudah-dibuat
date: 2021-05-31T12:14:29.542Z
image: https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg
author: Katie Bryant
ratingvalue: 4.4
reviewcount: 5
recipeingredient:
- "500 gram dada ayam potong"
- "3 buah kentang potong dadu"
- "3 buah tomat merah potong sedang"
- "3-4 jeruk limau"
- " Bawang goreng optional"
- " Emping optional"
- "secukupnya Kecap manis"
- "secukupnya Bihun"
- " Bumbu Halus"
- "9 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas kunyit"
- "1/2 sdt pala"
- "1 sdt ketumbar"
- "1 sdt lada"
- "1 ruas jahe"
- "5 butir kemiri"
- " Bumbu tambahan"
- "1 kotak santan instan"
- "1 batang sereh digeprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 ruas lengkuas digeprek"
- "secukupnya Garam"
- "secukupnya Penyedap rasa"
- " Air"
- "2 batang daun bawang iris"
- " Minyak secukupnya untuk tumis bumbu"
recipeinstructions:
- "Potong ayam dan cuci bersih lalu sisihkan."
- "3 buah kentang potong dadu, cuci bersih lalu sisihkan."
- "Potong bahan lainnya seperti tomat dan daun bawang. Geprek sereh dan lengkuas, sisihkan."
- "Goreng ayam hingga kecoklatan. Jika sudah matang tiriskan, lalu suwir."
- "Goreng kentang hingga matang. Sisihkan."
- "(Disarankan langsung di panci) Ulek bumbu halus. Lalu tumis bumbu dengan minyak secukupnya hingga harum. Masukkan sereh, lengkuas, daun salam, daun jeruk, daun bawang. Jika sudah harum, masukkan air aduk sampai mendidih. Lalu masukkan santan, garam dan penyedap, aduk rata, cek rasa. Jika sudah matang, matikan kompor dan sisihkan."
- "Rebus bihun. Siapkan mangkuk, sajikan ayam yg telah di suwir, bihun, kentang goreng, tomat, bawang goreng, dan emping ke dalam mangkuk. Siram dengan kuah soto lalu tambahkan perasan jeruk limau, dan beri sedikit kecap manis. Selamat menikmati!"
categories:
- Resep
tags:
- soto
- ayam
- betawi

katakunci: soto ayam betawi 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Ayam Betawi (Santan)](https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan masakan lezat pada famili merupakan suatu hal yang sangat menyenangkan untuk kamu sendiri. Kewajiban seorang  wanita Tidak sekedar mengatur rumah saja, namun kamu pun wajib memastikan kebutuhan gizi tercukupi dan masakan yang dikonsumsi orang tercinta wajib enak.

Di masa  sekarang, anda sebenarnya dapat membeli olahan jadi meski tidak harus repot memasaknya dulu. Tapi ada juga lho mereka yang selalu ingin menyajikan yang terbaik untuk keluarganya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan kesukaan famili. 



Mungkinkah anda adalah seorang penyuka soto ayam betawi (santan)?. Tahukah kamu, soto ayam betawi (santan) merupakan hidangan khas di Indonesia yang saat ini digemari oleh banyak orang dari hampir setiap tempat di Indonesia. Kamu dapat memasak soto ayam betawi (santan) sendiri di rumah dan boleh dijadikan hidangan kegemaranmu di hari liburmu.

Kalian tidak perlu bingung jika kamu ingin menyantap soto ayam betawi (santan), lantaran soto ayam betawi (santan) sangat mudah untuk dicari dan juga anda pun boleh membuatnya sendiri di rumah. soto ayam betawi (santan) boleh dimasak lewat beraneka cara. Saat ini ada banyak resep modern yang membuat soto ayam betawi (santan) lebih lezat.

Resep soto ayam betawi (santan) juga sangat mudah untuk dibuat, lho. Kamu tidak usah ribet-ribet untuk memesan soto ayam betawi (santan), lantaran Kamu dapat menghidangkan ditempatmu. Untuk Kamu yang mau mencobanya, di bawah ini adalah resep untuk membuat soto ayam betawi (santan) yang enak yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Betawi (Santan):

1. Gunakan 500 gram dada ayam, potong
1. Sediakan 3 buah kentang, potong dadu
1. Siapkan 3 buah tomat merah, potong sedang
1. Siapkan 3-4 jeruk limau
1. Sediakan  Bawang goreng (optional)
1. Siapkan  Emping (optional)
1. Gunakan secukupnya Kecap manis,
1. Siapkan secukupnya Bihun
1. Gunakan  Bumbu Halus
1. Sediakan 9 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Gunakan 1 ruas kunyit
1. Ambil 1/2 sdt pala
1. Ambil 1 sdt ketumbar
1. Sediakan 1 sdt lada
1. Ambil 1 ruas jahe
1. Siapkan 5 butir kemiri
1. Siapkan  Bumbu tambahan
1. Siapkan 1 kotak santan instan
1. Sediakan 1 batang sereh (digeprek)
1. Ambil 2 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Siapkan 1 ruas lengkuas (digeprek)
1. Siapkan secukupnya Garam
1. Gunakan secukupnya Penyedap rasa
1. Siapkan  Air
1. Sediakan 2 batang daun bawang, iris
1. Gunakan  Minyak secukupnya (untuk tumis bumbu)




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Betawi (Santan):

1. Potong ayam dan cuci bersih lalu sisihkan.
1. 3 buah kentang potong dadu, cuci bersih lalu sisihkan.
1. Potong bahan lainnya seperti tomat dan daun bawang. Geprek sereh dan lengkuas, sisihkan.
1. Goreng ayam hingga kecoklatan. Jika sudah matang tiriskan, lalu suwir.
1. Goreng kentang hingga matang. Sisihkan.
1. (Disarankan langsung di panci) Ulek bumbu halus. Lalu tumis bumbu dengan minyak secukupnya hingga harum. Masukkan sereh, lengkuas, daun salam, daun jeruk, daun bawang. Jika sudah harum, masukkan air aduk sampai mendidih. Lalu masukkan santan, garam dan penyedap, aduk rata, cek rasa. Jika sudah matang, matikan kompor dan sisihkan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Soto Ayam Betawi (Santan)">1. Rebus bihun. Siapkan mangkuk, sajikan ayam yg telah di suwir, bihun, kentang goreng, tomat, bawang goreng, dan emping ke dalam mangkuk. Siram dengan kuah soto lalu tambahkan perasan jeruk limau, dan beri sedikit kecap manis. Selamat menikmati!




Ternyata cara membuat soto ayam betawi (santan) yang mantab sederhana ini gampang banget ya! Semua orang mampu menghidangkannya. Cara buat soto ayam betawi (santan) Sangat sesuai sekali untuk anda yang baru akan belajar memasak maupun bagi kalian yang sudah lihai memasak.

Tertarik untuk mencoba membikin resep soto ayam betawi (santan) mantab simple ini? Kalau anda tertarik, ayo kalian segera menyiapkan peralatan dan bahan-bahannya, lalu bikin deh Resep soto ayam betawi (santan) yang nikmat dan sederhana ini. Benar-benar gampang kan. 

Maka dari itu, ketimbang anda berlama-lama, maka kita langsung saja bikin resep soto ayam betawi (santan) ini. Pasti anda tiidak akan nyesel sudah buat resep soto ayam betawi (santan) mantab simple ini! Selamat berkreasi dengan resep soto ayam betawi (santan) lezat tidak ribet ini di rumah masing-masing,ya!.

