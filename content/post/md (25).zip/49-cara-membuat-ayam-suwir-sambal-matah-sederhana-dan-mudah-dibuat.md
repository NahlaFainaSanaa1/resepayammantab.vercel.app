---
description: "Cara membuat Ayam Suwir Sambal Matah Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam Suwir Sambal Matah Sederhana dan Mudah Dibuat"
slug: 49-cara-membuat-ayam-suwir-sambal-matah-sederhana-dan-mudah-dibuat
date: 2021-03-23T16:52:48.550Z
image: https://img-global.cpcdn.com/recipes/c0a7229d5016ecca/680x482cq70/ayam-suwir-sambal-matah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c0a7229d5016ecca/680x482cq70/ayam-suwir-sambal-matah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c0a7229d5016ecca/680x482cq70/ayam-suwir-sambal-matah-foto-resep-utama.jpg
author: Rena Wright
ratingvalue: 5
reviewcount: 4
recipeingredient:
- "1 paha ayam paha atasbawah cuci bersih"
- "secukupnya Air"
- "1 siung bawang putih geprek"
- "1 ruas jahe kupas geprek"
- "2 lembar daun salam"
- "secukupnya Garam"
- "secukupnya Merica"
- " Bahan Sambal Matah"
- "2 buah cabai keriting merah jumlah bisa disesuaikan sih sans"
- "1 siung bawang putih kecil"
- "5-6 siung bawang merah lupa akutu berapa siung tadi"
- "1 buah bunga kecombrang kecil optional"
- "2 batang serai ambil bagian putihnya aja"
- "2 lembar daun jeruk buang tulangnya"
- "secukupnya Garam"
- "secukupnya Gula"
- " Penyedap optional"
- "1 sdm minyak kelapa bisa diskip sih biar alaala"
recipeinstructions:
- "Didihkan air, masukkan jahe, bawang putih, daun salam, ayam, garam dan merica. Rebus sampai daging ayamnya matang (ya iyalah mbak)"
- "Sembari menanti daging ayamnya matang, cuci bersih semua bahan sambal matah (kecuali garam, gula, dan penyedap, ofc. Hanyut nanti bund)"
- "Iris tipis semua bahan sambal matah, beri garam, gula, penyedap, aduk2. Kalo mau pake minyak, siram semua bahan sambal matahnya dengan minyak panas. Tp karena aku lg sok sehat dan malesan, jd kuskip aja~"
- "Setelah ayam matang, angkat dan tiriskan. Suwir2 pakai garpu. Buang tulangnya (ya iyalah)"
- "Campurkan ayam suwir dan sambal matah. Udah 😂"
categories:
- Resep
tags:
- ayam
- suwir
- sambal

katakunci: ayam suwir sambal 
nutrition: 202 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Suwir Sambal Matah](https://img-global.cpcdn.com/recipes/c0a7229d5016ecca/680x482cq70/ayam-suwir-sambal-matah-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan santapan nikmat pada famili merupakan suatu hal yang menyenangkan untuk anda sendiri. Peran seorang ibu bukan sekadar menjaga rumah saja, tetapi anda pun harus memastikan keperluan nutrisi terpenuhi dan juga panganan yang dikonsumsi orang tercinta harus enak.

Di zaman  sekarang, anda memang bisa membeli olahan instan walaupun tidak harus susah membuatnya lebih dulu. Tapi banyak juga mereka yang selalu ingin menghidangkan yang terenak bagi keluarganya. Pasalnya, memasak sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga tercinta. 



Apakah anda adalah salah satu penikmat ayam suwir sambal matah?. Tahukah kamu, ayam suwir sambal matah merupakan sajian khas di Nusantara yang sekarang disukai oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Kita bisa membuat ayam suwir sambal matah sendiri di rumah dan pasti jadi camilan kesukaanmu di hari liburmu.

Kamu tak perlu bingung untuk menyantap ayam suwir sambal matah, lantaran ayam suwir sambal matah tidak sukar untuk dicari dan kita pun boleh memasaknya sendiri di tempatmu. ayam suwir sambal matah boleh dimasak lewat bermacam cara. Kini pun sudah banyak sekali resep modern yang membuat ayam suwir sambal matah lebih nikmat.

Resep ayam suwir sambal matah juga sangat gampang dibikin, lho. Kamu tidak perlu ribet-ribet untuk memesan ayam suwir sambal matah, sebab Kamu dapat menyajikan sendiri di rumah. Untuk Kamu yang ingin mencobanya, dibawah ini merupakan resep untuk menyajikan ayam suwir sambal matah yang nikamat yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Suwir Sambal Matah:

1. Sediakan 1 paha ayam (paha atas+bawah), cuci bersih
1. Gunakan secukupnya Air
1. Ambil 1 siung bawang putih, geprek
1. Siapkan 1 ruas jahe, kupas, geprek
1. Ambil 2 lembar daun salam
1. Siapkan secukupnya Garam
1. Gunakan secukupnya Merica
1. Siapkan  Bahan Sambal Matah
1. Sediakan 2 buah cabai keriting merah (jumlah bisa disesuaikan sih, sans)
1. Gunakan 1 siung bawang putih kecil
1. Gunakan 5-6 siung bawang merah (lupa akutu berapa siung tadi)
1. Ambil 1 buah bunga kecombrang kecil (optional)
1. Siapkan 2 batang serai, ambil bagian putihnya aja
1. Sediakan 2 lembar daun jeruk, buang tulangnya
1. Siapkan secukupnya Garam
1. Sediakan secukupnya Gula
1. Ambil  Penyedap (optional)
1. Siapkan 1 sdm minyak kelapa (bisa diskip sih biar ala-ala)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Suwir Sambal Matah:

1. Didihkan air, masukkan jahe, bawang putih, daun salam, ayam, garam dan merica. Rebus sampai daging ayamnya matang (ya iyalah mbak)
1. Sembari menanti daging ayamnya matang, cuci bersih semua bahan sambal matah (kecuali garam, gula, dan penyedap, ofc. Hanyut nanti bund)
1. Iris tipis semua bahan sambal matah, beri garam, gula, penyedap, aduk2. Kalo mau pake minyak, siram semua bahan sambal matahnya dengan minyak panas. Tp karena aku lg sok sehat dan malesan, jd kuskip aja~
1. Setelah ayam matang, angkat dan tiriskan. Suwir2 pakai garpu. Buang tulangnya (ya iyalah)
1. Campurkan ayam suwir dan sambal matah. Udah 😂




Wah ternyata cara buat ayam suwir sambal matah yang lezat tidak ribet ini enteng sekali ya! Kamu semua dapat menghidangkannya. Resep ayam suwir sambal matah Sangat cocok sekali buat anda yang baru belajar memasak atau juga bagi kamu yang sudah jago dalam memasak.

Tertarik untuk mencoba bikin resep ayam suwir sambal matah lezat simple ini? Kalau kamu mau, yuk kita segera buruan siapin peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam suwir sambal matah yang lezat dan sederhana ini. Betul-betul taidak sulit kan. 

Maka dari itu, ketimbang anda berlama-lama, yuk kita langsung sajikan resep ayam suwir sambal matah ini. Dijamin anda tak akan nyesel sudah membuat resep ayam suwir sambal matah nikmat sederhana ini! Selamat berkreasi dengan resep ayam suwir sambal matah lezat tidak ribet ini di rumah masing-masing,ya!.

