---
description: "Bahan-bahan Soto Ayam Santan ala Violet Azalea yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Soto Ayam Santan ala Violet Azalea yang lezat dan Mudah Dibuat"
slug: 29-bahan-bahan-soto-ayam-santan-ala-violet-azalea-yang-lezat-dan-mudah-dibuat
date: 2021-01-30T20:28:32.586Z
image: https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg
author: Clyde McGee
ratingvalue: 3.9
reviewcount: 3
recipeingredient:
- "1 ekor ayam 15 kg"
- "1 1/2 liter air"
- "2 liter santan kekentalan sedang"
- "4 buah tomat ukuran besar potong"
- "2 batang serai geprek"
- "2 ruas jari lengkuas geprek"
- "5 lembar daun jeruk"
- "4 lembar daun salam"
- "secukupnya garam"
- "1 sachet kaldu bubuk rasa ayam"
- "secukupnya vetsin"
- "1 sdm gula pasir"
- " Bumbu Halus "
- "8 siung bawang merah"
- "5 siung bawang putih"
- "2 1/2 ruas jari kunyit bakar kupas kulit arinya"
- "1 1/2 ruas jahe"
- "4 buah kemiri sangrai"
- "1 sdm ketumbar butiran sangrai"
- " Pelengkap "
- " Perkedel Singkong           lihat resep"
- " Sambal           lihat resep"
- " Bawang goreng"
- "iris Daun bawang"
recipeinstructions:
- "Tumis bumbu halus, daun jeruk, daun salam, lengkuas dan serai hingga harum dan matang. Sisihkan."
- "Di dalam sebuah panci rebus ayam dan air. Masak hingga ayam lunak dan daging terlihat agak terlepas dari tulang. Beri santan dan tumisan bumbu."
- "Bumbui dengan kaldu bubuk rasa ayam, garam, vetsin dan gula. Aduk terus ya agar santan tak terpecah. Sesaat sebelum diangkat masukkan tomat iris. Angkat."
- "Angkat ayam. Tiriskan. Goreng sejenak saja di api besar cukup hingga agak nyoklat sedikit. Tidak usah sampai kering. Suwir-suwir daging ayam. Sisihkan."
- "Di dalam piring sendok nasi hangat. Sendokkan kuah ke dalam piring berisi nasi. Sajikan dengan pelengkap."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 107 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam Santan ala Violet Azalea](https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, mempersiapkan santapan enak untuk orang tercinta merupakan hal yang menggembirakan untuk anda sendiri. Kewajiban seorang  wanita bukan sekedar mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib memastikan keperluan nutrisi tercukupi dan juga masakan yang dikonsumsi keluarga tercinta wajib lezat.

Di masa  sekarang, kalian memang bisa membeli hidangan yang sudah jadi tanpa harus ribet membuatnya terlebih dahulu. Tetapi banyak juga mereka yang memang ingin memberikan hidangan yang terbaik bagi keluarganya. Pasalnya, memasak sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai selera keluarga tercinta. 



Apakah anda merupakan seorang penyuka soto ayam santan ala violet azalea?. Tahukah kamu, soto ayam santan ala violet azalea adalah sajian khas di Nusantara yang kini disukai oleh setiap orang di berbagai daerah di Indonesia. Kalian bisa membuat soto ayam santan ala violet azalea sendiri di rumahmu dan boleh jadi camilan kegemaranmu di hari liburmu.

Kamu tidak usah bingung jika kamu ingin memakan soto ayam santan ala violet azalea, sebab soto ayam santan ala violet azalea mudah untuk ditemukan dan juga kalian pun bisa mengolahnya sendiri di tempatmu. soto ayam santan ala violet azalea dapat dimasak memalui bermacam cara. Kini telah banyak resep modern yang menjadikan soto ayam santan ala violet azalea lebih enak.

Resep soto ayam santan ala violet azalea pun gampang sekali untuk dibikin, lho. Kamu tidak perlu repot-repot untuk membeli soto ayam santan ala violet azalea, lantaran Kita mampu menghidangkan di rumahmu. Bagi Anda yang akan menghidangkannya, inilah cara untuk membuat soto ayam santan ala violet azalea yang mantab yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Santan ala Violet Azalea:

1. Sediakan 1 ekor ayam (1,5 kg)
1. Ambil 1 1/2 liter air
1. Siapkan 2 liter santan kekentalan sedang
1. Ambil 4 buah tomat ukuran besar, potong
1. Gunakan 2 batang serai, geprek
1. Sediakan 2 ruas jari lengkuas, geprek
1. Siapkan 5 lembar daun jeruk
1. Gunakan 4 lembar daun salam
1. Siapkan secukupnya garam
1. Siapkan 1 sachet kaldu bubuk rasa ayam
1. Gunakan secukupnya vetsin
1. Siapkan 1 sdm gula pasir
1. Gunakan  Bumbu Halus :
1. Siapkan 8 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Ambil 2 1/2 ruas jari kunyit, bakar, kupas kulit arinya
1. Siapkan 1 1/2 ruas jahe
1. Siapkan 4 buah kemiri, sangrai
1. Ambil 1 sdm ketumbar butiran, sangrai
1. Sediakan  Pelengkap :
1. Siapkan  Perkedel Singkong           (lihat resep)
1. Gunakan  Sambal           (lihat resep)
1. Sediakan  Bawang goreng
1. Siapkan iris Daun bawang




<!--inarticleads2-->

##### Cara membuat Soto Ayam Santan ala Violet Azalea:

1. Tumis bumbu halus, daun jeruk, daun salam, lengkuas dan serai hingga harum dan matang. Sisihkan.
1. Di dalam sebuah panci rebus ayam dan air. Masak hingga ayam lunak dan daging terlihat agak terlepas dari tulang. Beri santan dan tumisan bumbu.
1. Bumbui dengan kaldu bubuk rasa ayam, garam, vetsin dan gula. Aduk terus ya agar santan tak terpecah. Sesaat sebelum diangkat masukkan tomat iris. Angkat.
1. Angkat ayam. Tiriskan. Goreng sejenak saja di api besar cukup hingga agak nyoklat sedikit. Tidak usah sampai kering. Suwir-suwir daging ayam. Sisihkan.
1. Di dalam piring sendok nasi hangat. Sendokkan kuah ke dalam piring berisi nasi. Sajikan dengan pelengkap.




Ternyata resep soto ayam santan ala violet azalea yang enak tidak rumit ini mudah sekali ya! Kamu semua mampu memasaknya. Cara buat soto ayam santan ala violet azalea Sangat cocok banget untuk kita yang baru belajar memasak atau juga bagi kamu yang telah hebat dalam memasak.

Apakah kamu tertarik mencoba bikin resep soto ayam santan ala violet azalea lezat tidak rumit ini? Kalau anda ingin, mending kamu segera buruan siapin peralatan dan bahan-bahannya, kemudian bikin deh Resep soto ayam santan ala violet azalea yang enak dan tidak ribet ini. Sungguh mudah kan. 

Jadi, ketimbang kamu diam saja, maka langsung aja sajikan resep soto ayam santan ala violet azalea ini. Pasti anda gak akan menyesal sudah bikin resep soto ayam santan ala violet azalea nikmat sederhana ini! Selamat mencoba dengan resep soto ayam santan ala violet azalea nikmat tidak ribet ini di tempat tinggal masing-masing,oke!.

