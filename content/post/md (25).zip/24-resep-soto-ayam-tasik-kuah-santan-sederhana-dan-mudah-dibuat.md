---
description: "Resep Soto Ayam Tasik kuah santan Sederhana dan Mudah Dibuat"
title: "Resep Soto Ayam Tasik kuah santan Sederhana dan Mudah Dibuat"
slug: 24-resep-soto-ayam-tasik-kuah-santan-sederhana-dan-mudah-dibuat
date: 2021-05-03T21:53:14.846Z
image: https://img-global.cpcdn.com/recipes/6f6ccb073e851e61/680x482cq70/soto-ayam-tasik-kuah-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f6ccb073e851e61/680x482cq70/soto-ayam-tasik-kuah-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f6ccb073e851e61/680x482cq70/soto-ayam-tasik-kuah-santan-foto-resep-utama.jpg
author: Bradley Tyler
ratingvalue: 3.7
reviewcount: 14
recipeingredient:
- "1/2 ekor ayam kampung"
- "1500 ml air"
- "500 ml santan"
- " Bumbu cemplung "
- "2 lbr daun salam"
- "2 btg sere"
- "3 cm lengkuas"
- "2 btg daun bawang simpulkan"
- " Bumbu perasa "
- "3 sdt garam"
- "1 sdt gula pasir"
- " Bumbu halus "
- "6 siung bawang merah"
- "2 siung bawang putih"
- "1/2 sdt merica"
- "2 butir kemiri sangrai"
- "2 sdm minyak sayur utk menumis"
- " Pelengkap "
- "1 bks kecil soun rendam"
- "1 btg saledri cincang halus"
- "2 sdm bawang goreng"
- " Kerupuk sambal"
recipeinstructions:
- "Didihkan air rebus ayam yg sdh di potong2 beri garam, masak hingga matang, angkat ayam dan suwir2, saring kuahnya"
- "Panaskan minyak lalu tumis bumbu halus hingga layu dan wangi + bumbu cemplung aduk rata masukkan dlm air kaldu rebusan ayam biarkan mendidih + sisa garam aduk hingga rata, tuang santan aduk terus perlahan jgn sampai santan pecah biarkan mendidih"
- "Cek rasa matang angkat Siapkan mangkok tata nasi, soun, ayam yg sdh di suwir2 + daun saledri dan siram kuah soto di atasnya beri taburan bawang goreng"
- "Siap disajikan dgn sambal, air jeruk nipis dan kerupuk"
categories:
- Resep
tags:
- soto
- ayam
- tasik

katakunci: soto ayam tasik 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Ayam Tasik kuah santan](https://img-global.cpcdn.com/recipes/6f6ccb073e851e61/680x482cq70/soto-ayam-tasik-kuah-santan-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan masakan mantab buat famili adalah suatu hal yang menyenangkan bagi kamu sendiri. Kewajiban seorang ibu Tidak hanya mengatur rumah saja, tapi kamu juga wajib menyediakan kebutuhan nutrisi tercukupi dan panganan yang disantap keluarga tercinta wajib menggugah selera.

Di waktu  sekarang, kamu sebenarnya mampu memesan olahan siap saji tidak harus capek memasaknya dahulu. Namun banyak juga orang yang selalu ingin memberikan makanan yang terlezat bagi keluarganya. Karena, menghidangkan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan selera keluarga tercinta. 



Mungkinkah anda merupakan salah satu penyuka soto ayam tasik kuah santan?. Asal kamu tahu, soto ayam tasik kuah santan adalah makanan khas di Nusantara yang kini disukai oleh orang-orang di berbagai daerah di Indonesia. Kalian bisa memasak soto ayam tasik kuah santan sendiri di rumah dan pasti jadi camilan kegemaranmu di akhir pekanmu.

Anda jangan bingung untuk mendapatkan soto ayam tasik kuah santan, sebab soto ayam tasik kuah santan tidak sulit untuk dicari dan juga kamu pun bisa menghidangkannya sendiri di tempatmu. soto ayam tasik kuah santan dapat dimasak memalui berbagai cara. Kini pun telah banyak banget resep modern yang membuat soto ayam tasik kuah santan semakin lezat.

Resep soto ayam tasik kuah santan juga sangat mudah dibuat, lho. Kita tidak perlu repot-repot untuk membeli soto ayam tasik kuah santan, lantaran Kamu dapat menghidangkan sendiri di rumah. Bagi Kalian yang mau membuatnya, dibawah ini merupakan cara untuk membuat soto ayam tasik kuah santan yang mantab yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Soto Ayam Tasik kuah santan:

1. Gunakan 1/2 ekor ayam kampung
1. Siapkan 1500 ml air
1. Siapkan 500 ml santan
1. Ambil  Bumbu cemplung :
1. Siapkan 2 lbr daun salam
1. Gunakan 2 btg sere
1. Sediakan 3 cm lengkuas
1. Siapkan 2 btg daun bawang simpulkan
1. Sediakan  Bumbu perasa :
1. Siapkan 3 sdt garam
1. Gunakan 1 sdt gula pasir
1. Ambil  Bumbu halus :
1. Ambil 6 siung bawang merah
1. Ambil 2 siung bawang putih
1. Siapkan 1/2 sdt merica
1. Ambil 2 butir kemiri sangrai
1. Gunakan 2 sdm minyak sayur utk menumis
1. Siapkan  Pelengkap :
1. Gunakan 1 bks kecil soun rendam
1. Siapkan 1 btg saledri cincang halus
1. Sediakan 2 sdm bawang goreng
1. Ambil  Kerupuk, sambal




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Tasik kuah santan:

1. Didihkan air rebus ayam yg sdh di potong2 beri garam, masak hingga matang, angkat ayam dan suwir2, saring kuahnya
1. Panaskan minyak lalu tumis bumbu halus hingga layu dan wangi + bumbu cemplung aduk rata masukkan dlm air kaldu rebusan ayam biarkan mendidih + sisa garam aduk hingga rata, tuang santan aduk terus perlahan jgn sampai santan pecah biarkan mendidih
1. Cek rasa matang angkat - Siapkan mangkok tata nasi, soun, ayam yg sdh di suwir2 + daun saledri dan siram kuah soto di atasnya beri taburan bawang goreng
1. Siap disajikan dgn sambal, air jeruk nipis dan kerupuk




Ternyata cara membuat soto ayam tasik kuah santan yang lezat simple ini mudah banget ya! Anda Semua dapat mencobanya. Cara buat soto ayam tasik kuah santan Cocok sekali buat kalian yang baru mau belajar memasak ataupun juga bagi kalian yang telah jago memasak.

Tertarik untuk mulai mencoba buat resep soto ayam tasik kuah santan enak simple ini? Kalau anda tertarik, ayo kalian segera siapin alat dan bahannya, maka buat deh Resep soto ayam tasik kuah santan yang nikmat dan tidak rumit ini. Sungguh taidak sulit kan. 

Maka dari itu, ketimbang anda berlama-lama, hayo kita langsung buat resep soto ayam tasik kuah santan ini. Pasti kalian tak akan menyesal membuat resep soto ayam tasik kuah santan mantab simple ini! Selamat mencoba dengan resep soto ayam tasik kuah santan enak simple ini di rumah kalian sendiri,ya!.

