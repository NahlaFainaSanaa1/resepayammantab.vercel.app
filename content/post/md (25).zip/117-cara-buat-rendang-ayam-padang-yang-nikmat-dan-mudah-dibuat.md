---
description: "Cara buat Rendang Ayam Padang yang nikmat dan Mudah Dibuat"
title: "Cara buat Rendang Ayam Padang yang nikmat dan Mudah Dibuat"
slug: 117-cara-buat-rendang-ayam-padang-yang-nikmat-dan-mudah-dibuat
date: 2021-02-03T02:07:52.443Z
image: https://img-global.cpcdn.com/recipes/d26d9f67eeb8b5a4/680x482cq70/rendang-ayam-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d26d9f67eeb8b5a4/680x482cq70/rendang-ayam-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d26d9f67eeb8b5a4/680x482cq70/rendang-ayam-padang-foto-resep-utama.jpg
author: Herbert Garner
ratingvalue: 4.6
reviewcount: 15
recipeingredient:
- "7 potong ayam 250 gr ayam"
- "1 batang seraidigeprek"
- "3 lembar daun jeruk"
- "1 sendok teh garam"
- "1 sdt lada bubuk"
- "1/2 sdt kaldu bubuk"
- "40 ml santan kental"
- "400 ml air"
- "1 butir kapulaga"
- "2 butir cengkeh"
- "secukupnya Air asam jawa"
- " Cabe giling "
- "3 buah cabe merah besar"
- "4 buah cabe rawit"
- " Bumbu halus "
- "6 siung bawang merah"
- "3 siung bawang putih"
- "1 sdt ketumbar bubuk"
- "2 cm jahe"
recipeinstructions:
- "Cuci ayam hingga bersih dan sisihkan"
- "Blender bumbu cabe giling hingga halus lalu marinasi ke ayam yang sudah dicuci"
- "Haluskan bumbu menggunakan blender"
- "Tumis hingga harum bersama serai dan daun jeruk"
- "Masukkan ayam,aduk rata hingga berubah warna,tambahkan kapulaga,cengkeh,garam,merica bubuk,air dan santan.Masak hingga air berkurang,sambil sesekali diaduk"
- "Setelah air berkurang tambahkan air asam jawa dan sajikan"
categories:
- Resep
tags:
- rendang
- ayam
- padang

katakunci: rendang ayam padang 
nutrition: 109 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Lunch

---


![Rendang Ayam Padang](https://img-global.cpcdn.com/recipes/d26d9f67eeb8b5a4/680x482cq70/rendang-ayam-padang-foto-resep-utama.jpg)

Sebagai seorang wanita, menyuguhkan panganan enak bagi famili merupakan hal yang membahagiakan untuk kita sendiri. Peran seorang  wanita bukan cuma mengurus rumah saja, namun kamu pun harus menyediakan kebutuhan nutrisi terpenuhi dan juga panganan yang dikonsumsi anak-anak mesti lezat.

Di waktu  sekarang, kalian memang bisa mengorder olahan praktis tanpa harus ribet memasaknya dahulu. Tapi ada juga lho orang yang selalu ingin memberikan hidangan yang terbaik bagi orang yang dicintainya. Pasalnya, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan famili. 



Apakah anda adalah salah satu penggemar rendang ayam padang?. Asal kamu tahu, rendang ayam padang adalah sajian khas di Indonesia yang kini disukai oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Kita dapat menyajikan rendang ayam padang sendiri di rumahmu dan boleh jadi makanan favoritmu di hari libur.

Kalian tidak perlu bingung untuk memakan rendang ayam padang, sebab rendang ayam padang mudah untuk dicari dan kamu pun dapat memasaknya sendiri di tempatmu. rendang ayam padang dapat diolah dengan beraneka cara. Sekarang telah banyak banget cara modern yang membuat rendang ayam padang lebih mantap.

Resep rendang ayam padang juga mudah sekali dihidangkan, lho. Anda jangan ribet-ribet untuk membeli rendang ayam padang, sebab Kalian mampu menyajikan sendiri di rumah. Bagi Anda yang hendak menghidangkannya, dibawah ini merupakan resep membuat rendang ayam padang yang mantab yang bisa Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Rendang Ayam Padang:

1. Ambil 7 potong ayam (250 gr ayam)
1. Siapkan 1 batang serai,digeprek
1. Sediakan 3 lembar daun jeruk
1. Siapkan 1 sendok teh garam
1. Gunakan 1 sdt lada bubuk
1. Siapkan 1/2 sdt kaldu bubuk
1. Gunakan 40 ml santan kental
1. Sediakan 400 ml air
1. Sediakan 1 butir kapulaga
1. Gunakan 2 butir cengkeh
1. Siapkan secukupnya Air asam jawa
1. Sediakan  Cabe giling :
1. Ambil 3 buah cabe merah besar
1. Ambil 4 buah cabe rawit
1. Siapkan  Bumbu halus :
1. Sediakan 6 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Sediakan 1 sdt ketumbar bubuk
1. Ambil 2 cm jahe




<!--inarticleads2-->

##### Cara membuat Rendang Ayam Padang:

1. Cuci ayam hingga bersih dan sisihkan
1. Blender bumbu cabe giling hingga halus lalu marinasi ke ayam yang sudah dicuci
1. Haluskan bumbu menggunakan blender
1. Tumis hingga harum bersama serai dan daun jeruk
1. Masukkan ayam,aduk rata hingga berubah warna,tambahkan kapulaga,cengkeh,garam,merica bubuk,air dan santan.Masak hingga air berkurang,sambil sesekali diaduk
1. Setelah air berkurang tambahkan air asam jawa dan sajikan




Wah ternyata cara buat rendang ayam padang yang lezat tidak rumit ini gampang sekali ya! Kita semua mampu membuatnya. Cara Membuat rendang ayam padang Sangat sesuai banget buat kamu yang baru akan belajar memasak ataupun juga bagi anda yang telah pandai memasak.

Apakah kamu mau mencoba buat resep rendang ayam padang lezat sederhana ini? Kalau kalian mau, ayo kamu segera menyiapkan alat dan bahannya, lantas buat deh Resep rendang ayam padang yang enak dan simple ini. Benar-benar taidak sulit kan. 

Maka dari itu, ketimbang kalian berlama-lama, maka langsung aja buat resep rendang ayam padang ini. Pasti kalian gak akan nyesel bikin resep rendang ayam padang lezat simple ini! Selamat mencoba dengan resep rendang ayam padang mantab tidak rumit ini di tempat tinggal kalian sendiri,ya!.

