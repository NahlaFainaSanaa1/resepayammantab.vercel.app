---
description: "Cara buat Soto Ayam Santan Sederhana dan Mudah Dibuat"
title: "Cara buat Soto Ayam Santan Sederhana dan Mudah Dibuat"
slug: 22-cara-buat-soto-ayam-santan-sederhana-dan-mudah-dibuat
date: 2021-06-12T08:07:23.302Z
image: https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Aiden Brewer
ratingvalue: 3.8
reviewcount: 9
recipeingredient:
- "1/4 kg Dada Ayam"
- "1500 ml Air"
- "1 btg Serai memarkan"
- "2 cm Lengkuas memarkan"
- "3 lbr Daun Jeruk"
- "1 bks Santan Instan"
- "1/4 sdt Lada bubuk"
- "Secukupnya Bawang Goreng"
- "Secukupnya Garam Gula dan Kaldu Bubuk"
- " Cengkeh Kapulaga Bunga Lawang untuk wewangian bisa di skip"
- " bumbu halus"
- "7 bh Bawang merah"
- "5 bh Bawang Putih"
- "4 btr Kemiri"
- "2 cm Kunyit"
- "2 cm Jahe"
- "Secukupnya Minyak Goreng"
recipeinstructions:
- "Cuci bersih semua bahan"
- "Rebus ayam hingga empuk dan keluar kaldunya"
- "Tumis bumbu halus hingga wangi. Tambahkan serai, lengkuas, daun jeruk dan lada bubuk, aduk hingga rata kemudian sisihkan"
- "Masukkan bumbu yang sudah ditumis kedalam rebusan ayam, kemudian tambahkan garam, gula dan kaldu bubuk. Aduk hingga rata"
- "Koreksi rasa dan masak sekitar 15 menit dengan api kecil hingga bumbu meresap"
- "Angkat daging ayam, kemudian masukkan santan, aduk hingga rata dan tambahkan cengkeh, kapulaga dan bunga lawang (bisa di skip)"
- "Goreng ayam yang sudah di tiriskan, jangan terlalu kering, kemudian di suwir suwir"
- "Taburkan bawang goreng kedalam kuah soto yang telah matang. Soto ayam santan, siap dihidangkan!"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 286 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan masakan mantab bagi famili merupakan suatu hal yang menggembirakan bagi kita sendiri. Kewajiban seorang istri Tidak saja mengurus rumah saja, tapi kamu pun wajib menyediakan kebutuhan gizi terpenuhi dan panganan yang dikonsumsi keluarga tercinta wajib nikmat.

Di waktu  sekarang, anda sebenarnya bisa memesan santapan yang sudah jadi tidak harus capek mengolahnya lebih dulu. Namun banyak juga mereka yang selalu mau memberikan yang terbaik untuk orang tercintanya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan famili. 

Haluskan bumbu soto: bawang putih, bawang merah, merica, ketumbar dan kunyit. b. Tumis bumbu yang sudah dihaluskan sampai harum. c. Masukkan daun salam, jahe, serai dan lengkuas.

Apakah anda adalah salah satu penggemar soto ayam santan?. Tahukah kamu, soto ayam santan merupakan hidangan khas di Nusantara yang saat ini disenangi oleh kebanyakan orang di berbagai tempat di Nusantara. Anda dapat menyajikan soto ayam santan kreasi sendiri di rumahmu dan pasti jadi santapan favoritmu di hari libur.

Kita jangan bingung untuk memakan soto ayam santan, sebab soto ayam santan tidak sulit untuk dicari dan juga anda pun bisa membuatnya sendiri di tempatmu. soto ayam santan boleh dimasak memalui beragam cara. Saat ini telah banyak banget resep modern yang menjadikan soto ayam santan lebih enak.

Resep soto ayam santan juga sangat mudah untuk dibuat, lho. Anda tidak usah ribet-ribet untuk memesan soto ayam santan, karena Kamu mampu menyajikan ditempatmu. Bagi Kita yang ingin membuatnya, berikut resep membuat soto ayam santan yang nikamat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto Ayam Santan:

1. Gunakan 1/4 kg Dada Ayam
1. Gunakan 1500 ml Air
1. Ambil 1 btg Serai (memarkan)
1. Ambil 2 cm Lengkuas (memarkan)
1. Gunakan 3 lbr Daun Jeruk
1. Ambil 1 bks Santan Instan
1. Ambil 1/4 sdt Lada bubuk
1. Sediakan Secukupnya Bawang Goreng
1. Siapkan Secukupnya Garam, Gula dan Kaldu Bubuk
1. Gunakan  Cengkeh, Kapulaga, Bunga Lawang (untuk wewangian, bisa di skip)
1. Siapkan  bumbu halus
1. Sediakan 7 bh Bawang merah
1. Gunakan 5 bh Bawang Putih
1. Siapkan 4 btr Kemiri
1. Siapkan 2 cm Kunyit
1. Gunakan 2 cm Jahe
1. Gunakan Secukupnya Minyak Goreng


Soto ayam santan sudah sangat terkenal di Medan dan Bogor. Cocok jadi menu hari ini, berikut resep dan cara membuat soto ayam santan yang gurih. Bisa juga untuk menu buka puasamu nanti. Cara Membuat Soto Ayam Santan: Haluskan semua bahan bumbu halus, lalu tumis bersama dengan lengkuas, serai dan daun salam hingga harum. 

<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Santan:

1. Cuci bersih semua bahan
1. Rebus ayam hingga empuk dan keluar kaldunya
1. Tumis bumbu halus hingga wangi. Tambahkan serai, lengkuas, daun jeruk dan lada bubuk, aduk hingga rata kemudian sisihkan
1. Masukkan bumbu yang sudah ditumis kedalam rebusan ayam, kemudian tambahkan garam, gula dan kaldu bubuk. Aduk hingga rata
1. Koreksi rasa dan masak sekitar 15 menit dengan api kecil hingga bumbu meresap
1. Angkat daging ayam, kemudian masukkan santan, aduk hingga rata dan tambahkan cengkeh, kapulaga dan bunga lawang (bisa di skip)
1. Goreng ayam yang sudah di tiriskan, jangan terlalu kering, kemudian di suwir suwir
1. Taburkan bawang goreng kedalam kuah soto yang telah matang. - Soto ayam santan, siap dihidangkan!


Masukkan ayam kedalam tumisan bumbu, lalu aduk-aduk hingga berubah warna. Tuang santan kental dan air, Tambahkan kaldu bubuk dan garam, lalu test rasa. Masukkan kentang, ayam, dan tomat dalam mangkuk. Kemudian, siram dengan kuah soto yang gurih. Soto ayam santan yang gurih pun siap disantap bersama nasi panas. 

Ternyata cara membuat soto ayam santan yang nikamt tidak rumit ini mudah sekali ya! Anda Semua bisa memasaknya. Resep soto ayam santan Sangat sesuai sekali buat anda yang baru akan belajar memasak ataupun bagi kamu yang sudah lihai memasak.

Apakah kamu ingin mulai mencoba membuat resep soto ayam santan enak simple ini? Kalau anda tertarik, mending kamu segera siapin alat-alat dan bahannya, lantas buat deh Resep soto ayam santan yang nikmat dan tidak ribet ini. Sungguh mudah kan. 

Maka, daripada kamu berfikir lama-lama, yuk langsung aja hidangkan resep soto ayam santan ini. Dijamin kamu tak akan menyesal bikin resep soto ayam santan nikmat simple ini! Selamat mencoba dengan resep soto ayam santan mantab sederhana ini di tempat tinggal kalian sendiri,ya!.

