---
description: "Cara membuat *Burger Ketan Crispy isi Ayam Teriyaki* yang enak dan Mudah Dibuat"
title: "Cara membuat *Burger Ketan Crispy isi Ayam Teriyaki* yang enak dan Mudah Dibuat"
slug: 375-cara-membuat-burger-ketan-crispy-isi-ayam-teriyaki-yang-enak-dan-mudah-dibuat
date: 2021-06-06T01:46:48.876Z
image: https://img-global.cpcdn.com/recipes/4d758146cbe6c0ff/680x482cq70/burger-ketan-crispy-isi-ayam-teriyaki-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4d758146cbe6c0ff/680x482cq70/burger-ketan-crispy-isi-ayam-teriyaki-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4d758146cbe6c0ff/680x482cq70/burger-ketan-crispy-isi-ayam-teriyaki-foto-resep-utama.jpg
author: Dora Diaz
ratingvalue: 4.9
reviewcount: 7
recipeingredient:
- "250 gr beras ketan putih rendam  2 jam"
- "125 ml santan"
- "1 lbr daun salam"
- "1/4 sdt garam"
- "2 butir telur"
- "  150 gr tpg panir"
- " Bahan isian "
- "  250 gr ayam fillet"
- "1/2 butir bwg bombay"
- "3 siung bwg putih parut"
- "1/2 sdt lada bubuk"
- "1 sdm saus teriyaki"
- "2 sdm saus tiram"
- "2 sdm kecap manis"
- "1 sdm margarine utk menumis"
- "3 cabe merah iris"
- "1/2 sdt garam"
- "100 ml air"
- "1 sdt tpg maizena cairkan"
- " Pekengkap "
- "Secukupnya daun selada"
- "Secukupnya timun dan tomat merah"
recipeinstructions:
- "Buat isian, cuci bersih ayam fillet, potong sesuai selera lalu campurkan saus tiram, kecap manis dan biarkan ± 1 jam. panaskan margarine lalu tumis bwg putih dan bwg bombay hingga harum, masukkan cabe merah iris, aduk rata biarkan sebentar, masukkan ayam"
- "Aduk rata, lalu beri garam, aduk rata dan masak hingga ayam setengah matang, beri air, saus teriyaki dan lada bubuk, aduk rata dan masak hingga agak mengering"
- "Kemudian tuang larutan maizena, aduk rata. Masak hingga mengering, angkat, sisihkan."
- "Masak ketan, tiriskan beras ketan lalu kukus ± 20 menit. Sambil masak santan, beri garam dan daun pandan, masak hingga mendidih. Angkat ketan yg dikukusl, masukkan kedalam santan yg sudah dimasak, aduk rata"
- "Dan biarkan hingga santan menyerap lalu kukus kembali selama 30 menit, angkat. Pisahkan daun pandannya. Lalu tumbuk ketan sebentar selagi panas"
- "Setelah itu ratakan ketan, cetak bentuk bulat dengan mangkuk/cookie cutter, besarnya sesuai selera/kira2 seukuran roti burger. Tekan2, padatkan dan biarkan hingga dingin."
- "Setelah dingin celupkan ketelur yg sudah dikocok lepas lalu gulingkan ketepung panir"
- "Goreng dengan minyak panas hingga kekuningan, angkat dan biarkan dingin.  Penyajian, tata daun selada diatas ketan, beri ayam teriyaki"
- "Lalu beri timun dan tomat. Tutup dengan ketan goreng lagi diatasnya."
- "Dan burger ketan crispy siap untuk disajikan."
categories:
- Resep
tags:
- burger
- ketan
- crispy

katakunci: burger ketan crispy 
nutrition: 161 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dessert

---


![*Burger Ketan Crispy isi Ayam Teriyaki*](https://img-global.cpcdn.com/recipes/4d758146cbe6c0ff/680x482cq70/burger-ketan-crispy-isi-ayam-teriyaki-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan panganan enak buat keluarga tercinta merupakan hal yang memuaskan bagi anda sendiri. Peran seorang ibu bukan sekedar menangani rumah saja, tetapi anda juga wajib memastikan keperluan gizi tercukupi dan masakan yang dikonsumsi keluarga tercinta wajib sedap.

Di masa  sekarang, kita sebenarnya bisa mengorder olahan jadi walaupun tanpa harus ribet mengolahnya dulu. Tetapi ada juga orang yang selalu ingin menghidangkan yang terlezat bagi orang yang dicintainya. Karena, memasak yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai dengan kesukaan famili. 



Apakah anda adalah salah satu penikmat *burger ketan crispy isi ayam teriyaki*?. Asal kamu tahu, *burger ketan crispy isi ayam teriyaki* adalah makanan khas di Nusantara yang saat ini disukai oleh kebanyakan orang dari hampir setiap daerah di Indonesia. Kamu dapat menyajikan *burger ketan crispy isi ayam teriyaki* sendiri di rumahmu dan pasti jadi makanan kesenanganmu di hari libur.

Kalian tak perlu bingung untuk memakan *burger ketan crispy isi ayam teriyaki*, lantaran *burger ketan crispy isi ayam teriyaki* tidak sulit untuk ditemukan dan kamu pun boleh mengolahnya sendiri di rumah. *burger ketan crispy isi ayam teriyaki* bisa diolah dengan beragam cara. Kini telah banyak banget cara modern yang menjadikan *burger ketan crispy isi ayam teriyaki* semakin lebih mantap.

Resep *burger ketan crispy isi ayam teriyaki* pun gampang sekali untuk dibuat, lho. Kita jangan ribet-ribet untuk membeli *burger ketan crispy isi ayam teriyaki*, lantaran Anda mampu menyiapkan di rumah sendiri. Untuk Kalian yang hendak menghidangkannya, inilah resep untuk menyajikan *burger ketan crispy isi ayam teriyaki* yang nikamat yang bisa Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan *Burger Ketan Crispy isi Ayam Teriyaki*:

1. Ambil 250 gr beras ketan putih, rendam ± 2 jam
1. Gunakan 125 ml santan
1. Gunakan 1 lbr daun salam
1. Ambil 1/4 sdt garam
1. Siapkan 2 butir telur
1. Gunakan  ± 150 gr tpg panir
1. Sediakan  Bahan isian :
1. Gunakan  ± 250 gr ayam fillet
1. Siapkan 1/2 butir bwg bombay
1. Ambil 3 siung bwg putih, parut
1. Ambil 1/2 sdt lada bubuk
1. Sediakan 1 sdm saus teriyaki
1. Ambil 2 sdm saus tiram
1. Siapkan 2 sdm kecap manis
1. Sediakan 1 sdm margarine, utk menumis
1. Sediakan 3 cabe merah iris
1. Ambil 1/2 sdt garam
1. Siapkan 100 ml air
1. Ambil 1 sdt tpg maizena, cairkan
1. Sediakan  Pekengkap :
1. Ambil Secukupnya daun selada
1. Ambil Secukupnya timun dan tomat merah




<!--inarticleads2-->

##### Cara membuat *Burger Ketan Crispy isi Ayam Teriyaki*:

1. Buat isian, cuci bersih ayam fillet, potong sesuai selera lalu campurkan saus tiram, kecap manis dan biarkan ± 1 jam. panaskan margarine lalu tumis bwg putih dan bwg bombay hingga harum, masukkan cabe merah iris, aduk rata biarkan sebentar, masukkan ayam
1. Aduk rata, lalu beri garam, aduk rata dan masak hingga ayam setengah matang, beri air, saus teriyaki dan lada bubuk, aduk rata dan masak hingga agak mengering
1. Kemudian tuang larutan maizena, aduk rata. Masak hingga mengering, angkat, sisihkan.
1. Masak ketan, tiriskan beras ketan lalu kukus ± 20 menit. Sambil masak santan, beri garam dan daun pandan, masak hingga mendidih. Angkat ketan yg dikukusl, masukkan kedalam santan yg sudah dimasak, aduk rata
1. Dan biarkan hingga santan menyerap lalu kukus kembali selama 30 menit, angkat. Pisahkan daun pandannya. Lalu tumbuk ketan sebentar selagi panas
1. Setelah itu ratakan ketan, cetak bentuk bulat dengan mangkuk/cookie cutter, besarnya sesuai selera/kira2 seukuran roti burger. Tekan2, padatkan dan biarkan hingga dingin.
1. Setelah dingin celupkan ketelur yg sudah dikocok lepas lalu gulingkan ketepung panir
1. Goreng dengan minyak panas hingga kekuningan, angkat dan biarkan dingin.  - Penyajian, tata daun selada diatas ketan, beri ayam teriyaki
1. Lalu beri timun dan tomat. Tutup dengan ketan goreng lagi diatasnya.
1. Dan burger ketan crispy siap untuk disajikan.




Wah ternyata cara membuat *burger ketan crispy isi ayam teriyaki* yang lezat tidak ribet ini gampang banget ya! Anda Semua dapat mencobanya. Cara buat *burger ketan crispy isi ayam teriyaki* Sangat cocok banget untuk anda yang baru mau belajar memasak ataupun untuk kamu yang telah ahli dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep *burger ketan crispy isi ayam teriyaki* nikmat tidak ribet ini? Kalau tertarik, ayo kalian segera siapin alat-alat dan bahannya, maka buat deh Resep *burger ketan crispy isi ayam teriyaki* yang enak dan sederhana ini. Sangat mudah kan. 

Oleh karena itu, daripada kamu berfikir lama-lama, maka langsung aja buat resep *burger ketan crispy isi ayam teriyaki* ini. Dijamin anda tak akan nyesel bikin resep *burger ketan crispy isi ayam teriyaki* mantab tidak rumit ini! Selamat mencoba dengan resep *burger ketan crispy isi ayam teriyaki* lezat simple ini di rumah kalian sendiri,oke!.

