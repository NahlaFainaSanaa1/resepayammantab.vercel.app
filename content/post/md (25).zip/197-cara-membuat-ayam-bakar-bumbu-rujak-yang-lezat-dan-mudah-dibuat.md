---
description: "Cara membuat Ayam Bakar Bumbu Rujak yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Bakar Bumbu Rujak yang lezat dan Mudah Dibuat"
slug: 197-cara-membuat-ayam-bakar-bumbu-rujak-yang-lezat-dan-mudah-dibuat
date: 2021-02-05T12:58:29.021Z
image: https://img-global.cpcdn.com/recipes/e90d18b57923c597/680x482cq70/ayam-bakar-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e90d18b57923c597/680x482cq70/ayam-bakar-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e90d18b57923c597/680x482cq70/ayam-bakar-bumbu-rujak-foto-resep-utama.jpg
author: Victoria Pena
ratingvalue: 4.3
reviewcount: 15
recipeingredient:
- "1 ekor ayam negri  pejantan"
- " Bahan Marinase"
- "2 sdt asem jawa"
- "secukupnya garam"
- " Bumbu halus"
- "4 siung bawang putih"
- "8 siung bawang merah"
- "3 butir kemiri sangrai"
- "3 cabe merah besar"
- "6 cabe merah kriting"
- "2 ruas lengkoas"
- "1 ruas jahe"
- "2 sendok makan minyak goreng"
- " Bumbu tambahan"
- "1 batang sereh"
- "2 lembar daun salam"
- "2 lebar daun jeruk"
- "1 sdt merica bubuk"
- "1 sdm gula merah"
- "1 sdm gula pasir"
- "100 ml santan kental"
- " Kaldu secukupnya aku pake totole kaldu jamur"
recipeinstructions:
- "Potong ayam jadi 10 bagian Siram ayam dengan air asem jawa + garam dan diamkan selama 10 menit"
- "Tumis bumbu halus dan tambahkan salam, sereh, daun jeruk hingga matang dan harum"
- "Setelah tumisan matang (keluar minyak) masukan ayam dan masak sebentar sambil diaduk, masukan garam, gula pasir, merica, gula merah, dan kaldu"
- "Tambahkan santan, lalu aduk dan masak ayam hingga matang"
- "Setelah ayam matang dan bumbu mengental, matikan api, dan ayam siap dibakar di grill pan dengan sedikit tambahan minyak"
- "Siram ayam yg sudah dibakar dengan bumbu ayam, lalu siap utk disajikan"
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Bakar Bumbu Rujak](https://img-global.cpcdn.com/recipes/e90d18b57923c597/680x482cq70/ayam-bakar-bumbu-rujak-foto-resep-utama.jpg)

Andai kita seorang ibu, menyajikan olahan mantab untuk keluarga adalah suatu hal yang memuaskan bagi kamu sendiri. Kewajiban seorang istri bukan saja menjaga rumah saja, namun anda pun wajib memastikan keperluan gizi terpenuhi dan hidangan yang disantap keluarga tercinta harus sedap.

Di era  saat ini, kamu sebenarnya dapat membeli hidangan instan meski tanpa harus susah membuatnya terlebih dahulu. Tetapi banyak juga lho orang yang memang ingin menyajikan yang terlezat untuk orang yang dicintainya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan orang tercinta. 



Apakah kamu seorang penikmat ayam bakar bumbu rujak?. Asal kamu tahu, ayam bakar bumbu rujak merupakan hidangan khas di Nusantara yang saat ini digemari oleh setiap orang di hampir setiap wilayah di Indonesia. Anda bisa membuat ayam bakar bumbu rujak sendiri di rumahmu dan dapat dijadikan santapan favorit di akhir pekanmu.

Kalian tak perlu bingung jika kamu ingin mendapatkan ayam bakar bumbu rujak, lantaran ayam bakar bumbu rujak mudah untuk didapatkan dan juga kamu pun dapat mengolahnya sendiri di rumah. ayam bakar bumbu rujak boleh dimasak memalui beragam cara. Sekarang ada banyak resep kekinian yang membuat ayam bakar bumbu rujak semakin nikmat.

Resep ayam bakar bumbu rujak juga gampang sekali dibikin, lho. Kalian tidak perlu repot-repot untuk memesan ayam bakar bumbu rujak, tetapi Kita bisa menyiapkan di rumah sendiri. Bagi Anda yang mau mencobanya, berikut cara menyajikan ayam bakar bumbu rujak yang lezat yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Bakar Bumbu Rujak:

1. Gunakan 1 ekor ayam negri / pejantan
1. Ambil  Bahan Marinase
1. Ambil 2 sdt asem jawa
1. Gunakan secukupnya garam
1. Siapkan  Bumbu halus
1. Sediakan 4 siung bawang putih
1. Gunakan 8 siung bawang merah
1. Gunakan 3 butir kemiri (sangrai)
1. Sediakan 3 cabe merah besar
1. Gunakan 6 cabe merah kriting
1. Gunakan 2 ruas lengkoas
1. Ambil 1 ruas jahe
1. Ambil 2 sendok makan minyak goreng
1. Ambil  Bumbu tambahan
1. Sediakan 1 batang sereh
1. Siapkan 2 lembar daun salam
1. Gunakan 2 lebar daun jeruk
1. Ambil 1 sdt merica bubuk
1. Ambil 1 sdm gula merah
1. Siapkan 1 sdm gula pasir
1. Sediakan 100 ml santan kental
1. Gunakan  Kaldu secukupnya (aku pake totole kaldu jamur)




<!--inarticleads2-->

##### Cara menyiapkan Ayam Bakar Bumbu Rujak:

1. Potong ayam jadi 10 bagian - Siram ayam dengan air asem jawa + garam dan diamkan selama 10 menit
1. Tumis bumbu halus dan tambahkan salam, sereh, daun jeruk hingga matang dan harum
1. Setelah tumisan matang (keluar minyak) masukan ayam dan masak sebentar sambil diaduk, masukan garam, gula pasir, merica, gula merah, dan kaldu
1. Tambahkan santan, lalu aduk dan masak ayam hingga matang
1. Setelah ayam matang dan bumbu mengental, matikan api, dan ayam siap dibakar di grill pan dengan sedikit tambahan minyak
1. Siram ayam yg sudah dibakar dengan bumbu ayam, lalu siap utk disajikan




Wah ternyata cara membuat ayam bakar bumbu rujak yang mantab sederhana ini gampang banget ya! Anda Semua dapat membuatnya. Resep ayam bakar bumbu rujak Cocok banget untuk kalian yang baru mau belajar memasak ataupun juga untuk kalian yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam bakar bumbu rujak enak simple ini? Kalau kamu ingin, mending kamu segera siapin alat-alat dan bahannya, lalu bikin deh Resep ayam bakar bumbu rujak yang lezat dan simple ini. Benar-benar gampang kan. 

Oleh karena itu, ketimbang kita berlama-lama, maka kita langsung hidangkan resep ayam bakar bumbu rujak ini. Pasti kalian tiidak akan menyesal bikin resep ayam bakar bumbu rujak nikmat sederhana ini! Selamat mencoba dengan resep ayam bakar bumbu rujak nikmat tidak rumit ini di rumah kalian sendiri,ya!.

