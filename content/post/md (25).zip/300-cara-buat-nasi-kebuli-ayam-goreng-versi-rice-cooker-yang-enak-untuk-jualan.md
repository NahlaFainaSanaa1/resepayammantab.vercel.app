---
description: "Cara buat Nasi kebuli ayam goreng versi rice cooker yang enak Untuk Jualan"
title: "Cara buat Nasi kebuli ayam goreng versi rice cooker yang enak Untuk Jualan"
slug: 300-cara-buat-nasi-kebuli-ayam-goreng-versi-rice-cooker-yang-enak-untuk-jualan
date: 2021-07-03T20:42:10.505Z
image: https://img-global.cpcdn.com/recipes/abc1155302abc469/680x482cq70/nasi-kebuli-ayam-goreng-versi-rice-cooker-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/abc1155302abc469/680x482cq70/nasi-kebuli-ayam-goreng-versi-rice-cooker-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/abc1155302abc469/680x482cq70/nasi-kebuli-ayam-goreng-versi-rice-cooker-foto-resep-utama.jpg
author: Iva Hunt
ratingvalue: 3
reviewcount: 4
recipeingredient:
- "1 ekor ayam saya menggunakan ayam negeri  4 sendok makan garam kasar"
- "500 gram beras cuci bersih dan tiriskan"
- "800 ml air"
- "1 butir bawang bombay belah dua dan rajang setipis mungkin"
- " Bumbu dihaluskan"
- "10 butir bawang merah"
- "5 butir bawang putih"
- "1/2 butir pala"
- "4 cm jahe"
- "1 sendok makan ketumbar sangrai"
- "1 sendok teh merica sangrai"
- "1/2 sedok teh jintan sangrai"
- " Bumbu lainnya"
- "3 batang kayu manis"
- "3 batang serai ambil bagian putihnya dan memarkan"
- "8 butir cengkeh"
- "4 butir kapulaga"
- "3 butir kembang lawangpekakstar anise"
- "2 sendok teh garam"
- "1 sendok teh kaldu bubuk"
- " Pelengkap"
- "4 sendok makan bawang merah goreng"
- "1 sendok makan kismis optional"
- "3 sendok makan nanas cincang kalengan optional"
recipeinstructions:
- "Siapkan ayam, letakkan ayam di atas wadah datar atau talenan. Gosok permukaan kulit ayam dengan garam hingga licin dan halus, kalau perlu gosokkan juga garam ke dalam rongga ayam. Lakukan ini pada seluruh permukaan ayam, jangan ada bagian yang terlewat. Cara ini membuat ayam menjadi bebas bau."
- "Cuci bersih ayam di air mengalir, pada saat ini anda bisa melihat ayam terlihat kesat dan kinclong bebas rambut-rambut halus dan kulit ari yang masih suka menempel."
- "Potong ayam kecil-kecil, kira-kira seukuran dua ruas jari telunjuk, potong paha bagian bawah menjadi dua bagian. Kemudian tiriskan ayam dengan meletakkannya di wadah berlubang. Sisihkan."
- "Siapkan penggorengan, beri 3 sendok makan minyak dan panaskan. Goreng bawang bombay hingga warnanya kecoklatan, harum dan matang. Aduk-aduk selama bawang digoreng, proses ini cukup lama. Jika telah matang, angkat dan tiriskan. Bawang bombay goreng ini gunanya untuk taburan saat nasi matang."
- "Gunakan penggorengan bekas menggoreng bawang, jika masih ada sisa minyak disana maka tidak perlu manambahkan minyak yang baru. Jika minyak habis, beri 2 sendok makan minyak dan panaskan. Tumis cengkeh, kapulaga, kembang lawang, serai dan kayu manis, sebentar hingga tercium bau harum. Masukkan bumbu halus. Tumis hingga bumbu harum dan matang. Tambahkan 100 ml air, garam, dan kaldu bubuk, aduk rata."
- "Masukkan potongan ayam ke dalam tumisan bumbu, aduk-aduk hingga ayam tercampur bumbu dan biarkan ayam dimasak hingga berubah warna. Tambahkan 400 ml air ke dalam ayam, tutup wajan dan masak hingga ayam matang. Cicipi rasanya, jika kurang asin tambahkan garam."
- "Jika ayam telah empuk dan matang, angkat ayam dari wajan. Sisihkan."
- "Masukkan beras ke dalam rice cooker. Tuangkan air kaldu bumbu bekas menumis ayam. Tambahkan air lagi hingga kira-kira cukup untuk memasak nasi. Perlu diingat nasi kebuli biasanya teksturnya tidak lembek jadi jangan menambahkan banyak air ke dalam rice cooker. Gunakan air secukupnya. Masak hingga nasi matang. Cicipi rasanya, jika kurang asin tambahkan garam. Aduk-aduk nasi di dalam rice cooker agar remah dan tidak menggumpal. Buang serai, kayu manis dan kembang lawang yang terlihat di dalam nas"
- "Jika anda menggunakan kismis dan potongan nanas, masukkan pada tahap ini dan aduk rata. Tutup rice cooker dan biarkan nasi hangat di dalam rice cooker."
- "Siapkan minyak agak banyak di wajan. Panaskan hingga benar-benar panas. Goreng potongan ayam yang telah matang ke dalam minyak hingga coklat keemasan. Atau setengah matang jika anda suka. Angkat dan tiriskan."
- "Siapkan piring saji, sendokkan nasi ke dalam piring, taburi dengan bawang bombay dan bawang merah goreng. Sajikan dengan ayam goreng."
categories:
- Resep
tags:
- nasi
- kebuli
- ayam

katakunci: nasi kebuli ayam 
nutrition: 215 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dinner

---


![Nasi kebuli ayam goreng versi rice cooker](https://img-global.cpcdn.com/recipes/abc1155302abc469/680x482cq70/nasi-kebuli-ayam-goreng-versi-rice-cooker-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan olahan menggugah selera buat orang tercinta adalah hal yang memuaskan bagi anda sendiri. Tugas seorang  wanita bukan cuma menangani rumah saja, namun anda pun harus menyediakan kebutuhan nutrisi terpenuhi dan juga masakan yang disantap orang tercinta wajib menggugah selera.

Di masa  sekarang, kita sebenarnya mampu membeli hidangan siap saji walaupun tidak harus capek memasaknya dahulu. Namun banyak juga lho orang yang memang mau menghidangkan yang terbaik untuk orang yang dicintainya. Sebab, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan orang tercinta. 



Apakah anda merupakan salah satu penikmat nasi kebuli ayam goreng versi rice cooker?. Asal kamu tahu, nasi kebuli ayam goreng versi rice cooker merupakan makanan khas di Indonesia yang sekarang digemari oleh orang-orang dari hampir setiap wilayah di Indonesia. Kalian dapat memasak nasi kebuli ayam goreng versi rice cooker sendiri di rumahmu dan boleh dijadikan makanan kesenanganmu di hari liburmu.

Kita tidak perlu bingung jika kamu ingin memakan nasi kebuli ayam goreng versi rice cooker, karena nasi kebuli ayam goreng versi rice cooker tidak sukar untuk didapatkan dan juga kita pun bisa membuatnya sendiri di rumah. nasi kebuli ayam goreng versi rice cooker bisa dibuat lewat berbagai cara. Saat ini ada banyak banget cara kekinian yang membuat nasi kebuli ayam goreng versi rice cooker lebih lezat.

Resep nasi kebuli ayam goreng versi rice cooker pun gampang untuk dibikin, lho. Kamu tidak usah capek-capek untuk memesan nasi kebuli ayam goreng versi rice cooker, sebab Kita dapat membuatnya sendiri di rumah. Untuk Kalian yang ingin mencobanya, inilah resep untuk membuat nasi kebuli ayam goreng versi rice cooker yang enak yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Nasi kebuli ayam goreng versi rice cooker:

1. Siapkan 1 ekor ayam, saya menggunakan ayam negeri + 4 sendok makan garam kasar
1. Gunakan 500 gram beras, cuci bersih dan tiriskan
1. Siapkan 800 ml air
1. Gunakan 1 butir bawang bombay, belah dua dan rajang setipis mungkin
1. Siapkan  Bumbu dihaluskan:
1. Sediakan 10 butir bawang merah
1. Siapkan 5 butir bawang putih
1. Siapkan 1/2 butir pala
1. Sediakan 4 cm jahe
1. Sediakan 1 sendok makan ketumbar, sangrai
1. Ambil 1 sendok teh merica, sangrai
1. Ambil 1/2 sedok teh jintan, sangrai
1. Siapkan  Bumbu lainnya:
1. Sediakan 3 batang kayu manis
1. Gunakan 3 batang serai, ambil bagian putihnya dan memarkan
1. Ambil 8 butir cengkeh
1. Gunakan 4 butir kapulaga
1. Sediakan 3 butir kembang lawang/pekak/star anise
1. Ambil 2 sendok teh garam
1. Ambil 1 sendok teh kaldu bubuk
1. Gunakan  Pelengkap:
1. Gunakan 4 sendok makan bawang merah goreng
1. Gunakan 1 sendok makan kismis (optional)
1. Siapkan 3 sendok makan nanas cincang, kalengan (optional)




<!--inarticleads2-->

##### Langkah-langkah membuat Nasi kebuli ayam goreng versi rice cooker:

1. Siapkan ayam, letakkan ayam di atas wadah datar atau talenan. Gosok permukaan kulit ayam dengan garam hingga licin dan halus, kalau perlu gosokkan juga garam ke dalam rongga ayam. Lakukan ini pada seluruh permukaan ayam, jangan ada bagian yang terlewat. Cara ini membuat ayam menjadi bebas bau.
1. Cuci bersih ayam di air mengalir, pada saat ini anda bisa melihat ayam terlihat kesat dan kinclong bebas rambut-rambut halus dan kulit ari yang masih suka menempel.
1. Potong ayam kecil-kecil, kira-kira seukuran dua ruas jari telunjuk, potong paha bagian bawah menjadi dua bagian. Kemudian tiriskan ayam dengan meletakkannya di wadah berlubang. Sisihkan.
1. Siapkan penggorengan, beri 3 sendok makan minyak dan panaskan. Goreng bawang bombay hingga warnanya kecoklatan, harum dan matang. Aduk-aduk selama bawang digoreng, proses ini cukup lama. Jika telah matang, angkat dan tiriskan. Bawang bombay goreng ini gunanya untuk taburan saat nasi matang.
1. Gunakan penggorengan bekas menggoreng bawang, jika masih ada sisa minyak disana maka tidak perlu manambahkan minyak yang baru. Jika minyak habis, beri 2 sendok makan minyak dan panaskan. Tumis cengkeh, kapulaga, kembang lawang, serai dan kayu manis, sebentar hingga tercium bau harum. Masukkan bumbu halus. Tumis hingga bumbu harum dan matang. Tambahkan 100 ml air, garam, dan kaldu bubuk, aduk rata.
1. Masukkan potongan ayam ke dalam tumisan bumbu, aduk-aduk hingga ayam tercampur bumbu dan biarkan ayam dimasak hingga berubah warna. Tambahkan 400 ml air ke dalam ayam, tutup wajan dan masak hingga ayam matang. Cicipi rasanya, jika kurang asin tambahkan garam.
1. Jika ayam telah empuk dan matang, angkat ayam dari wajan. Sisihkan.
1. Masukkan beras ke dalam rice cooker. Tuangkan air kaldu bumbu bekas menumis ayam. Tambahkan air lagi hingga kira-kira cukup untuk memasak nasi. Perlu diingat nasi kebuli biasanya teksturnya tidak lembek jadi jangan menambahkan banyak air ke dalam rice cooker. Gunakan air secukupnya. Masak hingga nasi matang. Cicipi rasanya, jika kurang asin tambahkan garam. Aduk-aduk nasi di dalam rice cooker agar remah dan tidak menggumpal. Buang serai, kayu manis dan kembang lawang yang terlihat di dalam nas
1. Jika anda menggunakan kismis dan potongan nanas, masukkan pada tahap ini dan aduk rata. Tutup rice cooker dan biarkan nasi hangat di dalam rice cooker.
1. Siapkan minyak agak banyak di wajan. Panaskan hingga benar-benar panas. Goreng potongan ayam yang telah matang ke dalam minyak hingga coklat keemasan. Atau setengah matang jika anda suka. Angkat dan tiriskan.
1. Siapkan piring saji, sendokkan nasi ke dalam piring, taburi dengan bawang bombay dan bawang merah goreng. Sajikan dengan ayam goreng.




Ternyata cara membuat nasi kebuli ayam goreng versi rice cooker yang enak tidak ribet ini mudah banget ya! Kamu semua bisa memasaknya. Resep nasi kebuli ayam goreng versi rice cooker Sesuai banget buat anda yang baru akan belajar memasak ataupun bagi kamu yang sudah ahli memasak.

Tertarik untuk mulai mencoba buat resep nasi kebuli ayam goreng versi rice cooker mantab sederhana ini? Kalau anda mau, ayo kamu segera buruan siapkan alat-alat dan bahan-bahannya, lalu bikin deh Resep nasi kebuli ayam goreng versi rice cooker yang enak dan tidak ribet ini. Sangat mudah kan. 

Jadi, daripada kalian diam saja, maka kita langsung hidangkan resep nasi kebuli ayam goreng versi rice cooker ini. Pasti anda tak akan nyesel bikin resep nasi kebuli ayam goreng versi rice cooker lezat sederhana ini! Selamat mencoba dengan resep nasi kebuli ayam goreng versi rice cooker mantab sederhana ini di tempat tinggal kalian sendiri,oke!.

