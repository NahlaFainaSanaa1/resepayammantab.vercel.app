---
description: "Resep Ayam Goreng Sambal Matah yang lezat Untuk Jualan"
title: "Resep Ayam Goreng Sambal Matah yang lezat Untuk Jualan"
slug: 54-resep-ayam-goreng-sambal-matah-yang-lezat-untuk-jualan
date: 2021-04-22T05:48:42.268Z
image: https://img-global.cpcdn.com/recipes/9460161d2089d7dd/680x482cq70/ayam-goreng-sambal-matah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9460161d2089d7dd/680x482cq70/ayam-goreng-sambal-matah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9460161d2089d7dd/680x482cq70/ayam-goreng-sambal-matah-foto-resep-utama.jpg
author: Frances Manning
ratingvalue: 3.3
reviewcount: 10
recipeingredient:
- " Untuk ayam"
- "1 1/2 ekor ayam kampung ukuran kecil 1 ekor potong menjadi 4 bagian"
- " Optional tahu tempe"
- "4 iris lengkuas parut boleh dibanyakin kalau mau"
- "1 batang serai memarkan"
- "3 lbr daun salam"
- "5 lbr daun jeruk"
- "1,2 L air"
- "2-3 sdt kaldu ayam atau jamur bubuk"
- "4 mata asam Jawa"
- "secukupnya Minyak goreng"
- " Bumbu halus ayam"
- "5 butir bawang merah"
- "3 siung bawang putih"
- "2 sdt biji ketumbar"
- " Sejari telunjuk kunyit kupas dan bakar"
- "1 sdt garam"
- " Sambal matah"
- "12 butir bawang merah iris tipis"
- "3-4 batang serai dicacah halus atau iris tipis bagian putih saja yang masih muda"
- "4 siung bawang putih cacah halus"
- "30 buah cabai rawit merah iris tipis"
- "8-10 lbr daun jeruk buang serat nya dan iris tipis"
- "2 buah jeruk limau"
- "3/4 sdt Garam"
- "1 sdt kaldu ayam atau jamur bubuk"
- "1 sdt gula pasir"
- "secukupnya Minyak goreng panas"
recipeinstructions:
- "Masukkan semua bahan ayam bersama bumbu halus. Masak dengan api kecil hingga empuk dan kuah habis. Bumbu halus saya suka ganti dengan Bumbu Dasar Kuning di buku saya “Masak Tanpa Ribet” Jadi praktis banget, engga harus uleg bumbu lagi. Siapkan wajan penggorengan, goreng ayam hingga kecokelatan. Tiriskan. Untuk sambal matah: Masukkan semua bahan kecuali minyak dalam mangkuk. Tambahkan minyak panas sisa menggoreng ayam. Aduk rata. Tambahkan perasan jeruk limau."
- "Sajikan ayam goreng dengan nasi putih hangat, lalapan dan sambal matah di atasnya 👍🏻 Untuk 4-6 porsi"
categories:
- Resep
tags:
- ayam
- goreng
- sambal

katakunci: ayam goreng sambal 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Goreng Sambal Matah](https://img-global.cpcdn.com/recipes/9460161d2089d7dd/680x482cq70/ayam-goreng-sambal-matah-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan hidangan lezat buat keluarga tercinta merupakan hal yang mengasyikan bagi kamu sendiri. Kewajiban seorang istri bukan sekedar menjaga rumah saja, tetapi kamu juga harus memastikan kebutuhan nutrisi tercukupi dan juga masakan yang dikonsumsi anak-anak harus lezat.

Di era  saat ini, kamu memang bisa membeli olahan siap saji walaupun tanpa harus repot mengolahnya lebih dulu. Namun ada juga lho orang yang memang ingin menyajikan yang terbaik bagi orang yang dicintainya. Karena, memasak sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera famili. 



Mungkinkah anda adalah seorang penikmat ayam goreng sambal matah?. Tahukah kamu, ayam goreng sambal matah adalah hidangan khas di Nusantara yang kini digemari oleh banyak orang dari hampir setiap daerah di Nusantara. Kamu bisa membuat ayam goreng sambal matah hasil sendiri di rumah dan pasti jadi camilan kegemaranmu di hari libur.

Kalian tak perlu bingung untuk mendapatkan ayam goreng sambal matah, sebab ayam goreng sambal matah sangat mudah untuk ditemukan dan kalian pun dapat mengolahnya sendiri di tempatmu. ayam goreng sambal matah boleh dimasak dengan beragam cara. Kini telah banyak resep kekinian yang membuat ayam goreng sambal matah semakin lebih lezat.

Resep ayam goreng sambal matah pun mudah sekali dibuat, lho. Anda jangan ribet-ribet untuk memesan ayam goreng sambal matah, sebab Kalian dapat menghidangkan di rumahmu. Bagi Kita yang akan menyajikannya, berikut ini resep menyajikan ayam goreng sambal matah yang nikamat yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Goreng Sambal Matah:

1. Siapkan  Untuk ayam
1. Gunakan 1 1/2 ekor ayam kampung ukuran kecil, 1 ekor potong menjadi 4 bagian
1. Sediakan  Optional: tahu tempe
1. Ambil 4 iris lengkuas, parut (boleh dibanyakin kalau mau)
1. Gunakan 1 batang serai, memarkan
1. Siapkan 3 lbr daun salam
1. Ambil 5 lbr daun jeruk
1. Gunakan 1,2 L air
1. Sediakan 2-3 sdt kaldu ayam atau jamur bubuk
1. Sediakan 4 mata asam Jawa
1. Gunakan secukupnya Minyak goreng
1. Siapkan  Bumbu halus ayam:
1. Ambil 5 butir bawang merah
1. Gunakan 3 siung bawang putih
1. Gunakan 2 sdt biji ketumbar
1. Gunakan  Sejari telunjuk kunyit, kupas dan bakar
1. Sediakan 1 sdt garam
1. Sediakan  Sambal matah:
1. Ambil 12 butir bawang merah, iris tipis
1. Ambil 3-4 batang serai dicacah halus atau iris tipis (bagian putih saja yang masih muda)
1. Siapkan 4 siung bawang putih, cacah halus
1. Sediakan 30 buah cabai rawit merah, iris tipis
1. Ambil 8-10 lbr daun jeruk, buang serat nya dan iris tipis
1. Sediakan 2 buah jeruk limau
1. Gunakan 3/4 sdt Garam
1. Sediakan 1 sdt kaldu ayam atau jamur bubuk
1. Ambil 1 sdt gula pasir
1. Ambil secukupnya Minyak goreng panas




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Sambal Matah:

1. Masukkan semua bahan ayam bersama bumbu halus. Masak dengan api kecil hingga empuk dan kuah habis. Bumbu halus saya suka ganti dengan Bumbu Dasar Kuning di buku saya “Masak Tanpa Ribet” Jadi praktis banget, engga harus uleg bumbu lagi. - Siapkan wajan penggorengan, goreng ayam hingga kecokelatan. Tiriskan. - Untuk sambal matah: Masukkan semua bahan kecuali minyak dalam mangkuk. - Tambahkan minyak panas sisa menggoreng ayam. Aduk rata. - Tambahkan perasan jeruk limau.
1. Sajikan ayam goreng dengan nasi putih hangat, lalapan dan sambal matah di atasnya 👍🏻 - Untuk 4-6 porsi




Ternyata resep ayam goreng sambal matah yang lezat simple ini enteng sekali ya! Kamu semua mampu menghidangkannya. Cara buat ayam goreng sambal matah Sangat sesuai banget buat kita yang sedang belajar memasak atau juga bagi anda yang telah jago memasak.

Tertarik untuk mulai mencoba buat resep ayam goreng sambal matah mantab tidak ribet ini? Kalau kalian tertarik, yuk kita segera buruan siapkan alat dan bahan-bahannya, lalu bikin deh Resep ayam goreng sambal matah yang lezat dan tidak rumit ini. Betul-betul mudah kan. 

Maka, ketimbang anda berfikir lama-lama, maka kita langsung buat resep ayam goreng sambal matah ini. Dijamin kalian tak akan nyesel bikin resep ayam goreng sambal matah lezat sederhana ini! Selamat berkreasi dengan resep ayam goreng sambal matah enak tidak rumit ini di rumah kalian sendiri,oke!.

