---
description: "Bahan-bahan Ayam Goreng Saus Mentega ala resto ft Nasi Daun Jeruk #2 yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Goreng Saus Mentega ala resto ft Nasi Daun Jeruk #2 yang nikmat dan Mudah Dibuat"
slug: 314-bahan-bahan-ayam-goreng-saus-mentega-ala-resto-ft-nasi-daun-jeruk-2-yang-nikmat-dan-mudah-dibuat
date: 2021-07-01T05:16:52.483Z
image: https://img-global.cpcdn.com/recipes/264ec5d65a0e3fcc/680x482cq70/ayam-goreng-saus-mentega-ala-resto-ft-nasi-daun-jeruk-2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/264ec5d65a0e3fcc/680x482cq70/ayam-goreng-saus-mentega-ala-resto-ft-nasi-daun-jeruk-2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/264ec5d65a0e3fcc/680x482cq70/ayam-goreng-saus-mentega-ala-resto-ft-nasi-daun-jeruk-2-foto-resep-utama.jpg
author: Ophelia McKenzie
ratingvalue: 3.4
reviewcount: 10
recipeingredient:
- "300 gram paha ayam potong kecil aku pakai dada ayam fillet"
- "2 sdm maizena"
- "1 butir telur kocok lepas"
- " Bumbu Marinasi "
- "3 siung bawang putih cincang halus"
- "1 cm jahe cincang halus"
- "30 ml saus tiram"
- "75 ml minyak goreng"
- " Bahan saus mentega "
- "100 gram margarin"
- "1 buah bawang bombay iris"
- "3 siung bawang putih iris"
- "5 siung bawang merah iris"
- "30 ml saus tiram"
- "50 ml kecap Inggris"
- "30 ml kecap manis"
- "Secukupnya garam"
- "Secukupnya merica"
- "Secukupnya kaldu jamur"
- " Pelengkap "
- " Jeruk limau daun bawang"
- " Bahan Nasi daun jeruk "
- "250 gram nasi putih 2 porsi nasi"
- "30 ml minyak goreng"
- "2 siung bawang putih cincang halus"
- "6 lembar daun jeruk iris"
- "1 sdm margarin"
- "1/2 sdt garam"
- "1/4 sdt gula pasir"
- "1/8 sdt merica"
- "Secukupnya kaldu jamur"
recipeinstructions:
- "Campur ayam dengan bahan marinasi : bawang putih, jahe, saus tiram, telur dan maizena. Aduk rata dan diamkan sesaat"
- "Goreng ayam sampai matang, crispy, dan kecoklatan. Angkat, tiriskan dan sisihkan."
- "Tumis dengan margarin : bawang bombay, bawang merah, bawang putih sampai wangi"
- "Masukkan kecap manis, saos tiram, dan kecap inggris. Aduk rata dan koreksi rasa. Jika kurang pas bisa bubuhi garam, merica, dan kaldu jamur."
- "Masukkan ayam, aduk sampai ayam terbalut saus. Angkat dan sisihkan."
- "Panaskan minyak, tumis bawang putih dan daun jeruk sampai wangi. Aduk rata."
- "Masukkan nasi, aduk rata."
- "Sisihkan nasi dipinggir wajan, tambahkan margarin. Aduk rata."
- "Bubuhi dengan garam, gula, merica dan kaldu jamur. Aduk rata dan koreksi rasa"
- "Sajikan ayam goreng saus mentega dan nasi daun jeruk"
categories:
- Resep
tags:
- ayam
- goreng
- saus

katakunci: ayam goreng saus 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Goreng Saus Mentega ala resto ft Nasi Daun Jeruk #2](https://img-global.cpcdn.com/recipes/264ec5d65a0e3fcc/680x482cq70/ayam-goreng-saus-mentega-ala-resto-ft-nasi-daun-jeruk-2-foto-resep-utama.jpg)

Apabila kita seorang orang tua, menyediakan santapan enak pada famili merupakan suatu hal yang menggembirakan bagi kita sendiri. Tanggung jawab seorang ibu Tidak sekedar menjaga rumah saja, tetapi kamu pun wajib menyediakan keperluan nutrisi terpenuhi dan juga panganan yang disantap keluarga tercinta wajib sedap.

Di zaman  saat ini, kita sebenarnya mampu membeli olahan jadi meski tanpa harus susah membuatnya dahulu. Namun ada juga lho mereka yang memang ingin memberikan hidangan yang terlezat untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Mungkinkah anda adalah seorang penggemar ayam goreng saus mentega ala resto ft nasi daun jeruk #2?. Tahukah kamu, ayam goreng saus mentega ala resto ft nasi daun jeruk #2 adalah makanan khas di Nusantara yang kini disenangi oleh orang-orang di hampir setiap tempat di Indonesia. Kalian dapat membuat ayam goreng saus mentega ala resto ft nasi daun jeruk #2 kreasi sendiri di rumahmu dan boleh dijadikan camilan favoritmu di akhir pekanmu.

Anda tidak perlu bingung jika kamu ingin menyantap ayam goreng saus mentega ala resto ft nasi daun jeruk #2, sebab ayam goreng saus mentega ala resto ft nasi daun jeruk #2 gampang untuk dicari dan juga kamu pun boleh membuatnya sendiri di rumah. ayam goreng saus mentega ala resto ft nasi daun jeruk #2 bisa dimasak memalui beraneka cara. Kini pun sudah banyak cara modern yang membuat ayam goreng saus mentega ala resto ft nasi daun jeruk #2 semakin lebih enak.

Resep ayam goreng saus mentega ala resto ft nasi daun jeruk #2 juga mudah sekali untuk dibikin, lho. Kita jangan capek-capek untuk membeli ayam goreng saus mentega ala resto ft nasi daun jeruk #2, lantaran Anda dapat menyiapkan sendiri di rumah. Bagi Kita yang akan membuatnya, berikut ini cara menyajikan ayam goreng saus mentega ala resto ft nasi daun jeruk #2 yang nikamat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Goreng Saus Mentega ala resto ft Nasi Daun Jeruk #2:

1. Gunakan 300 gram paha ayam potong kecil (aku pakai dada ayam fillet)
1. Ambil 2 sdm maizena
1. Gunakan 1 butir telur kocok lepas
1. Sediakan  Bumbu Marinasi :
1. Gunakan 3 siung bawang putih, cincang halus
1. Gunakan 1 cm jahe, cincang halus
1. Sediakan 30 ml saus tiram
1. Sediakan 75 ml minyak goreng
1. Sediakan  Bahan saus mentega :
1. Siapkan 100 gram margarin
1. Ambil 1 buah bawang bombay, iris
1. Siapkan 3 siung bawang putih, iris
1. Sediakan 5 siung bawang merah, iris
1. Siapkan 30 ml saus tiram
1. Sediakan 50 ml kecap Inggris
1. Sediakan 30 ml kecap manis
1. Sediakan Secukupnya garam
1. Siapkan Secukupnya merica
1. Siapkan Secukupnya kaldu jamur
1. Sediakan  Pelengkap :
1. Ambil  Jeruk limau, daun bawang
1. Siapkan  Bahan Nasi daun jeruk :
1. Sediakan 250 gram nasi putih (2 porsi nasi)
1. Sediakan 30 ml minyak goreng
1. Siapkan 2 siung bawang putih, cincang halus
1. Sediakan 6 lembar daun jeruk, iris
1. Sediakan 1 sdm margarin
1. Siapkan 1/2 sdt garam
1. Siapkan 1/4 sdt gula pasir
1. Siapkan 1/8 sdt merica
1. Siapkan Secukupnya kaldu jamur




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Saus Mentega ala resto ft Nasi Daun Jeruk #2:

1. Campur ayam dengan bahan marinasi : bawang putih, jahe, saus tiram, telur dan maizena. Aduk rata dan diamkan sesaat
1. Goreng ayam sampai matang, crispy, dan kecoklatan. Angkat, tiriskan dan sisihkan.
1. Tumis dengan margarin : bawang bombay, bawang merah, bawang putih sampai wangi
1. Masukkan kecap manis, saos tiram, dan kecap inggris. Aduk rata dan koreksi rasa. Jika kurang pas bisa bubuhi garam, merica, dan kaldu jamur.
1. Masukkan ayam, aduk sampai ayam terbalut saus. Angkat dan sisihkan.
1. Panaskan minyak, tumis bawang putih dan daun jeruk sampai wangi. Aduk rata.
1. Masukkan nasi, aduk rata.
1. Sisihkan nasi dipinggir wajan, tambahkan margarin. Aduk rata.
1. Bubuhi dengan garam, gula, merica dan kaldu jamur. Aduk rata dan koreksi rasa
1. Sajikan ayam goreng saus mentega dan nasi daun jeruk




Wah ternyata cara buat ayam goreng saus mentega ala resto ft nasi daun jeruk #2 yang lezat sederhana ini mudah sekali ya! Kamu semua dapat menghidangkannya. Cara buat ayam goreng saus mentega ala resto ft nasi daun jeruk #2 Sangat sesuai banget untuk kita yang sedang belajar memasak ataupun untuk anda yang sudah hebat dalam memasak.

Apakah kamu ingin mulai mencoba buat resep ayam goreng saus mentega ala resto ft nasi daun jeruk #2 lezat tidak ribet ini? Kalau anda mau, yuk kita segera menyiapkan peralatan dan bahannya, setelah itu bikin deh Resep ayam goreng saus mentega ala resto ft nasi daun jeruk #2 yang nikmat dan simple ini. Betul-betul taidak sulit kan. 

Maka, daripada anda berfikir lama-lama, hayo kita langsung saja sajikan resep ayam goreng saus mentega ala resto ft nasi daun jeruk #2 ini. Pasti kamu tak akan nyesel bikin resep ayam goreng saus mentega ala resto ft nasi daun jeruk #2 nikmat tidak rumit ini! Selamat berkreasi dengan resep ayam goreng saus mentega ala resto ft nasi daun jeruk #2 lezat simple ini di rumah kalian sendiri,ya!.

