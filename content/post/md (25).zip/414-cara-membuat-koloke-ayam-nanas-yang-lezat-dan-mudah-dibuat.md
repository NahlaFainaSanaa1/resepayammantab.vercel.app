---
description: "Cara membuat Koloke Ayam Nanas yang lezat dan Mudah Dibuat"
title: "Cara membuat Koloke Ayam Nanas yang lezat dan Mudah Dibuat"
slug: 414-cara-membuat-koloke-ayam-nanas-yang-lezat-dan-mudah-dibuat
date: 2021-06-28T08:07:27.099Z
image: https://img-global.cpcdn.com/recipes/e1f76a658607e9f7/680x482cq70/koloke-ayam-nanas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e1f76a658607e9f7/680x482cq70/koloke-ayam-nanas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e1f76a658607e9f7/680x482cq70/koloke-ayam-nanas-foto-resep-utama.jpg
author: Lottie Rodriguez
ratingvalue: 4.7
reviewcount: 9
recipeingredient:
- " Ayam Tepung"
- "200 gram ayam fillet potong kotak kecil"
- "1/2 sdt kaldu"
- "1/2 sdt garam"
- "1/4 sdt lada"
- "3 sdm munjung tepung terigu"
- "1 sdm munjung tepung tapioka"
- "Secukupnya minyak untuk menggoreng"
- " Bahan lainnya"
- "1/4 buah nanas potongpotong"
- "2 batang daun bawang potong memanjang"
- "1 buah tomat ukuran kecil potong 4"
- "1/2 buah bawang bombai iris tipis"
- "2 siung bawang putih iris tipis"
- "2 sdm saus sambal"
- "1 sdm saus tomat"
- "1 sdt saus tiram"
- "1/4 sdt kaldu"
- "Sejumput lada bubuk"
- "50 ml air"
- " Garam dan gula untuk koreksi rasa"
recipeinstructions:
- "Marinasi ayam dengan garam, kaldu, dan lada diamkan 15 menit. Lalu tambahkan tepung terigu dan tepung tapioka. Remas-remas hingga tepung menempel"
- "Panaskan minyak dan goreng ayam hingga matang dan kecoklatan. Angkat dan tiriskan"
- "Tumis bawang putih dengan sedikit minyak hingga harum dan kecoklatan lalu tambakan daun bawang, bawang bombai, tomat dan nanas aduk rata"
- "Lalu tambakan saus sambal, saus tomat, saus tiram, lada, kaldu dan air aduk rata. Setelah itu masukkan ayam. Aduk-aduk hingga air sedikit mengering. Tes rasa"
- "Koloke ayam nanas siap disajikan dengan nasi panas"
categories:
- Resep
tags:
- koloke
- ayam
- nanas

katakunci: koloke ayam nanas 
nutrition: 124 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch

---


![Koloke Ayam Nanas](https://img-global.cpcdn.com/recipes/e1f76a658607e9f7/680x482cq70/koloke-ayam-nanas-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan masakan mantab bagi keluarga merupakan hal yang menyenangkan bagi kita sendiri. Kewajiban seorang  wanita Tidak sekadar mengerjakan pekerjaan rumah saja, tapi kamu pun wajib memastikan kebutuhan nutrisi terpenuhi dan hidangan yang dimakan keluarga tercinta harus nikmat.

Di era  saat ini, anda memang dapat memesan masakan instan meski tanpa harus repot memasaknya dahulu. Namun banyak juga lho mereka yang memang ingin menghidangkan yang terenak bagi orang yang dicintainya. Pasalnya, memasak yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan masakan kesukaan keluarga tercinta. 



Apakah anda adalah seorang penikmat koloke ayam nanas?. Tahukah kamu, koloke ayam nanas merupakan sajian khas di Indonesia yang kini disukai oleh banyak orang dari hampir setiap wilayah di Indonesia. Kamu bisa memasak koloke ayam nanas kreasi sendiri di rumah dan boleh jadi hidangan favorit di akhir pekanmu.

Kalian tidak perlu bingung jika kamu ingin mendapatkan koloke ayam nanas, karena koloke ayam nanas tidak sukar untuk dicari dan juga kamu pun bisa membuatnya sendiri di tempatmu. koloke ayam nanas dapat dimasak dengan berbagai cara. Kini pun ada banyak banget cara kekinian yang membuat koloke ayam nanas semakin lebih enak.

Resep koloke ayam nanas juga gampang sekali untuk dibikin, lho. Anda tidak perlu capek-capek untuk membeli koloke ayam nanas, lantaran Anda mampu menyajikan di rumahmu. Bagi Kalian yang akan mencobanya, dibawah ini merupakan resep untuk menyajikan koloke ayam nanas yang mantab yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Koloke Ayam Nanas:

1. Siapkan  📌Ayam Tepung
1. Siapkan 200 gram ayam fillet potong kotak kecil
1. Siapkan 1/2 sdt kaldu
1. Sediakan 1/2 sdt garam
1. Gunakan 1/4 sdt lada
1. Siapkan 3 sdm munjung tepung terigu
1. Sediakan 1 sdm munjung tepung tapioka
1. Sediakan Secukupnya minyak untuk menggoreng
1. Siapkan  📌Bahan lainnya
1. Gunakan 1/4 buah nanas (potong-potong)
1. Siapkan 2 batang daun bawang potong memanjang
1. Sediakan 1 buah tomat ukuran kecil potong 4
1. Ambil 1/2 buah bawang bombai iris tipis
1. Sediakan 2 siung bawang putih iris tipis
1. Sediakan 2 sdm saus sambal
1. Sediakan 1 sdm saus tomat
1. Siapkan 1 sdt saus tiram
1. Gunakan 1/4 sdt kaldu
1. Siapkan Sejumput lada bubuk
1. Siapkan 50 ml air
1. Ambil  Garam dan gula untuk koreksi rasa




<!--inarticleads2-->

##### Langkah-langkah membuat Koloke Ayam Nanas:

1. Marinasi ayam dengan garam, kaldu, dan lada diamkan 15 menit. Lalu tambahkan tepung terigu dan tepung tapioka. Remas-remas hingga tepung menempel
1. Panaskan minyak dan goreng ayam hingga matang dan kecoklatan. Angkat dan tiriskan
1. Tumis bawang putih dengan sedikit minyak hingga harum dan kecoklatan lalu tambakan daun bawang, bawang bombai, tomat dan nanas aduk rata
1. Lalu tambakan saus sambal, saus tomat, saus tiram, lada, kaldu dan air aduk rata. Setelah itu masukkan ayam. Aduk-aduk hingga air sedikit mengering. Tes rasa
1. Koloke ayam nanas siap disajikan dengan nasi panas




Wah ternyata cara buat koloke ayam nanas yang mantab tidak rumit ini mudah banget ya! Kamu semua bisa membuatnya. Resep koloke ayam nanas Sesuai sekali untuk kita yang baru akan belajar memasak maupun juga bagi kalian yang sudah pandai memasak.

Tertarik untuk mencoba buat resep koloke ayam nanas lezat tidak rumit ini? Kalau anda ingin, mending kamu segera siapin alat dan bahan-bahannya, setelah itu buat deh Resep koloke ayam nanas yang lezat dan simple ini. Betul-betul gampang kan. 

Maka dari itu, daripada kalian diam saja, maka kita langsung saja hidangkan resep koloke ayam nanas ini. Dijamin anda tak akan nyesel sudah bikin resep koloke ayam nanas lezat simple ini! Selamat mencoba dengan resep koloke ayam nanas enak tidak rumit ini di tempat tinggal sendiri,ya!.

