---
description: "Bahan-bahan Ayam Ingkung Potong Sederhana Untuk Jualan"
title: "Bahan-bahan Ayam Ingkung Potong Sederhana Untuk Jualan"
slug: 237-bahan-bahan-ayam-ingkung-potong-sederhana-untuk-jualan
date: 2021-06-24T03:38:53.366Z
image: https://img-global.cpcdn.com/recipes/e44ffb54632108a6/680x482cq70/ayam-ingkung-potong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e44ffb54632108a6/680x482cq70/ayam-ingkung-potong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e44ffb54632108a6/680x482cq70/ayam-ingkung-potong-foto-resep-utama.jpg
author: Herbert Cannon
ratingvalue: 3
reviewcount: 5
recipeingredient:
- "1/2 ekor ayam"
- "500 ml santan kekentalan sedang"
- "2 batang sereh geprek"
- "2 lembar daun salam"
- "Seruas lengkuas geprek"
- "4 lembar daun jeruk"
- "2 sdm gula merah"
- "Secukupnya asam jawa"
- "1 buah jeruk nipis"
- "Secukupnya garam"
- "Secukupnya penyedap rasa"
- "1 sdt gula pasir"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas kunyit bakar"
- "3 butir kemiri sangrai"
- "1/2 ruas jahe"
- "1 sdt merica"
- "Sedikit lengkuas"
recipeinstructions:
- "Cuci bersih ayam kemudian lumuri dengan jeruk nipis dan diamkan kurleb 30menit"
- "Ulek bumbu halus dan bumbu cemplung"
- "Setelah 30menit cuci kembali ayam dan tiriskan"
- "Tumis bumbu halus sampai matang dan masukkan sereh, daun salam, daun jeruk, dan lengkuas"
- "Siapkan panci dan masukkan ayam, santan, dan bumbu yang sudah ditumis kedalam panci, tambahkan asam jawa, gula merah, garam, penyedap rasa, gula pasir dan aduk2. Kemudian nyalakan api dan tutup panci, tunggu sampai ayam empuk. Buka tutup panci, aduk2 lagi dan cek rasa dan keempukan ayam. Tunggu sampai kuah santan agak menyusut."
- "Setelah dirasa cukup kental kuahnya/agak menyusut, matikan apinya. Dan ayam ingkung siap dihilangkan dan disantap.."
categories:
- Resep
tags:
- ayam
- ingkung
- potong

katakunci: ayam ingkung potong 
nutrition: 132 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Ingkung Potong](https://img-global.cpcdn.com/recipes/e44ffb54632108a6/680x482cq70/ayam-ingkung-potong-foto-resep-utama.jpg)

Jika kamu seorang orang tua, menyediakan masakan mantab buat famili adalah suatu hal yang menyenangkan untuk anda sendiri. Tanggung jawab seorang istri bukan sekadar menjaga rumah saja, tetapi kamu juga harus memastikan kebutuhan gizi tercukupi dan santapan yang dikonsumsi orang tercinta harus mantab.

Di zaman  sekarang, kamu sebenarnya bisa mengorder panganan praktis tidak harus repot mengolahnya terlebih dahulu. Namun ada juga mereka yang memang mau menyajikan yang terenak bagi orang tercintanya. Sebab, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai dengan makanan kesukaan orang tercinta. 



Mungkinkah anda merupakan seorang penyuka ayam ingkung potong?. Asal kamu tahu, ayam ingkung potong merupakan makanan khas di Nusantara yang sekarang disukai oleh orang-orang di berbagai wilayah di Indonesia. Kita bisa menghidangkan ayam ingkung potong sendiri di rumahmu dan boleh dijadikan hidangan favoritmu di akhir pekanmu.

Kita tak perlu bingung untuk memakan ayam ingkung potong, lantaran ayam ingkung potong tidak sukar untuk didapatkan dan anda pun dapat mengolahnya sendiri di rumah. ayam ingkung potong bisa dibuat dengan beraneka cara. Kini pun telah banyak sekali cara modern yang menjadikan ayam ingkung potong semakin lebih mantap.

Resep ayam ingkung potong juga mudah sekali dihidangkan, lho. Kamu tidak usah ribet-ribet untuk membeli ayam ingkung potong, lantaran Kalian dapat membuatnya di rumah sendiri. Bagi Kita yang ingin membuatnya, dibawah ini merupakan cara menyajikan ayam ingkung potong yang mantab yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Ingkung Potong:

1. Gunakan 1/2 ekor ayam
1. Sediakan 500 ml santan kekentalan sedang
1. Sediakan 2 batang sereh geprek
1. Sediakan 2 lembar daun salam
1. Sediakan Seruas lengkuas geprek
1. Ambil 4 lembar daun jeruk
1. Gunakan 2 sdm gula merah
1. Sediakan Secukupnya asam jawa
1. Gunakan 1 buah jeruk nipis
1. Ambil Secukupnya garam
1. Ambil Secukupnya penyedap rasa
1. Siapkan 1 sdt gula pasir
1. Ambil  Bumbu halus
1. Ambil 5 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Gunakan 1 ruas kunyit bakar
1. Ambil 3 butir kemiri sangrai
1. Ambil 1/2 ruas jahe
1. Sediakan 1 sdt merica
1. Ambil Sedikit lengkuas




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Ingkung Potong:

1. Cuci bersih ayam kemudian lumuri dengan jeruk nipis dan diamkan kurleb 30menit
1. Ulek bumbu halus dan bumbu cemplung
1. Setelah 30menit cuci kembali ayam dan tiriskan
1. Tumis bumbu halus sampai matang dan masukkan sereh, daun salam, daun jeruk, dan lengkuas
1. Siapkan panci dan masukkan ayam, santan, dan bumbu yang sudah ditumis kedalam panci, tambahkan asam jawa, gula merah, garam, penyedap rasa, gula pasir dan aduk2. Kemudian nyalakan api dan tutup panci, tunggu sampai ayam empuk. Buka tutup panci, aduk2 lagi dan cek rasa dan keempukan ayam. Tunggu sampai kuah santan agak menyusut.
1. Setelah dirasa cukup kental kuahnya/agak menyusut, matikan apinya. Dan ayam ingkung siap dihilangkan dan disantap..




Wah ternyata cara buat ayam ingkung potong yang mantab sederhana ini mudah sekali ya! Anda Semua mampu mencobanya. Cara Membuat ayam ingkung potong Cocok banget buat kamu yang sedang belajar memasak ataupun bagi anda yang sudah jago memasak.

Tertarik untuk mencoba membikin resep ayam ingkung potong lezat tidak ribet ini? Kalau anda ingin, mending kamu segera buruan siapkan peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam ingkung potong yang lezat dan sederhana ini. Sungguh mudah kan. 

Jadi, daripada kalian berfikir lama-lama, yuk kita langsung saja bikin resep ayam ingkung potong ini. Dijamin kamu tiidak akan menyesal sudah bikin resep ayam ingkung potong mantab tidak rumit ini! Selamat mencoba dengan resep ayam ingkung potong lezat tidak rumit ini di tempat tinggal masing-masing,ya!.

