---
description: "Cara membuat Ayam bakar bumbu rujak yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam bakar bumbu rujak yang enak dan Mudah Dibuat"
slug: 198-cara-membuat-ayam-bakar-bumbu-rujak-yang-enak-dan-mudah-dibuat
date: 2021-05-04T04:03:28.923Z
image: https://img-global.cpcdn.com/recipes/c8802917ca01466f/680x482cq70/ayam-bakar-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c8802917ca01466f/680x482cq70/ayam-bakar-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c8802917ca01466f/680x482cq70/ayam-bakar-bumbu-rujak-foto-resep-utama.jpg
author: Marie George
ratingvalue: 5
reviewcount: 11
recipeingredient:
- "1 ekor ayam kampung"
- "1 serei geprek"
- "3 daun jeruk"
- "2 daun salam"
- "1 Jeruk nipis"
- "1 santan kara"
- "seperlunya Minyak goreng"
- " Bumbu halus"
- "6 bawang merah"
- "5 bawang putih"
- "6 cabe merah"
- "10 cabe rawit"
- "4 kemiri sangrai"
- "1/4 st terasi bakar"
- "1 sm ketumbar"
- "1/2 ruas jahe"
- "1/2 ruas kunir"
- "Sedikit asem tua"
- "2 lembar daun jeruk"
- "1 saset masako"
- "1 st garam"
- "1 st gula"
- "Sedikit gula merah"
recipeinstructions:
- "Cuci bersih ayam,potong jadi 4 bagian lumuri dengan garam dan jeruk nipis,diamkan sampai 30 menit."
- "Blender bumbu halus,kemudian tumis kasih daun jeruk,serei,daun salam sampai agak set kemudian kasih minyak goreng sedikit"
- "Masukkan air 1 gelas kemudian masukkan santan kara,aduk  Masukkan garam,gula,penyedap,gula merah Periksa rasa"
- "Cuci ayam yang direndam tadi,masukkan ayam tambahkan air sampai ayam tenggelam,ukep ayam sampai air set"
- "Siapkan grill,bakar ayam sambil oles2 ayam sisa bumbu tadi"
- "Angkat ayam, Sudah siap disantap Sajikan dengan nasi hangat.... Mantapp....👍😁"
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 103 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam bakar bumbu rujak](https://img-global.cpcdn.com/recipes/c8802917ca01466f/680x482cq70/ayam-bakar-bumbu-rujak-foto-resep-utama.jpg)

Apabila kalian seorang istri, menyuguhkan panganan sedap buat keluarga adalah hal yang membahagiakan bagi anda sendiri. Kewajiban seorang ibu bukan cuma mengerjakan pekerjaan rumah saja, tetapi anda pun wajib menyediakan keperluan nutrisi tercukupi dan olahan yang dimakan orang tercinta wajib enak.

Di waktu  saat ini, kita sebenarnya bisa mengorder hidangan instan walaupun tanpa harus ribet mengolahnya dulu. Tetapi ada juga mereka yang memang mau memberikan makanan yang terenak untuk keluarganya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai selera famili. 

Ayam dengan kuah bumbu rujak yang kental mungkin sudah pernah Anda coba. Bagaimana dengan ayam bakar dengan bumbu rujak? Rasanya juga sama lezatnya, namun semakin menggoda karena berpadu dengan aroma bakaran yang khas.

Mungkinkah kamu seorang penggemar ayam bakar bumbu rujak?. Tahukah kamu, ayam bakar bumbu rujak merupakan makanan khas di Nusantara yang kini disenangi oleh setiap orang dari berbagai daerah di Nusantara. Kita dapat menyajikan ayam bakar bumbu rujak kreasi sendiri di rumahmu dan pasti jadi makanan kesukaanmu di akhir pekan.

Kita jangan bingung untuk memakan ayam bakar bumbu rujak, lantaran ayam bakar bumbu rujak sangat mudah untuk dicari dan juga kalian pun bisa menghidangkannya sendiri di rumah. ayam bakar bumbu rujak dapat dimasak lewat beraneka cara. Saat ini sudah banyak resep kekinian yang menjadikan ayam bakar bumbu rujak lebih lezat.

Resep ayam bakar bumbu rujak juga gampang sekali dibuat, lho. Kalian tidak perlu repot-repot untuk membeli ayam bakar bumbu rujak, sebab Anda bisa menghidangkan di rumahmu. Bagi Kamu yang mau menghidangkannya, inilah cara untuk menyajikan ayam bakar bumbu rujak yang nikamat yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam bakar bumbu rujak:

1. Gunakan 1 ekor ayam kampung
1. Gunakan 1 serei geprek
1. Gunakan 3 daun jeruk
1. Ambil 2 daun salam
1. Sediakan 1 Jeruk nipis
1. Siapkan 1 santan kara
1. Siapkan seperlunya Minyak goreng
1. Siapkan  Bumbu halus
1. Gunakan 6 bawang merah
1. Ambil 5 bawang putih
1. Sediakan 6 cabe merah
1. Gunakan 10 cabe rawit
1. Sediakan 4 kemiri sangrai
1. Sediakan 1/4 st terasi bakar
1. Sediakan 1 sm ketumbar
1. Ambil 1/2 ruas jahe
1. Sediakan 1/2 ruas kunir
1. Gunakan Sedikit asem tua
1. Ambil 2 lembar daun jeruk
1. Ambil 1 saset masako
1. Ambil 1 st garam
1. Siapkan 1 st gula
1. Sediakan Sedikit gula merah


Apalagi jika keluarga gemar makan ayam, resep ini sangat cocok untuk disajikan sebagai variasi menu ayam. Ayam bakar bumbu rujak merupakan salah satu masakan yang mempunyai cita rasa khas pedas manis. Disebut sebagai ayam bakar dengan bumbu rujak, karena memang rasanya seperti rujak pada umumnya, dengan dominasi rasa pedas manis tersebut. Ayam bakar bumbu rujak adalah makanan khas Jawa yang berbahan dasar daging ayam yang masih berusia muda dan menggunakan bumbu dasar merah kemudian di bakar. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam bakar bumbu rujak:

1. Cuci bersih ayam,potong jadi 4 bagian lumuri dengan garam dan jeruk nipis,diamkan sampai 30 menit.
1. Blender bumbu halus,kemudian tumis kasih daun jeruk,serei,daun salam sampai agak set kemudian kasih minyak goreng sedikit
1. Masukkan air 1 gelas kemudian masukkan santan kara,aduk  - Masukkan garam,gula,penyedap,gula merah - Periksa rasa
1. Cuci ayam yang direndam tadi,masukkan ayam tambahkan air sampai ayam tenggelam,ukep ayam sampai air set
1. Siapkan grill,bakar ayam sambil oles2 ayam sisa bumbu tadi
1. Angkat ayam, - Sudah siap disantap - Sajikan dengan nasi hangat.... - Mantapp....👍😁


Bumbu dasar merah ialah bumbu yang terbuat dari garam, bawang putih, bawang merah, dan cabe merah. Ayam bumbu rujak is a typical Javanese food made from chicken meat which is still young and uses a red basic spice then grilled. A red base is a spice made from salt, garlic, onion, and red chili. Called seasoning rujak because there are many spices besides chili. Semoga senantiasa diberikan rahmat hidayah dari Allah SWT ya. 

Ternyata cara buat ayam bakar bumbu rujak yang mantab tidak rumit ini enteng sekali ya! Kalian semua dapat mencobanya. Cara buat ayam bakar bumbu rujak Sesuai banget untuk kita yang baru akan belajar memasak ataupun juga bagi anda yang sudah pandai dalam memasak.

Apakah kamu mau mulai mencoba membuat resep ayam bakar bumbu rujak mantab simple ini? Kalau anda mau, ayo kamu segera siapin peralatan dan bahan-bahannya, setelah itu buat deh Resep ayam bakar bumbu rujak yang enak dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka, daripada kalian diam saja, hayo kita langsung saja bikin resep ayam bakar bumbu rujak ini. Pasti kalian tak akan nyesel sudah buat resep ayam bakar bumbu rujak mantab tidak ribet ini! Selamat mencoba dengan resep ayam bakar bumbu rujak enak tidak rumit ini di rumah masing-masing,oke!.

