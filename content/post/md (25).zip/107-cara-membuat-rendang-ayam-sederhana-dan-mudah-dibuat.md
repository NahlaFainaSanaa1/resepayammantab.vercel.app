---
description: "Cara membuat Rendang Ayam Sederhana dan Mudah Dibuat"
title: "Cara membuat Rendang Ayam Sederhana dan Mudah Dibuat"
slug: 107-cara-membuat-rendang-ayam-sederhana-dan-mudah-dibuat
date: 2021-02-05T19:21:27.710Z
image: https://img-global.cpcdn.com/recipes/59d60d84db080f62/680x482cq70/rendang-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/59d60d84db080f62/680x482cq70/rendang-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/59d60d84db080f62/680x482cq70/rendang-ayam-foto-resep-utama.jpg
author: Barry Green
ratingvalue: 3.2
reviewcount: 5
recipeingredient:
- "1 ekor ayam berat 1kg  15 kg cuci bersih"
- "250 gr kentang mini cuci bersih"
- "1500 ml santan dari 3 butir kelapa ukuran besar"
- " Bumbu Halus "
- "200 gr cabe merah keriting"
- "50 gr rawit"
- "100 gr bawang merah"
- "10 siung bawang putih"
- "4 cm jahe"
- "3 ruas lengkuas"
- "3 cm kunyit"
- "1/2 buah pala ukuran besar"
- " Bumbu lainnya "
- "4 buah kapulaga"
- "3 buah bunga lawang"
- "6 buah cengkeh"
- "2 batang sereh"
- "10 lembar daun jeruk"
- "1 lembar daun kunyit"
- "2 sdt garam"
- "1/2 sdt kaldu bubuk"
- "1 sdm ketumbar bubuk"
- "1/2 sdt lada bubuk"
recipeinstructions:
- "Masukkan bumbu halus dan bumbu lainnya kedalam wajan. Masukkan santan."
- "Nyalakan api. Masak hingga santan mendidih sambil terus diaduk biar tidak pecah santan."
- "Setelah mendidih, masak terus hingga santan keluar minyak."
- "Setelah itu masukkan kentang mini. Terakhir masukan ayam. Masak hingga menjadi rendang."
categories:
- Resep
tags:
- rendang
- ayam

katakunci: rendang ayam 
nutrition: 186 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Lunch

---


![Rendang Ayam](https://img-global.cpcdn.com/recipes/59d60d84db080f62/680x482cq70/rendang-ayam-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan panganan menggugah selera untuk orang tercinta adalah suatu hal yang memuaskan untuk kita sendiri. Kewajiban seorang ibu Tidak sekedar menjaga rumah saja, tetapi anda pun harus menyediakan keperluan gizi tercukupi dan hidangan yang disantap anak-anak wajib nikmat.

Di era  sekarang, kalian sebenarnya dapat membeli olahan jadi meski tidak harus repot memasaknya lebih dulu. Namun ada juga lho mereka yang selalu mau memberikan hidangan yang terbaik bagi orang tercintanya. Karena, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai kesukaan keluarga. 



Apakah anda merupakan salah satu penggemar rendang ayam?. Asal kamu tahu, rendang ayam merupakan hidangan khas di Nusantara yang sekarang disenangi oleh orang-orang di hampir setiap daerah di Nusantara. Kamu bisa menyajikan rendang ayam buatan sendiri di rumahmu dan pasti jadi makanan favorit di akhir pekanmu.

Anda tidak perlu bingung untuk memakan rendang ayam, lantaran rendang ayam mudah untuk dicari dan kalian pun bisa membuatnya sendiri di tempatmu. rendang ayam bisa dibuat memalui bermacam cara. Kini pun sudah banyak banget cara modern yang menjadikan rendang ayam lebih nikmat.

Resep rendang ayam pun mudah untuk dibuat, lho. Kalian jangan capek-capek untuk membeli rendang ayam, tetapi Kita mampu menyajikan sendiri di rumah. Bagi Anda yang akan mencobanya, berikut resep untuk membuat rendang ayam yang lezat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Rendang Ayam:

1. Siapkan 1 ekor ayam (berat 1kg - 1,5 kg), cuci bersih
1. Ambil 250 gr kentang mini, cuci bersih
1. Ambil 1500 ml santan (dari 3 butir kelapa ukuran besar)
1. Sediakan  Bumbu Halus :
1. Siapkan 200 gr cabe merah keriting
1. Gunakan 50 gr rawit
1. Gunakan 100 gr bawang merah
1. Siapkan 10 siung bawang putih
1. Siapkan 4 cm jahe
1. Sediakan 3 ruas lengkuas
1. Siapkan 3 cm kunyit
1. Ambil 1/2 buah pala ukuran besar
1. Sediakan  Bumbu lainnya :
1. Siapkan 4 buah kapulaga
1. Gunakan 3 buah bunga lawang
1. Sediakan 6 buah cengkeh
1. Sediakan 2 batang sereh
1. Sediakan 10 lembar daun jeruk
1. Sediakan 1 lembar daun kunyit
1. Gunakan 2 sdt garam
1. Siapkan 1/2 sdt kaldu bubuk
1. Siapkan 1 sdm ketumbar bubuk
1. Sediakan 1/2 sdt lada bubuk




<!--inarticleads2-->

##### Cara menyiapkan Rendang Ayam:

1. Masukkan bumbu halus dan bumbu lainnya kedalam wajan. Masukkan santan.
1. Nyalakan api. Masak hingga santan mendidih sambil terus diaduk biar tidak pecah santan.
1. Setelah mendidih, masak terus hingga santan keluar minyak.
1. Setelah itu masukkan kentang mini. Terakhir masukan ayam. Masak hingga menjadi rendang.




Wah ternyata resep rendang ayam yang mantab simple ini mudah sekali ya! Anda Semua bisa memasaknya. Cara Membuat rendang ayam Sangat cocok banget untuk kalian yang baru belajar memasak ataupun bagi kamu yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba membuat resep rendang ayam enak sederhana ini? Kalau kamu tertarik, mending kamu segera siapin alat dan bahannya, setelah itu buat deh Resep rendang ayam yang nikmat dan simple ini. Betul-betul mudah kan. 

Oleh karena itu, daripada kita diam saja, ayo kita langsung sajikan resep rendang ayam ini. Dijamin kalian gak akan nyesel bikin resep rendang ayam lezat tidak ribet ini! Selamat mencoba dengan resep rendang ayam lezat tidak rumit ini di tempat tinggal masing-masing,oke!.

