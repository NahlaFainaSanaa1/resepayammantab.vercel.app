---
description: "Cara membuat Rendang Ayam Sederhana Untuk Jualan"
title: "Cara membuat Rendang Ayam Sederhana Untuk Jualan"
slug: 105-cara-membuat-rendang-ayam-sederhana-untuk-jualan
date: 2021-04-19T23:25:40.888Z
image: https://img-global.cpcdn.com/recipes/f6df8e5e569e1556/680x482cq70/rendang-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f6df8e5e569e1556/680x482cq70/rendang-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f6df8e5e569e1556/680x482cq70/rendang-ayam-foto-resep-utama.jpg
author: Sue Ingram
ratingvalue: 3.5
reviewcount: 13
recipeingredient:
- "1 kg Ayam potong"
- "1/2 butir kelapa parut pilih yang agak muda"
- "700 ml santan cair"
- " Minyak goreng untuk menumis"
- "secukupnya Garam dan kaldu bubuk"
- "2 bungkus santan kara sachet"
- "2 batang sereh"
- "3 lembar daun jeruk"
- "2 lembar daun salam"
- "2 lembar daun kunyit"
- "1 sdm air asam jawa"
- "1 sdt gula merah sisir"
- "5 biji bunga lawang"
- "5 kapulaga"
- "7 biji cengkeh"
- "1 batang kayu manis ukuran jari"
- " Bumbu halus "
- "10 cabe merah ukuran besar buang bijinya"
- "12 siung bawang merah"
- "5 siung bawang putih"
- "8 cabe rewit optinal"
- "5 butir kemiri"
- "2 ruas lengkuas"
- "1 ruas jahe"
- "1 sdt ketumbar halus"
- "1 sdt lada bubuk"
recipeinstructions:
- "Sangrai kelapa yang agak muda hingga kering (boleh digoreng) haluskan kelapa dengan cooper/ boleh di tumbuk sisihkan"
- "Cuci ayam hingga bersih boleh juga beri perasan air jeruk nipis untuk menghilangkan bau amisnya.."
- "Pnaskan sedikit minyak goreng tumis bumbu halus masukkan kelapa sangrai dan masukkan sereh,daun salam,daun jeruk,daun kunyit,bunga lawang,cengkeh dan kayu manis tumis hingga matang"
- "Masukkan ayam beri santan cair masak hingga mendidih"
- "Bumbui dengan gula merah,garam dan kaldu bubuk,beri santan sachet kental aduk rata"
- "Setelah semua tercampur rata tutup wajan masak dengan api kecil sampai menyusut dan mengeluarkan minyak,test rasa dan matikan api taburi dengan bawang goreng dan irisan cabe merah"
categories:
- Resep
tags:
- rendang
- ayam

katakunci: rendang ayam 
nutrition: 144 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Lunch

---


![Rendang Ayam](https://img-global.cpcdn.com/recipes/f6df8e5e569e1556/680x482cq70/rendang-ayam-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, mempersiapkan masakan mantab kepada keluarga tercinta merupakan suatu hal yang memuaskan untuk anda sendiri. Kewajiban seorang istri bukan sekadar menjaga rumah saja, namun kamu pun harus memastikan keperluan gizi terpenuhi dan panganan yang dimakan anak-anak wajib mantab.

Di masa  sekarang, kita memang bisa mengorder olahan siap saji tanpa harus susah memasaknya dahulu. Tapi banyak juga orang yang selalu mau memberikan makanan yang terbaik bagi orang yang dicintainya. Karena, menghidangkan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penggemar rendang ayam?. Tahukah kamu, rendang ayam merupakan hidangan khas di Nusantara yang saat ini disukai oleh setiap orang dari berbagai tempat di Indonesia. Kalian bisa membuat rendang ayam sendiri di rumahmu dan boleh dijadikan santapan favorit di akhir pekanmu.

Kamu tidak usah bingung untuk menyantap rendang ayam, sebab rendang ayam gampang untuk ditemukan dan anda pun boleh membuatnya sendiri di rumah. rendang ayam boleh diolah dengan berbagai cara. Kini pun sudah banyak cara modern yang menjadikan rendang ayam semakin enak.

Resep rendang ayam pun sangat gampang dibikin, lho. Kalian jangan capek-capek untuk memesan rendang ayam, lantaran Kamu dapat menyiapkan sendiri di rumah. Bagi Anda yang ingin membuatnya, di bawah ini adalah resep untuk menyajikan rendang ayam yang mantab yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Rendang Ayam:

1. Ambil 1 kg Ayam potong
1. Ambil 1/2 butir kelapa parut (pilih yang agak muda)
1. Ambil 700 ml santan cair
1. Sediakan  Minyak goreng untuk menumis
1. Gunakan secukupnya Garam dan kaldu bubuk
1. Siapkan 2 bungkus santan kara sachet
1. Ambil 2 batang sereh
1. Siapkan 3 lembar daun jeruk
1. Ambil 2 lembar daun salam
1. Sediakan 2 lembar daun kunyit
1. Siapkan 1 sdm air asam jawa
1. Gunakan 1 sdt gula merah sisir
1. Gunakan 5 biji bunga lawang
1. Ambil 5 kapulaga
1. Sediakan 7 biji cengkeh
1. Gunakan 1 batang kayu manis ukuran jari
1. Gunakan  Bumbu halus :
1. Sediakan 10 cabe merah ukuran besar (buang bijinya)
1. Ambil 12 siung bawang merah
1. Ambil 5 siung bawang putih
1. Gunakan 8 cabe rewit (optinal)
1. Sediakan 5 butir kemiri
1. Sediakan 2 ruas lengkuas
1. Siapkan 1 ruas jahe
1. Gunakan 1 sdt ketumbar halus
1. Ambil 1 sdt lada bubuk




<!--inarticleads2-->

##### Cara menyiapkan Rendang Ayam:

1. Sangrai kelapa yang agak muda hingga kering (boleh digoreng) haluskan kelapa dengan cooper/ boleh di tumbuk sisihkan
1. Cuci ayam hingga bersih boleh juga beri perasan air jeruk nipis untuk menghilangkan bau amisnya..
1. Pnaskan sedikit minyak goreng tumis bumbu halus masukkan kelapa sangrai dan masukkan sereh,daun salam,daun jeruk,daun kunyit,bunga lawang,cengkeh dan kayu manis tumis hingga matang
1. Masukkan ayam beri santan cair masak hingga mendidih
1. Bumbui dengan gula merah,garam dan kaldu bubuk,beri santan sachet kental aduk rata
1. Setelah semua tercampur rata tutup wajan masak dengan api kecil sampai menyusut dan mengeluarkan minyak,test rasa dan matikan api taburi dengan bawang goreng dan irisan cabe merah




Wah ternyata cara membuat rendang ayam yang nikamt tidak ribet ini gampang banget ya! Kamu semua mampu memasaknya. Resep rendang ayam Sesuai banget untuk anda yang baru belajar memasak ataupun juga untuk kalian yang sudah hebat memasak.

Apakah kamu ingin mulai mencoba membuat resep rendang ayam nikmat simple ini? Kalau tertarik, yuk kita segera siapin peralatan dan bahan-bahannya, lalu bikin deh Resep rendang ayam yang mantab dan simple ini. Sangat mudah kan. 

Maka, daripada kita diam saja, maka kita langsung hidangkan resep rendang ayam ini. Pasti kamu tiidak akan menyesal bikin resep rendang ayam nikmat simple ini! Selamat mencoba dengan resep rendang ayam nikmat tidak rumit ini di rumah sendiri,ya!.

