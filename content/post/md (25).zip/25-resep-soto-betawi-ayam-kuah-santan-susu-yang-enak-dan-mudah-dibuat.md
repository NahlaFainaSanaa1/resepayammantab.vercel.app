---
description: "Resep Soto Betawi Ayam (kuah santan susu) yang enak dan Mudah Dibuat"
title: "Resep Soto Betawi Ayam (kuah santan susu) yang enak dan Mudah Dibuat"
slug: 25-resep-soto-betawi-ayam-kuah-santan-susu-yang-enak-dan-mudah-dibuat
date: 2021-04-27T10:04:50.936Z
image: https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg
author: Elva Ward
ratingvalue: 3.3
reviewcount: 11
recipeingredient:
- " BAhan  bahan "
- "500 gr ayam bagian dada"
- "2000 ml santan"
- "500 ml susu cair full cream"
- "2 batang sereh geprek"
- "1 ruas lengkuas geprek"
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "Secukup nya garam gula dan kaldu bubuk"
- " Bumbu Halus "
- "6 bh bawang merah"
- "4 buah bawang putih"
- "Seruas kunyit"
- "Seruas jahe"
- "5 buah kemiri sangrai"
- "1 sdt lada butiran"
- " Bahan Pelengkap"
- " Emping goreng"
- "1/2 kg kentang iris tipis bulat goreng kering"
- " Daun bawang"
- " Tomat"
- " Jeruk limo"
- " Sambal"
- " Bawang goreng"
recipeinstructions:
- "Potong kecil2 ayam lalu cuci bersih dan beri kucuran air jeruk nipis diam kan sebentar lalu cuci bersih kembali tiriskan"
- "Tumis bumbu halus hingga harum lalu masukan salam, sereh, lengkuas dan daun jeruk aduk hingga bumbu matang"
- "Panaskan santan biarkan hingga mendidih lalu masukan bumbu halus dan masukan ayam aduk biar kan ayam matang. Masukan susu beri gula garam dan kaldu bubuk koreksi rasa matikan kompor"
- "Penyajian.. tuang soto di mangkuk lalu beri tambahan bahan pelengkap lain nya sajikam dengan nasi hangat.. mantaaappp 🤤"
categories:
- Resep
tags:
- soto
- betawi
- ayam

katakunci: soto betawi ayam 
nutrition: 122 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto Betawi Ayam (kuah santan susu)](https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan masakan nikmat buat keluarga tercinta adalah hal yang membahagiakan bagi kita sendiri. Kewajiban seorang  wanita Tidak sekedar mengurus rumah saja, tapi anda pun harus memastikan kebutuhan gizi terpenuhi dan panganan yang dikonsumsi keluarga tercinta mesti nikmat.

Di waktu  saat ini, anda sebenarnya mampu memesan hidangan praktis meski tanpa harus capek mengolahnya terlebih dahulu. Tetapi ada juga lho orang yang memang ingin memberikan makanan yang terenak untuk orang tercintanya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan famili. 



Mungkinkah kamu salah satu penikmat soto betawi ayam (kuah santan susu)?. Tahukah kamu, soto betawi ayam (kuah santan susu) merupakan hidangan khas di Indonesia yang sekarang disenangi oleh setiap orang di hampir setiap tempat di Nusantara. Kalian bisa membuat soto betawi ayam (kuah santan susu) sendiri di rumah dan boleh jadi makanan kegemaranmu di hari libur.

Kita tak perlu bingung untuk mendapatkan soto betawi ayam (kuah santan susu), sebab soto betawi ayam (kuah santan susu) gampang untuk dicari dan anda pun bisa memasaknya sendiri di rumah. soto betawi ayam (kuah santan susu) boleh dimasak lewat bermacam cara. Kini telah banyak banget resep kekinian yang membuat soto betawi ayam (kuah santan susu) semakin lebih lezat.

Resep soto betawi ayam (kuah santan susu) juga sangat mudah dihidangkan, lho. Anda jangan capek-capek untuk memesan soto betawi ayam (kuah santan susu), lantaran Kamu bisa menyajikan di rumah sendiri. Bagi Kita yang mau mencobanya, inilah cara untuk menyajikan soto betawi ayam (kuah santan susu) yang nikamat yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Soto Betawi Ayam (kuah santan susu):

1. Ambil  BAhan - bahan :
1. Sediakan 500 gr ayam bagian dada
1. Ambil 2000 ml santan
1. Siapkan 500 ml susu cair full cream
1. Gunakan 2 batang sereh geprek
1. Sediakan 1 ruas lengkuas geprek
1. Sediakan 3 lembar daun salam
1. Siapkan 4 lembar daun jeruk
1. Sediakan Secukup nya garam, gula dan kaldu bubuk
1. Siapkan  Bumbu Halus :
1. Siapkan 6 bh bawang merah
1. Ambil 4 buah bawang putih
1. Siapkan Seruas kunyit
1. Siapkan Seruas jahe
1. Ambil 5 buah kemiri sangrai
1. Ambil 1 sdt lada butiran
1. Siapkan  Bahan Pelengkap
1. Siapkan  Emping goreng
1. Ambil 1/2 kg kentang iris tipis bulat goreng kering
1. Sediakan  Daun bawang
1. Gunakan  Tomat
1. Gunakan  Jeruk limo
1. Gunakan  Sambal
1. Ambil  Bawang goreng




<!--inarticleads2-->

##### Cara menyiapkan Soto Betawi Ayam (kuah santan susu):

1. Potong kecil2 ayam lalu cuci bersih dan beri kucuran air jeruk nipis diam kan sebentar lalu cuci bersih kembali tiriskan
1. Tumis bumbu halus hingga harum lalu masukan salam, sereh, lengkuas dan daun jeruk aduk hingga bumbu matang
1. Panaskan santan biarkan hingga mendidih lalu masukan bumbu halus dan masukan ayam aduk biar kan ayam matang. Masukan susu beri gula garam dan kaldu bubuk koreksi rasa matikan kompor
1. Penyajian.. tuang soto di mangkuk lalu beri tambahan bahan pelengkap lain nya sajikam dengan nasi hangat.. mantaaappp 🤤




Ternyata cara membuat soto betawi ayam (kuah santan susu) yang lezat tidak rumit ini gampang sekali ya! Kamu semua bisa menghidangkannya. Cara buat soto betawi ayam (kuah santan susu) Sesuai banget untuk kamu yang sedang belajar memasak atau juga bagi kamu yang telah ahli dalam memasak.

Tertarik untuk mencoba buat resep soto betawi ayam (kuah santan susu) lezat sederhana ini? Kalau ingin, ayo kalian segera siapin alat dan bahan-bahannya, maka buat deh Resep soto betawi ayam (kuah santan susu) yang mantab dan tidak rumit ini. Sangat taidak sulit kan. 

Maka dari itu, ketimbang kalian berlama-lama, hayo kita langsung buat resep soto betawi ayam (kuah santan susu) ini. Pasti anda gak akan menyesal sudah membuat resep soto betawi ayam (kuah santan susu) mantab simple ini! Selamat berkreasi dengan resep soto betawi ayam (kuah santan susu) mantab tidak ribet ini di rumah kalian masing-masing,oke!.

