---
description: "Resep Ayam Goreng (dan Tempe Goreng) Lengkuas yang nikmat Untuk Jualan"
title: "Resep Ayam Goreng (dan Tempe Goreng) Lengkuas yang nikmat Untuk Jualan"
slug: 157-resep-ayam-goreng-dan-tempe-goreng-lengkuas-yang-nikmat-untuk-jualan
date: 2021-05-18T16:08:57.628Z
image: https://img-global.cpcdn.com/recipes/9c7a0742dd28c93b/680x482cq70/ayam-goreng-dan-tempe-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9c7a0742dd28c93b/680x482cq70/ayam-goreng-dan-tempe-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9c7a0742dd28c93b/680x482cq70/ayam-goreng-dan-tempe-goreng-lengkuas-foto-resep-utama.jpg
author: Hester Boone
ratingvalue: 3.3
reviewcount: 6
recipeingredient:
- "1 ekor ayam kampung"
- "250 gr lengkuas"
- "1/2 sdt merica bubuk"
- " Garam secukupnya resep asli 15sdt"
- " Penyedap secukupnya resep asli 12 sdt"
- " Bumbu halus"
- "3 serai geprek"
- "5 lembar daun salam"
- "5 kemiri sangrai"
- "7 bawang putih"
- "7 bawang merah"
- "2 sdt ketumbar"
- "secukupnya Minyak"
recipeinstructions:
- "Potong lengkuas mengikuti serat (memanjang) lalu blender dengan air secukupnya saja, jangan terlalu halus ya, kita mau lengkuasnya serbut2 gitu"
- "Blender bawang merah, bawang putih, kemiri, ketumbar dengan minyak secukupnya"
- "Tumis bumbu halus dengan api kecil (api kecil ya, pelan2 ditumis sampai harum dan setengah kering), lalu masukkan daun salam, serai, lalu tumis lagi sampai kering"
- "Masukkan air kira2 1L dulu, aduk rata. Lalu masukkan lengkuas yg sudah diblender, masak hingga bumbu matang"
- "Masukkan ayam (saya sekalian masukkin tempe, sekalian ungkep hehe), bumbui dengan garam, penyedap dan merica. Masak dengan api sedang hingga air setengah susut"
- "Kalo airnya sudah hampir menyusut, angkat ayam dan tempe, sisihkan daun salam dan serai juga"
- "Masak sisa bumbu endapan sampai air benar2 menyusut dan mengeluarkan minyak"
- "Goreng ayam dan bumbu sampai kecoklatan. Sajikan dengan nasi hangat, sambal dan sayur asem. Duhh! Enakkkk 🤤"
categories:
- Resep
tags:
- ayam
- goreng
- dan

katakunci: ayam goreng dan 
nutrition: 117 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng (dan Tempe Goreng) Lengkuas](https://img-global.cpcdn.com/recipes/9c7a0742dd28c93b/680x482cq70/ayam-goreng-dan-tempe-goreng-lengkuas-foto-resep-utama.jpg)

Selaku seorang orang tua, menyajikan masakan enak kepada keluarga adalah suatu hal yang mengasyikan bagi anda sendiri. Tanggung jawab seorang ibu Tidak sekedar menjaga rumah saja, tetapi kamu juga harus memastikan keperluan nutrisi tercukupi dan panganan yang disantap anak-anak harus mantab.

Di zaman  sekarang, kita memang mampu memesan panganan jadi meski tanpa harus susah memasaknya dulu. Namun banyak juga orang yang selalu mau memberikan makanan yang terlezat bagi orang tercintanya. Lantaran, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai makanan kesukaan famili. 



Apakah anda salah satu penikmat ayam goreng (dan tempe goreng) lengkuas?. Tahukah kamu, ayam goreng (dan tempe goreng) lengkuas merupakan hidangan khas di Indonesia yang kini digemari oleh orang-orang di berbagai tempat di Indonesia. Kalian bisa menghidangkan ayam goreng (dan tempe goreng) lengkuas sendiri di rumah dan dapat dijadikan santapan kesenanganmu di hari liburmu.

Kamu tidak perlu bingung jika kamu ingin menyantap ayam goreng (dan tempe goreng) lengkuas, lantaran ayam goreng (dan tempe goreng) lengkuas tidak sulit untuk dicari dan juga kamu pun dapat membuatnya sendiri di tempatmu. ayam goreng (dan tempe goreng) lengkuas dapat dimasak memalui beraneka cara. Kini pun sudah banyak cara modern yang membuat ayam goreng (dan tempe goreng) lengkuas lebih enak.

Resep ayam goreng (dan tempe goreng) lengkuas pun gampang untuk dibikin, lho. Kalian tidak perlu capek-capek untuk memesan ayam goreng (dan tempe goreng) lengkuas, lantaran Kalian mampu menyiapkan sendiri di rumah. Bagi Kamu yang akan membuatnya, di bawah ini adalah cara untuk membuat ayam goreng (dan tempe goreng) lengkuas yang nikamat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Goreng (dan Tempe Goreng) Lengkuas:

1. Siapkan 1 ekor ayam kampung
1. Siapkan 250 gr lengkuas
1. Sediakan 1/2 sdt merica bubuk
1. Siapkan  Garam secukupnya (resep asli 1.5sdt)
1. Gunakan  Penyedap secukupnya (resep asli 1/2 sdt)
1. Sediakan  Bumbu halus:
1. Siapkan 3 serai, geprek
1. Siapkan 5 lembar daun salam
1. Ambil 5 kemiri sangrai
1. Ambil 7 bawang putih
1. Sediakan 7 bawang merah
1. Siapkan 2 sdt ketumbar
1. Siapkan secukupnya Minyak




<!--inarticleads2-->

##### Cara membuat Ayam Goreng (dan Tempe Goreng) Lengkuas:

1. Potong lengkuas mengikuti serat (memanjang) lalu blender dengan air secukupnya saja, jangan terlalu halus ya, kita mau lengkuasnya serbut2 gitu
1. Blender bawang merah, bawang putih, kemiri, ketumbar dengan minyak secukupnya
1. Tumis bumbu halus dengan api kecil (api kecil ya, pelan2 ditumis sampai harum dan setengah kering), lalu masukkan daun salam, serai, lalu tumis lagi sampai kering
1. Masukkan air kira2 1L dulu, aduk rata. Lalu masukkan lengkuas yg sudah diblender, masak hingga bumbu matang
1. Masukkan ayam (saya sekalian masukkin tempe, sekalian ungkep hehe), bumbui dengan garam, penyedap dan merica. Masak dengan api sedang hingga air setengah susut
1. Kalo airnya sudah hampir menyusut, angkat ayam dan tempe, sisihkan daun salam dan serai juga
1. Masak sisa bumbu endapan sampai air benar2 menyusut dan mengeluarkan minyak
1. Goreng ayam dan bumbu sampai kecoklatan. Sajikan dengan nasi hangat, sambal dan sayur asem. Duhh! Enakkkk 🤤




Wah ternyata resep ayam goreng (dan tempe goreng) lengkuas yang mantab sederhana ini gampang banget ya! Anda Semua bisa membuatnya. Resep ayam goreng (dan tempe goreng) lengkuas Sangat cocok sekali buat kalian yang baru akan belajar memasak atau juga bagi anda yang telah ahli dalam memasak.

Tertarik untuk mencoba buat resep ayam goreng (dan tempe goreng) lengkuas nikmat tidak ribet ini? Kalau mau, ayo kalian segera buruan siapin alat dan bahannya, lantas bikin deh Resep ayam goreng (dan tempe goreng) lengkuas yang enak dan sederhana ini. Benar-benar gampang kan. 

Jadi, daripada anda berlama-lama, ayo kita langsung saja bikin resep ayam goreng (dan tempe goreng) lengkuas ini. Pasti anda tiidak akan nyesel sudah membuat resep ayam goreng (dan tempe goreng) lengkuas enak sederhana ini! Selamat mencoba dengan resep ayam goreng (dan tempe goreng) lengkuas enak tidak rumit ini di tempat tinggal sendiri,ya!.

