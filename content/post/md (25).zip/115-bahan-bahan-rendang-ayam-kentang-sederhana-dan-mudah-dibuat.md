---
description: "Bahan-bahan Rendang Ayam Kentang Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Rendang Ayam Kentang Sederhana dan Mudah Dibuat"
slug: 115-bahan-bahan-rendang-ayam-kentang-sederhana-dan-mudah-dibuat
date: 2021-02-02T16:54:42.076Z
image: https://img-global.cpcdn.com/recipes/d231b723b170981e/680x482cq70/rendang-ayam-kentang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d231b723b170981e/680x482cq70/rendang-ayam-kentang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d231b723b170981e/680x482cq70/rendang-ayam-kentang-foto-resep-utama.jpg
author: Peter Brooks
ratingvalue: 3.6
reviewcount: 15
recipeingredient:
- "1 ekor ayam 2kg"
- "1/2 kg kentang potong besar"
- "6 sdm bumbu dasar merah           lihat resep"
- "4 sdm bumbu dasar kuning           lihat resep"
- "2 sachet santan instant 65 ml"
- "1 sdt garam selera"
- "1 sdt gula pasir selera"
- "3 iris gula merah selera"
- "600 ml air"
- " Bumbu Cemplung"
- "5 lbr daun salam"
- "2 lbr daun jeruk"
- "1 batang sereh memarkan"
- "5 cm kayu manis"
- "3 bh bunga lawang"
- "7 bh cengkeh"
- "2 bh kapulaga"
- "3 iris pala dihaluskan"
- "1 sdm ketumbar bubuk"
- "1/2 sdt lada bubuk"
recipeinstructions:
- "Siapkan bahannya."
- "Cuci bersih ayam beri perasan jeruk dan garam, diaduk rata biarkan beberapa saat. Cuci dan bilas kembali."
- "Tumis bumbu dasar merah, dan bumbu dasar kuning. Masukkan bumbu Cemplung biarkan harum. Masukkan ayam dan biarkan hingga ayam 1/2 empuk."
- "Masukkan potongan kentang. Beri santan instan dan biarkan mendidih. Tambahkan garam, gula pasir dan gula merah."
- "Biarkan hingga kuahnya sedikit dan mengental, koreksi rasa. Angkat dan sajikan."
categories:
- Resep
tags:
- rendang
- ayam
- kentang

katakunci: rendang ayam kentang 
nutrition: 265 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner

---


![Rendang Ayam Kentang](https://img-global.cpcdn.com/recipes/d231b723b170981e/680x482cq70/rendang-ayam-kentang-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan masakan menggugah selera buat famili merupakan hal yang mengasyikan untuk anda sendiri. Tugas seorang  wanita bukan sekedar mengerjakan pekerjaan rumah saja, namun anda pun wajib memastikan keperluan nutrisi tercukupi dan juga masakan yang disantap orang tercinta mesti sedap.

Di zaman  sekarang, anda sebenarnya mampu mengorder hidangan yang sudah jadi tidak harus susah memasaknya dahulu. Tapi ada juga orang yang memang mau memberikan yang terbaik untuk orang tercintanya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan masakan kesukaan famili. 



Apakah kamu salah satu penyuka rendang ayam kentang?. Asal kamu tahu, rendang ayam kentang merupakan hidangan khas di Indonesia yang sekarang disenangi oleh banyak orang dari hampir setiap tempat di Indonesia. Kalian dapat menghidangkan rendang ayam kentang buatan sendiri di rumahmu dan boleh jadi camilan favorit di hari libur.

Kalian tidak usah bingung untuk memakan rendang ayam kentang, lantaran rendang ayam kentang mudah untuk dicari dan kamu pun bisa memasaknya sendiri di rumah. rendang ayam kentang bisa dibuat memalui bermacam cara. Sekarang sudah banyak banget cara modern yang membuat rendang ayam kentang lebih nikmat.

Resep rendang ayam kentang pun mudah dihidangkan, lho. Kalian tidak usah capek-capek untuk membeli rendang ayam kentang, sebab Kamu dapat menghidangkan ditempatmu. Bagi Kita yang hendak membuatnya, inilah resep untuk menyajikan rendang ayam kentang yang nikamat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Rendang Ayam Kentang:

1. Gunakan 1 ekor ayam (2kg)
1. Ambil 1/2 kg kentang potong besar
1. Sediakan 6 sdm bumbu dasar merah           (lihat resep)
1. Sediakan 4 sdm bumbu dasar kuning           (lihat resep)
1. Gunakan 2 sachet santan instant @65 ml
1. Siapkan 1 sdt garam (selera)
1. Ambil 1 sdt gula pasir (selera)
1. Siapkan 3 iris gula merah (selera)
1. Ambil 600 ml air
1. Ambil  Bumbu Cemplung:
1. Sediakan 5 lbr daun salam
1. Sediakan 2 lbr daun jeruk
1. Siapkan 1 batang sereh memarkan
1. Sediakan 5 cm kayu manis
1. Sediakan 3 bh bunga lawang
1. Siapkan 7 bh cengkeh
1. Ambil 2 bh kapulaga
1. Ambil 3 iris pala dihaluskan
1. Siapkan 1 sdm ketumbar bubuk
1. Siapkan 1/2 sdt lada bubuk




<!--inarticleads2-->

##### Cara membuat Rendang Ayam Kentang:

1. Siapkan bahannya.
1. Cuci bersih ayam beri perasan jeruk dan garam, diaduk rata biarkan beberapa saat. Cuci dan bilas kembali.
1. Tumis bumbu dasar merah, dan bumbu dasar kuning. Masukkan bumbu Cemplung biarkan harum. Masukkan ayam dan biarkan hingga ayam 1/2 empuk.
1. Masukkan potongan kentang. Beri santan instan dan biarkan mendidih. Tambahkan garam, gula pasir dan gula merah.
1. Biarkan hingga kuahnya sedikit dan mengental, koreksi rasa. Angkat dan sajikan.




Wah ternyata resep rendang ayam kentang yang lezat simple ini enteng sekali ya! Semua orang dapat membuatnya. Resep rendang ayam kentang Sangat cocok sekali buat kita yang sedang belajar memasak ataupun juga untuk kalian yang sudah pandai dalam memasak.

Apakah kamu ingin mulai mencoba membikin resep rendang ayam kentang nikmat simple ini? Kalau kalian tertarik, ayo kalian segera siapkan alat-alat dan bahan-bahannya, lantas bikin deh Resep rendang ayam kentang yang mantab dan tidak rumit ini. Sungguh gampang kan. 

Oleh karena itu, ketimbang kita diam saja, yuk langsung aja hidangkan resep rendang ayam kentang ini. Dijamin kamu gak akan nyesel sudah bikin resep rendang ayam kentang enak tidak ribet ini! Selamat berkreasi dengan resep rendang ayam kentang lezat tidak rumit ini di tempat tinggal masing-masing,ya!.

