---
description: "Cara membuat Ayam goreng bumbu ungkep sambal matah yang enak Untuk Jualan"
title: "Cara membuat Ayam goreng bumbu ungkep sambal matah yang enak Untuk Jualan"
slug: 266-cara-membuat-ayam-goreng-bumbu-ungkep-sambal-matah-yang-enak-untuk-jualan
date: 2021-01-14T17:18:19.697Z
image: https://img-global.cpcdn.com/recipes/219c361ccb1857c3/680x482cq70/ayam-goreng-bumbu-ungkep-sambal-matah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/219c361ccb1857c3/680x482cq70/ayam-goreng-bumbu-ungkep-sambal-matah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/219c361ccb1857c3/680x482cq70/ayam-goreng-bumbu-ungkep-sambal-matah-foto-resep-utama.jpg
author: Harold Cohen
ratingvalue: 3.6
reviewcount: 8
recipeingredient:
- " Bahan ayam ungkep"
- "1 ekor Ayam"
- "4 batang Serai"
- "5 siung Bawang merah"
- "5 siung Bawang putih"
- "secukupnya Merica"
- "secukupnya Ketumbar"
- "secukupnya Garam"
- " Lengkuas sebesar 1 jari di memarkan"
- " Air"
- " Bahan sambal matah"
- "30 biji Cabai"
- "10 siung Bawang putih"
- "10 siung Bawang merah"
- "4 batang Serai"
- " Daun jeruk 5 lembah"
- "secukupnya Garam"
- " Penyedap rasa secukupnya aku pakai royco rasa ayam"
- "secukupnya Jeruk nipis"
- "5 sendok Minyak goreng panas"
recipeinstructions:
- "Ayam ungkep: potong ayamnya dan bersihkan. Kemudian haluskan bumbu ayam ungkep. Masukkan air, ayam dan bumbu yg sudah dihaluskan kemudian ungkep sampai airnya sisa sedikit. Angkat dan tiriskan. Setelah itu goreng hingga kecoklatan"
- "Sambal matah: potong bahan sambal matah setelah itu siram dengan minyak panas hasil dari goreng ayam tadi kemudia masukkan garam, penyedap rasa dan jeruk nipis. :)"
categories:
- Resep
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam goreng bumbu ungkep sambal matah](https://img-global.cpcdn.com/recipes/219c361ccb1857c3/680x482cq70/ayam-goreng-bumbu-ungkep-sambal-matah-foto-resep-utama.jpg)

Andai kamu seorang ibu, menyajikan masakan enak untuk orang tercinta merupakan suatu hal yang menggembirakan untuk anda sendiri. Kewajiban seorang istri bukan sekadar menjaga rumah saja, tetapi kamu juga wajib menyediakan keperluan gizi terpenuhi dan juga olahan yang dikonsumsi anak-anak wajib mantab.

Di waktu  saat ini, anda sebenarnya dapat memesan masakan siap saji tanpa harus susah mengolahnya terlebih dahulu. Namun banyak juga lho orang yang selalu mau memberikan makanan yang terlezat untuk orang tercintanya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan selera orang tercinta. 



Mungkinkah anda adalah salah satu penggemar ayam goreng bumbu ungkep sambal matah?. Tahukah kamu, ayam goreng bumbu ungkep sambal matah adalah makanan khas di Indonesia yang kini disukai oleh kebanyakan orang dari berbagai wilayah di Nusantara. Kita bisa membuat ayam goreng bumbu ungkep sambal matah hasil sendiri di rumah dan dapat dijadikan hidangan favoritmu di akhir pekan.

Kita tidak usah bingung jika kamu ingin mendapatkan ayam goreng bumbu ungkep sambal matah, lantaran ayam goreng bumbu ungkep sambal matah tidak sulit untuk didapatkan dan kita pun bisa memasaknya sendiri di rumah. ayam goreng bumbu ungkep sambal matah bisa dimasak memalui beraneka cara. Saat ini telah banyak banget resep kekinian yang membuat ayam goreng bumbu ungkep sambal matah semakin mantap.

Resep ayam goreng bumbu ungkep sambal matah juga sangat mudah untuk dibuat, lho. Kita tidak usah capek-capek untuk membeli ayam goreng bumbu ungkep sambal matah, sebab Kalian mampu menghidangkan di rumah sendiri. Bagi Kita yang hendak menyajikannya, dibawah ini merupakan cara menyajikan ayam goreng bumbu ungkep sambal matah yang lezat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam goreng bumbu ungkep sambal matah:

1. Gunakan  Bahan ayam ungkep:
1. Ambil 1 ekor Ayam
1. Gunakan 4 batang Serai
1. Siapkan 5 siung Bawang merah
1. Sediakan 5 siung Bawang putih
1. Gunakan secukupnya Merica
1. Ambil secukupnya Ketumbar
1. Ambil secukupnya Garam
1. Gunakan  Lengkuas sebesar 1 jari di memarkan
1. Ambil  Air
1. Ambil  Bahan sambal matah
1. Gunakan 30 biji Cabai
1. Gunakan 10 siung Bawang putih
1. Siapkan 10 siung Bawang merah
1. Gunakan 4 batang Serai
1. Gunakan  Daun jeruk 5 lembah
1. Ambil secukupnya Garam
1. Ambil  Penyedap rasa secukupnya (aku pakai royco rasa ayam)
1. Ambil secukupnya Jeruk nipis
1. Ambil 5 sendok Minyak goreng panas




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam goreng bumbu ungkep sambal matah:

1. Ayam ungkep: potong ayamnya dan bersihkan. Kemudian haluskan bumbu ayam ungkep. Masukkan air, ayam dan bumbu yg sudah dihaluskan kemudian ungkep sampai airnya sisa sedikit. Angkat dan tiriskan. Setelah itu goreng hingga kecoklatan
1. Sambal matah: potong bahan sambal matah setelah itu siram dengan minyak panas hasil dari goreng ayam tadi kemudia masukkan garam, penyedap rasa dan jeruk nipis. :)




Ternyata cara buat ayam goreng bumbu ungkep sambal matah yang enak tidak ribet ini gampang sekali ya! Kita semua bisa mencobanya. Cara Membuat ayam goreng bumbu ungkep sambal matah Sangat sesuai sekali untuk kita yang baru mau belajar memasak ataupun bagi anda yang telah lihai memasak.

Tertarik untuk mencoba membikin resep ayam goreng bumbu ungkep sambal matah mantab sederhana ini? Kalau mau, ayo kamu segera buruan siapkan peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam goreng bumbu ungkep sambal matah yang mantab dan tidak rumit ini. Sangat mudah kan. 

Maka dari itu, daripada kalian berfikir lama-lama, yuk kita langsung hidangkan resep ayam goreng bumbu ungkep sambal matah ini. Dijamin kalian tiidak akan nyesel sudah membuat resep ayam goreng bumbu ungkep sambal matah enak tidak rumit ini! Selamat berkreasi dengan resep ayam goreng bumbu ungkep sambal matah lezat simple ini di rumah masing-masing,ya!.

