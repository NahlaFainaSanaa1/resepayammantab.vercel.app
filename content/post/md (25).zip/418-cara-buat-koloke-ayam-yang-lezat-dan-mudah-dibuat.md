---
description: "Cara buat Koloke Ayam yang lezat dan Mudah Dibuat"
title: "Cara buat Koloke Ayam yang lezat dan Mudah Dibuat"
slug: 418-cara-buat-koloke-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-06-10T12:58:31.563Z
image: https://img-global.cpcdn.com/recipes/a8bec63f90de6017/680x482cq70/koloke-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a8bec63f90de6017/680x482cq70/koloke-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a8bec63f90de6017/680x482cq70/koloke-ayam-foto-resep-utama.jpg
author: Ann Bridges
ratingvalue: 3.6
reviewcount: 15
recipeingredient:
- " Saus Koloke"
- "1/4 wortel iris tipis2 memanjang"
- "4 siung bawang putih"
- "1/2 bawang bombay ukuran kecil"
- "7 sendok saus tomat"
- "7 sendok saos sambal"
- "3 sdt totolkaldu"
- "2 sdm maizena cair"
- "secukupnya Garam dan gula"
- " Ayam Goreng"
- "1/2 kg dada ayam fillet"
- "1 bungkus tepung krispy kobe"
recipeinstructions:
- "Pisahkan tepung kobe menjadi dua, basah dan kering. Balurkan ayam yg telah dipotong kecil-kecil ke dalam tepung basah, tepung kering kemudian goreng hingga kecoklatan"
- "Masukkan semua bahan saus koloke ke dalam penggorengan dan tumis. Tambahkan air 250 ml"
- "Tunggu hingga saus mendidih. Masukkan gula dan garam sesuai selera."
- "Tambahkan tepung maizena yang telah dicairkan"
- "Masukkan ayam ke dalam saus koloke dan goreng sebentar dengan api kecil"
categories:
- Resep
tags:
- koloke
- ayam

katakunci: koloke ayam 
nutrition: 188 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Lunch

---


![Koloke Ayam](https://img-global.cpcdn.com/recipes/a8bec63f90de6017/680x482cq70/koloke-ayam-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan hidangan sedap pada orang tercinta merupakan hal yang membahagiakan untuk kamu sendiri. Tanggung jawab seorang istri bukan saja menjaga rumah saja, namun anda juga wajib menyediakan keperluan gizi tercukupi dan panganan yang dikonsumsi keluarga tercinta wajib nikmat.

Di waktu  sekarang, kita memang dapat membeli panganan siap saji tanpa harus susah mengolahnya dahulu. Tetapi banyak juga orang yang memang mau menyajikan yang terlezat untuk orang tercintanya. Pasalnya, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan famili. 



Apakah anda salah satu penikmat koloke ayam?. Asal kamu tahu, koloke ayam merupakan makanan khas di Nusantara yang kini digemari oleh kebanyakan orang di hampir setiap tempat di Indonesia. Kita dapat membuat koloke ayam kreasi sendiri di rumah dan dapat dijadikan hidangan kesenanganmu di akhir pekanmu.

Kamu tidak usah bingung untuk mendapatkan koloke ayam, lantaran koloke ayam mudah untuk dicari dan kalian pun dapat mengolahnya sendiri di tempatmu. koloke ayam bisa dibuat memalui beragam cara. Kini sudah banyak sekali cara modern yang membuat koloke ayam lebih lezat.

Resep koloke ayam pun mudah untuk dibikin, lho. Anda tidak usah repot-repot untuk membeli koloke ayam, karena Anda bisa menghidangkan di rumahmu. Untuk Kamu yang hendak mencobanya, dibawah ini merupakan cara untuk menyajikan koloke ayam yang mantab yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Koloke Ayam:

1. Ambil  Saus Koloke
1. Sediakan 1/4 wortel iris tipis2 memanjang
1. Gunakan 4 siung bawang putih
1. Siapkan 1/2 bawang bombay ukuran kecil
1. Gunakan 7 sendok saus tomat
1. Gunakan 7 sendok saos sambal
1. Sediakan 3 sdt totol/kaldu
1. Sediakan 2 sdm maizena cair
1. Ambil secukupnya Garam dan gula
1. Siapkan  Ayam Goreng
1. Gunakan 1/2 kg dada ayam fillet
1. Sediakan 1 bungkus tepung krispy kobe




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Koloke Ayam:

1. Pisahkan tepung kobe menjadi dua, basah dan kering. Balurkan ayam yg telah dipotong kecil-kecil ke dalam tepung basah, tepung kering kemudian goreng hingga kecoklatan
1. Masukkan semua bahan saus koloke ke dalam penggorengan dan tumis. Tambahkan air 250 ml
1. Tunggu hingga saus mendidih. Masukkan gula dan garam sesuai selera.
1. Tambahkan tepung maizena yang telah dicairkan
1. Masukkan ayam ke dalam saus koloke dan goreng sebentar dengan api kecil




Wah ternyata cara buat koloke ayam yang lezat tidak ribet ini mudah banget ya! Kalian semua dapat membuatnya. Resep koloke ayam Sangat cocok sekali buat anda yang baru belajar memasak maupun bagi kalian yang sudah pandai dalam memasak.

Tertarik untuk mencoba membuat resep koloke ayam mantab sederhana ini? Kalau kamu tertarik, ayo kamu segera siapkan peralatan dan bahan-bahannya, kemudian buat deh Resep koloke ayam yang lezat dan tidak rumit ini. Sangat mudah kan. 

Jadi, ketimbang anda berfikir lama-lama, yuk kita langsung saja sajikan resep koloke ayam ini. Dijamin kamu tiidak akan menyesal bikin resep koloke ayam mantab tidak ribet ini! Selamat mencoba dengan resep koloke ayam nikmat simple ini di rumah kalian masing-masing,ya!.

