---
description: "Bahan-bahan Soto Ayam Santan yang nikmat Untuk Jualan"
title: "Bahan-bahan Soto Ayam Santan yang nikmat Untuk Jualan"
slug: 31-bahan-bahan-soto-ayam-santan-yang-nikmat-untuk-jualan
date: 2021-04-17T18:47:15.858Z
image: https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Amanda Bennett
ratingvalue: 4.1
reviewcount: 12
recipeingredient:
- "1/2 ekor ayam bagian dada cuci bersih sy pakai bagian paha"
- "250 ml santan dr 12 buah kelapa"
- "1 liter air"
- "4 lembar daun jeruk sobek2"
- "2 lembar daun salam"
- "2 batang sereh geprek"
- "1 ruas jari lengkuas geprek"
- "Secukupnya gulagaram"
- "Secukupnya kaldu ayam bubuk"
- " Bumbu halus "
- "6 siung bawang merah"
- "3 Siung bawang putih"
- "3 butir kemiri"
- "1/2 sdt ketumbar"
- "Secukupnya lada"
- " Pelengkap "
- " Sambal"
- " Daun bawang"
- " Jeruk nipis"
- " Bawang goreng"
- " Kentang goreng"
- " Tomat"
recipeinstructions:
- "Didihkan 1 liter air di panci lalu masukan ayam,rebus ayam dgn api kecil"
- "Tumis bumbu halus,daun jeruk,daun salam,lengkuas,sereh sampai harum,masukan tumisan bumbu ke dlm rebusan ayam,masukan royco,garam dan gula,masak hingga ayam empuk dan bumbu meresap. Masukan santan aduk2 agar tdk pecah,klu kira2 krg kental kuahnya bs di tambah santan instan,aduk hingga mendidih"
- "Setelah mendidih lalu angkat ayam dan tiriskan"
- "Tes rasa lalu matikan"
- "Pansakan minyak goreng lalu goreng ayam,tdk ush terlalu kering,lalu siapkan mangkuk saji,suir2 ayam"
- "Siapkan mangkuk dan tata di magkuk saji dgn pelengkapnya .. Yuumyyy"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 195 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dessert

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, mempersiapkan panganan lezat bagi famili adalah hal yang menggembirakan bagi anda sendiri. Peran seorang istri bukan cuma menjaga rumah saja, namun anda juga harus menyediakan kebutuhan gizi tercukupi dan santapan yang dimakan keluarga tercinta wajib enak.

Di zaman  saat ini, kalian memang mampu membeli hidangan siap saji meski tanpa harus susah memasaknya lebih dulu. Tapi ada juga orang yang selalu ingin menghidangkan yang terbaik untuk keluarganya. Sebab, memasak sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan berdasarkan makanan kesukaan famili. 



Apakah anda salah satu penikmat soto ayam santan?. Tahukah kamu, soto ayam santan merupakan sajian khas di Nusantara yang sekarang disenangi oleh kebanyakan orang dari berbagai wilayah di Indonesia. Kita dapat membuat soto ayam santan sendiri di rumahmu dan pasti jadi makanan favorit di akhir pekanmu.

Kalian jangan bingung untuk menyantap soto ayam santan, sebab soto ayam santan sangat mudah untuk didapatkan dan kalian pun boleh membuatnya sendiri di rumah. soto ayam santan boleh diolah lewat bermacam cara. Sekarang sudah banyak sekali resep modern yang menjadikan soto ayam santan semakin lezat.

Resep soto ayam santan pun gampang dibuat, lho. Kalian jangan repot-repot untuk membeli soto ayam santan, tetapi Kamu mampu membuatnya ditempatmu. Bagi Anda yang akan mencobanya, di bawah ini adalah cara untuk membuat soto ayam santan yang mantab yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Santan:

1. Ambil 1/2 ekor ayam bagian dada cuci bersih, sy pakai bagian paha
1. Siapkan 250 ml santan dr 1/2 buah kelapa
1. Ambil 1 liter air
1. Siapkan 4 lembar daun jeruk sobek2
1. Sediakan 2 lembar daun salam
1. Ambil 2 batang sereh geprek
1. Siapkan 1 ruas jari lengkuas geprek
1. Ambil Secukupnya gula,garam
1. Ambil Secukupnya kaldu ayam bubuk
1. Ambil  Bumbu halus :
1. Gunakan 6 siung bawang merah
1. Ambil 3 Siung bawang putih
1. Ambil 3 butir kemiri
1. Ambil 1/2 sdt ketumbar
1. Siapkan Secukupnya lada
1. Ambil  Pelengkap :
1. Gunakan  Sambal
1. Gunakan  Daun bawang
1. Gunakan  Jeruk nipis
1. Siapkan  Bawang goreng
1. Gunakan  Kentang goreng
1. Gunakan  Tomat




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Santan:

1. Didihkan 1 liter air di panci lalu masukan ayam,rebus ayam dgn api kecil
1. Tumis bumbu halus,daun jeruk,daun salam,lengkuas,sereh sampai harum,masukan tumisan bumbu ke dlm rebusan ayam,masukan royco,garam dan gula,masak hingga ayam empuk dan bumbu meresap. Masukan santan aduk2 agar tdk pecah,klu kira2 krg kental kuahnya bs di tambah santan instan,aduk hingga mendidih
1. Setelah mendidih lalu angkat ayam dan tiriskan
1. Tes rasa lalu matikan
1. Pansakan minyak goreng lalu goreng ayam,tdk ush terlalu kering,lalu siapkan mangkuk saji,suir2 ayam
1. Siapkan mangkuk dan tata di magkuk saji dgn pelengkapnya .. Yuumyyy




Ternyata cara membuat soto ayam santan yang lezat tidak ribet ini mudah sekali ya! Kita semua bisa mencobanya. Cara Membuat soto ayam santan Sangat sesuai sekali buat kalian yang baru akan belajar memasak atau juga untuk kalian yang telah lihai dalam memasak.

Apakah kamu mau mencoba membuat resep soto ayam santan lezat tidak rumit ini? Kalau kamu mau, ayo kamu segera buruan siapin alat-alat dan bahannya, setelah itu bikin deh Resep soto ayam santan yang lezat dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka, daripada kita berlama-lama, ayo kita langsung sajikan resep soto ayam santan ini. Pasti kalian gak akan nyesel bikin resep soto ayam santan enak tidak rumit ini! Selamat berkreasi dengan resep soto ayam santan nikmat tidak ribet ini di rumah kalian masing-masing,ya!.

