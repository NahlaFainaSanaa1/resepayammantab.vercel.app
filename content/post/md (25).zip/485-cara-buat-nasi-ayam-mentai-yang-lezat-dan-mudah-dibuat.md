---
description: "Cara buat Nasi ayam mentai yang lezat dan Mudah Dibuat"
title: "Cara buat Nasi ayam mentai yang lezat dan Mudah Dibuat"
slug: 485-cara-buat-nasi-ayam-mentai-yang-lezat-dan-mudah-dibuat
date: 2021-03-22T19:16:44.700Z
image: https://img-global.cpcdn.com/recipes/24ba2d18b22ad132/680x482cq70/nasi-ayam-mentai-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24ba2d18b22ad132/680x482cq70/nasi-ayam-mentai-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24ba2d18b22ad132/680x482cq70/nasi-ayam-mentai-foto-resep-utama.jpg
author: Lillian Hamilton
ratingvalue: 3.7
reviewcount: 14
recipeingredient:
- " Bahan saus "
- " Mayonaise aku pakai mayumi"
- " Saus pedas aku pakai delmonte"
- " Bon nori mama suka"
- " Bahan nasi "
- "secukupnya Nasi"
- "1 sdm minyak wijen"
- "secukupnya Bon nori"
- "sesuai selera Bon cabe"
- " Bahan ayam "
- " Ayam fillet 1kg"
- "2 bawang putih cincang"
- " Marinasi ayam "
- "2 bawang putih cincang"
- "Seruas jari jahe cincang"
- "1 sdm minyak wijen"
- "1 sdm saos tiram"
recipeinstructions:
- "Marinasi ayam yang sudah di potong dadu dengan bawang putih, jahe, minyak wijen dan saus tiram. Diamkan selama 30menit - 1jam."
- "Tumis bawang putih, masukkan ayam. Tumis hingga sudah agak matang. Masukkan air sedikit. Beri garam, gula, lada secukupnya. Boleh tambah saos tiram."
- "Campur semua bahan nasi."
- "Campur semua bahan saos"
- "Susun nasi di atas wadah, lalu ayam, dan ditutup dengan saos mentai. Lalu taburi bon nori di atasnya."
- "Ovem selama 20 menit, dengan suhu 200 dan api atas saja. Siap dimakaaan."
categories:
- Resep
tags:
- nasi
- ayam
- mentai

katakunci: nasi ayam mentai 
nutrition: 219 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dessert

---


![Nasi ayam mentai](https://img-global.cpcdn.com/recipes/24ba2d18b22ad132/680x482cq70/nasi-ayam-mentai-foto-resep-utama.jpg)

Apabila kamu seorang yang hobi memasak, menyajikan hidangan menggugah selera buat keluarga tercinta merupakan hal yang menyenangkan untuk kita sendiri. Kewajiban seorang ibu Tidak cuman menangani rumah saja, namun kamu pun harus memastikan keperluan gizi tercukupi dan masakan yang disantap anak-anak wajib sedap.

Di masa  sekarang, kamu sebenarnya bisa memesan hidangan yang sudah jadi walaupun tidak harus capek membuatnya terlebih dahulu. Namun banyak juga lho mereka yang memang mau menghidangkan yang terbaik bagi orang tercintanya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan sesuai selera keluarga tercinta. 



Mungkinkah anda merupakan salah satu penyuka nasi ayam mentai?. Asal kamu tahu, nasi ayam mentai merupakan sajian khas di Nusantara yang sekarang disenangi oleh setiap orang di berbagai daerah di Nusantara. Kita dapat menyajikan nasi ayam mentai buatan sendiri di rumahmu dan pasti jadi makanan kegemaranmu di hari libur.

Anda jangan bingung jika kamu ingin menyantap nasi ayam mentai, karena nasi ayam mentai tidak sulit untuk ditemukan dan anda pun dapat membuatnya sendiri di tempatmu. nasi ayam mentai bisa dimasak dengan beraneka cara. Saat ini telah banyak banget cara kekinian yang membuat nasi ayam mentai semakin lezat.

Resep nasi ayam mentai pun gampang dibuat, lho. Anda tidak usah repot-repot untuk memesan nasi ayam mentai, lantaran Kita bisa membuatnya ditempatmu. Bagi Anda yang mau menghidangkannya, inilah cara untuk menyajikan nasi ayam mentai yang lezat yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Nasi ayam mentai:

1. Ambil  Bahan saus :
1. Sediakan  Mayonaise (aku pakai mayumi)
1. Siapkan  Saus pedas (aku pakai delmonte)
1. Ambil  Bon nori mama suka
1. Ambil  Bahan nasi :
1. Ambil secukupnya Nasi
1. Sediakan 1 sdm minyak wijen
1. Siapkan secukupnya Bon nori
1. Sediakan sesuai selera Bon cabe
1. Ambil  Bahan ayam :
1. Sediakan  Ayam fillet (1kg)
1. Sediakan 2 bawang putih cincang
1. Sediakan  Marinasi ayam :
1. Sediakan 2 bawang putih cincang
1. Sediakan Seruas jari jahe cincang
1. Ambil 1 sdm minyak wijen
1. Ambil 1 sdm saos tiram




<!--inarticleads2-->

##### Langkah-langkah membuat Nasi ayam mentai:

1. Marinasi ayam yang sudah di potong dadu dengan bawang putih, jahe, minyak wijen dan saus tiram. Diamkan selama 30menit - 1jam.
1. Tumis bawang putih, masukkan ayam. Tumis hingga sudah agak matang. Masukkan air sedikit. Beri garam, gula, lada secukupnya. Boleh tambah saos tiram.
1. Campur semua bahan nasi.
1. Campur semua bahan saos
1. Susun nasi di atas wadah, lalu ayam, dan ditutup dengan saos mentai. Lalu taburi bon nori di atasnya.
1. Ovem selama 20 menit, dengan suhu 200 dan api atas saja. Siap dimakaaan.




Ternyata resep nasi ayam mentai yang mantab sederhana ini enteng banget ya! Kamu semua mampu menghidangkannya. Cara buat nasi ayam mentai Sangat sesuai sekali buat kamu yang baru belajar memasak ataupun bagi anda yang telah jago dalam memasak.

Tertarik untuk mulai mencoba membuat resep nasi ayam mentai nikmat simple ini? Kalau kalian tertarik, mending kamu segera buruan siapin alat-alat dan bahan-bahannya, lalu bikin deh Resep nasi ayam mentai yang mantab dan simple ini. Sangat mudah kan. 

Maka dari itu, daripada anda berlama-lama, yuk kita langsung saja bikin resep nasi ayam mentai ini. Pasti kalian tiidak akan menyesal bikin resep nasi ayam mentai mantab tidak ribet ini! Selamat berkreasi dengan resep nasi ayam mentai mantab tidak ribet ini di rumah kalian masing-masing,oke!.

