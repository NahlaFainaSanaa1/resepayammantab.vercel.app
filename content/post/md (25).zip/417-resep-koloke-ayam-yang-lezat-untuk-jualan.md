---
description: "Resep Koloke Ayam yang lezat Untuk Jualan"
title: "Resep Koloke Ayam yang lezat Untuk Jualan"
slug: 417-resep-koloke-ayam-yang-lezat-untuk-jualan
date: 2021-04-16T18:51:49.294Z
image: https://img-global.cpcdn.com/recipes/247fb2be7642f2aa/680x482cq70/koloke-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/247fb2be7642f2aa/680x482cq70/koloke-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/247fb2be7642f2aa/680x482cq70/koloke-ayam-foto-resep-utama.jpg
author: Eddie Watkins
ratingvalue: 4.8
reviewcount: 7
recipeingredient:
- "50 gr fillet ayam potong kecil"
- "1/4 bh nanas potong kecil"
- "1/2 bh timun potongpotong"
- "1/2 bh wortel kecil potong korek api"
- "1/2 buah bawang Bombay potong bulat"
- " Bumbu perendam"
- "1 sdt bawang putih bubuk"
- "1/2 sdt lada bubuk"
- "1 sdm susu bubuk"
- "1/2 sdt garam"
- "1 butir telur"
- " Bahan kering"
- "150 gr tepung bumbu"
- " Saus asam manis"
- "3 bh bawang putih cincang"
- "4 siung bawang putih cincang"
- "1/4 bh Bombay cincang"
- "6 sdm saus tomat"
- "1 sdm kecap inggris skip"
- "1 sdm saus sambal"
- "300 ml air"
- "1/2 sdt garam selera"
- "1/2 sdt gula pasir"
recipeinstructions:
- "Siapkan bahan-bahannya."
- "Ayam yang sudah dipotong-potong diberi bumbu perendam biarkan hingga 15 menit. Lalu gulingkan ke bahan kering."
- "Goreng hingga matang, angkat dan tiriskan."
- "Buat bumbu saus: tumis bawang merah, bawang bombay dan bawang putih hingga harum lalu tambahkan air biarkan mendidih. Masukkan wortel, timun lalu potongan nanas. Biarkan setengah empuk saja."
- "Masukkan saus tomat, saus sambal, garam dan gula pasir koreksi rasa. Masukkan bawang Bombay iris bulat hingga setengah layu. Aduk rata."
- "Masukkan ayam goreng tepung aduk sebentar hingga tercampur rata. Angkat dan sajikan."
categories:
- Resep
tags:
- koloke
- ayam

katakunci: koloke ayam 
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dessert

---


![Koloke Ayam](https://img-global.cpcdn.com/recipes/247fb2be7642f2aa/680x482cq70/koloke-ayam-foto-resep-utama.jpg)

Apabila kita seorang ibu, mempersiapkan hidangan nikmat untuk orang tercinta merupakan suatu hal yang membahagiakan untuk kita sendiri. Tanggung jawab seorang  wanita bukan sekedar mengerjakan pekerjaan rumah saja, namun kamu juga wajib memastikan kebutuhan gizi terpenuhi dan juga panganan yang disantap orang tercinta harus menggugah selera.

Di zaman  sekarang, kalian memang dapat membeli santapan praktis tidak harus repot memasaknya dahulu. Tetapi ada juga orang yang selalu ingin menyajikan yang terenak untuk orang yang dicintainya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan kesukaan famili. 



Mungkinkah anda merupakan seorang penikmat koloke ayam?. Asal kamu tahu, koloke ayam merupakan sajian khas di Indonesia yang kini digemari oleh kebanyakan orang di hampir setiap tempat di Indonesia. Kita bisa memasak koloke ayam kreasi sendiri di rumahmu dan dapat dijadikan santapan kesenanganmu di hari liburmu.

Anda tidak perlu bingung untuk mendapatkan koloke ayam, lantaran koloke ayam tidak sukar untuk didapatkan dan juga kalian pun dapat membuatnya sendiri di tempatmu. koloke ayam bisa diolah memalui beraneka cara. Saat ini telah banyak banget cara kekinian yang membuat koloke ayam lebih enak.

Resep koloke ayam juga mudah dibuat, lho. Kalian tidak perlu ribet-ribet untuk membeli koloke ayam, tetapi Kamu mampu menghidangkan di rumah sendiri. Untuk Kamu yang akan menghidangkannya, dibawah ini merupakan cara untuk menyajikan koloke ayam yang enak yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Koloke Ayam:

1. Ambil 50 gr fillet ayam potong kecil
1. Siapkan 1/4 bh nanas potong kecil
1. Ambil 1/2 bh timun potong-potong
1. Siapkan 1/2 bh wortel kecil potong korek api
1. Sediakan 1/2 buah bawang Bombay potong bulat
1. Ambil  Bumbu perendam:
1. Siapkan 1 sdt bawang putih bubuk
1. Sediakan 1/2 sdt lada bubuk
1. Siapkan 1 sdm susu bubuk
1. Ambil 1/2 sdt garam
1. Gunakan 1 butir telur
1. Sediakan  Bahan kering
1. Gunakan 150 gr tepung bumbu
1. Sediakan  Saus asam manis:
1. Gunakan 3 bh bawang putih cincang
1. Sediakan 4 siung bawang putih cincang
1. Ambil 1/4 bh Bombay cincang
1. Ambil 6 sdm saus tomat
1. Ambil 1 sdm kecap inggris (skip)
1. Sediakan 1 sdm saus sambal
1. Ambil 300 ml air
1. Sediakan 1/2 sdt garam (selera)
1. Siapkan 1/2 sdt gula pasir




<!--inarticleads2-->

##### Cara membuat Koloke Ayam:

1. Siapkan bahan-bahannya.
1. Ayam yang sudah dipotong-potong diberi bumbu perendam biarkan hingga 15 menit. Lalu gulingkan ke bahan kering.
1. Goreng hingga matang, angkat dan tiriskan.
1. Buat bumbu saus: tumis bawang merah, bawang bombay dan bawang putih hingga harum lalu tambahkan air biarkan mendidih. Masukkan wortel, timun lalu potongan nanas. Biarkan setengah empuk saja.
1. Masukkan saus tomat, saus sambal, garam dan gula pasir koreksi rasa. Masukkan bawang Bombay iris bulat hingga setengah layu. Aduk rata.
1. Masukkan ayam goreng tepung aduk sebentar hingga tercampur rata. Angkat dan sajikan.




Ternyata cara buat koloke ayam yang lezat tidak rumit ini gampang sekali ya! Kamu semua bisa membuatnya. Resep koloke ayam Sangat sesuai sekali untuk anda yang baru mau belajar memasak ataupun juga untuk kalian yang sudah pandai memasak.

Apakah kamu tertarik mulai mencoba buat resep koloke ayam nikmat simple ini? Kalau kalian mau, yuk kita segera buruan siapin peralatan dan bahan-bahannya, maka buat deh Resep koloke ayam yang nikmat dan tidak rumit ini. Benar-benar mudah kan. 

Oleh karena itu, daripada kita berlama-lama, ayo langsung aja buat resep koloke ayam ini. Pasti kalian tak akan nyesel sudah bikin resep koloke ayam enak sederhana ini! Selamat mencoba dengan resep koloke ayam mantab simple ini di rumah kalian sendiri,ya!.

