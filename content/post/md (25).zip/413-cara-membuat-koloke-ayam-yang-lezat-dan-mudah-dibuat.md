---
description: "Cara membuat Koloke Ayam yang lezat dan Mudah Dibuat"
title: "Cara membuat Koloke Ayam yang lezat dan Mudah Dibuat"
slug: 413-cara-membuat-koloke-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-05-29T11:04:12.929Z
image: https://img-global.cpcdn.com/recipes/9274076ffd6c7401/680x482cq70/koloke-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9274076ffd6c7401/680x482cq70/koloke-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9274076ffd6c7401/680x482cq70/koloke-ayam-foto-resep-utama.jpg
author: Michael McCormick
ratingvalue: 3.5
reviewcount: 12
recipeingredient:
- "400 gr daging dada ayam fillet"
- "5 sdm Tepung Super Crispy Kentucky Kobe"
- "100 ml air"
- " Jeruk nipis"
- "1 bungkus Tepung Super Crispy Kentucky Kobe 200 gr"
- "Secukupnya minyak goreng"
- " Bahan Saus"
- "1/4 buah nanas ukuran sedang potongpotong kecil"
- "1 siung bawang bombay sedang iris kecil"
- "2 buah tomat merah resep asli 3"
- "100 ml air"
- "1 sdt kecap ikan"
- "1 sdt kecap asin"
- "1 sdm gula"
- "1 sdm air jeruk nipis"
- "1 btg daun bawang potong sesuai selera"
- "1 sdm minyak untuk menumis"
- "1 sdm Tepung Bumbu Putih Kobe5 sdm air untuk pengental"
recipeinstructions:
- "Siapkan bahan-bahan. Cuci bersih dada ayam, potong tipis-tipis, beri air jeruk nipis, diamkan sebentar, bilas. Buat adonan dari Tepung Crispy+air, adonan cukup kental ya."
- "Rendam ayam dalam adonan selama 30 menit. Siapkan minyak goreng panas. Setelah cukup merendam, siapkan Tepung Crispy kering dalam piring. Balut ayam merata dengan tepung sambil ditekan2 perlahan, lalu goreng dgn api sedang sampai matang berwarna coklat keemasan. Angkat tiriskan."
- "Membuat saus : rebus tomat sampai lembek dan terkelupas kulitnya. Angkat, tunggu hangat lalu haluskan (bisa pakai blender/chopper)."
- "Tumis bawang bombay sampai harum, lalu masukkan tomat halus. Aduk rata. Tambahkan air dan bumbu-bumbu aduk rata. Koreksi rasanya."
- "Masukkan nanas dan daun bawang aduk rata. Terakhir sebelum diangkat, masukkan pengental aduk rata."
- "Penyajian : tata ayam crispy dalam piring, siram dengan saus asam manis nanas."
categories:
- Resep
tags:
- koloke
- ayam

katakunci: koloke ayam 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dessert

---


![Koloke Ayam](https://img-global.cpcdn.com/recipes/9274076ffd6c7401/680x482cq70/koloke-ayam-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan masakan menggugah selera untuk famili adalah suatu hal yang sangat menyenangkan bagi kita sendiri. Tanggung jawab seorang istri Tidak cuma mengerjakan pekerjaan rumah saja, tapi kamu pun harus memastikan kebutuhan gizi tercukupi dan juga hidangan yang disantap keluarga tercinta harus nikmat.

Di zaman  sekarang, kamu sebenarnya dapat membeli santapan siap saji tidak harus capek memasaknya dahulu. Tetapi ada juga orang yang memang mau memberikan hidangan yang terlezat bagi keluarganya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan famili. 



Apakah anda seorang penggemar koloke ayam?. Tahukah kamu, koloke ayam adalah hidangan khas di Nusantara yang sekarang disenangi oleh orang-orang di berbagai daerah di Nusantara. Anda bisa membuat koloke ayam kreasi sendiri di rumah dan boleh jadi makanan favorit di akhir pekanmu.

Kalian tak perlu bingung jika kamu ingin memakan koloke ayam, karena koloke ayam mudah untuk ditemukan dan anda pun boleh memasaknya sendiri di rumah. koloke ayam bisa dimasak memalui beragam cara. Kini pun telah banyak banget cara kekinian yang menjadikan koloke ayam lebih nikmat.

Resep koloke ayam juga sangat mudah untuk dibuat, lho. Kita tidak perlu capek-capek untuk membeli koloke ayam, karena Kalian mampu menghidangkan sendiri di rumah. Bagi Kita yang mau menghidangkannya, berikut ini cara untuk membuat koloke ayam yang lezat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Koloke Ayam:

1. Ambil 400 gr daging dada ayam fillet
1. Siapkan 5 sdm Tepung Super Crispy Kentucky Kobe
1. Gunakan 100 ml air
1. Ambil  Jeruk nipis
1. Siapkan 1 bungkus Tepung Super Crispy Kentucky Kobe (200 gr)
1. Siapkan Secukupnya minyak goreng
1. Ambil  Bahan Saus
1. Siapkan 1/4 buah nanas ukuran sedang (potong-potong kecil)
1. Ambil 1 siung bawang bombay sedang (iris kecil)
1. Gunakan 2 buah tomat merah (resep asli 3)
1. Ambil 100 ml air
1. Siapkan 1 sdt kecap ikan
1. Siapkan 1 sdt kecap asin
1. Gunakan 1 sdm gula
1. Gunakan 1 sdm air jeruk nipis
1. Sediakan 1 btg daun bawang (potong sesuai selera)
1. Gunakan 1 sdm minyak untuk menumis
1. Gunakan 1 sdm Tepung Bumbu Putih Kobe+5 sdm air untuk pengental




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Koloke Ayam:

1. Siapkan bahan-bahan. Cuci bersih dada ayam, potong tipis-tipis, beri air jeruk nipis, diamkan sebentar, bilas. Buat adonan dari Tepung Crispy+air, adonan cukup kental ya.
1. Rendam ayam dalam adonan selama 30 menit. Siapkan minyak goreng panas. Setelah cukup merendam, siapkan Tepung Crispy kering dalam piring. Balut ayam merata dengan tepung sambil ditekan2 perlahan, lalu goreng dgn api sedang sampai matang berwarna coklat keemasan. Angkat tiriskan.
1. Membuat saus : rebus tomat sampai lembek dan terkelupas kulitnya. Angkat, tunggu hangat lalu haluskan (bisa pakai blender/chopper).
1. Tumis bawang bombay sampai harum, lalu masukkan tomat halus. Aduk rata. Tambahkan air dan bumbu-bumbu aduk rata. Koreksi rasanya.
1. Masukkan nanas dan daun bawang aduk rata. Terakhir sebelum diangkat, masukkan pengental aduk rata.
1. Penyajian : tata ayam crispy dalam piring, siram dengan saus asam manis nanas.




Wah ternyata cara membuat koloke ayam yang mantab sederhana ini gampang banget ya! Anda Semua dapat memasaknya. Cara Membuat koloke ayam Cocok banget untuk kalian yang baru belajar memasak maupun juga untuk kamu yang sudah jago memasak.

Tertarik untuk mulai mencoba membuat resep koloke ayam enak tidak rumit ini? Kalau tertarik, yuk kita segera siapin alat dan bahan-bahannya, lalu bikin deh Resep koloke ayam yang nikmat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kita berlama-lama, yuk kita langsung saja bikin resep koloke ayam ini. Dijamin kamu gak akan menyesal membuat resep koloke ayam nikmat sederhana ini! Selamat berkreasi dengan resep koloke ayam mantab sederhana ini di tempat tinggal sendiri,oke!.

