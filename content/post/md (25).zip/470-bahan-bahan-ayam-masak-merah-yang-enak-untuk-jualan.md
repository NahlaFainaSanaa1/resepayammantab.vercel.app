---
description: "Bahan-bahan Ayam masak merah yang enak Untuk Jualan"
title: "Bahan-bahan Ayam masak merah yang enak Untuk Jualan"
slug: 470-bahan-bahan-ayam-masak-merah-yang-enak-untuk-jualan
date: 2021-03-24T02:11:38.912Z
image: https://img-global.cpcdn.com/recipes/8f10084c47979600/680x482cq70/ayam-masak-merah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8f10084c47979600/680x482cq70/ayam-masak-merah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8f10084c47979600/680x482cq70/ayam-masak-merah-foto-resep-utama.jpg
author: Elnora Lindsey
ratingvalue: 4.7
reviewcount: 7
recipeingredient:
- "1 ekor ayam berat  13 kg potong2"
- "1 bh jeruk nipis"
- "1 sdt garam"
- "2 btg serai ambil bagian putihnya geprek"
- "1 bh bawang bombay belah 2 iris kasar"
- "2 sdm gula pasir"
- "1 sdt garam"
- "4 sdm saus sambal"
- "250 ml air"
- "200 ml minyak goreng untuk menumis"
- " Daun seledri secukupnya untuk taburan"
- " Bawang goreng secukupnya untuk taburan"
- " Bumbu halus "
- "8 butir bawang merah"
- "6 siung bawang putih"
- "2 cm jahe"
- "20 bh cabai kering warnanya bikin merah lebih cantik"
recipeinstructions:
- "Cuci bersih ayam lalu baluri dengan garam dan air jeruk nipis. Diamkan 15 menit. Lalu goreng 3/4 matang. Sisihkan."
- "Panaskan minyak. Tumis serai sampai agak kering. Lalu masukkan bawang bombay. Tumis sebentar. Lalu masukkan bumbu halus. Tumis hingga wangi dan warna berubah agak gelap."
- "Masukkan saus sambal, gula pasir dan garam.. aduk rata."
- "Masukkan ayam. Tambahkan air, masak hingga air agak menyusut. Test rasa. Angkat. Sajikan dengan ditaburi daun seledri dan bawang merah goreng."
categories:
- Resep
tags:
- ayam
- masak
- merah

katakunci: ayam masak merah 
nutrition: 132 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam masak merah](https://img-global.cpcdn.com/recipes/8f10084c47979600/680x482cq70/ayam-masak-merah-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyajikan masakan mantab buat keluarga merupakan suatu hal yang menyenangkan untuk kita sendiri. Kewajiban seorang istri bukan cuman mengatur rumah saja, tetapi anda pun wajib menyediakan kebutuhan gizi tercukupi dan juga panganan yang dikonsumsi anak-anak mesti sedap.

Di zaman  saat ini, anda memang dapat membeli santapan praktis tanpa harus repot membuatnya lebih dulu. Tetapi banyak juga mereka yang selalu ingin memberikan hidangan yang terenak untuk keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai masakan kesukaan famili. 



Apakah anda adalah seorang penggemar ayam masak merah?. Asal kamu tahu, ayam masak merah merupakan sajian khas di Nusantara yang kini disenangi oleh setiap orang dari hampir setiap tempat di Nusantara. Anda dapat menghidangkan ayam masak merah hasil sendiri di rumahmu dan pasti jadi camilan kesenanganmu di hari libur.

Kita tidak perlu bingung jika kamu ingin mendapatkan ayam masak merah, karena ayam masak merah mudah untuk ditemukan dan anda pun dapat membuatnya sendiri di tempatmu. ayam masak merah boleh dimasak memalui beragam cara. Sekarang ada banyak cara modern yang membuat ayam masak merah semakin mantap.

Resep ayam masak merah pun sangat gampang dihidangkan, lho. Kalian jangan ribet-ribet untuk memesan ayam masak merah, karena Kamu bisa membuatnya sendiri di rumah. Bagi Kita yang hendak membuatnya, inilah resep untuk menyajikan ayam masak merah yang nikamat yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam masak merah:

1. Ambil 1 ekor ayam (berat +/- 1.3 kg) potong2
1. Ambil 1 bh jeruk nipis
1. Gunakan 1 sdt garam
1. Siapkan 2 btg serai, ambil bagian putihnya, geprek
1. Siapkan 1 bh bawang bombay, belah 2 iris kasar
1. Ambil 2 sdm gula pasir
1. Siapkan 1 sdt garam
1. Ambil 4 sdm saus sambal
1. Sediakan 250 ml air
1. Sediakan 200 ml minyak goreng untuk menumis
1. Sediakan  Daun seledri secukupnya untuk taburan
1. Ambil  Bawang goreng secukupnya untuk taburan
1. Ambil  Bumbu halus :
1. Ambil 8 butir bawang merah
1. Gunakan 6 siung bawang putih
1. Sediakan 2 cm jahe
1. Sediakan 20 bh cabai kering (warnanya bikin merah lebih cantik)




<!--inarticleads2-->

##### Cara membuat Ayam masak merah:

1. Cuci bersih ayam lalu baluri dengan garam dan air jeruk nipis. Diamkan 15 menit. Lalu goreng 3/4 matang. Sisihkan.
1. Panaskan minyak. Tumis serai sampai agak kering. Lalu masukkan bawang bombay. Tumis sebentar. Lalu masukkan bumbu halus. Tumis hingga wangi dan warna berubah agak gelap.
1. Masukkan saus sambal, gula pasir dan garam.. aduk rata.
1. Masukkan ayam. Tambahkan air, masak hingga air agak menyusut. Test rasa. Angkat. Sajikan dengan ditaburi daun seledri dan bawang merah goreng.




Wah ternyata cara membuat ayam masak merah yang mantab sederhana ini mudah banget ya! Kamu semua mampu menghidangkannya. Resep ayam masak merah Sangat cocok sekali untuk kalian yang baru akan belajar memasak atau juga bagi anda yang sudah hebat memasak.

Tertarik untuk mencoba membikin resep ayam masak merah nikmat sederhana ini? Kalau kalian mau, ayo kamu segera siapkan alat dan bahannya, maka bikin deh Resep ayam masak merah yang mantab dan simple ini. Benar-benar gampang kan. 

Maka, ketimbang kita berfikir lama-lama, yuk kita langsung sajikan resep ayam masak merah ini. Dijamin kamu tiidak akan nyesel sudah bikin resep ayam masak merah lezat tidak rumit ini! Selamat berkreasi dengan resep ayam masak merah nikmat simple ini di tempat tinggal masing-masing,oke!.

