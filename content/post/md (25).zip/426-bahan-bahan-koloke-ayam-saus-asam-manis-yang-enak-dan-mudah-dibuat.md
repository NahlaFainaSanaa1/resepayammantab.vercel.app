---
description: "Bahan-bahan Koloke Ayam Saus Asam Manis yang enak dan Mudah Dibuat"
title: "Bahan-bahan Koloke Ayam Saus Asam Manis yang enak dan Mudah Dibuat"
slug: 426-bahan-bahan-koloke-ayam-saus-asam-manis-yang-enak-dan-mudah-dibuat
date: 2021-03-08T20:40:17.187Z
image: https://img-global.cpcdn.com/recipes/c5bdd66264ea6b09/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c5bdd66264ea6b09/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c5bdd66264ea6b09/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
author: Clara Valdez
ratingvalue: 3.7
reviewcount: 13
recipeingredient:
- "300 gram ayam fillet"
- " Bumbu Marinasi "
- "2 sdt bawang putih bubuk"
- "1/2 sdt lada bubuk"
- "Sejumput garam"
- " Putih telur dari 1 butir telur"
- "1 sdm bahan kering"
- "100 ml air es"
- " Bahan kering "
- "100 gr tepung ayam krispi"
- "100 gr terigu"
- "1/4 sdt baking powder"
- " Bahan saus "
- "1 buah bawang Bombay cincang kasar 12 nya untuk ditumis"
- "1 buah wortel potong korek api"
- "1 buah ketimun buang bijinya iris korek api"
- "1/4 buah nanas iris kecilkecil"
- "2 siung bawang putih cincang kasar"
- "1 sdm kecap inggris"
- "10 sdm saos tomat"
- "2 sdm saus sambal"
- "1/2 sdt lada halus"
- "1 sdt garam"
- "1 sdt gula pasir"
- "100-200 ml air"
recipeinstructions:
- "Cuci ayam, lalu potong-potong, beri bumbu marinasi, simpan dikulkas 30 menit."
- "Campurkan semua bahan basah,aduk rata. Sisihkan. Di wadah lain, campurkan semua bahan kering, aduk rata."
- "Kemudian masukan ayam ke dalam bahan kering lalu bahan basah, lalu bahan kering. Kemudian goreng diminyak banyak hingga berwarna golden brown. Angkat dan tiriskan."
- "Buat saus : tumis duo bawang. Masukkan saus tomat,saus sambal dan air. Tambah garam, gula dan lada,aduk rata. Masukkan wortel,timun dan nanas. Tes rasa. Tambahkan sisa bawang bombai."
- "Penyajiannya : tata ayam di wadah lalu siram dengan saus."
categories:
- Resep
tags:
- koloke
- ayam
- saus

katakunci: koloke ayam saus 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dessert

---


![Koloke Ayam Saus Asam Manis](https://img-global.cpcdn.com/recipes/c5bdd66264ea6b09/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg)

Apabila kita seorang wanita, menyajikan santapan sedap untuk orang tercinta adalah hal yang menyenangkan bagi kita sendiri. Kewajiban seorang istri Tidak saja menangani rumah saja, namun kamu pun wajib menyediakan kebutuhan gizi tercukupi dan olahan yang disantap keluarga tercinta mesti sedap.

Di zaman  saat ini, anda sebenarnya mampu mengorder olahan jadi meski tidak harus susah mengolahnya terlebih dahulu. Tetapi ada juga mereka yang memang ingin memberikan yang terenak bagi orang tercintanya. Sebab, menghidangkan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai masakan kesukaan famili. 



Mungkinkah anda adalah seorang penggemar koloke ayam saus asam manis?. Tahukah kamu, koloke ayam saus asam manis merupakan makanan khas di Nusantara yang sekarang disukai oleh orang-orang di berbagai tempat di Nusantara. Kita dapat menyajikan koloke ayam saus asam manis kreasi sendiri di rumah dan pasti jadi santapan favoritmu di hari liburmu.

Anda tidak perlu bingung untuk mendapatkan koloke ayam saus asam manis, lantaran koloke ayam saus asam manis tidak sulit untuk didapatkan dan kalian pun bisa memasaknya sendiri di tempatmu. koloke ayam saus asam manis dapat dimasak lewat bermacam cara. Saat ini telah banyak sekali cara kekinian yang menjadikan koloke ayam saus asam manis semakin enak.

Resep koloke ayam saus asam manis juga mudah sekali untuk dibuat, lho. Kita tidak perlu capek-capek untuk memesan koloke ayam saus asam manis, lantaran Kita dapat menyajikan sendiri di rumah. Bagi Kalian yang akan menyajikannya, di bawah ini adalah cara membuat koloke ayam saus asam manis yang enak yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Koloke Ayam Saus Asam Manis:

1. Ambil 300 gram ayam fillet
1. Gunakan  Bumbu Marinasi :
1. Gunakan 2 sdt bawang putih bubuk
1. Siapkan 1/2 sdt lada bubuk
1. Sediakan Sejumput garam
1. Ambil  Putih telur dari 1 butir telur
1. Ambil 1 sdm bahan kering
1. Ambil 100 ml air es
1. Siapkan  Bahan kering :
1. Ambil 100 gr tepung ayam krispi
1. Ambil 100 gr terigu
1. Sediakan 1/4 sdt baking powder
1. Siapkan  Bahan saus :
1. Sediakan 1 buah bawang Bombay, cincang kasar, 1/2 nya untuk ditumis
1. Sediakan 1 buah wortel, potong korek api
1. Sediakan 1 buah ketimun, buang bijinya, iris korek api
1. Sediakan 1/4 buah nanas, iris kecil-kecil
1. Sediakan 2 siung bawang putih, cincang kasar
1. Ambil 1 sdm kecap inggris
1. Ambil 10 sdm saos tomat
1. Siapkan 2 sdm saus sambal
1. Sediakan 1/2 sdt lada halus
1. Siapkan 1 sdt garam
1. Gunakan 1 sdt gula pasir
1. Gunakan 100-200 ml air




<!--inarticleads2-->

##### Cara membuat Koloke Ayam Saus Asam Manis:

1. Cuci ayam, lalu potong-potong, beri bumbu marinasi, simpan dikulkas 30 menit.
1. Campurkan semua bahan basah,aduk rata. Sisihkan. Di wadah lain, campurkan semua bahan kering, aduk rata.
1. Kemudian masukan ayam ke dalam bahan kering lalu bahan basah, lalu bahan kering. Kemudian goreng diminyak banyak hingga berwarna golden brown. Angkat dan tiriskan.
1. Buat saus : tumis duo bawang. Masukkan saus tomat,saus sambal dan air. Tambah garam, gula dan lada,aduk rata. Masukkan wortel,timun dan nanas. Tes rasa. Tambahkan sisa bawang bombai.
1. Penyajiannya : tata ayam di wadah lalu siram dengan saus.




Wah ternyata cara membuat koloke ayam saus asam manis yang nikamt tidak ribet ini mudah banget ya! Anda Semua dapat membuatnya. Cara buat koloke ayam saus asam manis Cocok banget buat kita yang baru mau belajar memasak ataupun juga untuk kalian yang sudah hebat memasak.

Tertarik untuk mencoba buat resep koloke ayam saus asam manis enak tidak rumit ini? Kalau kamu ingin, mending kamu segera buruan siapkan peralatan dan bahan-bahannya, lantas buat deh Resep koloke ayam saus asam manis yang mantab dan tidak ribet ini. Benar-benar gampang kan. 

Oleh karena itu, daripada anda diam saja, yuk kita langsung bikin resep koloke ayam saus asam manis ini. Dijamin kalian tiidak akan menyesal sudah buat resep koloke ayam saus asam manis nikmat tidak ribet ini! Selamat mencoba dengan resep koloke ayam saus asam manis mantab tidak rumit ini di rumah kalian sendiri,oke!.

