---
description: "Resep Mentai Rice Chicken Sederhana Untuk Jualan"
title: "Resep Mentai Rice Chicken Sederhana Untuk Jualan"
slug: 473-resep-mentai-rice-chicken-sederhana-untuk-jualan
date: 2021-04-02T03:27:09.966Z
image: https://img-global.cpcdn.com/recipes/e3ee29f62139c113/680x482cq70/mentai-rice-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e3ee29f62139c113/680x482cq70/mentai-rice-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e3ee29f62139c113/680x482cq70/mentai-rice-chicken-foto-resep-utama.jpg
author: Teresa Sims
ratingvalue: 3.3
reviewcount: 3
recipeingredient:
- " Bahan Marinasi Ayam "
- "200 gr ayam filletpotong"
- "2 siung bwgputih"
- "1 sdm saus tiram1sdm kecap asin1sdm santan kental susu"
- "1 sdt minyak wijen  1sdt gula aren"
- " Bahan campuran Nasi "
- "2 porsi nasi"
- "4 sdm nori abon nori"
- "1 sdt minyak wijen  1sdt kecap asin"
- " Bahan Saus "
- "5 sdm mayonaise"
- "2 sdm saus sambal"
- "2 sdm SKM"
- " Topping "
- " Keju melted  abon nori"
recipeinstructions:
- "Ayam :  campur kan ayam dg semua bahan marinasi,kecuali bombay,masukkan ke kulkas minim 30mnt,semalaman jg bisa.sakkarepe wes. 🍗 tumis bombay hingga harum,kemudian masuk ayam,masak hingga kulitnya kesat,bisa ditambahkan air sedikit,masak hingga kuah kering kembali &amp; ayam kecoklatan.sisihkan 🍗 kalau ga mau ribet ayam bs dipanggang diatas asap hingga betul&#34; matang."
- "Nasi : aduk semua jadi 1.sisihkan"
- "Saus : aduk mayonaise dg saus sambal &amp; skm"
- "Penyelesaian :  Tata nasi pd loyang / alumunium cup, kemudian beri lapisan ayam ratakan,lapisi atasnya dg nasi lg,kemudian topping dg  campuran saus &amp; keju tadi. 🍛 oven kurleb 20mnt/hingga atasnya berubah warna matang.angkat,taburi dg abon nori pedas Yummmyyyy..... Yippy yipppy...yipppyyy..."
categories:
- Resep
tags:
- mentai
- rice
- chicken

katakunci: mentai rice chicken 
nutrition: 165 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Lunch

---


![Mentai Rice Chicken](https://img-global.cpcdn.com/recipes/e3ee29f62139c113/680x482cq70/mentai-rice-chicken-foto-resep-utama.jpg)

Jika kalian seorang orang tua, mempersiapkan santapan lezat untuk keluarga merupakan suatu hal yang memuaskan untuk kita sendiri. Kewajiban seorang ibu Tidak sekedar mengurus rumah saja, namun anda pun wajib menyediakan keperluan gizi terpenuhi dan santapan yang dikonsumsi anak-anak wajib menggugah selera.

Di masa  saat ini, kamu sebenarnya mampu membeli panganan praktis tidak harus repot membuatnya dahulu. Tapi banyak juga mereka yang selalu mau memberikan yang terenak bagi orang yang dicintainya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan kesukaan orang tercinta. 



Apakah kamu seorang penggemar mentai rice chicken?. Asal kamu tahu, mentai rice chicken adalah sajian khas di Indonesia yang saat ini disukai oleh banyak orang dari berbagai daerah di Indonesia. Anda bisa membuat mentai rice chicken sendiri di rumah dan dapat dijadikan santapan kegemaranmu di akhir pekanmu.

Kamu tidak perlu bingung jika kamu ingin mendapatkan mentai rice chicken, lantaran mentai rice chicken sangat mudah untuk ditemukan dan juga kamu pun boleh membuatnya sendiri di tempatmu. mentai rice chicken bisa diolah lewat beragam cara. Kini pun telah banyak banget resep kekinian yang menjadikan mentai rice chicken semakin lebih mantap.

Resep mentai rice chicken pun sangat gampang untuk dibuat, lho. Kalian tidak perlu capek-capek untuk membeli mentai rice chicken, tetapi Kalian mampu menyajikan sendiri di rumah. Bagi Kalian yang ingin membuatnya, berikut cara untuk membuat mentai rice chicken yang mantab yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Mentai Rice Chicken:

1. Siapkan  Bahan Marinasi Ayam :
1. Gunakan 200 gr ayam fillet,potong&#34;
1. Ambil 2 siung bwg.putih
1. Ambil 1 sdm saus tiram,1sdm kecap asin,1sdm santan kental /susu
1. Siapkan 1 sdt minyak wijen + 1sdt gula aren
1. Gunakan  Bahan campuran Nasi :
1. Ambil 2 porsi nasi
1. Siapkan 4 sdm nori /abon nori
1. Gunakan 1 sdt minyak wijen + 1sdt kecap asin
1. Siapkan  Bahan Saus :
1. Siapkan 5 sdm mayonaise
1. Sediakan 2 sdm saus sambal
1. Siapkan 2 sdm SKM
1. Sediakan  Topping :
1. Siapkan  Keju melted &amp; abon nori




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Mentai Rice Chicken:

1. Ayam :  - campur kan ayam dg semua bahan marinasi,kecuali bombay,masukkan ke kulkas minim 30mnt,semalaman jg bisa.sakkarepe wes. - 🍗 tumis bombay hingga harum,kemudian masuk ayam,masak hingga kulitnya kesat,bisa ditambahkan air sedikit,masak hingga kuah kering kembali &amp; ayam kecoklatan.sisihkan - 🍗 kalau ga mau ribet ayam bs dipanggang diatas asap hingga betul&#34; matang.
1. Nasi : aduk semua jadi 1.sisihkan
1. Saus : aduk mayonaise dg saus sambal &amp; skm
1. Penyelesaian :  - Tata nasi pd loyang / alumunium cup, kemudian beri lapisan ayam ratakan,lapisi atasnya dg nasi lg,kemudian topping dg  campuran saus &amp; keju tadi. - 🍛 oven kurleb 20mnt/hingga atasnya berubah warna matang.angkat,taburi dg abon nori pedas - Yummmyyyy..... Yippy yipppy...yipppyyy...




Ternyata cara buat mentai rice chicken yang lezat tidak rumit ini mudah sekali ya! Kamu semua dapat menghidangkannya. Cara buat mentai rice chicken Sangat cocok banget untuk anda yang baru akan belajar memasak ataupun juga untuk anda yang telah lihai memasak.

Apakah kamu ingin mulai mencoba bikin resep mentai rice chicken mantab simple ini? Kalau tertarik, yuk kita segera buruan menyiapkan alat dan bahan-bahannya, setelah itu bikin deh Resep mentai rice chicken yang nikmat dan sederhana ini. Benar-benar mudah kan. 

Maka dari itu, daripada anda berlama-lama, ayo kita langsung hidangkan resep mentai rice chicken ini. Dijamin anda gak akan nyesel bikin resep mentai rice chicken enak simple ini! Selamat berkreasi dengan resep mentai rice chicken nikmat simple ini di tempat tinggal sendiri,ya!.

