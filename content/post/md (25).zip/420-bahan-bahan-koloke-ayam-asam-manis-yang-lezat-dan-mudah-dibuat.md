---
description: "Bahan-bahan Koloke ayam asam manis yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Koloke ayam asam manis yang lezat dan Mudah Dibuat"
slug: 420-bahan-bahan-koloke-ayam-asam-manis-yang-lezat-dan-mudah-dibuat
date: 2021-03-11T20:32:46.425Z
image: https://img-global.cpcdn.com/recipes/2c0b09020fca45ee/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2c0b09020fca45ee/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2c0b09020fca45ee/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg
author: Ruby Williams
ratingvalue: 4.4
reviewcount: 7
recipeingredient:
- " Bahan Ayam dan Marinasi"
- "300 gr dada ayam fillet"
- "2 sdt bawang putih bubuk"
- "1/2 sdt lada halus"
- "Sejumput garam"
- " Bahan Basah"
- "1 butir putih telur"
- "1 sdm bahan kering"
- "100 ml air es"
- " Bahan Kering"
- "100 gr tepung ayam krispi"
- "100 gr tepung terigu"
- "1/4 sdt baking powder"
- " Bahan Saus"
- "2 bh bawang putih"
- "1 bh Bawang Bombay separuh di cincang separuh potong cincin"
- "1 bh wortel"
- "1 bh timun"
- "3 bh cabai keriting potong serong"
- "1/4 bh nanas"
- "10 sdm saus tomat"
- "2 sdm saus sambal"
- "1 sdm kecap inggris"
- "1 sdt garam"
- "1 sdt gula pasir"
- "1/2 sdt lada halus"
- "200 ml air"
recipeinstructions:
- "Cuci ayam, potong dadu kemudian beri bumbu marinasi yang rata. Diamkan 30 menit di chiller"
- "Siapkan adonan basah dan kering. Masukkan ayam di adonan basah, kemudian kering ulangi 2x bila perlu"
- "Goreng ayam hingga matang kecoklatan (golden brown). Sisihkan"
- "Siapkan bahan kuah. Cincang bawang putih dan Bombay. Iris cabai, Potong dadu nanas, wortel dan ketimun di potong korek api. Tumis duo bawang sampai keluar harumnya. Masukkan cabai dan air. Tambahkan saus tomat, saus sambal dan bahan2 penyedap lainnya. Test rasa"
- "Masukkan wortel timun dan nanas. Tunggu sampai wortel empuk (sekitar 5-7menit).terakhir masukkan bawang Bombay yang dipotong cincin"
- "Campurkan ayam dan kuahnya. Siap di hidangkan"
categories:
- Resep
tags:
- koloke
- ayam
- asam

katakunci: koloke ayam asam 
nutrition: 178 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Lunch

---


![Koloke ayam asam manis](https://img-global.cpcdn.com/recipes/2c0b09020fca45ee/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg)

Apabila kita seorang ibu, mempersiapkan masakan mantab bagi orang tercinta adalah suatu hal yang memuaskan untuk kamu sendiri. Tugas seorang  wanita Tidak sekadar mengerjakan pekerjaan rumah saja, namun anda pun wajib memastikan kebutuhan nutrisi tercukupi dan panganan yang dimakan anak-anak mesti lezat.

Di zaman  saat ini, kita sebenarnya bisa memesan panganan yang sudah jadi meski tidak harus susah membuatnya dahulu. Tapi banyak juga lho orang yang memang ingin menyajikan yang terbaik bagi orang tercintanya. Karena, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai masakan kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penikmat koloke ayam asam manis?. Tahukah kamu, koloke ayam asam manis merupakan sajian khas di Nusantara yang sekarang disukai oleh orang-orang dari berbagai wilayah di Indonesia. Kamu bisa memasak koloke ayam asam manis olahan sendiri di rumah dan boleh jadi camilan kesukaanmu di akhir pekanmu.

Kalian jangan bingung untuk menyantap koloke ayam asam manis, sebab koloke ayam asam manis gampang untuk didapatkan dan juga kamu pun bisa memasaknya sendiri di tempatmu. koloke ayam asam manis boleh diolah dengan bermacam cara. Sekarang telah banyak banget cara kekinian yang menjadikan koloke ayam asam manis lebih lezat.

Resep koloke ayam asam manis pun gampang sekali untuk dibikin, lho. Anda jangan capek-capek untuk membeli koloke ayam asam manis, karena Kita bisa menyajikan ditempatmu. Bagi Kalian yang ingin mencobanya, di bawah ini adalah resep menyajikan koloke ayam asam manis yang lezat yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Koloke ayam asam manis:

1. Gunakan  Bahan Ayam dan Marinasi
1. Ambil 300 gr dada ayam fillet
1. Ambil 2 sdt bawang putih bubuk
1. Sediakan 1/2 sdt lada halus
1. Siapkan Sejumput garam
1. Siapkan  Bahan Basah
1. Ambil 1 butir putih telur
1. Sediakan 1 sdm bahan kering
1. Ambil 100 ml air es
1. Ambil  Bahan Kering
1. Gunakan 100 gr tepung ayam krispi
1. Gunakan 100 gr tepung terigu
1. Gunakan 1/4 sdt baking powder
1. Sediakan  Bahan Saus
1. Siapkan 2 bh bawang putih
1. Gunakan 1 bh Bawang Bombay, separuh di cincang, separuh potong cincin
1. Siapkan 1 bh wortel
1. Gunakan 1 bh timun
1. Sediakan 3 bh cabai keriting potong serong
1. Gunakan 1/4 bh nanas
1. Ambil 10 sdm saus tomat
1. Gunakan 2 sdm saus sambal
1. Ambil 1 sdm kecap inggris
1. Sediakan 1 sdt garam
1. Ambil 1 sdt gula pasir
1. Siapkan 1/2 sdt lada halus
1. Siapkan 200 ml air




<!--inarticleads2-->

##### Cara menyiapkan Koloke ayam asam manis:

1. Cuci ayam, potong dadu kemudian beri bumbu marinasi yang rata. Diamkan 30 menit di chiller
1. Siapkan adonan basah dan kering. Masukkan ayam di adonan basah, kemudian kering ulangi 2x bila perlu
1. Goreng ayam hingga matang kecoklatan (golden brown). Sisihkan
1. Siapkan bahan kuah. Cincang bawang putih dan Bombay. Iris cabai, Potong dadu nanas, wortel dan ketimun di potong korek api. Tumis duo bawang sampai keluar harumnya. Masukkan cabai dan air. Tambahkan saus tomat, saus sambal dan bahan2 penyedap lainnya. Test rasa
1. Masukkan wortel timun dan nanas. Tunggu sampai wortel empuk (sekitar 5-7menit).terakhir masukkan bawang Bombay yang dipotong cincin
1. Campurkan ayam dan kuahnya. Siap di hidangkan




Ternyata cara buat koloke ayam asam manis yang nikamt tidak ribet ini mudah banget ya! Semua orang bisa memasaknya. Cara Membuat koloke ayam asam manis Cocok banget untuk kita yang baru mau belajar memasak ataupun juga untuk anda yang telah jago memasak.

Apakah kamu tertarik mencoba buat resep koloke ayam asam manis lezat tidak ribet ini? Kalau kamu mau, ayo kalian segera menyiapkan alat dan bahan-bahannya, lalu buat deh Resep koloke ayam asam manis yang lezat dan simple ini. Sungguh gampang kan. 

Maka dari itu, ketimbang anda berfikir lama-lama, ayo kita langsung hidangkan resep koloke ayam asam manis ini. Dijamin kalian tak akan menyesal sudah membuat resep koloke ayam asam manis lezat simple ini! Selamat mencoba dengan resep koloke ayam asam manis nikmat simple ini di rumah sendiri,ya!.

