---
description: "Resep Koloke Ayam Saus Asam Manis yang enak dan Mudah Dibuat"
title: "Resep Koloke Ayam Saus Asam Manis yang enak dan Mudah Dibuat"
slug: 423-resep-koloke-ayam-saus-asam-manis-yang-enak-dan-mudah-dibuat
date: 2021-05-20T02:24:38.566Z
image: https://img-global.cpcdn.com/recipes/029b11fa3c8b77eb/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/029b11fa3c8b77eb/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/029b11fa3c8b77eb/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
author: Louis Jackson
ratingvalue: 3.7
reviewcount: 12
recipeingredient:
- "300 gr fillet ayam"
- " Bumbu Marinasi "
- "2 sdt bawang putih bubuk"
- "1/2 sdt merica bubuk"
- "Sejumput garam"
- " Bahan kering "
- "100 gr tepung ayam krispi"
- "100 gr tepung terigu"
- "1/4 sdt baking powder"
- " Bahan basah "
- " Putih telur dari 1 butir telur"
- "1 sdm bahan kering"
- "100 ml air es"
- " Bahan saus "
- "1/2 buah bawang bombay cincang kasar untuk ditumis"
- "2 siung bawang putih cincang halus"
- "1/2 buah bawang bombay iris"
- "1 buah wortel potong korek api"
- "1 buah timun buang bijinya potong korek api"
- "1/4 buah nanas potong kecil"
- "1 sdm kecap inggris"
- "10 sdm saus tomat"
- "2 sdm saus sambal"
- "1/2 sdt merica bubuk"
- "1 sdt garam"
- "1 sdt gula pasir"
- "200 ml air"
- " Cabe iris serong optional"
recipeinstructions:
- "Cuci bersih ayam, lalu potong2. Tambahkan bumbu marinasi, diamkan 30 menit di lemari es."
- "Buat bahan kering, campur semua bahan. Begitu juga bahan basah, campur semua bahan, aduk rata."
- "Masukkan ayam kedalam bahan kering, lalu celupkan ke bahan basah, kemudian masukkan kembali ke bahan kering. Aduk rata sambil sedikit dicubit2."
- "Goreng ayam dalam minyak panas dan banyak dengan api sedang sampai golden brown, angkat, tiriskan."
- "Buat saus : tumis duo bawang sampai harum. Lalu masukkan saus tomat, saus sambal, dan air. Tambahkan bumbu2, kemudian masukkan wortel, timun, nanas, dan irisan bawang bombay. Tes rasa."
- "Penyajian : tata ayam dipiring saji, lalu siram dengan saus. Siap disajikan. Selamat mencoba."
categories:
- Resep
tags:
- koloke
- ayam
- saus

katakunci: koloke ayam saus 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Lunch

---


![Koloke Ayam Saus Asam Manis](https://img-global.cpcdn.com/recipes/029b11fa3c8b77eb/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg)

Apabila kamu seorang orang tua, menyuguhkan santapan nikmat pada orang tercinta adalah suatu hal yang memuaskan bagi anda sendiri. Tanggung jawab seorang istri bukan hanya mengatur rumah saja, tetapi anda pun wajib memastikan kebutuhan nutrisi terpenuhi dan masakan yang dimakan orang tercinta mesti menggugah selera.

Di masa  saat ini, kamu memang bisa membeli hidangan praktis meski tidak harus capek mengolahnya lebih dulu. Tetapi ada juga lho orang yang selalu mau menyajikan yang terbaik untuk orang tercintanya. Sebab, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penyuka koloke ayam saus asam manis?. Asal kamu tahu, koloke ayam saus asam manis adalah makanan khas di Nusantara yang kini disukai oleh orang-orang dari berbagai daerah di Nusantara. Kalian dapat memasak koloke ayam saus asam manis buatan sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di akhir pekan.

Kamu tidak perlu bingung jika kamu ingin mendapatkan koloke ayam saus asam manis, lantaran koloke ayam saus asam manis gampang untuk dicari dan kalian pun dapat memasaknya sendiri di rumah. koloke ayam saus asam manis boleh dimasak lewat bermacam cara. Kini pun sudah banyak banget cara modern yang membuat koloke ayam saus asam manis semakin mantap.

Resep koloke ayam saus asam manis juga mudah sekali untuk dibikin, lho. Kamu jangan repot-repot untuk memesan koloke ayam saus asam manis, lantaran Anda mampu menghidangkan sendiri di rumah. Bagi Kita yang ingin menyajikannya, dibawah ini merupakan cara menyajikan koloke ayam saus asam manis yang enak yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Koloke Ayam Saus Asam Manis:

1. Siapkan 300 gr fillet ayam
1. Gunakan  Bumbu Marinasi :
1. Gunakan 2 sdt bawang putih bubuk
1. Ambil 1/2 sdt merica bubuk
1. Gunakan Sejumput garam
1. Gunakan  Bahan kering :
1. Siapkan 100 gr tepung ayam krispi
1. Sediakan 100 gr tepung terigu
1. Siapkan 1/4 sdt baking powder
1. Gunakan  Bahan basah :
1. Sediakan  Putih telur dari 1 butir telur
1. Siapkan 1 sdm bahan kering
1. Gunakan 100 ml air es
1. Ambil  Bahan saus :
1. Gunakan 1/2 buah bawang bombay, cincang kasar untuk ditumis
1. Sediakan 2 siung bawang putih, cincang halus
1. Siapkan 1/2 buah bawang bombay, iris
1. Ambil 1 buah wortel, potong korek api
1. Ambil 1 buah timun, buang bijinya, potong korek api
1. Siapkan 1/4 buah nanas, potong kecil
1. Gunakan 1 sdm kecap inggris
1. Sediakan 10 sdm saus tomat
1. Siapkan 2 sdm saus sambal
1. Siapkan 1/2 sdt merica bubuk
1. Ambil 1 sdt garam
1. Gunakan 1 sdt gula pasir
1. Gunakan 200 ml air
1. Sediakan  Cabe, iris serong (optional)




<!--inarticleads2-->

##### Cara menyiapkan Koloke Ayam Saus Asam Manis:

1. Cuci bersih ayam, lalu potong2. Tambahkan bumbu marinasi, diamkan 30 menit di lemari es.
1. Buat bahan kering, campur semua bahan. Begitu juga bahan basah, campur semua bahan, aduk rata.
1. Masukkan ayam kedalam bahan kering, lalu celupkan ke bahan basah, kemudian masukkan kembali ke bahan kering. Aduk rata sambil sedikit dicubit2.
1. Goreng ayam dalam minyak panas dan banyak dengan api sedang sampai golden brown, angkat, tiriskan.
1. Buat saus : tumis duo bawang sampai harum. Lalu masukkan saus tomat, saus sambal, dan air. Tambahkan bumbu2, kemudian masukkan wortel, timun, nanas, dan irisan bawang bombay. Tes rasa.
1. Penyajian : tata ayam dipiring saji, lalu siram dengan saus. Siap disajikan. Selamat mencoba.




Ternyata resep koloke ayam saus asam manis yang enak simple ini enteng banget ya! Kalian semua dapat membuatnya. Cara Membuat koloke ayam saus asam manis Sangat cocok sekali buat kalian yang baru akan belajar memasak maupun juga untuk kamu yang sudah hebat dalam memasak.

Tertarik untuk mencoba membuat resep koloke ayam saus asam manis mantab sederhana ini? Kalau anda tertarik, ayo kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep koloke ayam saus asam manis yang mantab dan simple ini. Sungguh gampang kan. 

Maka, ketimbang kita diam saja, hayo kita langsung saja bikin resep koloke ayam saus asam manis ini. Dijamin kalian tak akan menyesal sudah bikin resep koloke ayam saus asam manis mantab tidak rumit ini! Selamat mencoba dengan resep koloke ayam saus asam manis lezat simple ini di rumah sendiri,oke!.

