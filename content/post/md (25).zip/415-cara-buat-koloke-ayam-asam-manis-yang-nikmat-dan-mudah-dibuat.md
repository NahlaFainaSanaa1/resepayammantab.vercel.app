---
description: "Cara buat Koloke Ayam Asam Manis yang nikmat dan Mudah Dibuat"
title: "Cara buat Koloke Ayam Asam Manis yang nikmat dan Mudah Dibuat"
slug: 415-cara-buat-koloke-ayam-asam-manis-yang-nikmat-dan-mudah-dibuat
date: 2021-02-15T00:05:58.198Z
image: https://img-global.cpcdn.com/recipes/6f460bb6063f90da/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f460bb6063f90da/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f460bb6063f90da/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg
author: Bernard Rodriquez
ratingvalue: 4.6
reviewcount: 6
recipeingredient:
- "300 gr ayam fillet potong sesuai selera"
- "2 siung bawang putih"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- " Lapisan"
- "7 sdm tepung pro sedang"
- "2 sdm maizena"
- "1 sdt lada bubuk"
- "1/2 sdt garam"
- "1 btr telur kocok lepas"
- " Saus"
- "2 siung bawang putih geprek cincang halus"
- "1 bh bawang bombay iris"
- "3 bh cabe merah keriting iris serong"
- "1 bh tomat"
- "1 bh wortel skip"
- "1 bh nanas skip"
- "1 bh timun skip"
- "5 sdm saus tomat"
- "2 sdm saus cabe"
- "1 sdm kecap inggris"
- "1 sdm minyak wijen"
- "1 sdm kecap asin"
- "1 sdm gula pasir"
- "200 ml air"
- "1 sdm maizena larutkan dgn sedikit air"
recipeinstructions:
- "Bersihkan ayam, potong sesuai selera cuci bersih dan marinasi sekitar 1 jam taruh kulkas"
- "Campur tepung, lada dan garam, aduk merata, masukkan ayam pada telur kocok dan gulirkan pada tepung tepuk sebentar lalu goreng hingga kecoklatan dan matang"
- "Saus: tumis bawang putih hingga harum lalu masukkan bawang bombay aduk rata jika sdh layu masukkan air, dan bahan yg lain, campur merata, tes rasa jika sdh pas tambahkan larutan maizena, tunggu set baru matikan"
- "Penyajian: taruh ayam krispy di piring saji dan siram dengan saus, sajikan."
categories:
- Resep
tags:
- koloke
- ayam
- asam

katakunci: koloke ayam asam 
nutrition: 114 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dinner

---


![Koloke Ayam Asam Manis](https://img-global.cpcdn.com/recipes/6f460bb6063f90da/680x482cq70/koloke-ayam-asam-manis-foto-resep-utama.jpg)

Apabila kamu seorang istri, menyajikan hidangan nikmat pada keluarga tercinta merupakan suatu hal yang sangat menyenangkan untuk kamu sendiri. Tanggung jawab seorang ibu bukan sekadar menangani rumah saja, tetapi anda pun harus menyediakan keperluan nutrisi terpenuhi dan masakan yang dimakan keluarga tercinta harus lezat.

Di zaman  sekarang, kalian sebenarnya mampu memesan olahan yang sudah jadi meski tidak harus ribet membuatnya terlebih dahulu. Tapi banyak juga lho mereka yang memang mau memberikan hidangan yang terenak untuk orang yang dicintainya. Sebab, memasak yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai kesukaan keluarga tercinta. 



Apakah kamu salah satu penyuka koloke ayam asam manis?. Asal kamu tahu, koloke ayam asam manis adalah makanan khas di Nusantara yang kini disukai oleh orang-orang dari hampir setiap wilayah di Indonesia. Kamu bisa memasak koloke ayam asam manis olahan sendiri di rumah dan boleh dijadikan makanan kesenanganmu di hari liburmu.

Kamu jangan bingung jika kamu ingin menyantap koloke ayam asam manis, sebab koloke ayam asam manis mudah untuk ditemukan dan kalian pun boleh membuatnya sendiri di rumah. koloke ayam asam manis boleh dibuat memalui beraneka cara. Kini pun ada banyak sekali resep modern yang menjadikan koloke ayam asam manis lebih enak.

Resep koloke ayam asam manis juga mudah dibuat, lho. Kita tidak usah capek-capek untuk memesan koloke ayam asam manis, karena Kamu mampu membuatnya di rumah sendiri. Untuk Kamu yang hendak menyajikannya, berikut cara menyajikan koloke ayam asam manis yang nikamat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Koloke Ayam Asam Manis:

1. Sediakan 300 gr ayam fillet, potong sesuai selera
1. Siapkan 2 siung bawang putih
1. Ambil 1/2 sdt lada bubuk
1. Siapkan 1/2 sdt garam
1. Ambil  Lapisan:
1. Gunakan 7 sdm tepung pro sedang
1. Gunakan 2 sdm maizena
1. Sediakan 1 sdt lada bubuk
1. Sediakan 1/2 sdt garam
1. Gunakan 1 btr telur kocok lepas
1. Siapkan  Saus:
1. Siapkan 2 siung bawang putih geprek cincang halus
1. Siapkan 1 bh bawang bombay iris
1. Ambil 3 bh cabe merah keriting iris serong
1. Sediakan 1 bh tomat
1. Gunakan 1 bh wortel (skip)
1. Siapkan 1 bh nanas (skip)
1. Sediakan 1 bh timun (skip)
1. Siapkan 5 sdm saus tomat
1. Ambil 2 sdm saus cabe
1. Gunakan 1 sdm kecap inggris
1. Sediakan 1 sdm minyak wijen
1. Gunakan 1 sdm kecap asin
1. Sediakan 1 sdm gula pasir
1. Sediakan 200 ml air
1. Gunakan 1 sdm maizena larutkan dgn sedikit air




<!--inarticleads2-->

##### Cara membuat Koloke Ayam Asam Manis:

1. Bersihkan ayam, potong sesuai selera cuci bersih dan marinasi sekitar 1 jam taruh kulkas
1. Campur tepung, lada dan garam, aduk merata, masukkan ayam pada telur kocok dan gulirkan pada tepung tepuk sebentar lalu goreng hingga kecoklatan dan matang
1. Saus: tumis bawang putih hingga harum lalu masukkan bawang bombay aduk rata jika sdh layu masukkan air, dan bahan yg lain, campur merata, tes rasa jika sdh pas tambahkan larutan maizena, tunggu set baru matikan
1. Penyajian: taruh ayam krispy di piring saji dan siram dengan saus, sajikan.




Wah ternyata resep koloke ayam asam manis yang lezat tidak rumit ini mudah sekali ya! Kalian semua bisa membuatnya. Cara buat koloke ayam asam manis Sangat sesuai banget untuk anda yang baru belajar memasak ataupun juga bagi kalian yang telah ahli memasak.

Tertarik untuk mencoba membikin resep koloke ayam asam manis enak tidak rumit ini? Kalau tertarik, yuk kita segera menyiapkan peralatan dan bahan-bahannya, lalu buat deh Resep koloke ayam asam manis yang enak dan tidak rumit ini. Sangat taidak sulit kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, yuk langsung aja bikin resep koloke ayam asam manis ini. Pasti kalian tak akan menyesal sudah bikin resep koloke ayam asam manis enak tidak rumit ini! Selamat mencoba dengan resep koloke ayam asam manis nikmat tidak ribet ini di tempat tinggal kalian sendiri,oke!.

