---
description: "Cara buat Ayam goreng lengkuas (irit gas) yang lezat Untuk Jualan"
title: "Cara buat Ayam goreng lengkuas (irit gas) yang lezat Untuk Jualan"
slug: 148-cara-buat-ayam-goreng-lengkuas-irit-gas-yang-lezat-untuk-jualan
date: 2021-02-15T04:29:14.280Z
image: https://img-global.cpcdn.com/recipes/7d78e5ae2f66d760/680x482cq70/ayam-goreng-lengkuas-irit-gas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7d78e5ae2f66d760/680x482cq70/ayam-goreng-lengkuas-irit-gas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7d78e5ae2f66d760/680x482cq70/ayam-goreng-lengkuas-irit-gas-foto-resep-utama.jpg
author: Joshua Robertson
ratingvalue: 3
reviewcount: 5
recipeingredient:
- "1 ekor ayam"
- "3 batang sereh geprek atau iris"
- "3 lembar salam"
- "1 sdt lada bubuk"
- "1 sdt garam"
- "1,5 sdt gula pasir"
- "400 ml air"
- " Bumbu halus 1"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "5 kemiri"
- "1 sdt ketumbar"
- "1 telunjuk kunyit"
- "50 ml minyak goreng"
- " Bumbu halus 2"
- "150 gr lengkuas pink potong memanjang"
- "100 ml air"
recipeinstructions:
- "Panaskan wajan, tumis bumbu halus 1 hingga harum."
- "Masukkan salam dan sereh tumis harum."
- "Masukkan lengkuas, aduk rata"
- "Masukkan ayam, air dan bumbu lainnya, aduk rata. Tutup panci, masak selama 5 menit. Matikan kompor 30 menit. Nyalakan kompor lagi selama 5 menit. Matikan kompor 30 menit. Setelah itu buka tutup panci."
- "Hilangkan uap panas,"
- "Goreng ayam dan lengkuas dengan api agak besar. Sampai ayam dan lengkuas berwarna kecoklatan. Angkat dan sajikan"
- "Tips menghaluskan dengan blender. Haluskan ketumbar dan kemiri terlebih dahulu. Setelah halus, masukkan bahan lainnya dan blander kembali."
categories:
- Resep
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 218 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam goreng lengkuas (irit gas)](https://img-global.cpcdn.com/recipes/7d78e5ae2f66d760/680x482cq70/ayam-goreng-lengkuas-irit-gas-foto-resep-utama.jpg)

Sebagai seorang ibu, mempersiapkan olahan mantab buat keluarga tercinta merupakan hal yang sangat menyenangkan untuk kita sendiri. Peran seorang  wanita bukan hanya menangani rumah saja, tapi anda juga harus menyediakan kebutuhan gizi terpenuhi dan juga panganan yang disantap keluarga tercinta harus nikmat.

Di era  saat ini, kalian memang dapat membeli hidangan siap saji tanpa harus susah memasaknya lebih dulu. Namun ada juga mereka yang memang mau memberikan makanan yang terlezat untuk keluarganya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan orang tercinta. 

Tapi siapa sangka, ayam goreng yang bertabur kremesan ini terbuat dari parutan lengkuas yang dimasak sedemikian rupa sehingga memiliki citarasa gurih yang menggoda selera makan. Penggunaan lengkuas atau laos sangat berperan penting terhadap resep ayam goreng lengkuas yang akan. Ayam Goreng Lengkuas, resep klasik bagi mereka yang mencari selingan selain serundeng ataupun kremes.

Mungkinkah anda adalah seorang penikmat ayam goreng lengkuas (irit gas)?. Asal kamu tahu, ayam goreng lengkuas (irit gas) merupakan hidangan khas di Nusantara yang saat ini digemari oleh banyak orang dari hampir setiap tempat di Nusantara. Kalian dapat membuat ayam goreng lengkuas (irit gas) sendiri di rumah dan dapat dijadikan camilan favorit di hari liburmu.

Anda tidak usah bingung untuk menyantap ayam goreng lengkuas (irit gas), lantaran ayam goreng lengkuas (irit gas) gampang untuk didapatkan dan kita pun boleh menghidangkannya sendiri di tempatmu. ayam goreng lengkuas (irit gas) bisa diolah memalui beragam cara. Saat ini sudah banyak banget cara kekinian yang membuat ayam goreng lengkuas (irit gas) semakin lebih lezat.

Resep ayam goreng lengkuas (irit gas) pun sangat mudah dibikin, lho. Kita tidak perlu ribet-ribet untuk membeli ayam goreng lengkuas (irit gas), lantaran Kita dapat menghidangkan sendiri di rumah. Untuk Anda yang mau mencobanya, dibawah ini merupakan cara untuk menyajikan ayam goreng lengkuas (irit gas) yang lezat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam goreng lengkuas (irit gas):

1. Siapkan 1 ekor ayam
1. Siapkan 3 batang sereh, geprek atau iris
1. Ambil 3 lembar salam
1. Gunakan 1 sdt lada bubuk
1. Ambil 1 sdt garam
1. Sediakan 1,5 sdt gula pasir
1. Sediakan 400 ml air
1. Siapkan  Bumbu halus 1
1. Gunakan 7 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Gunakan 5 kemiri
1. Sediakan 1 sdt ketumbar
1. Gunakan 1 telunjuk kunyit
1. Sediakan 50 ml minyak goreng
1. Gunakan  Bumbu halus 2
1. Sediakan 150 gr lengkuas (pink), potong memanjang
1. Ambil 100 ml air


Ayam goreng memang menjadi salah satu menu hidangan favorit, baik bagi anak-anak maupun orang dewasa. Tidak heran, daging ayam yang kenyal dan nikmat itu memang paling enak disajikan saat masih panas-panas, apalagi kalau ada bumbu kremesannya yang menambah cita rasa. Contact Ayam Goreng Lengkuas on Messenger. Dg rasa syukur Ayam Goreng telah buka di Jl. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam goreng lengkuas (irit gas):

1. Panaskan wajan, tumis bumbu halus 1 hingga harum.
1. Masukkan salam dan sereh tumis harum.
1. Masukkan lengkuas, aduk rata
1. Masukkan ayam, air dan bumbu lainnya, aduk rata. Tutup panci, masak selama 5 menit. Matikan kompor 30 menit. Nyalakan kompor lagi selama 5 menit. Matikan kompor 30 menit. Setelah itu buka tutup panci.
1. Hilangkan uap panas,
1. Goreng ayam dan lengkuas dengan api agak besar. Sampai ayam dan lengkuas berwarna kecoklatan. Angkat dan sajikan
1. Tips menghaluskan dengan blender. - Haluskan ketumbar dan kemiri terlebih dahulu. Setelah halus, masukkan bahan lainnya dan blander kembali.


Terate Sooko Mojokerto Ruko lotus suouare. Salah satu Ikon kuliner Indonesia dari kota Bandung: Ayam Goreng Lengkuas. Sekilas mirip Ayam Goreng ditaburi serundeng dan serundeng ini berasal dari lengkuas yang diparut. Ternyata resep ayam goreng lengkuas tidak begitu sulit lho, Moms! Moms bisa membuatnya di rumah dengan bahan-bahan yang mudah ditemukan. 

Ternyata resep ayam goreng lengkuas (irit gas) yang enak simple ini mudah banget ya! Kita semua mampu memasaknya. Cara Membuat ayam goreng lengkuas (irit gas) Sangat sesuai banget buat kalian yang baru belajar memasak maupun bagi anda yang telah lihai dalam memasak.

Apakah kamu mau mencoba bikin resep ayam goreng lengkuas (irit gas) lezat tidak ribet ini? Kalau anda ingin, ayo kamu segera siapkan alat dan bahan-bahannya, lalu buat deh Resep ayam goreng lengkuas (irit gas) yang enak dan simple ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kita berfikir lama-lama, hayo kita langsung saja hidangkan resep ayam goreng lengkuas (irit gas) ini. Dijamin kalian tiidak akan menyesal membuat resep ayam goreng lengkuas (irit gas) enak sederhana ini! Selamat mencoba dengan resep ayam goreng lengkuas (irit gas) mantab sederhana ini di rumah sendiri,oke!.

