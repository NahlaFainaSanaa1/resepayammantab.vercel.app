---
description: "Bahan-bahan Koloke ayam saus asam manis yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Koloke ayam saus asam manis yang lezat dan Mudah Dibuat"
slug: 431-bahan-bahan-koloke-ayam-saus-asam-manis-yang-lezat-dan-mudah-dibuat
date: 2021-03-19T02:34:08.740Z
image: https://img-global.cpcdn.com/recipes/b53a82840f447fbf/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b53a82840f447fbf/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b53a82840f447fbf/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg
author: Tommy Soto
ratingvalue: 5
reviewcount: 14
recipeingredient:
- "300 gr ayam fillet"
- " Bumbu marinasi"
- "2 sdt bawang putih bubuk"
- "1/2 sdt lada halus"
- "Secukupnya garam"
- " Bahan kering"
- "100 gr tepung ayam krispi"
- "100 gr tepung terigu"
- "1/4 sdt baking powder"
- " Bahan basah"
- " Putih telur dr 1btr telur"
- " Ambil 1 sdm dari campuran bahan kering"
- "100 ml air es"
- " Bahan saus"
- "1 bh bawang bombay cincang kasar 12 utk ditumis"
- "1 bh wortelpotong korek api"
- "1/2 bonggol jagung"
- "2 bawang putih cincang halus"
- "1 sdm kecap inggris"
- "10 sdm saus tomat"
- "2 sdm saus sambal"
- "1/2 sdt lada halus"
- "1 sdt garam"
- "1 sdt gula pasir"
- "200 ml air"
- "1 sdm air jeruk nipis"
- " Cabeiris serong optional"
recipeinstructions:
- "Cuci ayam lalu potong2, tambahkan bumbu marinasi,diamkan 30 mnt di lemari es"
- "Buat bahan kering campur semua bahan, begitu juga bahan basah campur semua bahan aduk.rata"
- "Untuk menggoreng ayam, masukan ke dalam bahan kering kemudian celupkna ke bahan basah masukan kembali ke bahan kering aduk rata sambil.sedikit dicubit2"
- "Goreng ayam di minyak banyak yg sdh dipanaskan, goreng dgn apoi sedang sampai golden brown,tiriskan"
- "Membuat saus, tumis duo bawang sampai harum.lalu masukan cabe iris kemudian saus tomat.,saus sambal,air. Tambahkan bumbu2 lalu masukan wortel, jagung, air jeruk nipis &amp; sisa bawang bombay,tes rasa"
- "Penyajian, tata ayam di wadah lalu siram dengn saus"
categories:
- Resep
tags:
- koloke
- ayam
- saus

katakunci: koloke ayam saus 
nutrition: 261 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Lunch

---


![Koloke ayam saus asam manis](https://img-global.cpcdn.com/recipes/b53a82840f447fbf/680x482cq70/koloke-ayam-saus-asam-manis-foto-resep-utama.jpg)

Apabila kamu seorang yang hobi masak, mempersiapkan panganan menggugah selera untuk keluarga merupakan hal yang membahagiakan untuk anda sendiri. Kewajiban seorang ibu bukan saja mengerjakan pekerjaan rumah saja, tapi anda pun wajib memastikan keperluan nutrisi terpenuhi dan juga panganan yang dimakan anak-anak mesti nikmat.

Di era  saat ini, kita sebenarnya dapat mengorder hidangan yang sudah jadi meski tanpa harus capek mengolahnya dulu. Namun ada juga orang yang selalu mau memberikan makanan yang terenak bagi orang tercintanya. Sebab, menyajikan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan selera keluarga. 

Kalau di telusuri konon resep ayam koloke saus asam manis punya julukan ayam kuluyuk berasal dari orang cina yang ingin menyebutkan kruyuk-kruyuk ketika perut lapar. Yuk langsung saja di simak Bahan-bahan dan Cara Membuat Resep Ayam Koloke Saus Asam Manis seperti berikut ini. Resep Membuat Koloke Ayam Chinese Food.

Mungkinkah kamu seorang penyuka koloke ayam saus asam manis?. Asal kamu tahu, koloke ayam saus asam manis adalah sajian khas di Nusantara yang kini disukai oleh setiap orang dari hampir setiap tempat di Nusantara. Anda bisa memasak koloke ayam saus asam manis kreasi sendiri di rumah dan pasti jadi makanan kegemaranmu di hari libur.

Kita tidak usah bingung jika kamu ingin mendapatkan koloke ayam saus asam manis, sebab koloke ayam saus asam manis tidak sulit untuk didapatkan dan juga kamu pun boleh membuatnya sendiri di rumah. koloke ayam saus asam manis boleh dimasak lewat bermacam cara. Sekarang telah banyak sekali cara kekinian yang membuat koloke ayam saus asam manis lebih lezat.

Resep koloke ayam saus asam manis pun gampang dibuat, lho. Kita tidak usah repot-repot untuk membeli koloke ayam saus asam manis, tetapi Kita mampu menyajikan sendiri di rumah. Bagi Kamu yang hendak menyajikannya, di bawah ini adalah cara untuk membuat koloke ayam saus asam manis yang mantab yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Koloke ayam saus asam manis:

1. Ambil 300 gr ayam fillet
1. Siapkan  Bumbu marinasi:
1. Sediakan 2 sdt bawang putih bubuk
1. Sediakan 1/2 sdt lada halus
1. Sediakan Secukupnya garam
1. Ambil  Bahan kering:
1. Gunakan 100 gr tepung ayam krispi
1. Gunakan 100 gr tepung terigu
1. Sediakan 1/4 sdt baking powder
1. Ambil  Bahan basah:
1. Sediakan  Putih telur dr 1btr telur
1. Sediakan  Ambil 1 sdm dari campuran bahan kering
1. Sediakan 100 ml air es
1. Siapkan  Bahan saus:
1. Siapkan 1 bh bawang bombay, cincang kasar 1/2 utk ditumis
1. Sediakan 1 bh wortel,potong korek api
1. Ambil 1/2 bonggol jagung
1. Ambil 2 bawang putih, cincang halus
1. Gunakan 1 sdm kecap inggris
1. Gunakan 10 sdm saus tomat
1. Gunakan 2 sdm saus sambal
1. Sediakan 1/2 sdt lada halus
1. Sediakan 1 sdt garam
1. Siapkan 1 sdt gula pasir
1. Siapkan 200 ml air
1. Ambil 1 sdm air jeruk nipis
1. Ambil  Cabe,iris serong (optional)


Umumnya saus asam manis tersebut berisi potongan bawang bombay, wortel, brokoli dan juga buah nanas. Oh iya, walaupun ayam kuluyuk enak di sajikan bersama saus asam manisnya. KOLOKE AYAM MASAK DARI RUMAH, AYAM GORENG TEPUNG SAOS ASAM MANIsПодробнее. CARA MASAK KOLOKE / AYAM ASAM MANIS MUDAH DAN ENAK!!!Подробнее. 

<!--inarticleads2-->

##### Cara membuat Koloke ayam saus asam manis:

1. Cuci ayam lalu potong2, tambahkan bumbu marinasi,diamkan 30 mnt di lemari es
1. Buat bahan kering campur semua bahan, begitu juga bahan basah campur semua bahan aduk.rata
1. Untuk menggoreng ayam, masukan ke dalam bahan kering kemudian celupkna ke bahan basah masukan kembali ke bahan kering aduk rata sambil.sedikit dicubit2
1. Goreng ayam di minyak banyak yg sdh dipanaskan, goreng dgn apoi sedang sampai golden brown,tiriskan
1. Membuat saus, tumis duo bawang sampai harum.lalu masukan cabe iris kemudian saus tomat.,saus sambal,air. Tambahkan bumbu2 lalu masukan wortel, jagung, air jeruk nipis &amp; sisa bawang bombay,tes rasa
1. Penyajian, tata ayam di wadah lalu siram dengn saus


Saus asam manis juga digunakan pada masakan ayam, daging sapi, atau daging babi yang digoreng tidak sampai garing, ditambah sayur-sayuran seperti bawang bombay, nanas, paprika, kol dan tomat. Saus asam manis siap pakai dan serba guna untuk berbagai masakan juga dijual dalam kemasan. Koloke merupakan makanan khas oriental berbahan dasar ayam filet. Koloke memang tidak setenar fuyunghai dan capcay. Setelah dilumuri tepung dan digoreng, ayam disiram dengan saus asam manis. 

Ternyata resep koloke ayam saus asam manis yang enak tidak rumit ini enteng banget ya! Kamu semua bisa mencobanya. Resep koloke ayam saus asam manis Sangat sesuai banget untuk kalian yang baru akan belajar memasak ataupun untuk kalian yang sudah hebat memasak.

Apakah kamu tertarik mulai mencoba membuat resep koloke ayam saus asam manis enak tidak ribet ini? Kalau kamu tertarik, mending kamu segera menyiapkan peralatan dan bahannya, lalu bikin deh Resep koloke ayam saus asam manis yang nikmat dan sederhana ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kalian diam saja, hayo kita langsung saja hidangkan resep koloke ayam saus asam manis ini. Dijamin anda tak akan menyesal sudah buat resep koloke ayam saus asam manis mantab sederhana ini! Selamat berkreasi dengan resep koloke ayam saus asam manis enak simple ini di rumah sendiri,oke!.

