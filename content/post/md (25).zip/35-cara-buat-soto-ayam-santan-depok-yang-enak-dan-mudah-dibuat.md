---
description: "Cara buat Soto Ayam Santan Depok yang enak dan Mudah Dibuat"
title: "Cara buat Soto Ayam Santan Depok yang enak dan Mudah Dibuat"
slug: 35-cara-buat-soto-ayam-santan-depok-yang-enak-dan-mudah-dibuat
date: 2021-07-05T03:32:46.976Z
image: https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg
author: Kevin Wood
ratingvalue: 4
reviewcount: 8
recipeingredient:
- "300 gr ayam filet"
- "300 gr kentang"
- "1 buah Belimbing Dewa manis"
- "800 ml air matang"
- "200 ml santan kental  instan"
- "  bumbu halus"
- "7 buah bawang merah"
- "5 siung bawang putih"
- "1 sdt ketumbar"
- "1/2 sdt jinten"
- "2 cm kencur"
- "  bumbu cemplung"
- "2 batang sere geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "2 cm lengkuas"
- "1 sdm peres garam"
- "  pelengkap"
- " Bawang merah goreng"
- " Sambel dari cabe rawit"
- " Emping"
- " Daun bawang"
recipeinstructions:
- "Siapkan bahan. Blender bumbu halus. Potong ayam dan kentang."
- "Tumis bumbu cemplung hingga harum. Kemudian masukan bumbu halus tumis hingga matang.           (lihat tips)"
- "Masukkan ayam aduk hingga ayam berubah warna."
- "Masukkan kentang, air dan garam."
- "Bila kentang sudah empuk maka masukkan santan. Setelah mendidih masukkan belimbing. Tes rasa dan tunggu mendidih matikan kompor."
- "Soto Ayam Santan Depok siap disajikan."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 141 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![Soto Ayam Santan Depok](https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan masakan enak bagi famili adalah hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang  wanita Tidak hanya mengurus rumah saja, tapi anda pun wajib memastikan kebutuhan gizi tercukupi dan juga masakan yang dikonsumsi orang tercinta harus menggugah selera.

Di zaman  sekarang, kita memang mampu membeli santapan yang sudah jadi meski tidak harus repot memasaknya lebih dulu. Tetapi ada juga lho mereka yang selalu mau menyajikan yang terenak bagi orang tercintanya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan kesukaan famili. 



Mungkinkah anda seorang penggemar soto ayam santan depok?. Asal kamu tahu, soto ayam santan depok adalah hidangan khas di Indonesia yang kini disenangi oleh banyak orang dari hampir setiap daerah di Indonesia. Anda dapat memasak soto ayam santan depok olahan sendiri di rumah dan boleh dijadikan camilan favoritmu di akhir pekanmu.

Kalian tidak perlu bingung jika kamu ingin mendapatkan soto ayam santan depok, sebab soto ayam santan depok mudah untuk didapatkan dan juga kalian pun dapat mengolahnya sendiri di rumah. soto ayam santan depok dapat diolah memalui beraneka cara. Sekarang sudah banyak cara modern yang membuat soto ayam santan depok lebih mantap.

Resep soto ayam santan depok juga gampang dibikin, lho. Anda tidak perlu ribet-ribet untuk memesan soto ayam santan depok, lantaran Kamu bisa menyiapkan sendiri di rumah. Bagi Anda yang hendak membuatnya, berikut resep untuk membuat soto ayam santan depok yang enak yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Soto Ayam Santan Depok:

1. Sediakan 300 gr ayam filet
1. Ambil 300 gr kentang
1. Gunakan 1 buah Belimbing Dewa (manis)
1. Sediakan 800 ml air matang
1. Gunakan 200 ml santan kental / instan
1. Gunakan  🧄🧄 bumbu halus
1. Siapkan 7 buah bawang merah
1. Siapkan 5 siung bawang putih
1. Sediakan 1 sdt ketumbar
1. Ambil 1/2 sdt jinten
1. Gunakan 2 cm kencur
1. Gunakan  🧄🧄 bumbu cemplung
1. Gunakan 2 batang sere geprek
1. Sediakan 2 lembar daun salam
1. Gunakan 2 lembar daun jeruk
1. Sediakan 2 cm lengkuas
1. Siapkan 1 sdm peres garam
1. Ambil  🧄🧄 pelengkap
1. Ambil  Bawang merah goreng
1. Sediakan  Sambel dari cabe rawit
1. Ambil  Emping
1. Ambil  Daun bawang




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Santan Depok:

1. Siapkan bahan. Blender bumbu halus. Potong ayam dan kentang.
1. Tumis bumbu cemplung hingga harum. Kemudian masukan bumbu halus tumis hingga matang. -           (lihat tips)
1. Masukkan ayam aduk hingga ayam berubah warna.
1. Masukkan kentang, air dan garam.
1. Bila kentang sudah empuk maka masukkan santan. Setelah mendidih masukkan belimbing. - Tes rasa dan tunggu mendidih matikan kompor.
1. Soto Ayam Santan Depok siap disajikan.




Wah ternyata resep soto ayam santan depok yang nikamt simple ini enteng sekali ya! Kamu semua bisa menghidangkannya. Cara buat soto ayam santan depok Sangat sesuai banget buat anda yang sedang belajar memasak ataupun juga bagi kamu yang sudah ahli memasak.

Apakah kamu mau mulai mencoba membuat resep soto ayam santan depok mantab tidak ribet ini? Kalau ingin, mending kamu segera buruan menyiapkan peralatan dan bahan-bahannya, maka bikin deh Resep soto ayam santan depok yang lezat dan tidak ribet ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kalian berfikir lama-lama, ayo langsung aja hidangkan resep soto ayam santan depok ini. Dijamin anda tiidak akan menyesal bikin resep soto ayam santan depok enak sederhana ini! Selamat berkreasi dengan resep soto ayam santan depok mantab sederhana ini di tempat tinggal masing-masing,oke!.

