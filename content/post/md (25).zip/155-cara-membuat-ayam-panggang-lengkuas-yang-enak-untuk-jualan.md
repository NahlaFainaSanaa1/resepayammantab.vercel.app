---
description: "Cara membuat Ayam Panggang Lengkuas yang enak Untuk Jualan"
title: "Cara membuat Ayam Panggang Lengkuas yang enak Untuk Jualan"
slug: 155-cara-membuat-ayam-panggang-lengkuas-yang-enak-untuk-jualan
date: 2021-02-22T07:32:45.702Z
image: https://img-global.cpcdn.com/recipes/c4d95111dbfb4b11/680x482cq70/ayam-panggang-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c4d95111dbfb4b11/680x482cq70/ayam-panggang-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c4d95111dbfb4b11/680x482cq70/ayam-panggang-lengkuas-foto-resep-utama.jpg
author: Randy Colon
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- "380 gr ayam"
- "150 ml air"
- "2,5 sdt garam"
- "10 gr gula merah"
- " Bumbu Cemplung"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang serai geprek"
- " Bumbu Halus"
- "75 gr lengkuas"
- "1,5 cm kunyit"
- "1 cm jahe"
- "3 siung bawang putih"
- "1 sdt ketumbar"
- "1/4 sdt merica butiran"
- "2 buah kemiri"
- "8 sdm air"
recipeinstructions:
- "Rebus ayam hingga mendidih, tiriskan. Sangrai bumbu halus hingga harum."
- "Tuang air lalu bumbui, kemudian masukkan ayam dan bumbu cemplung masak hingga air menyusut."
- "Saring kemudian letakkan di loyang. Panaskan oven selama 15 menit dengan api besar lalu oven ayam selama 60 menit dengan api sedang. Matikan kompor dan sajikan 🤤"
categories:
- Resep
tags:
- ayam
- panggang
- lengkuas

katakunci: ayam panggang lengkuas 
nutrition: 109 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Panggang Lengkuas](https://img-global.cpcdn.com/recipes/c4d95111dbfb4b11/680x482cq70/ayam-panggang-lengkuas-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan olahan lezat kepada keluarga tercinta adalah hal yang membahagiakan untuk anda sendiri. Kewajiban seorang ibu Tidak sekedar menangani rumah saja, tetapi kamu pun wajib menyediakan keperluan gizi terpenuhi dan panganan yang dikonsumsi anak-anak mesti sedap.

Di era  saat ini, anda sebenarnya bisa mengorder masakan praktis meski tidak harus susah mengolahnya dahulu. Namun ada juga lho mereka yang selalu mau memberikan hidangan yang terbaik untuk keluarganya. Lantaran, menyajikan masakan yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan orang tercinta. 



Mungkinkah kamu salah satu penikmat ayam panggang lengkuas?. Asal kamu tahu, ayam panggang lengkuas adalah makanan khas di Indonesia yang saat ini digemari oleh orang-orang dari berbagai wilayah di Indonesia. Kamu dapat menghidangkan ayam panggang lengkuas hasil sendiri di rumah dan boleh jadi santapan kesenanganmu di hari liburmu.

Anda tak perlu bingung untuk menyantap ayam panggang lengkuas, karena ayam panggang lengkuas mudah untuk ditemukan dan juga kamu pun boleh membuatnya sendiri di rumah. ayam panggang lengkuas boleh dimasak lewat beragam cara. Kini ada banyak resep kekinian yang membuat ayam panggang lengkuas lebih nikmat.

Resep ayam panggang lengkuas juga sangat gampang untuk dibuat, lho. Kamu jangan repot-repot untuk memesan ayam panggang lengkuas, karena Kalian mampu menyiapkan sendiri di rumah. Untuk Kita yang mau membuatnya, dibawah ini merupakan cara membuat ayam panggang lengkuas yang nikamat yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Panggang Lengkuas:

1. Sediakan 380 gr ayam
1. Sediakan 150 ml air
1. Ambil 2,5 sdt garam
1. Ambil 10 gr gula merah
1. Siapkan  Bumbu Cemplung
1. Ambil 2 lembar daun jeruk
1. Gunakan 2 lembar daun salam
1. Siapkan 1 batang serai (geprek)
1. Ambil  Bumbu Halus
1. Siapkan 75 gr lengkuas
1. Gunakan 1,5 cm kunyit
1. Gunakan 1 cm jahe
1. Sediakan 3 siung bawang putih
1. Siapkan 1 sdt ketumbar
1. Gunakan 1/4 sdt merica butiran
1. Siapkan 2 buah kemiri
1. Gunakan 8 sdm air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Panggang Lengkuas:

1. Rebus ayam hingga mendidih, tiriskan. Sangrai bumbu halus hingga harum.
1. Tuang air lalu bumbui, kemudian masukkan ayam dan bumbu cemplung masak hingga air menyusut.
1. Saring kemudian letakkan di loyang. Panaskan oven selama 15 menit dengan api besar lalu oven ayam selama 60 menit dengan api sedang. Matikan kompor dan sajikan 🤤




Ternyata cara membuat ayam panggang lengkuas yang enak simple ini enteng banget ya! Kita semua mampu memasaknya. Cara buat ayam panggang lengkuas Sangat sesuai banget untuk kita yang baru belajar memasak ataupun untuk kalian yang sudah lihai dalam memasak.

Tertarik untuk mencoba bikin resep ayam panggang lengkuas enak simple ini? Kalau kamu tertarik, ayo kalian segera siapin peralatan dan bahannya, lalu buat deh Resep ayam panggang lengkuas yang nikmat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Maka, ketimbang anda diam saja, hayo kita langsung saja hidangkan resep ayam panggang lengkuas ini. Pasti kalian gak akan menyesal bikin resep ayam panggang lengkuas lezat sederhana ini! Selamat berkreasi dengan resep ayam panggang lengkuas lezat tidak rumit ini di rumah sendiri,ya!.

