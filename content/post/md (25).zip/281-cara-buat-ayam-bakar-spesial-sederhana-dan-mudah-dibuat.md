---
description: "Cara buat Ayam bakar spesial Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam bakar spesial Sederhana dan Mudah Dibuat"
slug: 281-cara-buat-ayam-bakar-spesial-sederhana-dan-mudah-dibuat
date: 2021-05-18T13:36:19.912Z
image: https://img-global.cpcdn.com/recipes/e7e3e2e70f3f1e1b/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e7e3e2e70f3f1e1b/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e7e3e2e70f3f1e1b/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg
author: Marc Singleton
ratingvalue: 4
reviewcount: 5
recipeingredient:
- "3 ekor Ayam kampung"
- " Bumbu halus"
- "15 sg bawang merah"
- "10 sg bawang putih"
- "10 cm kunyit"
- "10 cm jahe"
- "10 butir kemiri"
- "1 sdt ladaku"
- "2 sdm ketumbar bubuk"
- " Bumbu tambahan"
- "3 btg serai geprek"
- "10 cm lengkuas geprek"
- "5 lbr daun salam"
- "100 gr gula merah"
- "3 sdm air asam jawakental"
- " Kecap manis"
- "2 sdm margarin"
- " Minyak utk menumis"
- "5 sdm minyak wijen"
- "3 sdm saos raja rasa"
recipeinstructions:
- "Ayam kampung di potong jadi 5 bagian,cuci bersih,lumuri jeruk nipis,diamkan sejenak,lalu cuci bersih dan tiriskan"
- "Panaskan wajan,masukkan margarin dan minyak,setelah panas tuangkan bumbu halus,aduk smpai wangi"
- "Masukkan daun salam,serai, lengkuas,aduk lg,biarkan beberapa saat,sampai kluar minyaknya"
- "Masukkan gula merah,air asam, kecap,minyak wijen,saos raja rasa,garam dan penyedap rasa,aduk sebentar"
- "Masukkan ayam,aduk sampai bumbu rata,beri sedkit air,lalu tutup, sambil sesekali d aduk biarkan smpai ayam matang,Angkat dan tiriskan.."
- "Panaskan pembakaran,bisa dgn memakai arang,atau pun alat panggang lain,d oven jg bs"
- "Bakar ayam sambil sesekali d olesi sisa bumbunya,bolak balik sampai matang merata,angkat  sajikan brsama,lalapan dan sambalnya #yank  #cookingstories"
categories:
- Resep
tags:
- ayam
- bakar
- spesial

katakunci: ayam bakar spesial 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam bakar spesial](https://img-global.cpcdn.com/recipes/e7e3e2e70f3f1e1b/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg)

Andai kalian seorang istri, mempersiapkan masakan nikmat bagi orang tercinta merupakan hal yang mengasyikan bagi anda sendiri. Peran seorang istri bukan saja mengatur rumah saja, namun anda juga harus memastikan keperluan nutrisi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta mesti mantab.

Di zaman  saat ini, kamu sebenarnya dapat mengorder santapan yang sudah jadi walaupun tanpa harus susah mengolahnya terlebih dahulu. Tetapi ada juga lho mereka yang selalu ingin memberikan hidangan yang terenak bagi orang tercintanya. Pasalnya, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan famili. 



Apakah kamu salah satu penyuka ayam bakar spesial?. Tahukah kamu, ayam bakar spesial merupakan sajian khas di Nusantara yang kini digemari oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Kamu bisa memasak ayam bakar spesial sendiri di rumah dan boleh dijadikan camilan kegemaranmu di akhir pekanmu.

Kamu tidak perlu bingung jika kamu ingin menyantap ayam bakar spesial, karena ayam bakar spesial gampang untuk ditemukan dan kamu pun boleh membuatnya sendiri di tempatmu. ayam bakar spesial bisa dibuat dengan berbagai cara. Kini sudah banyak banget resep kekinian yang membuat ayam bakar spesial semakin lebih mantap.

Resep ayam bakar spesial pun sangat mudah untuk dibikin, lho. Anda tidak perlu ribet-ribet untuk membeli ayam bakar spesial, tetapi Kita bisa membuatnya sendiri di rumah. Untuk Anda yang ingin menyajikannya, berikut resep untuk membuat ayam bakar spesial yang enak yang bisa Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam bakar spesial:

1. Siapkan 3 ekor Ayam kampung
1. Siapkan  Bumbu halus:
1. Siapkan 15 sg bawang merah
1. Gunakan 10 sg bawang putih
1. Sediakan 10 cm kunyit
1. Sediakan 10 cm jahe
1. Sediakan 10 butir kemiri
1. Siapkan 1 sdt ladaku
1. Sediakan 2 sdm ketumbar bubuk
1. Siapkan  Bumbu tambahan:
1. Gunakan 3 btg serai geprek
1. Gunakan 10 cm lengkuas geprek
1. Ambil 5 lbr daun salam
1. Siapkan 100 gr gula merah
1. Siapkan 3 sdm air asam jawa(kental)
1. Sediakan  Kecap manis
1. Sediakan 2 sdm margarin
1. Sediakan  Minyak utk menumis
1. Sediakan 5 sdm minyak wijen
1. Sediakan 3 sdm saos raja rasa




<!--inarticleads2-->

##### Cara membuat Ayam bakar spesial:

1. Ayam kampung di potong jadi 5 bagian,cuci bersih,lumuri jeruk nipis,diamkan sejenak,lalu cuci bersih dan tiriskan
1. Panaskan wajan,masukkan margarin dan minyak,setelah panas tuangkan bumbu halus,aduk smpai wangi
1. Masukkan daun salam,serai, lengkuas,aduk lg,biarkan beberapa saat,sampai kluar minyaknya
1. Masukkan gula merah,air asam, kecap,minyak wijen,saos raja rasa,garam dan penyedap rasa,aduk sebentar
1. Masukkan ayam,aduk sampai bumbu rata,beri sedkit air,lalu tutup, sambil sesekali d aduk biarkan smpai ayam matang,Angkat dan tiriskan..
1. Panaskan pembakaran,bisa dgn memakai arang,atau pun alat panggang lain,d oven jg bs
1. Bakar ayam sambil sesekali d olesi sisa bumbunya,bolak balik sampai matang merata,angkat  - sajikan brsama,lalapan dan sambalnya - #yank  - #cookingstories




Wah ternyata cara buat ayam bakar spesial yang lezat tidak ribet ini mudah banget ya! Semua orang bisa mencobanya. Cara buat ayam bakar spesial Sangat cocok sekali buat kamu yang sedang belajar memasak ataupun bagi kamu yang telah hebat memasak.

Apakah kamu mau mulai mencoba buat resep ayam bakar spesial enak tidak ribet ini? Kalau anda tertarik, ayo kamu segera buruan siapin alat dan bahannya, lantas buat deh Resep ayam bakar spesial yang mantab dan sederhana ini. Sangat taidak sulit kan. 

Jadi, daripada anda diam saja, ayo kita langsung sajikan resep ayam bakar spesial ini. Pasti kalian tiidak akan menyesal sudah membuat resep ayam bakar spesial enak simple ini! Selamat mencoba dengan resep ayam bakar spesial lezat tidak rumit ini di rumah kalian masing-masing,oke!.

