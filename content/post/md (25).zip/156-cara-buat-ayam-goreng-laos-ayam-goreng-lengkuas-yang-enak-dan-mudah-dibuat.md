---
description: "Cara buat Ayam Goreng Laos / Ayam Goreng Lengkuas yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Goreng Laos / Ayam Goreng Lengkuas yang enak dan Mudah Dibuat"
slug: 156-cara-buat-ayam-goreng-laos-ayam-goreng-lengkuas-yang-enak-dan-mudah-dibuat
date: 2021-04-06T08:03:34.591Z
image: https://img-global.cpcdn.com/recipes/37c1ff4af4d963c5/680x482cq70/ayam-goreng-laos-ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/37c1ff4af4d963c5/680x482cq70/ayam-goreng-laos-ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/37c1ff4af4d963c5/680x482cq70/ayam-goreng-laos-ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Mamie Shaw
ratingvalue: 5
reviewcount: 11
recipeingredient:
- "1 kg ayam saya pakai pejantan"
- "1 buah lengkuas besar"
- "3 buah kemiri"
- "5 butir bawang merah"
- "5 butir bawang putih"
- "1 ruas kunyit"
- "secukupnya garam"
- "1 batang sereh"
- "2 lembar daun salam"
- "1000 ml air matang"
recipeinstructions:
- "Cuci ayam &amp; semua bahan hingga bersih. Parut lengkuas hingga habis"
- "Haluskan bawang merah, bawang putih, kemiri, kunyit, garam"
- "Tumis hingga wangi bahan yg sudah di haluskan, Lalu masukan daun salam, sereh, dan parutan lengkuas"
- "Masukan ayam dan air matang, lalu ungkeb hingga matang dan air surut"
- "Setelah ayam matang didalam wajan panaskan minyak goreng dan goreng ayam hingga kuning keemasan"
categories:
- Resep
tags:
- ayam
- goreng
- laos

katakunci: ayam goreng laos 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Laos / Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/37c1ff4af4d963c5/680x482cq70/ayam-goreng-laos-ayam-goreng-lengkuas-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan hidangan nikmat untuk keluarga adalah hal yang memuaskan untuk anda sendiri. Peran seorang  wanita bukan hanya menangani rumah saja, namun kamu juga wajib memastikan keperluan gizi terpenuhi dan juga olahan yang dimakan keluarga tercinta harus enak.

Di waktu  sekarang, kalian sebenarnya mampu membeli hidangan yang sudah jadi tidak harus susah memasaknya lebih dulu. Tetapi banyak juga lho orang yang memang mau memberikan yang terlezat bagi keluarganya. Karena, memasak yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai kesukaan orang tercinta. 



Mungkinkah kamu salah satu penggemar ayam goreng laos / ayam goreng lengkuas?. Tahukah kamu, ayam goreng laos / ayam goreng lengkuas adalah hidangan khas di Nusantara yang kini disukai oleh kebanyakan orang dari berbagai daerah di Nusantara. Anda bisa memasak ayam goreng laos / ayam goreng lengkuas sendiri di rumah dan boleh dijadikan santapan kesenanganmu di hari liburmu.

Anda tidak usah bingung jika kamu ingin menyantap ayam goreng laos / ayam goreng lengkuas, lantaran ayam goreng laos / ayam goreng lengkuas mudah untuk ditemukan dan kalian pun dapat membuatnya sendiri di rumah. ayam goreng laos / ayam goreng lengkuas dapat diolah memalui bermacam cara. Kini pun sudah banyak sekali cara kekinian yang menjadikan ayam goreng laos / ayam goreng lengkuas semakin lezat.

Resep ayam goreng laos / ayam goreng lengkuas pun sangat gampang untuk dibuat, lho. Kita tidak usah ribet-ribet untuk membeli ayam goreng laos / ayam goreng lengkuas, karena Anda bisa membuatnya di rumahmu. Bagi Anda yang hendak mencobanya, dibawah ini merupakan cara membuat ayam goreng laos / ayam goreng lengkuas yang enak yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Goreng Laos / Ayam Goreng Lengkuas:

1. Ambil 1 kg ayam (saya pakai pejantan)
1. Siapkan 1 buah lengkuas besar
1. Sediakan 3 buah kemiri
1. Gunakan 5 butir bawang merah
1. Sediakan 5 butir bawang putih
1. Siapkan 1 ruas kunyit
1. Gunakan secukupnya garam
1. Siapkan 1 batang sereh
1. Ambil 2 lembar daun salam
1. Sediakan 1000 ml air matang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Goreng Laos / Ayam Goreng Lengkuas:

1. Cuci ayam &amp; semua bahan hingga bersih. - Parut lengkuas hingga habis
1. Haluskan bawang merah, bawang putih, kemiri, kunyit, garam
1. Tumis hingga wangi bahan yg sudah di haluskan, Lalu masukan daun salam, sereh, dan parutan lengkuas
1. Masukan ayam dan air matang, lalu ungkeb hingga matang dan air surut
1. Setelah ayam matang - didalam wajan panaskan minyak goreng dan goreng ayam hingga kuning keemasan




Wah ternyata resep ayam goreng laos / ayam goreng lengkuas yang nikamt simple ini mudah sekali ya! Anda Semua dapat membuatnya. Cara buat ayam goreng laos / ayam goreng lengkuas Sangat cocok sekali buat anda yang sedang belajar memasak ataupun untuk kamu yang sudah pandai dalam memasak.

Apakah kamu ingin mencoba bikin resep ayam goreng laos / ayam goreng lengkuas enak simple ini? Kalau kalian mau, mending kamu segera menyiapkan alat dan bahannya, lalu buat deh Resep ayam goreng laos / ayam goreng lengkuas yang enak dan tidak rumit ini. Sungguh taidak sulit kan. 

Maka, daripada anda berlama-lama, ayo langsung aja sajikan resep ayam goreng laos / ayam goreng lengkuas ini. Dijamin kalian tiidak akan nyesel sudah buat resep ayam goreng laos / ayam goreng lengkuas enak tidak ribet ini! Selamat berkreasi dengan resep ayam goreng laos / ayam goreng lengkuas lezat tidak rumit ini di rumah kalian sendiri,ya!.

