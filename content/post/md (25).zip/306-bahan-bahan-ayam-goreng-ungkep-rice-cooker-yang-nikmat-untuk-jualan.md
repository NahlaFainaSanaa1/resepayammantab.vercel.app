---
description: "Bahan-bahan Ayam Goreng Ungkep - Rice Cooker yang nikmat Untuk Jualan"
title: "Bahan-bahan Ayam Goreng Ungkep - Rice Cooker yang nikmat Untuk Jualan"
slug: 306-bahan-bahan-ayam-goreng-ungkep-rice-cooker-yang-nikmat-untuk-jualan
date: 2021-02-03T08:11:58.155Z
image: https://img-global.cpcdn.com/recipes/5dde09c37197e40d/680x482cq70/ayam-goreng-ungkep-rice-cooker-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5dde09c37197e40d/680x482cq70/ayam-goreng-ungkep-rice-cooker-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5dde09c37197e40d/680x482cq70/ayam-goreng-ungkep-rice-cooker-foto-resep-utama.jpg
author: Randall Yates
ratingvalue: 3.3
reviewcount: 11
recipeingredient:
- "1/2 kg daging ayam potong sesuai selera"
- "1 kotak tempe  tahu optional"
- "3 lembar daun salam"
- "1 buah jeruk lemonnipis"
- " gula pasir secukupnya"
- " lada putih bubuk secukupnya"
- " garam secukupnya"
- " minyak goreng secukupnya"
- " air putih secukupnya kurang lebih 200 ml"
- " Bumbu halus"
- "6 siung bawang putih"
- "7 siung bawang merah"
- "2 sdt ketumbar"
- "3 ruas jempol kunyit"
- "3 butir kemiri"
- "1 ruas jempol jahe"
- "2 ruas jempol lengkuas"
- " Note  apabila kalian tidak mau ribet kalian bisa membeli bumbu halus yang sudah jadi atau telah digiling di pasar terdekat"
recipeinstructions:
- "Siapkan semua bahan serta alat masak yang diperlukan."
- "Bersihkan ayam serta potong daging yang besarannya sesuai selera."
- "Masukan perasan air jeruk lemon/nipis dan tambahkan sedikit garam ke dalam daging ayam yang telah dibersihkan. Step ini bertujuan untuk menghilangkan bau amis yang terdapat pada daging ayam."
- "Diamkan ayam pada rendaman air jeruk lemon/nipis selama kurang lebih 5 menit."
- "Campurkan semua bahan-bahan bumbu halus dan haluskan menggunakan ulekan atau blender."
- "Panaskan rice cooker (mode: cook) serta masukan sedikit minyak goreng untuk menumis bumbu halus."
- "Apabila minyak goreng sudah mulai panas, (biasanya mode rice cooker berubah menjadi warm) masukan bumbu halus dan daun salam kedalamnya dan pindahkan mode rice cooker menjadi cook."
- "Tumis bambu halus sampai mengeluarkan aroma wangi dan jangan sampai gosong ya."
- "Masukkan daging ayam ke dalam rice cooker, aduk dan diamkan selama 5 menit. Pada tahapan ini mode rice cooker akan berubah menjadi warm, oleh karenanya pindahkan mode tersebut hingga menjadi cook."
- "Tuangkan air putih ke dalam rice cooker hingga seluruh permukaan ayam terendam air, tambahkan bumbu seperti garam, lada putih dan gula sesuai dengan selera (biasanya masakan saya lebih dominan asin agar pada saat dimakan dengan nasi tetap mengeluarkan cita rasa gurih) dan koreksi rasa. Pada tahapan ini masukkan pula tahu/tempe ke dalamnya."
- "Ungkep / masak ayam beserta tahu atau tempe di dalam rice cooker hingga air ungkepan menjadi surut. Proses ini memakan waktu 45 menit dan apabila mode rice cooker berubah menjadi &#34;warm&#34;, maka perlu diubah kembali untuk menjadi mode &#34;cook&#34;. Jangan lupa sesekali diaduk ya, agar ayam beserta tahu/tempe tidak menjadi gosong pada saat proses pengungkepan."
- "Apabila air ungkepan telah habis, matikan rice cooker dan pindahkan ayam beserta tahu atau tempe ke wadah penyimpanan."
- "Ayam ungkep beserta tahu/tempe siap digoreng dan dihidangkan."
categories:
- Resep
tags:
- ayam
- goreng
- ungkep

katakunci: ayam goreng ungkep 
nutrition: 279 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Ungkep - Rice Cooker](https://img-global.cpcdn.com/recipes/5dde09c37197e40d/680x482cq70/ayam-goreng-ungkep-rice-cooker-foto-resep-utama.jpg)

Selaku seorang ibu, menyuguhkan masakan menggugah selera kepada keluarga merupakan hal yang mengasyikan untuk anda sendiri. Tanggung jawab seorang ibu bukan saja mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib menyediakan kebutuhan nutrisi terpenuhi dan masakan yang dikonsumsi orang tercinta wajib enak.

Di era  saat ini, kita sebenarnya mampu mengorder santapan jadi tidak harus ribet membuatnya dahulu. Tapi ada juga mereka yang memang ingin menyajikan yang terenak untuk orang tercintanya. Lantaran, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut berdasarkan selera keluarga. 



Apakah anda seorang penyuka ayam goreng ungkep - rice cooker?. Tahukah kamu, ayam goreng ungkep - rice cooker adalah sajian khas di Indonesia yang saat ini disenangi oleh setiap orang di berbagai wilayah di Indonesia. Kita bisa menghidangkan ayam goreng ungkep - rice cooker olahan sendiri di rumah dan pasti jadi hidangan favorit di hari libur.

Kita tidak perlu bingung untuk memakan ayam goreng ungkep - rice cooker, karena ayam goreng ungkep - rice cooker tidak sulit untuk didapatkan dan juga kamu pun dapat menghidangkannya sendiri di rumah. ayam goreng ungkep - rice cooker boleh dimasak memalui beragam cara. Kini pun ada banyak banget resep modern yang membuat ayam goreng ungkep - rice cooker semakin lebih enak.

Resep ayam goreng ungkep - rice cooker juga gampang sekali dibikin, lho. Kamu tidak perlu ribet-ribet untuk membeli ayam goreng ungkep - rice cooker, karena Kamu bisa membuatnya sendiri di rumah. Bagi Kalian yang akan menghidangkannya, berikut cara membuat ayam goreng ungkep - rice cooker yang lezat yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Goreng Ungkep - Rice Cooker:

1. Ambil 1/2 kg daging ayam (potong sesuai selera)
1. Sediakan 1 kotak tempe / tahu (optional)
1. Siapkan 3 lembar daun salam
1. Siapkan 1 buah jeruk lemon/nipis
1. Siapkan  gula pasir (secukupnya)
1. Siapkan  lada putih bubuk (secukupnya)
1. Ambil  garam (secukupnya)
1. Sediakan  minyak goreng (secukupnya)
1. Ambil  air putih (secukupnya, kurang lebih 200 ml)
1. Gunakan  Bumbu halus:
1. Siapkan 6 siung bawang putih
1. Ambil 7 siung bawang merah
1. Ambil 2 sdt ketumbar
1. Sediakan 3 ruas jempol kunyit
1. Gunakan 3 butir kemiri
1. Siapkan 1 ruas jempol jahe
1. Ambil 2 ruas jempol lengkuas
1. Siapkan  Note : apabila kalian tidak mau ribet, kalian bisa membeli bumbu halus yang sudah jadi atau telah digiling di pasar terdekat




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Ungkep - Rice Cooker:

1. Siapkan semua bahan serta alat masak yang diperlukan.
1. Bersihkan ayam serta potong daging yang besarannya sesuai selera.
1. Masukan perasan air jeruk lemon/nipis dan tambahkan sedikit garam ke dalam daging ayam yang telah dibersihkan. Step ini bertujuan untuk menghilangkan bau amis yang terdapat pada daging ayam.
1. Diamkan ayam pada rendaman air jeruk lemon/nipis selama kurang lebih 5 menit.
1. Campurkan semua bahan-bahan bumbu halus dan haluskan menggunakan ulekan atau blender.
1. Panaskan rice cooker (mode: cook) serta masukan sedikit minyak goreng untuk menumis bumbu halus.
1. Apabila minyak goreng sudah mulai panas, (biasanya mode rice cooker berubah menjadi warm) masukan bumbu halus dan daun salam kedalamnya dan pindahkan mode rice cooker menjadi cook.
1. Tumis bambu halus sampai mengeluarkan aroma wangi dan jangan sampai gosong ya.
1. Masukkan daging ayam ke dalam rice cooker, aduk dan diamkan selama 5 menit. Pada tahapan ini mode rice cooker akan berubah menjadi warm, oleh karenanya pindahkan mode tersebut hingga menjadi cook.
1. Tuangkan air putih ke dalam rice cooker hingga seluruh permukaan ayam terendam air, tambahkan bumbu seperti garam, lada putih dan gula sesuai dengan selera (biasanya masakan saya lebih dominan asin agar pada saat dimakan dengan nasi tetap mengeluarkan cita rasa gurih) dan koreksi rasa. Pada tahapan ini masukkan pula tahu/tempe ke dalamnya.
1. Ungkep / masak ayam beserta tahu atau tempe di dalam rice cooker hingga air ungkepan menjadi surut. Proses ini memakan waktu 45 menit dan apabila mode rice cooker berubah menjadi &#34;warm&#34;, maka perlu diubah kembali untuk menjadi mode &#34;cook&#34;. Jangan lupa sesekali diaduk ya, agar ayam beserta tahu/tempe tidak menjadi gosong pada saat proses pengungkepan.
1. Apabila air ungkepan telah habis, matikan rice cooker dan pindahkan ayam beserta tahu atau tempe ke wadah penyimpanan.
1. Ayam ungkep beserta tahu/tempe siap digoreng dan dihidangkan.




Wah ternyata cara buat ayam goreng ungkep - rice cooker yang mantab simple ini gampang banget ya! Kamu semua dapat membuatnya. Cara Membuat ayam goreng ungkep - rice cooker Sangat sesuai sekali untuk anda yang baru belajar memasak atau juga untuk anda yang telah lihai memasak.

Apakah kamu ingin mulai mencoba buat resep ayam goreng ungkep - rice cooker lezat sederhana ini? Kalau kamu mau, ayo kalian segera buruan menyiapkan alat dan bahannya, lalu bikin deh Resep ayam goreng ungkep - rice cooker yang mantab dan simple ini. Benar-benar taidak sulit kan. 

Maka dari itu, daripada kalian diam saja, maka kita langsung saja bikin resep ayam goreng ungkep - rice cooker ini. Pasti kamu tiidak akan menyesal bikin resep ayam goreng ungkep - rice cooker lezat tidak ribet ini! Selamat mencoba dengan resep ayam goreng ungkep - rice cooker enak tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

