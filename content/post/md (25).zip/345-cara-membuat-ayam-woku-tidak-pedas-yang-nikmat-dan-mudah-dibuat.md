---
description: "Cara membuat Ayam Woku (Tidak Pedas) yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Woku (Tidak Pedas) yang nikmat dan Mudah Dibuat"
slug: 345-cara-membuat-ayam-woku-tidak-pedas-yang-nikmat-dan-mudah-dibuat
date: 2021-05-08T12:10:34.376Z
image: https://img-global.cpcdn.com/recipes/8435e6004ccb0abd/680x482cq70/ayam-woku-tidak-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8435e6004ccb0abd/680x482cq70/ayam-woku-tidak-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8435e6004ccb0abd/680x482cq70/ayam-woku-tidak-pedas-foto-resep-utama.jpg
author: Marguerite Cummings
ratingvalue: 4.3
reviewcount: 9
recipeingredient:
- "1 ekor Ayam potong jadi 20 sy 1 kg paha ayam ras"
- "1 ikat Daun kemangi sy 3 ikat"
- " Bumbu halus "
- "8 butir Bawang merah"
- "5 siung Bawang putih"
- "1 buah Cabe merah"
- "1 buah Tomat"
- "4 butir Kemiri sangrai"
- "1 ruas Jahe"
- "1/2 lembar Daun pandan muda iris tipis bisa skip saya pake"
- "3 lembar Daun jeruk"
- "1 lembar Daun salam"
- "3 batang Serai memarkan"
- "1 sdm Kunyit bubuk saya 1 sdt saja"
- "1 sdt Garam"
- "1 sdt Gula pasir"
- "1/2 sdt Kaldu bubuk saya 1 sdt kaldu jamur"
- "1 batang Daun bawang iris 12 cm bisa skip saya pake"
- "500 ml Air saya 200 ml saja"
recipeinstructions:
- "Siapkan semua bahan. Bersihkan ayam. Beri perasan jeruk nipis. Rebus untuk menghilangkan lemaknya. Buang kaldunya. Petik daun kemangi. Kupas bawang merah, putih. Memarkan serai           (lihat tips)"
- "Masukkan bawang merah, bawang putih, cabe merah, tomat, kemiri, jahe dalam blender. Potong2 tipis daun pandan, 1/2 cm daun bawang"
- "Blender dengan ditambah sedikit air sampai halus"
- "Tumis sampai wangi"
- "Masukkan daun pandan, daun jeruk, daun salam, serai dan kunyit bubuk. Masak sampai setengah matang"
- "Masukkan ayam. Aduk pelan-pelan sampai ayam terlumuri bumbu"
- "Tambahkan air, garam, gula dan kaldu bubuk. Masak dengan api kecil sampai air menyusut dan bumbu meresap. Saya mengurangi jumlah air karena ayam saya sudah hampir matang, takut hancur. Dan masaknya lagi terburu2 😁"
- "Tambahkan daun bawang. Aduk rata"
- "Tambahkan daun kemangi. Aduk sebentar. Jangan sampai daun kemangi terlalu layu. Saya suka pake daun kemangi banyak..."
- "Ayam Woku siap untuk disajikan sebagai sarapan saya hari ini"
categories:
- Resep
tags:
- ayam
- woku
- tidak

katakunci: ayam woku tidak 
nutrition: 117 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Woku (Tidak Pedas)](https://img-global.cpcdn.com/recipes/8435e6004ccb0abd/680x482cq70/ayam-woku-tidak-pedas-foto-resep-utama.jpg)

Andai kamu seorang ibu, menyuguhkan masakan sedap bagi keluarga tercinta adalah hal yang memuaskan untuk anda sendiri. Peran seorang istri bukan saja mengurus rumah saja, tetapi kamu juga wajib memastikan kebutuhan nutrisi terpenuhi dan juga panganan yang disantap orang tercinta mesti mantab.

Di zaman  saat ini, kalian memang dapat mengorder masakan praktis walaupun tidak harus susah memasaknya dahulu. Tetapi banyak juga lho orang yang selalu mau memberikan yang terlezat bagi orang tercintanya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan keluarga. 



Apakah anda merupakan salah satu penggemar ayam woku (tidak pedas)?. Asal kamu tahu, ayam woku (tidak pedas) merupakan hidangan khas di Nusantara yang kini disukai oleh orang-orang di hampir setiap daerah di Indonesia. Kalian dapat menyajikan ayam woku (tidak pedas) hasil sendiri di rumahmu dan boleh jadi santapan favorit di akhir pekanmu.

Kalian tidak usah bingung untuk memakan ayam woku (tidak pedas), sebab ayam woku (tidak pedas) sangat mudah untuk didapatkan dan kalian pun dapat membuatnya sendiri di tempatmu. ayam woku (tidak pedas) bisa diolah memalui bermacam cara. Sekarang telah banyak banget cara modern yang membuat ayam woku (tidak pedas) lebih nikmat.

Resep ayam woku (tidak pedas) pun gampang sekali dihidangkan, lho. Kita jangan capek-capek untuk membeli ayam woku (tidak pedas), sebab Kamu mampu menyiapkan di rumahmu. Bagi Kalian yang akan menghidangkannya, berikut ini cara menyajikan ayam woku (tidak pedas) yang enak yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Woku (Tidak Pedas):

1. Sediakan 1 ekor Ayam, potong jadi 20 (sy 1 kg paha ayam ras)
1. Gunakan 1 ikat Daun kemangi (sy 3 ikat)
1. Gunakan  Bumbu halus :
1. Gunakan 8 butir Bawang merah
1. Gunakan 5 siung Bawang putih
1. Siapkan 1 buah Cabe merah
1. Sediakan 1 buah Tomat
1. Ambil 4 butir Kemiri, sangrai
1. Gunakan 1 ruas Jahe
1. Gunakan 1/2 lembar Daun pandan muda, iris tipis (bisa skip) (saya pake)
1. Sediakan 3 lembar Daun jeruk
1. Sediakan 1 lembar Daun salam
1. Sediakan 3 batang Serai, memarkan
1. Siapkan 1 sdm Kunyit bubuk (saya 1 sdt saja)
1. Siapkan 1 sdt Garam
1. Sediakan 1 sdt Gula pasir
1. Sediakan 1/2 sdt Kaldu bubuk (saya 1 sdt kaldu jamur)
1. Gunakan 1 batang Daun bawang, iris 1/2 cm (bisa skip) (saya pake)
1. Sediakan 500 ml Air (saya 200 ml saja)




<!--inarticleads2-->

##### Cara membuat Ayam Woku (Tidak Pedas):

1. Siapkan semua bahan. Bersihkan ayam. Beri perasan jeruk nipis. Rebus untuk menghilangkan lemaknya. Buang kaldunya. Petik daun kemangi. Kupas bawang merah, putih. Memarkan serai -           (lihat tips)
1. Masukkan bawang merah, bawang putih, cabe merah, tomat, kemiri, jahe dalam blender. Potong2 tipis daun pandan, 1/2 cm daun bawang
1. Blender dengan ditambah sedikit air sampai halus
1. Tumis sampai wangi
1. Masukkan daun pandan, daun jeruk, daun salam, serai dan kunyit bubuk. Masak sampai setengah matang
1. Masukkan ayam. Aduk pelan-pelan sampai ayam terlumuri bumbu
1. Tambahkan air, garam, gula dan kaldu bubuk. Masak dengan api kecil sampai air menyusut dan bumbu meresap. Saya mengurangi jumlah air karena ayam saya sudah hampir matang, takut hancur. Dan masaknya lagi terburu2 😁
1. Tambahkan daun bawang. Aduk rata
1. Tambahkan daun kemangi. Aduk sebentar. Jangan sampai daun kemangi terlalu layu. Saya suka pake daun kemangi banyak...
1. Ayam Woku siap untuk disajikan sebagai sarapan saya hari ini




Wah ternyata cara membuat ayam woku (tidak pedas) yang nikamt tidak rumit ini enteng banget ya! Kita semua bisa memasaknya. Resep ayam woku (tidak pedas) Sesuai sekali untuk kamu yang baru mau belajar memasak maupun juga bagi kamu yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba buat resep ayam woku (tidak pedas) enak simple ini? Kalau mau, mending kamu segera siapin alat dan bahan-bahannya, setelah itu bikin deh Resep ayam woku (tidak pedas) yang nikmat dan simple ini. Benar-benar mudah kan. 

Oleh karena itu, daripada kamu berfikir lama-lama, ayo langsung aja hidangkan resep ayam woku (tidak pedas) ini. Dijamin kalian tiidak akan nyesel sudah bikin resep ayam woku (tidak pedas) mantab simple ini! Selamat berkreasi dengan resep ayam woku (tidak pedas) enak sederhana ini di rumah masing-masing,ya!.

