---
description: "Cara buat Bubur Bali Bumbu Kacang dengan Ayam Suwir Sambal Matah yang nikmat dan Mudah Dibuat"
title: "Cara buat Bubur Bali Bumbu Kacang dengan Ayam Suwir Sambal Matah yang nikmat dan Mudah Dibuat"
slug: 43-cara-buat-bubur-bali-bumbu-kacang-dengan-ayam-suwir-sambal-matah-yang-nikmat-dan-mudah-dibuat
date: 2021-01-18T19:42:14.953Z
image: https://img-global.cpcdn.com/recipes/ba80aa8dbf850663/680x482cq70/bubur-bali-bumbu-kacang-dengan-ayam-suwir-sambal-matah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ba80aa8dbf850663/680x482cq70/bubur-bali-bumbu-kacang-dengan-ayam-suwir-sambal-matah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ba80aa8dbf850663/680x482cq70/bubur-bali-bumbu-kacang-dengan-ayam-suwir-sambal-matah-foto-resep-utama.jpg
author: Max McDonald
ratingvalue: 4.3
reviewcount: 14
recipeingredient:
- " Bahan Bubur"
- "250 gram beras cuci bersih"
- "1/2 sdt garam atau sesuai selera"
- "1 lembar daun salam"
- "1 liter air jika kurang bisa tambahkan"
- "200-250 ml santan cair"
- " Bahan Bumbu Kacang"
- "100 gram kacang goreng"
- "6 buah cabe rawit"
- "1 buah cabe merah besar"
- "1/2 sdt terasi"
- "100 ml air matang"
- "1/2 sdt garam dan kaldu bubuk"
- " Bahan Ayam Suwir Sambal Matah"
- "250 gram daging ayam ungkep           lihat resep"
- "5 buah cabe rawit"
- "8 butir bawang merah"
- "2 siung bawang putih opsional"
- "Sejumput garam"
- "1-2 sdm minyak goreng panas bekas gorengan jelantah"
- " Pelengkap"
- " Kerupuk"
- " Daun bawang"
- " Bawang goreng"
- " Minyak goreng"
recipeinstructions:
- "Setelah beras dicuci bersih, lalu beri air agak banyak ± 1 liter. Masak hingga mendidih, air asat dan beras menjadi bubur (gunakan api sedang).  Catatan: Jika 1 liter air dirasa kurang, bisa ditambahkan sesuai selera sampai nasi benar2 menjadi bubur."
- "Aduk terus lalu tambahkan santan, daun salam dan garam, aduk rata. Jika sudah tercampur dan sudah pas bisa matikan apinya.  Catatan: Ini tekstur bubur agak kasar gak terlalu halus ya. Jika ingin bubur yang benar2 halus bisa menggunakan nasi matang yang diblender selain itu juga prosesnya lebih cepat."
- "Haluskan cabe rawit, cabe merah, terasi dan garam. Tambahkan kacang goreng dan haluskan lagi (ulek rata)."
- "Panaskan sedikit minyak goreng. Tumis bumbu kacang hingga harum dan sedikit kering, tambahkan air, masak hingga mendidih, koreksi rasa. Jika sudah pas dan air asat, matikan api dan sisihkan."
- "Suwir-suwir ayam ungkepnya. Goreng sebentar dan beri sedikit air, masak hingga air asat/kering, jika sudah sisihkan."
- "Campur semua bahan sambal matah, siram dengan minyak panas. Tambahkan ayam suwir dan sedikit garam, aduk rata."
- "Penyajian: Siapkan bubur, siram bumbu kacang dan suwiran ayam sambal matah."
- "Beri taburan bawang goreng, daun bawang dan kerupuk. Dan bubur bali bumbu kacang dengan ayam suwir sambal matah siap dinikmati."
categories:
- Resep
tags:
- bubur
- bali
- bumbu

katakunci: bubur bali bumbu 
nutrition: 255 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dessert

---


![Bubur Bali Bumbu Kacang dengan Ayam Suwir Sambal Matah](https://img-global.cpcdn.com/recipes/ba80aa8dbf850663/680x482cq70/bubur-bali-bumbu-kacang-dengan-ayam-suwir-sambal-matah-foto-resep-utama.jpg)

Jika kalian seorang wanita, menyediakan olahan menggugah selera buat keluarga tercinta adalah suatu hal yang sangat menyenangkan bagi anda sendiri. Tanggung jawab seorang  wanita bukan saja mengatur rumah saja, namun anda juga harus memastikan kebutuhan nutrisi tercukupi dan panganan yang disantap orang tercinta mesti lezat.

Di zaman  sekarang, kalian memang dapat membeli olahan siap saji walaupun tidak harus capek mengolahnya lebih dulu. Tapi banyak juga mereka yang selalu mau memberikan yang terenak bagi keluarganya. Pasalnya, memasak yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan famili. 



Mungkinkah anda seorang penyuka bubur bali bumbu kacang dengan ayam suwir sambal matah?. Asal kamu tahu, bubur bali bumbu kacang dengan ayam suwir sambal matah adalah hidangan khas di Indonesia yang saat ini disenangi oleh banyak orang dari berbagai wilayah di Nusantara. Kamu bisa memasak bubur bali bumbu kacang dengan ayam suwir sambal matah buatan sendiri di rumah dan dapat dijadikan makanan favorit di akhir pekan.

Kamu tak perlu bingung jika kamu ingin mendapatkan bubur bali bumbu kacang dengan ayam suwir sambal matah, karena bubur bali bumbu kacang dengan ayam suwir sambal matah gampang untuk ditemukan dan anda pun boleh membuatnya sendiri di rumah. bubur bali bumbu kacang dengan ayam suwir sambal matah bisa diolah dengan berbagai cara. Kini pun sudah banyak resep kekinian yang membuat bubur bali bumbu kacang dengan ayam suwir sambal matah semakin lebih mantap.

Resep bubur bali bumbu kacang dengan ayam suwir sambal matah pun mudah untuk dibikin, lho. Kita tidak usah ribet-ribet untuk memesan bubur bali bumbu kacang dengan ayam suwir sambal matah, karena Kamu mampu menyiapkan di rumah sendiri. Bagi Kalian yang ingin menyajikannya, di bawah ini adalah resep membuat bubur bali bumbu kacang dengan ayam suwir sambal matah yang nikamat yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Bubur Bali Bumbu Kacang dengan Ayam Suwir Sambal Matah:

1. Ambil  Bahan Bubur:
1. Siapkan 250 gram beras, cuci bersih
1. Siapkan 1/2 sdt garam, atau sesuai selera
1. Ambil 1 lembar daun salam
1. Sediakan 1 liter air, jika kurang bisa tambahkan
1. Siapkan 200-250 ml santan cair
1. Siapkan  Bahan Bumbu Kacang:
1. Gunakan 100 gram kacang goreng
1. Sediakan 6 buah cabe rawit
1. Gunakan 1 buah cabe merah besar
1. Sediakan 1/2 sdt terasi
1. Ambil 100 ml air matang
1. Gunakan 1/2 sdt garam dan kaldu bubuk
1. Ambil  Bahan Ayam Suwir Sambal Matah:
1. Ambil 250 gram daging ayam ungkep           (lihat resep)
1. Gunakan 5 buah cabe rawit
1. Gunakan 8 butir bawang merah
1. Siapkan 2 siung bawang putih, opsional
1. Gunakan Sejumput garam
1. Ambil 1-2 sdm minyak goreng panas, bekas gorengan (jelantah)
1. Sediakan  Pelengkap:
1. Gunakan  Kerupuk
1. Ambil  Daun bawang
1. Sediakan  Bawang goreng
1. Ambil  Minyak goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Bubur Bali Bumbu Kacang dengan Ayam Suwir Sambal Matah:

1. Setelah beras dicuci bersih, lalu beri air agak banyak ± 1 liter. Masak hingga mendidih, air asat dan beras menjadi bubur (gunakan api sedang).  - Catatan: Jika 1 liter air dirasa kurang, bisa ditambahkan sesuai selera sampai nasi benar2 menjadi bubur.
1. Aduk terus lalu tambahkan santan, daun salam dan garam, aduk rata. Jika sudah tercampur dan sudah pas bisa matikan apinya.  - Catatan: Ini tekstur bubur agak kasar gak terlalu halus ya. Jika ingin bubur yang benar2 halus bisa menggunakan nasi matang yang diblender selain itu juga prosesnya lebih cepat.
1. Haluskan cabe rawit, cabe merah, terasi dan garam. Tambahkan kacang goreng dan haluskan lagi (ulek rata).
1. Panaskan sedikit minyak goreng. Tumis bumbu kacang hingga harum dan sedikit kering, tambahkan air, masak hingga mendidih, koreksi rasa. Jika sudah pas dan air asat, matikan api dan sisihkan.
1. Suwir-suwir ayam ungkepnya. Goreng sebentar dan beri sedikit air, masak hingga air asat/kering, jika sudah sisihkan.
1. Campur semua bahan sambal matah, siram dengan minyak panas. Tambahkan ayam suwir dan sedikit garam, aduk rata.
1. Penyajian: Siapkan bubur, siram bumbu kacang dan suwiran ayam sambal matah.
1. Beri taburan bawang goreng, daun bawang dan kerupuk. Dan bubur bali bumbu kacang dengan ayam suwir sambal matah siap dinikmati.




Wah ternyata cara membuat bubur bali bumbu kacang dengan ayam suwir sambal matah yang lezat simple ini gampang banget ya! Kamu semua bisa mencobanya. Cara Membuat bubur bali bumbu kacang dengan ayam suwir sambal matah Cocok sekali untuk kamu yang baru akan belajar memasak maupun juga untuk kamu yang sudah pandai memasak.

Apakah kamu ingin mulai mencoba bikin resep bubur bali bumbu kacang dengan ayam suwir sambal matah lezat tidak ribet ini? Kalau anda mau, ayo kalian segera buruan menyiapkan alat dan bahan-bahannya, kemudian bikin deh Resep bubur bali bumbu kacang dengan ayam suwir sambal matah yang nikmat dan simple ini. Sangat mudah kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, maka kita langsung sajikan resep bubur bali bumbu kacang dengan ayam suwir sambal matah ini. Dijamin kamu tak akan menyesal sudah bikin resep bubur bali bumbu kacang dengan ayam suwir sambal matah lezat tidak ribet ini! Selamat mencoba dengan resep bubur bali bumbu kacang dengan ayam suwir sambal matah mantab tidak rumit ini di rumah kalian sendiri,ya!.

