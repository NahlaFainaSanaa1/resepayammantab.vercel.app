---
description: "Cara buat Soto Ayam Santan yang nikmat dan Mudah Dibuat"
title: "Cara buat Soto Ayam Santan yang nikmat dan Mudah Dibuat"
slug: 28-cara-buat-soto-ayam-santan-yang-nikmat-dan-mudah-dibuat
date: 2021-05-04T14:09:01.589Z
image: https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Lelia Stevenson
ratingvalue: 4.5
reviewcount: 13
recipeingredient:
- "1/2 kg ayam"
- "1 buah santan"
- "Secukupnya garam"
- "Secukupnya lada bubuk"
- "Secukupnya kaldu bubukpenyedap"
- " Bumbu Halus"
- "4 siung bawang putih"
- "4 siung bawang merah"
- "2 butir kemiri sangrai"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1/2 ruas lengkuas"
- "1 sdt ketumbar"
- " Bumbu Cemplung"
- "1 batang sereh geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- " Bahan Pelengkap"
- "1 buah tomat"
- " Kentang goreng potong dadu"
- " Bawang goreng optional"
- " Daun bawang iris optional"
- " Emping"
recipeinstructions:
- "Tumis bumbu halus dan bumbu cemplung sampai harum."
- "Tambahkan air secukupnya untuk kuah dan masak hingga mendidih. Masukkan garam, lada dan penyedap."
- "Masukkan ayam ke dalam air kuah mendidih tadi dan masak sampai ayam matang. Kemudian angkat dan tiriskan ayam, lalu goreng sebentar sampai kecoklatan, dan suwir-suwir ayam."
- "Sementara itu masukkan santan ke dalam air kuah dan aduk perlahan. Jangan lupa koreksi rasa."
- "Jangan lupa juga goreng kentang yang sudah dipotong dadu."
- "Tata bahan pelengkap di mangkuk, dan siram dengan kuah soto. Siap disajikan dengan nasi hangat ^^ p.s:Kalo mau pedes bisa bikin sambel simplenya. Caranya rebus cabe rawit merah, kemudian blender atau ulek, tambahkan air dan garam sedikit."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 177 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan panganan nikmat buat keluarga adalah suatu hal yang membahagiakan bagi anda sendiri. Peran seorang ibu Tidak sekedar mengatur rumah saja, tetapi kamu juga wajib menyediakan kebutuhan nutrisi terpenuhi dan juga olahan yang dimakan anak-anak mesti mantab.

Di waktu  sekarang, kamu memang mampu memesan hidangan praktis walaupun tanpa harus ribet mengolahnya dahulu. Tetapi ada juga orang yang selalu ingin memberikan makanan yang terenak bagi orang yang dicintainya. Karena, menghidangkan masakan sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai selera keluarga. 



Mungkinkah anda merupakan seorang penyuka soto ayam santan?. Tahukah kamu, soto ayam santan adalah makanan khas di Nusantara yang saat ini disenangi oleh orang-orang di berbagai daerah di Indonesia. Kita bisa menyajikan soto ayam santan sendiri di rumah dan boleh dijadikan camilan kegemaranmu di akhir pekan.

Anda tak perlu bingung jika kamu ingin memakan soto ayam santan, lantaran soto ayam santan tidak sulit untuk didapatkan dan juga kamu pun boleh mengolahnya sendiri di rumah. soto ayam santan bisa dibuat dengan berbagai cara. Kini pun sudah banyak sekali cara kekinian yang membuat soto ayam santan semakin mantap.

Resep soto ayam santan pun sangat gampang dibikin, lho. Kita tidak perlu ribet-ribet untuk memesan soto ayam santan, sebab Anda mampu menyajikan di rumahmu. Untuk Kita yang ingin menghidangkannya, berikut ini resep menyajikan soto ayam santan yang nikamat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Santan:

1. Sediakan 1/2 kg ayam
1. Sediakan 1 buah santan
1. Siapkan Secukupnya garam
1. Ambil Secukupnya lada bubuk
1. Siapkan Secukupnya kaldu bubuk/penyedap
1. Sediakan  Bumbu Halus
1. Gunakan 4 siung bawang putih
1. Gunakan 4 siung bawang merah
1. Siapkan 2 butir kemiri (sangrai)
1. Sediakan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Sediakan 1/2 ruas lengkuas
1. Ambil 1 sdt ketumbar
1. Sediakan  Bumbu Cemplung
1. Gunakan 1 batang sereh (geprek)
1. Ambil 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Ambil  Bahan Pelengkap
1. Ambil 1 buah tomat
1. Sediakan  Kentang goreng (potong dadu)
1. Gunakan  Bawang goreng (optional)
1. Siapkan  Daun bawang iris (optional)
1. Ambil  Emping




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Santan:

1. Tumis bumbu halus dan bumbu cemplung sampai harum.
1. Tambahkan air secukupnya untuk kuah dan masak hingga mendidih. Masukkan garam, lada dan penyedap.
1. Masukkan ayam ke dalam air kuah mendidih tadi dan masak sampai ayam matang. Kemudian angkat dan tiriskan ayam, lalu goreng sebentar sampai kecoklatan, dan suwir-suwir ayam.
1. Sementara itu masukkan santan ke dalam air kuah dan aduk perlahan. Jangan lupa koreksi rasa.
1. Jangan lupa juga goreng kentang yang sudah dipotong dadu.
1. Tata bahan pelengkap di mangkuk, dan siram dengan kuah soto. Siap disajikan dengan nasi hangat ^^ p.s:Kalo mau pedes bisa bikin sambel simplenya. Caranya rebus cabe rawit merah, kemudian blender atau ulek, tambahkan air dan garam sedikit.




Wah ternyata resep soto ayam santan yang lezat tidak rumit ini enteng sekali ya! Kalian semua mampu membuatnya. Resep soto ayam santan Sangat sesuai sekali buat anda yang sedang belajar memasak ataupun juga bagi kalian yang sudah ahli memasak.

Tertarik untuk mencoba membikin resep soto ayam santan lezat tidak rumit ini? Kalau kamu mau, ayo kalian segera buruan siapin alat dan bahan-bahannya, lalu bikin deh Resep soto ayam santan yang lezat dan sederhana ini. Sangat gampang kan. 

Maka, ketimbang anda diam saja, ayo langsung aja sajikan resep soto ayam santan ini. Pasti kalian tiidak akan nyesel bikin resep soto ayam santan enak tidak rumit ini! Selamat berkreasi dengan resep soto ayam santan mantab tidak rumit ini di rumah kalian sendiri,oke!.

