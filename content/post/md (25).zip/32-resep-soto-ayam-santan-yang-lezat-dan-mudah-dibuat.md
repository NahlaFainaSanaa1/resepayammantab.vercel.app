---
description: "Resep Soto Ayam Santan yang lezat dan Mudah Dibuat"
title: "Resep Soto Ayam Santan yang lezat dan Mudah Dibuat"
slug: 32-resep-soto-ayam-santan-yang-lezat-dan-mudah-dibuat
date: 2021-02-27T14:39:52.604Z
image: https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Alma Tyler
ratingvalue: 4.6
reviewcount: 14
recipeingredient:
- "500 gr dada ayam"
- "1500 ml santan"
- "3 lbr daun salam"
- "3 lbr daub jeruk"
- "2 batang seraimemarkan"
- "2 ruas jari lengkuasmemarkan"
- "2 batang daun bawang potong 2 cm bagian putih kuskip"
- "Sesuai selera gulagaram dan kaldu bubuk"
- " Bumbu halus"
- "6 buah bawang merah"
- "3 siung bawang putih"
- "3 btr kemiri sangarai"
- "1 ruas jari jahe"
- "1/2 sdt ketumba"
- "1/2 sdt merica butir"
- " Pelengkap"
- "1 buah tomat besarpotong kotak kecil"
- "Sesuai selera irisan daun bawang kuskip seledri"
- "200 gr kol iris"
- "1 buah jeruk nipis"
- "Sesuai selera pelngkap lainya sambalbawang goreng dan emping"
recipeinstructions:
- "Potong dada ayam,cuci bersih lumuri dengan air jeruk nipis.Diamkan beberapa saat dan bilas.Goreng hingga agak kecoklatan saja.Kemudian suir suir."
- ""
- "Haluskan bahan bumbu halus.Tumis bumbu halus,daun salam,daun jeruk,serai dan lengkuas.Tumis hingga bumbu matang,beri sedikit air.Matikan api."
- "Masak santan hingga mendidih.Masukkan tumisan bumbu.Aduk selalu agar santan tidak pecah."
- "Masukkan ayam suir,beri bumbu gula,garam dan kaldu bubuk sesuai selera.Masak hingga bumbu pas dilidah."
- "Seduh irisan kol dengan air panas,tiriskan.Tata kol dimangkuk siram dengan kuah soto dan ayam.Beri pelengkap sesuai selera."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 128 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyajikan olahan nikmat untuk famili merupakan hal yang menggembirakan bagi kamu sendiri. Peran seorang istri Tidak sekedar menjaga rumah saja, tapi kamu pun wajib menyediakan kebutuhan nutrisi terpenuhi dan hidangan yang dimakan anak-anak harus nikmat.

Di masa  saat ini, anda sebenarnya mampu mengorder masakan praktis walaupun tidak harus capek membuatnya lebih dulu. Tetapi ada juga lho orang yang selalu ingin menyajikan yang terenak untuk orang yang dicintainya. Sebab, menyajikan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan famili. 



Apakah anda merupakan seorang penyuka soto ayam santan?. Tahukah kamu, soto ayam santan merupakan sajian khas di Nusantara yang sekarang disenangi oleh orang-orang dari hampir setiap tempat di Indonesia. Kamu dapat memasak soto ayam santan hasil sendiri di rumahmu dan boleh jadi camilan kesenanganmu di hari libur.

Kita tidak usah bingung untuk menyantap soto ayam santan, lantaran soto ayam santan sangat mudah untuk ditemukan dan kalian pun bisa memasaknya sendiri di tempatmu. soto ayam santan bisa dibuat dengan bermacam cara. Kini pun telah banyak banget cara kekinian yang menjadikan soto ayam santan semakin lezat.

Resep soto ayam santan juga sangat mudah dihidangkan, lho. Kita tidak perlu capek-capek untuk membeli soto ayam santan, sebab Kalian mampu menyiapkan di rumahmu. Untuk Kamu yang hendak membuatnya, di bawah ini adalah cara membuat soto ayam santan yang enak yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Santan:

1. Gunakan 500 gr dada ayam
1. Sediakan 1500 ml santan
1. Ambil 3 lbr daun salam
1. Ambil 3 lbr daub jeruk
1. Sediakan 2 batang serai,memarkan
1. Gunakan 2 ruas jari lengkuas,memarkan
1. Siapkan 2 batang daun bawang potong 2 cm bagian putih (kuskip)
1. Siapkan Sesuai selera gula,garam dan kaldu bubuk
1. Ambil  Bumbu halus
1. Gunakan 6 buah bawang merah
1. Sediakan 3 siung bawang putih
1. Gunakan 3 btr kemiri sangarai
1. Siapkan 1 ruas jari jahe
1. Siapkan 1/2 sdt ketumba
1. Ambil 1/2 sdt merica butir
1. Ambil  Pelengkap
1. Siapkan 1 buah tomat besar,potong kotak kecil
1. Gunakan Sesuai selera irisan daun bawang (kuskip) seledri
1. Sediakan 200 gr kol iris
1. Siapkan 1 buah jeruk nipis
1. Ambil Sesuai selera pelngkap lainya sambal,bawang goreng dan emping




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Santan:

1. Potong dada ayam,cuci bersih lumuri dengan air jeruk nipis.Diamkan beberapa saat dan bilas.Goreng hingga agak kecoklatan saja.Kemudian suir suir.
1. 
1. Haluskan bahan bumbu halus.Tumis bumbu halus,daun salam,daun jeruk,serai dan lengkuas.Tumis hingga bumbu matang,beri sedikit air.Matikan api.
1. Masak santan hingga mendidih.Masukkan tumisan bumbu.Aduk selalu agar santan tidak pecah.
1. Masukkan ayam suir,beri bumbu gula,garam dan kaldu bubuk sesuai selera.Masak hingga bumbu pas dilidah.
1. Seduh irisan kol dengan air panas,tiriskan.Tata kol dimangkuk siram dengan kuah soto dan ayam.Beri pelengkap sesuai selera.




Wah ternyata cara membuat soto ayam santan yang enak tidak ribet ini enteng banget ya! Semua orang bisa mencobanya. Cara Membuat soto ayam santan Sangat sesuai sekali buat kita yang baru belajar memasak maupun juga bagi kamu yang sudah lihai dalam memasak.

Apakah kamu mau mulai mencoba membuat resep soto ayam santan enak simple ini? Kalau kamu tertarik, yuk kita segera menyiapkan peralatan dan bahannya, lalu buat deh Resep soto ayam santan yang nikmat dan tidak ribet ini. Betul-betul taidak sulit kan. 

Maka, daripada kamu berfikir lama-lama, ayo kita langsung bikin resep soto ayam santan ini. Dijamin kalian gak akan nyesel sudah bikin resep soto ayam santan nikmat tidak rumit ini! Selamat mencoba dengan resep soto ayam santan enak sederhana ini di rumah kalian sendiri,ya!.

