---
description: "Bahan-bahan Ayam Bakar Spesial Sederhana Untuk Jualan"
title: "Bahan-bahan Ayam Bakar Spesial Sederhana Untuk Jualan"
slug: 280-bahan-bahan-ayam-bakar-spesial-sederhana-untuk-jualan
date: 2021-06-29T22:16:21.366Z
image: https://img-global.cpcdn.com/recipes/2f2e66853ab1c843/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2f2e66853ab1c843/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2f2e66853ab1c843/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg
author: Marcus Warner
ratingvalue: 4.1
reviewcount: 3
recipeingredient:
- "1 ekor ayam potong sesuai selera"
- "2 batang serai geprek"
- "8 lembar daun jeruk"
- "secukupnya Kecap manis"
- "2 buah asam jawa larutkan ke dalam air"
- "secukupnya Gula merah"
- "secukupnya lada bubuk"
- "secukupnya Garam"
- " Air untuk merebus ayam"
- " Minyak sayur untuk menumis"
- " Bumbu Halus "
- "4 siung bawang putih"
- "10 siung bawang merah"
- "secukupnya Cabe merah keriting"
- "2 cm jahe"
- "2 cm lengkuas"
recipeinstructions:
- "Cuci bersih ayam, lalu rebus ayam hingga setengah matang (buang air rebusan pertama) lalu cuci bersih ayam"
- "Tumis bumbu halus, hingga harum dan berubah warna"
- "Setelah bumbu halus berubah warna masukan ke dalam ayam yg telah di cucui dan di rebus tadi, tambahkan air(dikira² ya jg terlalu banyak jg airnya)"
- "Tambahkan air asam jawa, gula merah, garam, lada bubuk, kecap manis. Ungkep hingga air ungkepan berkurang, bumbu meresap, dan ayam empuk. Jgan lupa koreksi rasa yaa"
- "Lalu bakar ayam sambil di oles²in kuah ungkepan tadi. Sambil di bolak balik. (Lupa ke foto😅🙏)"
- "Hidangkan dengan nasi hanggat, sambal dan lalapan"
- "Selamat mencoba😍"
categories:
- Resep
tags:
- ayam
- bakar
- spesial

katakunci: ayam bakar spesial 
nutrition: 292 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Bakar Spesial](https://img-global.cpcdn.com/recipes/2f2e66853ab1c843/680x482cq70/ayam-bakar-spesial-foto-resep-utama.jpg)

Apabila kamu seorang orang tua, menyajikan panganan enak buat keluarga adalah hal yang memuaskan bagi anda sendiri. Tugas seorang ibu Tidak hanya menangani rumah saja, tetapi kamu juga harus memastikan kebutuhan nutrisi terpenuhi dan juga hidangan yang disantap anak-anak wajib sedap.

Di masa  sekarang, kalian memang bisa membeli panganan instan meski tidak harus ribet membuatnya terlebih dahulu. Tapi banyak juga orang yang memang ingin menghidangkan yang terlezat untuk orang yang dicintainya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan sesuai dengan makanan kesukaan keluarga. 



Mungkinkah anda merupakan seorang penyuka ayam bakar spesial?. Tahukah kamu, ayam bakar spesial merupakan hidangan khas di Nusantara yang sekarang disenangi oleh setiap orang di berbagai wilayah di Nusantara. Kalian dapat menghidangkan ayam bakar spesial buatan sendiri di rumahmu dan boleh jadi makanan kesukaanmu di hari libur.

Kamu tidak perlu bingung untuk menyantap ayam bakar spesial, karena ayam bakar spesial gampang untuk ditemukan dan kita pun boleh mengolahnya sendiri di rumah. ayam bakar spesial boleh dimasak lewat beragam cara. Kini pun sudah banyak cara kekinian yang menjadikan ayam bakar spesial semakin lebih lezat.

Resep ayam bakar spesial pun mudah untuk dibuat, lho. Kita tidak usah capek-capek untuk membeli ayam bakar spesial, karena Kalian mampu menyajikan sendiri di rumah. Bagi Kalian yang ingin membuatnya, berikut ini cara menyajikan ayam bakar spesial yang nikamat yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Bakar Spesial:

1. Ambil 1 ekor ayam (potong sesuai selera)
1. Ambil 2 batang serai (geprek)
1. Ambil 8 lembar daun jeruk
1. Gunakan secukupnya Kecap manis
1. Siapkan 2 buah asam jawa (larutkan ke dalam air)
1. Ambil secukupnya Gula merah
1. Ambil secukupnya lada bubuk
1. Siapkan secukupnya Garam
1. Gunakan  Air (untuk merebus ayam)
1. Ambil  Minyak sayur (untuk menumis)
1. Sediakan  Bumbu Halus :
1. Ambil 4 siung bawang putih
1. Ambil 10 siung bawang merah
1. Gunakan secukupnya Cabe merah keriting
1. Gunakan 2 cm jahe
1. Ambil 2 cm lengkuas




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Bakar Spesial:

1. Cuci bersih ayam, lalu rebus ayam hingga setengah matang (buang air rebusan pertama) lalu cuci bersih ayam
1. Tumis bumbu halus, hingga harum dan berubah warna
1. Setelah bumbu halus berubah warna masukan ke dalam ayam yg telah di cucui dan di rebus tadi, tambahkan air(dikira² ya jg terlalu banyak jg airnya)
1. Tambahkan air asam jawa, gula merah, garam, lada bubuk, kecap manis. Ungkep hingga air ungkepan berkurang, bumbu meresap, dan ayam empuk. Jgan lupa koreksi rasa yaa
1. Lalu bakar ayam sambil di oles²in kuah ungkepan tadi. Sambil di bolak balik. (Lupa ke foto😅🙏)
1. Hidangkan dengan nasi hanggat, sambal dan lalapan
1. Selamat mencoba😍




Wah ternyata cara membuat ayam bakar spesial yang nikamt sederhana ini mudah banget ya! Kamu semua mampu membuatnya. Cara Membuat ayam bakar spesial Sangat sesuai banget buat kamu yang baru akan belajar memasak maupun juga bagi kamu yang sudah hebat dalam memasak.

Tertarik untuk mencoba buat resep ayam bakar spesial lezat tidak ribet ini? Kalau kamu mau, yuk kita segera menyiapkan peralatan dan bahannya, kemudian bikin deh Resep ayam bakar spesial yang lezat dan simple ini. Sungguh taidak sulit kan. 

Oleh karena itu, ketimbang kamu berfikir lama-lama, yuk kita langsung saja sajikan resep ayam bakar spesial ini. Dijamin kamu tak akan menyesal sudah membuat resep ayam bakar spesial enak sederhana ini! Selamat mencoba dengan resep ayam bakar spesial mantab simple ini di rumah kalian sendiri,ya!.

