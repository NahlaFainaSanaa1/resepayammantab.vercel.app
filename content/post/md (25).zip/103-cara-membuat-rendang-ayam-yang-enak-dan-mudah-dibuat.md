---
description: "Cara membuat Rendang Ayam yang enak dan Mudah Dibuat"
title: "Cara membuat Rendang Ayam yang enak dan Mudah Dibuat"
slug: 103-cara-membuat-rendang-ayam-yang-enak-dan-mudah-dibuat
date: 2021-07-03T07:57:17.305Z
image: https://img-global.cpcdn.com/recipes/cda695ea10deaf8d/680x482cq70/rendang-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cda695ea10deaf8d/680x482cq70/rendang-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cda695ea10deaf8d/680x482cq70/rendang-ayam-foto-resep-utama.jpg
author: Olga Kelley
ratingvalue: 3.2
reviewcount: 9
recipeingredient:
- "1 ekor ayam"
- "5 cabai merah besar"
- "3 cabai rawit"
- "3 batang sereh memarkan"
- "11 buah bawang merah"
- "7 buah bawang putih"
- "1 ruas kunyit"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "5 buah kemiri"
- "500 ml santan kental"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "5 sdm minyak goreng untuk menumis"
- "1 sdm ketumbar boleh pakai yg bubuk"
- "1 sdt bubuk pala"
- "2 buah asam kandis  asam jawa"
- "40 gr gula merah"
- "1 sdm garam  kaldu bubuk boleh tambah"
recipeinstructions:
- "Cuci bersih ayam, beri perasan air jeruk nipis 2 buah buang air kemudian beri garam 1 sdt remat remat hingga rata."
- "Bumbu yang dihaluskan : bawang merah, bawang putih, kemiri, kunyit, jahe, lengkuas. // bumbu halus : cabai merah besar dan cabai rawit."
- "Saya haluskan terpisah ya, karena bumbu halus kuning akan ditumis terlebih dahulu kemudian dicampurkan dengan pala bubuk baru masukkan bumbu kedua (cabai yg dihaluskan)"
- "Saat menumis bumbu pertama yaitu bumbu kuning, tunggu sampai bumbu harum baru tambahkan garam dan kaldu bubuk. Kemudian masukkan daun salam, sereh, dan daun jeruk masaknya dgn api sedang ke kecil supaya bumbu matang merata dan tidak cepat kering."
- "Bumbu halus terpisah."
- "Masak pertama setelah bumbu matang dan kedua bumbu masuk, lalu ayamnya dimasukkan dan di aduk hingga merata sampai menyerap. Tunggu baru masukkan sedikit air matang."
- "Kira kira sampai mengeluarkan gelembung seperti ini jangan lupa masukkan asam kandis dan gula merah."
- "Ini setelah ditambahkan santan. Saya memasukkan santan terakhir, supaya tidak pecah dan lebih gurih. Tidak saya tambahkan air karena di awal menumis bumbu, airnya sudah lumayan banyak sekitar 2 gelas belimbing. Jadi hingga tunggu masak dan kuah menyusut kurang lebih 25 menit sampai bumbu meresap dan ayam matang empuk."
- "Rendang Ayam siap disajikan."
categories:
- Resep
tags:
- rendang
- ayam

katakunci: rendang ayam 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dessert

---


![Rendang Ayam](https://img-global.cpcdn.com/recipes/cda695ea10deaf8d/680x482cq70/rendang-ayam-foto-resep-utama.jpg)

Andai anda seorang ibu, mempersiapkan santapan mantab bagi famili adalah hal yang menggembirakan untuk kamu sendiri. Tugas seorang  wanita Tidak sekedar mengurus rumah saja, namun anda juga harus memastikan keperluan nutrisi tercukupi dan olahan yang dimakan orang tercinta harus lezat.

Di era  sekarang, kalian sebenarnya dapat mengorder santapan instan meski tanpa harus capek membuatnya lebih dulu. Tapi ada juga lho orang yang memang ingin memberikan makanan yang terbaik untuk orang tercintanya. Karena, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan sesuai kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penggemar rendang ayam?. Tahukah kamu, rendang ayam merupakan hidangan khas di Indonesia yang sekarang disenangi oleh setiap orang di hampir setiap wilayah di Nusantara. Kamu dapat membuat rendang ayam hasil sendiri di rumahmu dan boleh jadi camilan favoritmu di hari liburmu.

Kalian tak perlu bingung jika kamu ingin mendapatkan rendang ayam, karena rendang ayam sangat mudah untuk didapatkan dan juga kamu pun boleh menghidangkannya sendiri di rumah. rendang ayam bisa diolah memalui bermacam cara. Kini pun ada banyak sekali cara kekinian yang membuat rendang ayam semakin lebih enak.

Resep rendang ayam juga gampang untuk dibuat, lho. Kita jangan ribet-ribet untuk memesan rendang ayam, lantaran Anda bisa membuatnya di rumah sendiri. Untuk Kamu yang hendak membuatnya, berikut ini resep membuat rendang ayam yang nikamat yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Rendang Ayam:

1. Siapkan 1 ekor ayam
1. Gunakan 5 cabai merah besar
1. Sediakan 3 cabai rawit
1. Gunakan 3 batang sereh memarkan
1. Siapkan 11 buah bawang merah
1. Sediakan 7 buah bawang putih
1. Sediakan 1 ruas kunyit
1. Ambil 1 ruas lengkuas
1. Ambil 1 ruas jahe
1. Siapkan 5 buah kemiri
1. Siapkan 500 ml santan kental
1. Gunakan 3 lembar daun salam
1. Gunakan 3 lembar daun jeruk
1. Sediakan 5 sdm minyak goreng untuk menumis
1. Ambil 1 sdm ketumbar (boleh pakai yg bubuk)
1. Siapkan 1 sdt bubuk pala
1. Gunakan 2 buah asam kandis / asam jawa
1. Siapkan 40 gr gula merah
1. Siapkan 1 sdm garam &amp; kaldu bubuk (boleh tambah)




<!--inarticleads2-->

##### Cara menyiapkan Rendang Ayam:

1. Cuci bersih ayam, beri perasan air jeruk nipis 2 buah buang air kemudian beri garam 1 sdt remat remat hingga rata.
1. Bumbu yang dihaluskan : bawang merah, bawang putih, kemiri, kunyit, jahe, lengkuas. // bumbu halus : cabai merah besar dan cabai rawit.
1. Saya haluskan terpisah ya, karena bumbu halus kuning akan ditumis terlebih dahulu kemudian dicampurkan dengan pala bubuk baru masukkan bumbu kedua (cabai yg dihaluskan)
1. Saat menumis bumbu pertama yaitu bumbu kuning, tunggu sampai bumbu harum baru tambahkan garam dan kaldu bubuk. Kemudian masukkan daun salam, sereh, dan daun jeruk masaknya dgn api sedang ke kecil supaya bumbu matang merata dan tidak cepat kering.
1. Bumbu halus terpisah.
1. Masak pertama setelah bumbu matang dan kedua bumbu masuk, lalu ayamnya dimasukkan dan di aduk hingga merata sampai menyerap. Tunggu baru masukkan sedikit air matang.
1. Kira kira sampai mengeluarkan gelembung seperti ini jangan lupa masukkan asam kandis dan gula merah.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Rendang Ayam">1. Ini setelah ditambahkan santan. Saya memasukkan santan terakhir, supaya tidak pecah dan lebih gurih. Tidak saya tambahkan air karena di awal menumis bumbu, airnya sudah lumayan banyak sekitar 2 gelas belimbing. Jadi hingga tunggu masak dan kuah menyusut kurang lebih 25 menit sampai bumbu meresap dan ayam matang empuk.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Rendang Ayam">1. Rendang Ayam siap disajikan.




Ternyata cara membuat rendang ayam yang nikamt simple ini mudah banget ya! Anda Semua bisa memasaknya. Cara Membuat rendang ayam Sangat cocok sekali buat anda yang baru belajar memasak maupun juga untuk kalian yang telah hebat memasak.

Tertarik untuk mencoba membuat resep rendang ayam mantab tidak ribet ini? Kalau ingin, mending kamu segera siapin alat dan bahannya, lalu buat deh Resep rendang ayam yang nikmat dan tidak ribet ini. Sungguh gampang kan. 

Jadi, daripada kalian diam saja, ayo kita langsung hidangkan resep rendang ayam ini. Dijamin anda gak akan menyesal sudah bikin resep rendang ayam enak tidak ribet ini! Selamat mencoba dengan resep rendang ayam mantab tidak rumit ini di tempat tinggal kalian masing-masing,ya!.

