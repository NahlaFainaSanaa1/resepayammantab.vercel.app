---
description: "Bahan-bahan 🍚 Chicken Tuna Mentai Rice yang enak dan Mudah Dibuat"
title: "Bahan-bahan 🍚 Chicken Tuna Mentai Rice yang enak dan Mudah Dibuat"
slug: 489-bahan-bahan-chicken-tuna-mentai-rice-yang-enak-dan-mudah-dibuat
date: 2021-05-04T11:05:35.677Z
image: https://img-global.cpcdn.com/recipes/55472f388040eebd/680x482cq70/🍚-chicken-tuna-mentai-rice-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55472f388040eebd/680x482cq70/🍚-chicken-tuna-mentai-rice-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55472f388040eebd/680x482cq70/🍚-chicken-tuna-mentai-rice-foto-resep-utama.jpg
author: Dale Kelley
ratingvalue: 3.9
reviewcount: 10
recipeingredient:
- " Campuran Nasi "
- "1 porsi nasi pulen"
- "1 sdt bubuk cabai"
- "1 sdm minyak wijen"
- "1/2 sdt kecap ikan"
- "1/2 sdt kecap asin"
- "1/2 sdt saus tiram"
- "secukupnya Remahan Nori"
- " Tumisan Ayam dan Tuna "
- "100 gram daging Ayam dan Tuna dipotong dadu"
- "1/2 Sium bawang bombai"
- "1 sdm Margarin untuk menumis"
- "1/2 sdt garam"
- "1/2 sdt gula pasir"
- "1 sdt saus tiram"
- "secukupnya Air"
- " Saus Mentai "
- "2 Sdm mayonaise"
- "2 sdm saus sambal"
- " Topping "
- "secukupnya Keju parut"
- "secukupnya Nori"
recipeinstructions:
- "Siapkan semua bahan-bahan yang diperlukan."
- "Tumis bawang bombai hingga layu dan wangi kemudian masukan ayam dan tuna aduk hingga rata. Tambahkan air, garam, gula dan saus tiram. Cicipi dan koreksi rasa. Masak sampai ayam dan tuna matang serta air menyusut, angkat dan sisihkan."
- "Campurkan semua bahan campuran nasi aduk rata, test rasa. Lalu tata dalam loyang yang di alasi dengan aluminium foil sambil di tekan-tekan ringan supaya agak padat."
- "Membuat saus&#39;nya : Campurkan mayones dan saus sambal aduk rata."
- "Tahapan akhir: Tata ayam dan tuna di atas campuran nasi yang sudah di tekan-tekan tadi. Setelah itu tahap selanjutnya adalah menuangkan saus campuran mayones di atas ayam dan tuna kemudian tambahkan keju parut dan potongan Nori di atasnya. Lalu kemudian di panggang selama kurang lebih 20 menit pada suhu 100-150°c."
- "Setelah matang chicken tuna mentai siap untuk di sajikan."
categories:
- Resep
tags:
- chicken
- tuna
- mentai

katakunci: chicken tuna mentai 
nutrition: 281 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dessert

---


![🍚 Chicken Tuna Mentai Rice](https://img-global.cpcdn.com/recipes/55472f388040eebd/680x482cq70/🍚-chicken-tuna-mentai-rice-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyuguhkan santapan enak buat keluarga adalah hal yang sangat menyenangkan untuk kamu sendiri. Tugas seorang  wanita Tidak cuma mengatur rumah saja, tapi anda juga wajib menyediakan kebutuhan nutrisi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta wajib mantab.

Di era  sekarang, anda sebenarnya bisa mengorder olahan yang sudah jadi tidak harus capek mengolahnya terlebih dahulu. Tapi banyak juga lho mereka yang selalu ingin menghidangkan yang terbaik untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga. 



Mungkinkah anda seorang penikmat 🍚 chicken tuna mentai rice?. Tahukah kamu, 🍚 chicken tuna mentai rice adalah hidangan khas di Indonesia yang kini disukai oleh setiap orang di hampir setiap daerah di Indonesia. Anda dapat membuat 🍚 chicken tuna mentai rice sendiri di rumah dan boleh jadi makanan kesenanganmu di akhir pekanmu.

Kamu tidak perlu bingung untuk menyantap 🍚 chicken tuna mentai rice, lantaran 🍚 chicken tuna mentai rice mudah untuk didapatkan dan juga kita pun bisa menghidangkannya sendiri di tempatmu. 🍚 chicken tuna mentai rice dapat diolah memalui beragam cara. Saat ini telah banyak resep kekinian yang membuat 🍚 chicken tuna mentai rice semakin mantap.

Resep 🍚 chicken tuna mentai rice pun sangat gampang dibikin, lho. Kalian tidak perlu repot-repot untuk memesan 🍚 chicken tuna mentai rice, karena Kamu dapat menyajikan di rumah sendiri. Bagi Kamu yang akan mencobanya, inilah resep untuk membuat 🍚 chicken tuna mentai rice yang lezat yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan 🍚 Chicken Tuna Mentai Rice:

1. Sediakan  Campuran Nasi :
1. Gunakan 1 porsi nasi pulen
1. Gunakan 1 sdt bubuk cabai
1. Sediakan 1 sdm minyak wijen
1. Sediakan 1/2 sdt kecap ikan
1. Sediakan 1/2 sdt kecap asin
1. Sediakan 1/2 sdt saus tiram
1. Gunakan secukupnya Remahan Nori
1. Sediakan  Tumisan Ayam dan Tuna :
1. Sediakan 100 gram daging Ayam dan Tuna, dipotong dadu
1. Ambil 1/2 Sium bawang bombai
1. Sediakan 1 sdm Margarin, untuk menumis
1. Ambil 1/2 sdt garam
1. Sediakan 1/2 sdt gula pasir
1. Ambil 1 sdt saus tiram
1. Sediakan secukupnya Air
1. Ambil  Saus Mentai :
1. Sediakan 2 Sdm mayonaise
1. Gunakan 2 sdm saus sambal
1. Siapkan  Topping :
1. Ambil secukupnya Keju parut
1. Ambil secukupnya Nori




<!--inarticleads2-->

##### Cara menyiapkan 🍚 Chicken Tuna Mentai Rice:

1. Siapkan semua bahan-bahan yang diperlukan.
1. Tumis bawang bombai hingga layu dan wangi kemudian masukan ayam dan tuna aduk hingga rata. Tambahkan air, garam, gula dan saus tiram. Cicipi dan koreksi rasa. Masak sampai ayam dan tuna matang serta air menyusut, angkat dan sisihkan.
1. Campurkan semua bahan campuran nasi aduk rata, test rasa. Lalu tata dalam loyang yang di alasi dengan aluminium foil sambil di tekan-tekan ringan supaya agak padat.
1. Membuat saus&#39;nya : Campurkan mayones dan saus sambal aduk rata.
1. Tahapan akhir: Tata ayam dan tuna di atas campuran nasi yang sudah di tekan-tekan tadi. Setelah itu tahap selanjutnya adalah menuangkan saus campuran mayones di atas ayam dan tuna kemudian tambahkan keju parut dan potongan Nori di atasnya. Lalu kemudian di panggang selama kurang lebih 20 menit pada suhu 100-150°c.
1. Setelah matang chicken tuna mentai siap untuk di sajikan.




Wah ternyata resep 🍚 chicken tuna mentai rice yang lezat simple ini mudah sekali ya! Anda Semua bisa mencobanya. Resep 🍚 chicken tuna mentai rice Sesuai sekali buat kamu yang sedang belajar memasak atau juga untuk kalian yang sudah jago memasak.

Apakah kamu ingin mulai mencoba buat resep 🍚 chicken tuna mentai rice enak simple ini? Kalau anda ingin, ayo kamu segera buruan siapkan alat dan bahan-bahannya, setelah itu bikin deh Resep 🍚 chicken tuna mentai rice yang mantab dan sederhana ini. Sungguh mudah kan. 

Oleh karena itu, daripada kita berfikir lama-lama, maka kita langsung hidangkan resep 🍚 chicken tuna mentai rice ini. Dijamin anda tak akan nyesel bikin resep 🍚 chicken tuna mentai rice lezat sederhana ini! Selamat mencoba dengan resep 🍚 chicken tuna mentai rice lezat sederhana ini di rumah masing-masing,ya!.

