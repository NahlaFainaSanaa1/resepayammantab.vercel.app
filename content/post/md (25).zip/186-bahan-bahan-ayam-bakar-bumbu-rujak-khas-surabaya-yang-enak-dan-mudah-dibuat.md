---
description: "Bahan-bahan Ayam bakar bumbu rujak khas surabaya yang enak dan Mudah Dibuat"
title: "Bahan-bahan Ayam bakar bumbu rujak khas surabaya yang enak dan Mudah Dibuat"
slug: 186-bahan-bahan-ayam-bakar-bumbu-rujak-khas-surabaya-yang-enak-dan-mudah-dibuat
date: 2021-04-08T23:14:08.364Z
image: https://img-global.cpcdn.com/recipes/9147a2c416d0d4e7/680x482cq70/ayam-bakar-bumbu-rujak-khas-surabaya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9147a2c416d0d4e7/680x482cq70/ayam-bakar-bumbu-rujak-khas-surabaya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9147a2c416d0d4e7/680x482cq70/ayam-bakar-bumbu-rujak-khas-surabaya-foto-resep-utama.jpg
author: Seth Craig
ratingvalue: 3.8
reviewcount: 11
recipeingredient:
- "500 gr ayam potong kecil"
- "20 ml santan kara"
- "2 sdm gula merah"
- "1 sdt asam jawa diseduh air panas 3 sdm"
- "Secukupnya minyak"
- "Secukupnya garam totole"
- " Bumbu halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "10 buah cabe keriting atau cabe kering juga bisa kalo kering warna jadi lebih merah bagus"
- "10 buah cabe rawit"
- "4 buah kemiri"
- "3 cm jahe"
- "3 cm kunyit"
- "1 sdt ketumbar"
- "1/2 sdt jinten"
- "1 sdm terasi"
- " Bumbu cemplung"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "1 buah sereh digeprek"
- "3 cm lengkuas digeprek"
recipeinstructions:
- "Tumis minyak sedikit dengan bumbu yang sudah dihaluskan dan bumbu cemplung hingga airnya menguap dan bumbu mengeluarkan minyak tidak bau mentah. Masukkan ayam, aduk hingga merata dengan bumbu."
- "Masukkan air, rebus hingga mendidih. Beri santan, gula merah, santan, dan aduk terus agar santan tidak pecah. Beri garam dan totole sesuai selera."
- "Satkan airnya hingga berkurang setengahnya dan bumbu menjadi kental. Tambahkan air asam sesuai selera sampai dirasa pas (jangan langsung banyak nanti terlalu kecut). Siapkan teflon untuk membakar ayamnya. Ayam dibakar dengan sesekali diolesi bumbunya. Jika sudah terbakar semua, campur lagi ayam bakar dengan bumbu. Ayam bakar siap dihidangkan, selesai."
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 101 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam bakar bumbu rujak khas surabaya](https://img-global.cpcdn.com/recipes/9147a2c416d0d4e7/680x482cq70/ayam-bakar-bumbu-rujak-khas-surabaya-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan olahan lezat untuk keluarga tercinta merupakan suatu hal yang membahagiakan untuk kita sendiri. Tugas seorang  wanita bukan hanya menjaga rumah saja, tapi anda juga harus menyediakan kebutuhan nutrisi tercukupi dan olahan yang dikonsumsi keluarga tercinta mesti enak.

Di masa  sekarang, kalian sebenarnya dapat mengorder olahan siap saji meski tanpa harus capek membuatnya dahulu. Namun ada juga orang yang memang ingin menghidangkan yang terlezat untuk keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan masakan kesukaan famili. 

Asam Manis Ayam Bumbu rujak ini merupakan Salah Satu kuliner khas Surabaya (Jawa Timur) untuk membuatnya simple dan tidak lamaYuk ikutin aja ya. Ayam bakar bumbu rujak merupakan salah satu masakan yang mempunyai cita rasa khas pedas manis. Disebut sebagai ayam bakar dengan bumbu rujak, karena memang rasanya seperti rujak pada umumnya, dengan dominasi rasa pedas manis tersebut.

Mungkinkah anda merupakan salah satu penikmat ayam bakar bumbu rujak khas surabaya?. Tahukah kamu, ayam bakar bumbu rujak khas surabaya adalah makanan khas di Nusantara yang saat ini disenangi oleh orang-orang dari berbagai wilayah di Nusantara. Anda dapat membuat ayam bakar bumbu rujak khas surabaya sendiri di rumahmu dan dapat dijadikan santapan kesukaanmu di akhir pekanmu.

Kita tidak perlu bingung jika kamu ingin menyantap ayam bakar bumbu rujak khas surabaya, sebab ayam bakar bumbu rujak khas surabaya tidak sulit untuk dicari dan kita pun bisa membuatnya sendiri di rumah. ayam bakar bumbu rujak khas surabaya bisa dibuat dengan beragam cara. Sekarang telah banyak banget cara kekinian yang membuat ayam bakar bumbu rujak khas surabaya semakin nikmat.

Resep ayam bakar bumbu rujak khas surabaya juga sangat mudah dibikin, lho. Kalian tidak perlu repot-repot untuk memesan ayam bakar bumbu rujak khas surabaya, karena Kamu bisa menghidangkan sendiri di rumah. Bagi Kalian yang ingin mencobanya, dibawah ini merupakan cara menyajikan ayam bakar bumbu rujak khas surabaya yang lezat yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam bakar bumbu rujak khas surabaya:

1. Sediakan 500 gr ayam, potong kecil
1. Gunakan 20 ml santan kara
1. Gunakan 2 sdm gula merah
1. Gunakan 1 sdt asam jawa diseduh air panas 3 sdm
1. Sediakan Secukupnya minyak
1. Sediakan Secukupnya garam, totole
1. Siapkan  Bumbu halus
1. Gunakan 10 siung bawang merah
1. Ambil 5 siung bawang putih
1. Ambil 10 buah cabe keriting (atau cabe kering juga bisa, kalo kering warna jadi lebih merah bagus)
1. Sediakan 10 buah cabe rawit
1. Sediakan 4 buah kemiri
1. Sediakan 3 cm jahe
1. Sediakan 3 cm kunyit
1. Sediakan 1 sdt ketumbar
1. Siapkan 1/2 sdt jinten
1. Sediakan 1 sdm terasi
1. Sediakan  Bumbu cemplung
1. Siapkan 4 lembar daun jeruk
1. Sediakan 2 lembar daun salam
1. Ambil 1 buah sereh digeprek
1. Gunakan 3 cm lengkuas digeprek


Ayam bumbu rujak adalah sebuah makanan Jawa khas yang terbuat dari daging ayam yang masih muda dan dibumbui bumbu merah yang digiling. Bumbu merah tersebut terbuat dari garam, bawang putih, bawang bombai dan cabai merah. Jerry membuat ayam bumbu rujak pada grand final MasterChef Indonesia yang dinilai enak oleh juri. Tata ayam bumbu rujak di piring saji. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam bakar bumbu rujak khas surabaya:

1. Tumis minyak sedikit dengan bumbu yang sudah dihaluskan dan bumbu cemplung hingga airnya menguap dan bumbu mengeluarkan minyak tidak bau mentah. Masukkan ayam, aduk hingga merata dengan bumbu.
1. Masukkan air, rebus hingga mendidih. Beri santan, gula merah, santan, dan aduk terus agar santan tidak pecah. Beri garam dan totole sesuai selera.
1. Satkan airnya hingga berkurang setengahnya dan bumbu menjadi kental. Tambahkan air asam sesuai selera sampai dirasa pas (jangan langsung banyak nanti terlalu kecut). Siapkan teflon untuk membakar ayamnya. Ayam dibakar dengan sesekali diolesi bumbunya. Jika sudah terbakar semua, campur lagi ayam bakar dengan bumbu. Ayam bakar siap dihidangkan, selesai.


Baca juga: Resep Ayam Panggang Bumbu Rujak, Rasanya Asam Pedas. Ayam bumbu rujak is a typical Javanese food made from chicken meat which is still young and uses a red basic spice then grilled. A red base is a spice made from salt, garlic, onion, and red chili. Called seasoning rujak because there are many spices besides chili. Ayam Bakar Bumbu Rujak adalah salah satu kuliner favorit Nusantara yang resepnya wajib dicoba untuk para pecinta kuliner. 

Wah ternyata cara membuat ayam bakar bumbu rujak khas surabaya yang enak sederhana ini enteng banget ya! Anda Semua dapat menghidangkannya. Cara Membuat ayam bakar bumbu rujak khas surabaya Cocok banget buat kalian yang baru belajar memasak ataupun juga untuk kamu yang telah ahli dalam memasak.

Tertarik untuk mencoba membikin resep ayam bakar bumbu rujak khas surabaya lezat sederhana ini? Kalau mau, ayo kamu segera buruan siapin peralatan dan bahan-bahannya, lalu buat deh Resep ayam bakar bumbu rujak khas surabaya yang mantab dan tidak ribet ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kalian diam saja, ayo kita langsung saja sajikan resep ayam bakar bumbu rujak khas surabaya ini. Pasti kamu tiidak akan nyesel membuat resep ayam bakar bumbu rujak khas surabaya nikmat tidak ribet ini! Selamat berkreasi dengan resep ayam bakar bumbu rujak khas surabaya enak tidak rumit ini di rumah masing-masing,oke!.

