---
description: "Cara membuat Ayam Geprek yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Geprek yang lezat dan Mudah Dibuat"
slug: 366-cara-membuat-ayam-geprek-yang-lezat-dan-mudah-dibuat
date: 2021-05-21T17:29:47.999Z
image: https://img-global.cpcdn.com/recipes/30d5adb134b41668/680x482cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/30d5adb134b41668/680x482cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/30d5adb134b41668/680x482cq70/ayam-geprek-foto-resep-utama.jpg
author: Jordan Quinn
ratingvalue: 3.6
reviewcount: 4
recipeingredient:
- " Bahan Tepung Ayam"
- "seperlunya Daging ayam"
- " Tepung bumbu krispi"
- " Bahan Sambel"
- "1 bawang putih"
- "secukupnya Cabai merah  hijau"
- " Garam"
- " Gula pasir"
recipeinstructions:
- "Marinasi ayam selama 2 jam"
- "Siapkan 1 wadah untuk tepung dan 1 wadah untuk air dingin"
- "Campurkan ayam dengan tepung (jangan di pencet&#34;dan jgn di tekan&#34; ayamnya) stlh itu celupkan ayam ke air dingin"
- "Ulangi lagi setelah dicelupkan ke air dingin tepungi lagi ayam (kunci agar ayam krispi) lalu celupkan lg ke air dingin) dan baluri lagi dengan tepung"
- "Panas kan minyak dan goreng ayam (minyak harus sudah panas)  Goreng dengan waktu :  5 menit api besar 5 menit api kecil 3 menit api besar"
- "Ayam siap untuk di geprek"
- "Untuk bumbu ayam geprek nya. Haluskan bawang putih dan cabai lalu kasih sedikit minyak goreng yg panas (utk mengurangi bau bawang putih) jgn lupa untuk menambah gula pasir"
- "Ayam geprek siap dihidangkan ✨"
categories:
- Resep
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 202 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/30d5adb134b41668/680x482cq70/ayam-geprek-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan olahan menggugah selera bagi keluarga merupakan hal yang menggembirakan untuk anda sendiri. Peran seorang ibu bukan cuma menangani rumah saja, tapi kamu pun wajib memastikan keperluan gizi tercukupi dan masakan yang disantap anak-anak wajib sedap.

Di zaman  sekarang, kalian memang mampu mengorder santapan yang sudah jadi meski tidak harus capek membuatnya terlebih dahulu. Tapi ada juga lho mereka yang selalu mau menyajikan yang terlezat bagi orang tercintanya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut berdasarkan kesukaan orang tercinta. 



Apakah anda adalah salah satu penikmat ayam geprek?. Tahukah kamu, ayam geprek merupakan hidangan khas di Nusantara yang sekarang disenangi oleh setiap orang di hampir setiap wilayah di Nusantara. Anda dapat menyajikan ayam geprek kreasi sendiri di rumah dan dapat dijadikan makanan kesenanganmu di hari libur.

Kamu tak perlu bingung jika kamu ingin memakan ayam geprek, lantaran ayam geprek sangat mudah untuk didapatkan dan juga kita pun bisa menghidangkannya sendiri di rumah. ayam geprek boleh dimasak dengan bermacam cara. Saat ini sudah banyak banget resep kekinian yang menjadikan ayam geprek semakin lebih nikmat.

Resep ayam geprek juga gampang sekali untuk dibuat, lho. Kalian tidak perlu capek-capek untuk membeli ayam geprek, karena Kamu bisa menyiapkan di rumah sendiri. Untuk Kita yang akan membuatnya, dibawah ini merupakan resep menyajikan ayam geprek yang mantab yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Geprek:

1. Ambil  Bahan Tepung Ayam
1. Ambil seperlunya Daging ayam
1. Siapkan  Tepung bumbu krispi
1. Siapkan  Bahan Sambel
1. Siapkan 1 bawang putih
1. Siapkan secukupnya Cabai merah + hijau
1. Siapkan  Garam
1. Gunakan  Gula pasir




<!--inarticleads2-->

##### Cara membuat Ayam Geprek:

1. Marinasi ayam selama 2 jam
1. Siapkan 1 wadah untuk tepung dan 1 wadah untuk air dingin
1. Campurkan ayam dengan tepung (jangan di pencet&#34;dan jgn di tekan&#34; ayamnya) stlh itu celupkan ayam ke air dingin
1. Ulangi lagi setelah dicelupkan ke air dingin tepungi lagi ayam (kunci agar ayam krispi) lalu celupkan lg ke air dingin) dan baluri lagi dengan tepung
1. Panas kan minyak dan goreng ayam (minyak harus sudah panas)  - Goreng dengan waktu :  - 5 menit api besar - 5 menit api kecil - 3 menit api besar
1. Ayam siap untuk di geprek
1. Untuk bumbu ayam geprek nya. Haluskan bawang putih dan cabai lalu kasih sedikit minyak goreng yg panas (utk mengurangi bau bawang putih) jgn lupa untuk menambah gula pasir
1. Ayam geprek siap dihidangkan ✨




Wah ternyata cara buat ayam geprek yang nikamt tidak ribet ini mudah sekali ya! Kamu semua mampu membuatnya. Cara Membuat ayam geprek Sangat cocok banget untuk kita yang baru belajar memasak ataupun bagi kalian yang telah pandai memasak.

Tertarik untuk mulai mencoba buat resep ayam geprek enak sederhana ini? Kalau tertarik, ayo kalian segera siapin alat dan bahan-bahannya, maka buat deh Resep ayam geprek yang mantab dan sederhana ini. Benar-benar taidak sulit kan. 

Maka, ketimbang kalian berfikir lama-lama, hayo kita langsung bikin resep ayam geprek ini. Dijamin kamu gak akan nyesel sudah buat resep ayam geprek enak tidak ribet ini! Selamat berkreasi dengan resep ayam geprek enak sederhana ini di tempat tinggal masing-masing,ya!.

