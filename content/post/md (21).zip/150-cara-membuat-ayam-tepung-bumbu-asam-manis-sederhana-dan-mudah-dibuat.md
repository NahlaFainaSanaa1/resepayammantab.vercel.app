---
description: "Cara membuat Ayam tepung, bumbu asam manis Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam tepung, bumbu asam manis Sederhana dan Mudah Dibuat"
slug: 150-cara-membuat-ayam-tepung-bumbu-asam-manis-sederhana-dan-mudah-dibuat
date: 2021-05-09T23:44:30.617Z
image: https://img-global.cpcdn.com/recipes/fcfab0fdf6a6b92e/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fcfab0fdf6a6b92e/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fcfab0fdf6a6b92e/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg
author: Lillie Dennis
ratingvalue: 3.8
reviewcount: 7
recipeingredient:
- "1/2 kg ayam tanpa tulang cuci bersih lalu iris tipis"
- "5 sdm tepung terigu"
- "1 sdm tepung tapioka"
- "3 siung bawang putih cincang"
- "1 sdt garam halus"
- "3 sdm saos sambal"
- "2 sdm saos tomat"
- "1 sdt merica bubuk"
- "1 buah bawang bombay cincang"
- "1 sdt minyak wijen"
- "1 sdt gula pasir"
- "2 sdm bawang putih yg sdh di haluskan"
- "1 butir telur ayam"
- " Penyedap rasa secukupnya"
recipeinstructions:
- "Ayam kasih perasan jeruk nipis terlebih dahulu tuk mengurangi amis, diamkan beberapa mnt sj, lalu masukan bumbu yg di haluskan bawang putih,garam aduk rata lalu masukan 1 butir telur aduk rata,merica masukan tepung terigu dan tepung tapioka aduk&#34; diamkan 5mnt"
- "Panaskan wajan yg sdh di beri minyak goreng,dg api sedang, ayam mulai di goreng,masak sampai kuning keemasan,sisihkan dalam piring lodor"
- "Buat saosnya,goreng bawang putih cincang sdh harum masukan bawang bombaynya aduk rata lalu beri 1 gelas air putih lalu masukan sedikit garam, gula pasir,merica bubuk saos tomat,saos sambal minyak wijen dan penyedap rasa aduk rata beri sedikit tepung yg sdh di larut kan dg &#34;rata air putih campur aduk, kira 2 mnt matang angkat"
- "Ayam yg telah di sajikan dipiring lodor di siram dg saos asam manis,sajikan selagi hangat"
categories:
- Resep
tags:
- ayam
- tepung
- bumbu

katakunci: ayam tepung bumbu 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam tepung, bumbu asam manis](https://img-global.cpcdn.com/recipes/fcfab0fdf6a6b92e/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg)

Andai anda seorang ibu, menyuguhkan hidangan mantab pada keluarga adalah suatu hal yang membahagiakan bagi kamu sendiri. Peran seorang istri Tidak sekedar menangani rumah saja, tetapi anda pun harus menyediakan kebutuhan nutrisi tercukupi dan olahan yang disantap keluarga tercinta harus sedap.

Di zaman  saat ini, anda sebenarnya mampu membeli olahan praktis tanpa harus capek membuatnya terlebih dahulu. Namun ada juga lho orang yang memang ingin memberikan makanan yang terbaik bagi orang yang dicintainya. Pasalnya, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut berdasarkan kesukaan famili. 



Mungkinkah anda salah satu penggemar ayam tepung, bumbu asam manis?. Tahukah kamu, ayam tepung, bumbu asam manis merupakan sajian khas di Indonesia yang kini disukai oleh kebanyakan orang dari berbagai tempat di Nusantara. Anda dapat menyajikan ayam tepung, bumbu asam manis sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di akhir pekan.

Kamu tidak usah bingung untuk mendapatkan ayam tepung, bumbu asam manis, karena ayam tepung, bumbu asam manis tidak sukar untuk dicari dan kamu pun boleh memasaknya sendiri di rumah. ayam tepung, bumbu asam manis bisa dimasak lewat berbagai cara. Kini telah banyak banget resep kekinian yang menjadikan ayam tepung, bumbu asam manis semakin mantap.

Resep ayam tepung, bumbu asam manis pun mudah dihidangkan, lho. Anda tidak perlu repot-repot untuk membeli ayam tepung, bumbu asam manis, tetapi Anda bisa menyajikan sendiri di rumah. Untuk Kalian yang ingin membuatnya, dibawah ini merupakan resep untuk membuat ayam tepung, bumbu asam manis yang nikamat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam tepung, bumbu asam manis:

1. Sediakan 1/2 kg ayam tanpa tulang cuci bersih lalu iris tipis
1. Ambil 5 sdm tepung terigu
1. Sediakan 1 sdm tepung tapioka
1. Siapkan 3 siung bawang putih cincang
1. Siapkan 1 sdt garam halus
1. Siapkan 3 sdm saos sambal
1. Gunakan 2 sdm saos tomat
1. Siapkan 1 sdt merica bubuk
1. Sediakan 1 buah bawang bombay cincang
1. Ambil 1 sdt minyak wijen
1. Ambil 1 sdt gula pasir
1. Ambil 2 sdm bawang putih yg sdh di haluskan
1. Siapkan 1 butir telur ayam
1. Siapkan  Penyedap rasa secukupnya




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam tepung, bumbu asam manis:

1. Ayam kasih perasan jeruk nipis terlebih dahulu tuk mengurangi amis, diamkan beberapa mnt sj, lalu masukan bumbu yg di haluskan bawang putih,garam aduk rata lalu masukan 1 butir telur aduk rata,merica masukan tepung terigu dan tepung tapioka aduk&#34; diamkan 5mnt
1. Panaskan wajan yg sdh di beri minyak goreng,dg api sedang, ayam mulai di goreng,masak sampai kuning keemasan,sisihkan dalam piring lodor
1. Buat saosnya,goreng bawang putih cincang sdh harum masukan bawang bombaynya aduk rata lalu beri 1 gelas air putih lalu masukan sedikit garam, gula pasir,merica bubuk saos tomat,saos sambal minyak wijen dan penyedap rasa aduk rata beri sedikit tepung yg sdh di larut kan dg &#34;rata air putih campur aduk, kira 2 mnt matang angkat
1. Ayam yg telah di sajikan dipiring lodor di siram dg saos asam manis,sajikan selagi hangat




Ternyata cara buat ayam tepung, bumbu asam manis yang lezat tidak ribet ini gampang sekali ya! Kita semua mampu membuatnya. Cara Membuat ayam tepung, bumbu asam manis Cocok banget buat kamu yang baru belajar memasak ataupun untuk kamu yang telah ahli dalam memasak.

Apakah kamu tertarik mencoba membuat resep ayam tepung, bumbu asam manis lezat simple ini? Kalau tertarik, ayo kamu segera buruan siapkan peralatan dan bahannya, kemudian bikin deh Resep ayam tepung, bumbu asam manis yang lezat dan tidak ribet ini. Sungguh taidak sulit kan. 

Jadi, daripada kamu berfikir lama-lama, hayo langsung aja sajikan resep ayam tepung, bumbu asam manis ini. Dijamin anda gak akan menyesal bikin resep ayam tepung, bumbu asam manis lezat tidak ribet ini! Selamat berkreasi dengan resep ayam tepung, bumbu asam manis lezat tidak rumit ini di rumah kalian sendiri,oke!.

