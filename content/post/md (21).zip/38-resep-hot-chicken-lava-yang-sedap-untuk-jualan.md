---
description: "Resep Hot chicken lava yang sedap Untuk Jualan"
title: "Resep Hot chicken lava yang sedap Untuk Jualan"
slug: 38-resep-hot-chicken-lava-yang-sedap-untuk-jualan
date: 2021-03-10T04:03:29.401Z
image: https://img-global.cpcdn.com/recipes/56aecc9501741eb4/680x482cq70/hot-chicken-lava-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/56aecc9501741eb4/680x482cq70/hot-chicken-lava-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/56aecc9501741eb4/680x482cq70/hot-chicken-lava-foto-resep-utama.jpg
author: Henry Alexander
ratingvalue: 3.6
reviewcount: 13
recipeingredient:
- " Bahan pertama"
- "1/4 kg ayam"
- "1 sdt garlic bubuk"
- "1 sdt mrica bubuk"
- "1 sdt masako ayam"
- " Bahan kedua"
- "1/4 kg tepung serbaguna"
- "1 btr telur"
- "secukupnya minyak"
- " Bahan saus"
- "1 siung bawang putih"
- "20 cabe rawit"
- "sedikit garam"
- "3 sdm saus cabai"
- "sedikit mrica bubuk"
- "secukupnya air"
- "1 sdm minyak goreng"
recipeinstructions:
- "Potong ayam sesuai selera, campurkan bahan semua bahan pertama, aduk rata, diamkan di kulkas selama minimal 3 jam"
- "Panaskan minyak, siapkan tepung, kocok telur, masukkan ayam ke tepung kering, kemudian ke telur, dan ke tepung kering lagi, goreng dalam minyam panas dengan api sedang sampai matang kecoklatan"
- "Untuk sausnya, uleg cabe rawit dan bawang putih, tumis dg minyak sampai harum, masukkan saus cabai, air dan mrica, masak hingga kental, matikan api kemudian siramkan di atas ayam yg sudah di goreng"
categories:
- Resep
tags:
- hot
- chicken
- lava

katakunci: hot chicken lava 
nutrition: 136 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dinner

---


![Hot chicken lava](https://img-global.cpcdn.com/recipes/56aecc9501741eb4/680x482cq70/hot-chicken-lava-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, mempersiapkan panganan nikmat bagi keluarga tercinta merupakan hal yang memuaskan bagi kamu sendiri. Tugas seorang ibu bukan sekedar menangani rumah saja, tetapi kamu pun harus memastikan keperluan nutrisi tercukupi dan juga hidangan yang disantap orang tercinta mesti enak.

Di era  saat ini, anda sebenarnya mampu memesan masakan jadi meski tanpa harus susah membuatnya terlebih dahulu. Tetapi banyak juga lho orang yang selalu mau menyajikan yang terbaik untuk keluarganya. Pasalnya, memasak yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan keluarga. 



Mungkinkah anda adalah seorang penikmat hot chicken lava?. Asal kamu tahu, hot chicken lava adalah sajian khas di Nusantara yang kini digemari oleh orang-orang di hampir setiap tempat di Indonesia. Anda dapat memasak hot chicken lava sendiri di rumah dan boleh dijadikan camilan kesukaanmu di hari libur.

Anda tak perlu bingung untuk memakan hot chicken lava, sebab hot chicken lava tidak sulit untuk dicari dan juga kalian pun dapat mengolahnya sendiri di rumah. hot chicken lava boleh dimasak lewat berbagai cara. Saat ini ada banyak cara modern yang menjadikan hot chicken lava lebih lezat.

Resep hot chicken lava juga gampang sekali untuk dibikin, lho. Kalian tidak perlu ribet-ribet untuk membeli hot chicken lava, karena Kita bisa menghidangkan di rumah sendiri. Bagi Kalian yang hendak menyajikannya, berikut ini cara untuk menyajikan hot chicken lava yang mantab yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Hot chicken lava:

1. Ambil  Bahan pertama
1. Ambil 1/4 kg ayam
1. Sediakan 1 sdt garlic bubuk
1. Siapkan 1 sdt mrica bubuk
1. Siapkan 1 sdt masako ayam
1. Gunakan  Bahan kedua
1. Ambil 1/4 kg tepung serbaguna
1. Sediakan 1 btr telur
1. Sediakan secukupnya minyak
1. Siapkan  Bahan saus
1. Sediakan 1 siung bawang putih
1. Gunakan 20 cabe rawit
1. Sediakan sedikit garam
1. Siapkan 3 sdm saus cabai
1. Siapkan sedikit mrica bubuk
1. Gunakan secukupnya air
1. Sediakan 1 sdm minyak goreng




<!--inarticleads2-->

##### Cara menyiapkan Hot chicken lava:

1. Potong ayam sesuai selera, campurkan bahan semua bahan pertama, aduk rata, diamkan di kulkas selama minimal 3 jam
1. Panaskan minyak, siapkan tepung, kocok telur, masukkan ayam ke tepung kering, kemudian ke telur, dan ke tepung kering lagi, goreng dalam minyam panas dengan api sedang sampai matang kecoklatan
1. Untuk sausnya, uleg cabe rawit dan bawang putih, tumis dg minyak sampai harum, masukkan saus cabai, air dan mrica, masak hingga kental, matikan api kemudian siramkan di atas ayam yg sudah di goreng




Wah ternyata cara membuat hot chicken lava yang enak sederhana ini mudah sekali ya! Kalian semua bisa mencobanya. Resep hot chicken lava Sesuai sekali untuk anda yang sedang belajar memasak maupun juga untuk anda yang telah pandai dalam memasak.

Tertarik untuk mencoba membikin resep hot chicken lava enak simple ini? Kalau ingin, ayo kalian segera siapkan peralatan dan bahan-bahannya, kemudian bikin deh Resep hot chicken lava yang enak dan tidak rumit ini. Sungguh taidak sulit kan. 

Maka dari itu, daripada kita diam saja, hayo langsung aja sajikan resep hot chicken lava ini. Pasti kamu tiidak akan menyesal sudah membuat resep hot chicken lava lezat simple ini! Selamat berkreasi dengan resep hot chicken lava nikmat sederhana ini di rumah sendiri,ya!.

