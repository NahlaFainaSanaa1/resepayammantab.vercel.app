---
description: "Cara membuat Suwir Ayam Sambal Matah (Rice Bowl) 🍚🍚 yang nikmat Untuk Jualan"
title: "Cara membuat Suwir Ayam Sambal Matah (Rice Bowl) 🍚🍚 yang nikmat Untuk Jualan"
slug: 188-cara-membuat-suwir-ayam-sambal-matah-rice-bowl-yang-nikmat-untuk-jualan
date: 2021-03-30T05:23:17.277Z
image: https://img-global.cpcdn.com/recipes/66b15b5b39abd665/680x482cq70/suwir-ayam-sambal-matah-rice-bowl-🍚🍚-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/66b15b5b39abd665/680x482cq70/suwir-ayam-sambal-matah-rice-bowl-🍚🍚-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/66b15b5b39abd665/680x482cq70/suwir-ayam-sambal-matah-rice-bowl-🍚🍚-foto-resep-utama.jpg
author: Millie Garrett
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- "1/4 Kg Daging Ayam"
- "1/2 Bawang Bombay"
- "4 Daun Bawang"
- "3-4 Porsi Nasi Putih"
- " Bumbu ayam suwir "
- "5 Siung Bawang Merah"
- "3 Siung Bawang Putih"
- "1/4 SDT Pala"
- "1 SDT Merica Bubuk"
- "1 Batang Sereh"
- "2 Daun Salam"
- " Jahe"
- " Gula"
- " Garam"
- " Penyedap rasa optional"
- " Air"
- " Minyak goreng menumis bumbu"
- " Sambal Matah "
- "3 Siung Bawang Merah"
- "1 Siung Bawang Putih"
- "9 Cabe Rawit sesuai selera"
- "1 Lembar Daun Jeruk"
- "1 Batang Sereh"
- "1/2 Jeruk Nipis ambil air"
- " Terasi"
- " Gula"
- " Garam"
- " Minyak Goreng Panas secukupnya"
recipeinstructions:
- "Rebus daging ayam hingga matang, lalu suwir-suwir. Setelah itu potong daun bawang dan bawang bombay, sisihkan."
- "Haluskan bawang merah, bawang putih, pala, dan garam sebagai bahan bumbu untuk membuat ayam suwir."
- "Panaskan minyak goreng, lalu tumis sebentar bawang bombay hingga harum. Setelah itu masukkan bumbu halus, sereh dan jahe yang telah digeprek berserta daun salam. Tumis hingga bumbu halus."
- "Masukkan ayam yang telah disuwir ke dalam tumisan bumbu. Tambahkan sedikit air agar tidak terlalu kering, masukkan merica dan tambahkan kembali gula, garam sesuai selera apabila rasa masih kurang. Masak hingga semua ayam dan bumbu tercampur."
- "Membuat sambal matah : - Potong tipis-tipis bawang merah, bawang putih, cabai, sereh, dan daun jeruk. Masukkan ke dalam mangkuk kecil, lalu tambahkan sedikit gula, garam, terasi, dan perasan air jeruk nipis. Aduk rata dan sisihkan..  - Panaskan minyak kelapa hingga panas, lalu siramkan minyak ke dalam mangkuk bahan sambal matah. Aduk rata semua bahan hingga tercampur rata."
- "Siapkan mangkuk yang berisi nasi hangat, lalu tambahkan ayam suwir dan sambal matah diatasnya. Rice bowl ayam suwir sambal matah siap disajikan."
categories:
- Resep
tags:
- suwir
- ayam
- sambal

katakunci: suwir ayam sambal 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Lunch

---


![Suwir Ayam Sambal Matah (Rice Bowl) 🍚🍚](https://img-global.cpcdn.com/recipes/66b15b5b39abd665/680x482cq70/suwir-ayam-sambal-matah-rice-bowl-🍚🍚-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan hidangan nikmat pada famili adalah suatu hal yang menggembirakan bagi kita sendiri. Peran seorang ibu bukan sekedar mengatur rumah saja, tapi anda pun harus memastikan keperluan nutrisi terpenuhi dan juga panganan yang dikonsumsi orang tercinta harus menggugah selera.

Di masa  sekarang, kita memang bisa mengorder panganan jadi tidak harus ribet membuatnya terlebih dahulu. Tapi banyak juga orang yang selalu mau menghidangkan yang terenak bagi orang tercintanya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan selera keluarga. 



Apakah anda adalah seorang penyuka suwir ayam sambal matah (rice bowl) 🍚🍚?. Tahukah kamu, suwir ayam sambal matah (rice bowl) 🍚🍚 adalah makanan khas di Nusantara yang kini digemari oleh kebanyakan orang dari berbagai tempat di Indonesia. Anda dapat menghidangkan suwir ayam sambal matah (rice bowl) 🍚🍚 hasil sendiri di rumah dan dapat dijadikan hidangan favorit di akhir pekanmu.

Kita tidak perlu bingung untuk mendapatkan suwir ayam sambal matah (rice bowl) 🍚🍚, sebab suwir ayam sambal matah (rice bowl) 🍚🍚 mudah untuk dicari dan anda pun boleh membuatnya sendiri di tempatmu. suwir ayam sambal matah (rice bowl) 🍚🍚 dapat diolah memalui berbagai cara. Kini pun telah banyak cara modern yang membuat suwir ayam sambal matah (rice bowl) 🍚🍚 lebih mantap.

Resep suwir ayam sambal matah (rice bowl) 🍚🍚 juga sangat mudah untuk dibuat, lho. Kita tidak perlu ribet-ribet untuk membeli suwir ayam sambal matah (rice bowl) 🍚🍚, tetapi Kita bisa menyiapkan di rumah sendiri. Untuk Anda yang hendak menghidangkannya, di bawah ini adalah cara membuat suwir ayam sambal matah (rice bowl) 🍚🍚 yang enak yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Suwir Ayam Sambal Matah (Rice Bowl) 🍚🍚:

1. Ambil 1/4 Kg Daging Ayam
1. Siapkan 1/2 Bawang Bombay
1. Gunakan 4 Daun Bawang
1. Gunakan 3-4 Porsi Nasi Putih
1. Gunakan  Bumbu ayam suwir :
1. Siapkan 5 Siung Bawang Merah
1. Sediakan 3 Siung Bawang Putih
1. Sediakan 1/4 SDT Pala
1. Gunakan 1 SDT Merica Bubuk
1. Gunakan 1 Batang Sereh
1. Sediakan 2 Daun Salam
1. Ambil  Jahe
1. Gunakan  Gula
1. Gunakan  Garam
1. Gunakan  Penyedap rasa (optional)
1. Siapkan  Air
1. Siapkan  Minyak goreng (menumis bumbu)
1. Siapkan  Sambal Matah :
1. Siapkan 3 Siung Bawang Merah
1. Siapkan 1 Siung Bawang Putih
1. Sediakan 9 Cabe Rawit (sesuai selera)
1. Siapkan 1 Lembar Daun Jeruk
1. Siapkan 1 Batang Sereh
1. Siapkan 1/2 Jeruk Nipis (ambil air)
1. Siapkan  Terasi
1. Gunakan  Gula
1. Siapkan  Garam
1. Gunakan  Minyak Goreng Panas (secukupnya)




<!--inarticleads2-->

##### Cara menyiapkan Suwir Ayam Sambal Matah (Rice Bowl) 🍚🍚:

1. Rebus daging ayam hingga matang, lalu suwir-suwir. Setelah itu potong daun bawang dan bawang bombay, sisihkan.
1. Haluskan bawang merah, bawang putih, pala, dan garam sebagai bahan bumbu untuk membuat ayam suwir.
1. Panaskan minyak goreng, lalu tumis sebentar bawang bombay hingga harum. Setelah itu masukkan bumbu halus, sereh dan jahe yang telah digeprek berserta daun salam. Tumis hingga bumbu halus.
1. Masukkan ayam yang telah disuwir ke dalam tumisan bumbu. Tambahkan sedikit air agar tidak terlalu kering, masukkan merica dan tambahkan kembali gula, garam sesuai selera apabila rasa masih kurang. Masak hingga semua ayam dan bumbu tercampur.
1. Membuat sambal matah : - - Potong tipis-tipis bawang merah, bawang putih, cabai, sereh, dan daun jeruk. Masukkan ke dalam mangkuk kecil, lalu tambahkan sedikit gula, garam, terasi, dan perasan air jeruk nipis. Aduk rata dan sisihkan..  - - Panaskan minyak kelapa hingga panas, lalu siramkan minyak ke dalam mangkuk bahan sambal matah. Aduk rata semua bahan hingga tercampur rata.
1. Siapkan mangkuk yang berisi nasi hangat, lalu tambahkan ayam suwir dan sambal matah diatasnya. Rice bowl ayam suwir sambal matah siap disajikan.




Wah ternyata cara buat suwir ayam sambal matah (rice bowl) 🍚🍚 yang enak simple ini gampang sekali ya! Semua orang bisa mencobanya. Cara buat suwir ayam sambal matah (rice bowl) 🍚🍚 Sangat cocok banget untuk anda yang sedang belajar memasak ataupun juga bagi kamu yang telah ahli memasak.

Tertarik untuk mencoba membikin resep suwir ayam sambal matah (rice bowl) 🍚🍚 mantab sederhana ini? Kalau kamu ingin, ayo kalian segera buruan siapkan alat dan bahannya, lantas bikin deh Resep suwir ayam sambal matah (rice bowl) 🍚🍚 yang enak dan tidak rumit ini. Sungguh mudah kan. 

Maka, ketimbang kalian berlama-lama, hayo kita langsung buat resep suwir ayam sambal matah (rice bowl) 🍚🍚 ini. Dijamin kalian tiidak akan menyesal sudah membuat resep suwir ayam sambal matah (rice bowl) 🍚🍚 lezat tidak ribet ini! Selamat berkreasi dengan resep suwir ayam sambal matah (rice bowl) 🍚🍚 lezat sederhana ini di tempat tinggal kalian masing-masing,ya!.

