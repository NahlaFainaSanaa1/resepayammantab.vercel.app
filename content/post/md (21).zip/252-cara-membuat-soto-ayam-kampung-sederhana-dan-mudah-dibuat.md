---
description: "Cara membuat Soto ayam kampung Sederhana dan Mudah Dibuat"
title: "Cara membuat Soto ayam kampung Sederhana dan Mudah Dibuat"
slug: 252-cara-membuat-soto-ayam-kampung-sederhana-dan-mudah-dibuat
date: 2021-03-06T08:19:17.358Z
image: https://img-global.cpcdn.com/recipes/44ade79c18fd416b/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/44ade79c18fd416b/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/44ade79c18fd416b/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
author: Chris Blair
ratingvalue: 3.2
reviewcount: 14
recipeingredient:
- "500 gr ayam kampung"
- "1 batang daun seledri"
- "1 batang daun bawang besar"
- "1 buah serai geprek"
- "1 daun jeruk"
- "secukupnya Garam"
- " Kaldu bubuk"
- "5 buah cabe rawit dicemplungkan aja"
- "1/2 buah jeruk nipis"
- " Minyak untuk menumis"
- " Air"
- " Bumbu halus "
- "2 bawang putih besar"
- "6 bawang merah"
- "1/2 kemiri"
- "1 sdt ketumbar"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 ruas jari kunyit"
- "1 sdt merica"
recipeinstructions:
- "Haluskan bumbu dengan blender. Tumis bumbu halus dengan serai dan daun jeruk hingga harum. Tiriskan"
- "Didihkan air dan rebus ayam kampung hingga matang (sampai daging empuk)"
- "Setelah ayam matang, masukkan bumbu halus. Aduk hingga bumbu tercampur rata. Didihkan kembali hingga bumbu meresap ke ayam."
- "Tambahkan garam dan kaldu bubuk. Kemudian masukkan irisan daun bawanfg dan seledri. Tunggu hingga meresap. Koreksi rasa."
- "Jika sudah pas. Matikan kompor. Tambahkan perasan jeruk nipis."
- "Lebih nikmat disajikan dengan bihun, kecambah, dan irisan kubis 😊"
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 218 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dinner

---


![Soto ayam kampung](https://img-global.cpcdn.com/recipes/44ade79c18fd416b/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyajikan masakan enak kepada keluarga adalah suatu hal yang membahagiakan untuk anda sendiri. Tugas seorang ibu bukan saja menangani rumah saja, namun anda juga harus memastikan kebutuhan gizi tercukupi dan juga hidangan yang dikonsumsi keluarga tercinta mesti nikmat.

Di masa  saat ini, anda memang dapat mengorder santapan jadi walaupun tanpa harus susah mengolahnya dulu. Tapi banyak juga orang yang memang mau menyajikan yang terlezat bagi orang yang dicintainya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai masakan kesukaan orang tercinta. 



Mungkinkah anda seorang penyuka soto ayam kampung?. Tahukah kamu, soto ayam kampung merupakan makanan khas di Indonesia yang saat ini digemari oleh banyak orang di hampir setiap wilayah di Indonesia. Anda bisa membuat soto ayam kampung sendiri di rumah dan boleh jadi camilan kegemaranmu di akhir pekanmu.

Kamu tidak usah bingung jika kamu ingin memakan soto ayam kampung, sebab soto ayam kampung gampang untuk ditemukan dan kita pun boleh memasaknya sendiri di tempatmu. soto ayam kampung boleh dibuat memalui beraneka cara. Kini pun ada banyak cara modern yang menjadikan soto ayam kampung lebih mantap.

Resep soto ayam kampung pun sangat gampang dibikin, lho. Kamu jangan repot-repot untuk membeli soto ayam kampung, lantaran Kalian dapat menyiapkan sendiri di rumah. Bagi Kalian yang akan mencobanya, inilah resep menyajikan soto ayam kampung yang enak yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Soto ayam kampung:

1. Sediakan 500 gr ayam kampung
1. Gunakan 1 batang daun seledri
1. Sediakan 1 batang daun bawang besar
1. Ambil 1 buah serai geprek
1. Siapkan 1 daun jeruk
1. Sediakan secukupnya Garam
1. Ambil  Kaldu bubuk
1. Ambil 5 buah cabe rawit (dicemplungkan aja)
1. Siapkan 1/2 buah jeruk nipis
1. Siapkan  Minyak untuk menumis
1. Siapkan  Air
1. Siapkan  Bumbu halus :
1. Sediakan 2 bawang putih besar
1. Sediakan 6 bawang merah
1. Ambil 1/2 kemiri
1. Siapkan 1 sdt ketumbar
1. Gunakan 1 ruas jahe
1. Gunakan 1 ruas lengkuas
1. Ambil 1 ruas jari kunyit
1. Siapkan 1 sdt merica




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto ayam kampung:

1. Haluskan bumbu dengan blender. Tumis bumbu halus dengan serai dan daun jeruk hingga harum. Tiriskan
1. Didihkan air dan rebus ayam kampung hingga matang (sampai daging empuk)
1. Setelah ayam matang, masukkan bumbu halus. Aduk hingga bumbu tercampur rata. Didihkan kembali hingga bumbu meresap ke ayam.
1. Tambahkan garam dan kaldu bubuk. Kemudian masukkan irisan daun bawanfg dan seledri. Tunggu hingga meresap. Koreksi rasa.
1. Jika sudah pas. Matikan kompor. Tambahkan perasan jeruk nipis.
1. Lebih nikmat disajikan dengan bihun, kecambah, dan irisan kubis 😊




Ternyata cara membuat soto ayam kampung yang mantab tidak rumit ini gampang sekali ya! Anda Semua mampu menghidangkannya. Cara buat soto ayam kampung Sangat cocok banget buat anda yang baru mau belajar memasak maupun juga bagi kalian yang sudah hebat memasak.

Tertarik untuk mencoba membuat resep soto ayam kampung lezat simple ini? Kalau kamu tertarik, ayo kamu segera buruan siapkan peralatan dan bahan-bahannya, maka bikin deh Resep soto ayam kampung yang enak dan simple ini. Benar-benar mudah kan. 

Oleh karena itu, daripada kalian diam saja, ayo langsung aja hidangkan resep soto ayam kampung ini. Dijamin kamu tiidak akan menyesal sudah buat resep soto ayam kampung lezat tidak ribet ini! Selamat berkreasi dengan resep soto ayam kampung lezat sederhana ini di tempat tinggal sendiri,ya!.

