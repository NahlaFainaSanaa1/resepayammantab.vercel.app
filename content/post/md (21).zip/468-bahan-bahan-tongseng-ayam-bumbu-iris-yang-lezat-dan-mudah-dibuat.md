---
description: "Bahan-bahan Tongseng ayam bumbu iris yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Tongseng ayam bumbu iris yang lezat dan Mudah Dibuat"
slug: 468-bahan-bahan-tongseng-ayam-bumbu-iris-yang-lezat-dan-mudah-dibuat
date: 2021-04-14T19:02:15.517Z
image: https://img-global.cpcdn.com/recipes/169d7d91778bf61e/680x482cq70/tongseng-ayam-bumbu-iris-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/169d7d91778bf61e/680x482cq70/tongseng-ayam-bumbu-iris-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/169d7d91778bf61e/680x482cq70/tongseng-ayam-bumbu-iris-foto-resep-utama.jpg
author: Richard Atkins
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- "500 gr ayam potonhpotong"
- "4 buah tomat hijau dan merah belah 6"
- "3 lembar kol irisiris"
- "1 sdm gula semut"
- "1 sdt merica"
- "250 ml santan"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "secukupnya Kecap"
- "secukupnya Garam"
- "secukupnya Kaldu jamur"
- "iris Bumbu"
- "7 buah cabe merah keriting irisiris"
- "11 biji cabe rawit"
- "5 siung bawang merah iisiris"
- "4 siung bawang putih irisiris"
- "2 btg serai iris serong"
- "2 ruas jari lengkuas iris serong"
- "2 cm kunyit iris serong"
- "1 ruas jari jahe iris serong"
recipeinstructions:
- "Cuci bersih ayam lalu sisihkan"
- "Panaskan minyak tumis bawang merah,bawang putih,serai,lengkuas,daun salam,daun jeruk,jahe,kunyit dankedua cabe sampai harum"
- "Kemuadian masukan ayam aduk rata sampai ayam berubah warna.."
- "Lalu tambahkan santan aduk rata lagi dan beri gula,garam,merica,kecap dan kaldu jamur aduk rata..tunggu sampai semua bumbu meresap dan ayam matang,lalu koreksi rasanya dirasapas.."
- "Masukan kol dan tomat aduk rata tunggu sebentar sampai mendidih lalu angkat sajikan selamat mencoba...;)"
categories:
- Resep
tags:
- tongseng
- ayam
- bumbu

katakunci: tongseng ayam bumbu 
nutrition: 297 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Lunch

---


![Tongseng ayam bumbu iris](https://img-global.cpcdn.com/recipes/169d7d91778bf61e/680x482cq70/tongseng-ayam-bumbu-iris-foto-resep-utama.jpg)

Selaku seorang ibu, menyajikan hidangan sedap untuk famili adalah suatu hal yang menyenangkan untuk anda sendiri. Kewajiban seorang ibu bukan saja menjaga rumah saja, tapi anda pun wajib menyediakan keperluan nutrisi tercukupi dan juga panganan yang disantap keluarga tercinta harus nikmat.

Di zaman  saat ini, kita memang bisa memesan olahan praktis tidak harus capek mengolahnya terlebih dahulu. Namun banyak juga orang yang memang ingin menyajikan yang terenak bagi orang tercintanya. Karena, menyajikan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera keluarga tercinta. 



Mungkinkah anda adalah seorang penikmat tongseng ayam bumbu iris?. Tahukah kamu, tongseng ayam bumbu iris adalah hidangan khas di Indonesia yang sekarang digemari oleh banyak orang dari berbagai tempat di Nusantara. Anda bisa membuat tongseng ayam bumbu iris sendiri di rumahmu dan boleh dijadikan santapan kegemaranmu di akhir pekan.

Kita tak perlu bingung untuk memakan tongseng ayam bumbu iris, karena tongseng ayam bumbu iris tidak sulit untuk dicari dan juga kalian pun boleh memasaknya sendiri di tempatmu. tongseng ayam bumbu iris dapat diolah memalui beragam cara. Kini ada banyak banget resep modern yang menjadikan tongseng ayam bumbu iris lebih lezat.

Resep tongseng ayam bumbu iris juga sangat mudah dibikin, lho. Anda tidak usah capek-capek untuk membeli tongseng ayam bumbu iris, lantaran Kalian dapat menyiapkan ditempatmu. Bagi Kamu yang hendak menghidangkannya, berikut ini cara membuat tongseng ayam bumbu iris yang lezat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Tongseng ayam bumbu iris:

1. Siapkan 500 gr ayam potonh-potong
1. Siapkan 4 buah tomat hijau dan merah belah 6
1. Gunakan 3 lembar kol iris-iris
1. Sediakan 1 sdm gula semut
1. Siapkan 1 sdt merica
1. Siapkan 250 ml santan
1. Sediakan 2 lembar daun salam
1. Sediakan 2 lembar daun jeruk
1. Gunakan secukupnya Kecap
1. Siapkan secukupnya Garam
1. Ambil secukupnya Kaldu jamur
1. Gunakan iris Bumbu
1. Sediakan 7 buah cabe merah keriting iris-iris
1. Sediakan 11 biji cabe rawit
1. Ambil 5 siung bawang merah iis-iris
1. Sediakan 4 siung bawang putih iris-iris
1. Gunakan 2 btg serai iris serong
1. Sediakan 2 ruas jari lengkuas iris serong
1. Gunakan 2 cm kunyit iris serong
1. Gunakan 1 ruas jari jahe iris serong




<!--inarticleads2-->

##### Cara menyiapkan Tongseng ayam bumbu iris:

1. Cuci bersih ayam lalu sisihkan
1. Panaskan minyak tumis bawang merah,bawang putih,serai,lengkuas,daun salam,daun jeruk,jahe,kunyit dankedua cabe sampai harum
1. Kemuadian masukan ayam aduk rata sampai ayam berubah warna..
1. Lalu tambahkan santan aduk rata lagi dan beri gula,garam,merica,kecap dan kaldu jamur aduk rata..tunggu sampai semua bumbu meresap dan ayam matang,lalu koreksi rasanya dirasapas..
1. Masukan kol dan tomat aduk rata tunggu sebentar sampai mendidih lalu angkat sajikan selamat mencoba...;)




Ternyata resep tongseng ayam bumbu iris yang enak tidak rumit ini gampang banget ya! Kamu semua bisa memasaknya. Cara buat tongseng ayam bumbu iris Sangat cocok sekali untuk kita yang baru akan belajar memasak atau juga bagi kalian yang sudah lihai memasak.

Tertarik untuk mulai mencoba bikin resep tongseng ayam bumbu iris nikmat simple ini? Kalau kamu mau, ayo kalian segera siapin alat dan bahannya, setelah itu bikin deh Resep tongseng ayam bumbu iris yang nikmat dan tidak rumit ini. Sangat gampang kan. 

Jadi, ketimbang kita berlama-lama, maka kita langsung saja hidangkan resep tongseng ayam bumbu iris ini. Dijamin kalian gak akan nyesel sudah membuat resep tongseng ayam bumbu iris mantab simple ini! Selamat mencoba dengan resep tongseng ayam bumbu iris nikmat tidak rumit ini di tempat tinggal kalian masing-masing,ya!.

