---
description: "Cara memasak Coto ayam khas makassar yang lezat dan Mudah Dibuat"
title: "Cara memasak Coto ayam khas makassar yang lezat dan Mudah Dibuat"
slug: 54-cara-memasak-coto-ayam-khas-makassar-yang-lezat-dan-mudah-dibuat
date: 2021-05-18T13:25:51.934Z
image: https://img-global.cpcdn.com/recipes/d9997b3d696832d5/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d9997b3d696832d5/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d9997b3d696832d5/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
author: Jonathan Soto
ratingvalue: 4.8
reviewcount: 8
recipeingredient:
- "1/2 kilo ayam"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1/2 sendok teh pala bubuk"
- "Secukupnya merica bubuk"
- "Secukupnya kaldu ayam"
- "Secukupnya garam"
- "Secukupnya gula merah"
- "2 sendok makan air asam jawa"
- "Secukupnya Air"
- " Minyak untuk menumis bumbu"
- " Bumbu halus"
- "250 gram kacang tanah"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "2 btang serai"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "2 butir kemiri"
- " Bumbu pelengkap"
- " Daun bawang"
- " Daun seledri"
- " Bawang goreng"
- " Jeruk nipis"
- " Kecap"
- " Sambel"
recipeinstructions:
- "Cuci bersih ayam dan potong kecil kecil"
- "Rebus daging ayam sampai empuk"
- "Haluskan bumbu halus, kemudian masukkan kedalam minyak, masukkan daun salam dan daun jeruk tnggu sampai bumbu kering (sisa bumbu halus dan minyak)"
- "Campurkan bumbu halus kedalam rebusan daging ayam, tambahkan pala bubuk, merica, air asam, gula merah, kaldu dan garam. Cek rasa"
- "Jika sudah tercampur angkat dan coto ayam siap disajikan."
- "Tambahkan bumbu pelengkap supaya lebih nikmat..."
categories:
- Resep
tags:
- coto
- ayam
- khas

katakunci: coto ayam khas 
nutrition: 231 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dinner

---


![Coto ayam khas makassar](https://img-global.cpcdn.com/recipes/d9997b3d696832d5/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg)

Selaku seorang ibu, menyuguhkan santapan sedap buat famili adalah suatu hal yang memuaskan untuk kamu sendiri. Tanggung jawab seorang istri bukan sekedar menangani rumah saja, namun kamu juga harus memastikan keperluan gizi tercukupi dan juga masakan yang dimakan keluarga tercinta mesti enak.

Di waktu  saat ini, kita memang bisa memesan olahan instan tanpa harus ribet memasaknya dahulu. Tetapi ada juga lho orang yang selalu mau menyajikan yang terenak bagi keluarganya. Pasalnya, memasak sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut berdasarkan kesukaan orang tercinta. 



Apakah anda merupakan seorang penggemar coto ayam khas makassar?. Asal kamu tahu, coto ayam khas makassar adalah sajian khas di Nusantara yang sekarang digemari oleh banyak orang dari berbagai tempat di Nusantara. Kamu dapat menghidangkan coto ayam khas makassar kreasi sendiri di rumahmu dan pasti jadi makanan favoritmu di akhir pekan.

Kalian jangan bingung jika kamu ingin mendapatkan coto ayam khas makassar, karena coto ayam khas makassar sangat mudah untuk didapatkan dan juga kalian pun bisa memasaknya sendiri di tempatmu. coto ayam khas makassar bisa diolah memalui beraneka cara. Kini telah banyak resep modern yang menjadikan coto ayam khas makassar lebih mantap.

Resep coto ayam khas makassar juga mudah sekali dibikin, lho. Kalian jangan capek-capek untuk membeli coto ayam khas makassar, tetapi Kamu dapat membuatnya di rumahmu. Bagi Kita yang hendak menyajikannya, berikut resep menyajikan coto ayam khas makassar yang enak yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Coto ayam khas makassar:

1. Sediakan 1/2 kilo ayam
1. Ambil 2 lembar daun jeruk
1. Sediakan 2 lembar daun salam
1. Gunakan 1/2 sendok teh pala bubuk
1. Sediakan Secukupnya merica bubuk
1. Gunakan Secukupnya kaldu ayam
1. Ambil Secukupnya garam
1. Sediakan Secukupnya gula merah
1. Gunakan 2 sendok makan air asam jawa
1. Sediakan Secukupnya Air
1. Ambil  Minyak untuk menumis bumbu
1. Sediakan  Bumbu halus
1. Gunakan 250 gram kacang tanah
1. Gunakan 8 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Gunakan 2 btang serai
1. Siapkan 1 ruas lengkuas
1. Gunakan 1 ruas jahe
1. Gunakan 2 butir kemiri
1. Ambil  Bumbu pelengkap
1. Ambil  Daun bawang
1. Gunakan  Daun seledri
1. Gunakan  Bawang goreng
1. Ambil  Jeruk nipis
1. Gunakan  Kecap
1. Siapkan  Sambel




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Coto ayam khas makassar:

1. Cuci bersih ayam dan potong kecil kecil
1. Rebus daging ayam sampai empuk
1. Haluskan bumbu halus, kemudian masukkan kedalam minyak, masukkan daun salam dan daun jeruk tnggu sampai bumbu kering (sisa bumbu halus dan minyak)
1. Campurkan bumbu halus kedalam rebusan daging ayam, tambahkan pala bubuk, merica, air asam, gula merah, kaldu dan garam. Cek rasa
1. Jika sudah tercampur angkat dan coto ayam siap disajikan.
1. Tambahkan bumbu pelengkap supaya lebih nikmat...




Ternyata cara membuat coto ayam khas makassar yang lezat tidak rumit ini gampang banget ya! Kita semua dapat mencobanya. Resep coto ayam khas makassar Sangat cocok sekali untuk anda yang baru mau belajar memasak maupun untuk kalian yang sudah hebat dalam memasak.

Apakah kamu ingin mencoba bikin resep coto ayam khas makassar nikmat tidak ribet ini? Kalau anda mau, mending kamu segera siapin peralatan dan bahan-bahannya, maka buat deh Resep coto ayam khas makassar yang enak dan tidak rumit ini. Betul-betul gampang kan. 

Maka, daripada anda berlama-lama, maka kita langsung saja sajikan resep coto ayam khas makassar ini. Dijamin kalian tiidak akan nyesel sudah bikin resep coto ayam khas makassar nikmat tidak ribet ini! Selamat berkreasi dengan resep coto ayam khas makassar lezat tidak rumit ini di rumah sendiri,ya!.

