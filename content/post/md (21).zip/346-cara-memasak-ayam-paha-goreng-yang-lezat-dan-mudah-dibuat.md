---
description: "Cara memasak Ayam paha goreng yang lezat dan Mudah Dibuat"
title: "Cara memasak Ayam paha goreng yang lezat dan Mudah Dibuat"
slug: 346-cara-memasak-ayam-paha-goreng-yang-lezat-dan-mudah-dibuat
date: 2021-06-03T08:02:16.395Z
image: https://img-global.cpcdn.com/recipes/0ccb9cffa74ec144/680x482cq70/ayam-paha-goreng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ccb9cffa74ec144/680x482cq70/ayam-paha-goreng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ccb9cffa74ec144/680x482cq70/ayam-paha-goreng-foto-resep-utama.jpg
author: Dorothy Stone
ratingvalue: 3.8
reviewcount: 4
recipeingredient:
- "500 gr paha ayam"
- "1/4 dari buah Jeruk nipis"
- "1/2 sdt garam"
- " Bumbu uleg"
- "2 butir bawang merah"
- "3 siung bawang merah"
- "1 ruas jahe"
- "1 ruas kunyit"
- "2 butir kemiri"
- "1 sdt ketumbar bubuk"
- "1 sdm garam"
- " Bumbu lain"
- "2 lembar daun salam"
- "2 ruas lengkuas geprek"
- "1 serai geprek"
- "500 ml air"
- " Minyak"
- "1 sdt tepung terigu"
recipeinstructions:
- "Lumuri ayam dengan air jeruk nipis dan garam remas2 lalu cuci bersih tiriskan"
- "Tumis bumbu uleg masukan daun salam,lengkuas,sereh aduk lalu masukan paha ayam kolah kaleh sampai berubah warna tuangi air aduk didihkan"
- "Setelah kuah mendidih tambahkan garam sesuai selera dan tes rasa"
- "Jika udah pas tutup wajan biarkan kuah surut dan daging matang sambil sesekali di aduk ya"
- "Setelah kuah surut matikan api dan angkat paha ayam biarkan dingin"
- "Ambil 1sdt tepung terigu taruh di piring campurkan dengan 3 sdm air sampai tercampur rata lalu balurkan kesemua paha ayam sampai merata lalu goreng diminyak yang panas sampai kecoklatan dan matang angkat sajikan dengan sambal dan sayur sop"
categories:
- Resep
tags:
- ayam
- paha
- goreng

katakunci: ayam paha goreng 
nutrition: 269 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam paha goreng](https://img-global.cpcdn.com/recipes/0ccb9cffa74ec144/680x482cq70/ayam-paha-goreng-foto-resep-utama.jpg)

Jika anda seorang orang tua, menyajikan masakan menggugah selera pada famili merupakan hal yang menyenangkan bagi kita sendiri. Tanggung jawab seorang istri bukan saja mengatur rumah saja, namun kamu pun wajib memastikan keperluan gizi terpenuhi dan juga olahan yang dikonsumsi anak-anak mesti sedap.

Di zaman  saat ini, anda memang bisa memesan santapan yang sudah jadi meski tanpa harus repot membuatnya terlebih dahulu. Namun ada juga mereka yang selalu ingin menyajikan yang terenak untuk orang yang dicintainya. Lantaran, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai selera orang tercinta. 



Apakah kamu salah satu penyuka ayam paha goreng?. Asal kamu tahu, ayam paha goreng adalah makanan khas di Nusantara yang saat ini digemari oleh orang-orang dari hampir setiap tempat di Nusantara. Anda bisa membuat ayam paha goreng buatan sendiri di rumahmu dan boleh jadi hidangan favoritmu di hari liburmu.

Kalian tak perlu bingung jika kamu ingin memakan ayam paha goreng, lantaran ayam paha goreng tidak sukar untuk dicari dan juga kamu pun bisa mengolahnya sendiri di rumah. ayam paha goreng boleh dibuat memalui beragam cara. Saat ini telah banyak resep kekinian yang menjadikan ayam paha goreng lebih enak.

Resep ayam paha goreng pun mudah untuk dibuat, lho. Anda jangan repot-repot untuk membeli ayam paha goreng, tetapi Kalian mampu menyajikan sendiri di rumah. Bagi Anda yang ingin membuatnya, inilah resep untuk membuat ayam paha goreng yang nikamat yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam paha goreng:

1. Gunakan 500 gr paha ayam
1. Sediakan 1/4 dari buah Jeruk nipis
1. Gunakan 1/2 sdt garam
1. Ambil  Bumbu uleg:
1. Siapkan 2 butir bawang merah
1. Ambil 3 siung bawang merah
1. Gunakan 1 ruas jahe
1. Gunakan 1 ruas kunyit
1. Siapkan 2 butir kemiri
1. Ambil 1 sdt ketumbar bubuk
1. Ambil 1 sdm garam
1. Ambil  Bumbu lain:
1. Sediakan 2 lembar daun salam
1. Siapkan 2 ruas lengkuas geprek
1. Gunakan 1 serai geprek
1. Siapkan 500 ml air
1. Gunakan  Minyak
1. Sediakan 1 sdt tepung terigu




<!--inarticleads2-->

##### Cara membuat Ayam paha goreng:

1. Lumuri ayam dengan air jeruk nipis dan garam remas2 lalu cuci bersih tiriskan
1. Tumis bumbu uleg masukan daun salam,lengkuas,sereh aduk lalu masukan paha ayam kolah kaleh sampai berubah warna tuangi air aduk didihkan
1. Setelah kuah mendidih tambahkan garam sesuai selera dan tes rasa
1. Jika udah pas tutup wajan biarkan kuah surut dan daging matang sambil sesekali di aduk ya
1. Setelah kuah surut matikan api dan angkat paha ayam biarkan dingin
1. Ambil 1sdt tepung terigu taruh di piring campurkan dengan 3 sdm air sampai tercampur rata lalu balurkan kesemua paha ayam sampai merata lalu goreng diminyak yang panas sampai kecoklatan dan matang angkat sajikan dengan sambal dan sayur sop




Ternyata cara buat ayam paha goreng yang nikamt tidak rumit ini gampang banget ya! Kalian semua mampu memasaknya. Resep ayam paha goreng Sesuai sekali untuk kamu yang baru mau belajar memasak maupun bagi kalian yang telah jago dalam memasak.

Tertarik untuk mulai mencoba membuat resep ayam paha goreng mantab tidak rumit ini? Kalau kamu tertarik, yuk kita segera menyiapkan alat dan bahan-bahannya, lantas buat deh Resep ayam paha goreng yang mantab dan tidak ribet ini. Sungguh gampang kan. 

Jadi, daripada kalian berfikir lama-lama, maka kita langsung bikin resep ayam paha goreng ini. Dijamin kalian tiidak akan nyesel membuat resep ayam paha goreng enak tidak rumit ini! Selamat mencoba dengan resep ayam paha goreng enak tidak ribet ini di rumah sendiri,oke!.

