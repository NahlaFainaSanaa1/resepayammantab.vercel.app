---
description: "Resep Tongseng ayam (berkuah) yang lezat dan Mudah Dibuat"
title: "Resep Tongseng ayam (berkuah) yang lezat dan Mudah Dibuat"
slug: 473-resep-tongseng-ayam-berkuah-yang-lezat-dan-mudah-dibuat
date: 2021-01-27T17:35:05.285Z
image: https://img-global.cpcdn.com/recipes/68a076dce64520a8/680x482cq70/tongseng-ayam-berkuah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/68a076dce64520a8/680x482cq70/tongseng-ayam-berkuah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/68a076dce64520a8/680x482cq70/tongseng-ayam-berkuah-foto-resep-utama.jpg
author: Scott Mills
ratingvalue: 4.8
reviewcount: 9
recipeingredient:
- "1/2 ekor Ayam potong"
- "Secukupnya Kol"
- "1 buah Tomat Merah"
- "1 batang Daun Bawang"
- "3 lembar Daun Salam"
- "3 lembar Daun Jeruk"
- "2 batang Sereh pakai putihnya aja geprek"
- "1 cm Lengkuas geprek"
- "3 sdm Kecap Manis"
- "300 ml Air"
- "65 ml Santan Instan"
- "2 cm Kayu Manis saya skip kehabisan"
- "10 buah Cabe Rawit utuh saya skip"
- "Secukupnya Gula saya 1sdm"
- "Secukupnya Garam saya 1sdt"
- " Bumbu halus"
- "6 siung Bawang Merah"
- "4 siung Bawang Putih"
- "5 buah Cabe Kriting"
- "2 butir Kemiri sangrai"
- "1 ruas Kunyit bakar"
- "1 sdt Merica bubuk"
- "1 sdt Ketumbar bubuk"
recipeinstructions:
- "Siapkan bahan² yg sudah dicuci bersih. Haluskan bahan bumbu halus. Tumis bumbu halus juga daun salam, daun jeruk, lengkuas, sereh dan kayu manis hingga harum."
- "Masukkan ayam, masak sebentar kemudian tambahkan air. Masak lagi sampai ayam matang lalu masukkan santan, gula, garam, kecap manis. Sambil diicip icip. Sebelum kompor dimatikan masukkan irisan kol, daun bawang, dan tomat. Masak sebentar saja sampai tomat rada layu. Kemudian matikan kompor dan Tongseng ayam siap disantap."
categories:
- Resep
tags:
- tongseng
- ayam
- berkuah

katakunci: tongseng ayam berkuah 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Lunch

---


![Tongseng ayam (berkuah)](https://img-global.cpcdn.com/recipes/68a076dce64520a8/680x482cq70/tongseng-ayam-berkuah-foto-resep-utama.jpg)

Apabila kalian seorang yang hobi masak, menyediakan masakan enak bagi orang tercinta merupakan hal yang menggembirakan untuk kamu sendiri. Tanggung jawab seorang  wanita bukan sekadar mengatur rumah saja, namun anda pun harus memastikan keperluan nutrisi tercukupi dan panganan yang disantap anak-anak wajib lezat.

Di masa  saat ini, kamu memang mampu mengorder olahan instan tidak harus repot memasaknya dulu. Tetapi ada juga orang yang selalu ingin memberikan hidangan yang terbaik bagi orang yang dicintainya. Karena, memasak yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga. 



Mungkinkah anda seorang penggemar tongseng ayam (berkuah)?. Tahukah kamu, tongseng ayam (berkuah) adalah hidangan khas di Nusantara yang saat ini disukai oleh kebanyakan orang di berbagai daerah di Nusantara. Kita dapat menyajikan tongseng ayam (berkuah) sendiri di rumah dan boleh dijadikan hidangan favoritmu di hari liburmu.

Kita tidak usah bingung untuk mendapatkan tongseng ayam (berkuah), karena tongseng ayam (berkuah) gampang untuk didapatkan dan juga kamu pun bisa memasaknya sendiri di rumah. tongseng ayam (berkuah) bisa dibuat dengan berbagai cara. Sekarang telah banyak banget cara kekinian yang membuat tongseng ayam (berkuah) semakin lebih lezat.

Resep tongseng ayam (berkuah) pun mudah sekali untuk dibuat, lho. Kalian tidak perlu repot-repot untuk memesan tongseng ayam (berkuah), sebab Kamu mampu menghidangkan di rumahmu. Untuk Kamu yang akan membuatnya, inilah cara untuk membuat tongseng ayam (berkuah) yang lezat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Tongseng ayam (berkuah):

1. Gunakan 1/2 ekor Ayam (potong²)
1. Gunakan Secukupnya Kol
1. Ambil 1 buah Tomat Merah
1. Gunakan 1 batang Daun Bawang
1. Gunakan 3 lembar Daun Salam
1. Gunakan 3 lembar Daun Jeruk
1. Sediakan 2 batang Sereh (pakai putihnya aja, geprek)
1. Gunakan 1 cm Lengkuas (geprek)
1. Gunakan 3 sdm Kecap Manis
1. Siapkan 300 ml Air
1. Gunakan 65 ml Santan Instan
1. Sediakan 2 cm Kayu Manis (saya skip, kehabisan)
1. Ambil 10 buah Cabe Rawit utuh (saya skip)
1. Ambil Secukupnya Gula (saya 1sdm)
1. Ambil Secukupnya Garam (saya 1½sdt)
1. Gunakan  Bumbu halus
1. Gunakan 6 siung Bawang Merah
1. Ambil 4 siung Bawang Putih
1. Sediakan 5 buah Cabe Kriting
1. Sediakan 2 butir Kemiri (sangrai)
1. Gunakan 1 ruas Kunyit (bakar)
1. Ambil 1 sdt Merica bubuk
1. Siapkan 1 sdt Ketumbar bubuk




<!--inarticleads2-->

##### Cara menyiapkan Tongseng ayam (berkuah):

1. Siapkan bahan² yg sudah dicuci bersih. Haluskan bahan bumbu halus. Tumis bumbu halus juga daun salam, daun jeruk, lengkuas, sereh dan kayu manis hingga harum.
1. Masukkan ayam, masak sebentar kemudian tambahkan air. Masak lagi sampai ayam matang lalu masukkan santan, gula, garam, kecap manis. Sambil diicip icip. Sebelum kompor dimatikan masukkan irisan kol, daun bawang, dan tomat. Masak sebentar saja sampai tomat rada layu. Kemudian matikan kompor dan Tongseng ayam siap disantap.




Ternyata resep tongseng ayam (berkuah) yang mantab simple ini enteng sekali ya! Kita semua bisa menghidangkannya. Cara buat tongseng ayam (berkuah) Sesuai sekali buat kita yang sedang belajar memasak atau juga bagi kalian yang sudah ahli dalam memasak.

Apakah kamu mau mencoba buat resep tongseng ayam (berkuah) enak sederhana ini? Kalau kalian mau, ayo kalian segera menyiapkan alat dan bahan-bahannya, kemudian buat deh Resep tongseng ayam (berkuah) yang lezat dan simple ini. Betul-betul mudah kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, maka kita langsung saja buat resep tongseng ayam (berkuah) ini. Dijamin kamu tak akan nyesel bikin resep tongseng ayam (berkuah) enak tidak rumit ini! Selamat mencoba dengan resep tongseng ayam (berkuah) lezat tidak rumit ini di rumah masing-masing,oke!.

