---
description: "Cara buat Soto ayam yang lezat Untuk Jualan"
title: "Cara buat Soto ayam yang lezat Untuk Jualan"
slug: 228-cara-buat-soto-ayam-yang-lezat-untuk-jualan
date: 2021-04-17T14:39:12.876Z
image: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Michael Osborne
ratingvalue: 3.4
reviewcount: 15
recipeingredient:
- "1/2 kg ayam"
- " Bumbu halus "
- "5 siung bawang putih"
- "8 siung bawang merah"
- "4 buah kemiri"
- "2 ruas kunyit"
- " Tambahan "
- "2 batang sereh geprek"
- "3 lembar daun salam"
- "6 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "2 batang daun bawang iris"
- "1 batang seledri iris"
- "1 buah tomat iris sesuai selera"
- "1/2 jeruk nipis"
- "2 sdt Garam"
- "1/2 sdt Gula"
- "1 sdt Lada bubuk"
recipeinstructions:
- "Rebus ayam tidak usah lama2, lalu buang airnya. Rebus kembali."
- "Tumis bumbu halus di atas api sedang, jika sudah harum masukan daun salam, daun jeruk, sereh, lengkuas. Tambahkan 1 gelas belimbing air. Aduk sampai air mendidih. Matikan."
- "Jika rebusan ayam sudah mendidih, masukan bumbu yg sudah di tumis tadi. Aduk."
- "Tambahkan garam, lada, gula. Cek rasa. Matikan kompor."
- "Hidangkan soto di mangkuk, jangan lupa di beri irisan daun bawang, daun seledri, tomat dan perasan jeruk agar tambah segar."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 246 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Soto ayam](https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan olahan enak buat orang tercinta adalah hal yang menggembirakan bagi anda sendiri. Kewajiban seorang ibu Tidak sekadar mengatur rumah saja, tapi anda juga wajib menyediakan kebutuhan gizi tercukupi dan juga panganan yang dimakan keluarga tercinta mesti mantab.

Di zaman  saat ini, anda sebenarnya dapat membeli olahan instan walaupun tidak harus capek membuatnya dahulu. Namun ada juga lho orang yang selalu ingin menghidangkan yang terbaik untuk keluarganya. Pasalnya, memasak yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan keluarga. 



Apakah kamu salah satu penyuka soto ayam?. Asal kamu tahu, soto ayam merupakan makanan khas di Indonesia yang saat ini disenangi oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Anda bisa memasak soto ayam kreasi sendiri di rumahmu dan boleh jadi hidangan kesenanganmu di hari libur.

Kamu tidak usah bingung untuk menyantap soto ayam, lantaran soto ayam gampang untuk didapatkan dan juga kita pun bisa memasaknya sendiri di rumah. soto ayam bisa diolah dengan beraneka cara. Saat ini telah banyak cara kekinian yang membuat soto ayam lebih enak.

Resep soto ayam juga gampang sekali untuk dibikin, lho. Kita tidak perlu ribet-ribet untuk membeli soto ayam, sebab Kalian mampu menyajikan sendiri di rumah. Untuk Anda yang ingin membuatnya, berikut cara menyajikan soto ayam yang enak yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Soto ayam:

1. Ambil 1/2 kg ayam
1. Ambil  Bumbu halus :
1. Siapkan 5 siung bawang putih
1. Gunakan 8 siung bawang merah
1. Gunakan 4 buah kemiri
1. Sediakan 2 ruas kunyit
1. Sediakan  Tambahan :
1. Siapkan 2 batang sereh (geprek)
1. Ambil 3 lembar daun salam
1. Siapkan 6 lembar daun jeruk
1. Ambil 1 ruas lengkuas (geprek)
1. Gunakan 2 batang daun bawang (iris)
1. Ambil 1 batang seledri (iris)
1. Ambil 1 buah tomat (iris sesuai selera)
1. Sediakan 1/2 jeruk nipis
1. Ambil 2 sdt Garam
1. Sediakan 1/2 sdt Gula
1. Sediakan 1 sdt Lada bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Soto ayam:

1. Rebus ayam tidak usah lama2, lalu buang airnya. Rebus kembali.
1. Tumis bumbu halus di atas api sedang, jika sudah harum masukan daun salam, daun jeruk, sereh, lengkuas. Tambahkan 1 gelas belimbing air. Aduk sampai air mendidih. Matikan.
1. Jika rebusan ayam sudah mendidih, masukan bumbu yg sudah di tumis tadi. Aduk.
1. Tambahkan garam, lada, gula. Cek rasa. Matikan kompor.
1. Hidangkan soto di mangkuk, jangan lupa di beri irisan daun bawang, daun seledri, tomat dan perasan jeruk agar tambah segar.




Ternyata cara buat soto ayam yang mantab tidak ribet ini mudah banget ya! Semua orang mampu memasaknya. Cara buat soto ayam Cocok sekali untuk kalian yang baru akan belajar memasak maupun untuk anda yang sudah jago dalam memasak.

Tertarik untuk mulai mencoba bikin resep soto ayam enak simple ini? Kalau kalian tertarik, mending kamu segera menyiapkan peralatan dan bahannya, kemudian buat deh Resep soto ayam yang mantab dan tidak ribet ini. Benar-benar gampang kan. 

Maka dari itu, daripada kamu diam saja, ayo langsung aja buat resep soto ayam ini. Pasti anda tiidak akan menyesal sudah membuat resep soto ayam mantab sederhana ini! Selamat mencoba dengan resep soto ayam enak tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

