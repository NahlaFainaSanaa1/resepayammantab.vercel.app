---
description: "Cara membuat DOUBLE LAYERED BASQUE 😍🤩😍 Sederhana Untuk Jualan"
title: "Cara membuat DOUBLE LAYERED BASQUE 😍🤩😍 Sederhana Untuk Jualan"
slug: 170-cara-membuat-double-layered-basque-sederhana-untuk-jualan
date: 2021-05-23T07:46:55.273Z
image: https://img-global.cpcdn.com/recipes/046b40c688fea818/680x482cq70/double-layered-basque-😍🤩😍-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/046b40c688fea818/680x482cq70/double-layered-basque-😍🤩😍-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/046b40c688fea818/680x482cq70/double-layered-basque-😍🤩😍-foto-resep-utama.jpg
author: Emily Nunez
ratingvalue: 3
reviewcount: 13
recipeingredient:
- " Bahan Dasar"
- "230 gr creamcheese"
- "60 gr gula pasir"
- "2 butir telur ayam uk kecil ke sedang"
- " Layer dasar Matcha"
- "7.5 gr bubuk matcha"
- "68 gr whipping cream cair"
- " Layer atas"
- "5 gr tepung terigu protein rendah"
- "68 gr whipping cream cair"
- "1/2 sdt vanilla ekstrak"
- "1/2 sdt air lemon"
recipeinstructions:
- "Campur bahan layer matcha dan layer atas (tanpa vanilla ekstrak dan air lemon), aduk rata, sisihkan."
- "Mixer cream cheese sampai creamy, lalu masukan gula pasir, mixer dengan kecepatan tinggi sampai fluffy lalu satu persatu masukan telur, aduk rata dengan kecepatan rendah saja."
- "Bagi adonan menjadi 2 sama banyak lalu buat masing masing layer. Layer atas : kedalam setengah adonan, masukan larutan tepung dan whipping cream (langkah 1), tambahkan vanilla ekstrak dan air lemon lalu aduk rata, pindahkan ke plastik segitiga."
- "Layer matcha : kedalam setengah adonan lain, masukan larutan matcha whipping cream (langkah 1), lalu aduk rata menggunakan teknik aduk lipat. Pindahkan ke loyang yang telah dialasi 2 lapis baking paper. Panaskan oven api atas bawah 220 derajat."
- "Ratakan permukaannya, kemudian beri lapisan layer putih mulai dari tengah ya😃 goyangkan agar merata😍"
- "Panggang selama 25-28 menit, lalu pindah ke api atas 3-5 menit (kalau mau lebih hitam, saya ga suka gosong banget, 3 menit cukup🤩)"
- "Diamkan dalam suhu ruang lalu masukan kulkas min 6 jam. Potong, maem, nyam🤩"
categories:
- Resep
tags:
- double
- layered
- basque

katakunci: double layered basque 
nutrition: 225 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Lunch

---


![DOUBLE LAYERED BASQUE 😍🤩😍](https://img-global.cpcdn.com/recipes/046b40c688fea818/680x482cq70/double-layered-basque-😍🤩😍-foto-resep-utama.jpg)

Andai anda seorang orang tua, menyuguhkan olahan enak bagi famili adalah suatu hal yang sangat menyenangkan bagi anda sendiri. Tugas seorang ibu Tidak cuma menangani rumah saja, tetapi kamu juga harus memastikan kebutuhan nutrisi tercukupi dan olahan yang disantap orang tercinta wajib mantab.

Di zaman  saat ini, kalian sebenarnya dapat memesan panganan instan tanpa harus ribet memasaknya lebih dulu. Namun ada juga lho orang yang selalu ingin memberikan hidangan yang terbaik bagi orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan famili. 



Apakah anda merupakan salah satu penikmat double layered basque 😍🤩😍?. Asal kamu tahu, double layered basque 😍🤩😍 adalah sajian khas di Nusantara yang saat ini disukai oleh orang-orang dari hampir setiap tempat di Indonesia. Kamu bisa membuat double layered basque 😍🤩😍 sendiri di rumahmu dan boleh dijadikan camilan kesenanganmu di akhir pekan.

Anda tidak usah bingung untuk mendapatkan double layered basque 😍🤩😍, lantaran double layered basque 😍🤩😍 tidak sukar untuk dicari dan juga kalian pun bisa membuatnya sendiri di tempatmu. double layered basque 😍🤩😍 dapat dimasak lewat beragam cara. Kini pun telah banyak resep modern yang menjadikan double layered basque 😍🤩😍 semakin lebih nikmat.

Resep double layered basque 😍🤩😍 pun gampang sekali untuk dibuat, lho. Kalian tidak perlu repot-repot untuk membeli double layered basque 😍🤩😍, karena Anda bisa menyiapkan sendiri di rumah. Untuk Kalian yang akan mencobanya, di bawah ini adalah cara untuk membuat double layered basque 😍🤩😍 yang enak yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan DOUBLE LAYERED BASQUE 😍🤩😍:

1. Siapkan  Bahan Dasar
1. Gunakan 230 gr creamcheese
1. Ambil 60 gr gula pasir
1. Gunakan 2 butir telur ayam uk kecil ke sedang
1. Gunakan  Layer dasar (Matcha)
1. Sediakan 7.5 gr bubuk matcha
1. Siapkan 68 gr whipping cream cair
1. Sediakan  Layer atas
1. Gunakan 5 gr tepung terigu protein rendah
1. Gunakan 68 gr whipping cream cair
1. Ambil 1/2 sdt vanilla ekstrak
1. Ambil 1/2 sdt air lemon




<!--inarticleads2-->

##### Cara menyiapkan DOUBLE LAYERED BASQUE 😍🤩😍:

1. Campur bahan layer matcha dan layer atas (tanpa vanilla ekstrak dan air lemon), aduk rata, sisihkan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Mixer cream cheese sampai creamy, lalu masukan gula pasir, mixer dengan kecepatan tinggi sampai fluffy lalu satu persatu masukan telur, aduk rata dengan kecepatan rendah saja.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Bagi adonan menjadi 2 sama banyak lalu buat masing masing layer. Layer atas : kedalam setengah adonan, masukan larutan tepung dan whipping cream (langkah 1), tambahkan vanilla ekstrak dan air lemon lalu aduk rata, pindahkan ke plastik segitiga.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Layer matcha : kedalam setengah adonan lain, masukan larutan matcha whipping cream (langkah 1), lalu aduk rata menggunakan teknik aduk lipat. Pindahkan ke loyang yang telah dialasi 2 lapis baking paper. Panaskan oven api atas bawah 220 derajat.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Ratakan permukaannya, kemudian beri lapisan layer putih mulai dari tengah ya😃 goyangkan agar merata😍
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Panggang selama 25-28 menit, lalu pindah ke api atas 3-5 menit (kalau mau lebih hitam, saya ga suka gosong banget, 3 menit cukup🤩)
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Diamkan dalam suhu ruang lalu masukan kulkas min 6 jam. Potong, maem, nyam🤩
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">



Ternyata cara buat double layered basque 😍🤩😍 yang mantab simple ini mudah banget ya! Anda Semua dapat memasaknya. Cara Membuat double layered basque 😍🤩😍 Cocok banget buat kita yang baru mau belajar memasak ataupun juga bagi anda yang sudah pandai memasak.

Apakah kamu tertarik mencoba bikin resep double layered basque 😍🤩😍 nikmat sederhana ini? Kalau kamu tertarik, ayo kalian segera menyiapkan alat-alat dan bahannya, lantas bikin deh Resep double layered basque 😍🤩😍 yang enak dan sederhana ini. Sungguh mudah kan. 

Maka, ketimbang kamu diam saja, ayo kita langsung saja buat resep double layered basque 😍🤩😍 ini. Pasti anda tiidak akan nyesel sudah buat resep double layered basque 😍🤩😍 mantab tidak ribet ini! Selamat berkreasi dengan resep double layered basque 😍🤩😍 lezat tidak rumit ini di tempat tinggal sendiri,ya!.

