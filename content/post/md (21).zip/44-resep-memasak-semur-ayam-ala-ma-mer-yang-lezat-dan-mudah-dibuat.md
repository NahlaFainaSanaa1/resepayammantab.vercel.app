---
description: "Resep memasak Semur ayam ala Ma Mer yang lezat dan Mudah Dibuat"
title: "Resep memasak Semur ayam ala Ma Mer yang lezat dan Mudah Dibuat"
slug: 44-resep-memasak-semur-ayam-ala-ma-mer-yang-lezat-dan-mudah-dibuat
date: 2021-02-02T01:19:28.085Z
image: https://img-global.cpcdn.com/recipes/6674f30c8d9c6e5c/680x482cq70/semur-ayam-ala-ma-mer-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6674f30c8d9c6e5c/680x482cq70/semur-ayam-ala-ma-mer-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6674f30c8d9c6e5c/680x482cq70/semur-ayam-ala-ma-mer-foto-resep-utama.jpg
author: Martin Powell
ratingvalue: 5
reviewcount: 6
recipeingredient:
- "1 ekor ayam potong bisa jantan kampung atau broiler"
- "1 buah tomat iris"
- "2 buah kentang"
- "Segenggam soun"
- "3 buah cengkeh"
- "1 btg kayumanis"
- "Sepotong kecil pala"
- "1 buah bawang bombai ukuran kecil"
- "2 siung bawang putih"
- "3 sdm Kecap manis"
- " Garam"
- " Kaldu jamur"
- " Air"
recipeinstructions:
- "Tumis bawang bombay, bawang putih, sampai harum lalu masukan juga cengkeh, kayumanis, pala,tomat, ayam..masak sampai ayam berubah warna."
- "Tbahkan air kira2x 500 ml..tambahkan kecap, garam, kaldu jamur..masak dgn api kecil..sampai ayam empuk dan matang. Bila dirasa blm empuk bisa tambah air lg."
- "Setelah ayam empuk masukan kentang..masak sampai kentang empuk."
- "Terakhir masukan soun..biarkan mendidih..lgs matikan api..siap disajikan."
categories:
- Resep
tags:
- semur
- ayam
- ala

katakunci: semur ayam ala 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Lunch

---


![Semur ayam ala Ma Mer](https://img-global.cpcdn.com/recipes/6674f30c8d9c6e5c/680x482cq70/semur-ayam-ala-ma-mer-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan panganan menggugah selera kepada famili adalah suatu hal yang menyenangkan bagi kamu sendiri. Peran seorang  wanita Tidak sekadar mengurus rumah saja, tapi anda juga harus memastikan keperluan gizi terpenuhi dan santapan yang dikonsumsi orang tercinta wajib sedap.

Di era  saat ini, kita sebenarnya dapat mengorder hidangan siap saji walaupun tidak harus capek memasaknya terlebih dahulu. Tetapi banyak juga orang yang memang mau memberikan yang terenak bagi orang yang dicintainya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan kesukaan famili. 



Mungkinkah anda salah satu penyuka semur ayam ala ma mer?. Tahukah kamu, semur ayam ala ma mer adalah sajian khas di Indonesia yang kini digemari oleh orang-orang dari berbagai daerah di Nusantara. Anda bisa menghidangkan semur ayam ala ma mer sendiri di rumahmu dan dapat dijadikan hidangan favoritmu di akhir pekan.

Kamu jangan bingung untuk memakan semur ayam ala ma mer, sebab semur ayam ala ma mer mudah untuk dicari dan juga kita pun dapat menghidangkannya sendiri di rumah. semur ayam ala ma mer bisa dimasak dengan beraneka cara. Saat ini sudah banyak sekali cara modern yang menjadikan semur ayam ala ma mer lebih mantap.

Resep semur ayam ala ma mer pun mudah dibikin, lho. Anda tidak usah capek-capek untuk memesan semur ayam ala ma mer, karena Kamu bisa menyiapkan di rumahmu. Untuk Anda yang mau menghidangkannya, berikut resep untuk membuat semur ayam ala ma mer yang enak yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Semur ayam ala Ma Mer:

1. Gunakan 1 ekor ayam potong (bisa jantan, kampung atau broiler)
1. Sediakan 1 buah tomat iris
1. Ambil 2 buah kentang
1. Siapkan Segenggam soun
1. Siapkan 3 buah cengkeh
1. Gunakan 1 btg kayumanis
1. Gunakan Sepotong kecil pala
1. Ambil 1 buah bawang bombai ukuran kecil
1. Siapkan 2 siung bawang putih
1. Gunakan 3 sdm Kecap manis
1. Ambil  Garam
1. Ambil  Kaldu jamur
1. Ambil  Air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Semur ayam ala Ma Mer:

1. Tumis bawang bombay, bawang putih, sampai harum lalu masukan juga cengkeh, kayumanis, pala,tomat, ayam..masak sampai ayam berubah warna.
1. Tbahkan air kira2x 500 ml..tambahkan kecap, garam, kaldu jamur..masak dgn api kecil..sampai ayam empuk dan matang. Bila dirasa blm empuk bisa tambah air lg.
1. Setelah ayam empuk masukan kentang..masak sampai kentang empuk.
1. Terakhir masukan soun..biarkan mendidih..lgs matikan api..siap disajikan.




Ternyata cara buat semur ayam ala ma mer yang enak tidak ribet ini enteng banget ya! Kamu semua mampu menghidangkannya. Cara buat semur ayam ala ma mer Sangat sesuai banget buat kita yang baru akan belajar memasak ataupun juga untuk kalian yang sudah hebat memasak.

Tertarik untuk mencoba membuat resep semur ayam ala ma mer lezat simple ini? Kalau anda mau, mending kamu segera buruan siapkan peralatan dan bahannya, setelah itu buat deh Resep semur ayam ala ma mer yang mantab dan tidak ribet ini. Sangat gampang kan. 

Maka dari itu, ketimbang kita berlama-lama, maka kita langsung saja hidangkan resep semur ayam ala ma mer ini. Dijamin kamu tak akan nyesel sudah buat resep semur ayam ala ma mer mantab sederhana ini! Selamat berkreasi dengan resep semur ayam ala ma mer nikmat simple ini di rumah kalian masing-masing,oke!.

