---
description: "Cara memasak Soto Ayam yang sedap Untuk Jualan"
title: "Cara memasak Soto Ayam yang sedap Untuk Jualan"
slug: 225-cara-memasak-soto-ayam-yang-sedap-untuk-jualan
date: 2021-03-12T16:54:34.604Z
image: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Della Brown
ratingvalue: 4.1
reviewcount: 11
recipeingredient:
- "1 ekor Ayam belah jadi 4"
- "1500 ml Air"
- "2 batang Serai memarkan"
- "4 lembar Daun Jeruk"
- "2 cm Lengkuas memarkan"
- "1/4 sdt Lada bubuk"
- "Secukupnya Gula garam dan kaldu bubuk"
- " Bumbu Halus"
- "10 siung Bawang putih"
- "5 siung Bawang merah"
- "2 cm Jahe"
- "2 cm Kunyit"
- "4 butir Kemiri"
- " Pelengkap"
- "3 butir Telur rebu potong  potong"
- "4 lembar Kol iris halus"
- "100 gr Tauge"
- "2 bh Tomat potongpotong"
- "Beberapa lembar daun seledri rajang halus"
- "Secukupnya Bawang Merah goreng untuk taburan"
- "Secukupnya jeruk nipis untuk kecuran"
- " Sambal rebus cabai rawit haluskan dan beri tambahan gula dan garam secukupnya"
recipeinstructions:
- "Bersihkan ayam lalu rebus ayam sampai keluar kaldu dan ayam agak empuk. Haluskan bumbu dan tumis sampai harum, masukkan serai, daun jeruk, lengkuas dan lada bubuk, aduk-aduk sebentar. Masukkan bumbu tumis ke dalam rebusan ayam. Tambahkan gula, garam dan kaldu bubuk. Kecilkan api masak kira-kira 15 menit sampai bumbu meresap. Cicipi dan koreksi rasa."
- "Setelah ayam empuk, angkat dan goreng sebentar dengan sedikit minyak sampai ayam agak kecoklatan lalu suwir-suwir atau iris tipi sesuai selera. Siapkan pelengkap soto."
- "Hidangkan soto ayam dengan taburan kol rebus, irisan tomat, tauge, bawang goreng, telur rebus dan terakhir beri perasan jeruk nipis."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 267 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Sebagai seorang ibu, mempersiapkan santapan enak pada keluarga tercinta adalah suatu hal yang menggembirakan untuk kita sendiri. Peran seorang ibu Tidak sekedar mengerjakan pekerjaan rumah saja, namun anda juga wajib memastikan kebutuhan gizi terpenuhi dan juga olahan yang dimakan anak-anak harus lezat.

Di era  saat ini, kamu memang bisa memesan olahan siap saji tidak harus capek membuatnya dahulu. Namun banyak juga mereka yang selalu mau memberikan makanan yang terbaik bagi orang yang dicintainya. Sebab, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan salah satu penggemar soto ayam?. Tahukah kamu, soto ayam merupakan sajian khas di Nusantara yang sekarang disenangi oleh setiap orang dari berbagai daerah di Indonesia. Anda dapat menghidangkan soto ayam buatan sendiri di rumah dan boleh jadi santapan favorit di hari libur.

Kita jangan bingung untuk memakan soto ayam, karena soto ayam tidak sulit untuk dicari dan juga kalian pun boleh memasaknya sendiri di tempatmu. soto ayam bisa diolah lewat bermacam cara. Sekarang telah banyak resep modern yang membuat soto ayam lebih nikmat.

Resep soto ayam juga sangat mudah dibikin, lho. Kalian tidak perlu ribet-ribet untuk memesan soto ayam, tetapi Kalian dapat menghidangkan sendiri di rumah. Untuk Kita yang hendak menyajikannya, berikut cara untuk menyajikan soto ayam yang nikamat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Soto Ayam:

1. Siapkan 1 ekor Ayam belah jadi 4
1. Ambil 1500 ml Air
1. Siapkan 2 batang Serai, memarkan
1. Ambil 4 lembar Daun Jeruk
1. Sediakan 2 cm Lengkuas, memarkan
1. Siapkan 1/4 sdt Lada bubuk
1. Gunakan Secukupnya Gula, garam dan kaldu bubuk
1. Sediakan  Bumbu Halus:
1. Sediakan 10 siung Bawang putih
1. Ambil 5 siung Bawang merah
1. Ambil 2 cm Jahe
1. Siapkan 2 cm Kunyit
1. Sediakan 4 butir Kemiri
1. Gunakan  Pelengkap:
1. Siapkan 3 butir Telur rebu, potong - potong
1. Siapkan 4 lembar Kol, iris halus
1. Gunakan 100 gr Tauge
1. Siapkan 2 bh Tomat, potong-potong
1. Sediakan Beberapa lembar daun seledri, rajang halus
1. Ambil Secukupnya Bawang Merah goreng untuk taburan
1. Siapkan Secukupnya jeruk nipis untuk kecuran
1. Gunakan  Sambal: (rebus cabai rawit, haluskan dan beri tambahan gula dan garam secukupnya)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam:

1. Bersihkan ayam lalu rebus ayam sampai keluar kaldu dan ayam agak empuk. Haluskan bumbu dan tumis sampai harum, masukkan serai, daun jeruk, lengkuas dan lada bubuk, aduk-aduk sebentar. Masukkan bumbu tumis ke dalam rebusan ayam. Tambahkan gula, garam dan kaldu bubuk. Kecilkan api masak kira-kira 15 menit sampai bumbu meresap. Cicipi dan koreksi rasa.
1. Setelah ayam empuk, angkat dan goreng sebentar dengan sedikit minyak sampai ayam agak kecoklatan lalu suwir-suwir atau iris tipi sesuai selera. Siapkan pelengkap soto.
1. Hidangkan soto ayam dengan taburan kol rebus, irisan tomat, tauge, bawang goreng, telur rebus dan terakhir beri perasan jeruk nipis.




Ternyata cara buat soto ayam yang nikamt simple ini enteng banget ya! Kita semua bisa memasaknya. Resep soto ayam Sangat sesuai sekali untuk anda yang sedang belajar memasak ataupun juga untuk kamu yang sudah pandai dalam memasak.

Tertarik untuk mencoba membikin resep soto ayam mantab simple ini? Kalau kamu ingin, ayo kamu segera buruan siapin alat-alat dan bahan-bahannya, lalu buat deh Resep soto ayam yang nikmat dan tidak rumit ini. Betul-betul taidak sulit kan. 

Oleh karena itu, ketimbang kita diam saja, yuk kita langsung hidangkan resep soto ayam ini. Pasti kamu gak akan menyesal sudah bikin resep soto ayam mantab tidak ribet ini! Selamat mencoba dengan resep soto ayam mantab tidak rumit ini di tempat tinggal masing-masing,oke!.

