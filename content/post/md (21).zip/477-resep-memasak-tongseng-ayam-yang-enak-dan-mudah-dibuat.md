---
description: "Resep memasak Tongseng Ayam yang enak dan Mudah Dibuat"
title: "Resep memasak Tongseng Ayam yang enak dan Mudah Dibuat"
slug: 477-resep-memasak-tongseng-ayam-yang-enak-dan-mudah-dibuat
date: 2021-05-25T02:19:44.431Z
image: https://img-global.cpcdn.com/recipes/f1f0fd9a2568b8b7/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f1f0fd9a2568b8b7/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f1f0fd9a2568b8b7/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
author: Amy Sherman
ratingvalue: 4.8
reviewcount: 15
recipeingredient:
- "potong kecil Dada ayam"
- "3 lembar daun salam"
- "1 batang serai memarkan"
- "1 ruas lengkuas"
- " Cabe rawit merah"
- " Daun bawang"
- "1 buah tomat"
- " Bumbu Halus"
- "3 siung bawang putih"
- "4 siung bawang merah"
- "2 ruas kunyit"
- "1 ruas jahe"
- "2 kemiri sangrai"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya kaldu jamur"
- "Secukupnya kecap manis"
- " Jeruk lemon"
recipeinstructions:
- "Potong-potong ayam, kemarin dada jadi 12 bagian. Siram dengan perasan jeruk lemon. Diamkan sekitar 15 menit. Setelah itu cuci bersih, rebus setengah matang, angkat dan tiriskan."
- "Tumis salam, sereh, bumbu halus hingga matang. Masukkan ayam yang sudah di rebus. Siram dengan perasan jeruk lemon. Aduk-aduk."
- "Tambahkan kecap, air, garam, gula, kaldu jamur. Tes rasa. Masak dengan api kecil."
- "Iris cabe rawit merah sesuai selera, masukkan. Jika sudah matang matikan kompor. Masukkan irisan daun bawang dan tomat. Aduk sebentar."
- "Angkat dan sajikan."
categories:
- Resep
tags:
- tongseng
- ayam

katakunci: tongseng ayam 
nutrition: 207 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Tongseng Ayam](https://img-global.cpcdn.com/recipes/f1f0fd9a2568b8b7/680x482cq70/tongseng-ayam-foto-resep-utama.jpg)

Apabila kita seorang ibu, menyediakan olahan sedap bagi keluarga adalah suatu hal yang sangat menyenangkan untuk kamu sendiri. Tugas seorang istri bukan cuman menjaga rumah saja, tapi anda pun harus menyediakan kebutuhan nutrisi tercukupi dan hidangan yang disantap keluarga tercinta mesti nikmat.

Di masa  sekarang, kalian sebenarnya mampu mengorder masakan praktis meski tanpa harus capek memasaknya lebih dulu. Namun ada juga lho mereka yang memang ingin memberikan hidangan yang terlezat bagi orang tercintanya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga. 



Mungkinkah anda salah satu penggemar tongseng ayam?. Asal kamu tahu, tongseng ayam adalah sajian khas di Indonesia yang sekarang digemari oleh kebanyakan orang di berbagai daerah di Indonesia. Kita dapat membuat tongseng ayam sendiri di rumahmu dan dapat dijadikan camilan favoritmu di akhir pekan.

Kita tidak usah bingung untuk memakan tongseng ayam, sebab tongseng ayam sangat mudah untuk dicari dan kamu pun bisa mengolahnya sendiri di rumah. tongseng ayam bisa dimasak memalui beraneka cara. Kini pun telah banyak banget cara kekinian yang menjadikan tongseng ayam semakin lebih mantap.

Resep tongseng ayam juga gampang dihidangkan, lho. Kita tidak perlu ribet-ribet untuk memesan tongseng ayam, sebab Anda mampu menyajikan di rumahmu. Bagi Kalian yang mau membuatnya, berikut ini cara untuk membuat tongseng ayam yang lezat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Tongseng Ayam:

1. Siapkan potong kecil Dada ayam
1. Gunakan 3 lembar daun salam
1. Sediakan 1 batang serai, memarkan
1. Gunakan 1 ruas lengkuas
1. Gunakan  Cabe rawit merah
1. Ambil  Daun bawang
1. Ambil 1 buah tomat
1. Sediakan  Bumbu Halus
1. Siapkan 3 siung bawang putih
1. Gunakan 4 siung bawang merah
1. Siapkan 2 ruas kunyit
1. Ambil 1 ruas jahe
1. Gunakan 2 kemiri sangrai
1. Siapkan Secukupnya garam
1. Sediakan Secukupnya gula pasir
1. Sediakan Secukupnya kaldu jamur
1. Gunakan Secukupnya kecap manis
1. Sediakan  Jeruk lemon




<!--inarticleads2-->

##### Cara membuat Tongseng Ayam:

1. Potong-potong ayam, kemarin dada jadi 12 bagian. Siram dengan perasan jeruk lemon. Diamkan sekitar 15 menit. Setelah itu cuci bersih, rebus setengah matang, angkat dan tiriskan.
1. Tumis salam, sereh, bumbu halus hingga matang. Masukkan ayam yang sudah di rebus. Siram dengan perasan jeruk lemon. Aduk-aduk.
1. Tambahkan kecap, air, garam, gula, kaldu jamur. Tes rasa. Masak dengan api kecil.
1. Iris cabe rawit merah sesuai selera, masukkan. Jika sudah matang matikan kompor. Masukkan irisan daun bawang dan tomat. Aduk sebentar.
1. Angkat dan sajikan.




Wah ternyata resep tongseng ayam yang nikamt sederhana ini mudah banget ya! Kamu semua mampu menghidangkannya. Resep tongseng ayam Sangat cocok banget untuk kita yang baru mau belajar memasak atau juga bagi kalian yang telah lihai memasak.

Tertarik untuk mulai mencoba membikin resep tongseng ayam enak tidak rumit ini? Kalau anda tertarik, ayo kamu segera siapkan peralatan dan bahannya, lantas buat deh Resep tongseng ayam yang nikmat dan tidak ribet ini. Sangat taidak sulit kan. 

Maka dari itu, daripada kita berlama-lama, yuk langsung aja sajikan resep tongseng ayam ini. Dijamin kamu gak akan nyesel sudah membuat resep tongseng ayam lezat tidak rumit ini! Selamat berkreasi dengan resep tongseng ayam mantab tidak rumit ini di rumah masing-masing,ya!.

