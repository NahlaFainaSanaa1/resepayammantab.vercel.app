---
description: "Cara buat Chicken lava yang nikmat dan Mudah Dibuat"
title: "Cara buat Chicken lava yang nikmat dan Mudah Dibuat"
slug: 25-cara-buat-chicken-lava-yang-nikmat-dan-mudah-dibuat
date: 2021-04-08T23:01:38.204Z
image: https://img-global.cpcdn.com/recipes/cbd50ea8b9b08b5c/680x482cq70/chicken-lava-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cbd50ea8b9b08b5c/680x482cq70/chicken-lava-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cbd50ea8b9b08b5c/680x482cq70/chicken-lava-foto-resep-utama.jpg
author: Jon McKinney
ratingvalue: 4.4
reviewcount: 12
recipeingredient:
- "300 gr ayam fillet"
- "2 siung bawang putih"
- "1 buah jeruk nipis"
- "1 sdt cabai bubuk"
- "1 bungkus tepung serbaguna ayam krispy"
- " Minyak goreng"
- " Saus lava"
- "1/2 buab bawang bombai"
- "200 gr saos hot lava"
- "30 gr saus tomat"
- "30 gr saus sambal"
- "1 sdm gula pasir"
- "1/2 sdt kaldu"
- "1/2 sdt garam"
- "20 ml air"
- "2 sdm margarin  minyak goreng"
recipeinstructions:
- "Potong dadu ayam fillet, cuci bersoh dan tiriskan."
- "Parut bawang putih campurkan air perasan jeruk nipis dan cabai bubuk aduk rata. Masukkan ayam dan marinasi selama 30 menit"
- "Siapkan 3 sdm tepung dan campurkan air aduk rata, masukkan ayam dan balur dengan tepung kering lalu goreng di minyak panas. Lakukan sampai ayam habis."
- "Membuat saus, cincang bawang bombay tumis hingga wangi. Masukkan semua bahan saus. Aduk rata dan beri sedikit air. Cek rasa."
- "Jika saus sudah meletup-letup masukkan ayam yg sudah di goreng. Aduk hingga rata."
categories:
- Resep
tags:
- chicken
- lava

katakunci: chicken lava 
nutrition: 139 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dinner

---


![Chicken lava](https://img-global.cpcdn.com/recipes/cbd50ea8b9b08b5c/680x482cq70/chicken-lava-foto-resep-utama.jpg)

Jika kalian seorang yang hobi masak, menyajikan masakan lezat buat keluarga merupakan hal yang membahagiakan bagi kita sendiri. Tugas seorang ibu Tidak saja mengurus rumah saja, tetapi kamu juga wajib memastikan kebutuhan gizi tercukupi dan masakan yang disantap keluarga tercinta harus lezat.

Di zaman  saat ini, kamu memang mampu membeli olahan siap saji meski tidak harus repot membuatnya terlebih dahulu. Tapi ada juga orang yang selalu ingin menyajikan yang terenak bagi keluarganya. Karena, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan keluarga. 



Mungkinkah kamu salah satu penggemar chicken lava?. Tahukah kamu, chicken lava adalah makanan khas di Indonesia yang saat ini disenangi oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Kita bisa membuat chicken lava buatan sendiri di rumahmu dan boleh dijadikan hidangan kesenanganmu di hari liburmu.

Kalian jangan bingung jika kamu ingin mendapatkan chicken lava, sebab chicken lava sangat mudah untuk didapatkan dan juga kalian pun bisa mengolahnya sendiri di rumah. chicken lava bisa dimasak lewat berbagai cara. Kini pun sudah banyak cara kekinian yang menjadikan chicken lava lebih mantap.

Resep chicken lava pun gampang sekali untuk dibikin, lho. Kalian jangan repot-repot untuk memesan chicken lava, karena Kita mampu membuatnya ditempatmu. Untuk Kalian yang mau menyajikannya, dibawah ini merupakan resep menyajikan chicken lava yang lezat yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Chicken lava:

1. Gunakan 300 gr ayam fillet
1. Siapkan 2 siung bawang putih
1. Ambil 1 buah jeruk nipis
1. Sediakan 1 sdt cabai bubuk
1. Gunakan 1 bungkus tepung serbaguna ayam krispy
1. Gunakan  Minyak goreng
1. Ambil  Saus lava
1. Siapkan 1/2 buab bawang bombai
1. Sediakan 200 gr saos hot lava
1. Ambil 30 gr saus tomat
1. Gunakan 30 gr saus sambal
1. Gunakan 1 sdm gula pasir
1. Sediakan 1/2 sdt kaldu
1. Gunakan 1/2 sdt garam
1. Siapkan 20 ml air
1. Ambil 2 sdm margarin / minyak goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Chicken lava:

1. Potong dadu ayam fillet, cuci bersoh dan tiriskan.
1. Parut bawang putih campurkan air perasan jeruk nipis dan cabai bubuk aduk rata. Masukkan ayam dan marinasi selama 30 menit
1. Siapkan 3 sdm tepung dan campurkan air aduk rata, masukkan ayam dan balur dengan tepung kering lalu goreng di minyak panas. Lakukan sampai ayam habis.
1. Membuat saus, cincang bawang bombay tumis hingga wangi. Masukkan semua bahan saus. Aduk rata dan beri sedikit air. Cek rasa.
1. Jika saus sudah meletup-letup masukkan ayam yg sudah di goreng. Aduk hingga rata.




Ternyata cara membuat chicken lava yang enak tidak rumit ini mudah banget ya! Anda Semua mampu memasaknya. Cara Membuat chicken lava Sangat sesuai sekali untuk anda yang baru belajar memasak atau juga bagi kamu yang sudah hebat dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep chicken lava nikmat tidak ribet ini? Kalau kalian tertarik, mending kamu segera menyiapkan peralatan dan bahan-bahannya, setelah itu buat deh Resep chicken lava yang enak dan tidak ribet ini. Sangat gampang kan. 

Oleh karena itu, ketimbang kita diam saja, ayo kita langsung bikin resep chicken lava ini. Pasti anda gak akan menyesal sudah membuat resep chicken lava enak simple ini! Selamat mencoba dengan resep chicken lava enak simple ini di rumah sendiri,ya!.

