---
description: "Cara buat Ayam koloke bumbu asam manis yang nikmat Untuk Jualan"
title: "Cara buat Ayam koloke bumbu asam manis yang nikmat Untuk Jualan"
slug: 157-cara-buat-ayam-koloke-bumbu-asam-manis-yang-nikmat-untuk-jualan
date: 2021-06-08T08:08:28.200Z
image: https://img-global.cpcdn.com/recipes/a08c3e9a32522641/680x482cq70/ayam-koloke-bumbu-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a08c3e9a32522641/680x482cq70/ayam-koloke-bumbu-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a08c3e9a32522641/680x482cq70/ayam-koloke-bumbu-asam-manis-foto-resep-utama.jpg
author: Harvey Hunt
ratingvalue: 4.4
reviewcount: 7
recipeingredient:
- " Bahan lauk"
- "1 kg Ayam"
- " Tepung terigu secukupnya"
- " Merica bubuk"
- "secukupnya Garam"
- " Bahan saus"
- "4 buah cabai merah iris miring"
- "1 buah bawang bombay iris"
- " Tomat 1 buah iris sesuai selera"
- "1 buah wortel iris panjang2"
- "3 siung bawang putih"
- "1/2 cm ruas jahe digeprek"
- "1 batang daun bawang"
- "Secukupnya kaldu ayamjamur"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- " Saus tomat"
- "Secukupnya air"
- "1 sdm gula"
- "1,5 sdm telung maizena"
recipeinstructions:
- "Balur ayam yang telah dipotong dadu (atau sesuai selera) dengan garam dan merica bubuk secukupnya. Diamkan 15-20menit agar bumbu meresap kedalam ayam. Setelah itu balur dengan tepung terigu-celup air- terigu. Kemudian goreng."
- "Siapkan bahan saus. Tumis ke wajan yang telah diberi 3sdm minyak, masukkan bahan saus berurutan. Masukan semua bumbu saus kecuali air dan tepung maizena."
- "Ketika wortel sudah mulai lemas, masukkan air secukupnya,, aduk merata hingga rasa saus telah sesuai dengan selera. (Jika dirasa gula, garam, dan saus kurang, dapat ditambah sesuai selera."
- "Sudah jadi deh, oh iy, kalau bisa saus dan ayamnya dipisah ya, di sajikan bersamaan ketika hendak dimakan, agar ayamnya masih crispy ❤️"
categories:
- Resep
tags:
- ayam
- koloke
- bumbu

katakunci: ayam koloke bumbu 
nutrition: 136 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam koloke bumbu asam manis](https://img-global.cpcdn.com/recipes/a08c3e9a32522641/680x482cq70/ayam-koloke-bumbu-asam-manis-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan panganan sedap bagi keluarga merupakan hal yang sangat menyenangkan bagi kita sendiri. Kewajiban seorang istri Tidak cuman mengerjakan pekerjaan rumah saja, tapi kamu pun harus memastikan keperluan gizi terpenuhi dan juga masakan yang dimakan keluarga tercinta harus sedap.

Di masa  saat ini, anda sebenarnya dapat memesan panganan yang sudah jadi meski tanpa harus ribet memasaknya terlebih dahulu. Tapi ada juga lho mereka yang selalu mau memberikan yang terlezat bagi orang tercintanya. Sebab, menghidangkan masakan sendiri jauh lebih bersih dan bisa menyesuaikan sesuai kesukaan keluarga. 



Apakah anda salah satu penikmat ayam koloke bumbu asam manis?. Tahukah kamu, ayam koloke bumbu asam manis adalah makanan khas di Nusantara yang saat ini digemari oleh banyak orang dari hampir setiap wilayah di Indonesia. Anda bisa menghidangkan ayam koloke bumbu asam manis sendiri di rumah dan pasti jadi santapan favoritmu di akhir pekan.

Kamu tidak perlu bingung untuk menyantap ayam koloke bumbu asam manis, lantaran ayam koloke bumbu asam manis mudah untuk ditemukan dan kalian pun bisa mengolahnya sendiri di rumah. ayam koloke bumbu asam manis boleh dimasak lewat beraneka cara. Kini pun ada banyak cara kekinian yang menjadikan ayam koloke bumbu asam manis semakin mantap.

Resep ayam koloke bumbu asam manis pun sangat mudah dibuat, lho. Kamu tidak perlu capek-capek untuk memesan ayam koloke bumbu asam manis, lantaran Kalian bisa membuatnya sendiri di rumah. Untuk Kamu yang mau mencobanya, berikut ini cara untuk menyajikan ayam koloke bumbu asam manis yang nikamat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam koloke bumbu asam manis:

1. Sediakan  Bahan lauk
1. Sediakan 1 kg Ayam
1. Siapkan  Tepung terigu (secukupnya)
1. Gunakan  Merica bubuk
1. Sediakan secukupnya Garam
1. Gunakan  Bahan saus
1. Gunakan 4 buah cabai merah (iris miring)
1. Sediakan 1 buah bawang bombay (iris)
1. Ambil  Tomat 1 buah (iris sesuai selera)
1. Siapkan 1 buah wortel (iris panjang2)
1. Siapkan 3 siung bawang putih
1. Sediakan 1/2 cm ruas jahe (digeprek)
1. Gunakan 1 batang daun bawang
1. Siapkan Secukupnya kaldu (ayam/jamur)
1. Sediakan Secukupnya garam
1. Ambil Secukupnya gula pasir
1. Sediakan  Saus tomat
1. Siapkan Secukupnya air
1. Gunakan 1 sdm gula
1. Gunakan 1,5 sdm telung maizena




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam koloke bumbu asam manis:

1. Balur ayam yang telah dipotong dadu (atau sesuai selera) dengan garam dan merica bubuk secukupnya. Diamkan 15-20menit agar bumbu meresap kedalam ayam. Setelah itu balur dengan tepung terigu-celup air- terigu. Kemudian goreng.
1. Siapkan bahan saus. Tumis ke wajan yang telah diberi 3sdm minyak, masukkan bahan saus berurutan. Masukan semua bumbu saus kecuali air dan tepung maizena.
1. Ketika wortel sudah mulai lemas, masukkan air secukupnya,, aduk merata hingga rasa saus telah sesuai dengan selera. (Jika dirasa gula, garam, dan saus kurang, dapat ditambah sesuai selera.
1. Sudah jadi deh, oh iy, kalau bisa saus dan ayamnya dipisah ya, di sajikan bersamaan ketika hendak dimakan, agar ayamnya masih crispy ❤️




Wah ternyata cara membuat ayam koloke bumbu asam manis yang nikamt tidak ribet ini enteng banget ya! Semua orang mampu memasaknya. Resep ayam koloke bumbu asam manis Sangat cocok sekali untuk kalian yang baru akan belajar memasak ataupun bagi kamu yang telah lihai memasak.

Apakah kamu mau mencoba membuat resep ayam koloke bumbu asam manis lezat tidak rumit ini? Kalau kalian mau, yuk kita segera buruan siapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam koloke bumbu asam manis yang mantab dan sederhana ini. Sangat gampang kan. 

Maka, daripada kalian berlama-lama, maka kita langsung hidangkan resep ayam koloke bumbu asam manis ini. Dijamin anda tiidak akan nyesel sudah bikin resep ayam koloke bumbu asam manis nikmat tidak ribet ini! Selamat berkreasi dengan resep ayam koloke bumbu asam manis nikmat sederhana ini di rumah sendiri,oke!.

