---
description: "Resep memasak Tongseng Ayam yang sedap Untuk Jualan"
title: "Resep memasak Tongseng Ayam yang sedap Untuk Jualan"
slug: 465-resep-memasak-tongseng-ayam-yang-sedap-untuk-jualan
date: 2021-01-14T19:42:27.503Z
image: https://img-global.cpcdn.com/recipes/218b8a346b3cd643/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/218b8a346b3cd643/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/218b8a346b3cd643/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
author: Rose Patrick
ratingvalue: 4.9
reviewcount: 14
recipeingredient:
- "800 gr dada ayam fillet potong kecil"
- "1 buah kentang ukuran besar kupas dan potongpotong saya skip"
- "200 gr kol potongpotong"
- "2 sereh geprek"
- "65 ml santan cair instant"
- "1 ruas lengkuas geprek"
- "3 lembar daun salam"
- "3 lembar daun jeruk buang tulang daun"
- "12 buah cabe rawit utuh sesuaikan selera"
- "1 buat tomat"
- "2 sdm kaldu jamur ayam optional"
- "1 sdt gula pasir"
- "1/2 sdt garam"
- "700 ml air"
- "Secukupnya kecap manis dan minyak sayur untuk menumis"
- " BUMBU HALUS "
- "10 siung bawang merah"
- "6 siung bawang putih"
- "1 sdt ketumbar"
- "1/2 sdt lada bubuk"
- "1 ruas kunyit"
- "1 sdt jintan bubuk tambahan saya"
recipeinstructions:
- "Cuci bersih ayam, kemudian potong-potong dan remas-remas dengan garam dan air perasan jeruk nipis. Bilas sebentar."
- "Siapkan panci, rebus air dan ayam hingga matang selama 20 menit. Kemudian buang airnya &amp; sisihkan"
- "Tumis bumbu halus hingga harum lalu masukkan sereh, lengkuas, daun salam, daun jeruk dan tumis hingga rata"
- "Masukkan ayam lalu tambahkan air aduk hingga rata dan masak hingga mendidih"
- "Masukkan garam, kaldu bubuk, gula dan kecap manis. Tambahkan cabe rawit aduk perlahan dan koreksi rasa"
- "Masukkan santan lalu aduk hingga rata dan masukkan kol sambil terus diaduk rata sebentar lalu matikan kompor"
- "Tongseng ayam dituang ke piring saji lalu taburi bawang goreng dan daun bawang / seledri, hidangkan"
categories:
- Resep
tags:
- tongseng
- ayam

katakunci: tongseng ayam 
nutrition: 159 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner

---


![Tongseng Ayam](https://img-global.cpcdn.com/recipes/218b8a346b3cd643/680x482cq70/tongseng-ayam-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan panganan enak buat famili adalah hal yang menggembirakan bagi kita sendiri. Kewajiban seorang ibu Tidak hanya mengerjakan pekerjaan rumah saja, tapi kamu pun harus menyediakan keperluan gizi terpenuhi dan juga santapan yang dikonsumsi anak-anak mesti sedap.

Di masa  sekarang, kalian sebenarnya mampu memesan masakan yang sudah jadi tanpa harus susah mengolahnya dahulu. Tetapi banyak juga orang yang memang mau memberikan yang terbaik bagi orang yang dicintainya. Pasalnya, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan keluarga. 



Apakah anda merupakan salah satu penikmat tongseng ayam?. Asal kamu tahu, tongseng ayam adalah hidangan khas di Nusantara yang sekarang digemari oleh banyak orang di berbagai daerah di Indonesia. Kamu bisa memasak tongseng ayam kreasi sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di akhir pekan.

Kalian tidak usah bingung untuk menyantap tongseng ayam, karena tongseng ayam tidak sukar untuk didapatkan dan juga kita pun boleh membuatnya sendiri di rumah. tongseng ayam bisa diolah dengan beragam cara. Saat ini ada banyak resep modern yang membuat tongseng ayam semakin lebih mantap.

Resep tongseng ayam pun mudah untuk dibikin, lho. Kamu tidak usah repot-repot untuk membeli tongseng ayam, sebab Kalian mampu membuatnya di rumah sendiri. Bagi Anda yang hendak membuatnya, berikut resep untuk membuat tongseng ayam yang nikamat yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Tongseng Ayam:

1. Siapkan 800 gr dada ayam fillet, potong kecil
1. Ambil 1 buah kentang ukuran besar, kupas dan potong-potong (saya skip)
1. Ambil 200 gr kol, potong-potong
1. Gunakan 2 sereh geprek
1. Siapkan 65 ml santan cair instant
1. Siapkan 1 ruas lengkuas geprek
1. Gunakan 3 lembar daun salam
1. Ambil 3 lembar daun jeruk buang tulang daun
1. Siapkan 12 buah cabe rawit utuh (sesuaikan selera)
1. Sediakan 1 buat tomat
1. Sediakan 2 sdm kaldu jamur /ayam (optional)
1. Sediakan 1 sdt gula pasir
1. Ambil 1/2 sdt garam
1. Gunakan 700 ml air
1. Siapkan Secukupnya kecap manis dan minyak sayur untuk menumis
1. Sediakan  BUMBU HALUS :
1. Sediakan 10 siung bawang merah
1. Gunakan 6 siung bawang putih
1. Siapkan 1 sdt ketumbar
1. Ambil 1/2 sdt lada bubuk
1. Gunakan 1 ruas kunyit
1. Gunakan 1 sdt jintan bubuk (tambahan saya)




<!--inarticleads2-->

##### Cara menyiapkan Tongseng Ayam:

1. Cuci bersih ayam, kemudian potong-potong dan remas-remas dengan garam dan air perasan jeruk nipis. Bilas sebentar.
1. Siapkan panci, rebus air dan ayam hingga matang selama 20 menit. Kemudian buang airnya &amp; sisihkan
1. Tumis bumbu halus hingga harum lalu masukkan sereh, lengkuas, daun salam, daun jeruk dan tumis hingga rata
1. Masukkan ayam lalu tambahkan air aduk hingga rata dan masak hingga mendidih
1. Masukkan garam, kaldu bubuk, gula dan kecap manis. Tambahkan cabe rawit aduk perlahan dan koreksi rasa
1. Masukkan santan lalu aduk hingga rata dan masukkan kol sambil terus diaduk rata sebentar lalu matikan kompor
1. Tongseng ayam dituang ke piring saji lalu taburi bawang goreng dan daun bawang / seledri, hidangkan




Wah ternyata cara buat tongseng ayam yang lezat tidak ribet ini gampang sekali ya! Semua orang mampu mencobanya. Cara buat tongseng ayam Sangat cocok sekali buat kalian yang baru belajar memasak maupun untuk kamu yang sudah pandai memasak.

Apakah kamu ingin mulai mencoba buat resep tongseng ayam lezat sederhana ini? Kalau anda mau, yuk kita segera buruan siapkan peralatan dan bahan-bahannya, maka bikin deh Resep tongseng ayam yang enak dan sederhana ini. Betul-betul gampang kan. 

Jadi, ketimbang kamu diam saja, hayo kita langsung hidangkan resep tongseng ayam ini. Dijamin kamu gak akan nyesel sudah membuat resep tongseng ayam nikmat simple ini! Selamat berkreasi dengan resep tongseng ayam mantab simple ini di rumah masing-masing,ya!.

