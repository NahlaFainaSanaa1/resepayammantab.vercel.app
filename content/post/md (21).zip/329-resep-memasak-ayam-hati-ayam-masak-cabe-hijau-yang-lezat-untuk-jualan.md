---
description: "Resep memasak Ayam + hati ayam masak cabe hijau yang lezat Untuk Jualan"
title: "Resep memasak Ayam + hati ayam masak cabe hijau yang lezat Untuk Jualan"
slug: 329-resep-memasak-ayam-hati-ayam-masak-cabe-hijau-yang-lezat-untuk-jualan
date: 2021-02-28T05:30:29.840Z
image: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
author: Gussie Campbell
ratingvalue: 4.2
reviewcount: 3
recipeingredient:
- "1/2 ekor ayam"
- "3 hati ayam  ampela"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "8 cabe hijau besar bagusnya sih 15 cabe atau sesuai selera"
- "10 cabe rawit tergantung selera"
- "2 tomat merah ukuran sedang harus tomat hijau 34 buah"
- "2 batang serai geprek"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 lembar daun kunyit"
- "1 cm kunyit"
- "1 cm jahe"
- "1 cm lengkuas"
- "3 biji kemiri"
- "1/2 sdm ketumbar"
- "1/2 sdm merica"
- "2 asam gandis boleh pake air asam jawa"
- " Penyedap"
- " Gula"
- " Minyak goreng"
- " Air bersih"
recipeinstructions:
- "Bersihkan ayam dan jeroannya, lalu potong sesuai selera, saya rebus jeroannya dulu yah biar gak bau amis, bisa direbus langsung atau ditambah garam dan daun jeruk"
- "Haluskan bawang, jahe, lengkuas, kunyit, kemiri, tomat dan cabe lalu tumis hingga wangi lalu masukan serai, daun jeruk, daun salam tumis hingga mateng"
- "Masukan ayam dan jeroan, dan asam aduk hingga bumbu tercampur rata, lalu tambah air secukupnya, masak hingga air berkurang setengah tambahakn penyedap, garam, gula, ketumbar, merica (atau ini ditambah pas lagi numis bumbu juga gpp)"
- "Koreksi rasa, masak hingga matang dan daging ayam empuk, angkat dan sajikan dengan nasi hangat"
categories:
- Resep
tags:
- ayam
- 
- hati

katakunci: ayam  hati 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam + hati ayam masak cabe hijau](https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg)

Jika kalian seorang orang tua, mempersiapkan panganan mantab untuk keluarga merupakan hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang istri bukan cuman mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib memastikan keperluan nutrisi terpenuhi dan juga hidangan yang disantap keluarga tercinta wajib lezat.

Di masa  sekarang, kita sebenarnya mampu memesan santapan instan meski tidak harus repot membuatnya dahulu. Tapi banyak juga lho orang yang selalu mau memberikan yang terenak untuk orang tercintanya. Karena, menghidangkan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga tercinta. 



Mungkinkah kamu salah satu penggemar ayam + hati ayam masak cabe hijau?. Tahukah kamu, ayam + hati ayam masak cabe hijau merupakan hidangan khas di Nusantara yang kini disenangi oleh setiap orang dari hampir setiap daerah di Nusantara. Kamu bisa menghidangkan ayam + hati ayam masak cabe hijau olahan sendiri di rumahmu dan boleh jadi camilan kesukaanmu di akhir pekan.

Anda tidak usah bingung untuk menyantap ayam + hati ayam masak cabe hijau, sebab ayam + hati ayam masak cabe hijau tidak sulit untuk dicari dan anda pun boleh memasaknya sendiri di tempatmu. ayam + hati ayam masak cabe hijau bisa diolah dengan berbagai cara. Saat ini telah banyak banget cara kekinian yang menjadikan ayam + hati ayam masak cabe hijau semakin lebih lezat.

Resep ayam + hati ayam masak cabe hijau juga gampang sekali dibikin, lho. Kalian tidak perlu capek-capek untuk membeli ayam + hati ayam masak cabe hijau, lantaran Anda mampu menghidangkan di rumahmu. Bagi Kalian yang hendak mencobanya, berikut ini resep menyajikan ayam + hati ayam masak cabe hijau yang mantab yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam + hati ayam masak cabe hijau:

1. Sediakan 1/2 ekor ayam
1. Gunakan 3 hati ayam + ampela
1. Siapkan 8 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Sediakan 8 cabe hijau besar (bagusnya sih 15 cabe atau sesuai selera)
1. Sediakan 10 cabe rawit (tergantung selera)
1. Siapkan 2 tomat merah ukuran sedang (harus tomat hijau 3-4 buah)
1. Gunakan 2 batang serai (geprek)
1. Sediakan 3 lembar daun salam
1. Ambil 5 lembar daun jeruk
1. Sediakan 1 lembar daun kunyit
1. Siapkan 1 cm kunyit
1. Sediakan 1 cm jahe
1. Sediakan 1 cm lengkuas
1. Siapkan 3 biji kemiri
1. Sediakan 1/2 sdm ketumbar
1. Gunakan 1/2 sdm merica
1. Gunakan 2 asam gandis (boleh pake air asam jawa)
1. Gunakan  Penyedap
1. Sediakan  Gula
1. Ambil  Minyak goreng
1. Siapkan  Air bersih




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam + hati ayam masak cabe hijau:

1. Bersihkan ayam dan jeroannya, lalu potong sesuai selera, saya rebus jeroannya dulu yah biar gak bau amis, bisa direbus langsung atau ditambah garam dan daun jeruk
1. Haluskan bawang, jahe, lengkuas, kunyit, kemiri, tomat dan cabe lalu tumis hingga wangi lalu masukan serai, daun jeruk, daun salam tumis hingga mateng
1. Masukan ayam dan jeroan, dan asam aduk hingga bumbu tercampur rata, lalu tambah air secukupnya, masak hingga air berkurang setengah tambahakn penyedap, garam, gula, ketumbar, merica (atau ini ditambah pas lagi numis bumbu juga gpp)
1. Koreksi rasa, masak hingga matang dan daging ayam empuk, angkat dan sajikan dengan nasi hangat




Ternyata resep ayam + hati ayam masak cabe hijau yang nikamt tidak ribet ini gampang sekali ya! Kalian semua dapat memasaknya. Cara buat ayam + hati ayam masak cabe hijau Sangat sesuai sekali buat kita yang baru mau belajar memasak atau juga bagi kamu yang sudah jago dalam memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam + hati ayam masak cabe hijau nikmat tidak rumit ini? Kalau anda ingin, yuk kita segera buruan siapkan peralatan dan bahan-bahannya, maka bikin deh Resep ayam + hati ayam masak cabe hijau yang mantab dan sederhana ini. Benar-benar gampang kan. 

Maka dari itu, daripada kita berfikir lama-lama, maka kita langsung saja bikin resep ayam + hati ayam masak cabe hijau ini. Dijamin kalian tak akan menyesal sudah buat resep ayam + hati ayam masak cabe hijau lezat simple ini! Selamat berkreasi dengan resep ayam + hati ayam masak cabe hijau nikmat tidak ribet ini di rumah kalian masing-masing,ya!.

