---
description: "Bahan-bahan Coto Ayam Makassar Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Coto Ayam Makassar Sederhana dan Mudah Dibuat"
slug: 65-bahan-bahan-coto-ayam-makassar-sederhana-dan-mudah-dibuat
date: 2021-03-26T15:55:28.717Z
image: https://img-global.cpcdn.com/recipes/53a4ff5c80d5228e/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/53a4ff5c80d5228e/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/53a4ff5c80d5228e/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Francis Tate
ratingvalue: 4.6
reviewcount: 6
recipeingredient:
- "1 ekor ayam 1kg"
- "2 liter air cucian beras yg pertama"
- "1 kaleng susu beruang"
- "2 batang serai"
- "100 gr kacang tanah goreng"
- "secukupnya Garam"
- "secukupnya Kaldu bubuk"
- " Bahan rempah"
- "15 buah cengkeh"
- "1 sdm ketumbar biji"
- "1 sdm merica biji"
- "1/2 sdm jintan"
- "2 ruas jari kayu manis"
- "1 buah pala"
- " Bahan bumbu"
- "100 gr lengkuas"
- "50 gr jahe"
- "50 gr bawang merah"
- "50 gr bawang putih"
recipeinstructions:
- "Siapkan bahan-bahannya. Maafkan karena ga semua terfoto 😁"
- "Goreng bahan rempah hingga harum dan agak kering lalu uleg hingga halus. Setelah itu uleg bahan bumbu bersama bahan rempah. Jika bahan rempah dan bumbunya ingin diuleg, saya sarankan lengkuas dan jahe nya diparut terlebih dahulu biar memudahkan diuleg. Kecuali ingin bahannya diblender hingga halus."
- "Sambil menyiapkan bumbu, didihkan air cucian beras pertama yang telah disaring lalu masukkan daging ayam. Biasanya kalau menggunakan daging sapi, dagingnya direbus dalam ukuran besar. Setelah matang lalu daging diangkat dan ditiriskan. Setelah itulah baru kuah diberi bumbu. Tapi berhubung saya tidak ingin repot jadi daging ayamnya sudah sy potong-potong terlebih dahulu dan langsung sy masak sekaligus dengan bumbu 😁. Oya jangan lupa serai yang digeprek ditambahkan saat merebus dagingnya."
- "Sambil menunggu kuah mendidih, tumis bahan bumbu rempah hingga wangi."
- "Sambil menumis, uleg kacang tanah hingga halus. Lalu tambahkan ke tumisan bumbu rempah. Aduk hingga rata. Nah bumbu rempah yang telah ditambah kacang goreng inilah bumbu coto nya. Dan bumbu ini bisa disimpan di kulkas. Jadi gunakan secukupnya sesuai kebutuhan. Tapi yg jelas takaran bumbu ini untuk 1 ekor ayam 1kg ya hehe."
- "Tambahkan bumbu coto ke dalam kuah rebusan daging. Tambahkan garam dan kaldu ayam secukupnya. Terakhir masukkan susu beruang."
- "Jangan lupa memberi potongan daun bawang dan bawang goreng saat akan menyajikannya. Coto Makassar ini paling cocok disantap bersama ketupat 😍"
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Dinner

---


![Coto Ayam Makassar](https://img-global.cpcdn.com/recipes/53a4ff5c80d5228e/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan masakan nikmat bagi keluarga tercinta adalah hal yang menggembirakan bagi kita sendiri. Tanggung jawab seorang istri bukan sekadar mengurus rumah saja, namun anda pun harus menyediakan kebutuhan nutrisi tercukupi dan juga masakan yang dikonsumsi orang tercinta mesti menggugah selera.

Di waktu  sekarang, kalian memang dapat memesan masakan siap saji tidak harus ribet mengolahnya terlebih dahulu. Tapi banyak juga lho mereka yang memang mau menyajikan yang terlezat bagi orang tercintanya. Pasalnya, memasak yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan orang tercinta. 



Mungkinkah kamu seorang penggemar coto ayam makassar?. Tahukah kamu, coto ayam makassar adalah sajian khas di Nusantara yang sekarang disukai oleh setiap orang di berbagai daerah di Nusantara. Kalian dapat menyajikan coto ayam makassar kreasi sendiri di rumah dan pasti jadi hidangan favoritmu di hari liburmu.

Kalian jangan bingung untuk memakan coto ayam makassar, karena coto ayam makassar sangat mudah untuk ditemukan dan juga kamu pun bisa memasaknya sendiri di tempatmu. coto ayam makassar dapat dimasak dengan bermacam cara. Saat ini sudah banyak sekali resep kekinian yang menjadikan coto ayam makassar semakin lebih lezat.

Resep coto ayam makassar pun mudah dibikin, lho. Anda tidak perlu ribet-ribet untuk memesan coto ayam makassar, karena Kamu dapat menghidangkan ditempatmu. Untuk Kita yang ingin menyajikannya, berikut cara untuk menyajikan coto ayam makassar yang enak yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Coto Ayam Makassar:

1. Ambil 1 ekor ayam 1kg
1. Ambil 2 liter air cucian beras yg pertama
1. Sediakan 1 kaleng susu beruang
1. Gunakan 2 batang serai
1. Gunakan 100 gr kacang tanah goreng
1. Gunakan secukupnya Garam
1. Ambil secukupnya Kaldu bubuk
1. Ambil  Bahan rempah:
1. Gunakan 15 buah cengkeh
1. Ambil 1 sdm ketumbar biji
1. Siapkan 1 sdm merica biji
1. Ambil 1/2 sdm jintan
1. Gunakan 2 ruas jari kayu manis
1. Ambil 1 buah pala
1. Ambil  Bahan bumbu:
1. Sediakan 100 gr lengkuas
1. Sediakan 50 gr jahe
1. Siapkan 50 gr bawang merah
1. Siapkan 50 gr bawang putih




<!--inarticleads2-->

##### Cara membuat Coto Ayam Makassar:

1. Siapkan bahan-bahannya. Maafkan karena ga semua terfoto 😁
1. Goreng bahan rempah hingga harum dan agak kering lalu uleg hingga halus. Setelah itu uleg bahan bumbu bersama bahan rempah. Jika bahan rempah dan bumbunya ingin diuleg, saya sarankan lengkuas dan jahe nya diparut terlebih dahulu biar memudahkan diuleg. Kecuali ingin bahannya diblender hingga halus.
1. Sambil menyiapkan bumbu, didihkan air cucian beras pertama yang telah disaring lalu masukkan daging ayam. Biasanya kalau menggunakan daging sapi, dagingnya direbus dalam ukuran besar. Setelah matang lalu daging diangkat dan ditiriskan. Setelah itulah baru kuah diberi bumbu. Tapi berhubung saya tidak ingin repot jadi daging ayamnya sudah sy potong-potong terlebih dahulu dan langsung sy masak sekaligus dengan bumbu 😁. Oya jangan lupa serai yang digeprek ditambahkan saat merebus dagingnya.
1. Sambil menunggu kuah mendidih, tumis bahan bumbu rempah hingga wangi.
1. Sambil menumis, uleg kacang tanah hingga halus. Lalu tambahkan ke tumisan bumbu rempah. Aduk hingga rata. Nah bumbu rempah yang telah ditambah kacang goreng inilah bumbu coto nya. Dan bumbu ini bisa disimpan di kulkas. Jadi gunakan secukupnya sesuai kebutuhan. Tapi yg jelas takaran bumbu ini untuk 1 ekor ayam 1kg ya hehe.
1. Tambahkan bumbu coto ke dalam kuah rebusan daging. Tambahkan garam dan kaldu ayam secukupnya. Terakhir masukkan susu beruang.
1. Jangan lupa memberi potongan daun bawang dan bawang goreng saat akan menyajikannya. Coto Makassar ini paling cocok disantap bersama ketupat 😍




Wah ternyata resep coto ayam makassar yang enak tidak ribet ini gampang sekali ya! Kita semua dapat memasaknya. Cara buat coto ayam makassar Sangat cocok sekali buat kita yang baru belajar memasak ataupun juga bagi kamu yang telah hebat memasak.

Tertarik untuk mencoba membikin resep coto ayam makassar mantab sederhana ini? Kalau mau, ayo kalian segera siapkan alat dan bahannya, lantas bikin deh Resep coto ayam makassar yang mantab dan simple ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kamu berfikir lama-lama, maka langsung aja hidangkan resep coto ayam makassar ini. Pasti kalian tiidak akan nyesel sudah buat resep coto ayam makassar mantab tidak ribet ini! Selamat mencoba dengan resep coto ayam makassar lezat tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

