---
description: "Resep Ayam Asam Manis Bumbu Rempah Sederhana dan Mudah Dibuat"
title: "Resep Ayam Asam Manis Bumbu Rempah Sederhana dan Mudah Dibuat"
slug: 159-resep-ayam-asam-manis-bumbu-rempah-sederhana-dan-mudah-dibuat
date: 2021-06-12T20:10:56.761Z
image: https://img-global.cpcdn.com/recipes/39522eaee6e3c6f3/680x482cq70/ayam-asam-manis-bumbu-rempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/39522eaee6e3c6f3/680x482cq70/ayam-asam-manis-bumbu-rempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/39522eaee6e3c6f3/680x482cq70/ayam-asam-manis-bumbu-rempah-foto-resep-utama.jpg
author: Harriett Barnes
ratingvalue: 4
reviewcount: 15
recipeingredient:
- "1 ekor ayam"
- "1 bungkus kecap me bango 3k"
- "1 bungkus kecil asam"
- "secukupnya Ketumbar"
- "3 butir Kemiri"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "4 cm kunyit"
- "2 cm jahe"
- "4 cm lengkuas"
- "1 buah gula merah"
- " Sereh"
- " Daun salam"
- "1 liter Air"
- "3 sendok makan gula pasir"
- "1 sendok teh garam"
- "secukupnya Kaldu bubuk"
recipeinstructions:
- "Cuci bersih ayam yg sudah dipotong potong"
- "Haluskan ketumbar, kemiri, bawang merah, bawang putih, kunyit, asam jawa, gula merah"
- "Tumis bumbu hingga harum kemudian geprek dan masukkan jahe, lengkuas, sereh dan daun salam"
- "Masukan ayam, aduk aduk agar bumbu meresap lalu tambahkan air, diamkan hingga mendidih"
- "Tambahkan kecap, gula pasir, garam, kaldu bubuk. Koreksi rasa lalu masak hingga air menyurut. Koreksi rasa kembali"
- "Setelah matang angkat dan sajikan dengan penuh cinta"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Asam Manis Bumbu Rempah](https://img-global.cpcdn.com/recipes/39522eaee6e3c6f3/680x482cq70/ayam-asam-manis-bumbu-rempah-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan santapan sedap pada keluarga merupakan hal yang menyenangkan untuk kita sendiri. Tugas seorang ibu Tidak hanya mengurus rumah saja, tetapi kamu pun harus menyediakan kebutuhan nutrisi terpenuhi dan juga santapan yang disantap orang tercinta wajib lezat.

Di waktu  saat ini, kalian memang bisa mengorder olahan siap saji meski tanpa harus susah mengolahnya lebih dulu. Tapi ada juga orang yang selalu mau menyajikan yang terlezat bagi keluarganya. Sebab, menyajikan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai kesukaan orang tercinta. 



Apakah anda adalah salah satu penikmat ayam asam manis bumbu rempah?. Tahukah kamu, ayam asam manis bumbu rempah merupakan makanan khas di Indonesia yang sekarang disukai oleh setiap orang dari berbagai daerah di Nusantara. Kita dapat membuat ayam asam manis bumbu rempah sendiri di rumahmu dan boleh dijadikan hidangan kesenanganmu di akhir pekanmu.

Kalian tidak usah bingung jika kamu ingin mendapatkan ayam asam manis bumbu rempah, karena ayam asam manis bumbu rempah tidak sulit untuk ditemukan dan kalian pun bisa menghidangkannya sendiri di tempatmu. ayam asam manis bumbu rempah boleh dimasak dengan beragam cara. Kini pun ada banyak banget cara kekinian yang menjadikan ayam asam manis bumbu rempah lebih nikmat.

Resep ayam asam manis bumbu rempah pun mudah dihidangkan, lho. Kalian jangan repot-repot untuk membeli ayam asam manis bumbu rempah, lantaran Kalian mampu menyiapkan sendiri di rumah. Untuk Kita yang hendak menyajikannya, inilah resep untuk membuat ayam asam manis bumbu rempah yang lezat yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Asam Manis Bumbu Rempah:

1. Gunakan 1 ekor ayam
1. Siapkan 1 bungkus kecap (me bango 3k)
1. Sediakan 1 bungkus kecil asam
1. Sediakan secukupnya Ketumbar
1. Sediakan 3 butir Kemiri
1. Sediakan 6 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Siapkan 4 cm kunyit
1. Sediakan 2 cm jahe
1. Siapkan 4 cm lengkuas
1. Sediakan 1 buah gula merah
1. Gunakan  Sereh
1. Siapkan  Daun salam
1. Ambil 1 liter Air
1. Gunakan 3 sendok makan gula pasir
1. Ambil 1 sendok teh garam
1. Ambil secukupnya Kaldu bubuk




<!--inarticleads2-->

##### Cara membuat Ayam Asam Manis Bumbu Rempah:

1. Cuci bersih ayam yg sudah dipotong potong
1. Haluskan ketumbar, kemiri, bawang merah, bawang putih, kunyit, asam jawa, gula merah
1. Tumis bumbu hingga harum kemudian geprek dan masukkan jahe, lengkuas, sereh dan daun salam
1. Masukan ayam, aduk aduk agar bumbu meresap lalu tambahkan air, diamkan hingga mendidih
1. Tambahkan kecap, gula pasir, garam, kaldu bubuk. Koreksi rasa lalu masak hingga air menyurut. Koreksi rasa kembali
1. Setelah matang angkat dan sajikan dengan penuh cinta




Ternyata cara buat ayam asam manis bumbu rempah yang lezat simple ini gampang banget ya! Kita semua bisa memasaknya. Cara buat ayam asam manis bumbu rempah Sesuai sekali untuk kamu yang baru belajar memasak ataupun juga untuk kalian yang sudah lihai memasak.

Apakah kamu ingin mencoba membuat resep ayam asam manis bumbu rempah mantab tidak rumit ini? Kalau kalian mau, ayo kalian segera siapkan alat dan bahan-bahannya, setelah itu buat deh Resep ayam asam manis bumbu rempah yang lezat dan sederhana ini. Sangat mudah kan. 

Oleh karena itu, daripada kalian berfikir lama-lama, yuk kita langsung bikin resep ayam asam manis bumbu rempah ini. Dijamin kalian tiidak akan menyesal membuat resep ayam asam manis bumbu rempah enak sederhana ini! Selamat mencoba dengan resep ayam asam manis bumbu rempah nikmat tidak rumit ini di tempat tinggal sendiri,ya!.

