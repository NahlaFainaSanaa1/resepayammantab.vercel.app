---
description: "Cara memasak Tongseng Ayam Tanpa Santan yang lezat Untuk Jualan"
title: "Cara memasak Tongseng Ayam Tanpa Santan yang lezat Untuk Jualan"
slug: 466-cara-memasak-tongseng-ayam-tanpa-santan-yang-lezat-untuk-jualan
date: 2021-05-02T06:37:49.327Z
image: https://img-global.cpcdn.com/recipes/b6d7886a70be2279/680x482cq70/tongseng-ayam-tanpa-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b6d7886a70be2279/680x482cq70/tongseng-ayam-tanpa-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b6d7886a70be2279/680x482cq70/tongseng-ayam-tanpa-santan-foto-resep-utama.jpg
author: Willie George
ratingvalue: 3.1
reviewcount: 15
recipeingredient:
- "500 gram ayam negri potong2"
- "150 gram daun kol buang tulang daunnya potong kasar"
- "1 lembar daun salam"
- "1 sdm air asam"
- "1 batang serai memarkan"
- "5 sdm kecap manis"
- "1 buah tomat merah potong2"
- "2 buah tomat ijo potong2"
- "20 buah cabai rawit sy skip"
- "6 buah bawang merah iris tipis"
- " Minyak utk menumis"
- " Bumbu halus "
- "4 siung bawang putih"
- "1 sdt merica bulat"
- "1 sdt ketumbar sangrai"
- "1/2 sdt jintan sangrai"
- "1 sdt jahe"
- "1 cm kunyit bakar"
- "1 1/2 lengkuas cincang"
recipeinstructions:
- "Tumis bawang merah hingga layu dan harum. Masukkan bumbu halus, daun salam, dan serai. Aduk. Tambahkan ayam potong, aduk sampai berubah warna. Sisihkan."
- "Didihkan 500 ml air, masukkan tumisan ayam, kecap manis, dan air asam."
- "Masak sampai ayam lunak. Jika ayam belum empuk, boleh tambahkan air panas secukupnya."
- "Setelah ayam cukup empuk, masukkan tomat, cabai rawit, kol, garam, dan gula sesuai selera. Angkat. Sajikan selagi hangat dan nikmati dengan nasi putih hangat 😋😋"
categories:
- Resep
tags:
- tongseng
- ayam
- tanpa

katakunci: tongseng ayam tanpa 
nutrition: 156 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dessert

---


![Tongseng Ayam Tanpa Santan](https://img-global.cpcdn.com/recipes/b6d7886a70be2279/680x482cq70/tongseng-ayam-tanpa-santan-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan hidangan enak pada keluarga adalah hal yang menggembirakan untuk anda sendiri. Kewajiban seorang ibu bukan sekadar menjaga rumah saja, tetapi kamu pun harus menyediakan kebutuhan nutrisi terpenuhi dan masakan yang dikonsumsi anak-anak wajib nikmat.

Di masa  saat ini, kita sebenarnya bisa membeli olahan siap saji meski tidak harus capek mengolahnya dulu. Tapi ada juga mereka yang selalu mau memberikan hidangan yang terenak untuk orang yang dicintainya. Lantaran, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan kesukaan orang tercinta. 



Mungkinkah anda merupakan salah satu penyuka tongseng ayam tanpa santan?. Tahukah kamu, tongseng ayam tanpa santan adalah sajian khas di Indonesia yang sekarang digemari oleh kebanyakan orang dari hampir setiap daerah di Indonesia. Anda dapat menyajikan tongseng ayam tanpa santan sendiri di rumahmu dan boleh jadi makanan kesenanganmu di akhir pekanmu.

Kalian tak perlu bingung jika kamu ingin mendapatkan tongseng ayam tanpa santan, sebab tongseng ayam tanpa santan mudah untuk didapatkan dan juga kamu pun bisa membuatnya sendiri di tempatmu. tongseng ayam tanpa santan bisa dibuat memalui beraneka cara. Kini pun sudah banyak cara kekinian yang membuat tongseng ayam tanpa santan lebih enak.

Resep tongseng ayam tanpa santan pun sangat mudah dihidangkan, lho. Anda tidak perlu capek-capek untuk memesan tongseng ayam tanpa santan, sebab Kamu mampu menghidangkan di rumah sendiri. Untuk Kita yang akan membuatnya, berikut ini cara menyajikan tongseng ayam tanpa santan yang lezat yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Tongseng Ayam Tanpa Santan:

1. Gunakan 500 gram ayam negri, potong2
1. Siapkan 150 gram daun kol, buang tulang daunnya, potong kasar
1. Siapkan 1 lembar daun salam
1. Ambil 1 sdm air asam
1. Sediakan 1 batang serai, memarkan
1. Ambil 5 sdm kecap manis
1. Siapkan 1 buah tomat merah, potong2
1. Gunakan 2 buah tomat ijo, potong2
1. Ambil 20 buah cabai rawit (sy skip)
1. Siapkan 6 buah bawang merah, iris tipis
1. Gunakan  Minyak utk menumis
1. Gunakan  Bumbu halus :
1. Sediakan 4 siung bawang putih
1. Siapkan 1 sdt merica bulat
1. Sediakan 1 sdt ketumbar, sangrai
1. Gunakan 1/2 sdt jintan, sangrai
1. Sediakan 1 sdt jahe
1. Sediakan 1 cm kunyit, bakar
1. Ambil 1 1/2 lengkuas, cincang




<!--inarticleads2-->

##### Cara membuat Tongseng Ayam Tanpa Santan:

1. Tumis bawang merah hingga layu dan harum. Masukkan bumbu halus, daun salam, dan serai. Aduk. Tambahkan ayam potong, aduk sampai berubah warna. Sisihkan.
1. Didihkan 500 ml air, masukkan tumisan ayam, kecap manis, dan air asam.
1. Masak sampai ayam lunak. Jika ayam belum empuk, boleh tambahkan air panas secukupnya.
1. Setelah ayam cukup empuk, masukkan tomat, cabai rawit, kol, garam, dan gula sesuai selera. Angkat. Sajikan selagi hangat dan nikmati dengan nasi putih hangat 😋😋




Wah ternyata cara buat tongseng ayam tanpa santan yang lezat sederhana ini mudah sekali ya! Kalian semua bisa membuatnya. Cara buat tongseng ayam tanpa santan Sangat sesuai banget untuk kalian yang baru belajar memasak maupun juga bagi kamu yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba membikin resep tongseng ayam tanpa santan enak simple ini? Kalau ingin, ayo kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, lantas buat deh Resep tongseng ayam tanpa santan yang lezat dan tidak ribet ini. Benar-benar taidak sulit kan. 

Maka, daripada kalian diam saja, ayo langsung aja sajikan resep tongseng ayam tanpa santan ini. Pasti anda gak akan nyesel sudah buat resep tongseng ayam tanpa santan nikmat tidak rumit ini! Selamat mencoba dengan resep tongseng ayam tanpa santan mantab simple ini di tempat tinggal kalian sendiri,ya!.

