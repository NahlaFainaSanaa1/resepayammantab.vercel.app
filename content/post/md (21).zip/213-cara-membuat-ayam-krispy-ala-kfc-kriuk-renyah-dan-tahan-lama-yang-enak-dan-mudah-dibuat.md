---
description: "Cara membuat Ayam krispy ala kfc kriuk renyah dan tahan lama yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam krispy ala kfc kriuk renyah dan tahan lama yang enak dan Mudah Dibuat"
slug: 213-cara-membuat-ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-yang-enak-dan-mudah-dibuat
date: 2021-04-27T01:22:30.795Z
image: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
author: Nathaniel Gill
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- "1 ekor ayam uk  1kg"
- " Bumbu perendam "
- " Haluskan"
- "5-10 siung bawang putih"
- "2 buah cabe merah"
- "1 bungkus kaldu bubuk rasa ayam"
- "1 sendok teh merica bubuk"
- "1 sendok makan garam"
- "1 sendok makan ketumbar bubuk"
- "1 sendok teh cabai bubuk boleh skip"
- "1/2 sensok makan saus tiram"
- "1 butir telur kocok lepas dimasukan dibagian akhir setelah direndam"
- " Tepung kriuk"
- "400 gr terigu cakra  protein tinggi"
- "100 gr tepung maizena"
- "1 bungkus kaldu bubuk rasa ayam"
- "1 sendok makan bubuk cabai boleh dikurangidi skip"
- "1/2 sdt merica bubuk"
- "Secukupnya garam"
- " Bahan pelapis "
- "100 ml air"
- "3-4 cube es batu"
- "1 sendok teh soda kue"
- "5 sendok makan campuran tepung kriuk"
- " Minyak yang banyak untuk menggoreng dengan deep fried"
recipeinstructions:
- "Campur bumbu yang dihaluskan dengan bumbu perendam lainnya."
- "Siapkan ayam, tusuk-tusuk dengan garpu.. tambahkan campuran bumbu perendam. Remas-remas.. diamkan minimal 1 jam.. (rendam 1 malam didalam kulkas jika mau bumbunya lebih meresap)"
- "Siapkan campuran tepung kriuk.."
- "Siapkan campuran bumbu perendam"
- "Panaskan minyak, yang banyak ya. Supaya nnti ayamnya bisa terendam saat di goreng."
- "Siapkan ayam yang telah direndam. Masukan telur yang dikocok lepas. Aduk merata."
- "Masukan ayam ke dalam tepung kriuk. Remas remas sampai tepung menempel. Ketuk2 ayam kepinggiran baskom agar tepung yang tidak menempel akan jatuh."
- "Masukkan kedalam bumbu pelapis"
- "Masukkan lagi kedalam tepung kriuk. Remas-remas sambil di boleh balik sampai tepungnya menempel.."
- "Ketuk2 lagi dipinggir baskom sampai terbentuk kriwil-kriwilnya.."
- "Segera goreng dalam minyak panas yang banyak dengan api sedang. Ayam harus terendam semua didalam minyak ya. (emak pakai panci magic com kecil yang sudah tidak terpakai 😬😬)"
- "Goreng sampai kulit terlihat kuning kecoklatan. Pencet ayam dengan capit untuk memastikan sudah tidak lembek dan matang)"
- "Angkat dan tiriskan."
categories:
- Resep
tags:
- ayam
- krispy
- ala

katakunci: ayam krispy ala 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam krispy ala kfc kriuk renyah dan tahan lama](https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg)

Jika kalian seorang orang tua, menyediakan hidangan sedap buat keluarga tercinta adalah suatu hal yang sangat menyenangkan untuk anda sendiri. Peran seorang ibu bukan hanya menangani rumah saja, tapi kamu juga wajib memastikan kebutuhan gizi terpenuhi dan santapan yang dikonsumsi keluarga tercinta harus enak.

Di masa  sekarang, kamu sebenarnya bisa mengorder olahan instan walaupun tanpa harus capek mengolahnya terlebih dahulu. Namun ada juga orang yang memang mau memberikan yang terlezat untuk orang tercintanya. Pasalnya, memasak sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera keluarga. 



Mungkinkah anda adalah salah satu penyuka ayam krispy ala kfc kriuk renyah dan tahan lama?. Tahukah kamu, ayam krispy ala kfc kriuk renyah dan tahan lama adalah makanan khas di Nusantara yang kini disukai oleh orang-orang dari hampir setiap wilayah di Indonesia. Kalian dapat menghidangkan ayam krispy ala kfc kriuk renyah dan tahan lama olahan sendiri di rumah dan boleh dijadikan camilan favorit di hari libur.

Anda tak perlu bingung jika kamu ingin mendapatkan ayam krispy ala kfc kriuk renyah dan tahan lama, sebab ayam krispy ala kfc kriuk renyah dan tahan lama mudah untuk ditemukan dan kamu pun bisa memasaknya sendiri di rumah. ayam krispy ala kfc kriuk renyah dan tahan lama boleh diolah lewat berbagai cara. Sekarang sudah banyak banget cara kekinian yang menjadikan ayam krispy ala kfc kriuk renyah dan tahan lama lebih mantap.

Resep ayam krispy ala kfc kriuk renyah dan tahan lama pun gampang sekali untuk dibuat, lho. Anda tidak usah capek-capek untuk memesan ayam krispy ala kfc kriuk renyah dan tahan lama, karena Kita mampu membuatnya di rumah sendiri. Bagi Kamu yang akan mencobanya, inilah cara menyajikan ayam krispy ala kfc kriuk renyah dan tahan lama yang enak yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam krispy ala kfc kriuk renyah dan tahan lama:

1. Siapkan 1 ekor ayam uk +/- 1kg
1. Sediakan  Bumbu perendam :
1. Sediakan  Haluskan:
1. Sediakan 5-10 siung bawang putih
1. Gunakan 2 buah cabe merah
1. Siapkan 1 bungkus kaldu bubuk rasa ayam
1. Sediakan 1 sendok teh merica bubuk
1. Siapkan 1 sendok makan garam
1. Gunakan 1 sendok makan ketumbar bubuk
1. Ambil 1 sendok teh cabai bubuk (boleh skip)
1. Sediakan 1/2 sensok makan saus tiram
1. Siapkan 1 butir telur, kocok lepas (dimasukan dibagian akhir setelah direndam)
1. Gunakan  Tepung kriuk:
1. Siapkan 400 gr terigu cakra / protein tinggi
1. Ambil 100 gr tepung maizena
1. Ambil 1 bungkus kaldu bubuk rasa ayam
1. Siapkan 1 sendok makan bubuk cabai (boleh dikurangi/di skip)
1. Ambil 1/2 sdt merica bubuk
1. Gunakan Secukupnya garam
1. Gunakan  Bahan pelapis :
1. Siapkan 100 ml air
1. Gunakan 3-4 cube es batu
1. Sediakan 1 sendok teh soda kue
1. Sediakan 5 sendok makan campuran tepung kriuk
1. Ambil  Minyak yang banyak untuk menggoreng dengan deep fried




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam krispy ala kfc kriuk renyah dan tahan lama:

1. Campur bumbu yang dihaluskan dengan bumbu perendam lainnya.
1. Siapkan ayam, tusuk-tusuk dengan garpu.. tambahkan campuran bumbu perendam. Remas-remas.. diamkan minimal 1 jam.. (rendam 1 malam didalam kulkas jika mau bumbunya lebih meresap)
1. Siapkan campuran tepung kriuk..
1. Siapkan campuran bumbu perendam
1. Panaskan minyak, yang banyak ya. Supaya nnti ayamnya bisa terendam saat di goreng.
1. Siapkan ayam yang telah direndam. Masukan telur yang dikocok lepas. Aduk merata.
1. Masukan ayam ke dalam tepung kriuk. Remas remas sampai tepung menempel. Ketuk2 ayam kepinggiran baskom agar tepung yang tidak menempel akan jatuh.
1. Masukkan kedalam bumbu pelapis
1. Masukkan lagi kedalam tepung kriuk. Remas-remas sambil di boleh balik sampai tepungnya menempel..
1. Ketuk2 lagi dipinggir baskom sampai terbentuk kriwil-kriwilnya..
1. Segera goreng dalam minyak panas yang banyak dengan api sedang. Ayam harus terendam semua didalam minyak ya. (emak pakai panci magic com kecil yang sudah tidak terpakai 😬😬)
1. Goreng sampai kulit terlihat kuning kecoklatan. Pencet ayam dengan capit untuk memastikan sudah tidak lembek dan matang)
1. Angkat dan tiriskan.




Ternyata resep ayam krispy ala kfc kriuk renyah dan tahan lama yang mantab simple ini enteng sekali ya! Kalian semua dapat mencobanya. Resep ayam krispy ala kfc kriuk renyah dan tahan lama Sesuai banget buat kamu yang baru mau belajar memasak maupun bagi kamu yang telah pandai dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep ayam krispy ala kfc kriuk renyah dan tahan lama mantab simple ini? Kalau kalian mau, ayo kalian segera siapin peralatan dan bahannya, maka buat deh Resep ayam krispy ala kfc kriuk renyah dan tahan lama yang nikmat dan sederhana ini. Betul-betul mudah kan. 

Maka, ketimbang kita berlama-lama, hayo kita langsung saja hidangkan resep ayam krispy ala kfc kriuk renyah dan tahan lama ini. Pasti kamu tiidak akan menyesal sudah bikin resep ayam krispy ala kfc kriuk renyah dan tahan lama lezat sederhana ini! Selamat mencoba dengan resep ayam krispy ala kfc kriuk renyah dan tahan lama mantab simple ini di tempat tinggal kalian masing-masing,oke!.

