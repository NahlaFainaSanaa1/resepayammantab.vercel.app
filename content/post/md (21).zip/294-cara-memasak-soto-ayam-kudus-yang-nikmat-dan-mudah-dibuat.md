---
description: "Cara memasak Soto ayam Kudus yang nikmat dan Mudah Dibuat"
title: "Cara memasak Soto ayam Kudus yang nikmat dan Mudah Dibuat"
slug: 294-cara-memasak-soto-ayam-kudus-yang-nikmat-dan-mudah-dibuat
date: 2021-01-31T03:52:20.292Z
image: https://img-global.cpcdn.com/recipes/63ad7465fb4bb986/680x482cq70/soto-ayam-kudus-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/63ad7465fb4bb986/680x482cq70/soto-ayam-kudus-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/63ad7465fb4bb986/680x482cq70/soto-ayam-kudus-foto-resep-utama.jpg
author: Lydia West
ratingvalue: 3
reviewcount: 9
recipeingredient:
- "1 ekor ayam"
- "1 lt air untuk merebus bisa disesuaikan"
- "1 btg daun bawang iris 1 cm"
- "1 sdm minyak untuk menumis bumbu"
- " Bumbu"
- "5 siung bawang putih "
- "5-10 siung bawang merah "
- "1/4-1/2 siung bawang bombay  pengganti 5 bawang merah opsional"
- "4 btr kemiri "
- " Note  saya pakai 2 sdm bumbu putih"
- "1 sdt ketumbar bubuk"
- "1/2 sdt merica bubuk"
- "1 cm jahe or 12 sdt jahe bubuk"
- "1 cm kunyit or 12 sdt kunyit bubuk bisa ditambah untuk kuah yg lebih kuning"
- "1 sdt garam"
- "1/2 sdt gula"
- "1 cm lengkuas geprek"
- "1 btg sereh geprek"
- "2 lbr daun salam"
- "4 lbr daun jeruk buang tangkainya bisa dikurangi dan ditambahkan sari green lime"
- " Pelengkap"
- " Telur rebus kupas belah tengah"
- " Rice noodles siram air mendidih"
- " Kubis iris tipis siram air mendidih"
- " Taoge bersihkan siram air mendidih di gambar saya ga pake"
- " Bawang goreng"
- " Seledri cuci iris tipis"
- " Kentang iris tipis goreng kering"
recipeinstructions:
- "Rebus ayam, saring lemak pertama."
- "Haluskan semua bumbu kecuali daun2an. Tumis sampai harum. Tambahkan daun salam, daun jeruk dan sereh."
- "Masukkan bumbu yg sudah matang ke dalam kaldu ayam. Tambahkan garam dan gula sesuai selera. Cicipi."
- "Saat ayam telah matang, tiriskan ayam. Tambahkan daun bawang. Rebus sebentar lg sampai harum."
- "Suwir-suwir ayam. Boleh juga digoreng dulu. Sisa tulang biasanya saya kembalikan ke kuah kaldu."
- "Hidangkan dengan pelengkapnya dan selamat menikmati 😋. Semangat sehat 💪💕."
categories:
- Resep
tags:
- soto
- ayam
- kudus

katakunci: soto ayam kudus 
nutrition: 267 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Soto ayam Kudus](https://img-global.cpcdn.com/recipes/63ad7465fb4bb986/680x482cq70/soto-ayam-kudus-foto-resep-utama.jpg)

Apabila kamu seorang istri, menyediakan olahan sedap buat orang tercinta merupakan hal yang menyenangkan untuk kamu sendiri. Tugas seorang istri Tidak saja menjaga rumah saja, namun anda pun harus memastikan kebutuhan nutrisi terpenuhi dan juga panganan yang dimakan keluarga tercinta harus lezat.

Di era  sekarang, kalian sebenarnya mampu membeli masakan instan walaupun tidak harus capek membuatnya dahulu. Tetapi ada juga orang yang selalu ingin menyajikan yang terlezat untuk orang yang dicintainya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai dengan selera keluarga tercinta. 



Mungkinkah kamu salah satu penggemar soto ayam kudus?. Tahukah kamu, soto ayam kudus adalah makanan khas di Indonesia yang saat ini disukai oleh banyak orang dari berbagai wilayah di Indonesia. Kamu bisa membuat soto ayam kudus sendiri di rumah dan pasti jadi hidangan favoritmu di akhir pekanmu.

Kamu jangan bingung untuk menyantap soto ayam kudus, karena soto ayam kudus tidak sulit untuk didapatkan dan juga anda pun dapat menghidangkannya sendiri di tempatmu. soto ayam kudus boleh diolah memalui beraneka cara. Sekarang sudah banyak banget cara kekinian yang membuat soto ayam kudus semakin lebih mantap.

Resep soto ayam kudus pun mudah dibikin, lho. Kalian tidak usah ribet-ribet untuk memesan soto ayam kudus, lantaran Kalian dapat menghidangkan ditempatmu. Bagi Kamu yang mau mencobanya, inilah cara membuat soto ayam kudus yang enak yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto ayam Kudus:

1. Siapkan 1 ekor ayam
1. Ambil 1 lt air untuk merebus, bisa disesuaikan
1. Sediakan 1 btg daun bawang, iris 1 cm
1. Gunakan 1 sdm minyak untuk menumis bumbu
1. Siapkan  Bumbu
1. Ambil 5 siung bawang putih *
1. Ambil 5-10 siung bawang merah *
1. Ambil 1/4-1/2 siung bawang bombay *, pengganti 5 bawang merah (opsional)
1. Siapkan 4 btr kemiri *
1. Gunakan  Note: * saya pakai 2 sdm bumbu putih
1. Ambil 1 sdt ketumbar bubuk
1. Siapkan 1/2 sdt merica bubuk
1. Sediakan 1 cm jahe, or 1/2 sdt jahe bubuk
1. Sediakan 1 cm kunyit, or 1/2 sdt kunyit bubuk bisa ditambah untuk kuah yg lebih kuning
1. Siapkan 1 sdt garam
1. Siapkan 1/2 sdt gula
1. Siapkan 1 cm lengkuas, geprek
1. Gunakan 1 btg sereh, geprek
1. Gunakan 2 lbr daun salam
1. Gunakan 4 lbr daun jeruk, buang tangkainya, bisa dikurangi dan ditambahkan sari green lime
1. Gunakan  Pelengkap
1. Gunakan  Telur rebus, kupas, belah tengah
1. Ambil  Rice noodles, siram air mendidih
1. Ambil  Kubis, iris tipis, siram air mendidih
1. Siapkan  Taoge, bersihkan, siram air mendidih (di gambar saya ga pake)
1. Sediakan  Bawang goreng
1. Siapkan  Seledri, cuci, iris tipis
1. Sediakan  Kentang, iris tipis, goreng kering




<!--inarticleads2-->

##### Cara membuat Soto ayam Kudus:

1. Rebus ayam, saring lemak pertama.
1. Haluskan semua bumbu kecuali daun2an. Tumis sampai harum. Tambahkan daun salam, daun jeruk dan sereh.
1. Masukkan bumbu yg sudah matang ke dalam kaldu ayam. Tambahkan garam dan gula sesuai selera. Cicipi.
1. Saat ayam telah matang, tiriskan ayam. Tambahkan daun bawang. Rebus sebentar lg sampai harum.
1. Suwir-suwir ayam. Boleh juga digoreng dulu. Sisa tulang biasanya saya kembalikan ke kuah kaldu.
1. Hidangkan dengan pelengkapnya dan selamat menikmati 😋. Semangat sehat 💪💕.




Ternyata resep soto ayam kudus yang enak tidak ribet ini enteng banget ya! Kamu semua bisa membuatnya. Resep soto ayam kudus Sangat sesuai banget untuk kita yang sedang belajar memasak ataupun bagi kalian yang sudah pandai memasak.

Tertarik untuk mulai mencoba membikin resep soto ayam kudus mantab tidak ribet ini? Kalau kalian ingin, yuk kita segera buruan siapkan alat-alat dan bahannya, kemudian buat deh Resep soto ayam kudus yang mantab dan sederhana ini. Sungguh taidak sulit kan. 

Maka, daripada kamu diam saja, hayo kita langsung buat resep soto ayam kudus ini. Dijamin kalian tak akan menyesal sudah membuat resep soto ayam kudus enak simple ini! Selamat mencoba dengan resep soto ayam kudus nikmat simple ini di tempat tinggal masing-masing,ya!.

