---
description: "Resep memasak Coto ayam yang nikmat dan Mudah Dibuat"
title: "Resep memasak Coto ayam yang nikmat dan Mudah Dibuat"
slug: 64-resep-memasak-coto-ayam-yang-nikmat-dan-mudah-dibuat
date: 2021-06-11T10:13:20.742Z
image: https://img-global.cpcdn.com/recipes/604859a452334a5b/680x482cq70/coto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/604859a452334a5b/680x482cq70/coto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/604859a452334a5b/680x482cq70/coto-ayam-foto-resep-utama.jpg
author: Josie Stokes
ratingvalue: 4.8
reviewcount: 7
recipeingredient:
- "1/2 kg daging ayam"
- "1 genggam kacang goreng haluskan"
- "secukupnya Penyedap rasa Masako"
- "3 lbr daun jeruk"
- " Minyak untuk menumis"
- " Bumbu halus "
- "4 batang sereh"
- "5 buah bawang merah"
- "5 siung bawang putih"
- "2 cm jahe"
- "1 sdt ketumbar sangrai"
- "1 sdt jintan sangrai"
- "4 buah kemiri sangrai"
recipeinstructions:
- "Potong daging ayam kecil-kecil (seperti ingin masak ayam rica-rica) lalu cuci bersih"
- "Rebus ayam terlebih dahulu dengan 5 gelas air, masukkan 3 lbr daun jeruk"
- "Panaskan minyak lalu tumis bumbu halus"
- "Setelah daging ayam yang di rebus empuk, masukkan bumbu yang sudah di tumis, tambahkan Masako secukupnya"
- "Masukkan kacang yang sudah di haluskan dan daun bawang"
- "Masak kurang lebih 5 menit atau hingga matang, angkat lalu sajikan (beri perasan jeruk nipis, sambel dan kecap). Lebih nikmat di sajikan dengan ketupat atau buras"
categories:
- Resep
tags:
- coto
- ayam

katakunci: coto ayam 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dinner

---


![Coto ayam](https://img-global.cpcdn.com/recipes/604859a452334a5b/680x482cq70/coto-ayam-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan olahan enak buat keluarga adalah hal yang menggembirakan bagi anda sendiri. Kewajiban seorang istri bukan sekedar mengerjakan pekerjaan rumah saja, namun kamu pun wajib memastikan kebutuhan gizi terpenuhi dan juga hidangan yang disantap orang tercinta mesti sedap.

Di zaman  saat ini, anda memang mampu membeli olahan praktis tidak harus ribet membuatnya terlebih dahulu. Tetapi ada juga lho mereka yang memang mau memberikan yang terenak untuk keluarganya. Pasalnya, menyajikan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai kesukaan famili. 



Mungkinkah anda adalah salah satu penggemar coto ayam?. Tahukah kamu, coto ayam adalah makanan khas di Nusantara yang saat ini disukai oleh kebanyakan orang dari berbagai daerah di Indonesia. Kamu bisa membuat coto ayam sendiri di rumahmu dan boleh dijadikan hidangan kegemaranmu di akhir pekan.

Anda tidak usah bingung jika kamu ingin menyantap coto ayam, sebab coto ayam tidak sulit untuk dicari dan juga anda pun bisa memasaknya sendiri di tempatmu. coto ayam dapat diolah lewat berbagai cara. Kini sudah banyak sekali resep kekinian yang menjadikan coto ayam semakin lebih nikmat.

Resep coto ayam pun gampang dihidangkan, lho. Kalian jangan capek-capek untuk membeli coto ayam, tetapi Kamu bisa menghidangkan sendiri di rumah. Bagi Anda yang hendak membuatnya, inilah cara membuat coto ayam yang nikamat yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Coto ayam:

1. Gunakan 1/2 kg daging ayam
1. Siapkan 1 genggam kacang goreng (haluskan)
1. Sediakan secukupnya Penyedap rasa (Masako)
1. Gunakan 3 lbr daun jeruk
1. Siapkan  Minyak untuk menumis
1. Gunakan  Bumbu halus :
1. Gunakan 4 batang sereh
1. Ambil 5 buah bawang merah
1. Siapkan 5 siung bawang putih
1. Ambil 2 cm jahe
1. Gunakan 1 sdt ketumbar (sangrai)
1. Siapkan 1 sdt jintan (sangrai)
1. Siapkan 4 buah kemiri (sangrai)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Coto ayam:

1. Potong daging ayam kecil-kecil (seperti ingin masak ayam rica-rica) lalu cuci bersih
1. Rebus ayam terlebih dahulu dengan 5 gelas air, masukkan 3 lbr daun jeruk
1. Panaskan minyak lalu tumis bumbu halus
1. Setelah daging ayam yang di rebus empuk, masukkan bumbu yang sudah di tumis, tambahkan Masako secukupnya
1. Masukkan kacang yang sudah di haluskan dan daun bawang
1. Masak kurang lebih 5 menit atau hingga matang, angkat lalu sajikan (beri perasan jeruk nipis, sambel dan kecap). Lebih nikmat di sajikan dengan ketupat atau buras




Ternyata cara buat coto ayam yang lezat tidak ribet ini enteng sekali ya! Semua orang dapat memasaknya. Resep coto ayam Sesuai banget untuk kita yang baru mau belajar memasak maupun juga bagi kalian yang telah hebat dalam memasak.

Tertarik untuk mencoba bikin resep coto ayam lezat simple ini? Kalau kalian ingin, ayo kalian segera buruan menyiapkan alat-alat dan bahannya, maka buat deh Resep coto ayam yang nikmat dan sederhana ini. Sangat taidak sulit kan. 

Maka, daripada kalian diam saja, ayo kita langsung saja hidangkan resep coto ayam ini. Dijamin kamu tak akan menyesal sudah membuat resep coto ayam lezat simple ini! Selamat mencoba dengan resep coto ayam nikmat tidak rumit ini di tempat tinggal kalian sendiri,oke!.

