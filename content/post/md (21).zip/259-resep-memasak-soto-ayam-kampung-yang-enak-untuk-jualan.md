---
description: "Resep memasak Soto Ayam Kampung yang enak Untuk Jualan"
title: "Resep memasak Soto Ayam Kampung yang enak Untuk Jualan"
slug: 259-resep-memasak-soto-ayam-kampung-yang-enak-untuk-jualan
date: 2021-04-27T21:21:20.693Z
image: https://img-global.cpcdn.com/recipes/8d6feeac44a846be/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8d6feeac44a846be/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8d6feeac44a846be/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
author: Nancy Stevenson
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- "10 potong ayam"
- "5 siung bawang putih"
- "8 siung bawang merah"
- "1 ruas kunir"
- "1/2 ruas laos"
- "1/2 ruas jahe"
- "1 sdt merica"
- "1 sdt ketumbar"
- "3 butir kemiri"
- "1/2 sdt jinten"
- "2 lbr daun jeruk"
- " bawang pre"
- " bawang putih goreng"
- " serai"
- " minyak"
- " garam gula penyedap rasa"
recipeinstructions:
- "Blender semua bumbu (bawang putih, bawang merah, jahe, laos, kunir, ketumbar, jinten, merica, kemiri)"
- "Tumis bumbu yang sudah d blender, lalu masukkan sereh geprek dan 2 lbr daun jeruk dan tunggu sampai layu"
- "Didihkan air dan rebus ayam sampai setengah matang"
- "Setelah ayam mendidih masukkan bumbu yang sudah ditumis kedalam panci"
- "Tambahkan garam, gula penyedap rasa, dan tutup panci tunggu hingga 15 menit"
- "Setelah akan disajikan taburkan bawang putih goreng dan bawang pre"
- "Jangan lupa koreksi rasa sebelum disajikan"
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 222 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Ayam Kampung](https://img-global.cpcdn.com/recipes/8d6feeac44a846be/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyuguhkan masakan lezat buat keluarga tercinta merupakan hal yang memuaskan bagi kita sendiri. Tanggung jawab seorang  wanita bukan cuman mengatur rumah saja, namun kamu juga harus menyediakan kebutuhan nutrisi tercukupi dan santapan yang disantap anak-anak harus nikmat.

Di masa  saat ini, kita memang dapat membeli santapan instan meski tidak harus capek memasaknya lebih dulu. Tetapi ada juga lho mereka yang selalu ingin menyajikan yang terbaik untuk orang yang dicintainya. Karena, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan selera keluarga tercinta. 



Mungkinkah anda adalah salah satu penikmat soto ayam kampung?. Asal kamu tahu, soto ayam kampung adalah makanan khas di Nusantara yang sekarang disukai oleh banyak orang di berbagai daerah di Nusantara. Kita bisa menghidangkan soto ayam kampung sendiri di rumah dan boleh dijadikan camilan favorit di hari libur.

Kamu tidak usah bingung jika kamu ingin memakan soto ayam kampung, lantaran soto ayam kampung gampang untuk didapatkan dan juga kamu pun boleh membuatnya sendiri di rumah. soto ayam kampung bisa dibuat memalui berbagai cara. Saat ini sudah banyak resep modern yang menjadikan soto ayam kampung semakin nikmat.

Resep soto ayam kampung pun sangat gampang untuk dibuat, lho. Anda tidak usah ribet-ribet untuk memesan soto ayam kampung, tetapi Kalian bisa menghidangkan di rumah sendiri. Bagi Kalian yang ingin menghidangkannya, di bawah ini adalah cara menyajikan soto ayam kampung yang enak yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Kampung:

1. Ambil 10 potong ayam
1. Siapkan 5 siung bawang putih
1. Ambil 8 siung bawang merah
1. Ambil 1 ruas kunir
1. Ambil 1/2 ruas laos
1. Siapkan 1/2 ruas jahe
1. Siapkan 1 sdt merica
1. Sediakan 1 sdt ketumbar
1. Sediakan 3 butir kemiri
1. Ambil 1/2 sdt jinten
1. Ambil 2 lbr daun jeruk
1. Sediakan  bawang pre
1. Gunakan  bawang putih goreng
1. Siapkan  serai
1. Ambil  minyak
1. Siapkan  garam, gula penyedap rasa




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Kampung:

1. Blender semua bumbu (bawang putih, bawang merah, jahe, laos, kunir, ketumbar, jinten, merica, kemiri)
1. Tumis bumbu yang sudah d blender, lalu masukkan sereh geprek dan 2 lbr daun jeruk dan tunggu sampai layu
1. Didihkan air dan rebus ayam sampai setengah matang
1. Setelah ayam mendidih masukkan bumbu yang sudah ditumis kedalam panci
1. Tambahkan garam, gula penyedap rasa, dan tutup panci tunggu hingga 15 menit
1. Setelah akan disajikan taburkan bawang putih goreng dan bawang pre
1. Jangan lupa koreksi rasa sebelum disajikan




Wah ternyata cara membuat soto ayam kampung yang lezat tidak rumit ini mudah sekali ya! Anda Semua bisa mencobanya. Cara buat soto ayam kampung Sangat cocok banget untuk kita yang sedang belajar memasak atau juga bagi kamu yang telah pandai memasak.

Apakah kamu tertarik mencoba membuat resep soto ayam kampung lezat simple ini? Kalau kalian mau, ayo kamu segera siapkan alat-alat dan bahan-bahannya, maka bikin deh Resep soto ayam kampung yang mantab dan tidak rumit ini. Sungguh mudah kan. 

Maka, daripada anda berlama-lama, ayo kita langsung saja sajikan resep soto ayam kampung ini. Pasti kamu gak akan menyesal sudah buat resep soto ayam kampung mantab simple ini! Selamat berkreasi dengan resep soto ayam kampung lezat simple ini di tempat tinggal kalian sendiri,ya!.

