---
description: "Bahan-bahan Coto Ayam yang enak dan Mudah Dibuat"
title: "Bahan-bahan Coto Ayam yang enak dan Mudah Dibuat"
slug: 50-bahan-bahan-coto-ayam-yang-enak-dan-mudah-dibuat
date: 2021-04-10T01:33:40.722Z
image: https://img-global.cpcdn.com/recipes/a098016465b6be4d/680x482cq70/coto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a098016465b6be4d/680x482cq70/coto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a098016465b6be4d/680x482cq70/coto-ayam-foto-resep-utama.jpg
author: Owen Garner
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "500 gr daging ayam bagian dada dan paha"
- "1,5 L air cucian beras ke 2 dan 3"
- "5 cm kayu manis"
- "4 helai daun salam"
- "4 helai daun jeruk"
- "Secukupnya minyak untuk menumis bumbu"
- "Secukupnya garam dan gula"
- " Bumbu halus "
- "250 gr kacang sangrai"
- "5 siung bawang putih"
- "10 butir bawang merah"
- "3 butir kemiri disangrai"
- "Seruas jahe"
- "Seruas lengkuas"
- "5 batang sereh uk kecil ambil putihnya sajadiiris tipis"
- "1 sdt lada"
- "2 sdt ketumbar bubuk"
- "1 sdt jinten bubuk"
- "1 sdt pala bubuk"
- "200 ml air"
- " Bahan pelengkap "
- " Jeruk nipis"
- " Bawang goreng"
- " Daun bawang iris tipis"
recipeinstructions:
- "Siapkan bahan-bahan yang diperlukan."
- "Potong kotak atau sesuai selera daging ayam, lalu beri jeruk nipis, biarkan selama 10 menit, lalu bilas air bersih. Masukkan kedalam air cucian beras yg sudah dipanaskan. Masak sampai empuk."
- "Haluskan kacang, dan iris bahan bumbu agar lebih mudah menghaluskan, tambahkan air lalu blender semuanya hingga halus."
- "Panaskan minyak, lalu tumis bumbu halus beserta daun salam, daun jeruk, dan kayu manis. Masak hingga matang. Lalu masukkan kedalam rebusan ayam, beri gula dan garam secukupnya."
- "Masak hingga kuah menyusut dan mengental, cek rasa. Matikan api, sajikan dengan bahan pelengkap."
categories:
- Resep
tags:
- coto
- ayam

katakunci: coto ayam 
nutrition: 143 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dinner

---


![Coto Ayam](https://img-global.cpcdn.com/recipes/a098016465b6be4d/680x482cq70/coto-ayam-foto-resep-utama.jpg)

Jika kamu seorang orang tua, menyediakan santapan sedap buat orang tercinta merupakan hal yang mengasyikan untuk anda sendiri. Tanggung jawab seorang  wanita Tidak sekedar mengatur rumah saja, namun kamu pun wajib memastikan keperluan gizi tercukupi dan juga santapan yang disantap orang tercinta wajib nikmat.

Di era  saat ini, anda sebenarnya dapat mengorder santapan yang sudah jadi tanpa harus susah memasaknya lebih dulu. Namun ada juga lho mereka yang selalu mau menyajikan yang terenak untuk orang yang dicintainya. Sebab, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penggemar coto ayam?. Asal kamu tahu, coto ayam merupakan hidangan khas di Indonesia yang sekarang disenangi oleh orang-orang dari berbagai tempat di Nusantara. Anda bisa memasak coto ayam kreasi sendiri di rumahmu dan boleh dijadikan makanan kesukaanmu di akhir pekanmu.

Anda jangan bingung untuk mendapatkan coto ayam, lantaran coto ayam mudah untuk ditemukan dan juga anda pun boleh mengolahnya sendiri di rumah. coto ayam bisa dibuat lewat beraneka cara. Sekarang sudah banyak cara modern yang membuat coto ayam lebih lezat.

Resep coto ayam juga sangat mudah untuk dibuat, lho. Kita tidak usah ribet-ribet untuk membeli coto ayam, sebab Kalian mampu menghidangkan di rumah sendiri. Bagi Kamu yang ingin mencobanya, dibawah ini merupakan resep membuat coto ayam yang enak yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Coto Ayam:

1. Sediakan 500 gr daging ayam bagian dada dan paha
1. Siapkan 1,5 L air cucian beras ke 2 dan 3
1. Sediakan 5 cm kayu manis
1. Sediakan 4 helai daun salam
1. Gunakan 4 helai daun jeruk
1. Ambil Secukupnya minyak untuk menumis bumbu
1. Sediakan Secukupnya garam dan gula
1. Sediakan  Bumbu halus :
1. Sediakan 250 gr kacang sangrai
1. Siapkan 5 siung bawang putih
1. Siapkan 10 butir bawang merah
1. Gunakan 3 butir kemiri, disangrai
1. Gunakan Seruas jahe
1. Sediakan Seruas lengkuas
1. Gunakan 5 batang sereh uk kecil, ambil putihnya saja,diiris tipis
1. Siapkan 1 sdt lada
1. Gunakan 2 sdt ketumbar bubuk
1. Sediakan 1 sdt jinten bubuk
1. Siapkan 1 sdt pala bubuk
1. Siapkan 200 ml air
1. Gunakan  Bahan pelengkap :
1. Sediakan  Jeruk nipis
1. Siapkan  Bawang goreng
1. Sediakan  Daun bawang, iris tipis




<!--inarticleads2-->

##### Langkah-langkah membuat Coto Ayam:

1. Siapkan bahan-bahan yang diperlukan.
1. Potong kotak atau sesuai selera daging ayam, lalu beri jeruk nipis, biarkan selama 10 menit, lalu bilas air bersih. Masukkan kedalam air cucian beras yg sudah dipanaskan. Masak sampai empuk.
1. Haluskan kacang, dan iris bahan bumbu agar lebih mudah menghaluskan, tambahkan air lalu blender semuanya hingga halus.
1. Panaskan minyak, lalu tumis bumbu halus beserta daun salam, daun jeruk, dan kayu manis. Masak hingga matang. Lalu masukkan kedalam rebusan ayam, beri gula dan garam secukupnya.
1. Masak hingga kuah menyusut dan mengental, cek rasa. Matikan api, sajikan dengan bahan pelengkap.




Ternyata cara buat coto ayam yang mantab sederhana ini mudah banget ya! Semua orang mampu memasaknya. Cara Membuat coto ayam Sesuai banget untuk kalian yang baru belajar memasak ataupun juga bagi kamu yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba membuat resep coto ayam mantab tidak ribet ini? Kalau kalian mau, yuk kita segera buruan siapkan alat-alat dan bahannya, lantas bikin deh Resep coto ayam yang nikmat dan simple ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kita berfikir lama-lama, hayo kita langsung saja buat resep coto ayam ini. Pasti kalian tiidak akan nyesel bikin resep coto ayam lezat sederhana ini! Selamat mencoba dengan resep coto ayam lezat simple ini di tempat tinggal sendiri,ya!.

