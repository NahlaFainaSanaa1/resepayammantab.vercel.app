---
description: "Cara buat COTO MAKASSAR (AYAM) yang nikmat Untuk Jualan"
title: "Cara buat COTO MAKASSAR (AYAM) yang nikmat Untuk Jualan"
slug: 58-cara-buat-coto-makassar-ayam-yang-nikmat-untuk-jualan
date: 2021-05-31T13:44:47.984Z
image: https://img-global.cpcdn.com/recipes/fbc3b5bdb95a8cb5/680x482cq70/coto-makassar-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fbc3b5bdb95a8cb5/680x482cq70/coto-makassar-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fbc3b5bdb95a8cb5/680x482cq70/coto-makassar-ayam-foto-resep-utama.jpg
author: Mittie Adams
ratingvalue: 3.3
reviewcount: 4
recipeingredient:
- "1 ekor ayam dipotong kecil"
- "200 gr kacang tanah goreng haluskan"
- "2 lbr daun salam"
- "2 lbr daun jeruk"
- "1 btg daun bawang iris2"
- "1 ruas lengkuas geprek"
- "1 ltr air aku pake air dari cucian beras yg ke 2 dan ke 3"
- "1 potong kecil kayu manis"
- "secukupnya Minyak goreng"
- "secukupnya Garam"
- "secukupnya Kaldu ayam bubuk"
- " Bumbu halus"
- "10 siung bawang merah"
- "6 siung bawah putih"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "10 btg sereh putihnya aja"
- "1 sdt merica bubuk"
- "1 sdm ketumbar bubuk"
- " Pelengkap"
- "Irisan jeruk nipis"
- "Potongan daun bawang"
- " Bawang goreng"
recipeinstructions:
- "Rebus air hingga mendidih"
- "Sebelum bumbu2 dihaluskan sebaiknya ditumis dulu setelah semua bumbu diiris2, agar warna coto nanti bs lebih gelap dan bumbu lebih harum (tips)"
- "Setelah bumbu kecoklatan maka blender hingga halus dan tumis hingga harum. Jangan lupa masukkan daun salam, daun jeruk, lengkuas geprek dan kayu manis"
- "Kemudian masukkan ayam, aduk hingga bumbu meresap ke dalam daging ayam"
- "Jangan lupa masukkan daun bawang"
- "Aduk terus hingga ayam berubah warna agak pucat. Lalu tuang ke dalam panci berisi air yg telah mendidih tadi. (Kelupa foto)"
- "Masukkan kacang goreng halus, garam dan kaldu ayam bubuk. Masak hingga ayam matang."
- "Setelah mendidih dan ayam masak, angkat dan sajikan dengan pelengkap irisan jeruk nipis, irisan daun bawang, dan bawang goreng"
categories:
- Resep
tags:
- coto
- makassar
- ayam

katakunci: coto makassar ayam 
nutrition: 225 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dessert

---


![COTO MAKASSAR (AYAM)](https://img-global.cpcdn.com/recipes/fbc3b5bdb95a8cb5/680x482cq70/coto-makassar-ayam-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan olahan mantab kepada famili adalah hal yang mengasyikan untuk anda sendiri. Tanggung jawab seorang  wanita bukan hanya menjaga rumah saja, tetapi kamu pun harus memastikan kebutuhan nutrisi tercukupi dan santapan yang dimakan orang tercinta mesti nikmat.

Di zaman  saat ini, kalian memang dapat membeli olahan praktis meski tanpa harus repot membuatnya lebih dulu. Tetapi banyak juga lho mereka yang memang mau memberikan yang terenak untuk orang yang dicintainya. Sebab, menghidangkan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai kesukaan orang tercinta. 



Apakah anda seorang penyuka coto makassar (ayam)?. Tahukah kamu, coto makassar (ayam) merupakan sajian khas di Nusantara yang kini digemari oleh kebanyakan orang di hampir setiap daerah di Indonesia. Kita dapat membuat coto makassar (ayam) sendiri di rumahmu dan dapat dijadikan makanan kesukaanmu di hari libur.

Kamu tidak usah bingung jika kamu ingin memakan coto makassar (ayam), karena coto makassar (ayam) sangat mudah untuk ditemukan dan anda pun boleh memasaknya sendiri di rumah. coto makassar (ayam) bisa dibuat lewat bermacam cara. Sekarang sudah banyak banget resep kekinian yang menjadikan coto makassar (ayam) lebih mantap.

Resep coto makassar (ayam) pun gampang dibuat, lho. Kamu tidak perlu ribet-ribet untuk membeli coto makassar (ayam), tetapi Kamu bisa menghidangkan di rumahmu. Bagi Kita yang akan menyajikannya, berikut ini resep menyajikan coto makassar (ayam) yang lezat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan COTO MAKASSAR (AYAM):

1. Sediakan 1 ekor ayam, dipotong kecil²
1. Ambil 200 gr kacang tanah goreng, haluskan
1. Ambil 2 lbr daun salam
1. Ambil 2 lbr daun jeruk
1. Sediakan 1 btg daun bawang, iris2
1. Sediakan 1 ruas lengkuas, geprek
1. Gunakan 1 ltr air (aku pake air dari cucian beras yg ke 2 dan ke 3)
1. Sediakan 1 potong kecil kayu manis
1. Gunakan secukupnya Minyak goreng,
1. Ambil secukupnya Garam,
1. Ambil secukupnya Kaldu ayam bubuk
1. Sediakan  Bumbu halus
1. Gunakan 10 siung bawang merah
1. Gunakan 6 siung bawah putih
1. Siapkan 1 ruas jahe
1. Siapkan 1 ruas lengkuas
1. Sediakan 10 btg sereh (putihnya aja)
1. Ambil 1 sdt merica bubuk
1. Gunakan 1 sdm ketumbar bubuk
1. Gunakan  Pelengkap
1. Sediakan Irisan jeruk nipis
1. Ambil Potongan daun bawang
1. Gunakan  Bawang goreng




<!--inarticleads2-->

##### Cara membuat COTO MAKASSAR (AYAM):

1. Rebus air hingga mendidih
1. Sebelum bumbu2 dihaluskan sebaiknya ditumis dulu setelah semua bumbu diiris2, agar warna coto nanti bs lebih gelap dan bumbu lebih harum (tips)
1. Setelah bumbu kecoklatan maka blender hingga halus dan tumis hingga harum. Jangan lupa masukkan daun salam, daun jeruk, lengkuas geprek dan kayu manis
1. Kemudian masukkan ayam, aduk hingga bumbu meresap ke dalam daging ayam
1. Jangan lupa masukkan daun bawang
1. Aduk terus hingga ayam berubah warna agak pucat. Lalu tuang ke dalam panci berisi air yg telah mendidih tadi. (Kelupa foto)
1. Masukkan kacang goreng halus, garam dan kaldu ayam bubuk. Masak hingga ayam matang.
1. Setelah mendidih dan ayam masak, angkat dan sajikan dengan pelengkap irisan jeruk nipis, irisan daun bawang, dan bawang goreng




Ternyata cara membuat coto makassar (ayam) yang enak tidak ribet ini mudah banget ya! Semua orang dapat menghidangkannya. Cara Membuat coto makassar (ayam) Sangat sesuai banget untuk anda yang sedang belajar memasak ataupun untuk kamu yang telah hebat dalam memasak.

Apakah kamu ingin mulai mencoba buat resep coto makassar (ayam) nikmat tidak ribet ini? Kalau anda tertarik, ayo kalian segera buruan menyiapkan alat-alat dan bahan-bahannya, kemudian buat deh Resep coto makassar (ayam) yang nikmat dan sederhana ini. Sungguh mudah kan. 

Maka, ketimbang kalian berlama-lama, maka kita langsung bikin resep coto makassar (ayam) ini. Dijamin kamu tiidak akan nyesel membuat resep coto makassar (ayam) nikmat tidak ribet ini! Selamat berkreasi dengan resep coto makassar (ayam) mantab sederhana ini di rumah sendiri,oke!.

