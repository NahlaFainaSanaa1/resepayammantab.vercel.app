---
description: "Cara buat Ayam Bumbu Asam Manis yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Bumbu Asam Manis yang enak dan Mudah Dibuat"
slug: 161-cara-buat-ayam-bumbu-asam-manis-yang-enak-dan-mudah-dibuat
date: 2021-04-21T04:21:48.714Z
image: https://img-global.cpcdn.com/recipes/ed3af4e95c849dcd/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ed3af4e95c849dcd/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ed3af4e95c849dcd/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
author: Marvin Lawrence
ratingvalue: 4.6
reviewcount: 8
recipeingredient:
- "500 gr ayam filet"
- "1 buah wortel"
- "1 buah bawang bombay"
- "3 siung bawang putih"
- "3 buah cabe hijau"
- "1 bungkus tepung sajiku serbaguna"
- "4 sdm tepung tapioka"
- " Merica bubuk secukup nya"
- "secukupnya Garam"
- "secukupnya Gula merah"
- "1 bungkus saus asam manis saori"
- "secukupnya Penyedap rasa"
- " Minyak untuk menggoreng"
recipeinstructions:
- "Ayam filet dicuci bersih, potong tipis-tipis rendam pakai air garam. Siapkan tepung serbaguna tambah tepung tapioka cakpurkan dengan merica bubuk dan garam."
- "Ayam yang sudah di potong tipis masukkan terigu dan goreng sampai kuning keemasan, tiriskan"
- "Bersihkan wortel, cabe hijau, bawang kemudian potong korek api."
- "Tumis bawang bombay, bawang putih sampai harum. Masukkan wortel tambahkan sedikit garam dan air, tumis sampai layu"
- "Masukkan saus asam manis, gula dan penyedap rasa cek rasa. Kemudian masukkan ayam yang sudah di goreng, tambahkan cabe hijau dan masak sampai bumbu meresap."
- "Setelah bumbu meresap angkat dan hidangkan. Selamat mencoba moms"
categories:
- Resep
tags:
- ayam
- bumbu
- asam

katakunci: ayam bumbu asam 
nutrition: 261 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Bumbu Asam Manis](https://img-global.cpcdn.com/recipes/ed3af4e95c849dcd/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg)

Andai kamu seorang yang hobi memasak, mempersiapkan hidangan sedap kepada keluarga merupakan suatu hal yang menggembirakan bagi anda sendiri. Peran seorang  wanita bukan saja mengurus rumah saja, namun anda juga harus memastikan keperluan nutrisi terpenuhi dan juga masakan yang dimakan anak-anak wajib lezat.

Di era  sekarang, kalian memang dapat mengorder masakan siap saji walaupun tanpa harus susah mengolahnya dulu. Tapi ada juga lho orang yang memang mau memberikan yang terbaik untuk orang tercintanya. Karena, menghidangkan masakan sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penikmat ayam bumbu asam manis?. Tahukah kamu, ayam bumbu asam manis merupakan hidangan khas di Nusantara yang kini digemari oleh banyak orang dari berbagai wilayah di Indonesia. Kamu dapat menghidangkan ayam bumbu asam manis sendiri di rumah dan boleh dijadikan camilan kesukaanmu di hari liburmu.

Anda tidak perlu bingung jika kamu ingin mendapatkan ayam bumbu asam manis, lantaran ayam bumbu asam manis gampang untuk dicari dan juga kalian pun dapat membuatnya sendiri di rumah. ayam bumbu asam manis dapat diolah dengan bermacam cara. Kini ada banyak sekali resep modern yang membuat ayam bumbu asam manis semakin lebih enak.

Resep ayam bumbu asam manis pun sangat gampang untuk dibuat, lho. Kamu tidak perlu capek-capek untuk memesan ayam bumbu asam manis, lantaran Kalian bisa menyajikan sendiri di rumah. Bagi Kita yang hendak membuatnya, di bawah ini adalah resep menyajikan ayam bumbu asam manis yang mantab yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Bumbu Asam Manis:

1. Gunakan 500 gr ayam filet
1. Gunakan 1 buah wortel
1. Sediakan 1 buah bawang bombay
1. Gunakan 3 siung bawang putih
1. Sediakan 3 buah cabe hijau
1. Siapkan 1 bungkus tepung sajiku serbaguna
1. Gunakan 4 sdm tepung tapioka
1. Gunakan  Merica bubuk secukup nya
1. Gunakan secukupnya Garam
1. Siapkan secukupnya Gula merah
1. Siapkan 1 bungkus saus asam manis (saori)
1. Sediakan secukupnya Penyedap rasa
1. Gunakan  Minyak untuk menggoreng




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Bumbu Asam Manis:

1. Ayam filet dicuci bersih, potong tipis-tipis rendam pakai air garam. Siapkan tepung serbaguna tambah tepung tapioka cakpurkan dengan merica bubuk dan garam.
1. Ayam yang sudah di potong tipis masukkan terigu dan goreng sampai kuning keemasan, tiriskan
1. Bersihkan wortel, cabe hijau, bawang kemudian potong korek api.
1. Tumis bawang bombay, bawang putih sampai harum. Masukkan wortel tambahkan sedikit garam dan air, tumis sampai layu
1. Masukkan saus asam manis, gula dan penyedap rasa cek rasa. Kemudian masukkan ayam yang sudah di goreng, tambahkan cabe hijau dan masak sampai bumbu meresap.
1. Setelah bumbu meresap angkat dan hidangkan. Selamat mencoba moms




Ternyata resep ayam bumbu asam manis yang nikamt tidak rumit ini enteng sekali ya! Semua orang bisa membuatnya. Resep ayam bumbu asam manis Sangat sesuai banget untuk kamu yang sedang belajar memasak maupun untuk anda yang sudah pandai dalam memasak.

Tertarik untuk mencoba membikin resep ayam bumbu asam manis mantab tidak ribet ini? Kalau anda ingin, yuk kita segera buruan menyiapkan alat-alat dan bahan-bahannya, lalu buat deh Resep ayam bumbu asam manis yang nikmat dan tidak rumit ini. Sangat gampang kan. 

Oleh karena itu, daripada kalian diam saja, ayo langsung aja sajikan resep ayam bumbu asam manis ini. Dijamin kamu gak akan nyesel sudah membuat resep ayam bumbu asam manis lezat sederhana ini! Selamat berkreasi dengan resep ayam bumbu asam manis enak tidak ribet ini di tempat tinggal masing-masing,oke!.

