---
description: "Cara memasak Coto ayam makassar yang lezat Untuk Jualan"
title: "Cara memasak Coto ayam makassar yang lezat Untuk Jualan"
slug: 53-cara-memasak-coto-ayam-makassar-yang-lezat-untuk-jualan
date: 2021-03-09T19:08:51.869Z
image: https://img-global.cpcdn.com/recipes/52ce811871121a45/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/52ce811871121a45/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/52ce811871121a45/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Barry Daniel
ratingvalue: 3.2
reviewcount: 7
recipeingredient:
- "1 kg daging ayam potong dadu"
- "5 lembar daun jeruk"
- "3 lembar daun Salam"
- "Seruas lengkuasgeprek"
- "250 gr kacang tanah goreng dan haluskan"
- " Secukupnya kayu manis"
- " Secukupnya garam"
- " Secukupnya air"
- " Secukupnya kaldu ayam"
- " Bumbu yang di haluskan"
- " 10 butir bawang merah"
- " 10 butir bawang putih"
- " Seruas jahe"
- " Seruas lengkuas"
- " 1 sdt ketumbar"
- " 1 sdt merica"
- " 1 sdt jintan"
- " 1 buah pala"
- " 5 butir kemiri"
- "7 batang serai"
- " Bahan pelengkap"
- " Bawang goreng"
- " Daun bawang dan seledri"
- " Jeruk nipis"
- " Sambal"
recipeinstructions:
- "Cuci bersih daging ayam,rebus dengan air secukupnya sampai matang,angkat dan sisihkan"
- "Sementara daging ayam di rebus, tumis bumbu halus sampai harum dengan minyak secukupnya, masukkan daun jeruk, daun salam, lengkuas geprek, kayu manis"
- "Masak kembali air rebusan ayam sampai mendidih, masukkan bumbu halus, kacang halus, biarkan sampai bumbu meresap, masukkan garam dan kaldu bubuk, test rasa, angkat"
- "Masukkan daging ayam ke dalam wadah, siram dengan kuah coto, masukkan pelengkap, siap di hidangkan"
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 269 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Lunch

---


![Coto ayam makassar](https://img-global.cpcdn.com/recipes/52ce811871121a45/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan olahan mantab buat keluarga merupakan hal yang membahagiakan untuk anda sendiri. Peran seorang  wanita bukan sekedar mengerjakan pekerjaan rumah saja, tapi kamu juga wajib memastikan keperluan nutrisi terpenuhi dan juga hidangan yang dikonsumsi orang tercinta wajib mantab.

Di waktu  sekarang, kamu sebenarnya dapat membeli masakan praktis walaupun tanpa harus susah membuatnya dulu. Tetapi banyak juga orang yang selalu ingin menghidangkan yang terenak bagi orang yang dicintainya. Pasalnya, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai selera orang tercinta. 



Mungkinkah anda adalah seorang penikmat coto ayam makassar?. Tahukah kamu, coto ayam makassar adalah hidangan khas di Nusantara yang sekarang disukai oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Kalian dapat menyajikan coto ayam makassar sendiri di rumahmu dan dapat dijadikan hidangan favorit di hari liburmu.

Anda tidak perlu bingung untuk menyantap coto ayam makassar, lantaran coto ayam makassar gampang untuk didapatkan dan kita pun boleh mengolahnya sendiri di tempatmu. coto ayam makassar boleh diolah dengan beragam cara. Sekarang sudah banyak banget cara modern yang membuat coto ayam makassar lebih mantap.

Resep coto ayam makassar pun sangat mudah untuk dibikin, lho. Kamu tidak perlu repot-repot untuk memesan coto ayam makassar, lantaran Anda dapat menghidangkan di rumahmu. Bagi Kamu yang mau mencobanya, inilah resep untuk membuat coto ayam makassar yang enak yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Coto ayam makassar:

1. Gunakan 1 kg daging ayam (potong dadu)
1. Gunakan 5 lembar daun jeruk
1. Gunakan 3 lembar daun Salam
1. Siapkan Seruas lengkuas(geprek)
1. Ambil 250 gr kacang tanah (goreng dan haluskan)
1. Siapkan  Secukupnya kayu manis
1. Ambil  Secukupnya garam
1. Gunakan  Secukupnya air
1. Ambil  Secukupnya kaldu ayam
1. Siapkan  Bumbu yang di haluskan
1. Ambil  10 butir bawang merah
1. Gunakan  10 butir bawang putih
1. Siapkan  Seruas jahe
1. Gunakan  Seruas lengkuas
1. Ambil  1 sdt ketumbar
1. Sediakan  1 sdt merica
1. Siapkan  1 sdt jintan
1. Gunakan  1 buah pala
1. Ambil  5 butir kemiri
1. Ambil 7 batang serai
1. Siapkan  Bahan pelengkap
1. Ambil  Bawang goreng
1. Siapkan  Daun bawang dan seledri
1. Siapkan  Jeruk nipis
1. Gunakan  Sambal




<!--inarticleads2-->

##### Cara menyiapkan Coto ayam makassar:

1. Cuci bersih daging ayam,rebus dengan air secukupnya sampai matang,angkat dan sisihkan
1. Sementara daging ayam di rebus, tumis bumbu halus sampai harum dengan minyak secukupnya, masukkan daun jeruk, daun salam, lengkuas geprek, kayu manis
1. Masak kembali air rebusan ayam sampai mendidih, masukkan bumbu halus, kacang halus, biarkan sampai bumbu meresap, masukkan garam dan kaldu bubuk, test rasa, angkat
1. Masukkan daging ayam ke dalam wadah, siram dengan kuah coto, masukkan pelengkap, siap di hidangkan




Ternyata resep coto ayam makassar yang mantab tidak ribet ini gampang sekali ya! Kalian semua dapat memasaknya. Resep coto ayam makassar Sangat cocok sekali buat kamu yang baru mau belajar memasak ataupun juga bagi anda yang sudah lihai dalam memasak.

Apakah kamu ingin mencoba membikin resep coto ayam makassar lezat sederhana ini? Kalau kalian tertarik, ayo kalian segera buruan siapin alat dan bahannya, kemudian buat deh Resep coto ayam makassar yang lezat dan simple ini. Sangat taidak sulit kan. 

Jadi, ketimbang kita diam saja, yuk langsung aja sajikan resep coto ayam makassar ini. Pasti kalian tiidak akan menyesal sudah buat resep coto ayam makassar nikmat tidak rumit ini! Selamat berkreasi dengan resep coto ayam makassar lezat tidak ribet ini di rumah kalian sendiri,ya!.

