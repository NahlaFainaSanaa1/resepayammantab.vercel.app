---
description: "Cara membuat 12. Ayam asam manis yang nikmat dan Mudah Dibuat"
title: "Cara membuat 12. Ayam asam manis yang nikmat dan Mudah Dibuat"
slug: 139-cara-membuat-12-ayam-asam-manis-yang-nikmat-dan-mudah-dibuat
date: 2021-04-13T17:42:16.460Z
image: https://img-global.cpcdn.com/recipes/885227f325db5f3f/680x482cq70/12-ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/885227f325db5f3f/680x482cq70/12-ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/885227f325db5f3f/680x482cq70/12-ayam-asam-manis-foto-resep-utama.jpg
author: Travis Morris
ratingvalue: 3.9
reviewcount: 9
recipeingredient:
- "1/2 kg dada ayam potong sesuai selera"
- "2 sdm kecap asin"
- "1 buah jeruk nipis"
- "5 sdm tepung maizena"
- "2 btr putih telur"
- "Secukupnya minyak goreng"
- "1 buah paprika hijau"
- "1 buah nanas"
- "3 buah cabe merah besar"
- "1 buah bawang bombay"
- "3 siung bawang putih"
- "2 batang preidaun bawang"
- "2 sdm gula pasir"
- "3 sdm saos tiram"
- "5 sdm saos tomat"
- "1 sdm minyak wijen"
- "1 sdt lada bubuk"
- "1 sdt garam"
- "1 sdm margarinutk menumis"
recipeinstructions:
- "Potong dada ayam, cuci bersih tambahkan kecap asin dan perasan jeruk nipis, diamkan 10 menit."
- "Tambahkan putih telur dan tepung maizena aduk rata."
- "Goreng ayam sampai berwarna kuning keemasan."
- "Siapkan bahan yg akan ditumis, potong sesuai gambar dan disiapkan juga saos pelengkap utk penunjang rasa."
- "Tumis bawang putih dng sedikit margarin."
- "Berikutnya masukkan paprika dan bawang bombay"
- "Disusul cabe merah besar, ayam goreng, nanas dan semua saos, garam, gula, dan lada bubuk."
- "Terakhir baru masukkan bawang prei."
- "Angkat dan hidangkan dng nasi panas."
categories:
- Resep
tags:
- 12
- ayam
- asam

katakunci: 12 ayam asam 
nutrition: 254 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dessert

---


![12. Ayam asam manis](https://img-global.cpcdn.com/recipes/885227f325db5f3f/680x482cq70/12-ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan panganan mantab buat keluarga tercinta merupakan suatu hal yang memuaskan bagi anda sendiri. Kewajiban seorang ibu Tidak hanya mengatur rumah saja, namun kamu pun harus memastikan keperluan nutrisi tercukupi dan juga olahan yang dikonsumsi anak-anak wajib lezat.

Di waktu  sekarang, kita sebenarnya bisa mengorder olahan jadi meski tanpa harus ribet mengolahnya dahulu. Tetapi banyak juga orang yang selalu ingin menyajikan yang terlezat untuk orang tercintanya. Lantaran, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan berdasarkan kesukaan famili. 



Mungkinkah anda seorang penggemar 12. ayam asam manis?. Asal kamu tahu, 12. ayam asam manis merupakan sajian khas di Nusantara yang saat ini disenangi oleh setiap orang di berbagai daerah di Nusantara. Kalian bisa memasak 12. ayam asam manis olahan sendiri di rumah dan boleh dijadikan makanan favorit di akhir pekan.

Kamu tak perlu bingung jika kamu ingin memakan 12. ayam asam manis, lantaran 12. ayam asam manis tidak sukar untuk dicari dan kamu pun bisa mengolahnya sendiri di rumah. 12. ayam asam manis bisa dimasak lewat bermacam cara. Kini sudah banyak banget resep modern yang membuat 12. ayam asam manis semakin nikmat.

Resep 12. ayam asam manis juga mudah untuk dibuat, lho. Kalian tidak usah capek-capek untuk memesan 12. ayam asam manis, lantaran Anda bisa menyajikan sendiri di rumah. Untuk Kita yang hendak menyajikannya, di bawah ini adalah resep membuat 12. ayam asam manis yang nikamat yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan 12. Ayam asam manis:

1. Siapkan 1/2 kg dada ayam potong sesuai selera
1. Siapkan 2 sdm kecap asin
1. Gunakan 1 buah jeruk nipis
1. Gunakan 5 sdm tepung maizena
1. Sediakan 2 btr putih telur
1. Siapkan Secukupnya minyak goreng
1. Siapkan 1 buah paprika hijau
1. Sediakan 1 buah nanas
1. Sediakan 3 buah cabe merah besar
1. Siapkan 1 buah bawang bombay
1. Sediakan 3 siung bawang putih
1. Siapkan 2 batang prei/daun bawang
1. Siapkan 2 sdm gula pasir
1. Sediakan 3 sdm saos tiram
1. Siapkan 5 sdm saos tomat
1. Gunakan 1 sdm minyak wijen
1. Siapkan 1 sdt lada bubuk
1. Gunakan 1 sdt garam
1. Sediakan 1 sdm margarin(utk menumis)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan 12. Ayam asam manis:

1. Potong dada ayam, cuci bersih tambahkan kecap asin dan perasan jeruk nipis, diamkan 10 menit.
1. Tambahkan putih telur dan tepung maizena aduk rata.
1. Goreng ayam sampai berwarna kuning keemasan.
1. Siapkan bahan yg akan ditumis, potong sesuai gambar dan disiapkan juga saos pelengkap utk penunjang rasa.
1. Tumis bawang putih dng sedikit margarin.
1. Berikutnya masukkan paprika dan bawang bombay
1. Disusul cabe merah besar, ayam goreng, nanas dan semua saos, garam, gula, dan lada bubuk.
1. Terakhir baru masukkan bawang prei.
1. Angkat dan hidangkan dng nasi panas.




Ternyata cara buat 12. ayam asam manis yang mantab sederhana ini gampang sekali ya! Semua orang dapat membuatnya. Resep 12. ayam asam manis Cocok banget buat anda yang baru belajar memasak ataupun untuk kamu yang telah jago dalam memasak.

Tertarik untuk mencoba buat resep 12. ayam asam manis lezat tidak ribet ini? Kalau anda mau, yuk kita segera buruan menyiapkan alat dan bahannya, setelah itu bikin deh Resep 12. ayam asam manis yang enak dan tidak ribet ini. Sangat mudah kan. 

Jadi, ketimbang anda berfikir lama-lama, hayo langsung aja hidangkan resep 12. ayam asam manis ini. Pasti kamu tak akan menyesal bikin resep 12. ayam asam manis nikmat simple ini! Selamat mencoba dengan resep 12. ayam asam manis enak simple ini di tempat tinggal kalian masing-masing,ya!.

