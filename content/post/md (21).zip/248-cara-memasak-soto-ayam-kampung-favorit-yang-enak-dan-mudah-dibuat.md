---
description: "Cara memasak Soto ayam kampung favorit yang enak dan Mudah Dibuat"
title: "Cara memasak Soto ayam kampung favorit yang enak dan Mudah Dibuat"
slug: 248-cara-memasak-soto-ayam-kampung-favorit-yang-enak-dan-mudah-dibuat
date: 2021-05-26T02:24:43.340Z
image: https://img-global.cpcdn.com/recipes/1bd5e438f6ab68eb/680x482cq70/soto-ayam-kampung-favorit-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1bd5e438f6ab68eb/680x482cq70/soto-ayam-kampung-favorit-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1bd5e438f6ab68eb/680x482cq70/soto-ayam-kampung-favorit-foto-resep-utama.jpg
author: Bernice Cross
ratingvalue: 4.5
reviewcount: 6
recipeingredient:
- "1 ekor ayam kampung"
- "2,5 liter air matang"
- " Bumbu aromatik "
- "3 btg serehgeprak"
- "2 ruas lengkuasgeprak"
- "2 ruas jahegeprak"
- "3 lbr daun jeruk"
- "2 lbr daun salam"
- " Bumbu halus "
- "8 siung bawang merah"
- "4 siung bawang putih"
- "1 sdt merica butiran"
- "1 sdt ketumbar"
- "5 butir kemiri"
- "2 ruas kunir"
- "Sedikit air utk memblender"
- " 1 bgks bumbu instan soto"
recipeinstructions:
- "Didihkan air. Lalu masukkan ayam yg sdh dipotong kecil. Masukkan juga bumbu aromatik nya. Jgn lupa buang buih yg mengapung. Tutup pancinya. Biarkan selama 15 menit."
- "Sambil menunggu rebusan ayam,kita tumis bumbu blenderannya. Jangan diberi tambahan minyak ya selama awal menumis. Biarkan sampai bumbu saat/berkurang airnya,gunakan api kecil&amp;sering dioseng ya spy tdk gosong"
- "Setelah bumbu asat, baru tambahkan 1 sendok sayur minyak. Tumis sampai harum. Masukkan juga bumbu instan soto spy lbh nendang,aduk rata."
- "Masukkan bumbu kedalam rebusan ayam. Aduk rata. Tutup lagi kira2 selama 15 menit atau sampai ayam empuk. Lalu test rasanya. Bila sdh pas,matikan kompornya.. Nikmad bersama kupat/lontong.. Bisa jg disuwir ayamnya yaa..Alhamdulillah.."
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 223 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto ayam kampung favorit](https://img-global.cpcdn.com/recipes/1bd5e438f6ab68eb/680x482cq70/soto-ayam-kampung-favorit-foto-resep-utama.jpg)

Andai kalian seorang wanita, menyediakan panganan menggugah selera kepada orang tercinta merupakan hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang istri bukan hanya mengerjakan pekerjaan rumah saja, tapi kamu pun harus menyediakan kebutuhan gizi tercukupi dan santapan yang dimakan anak-anak mesti sedap.

Di era  sekarang, anda memang mampu memesan hidangan instan meski tidak harus ribet memasaknya lebih dulu. Tetapi ada juga lho orang yang memang mau memberikan hidangan yang terenak untuk keluarganya. Lantaran, memasak yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penggemar soto ayam kampung favorit?. Asal kamu tahu, soto ayam kampung favorit adalah hidangan khas di Nusantara yang kini disenangi oleh banyak orang dari berbagai tempat di Nusantara. Kalian bisa membuat soto ayam kampung favorit olahan sendiri di rumah dan pasti jadi santapan favoritmu di hari libur.

Kalian tidak perlu bingung untuk menyantap soto ayam kampung favorit, karena soto ayam kampung favorit tidak sukar untuk dicari dan juga kamu pun dapat membuatnya sendiri di tempatmu. soto ayam kampung favorit boleh dimasak dengan beraneka cara. Kini sudah banyak resep kekinian yang menjadikan soto ayam kampung favorit lebih enak.

Resep soto ayam kampung favorit juga sangat gampang untuk dibikin, lho. Kalian tidak perlu capek-capek untuk memesan soto ayam kampung favorit, lantaran Kita dapat menyiapkan di rumah sendiri. Bagi Kita yang ingin mencobanya, inilah resep untuk menyajikan soto ayam kampung favorit yang nikamat yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto ayam kampung favorit:

1. Ambil 1 ekor ayam kampung
1. Sediakan 2,5 liter air matang
1. Sediakan  Bumbu aromatik :
1. Gunakan 3 btg sereh,geprak
1. Siapkan 2 ruas lengkuas,geprak
1. Ambil 2 ruas jahe,geprak
1. Sediakan 3 lbr daun jeruk
1. Gunakan 2 lbr daun salam
1. Gunakan  Bumbu halus :
1. Gunakan 8 siung bawang merah
1. Gunakan 4 siung bawang putih
1. Gunakan 1 sdt merica butiran
1. Sediakan 1 sdt ketumbar
1. Sediakan 5 butir kemiri
1. Gunakan 2 ruas kunir
1. Ambil Sedikit air utk memblender
1. Gunakan  1 bgks bumbu instan soto




<!--inarticleads2-->

##### Cara menyiapkan Soto ayam kampung favorit:

1. Didihkan air. Lalu masukkan ayam yg sdh dipotong kecil. Masukkan juga bumbu aromatik nya. Jgn lupa buang buih yg mengapung. Tutup pancinya. Biarkan selama 15 menit.
1. Sambil menunggu rebusan ayam,kita tumis bumbu blenderannya. Jangan diberi tambahan minyak ya selama awal menumis. Biarkan sampai bumbu saat/berkurang airnya,gunakan api kecil&amp;sering dioseng ya spy tdk gosong
1. Setelah bumbu asat, baru tambahkan 1 sendok sayur minyak. Tumis sampai harum. Masukkan juga bumbu instan soto spy lbh nendang,aduk rata.
1. Masukkan bumbu kedalam rebusan ayam. Aduk rata. Tutup lagi kira2 selama 15 menit atau sampai ayam empuk. Lalu test rasanya. Bila sdh pas,matikan kompornya.. Nikmad bersama kupat/lontong.. Bisa jg disuwir ayamnya yaa..Alhamdulillah..




Ternyata cara membuat soto ayam kampung favorit yang mantab simple ini mudah sekali ya! Kita semua dapat mencobanya. Cara buat soto ayam kampung favorit Sangat sesuai sekali untuk kamu yang baru akan belajar memasak ataupun untuk anda yang sudah jago memasak.

Apakah kamu tertarik mulai mencoba buat resep soto ayam kampung favorit lezat tidak ribet ini? Kalau kamu mau, ayo kalian segera menyiapkan peralatan dan bahannya, lalu buat deh Resep soto ayam kampung favorit yang nikmat dan sederhana ini. Betul-betul mudah kan. 

Jadi, daripada kalian berlama-lama, hayo kita langsung hidangkan resep soto ayam kampung favorit ini. Dijamin kalian tak akan menyesal sudah membuat resep soto ayam kampung favorit mantab simple ini! Selamat berkreasi dengan resep soto ayam kampung favorit enak simple ini di rumah masing-masing,ya!.

