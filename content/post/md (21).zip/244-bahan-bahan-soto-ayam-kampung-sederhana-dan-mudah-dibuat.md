---
description: "Bahan-bahan Soto ayam kampung Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Soto ayam kampung Sederhana dan Mudah Dibuat"
slug: 244-bahan-bahan-soto-ayam-kampung-sederhana-dan-mudah-dibuat
date: 2021-05-24T19:55:50.679Z
image: https://img-global.cpcdn.com/recipes/9e23ddd8ba5b0b62/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9e23ddd8ba5b0b62/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9e23ddd8ba5b0b62/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
author: Jacob Caldwell
ratingvalue: 3.4
reviewcount: 11
recipeingredient:
- " Kentang"
- " Wortel"
- " Kolkobis"
- " Sledri"
- " Kecambah"
- " Ayam kampung"
- " Bumbu halus"
- " Bawang putih"
- " Jahe"
- " Ketumbar"
- " Kunyit"
- " Merica"
- " Kemiri"
- " Bahan pelengkap"
- " Daun salam"
- " Jahe geprek"
- " Lengkuas geprek"
- " Daun jeruk"
- " Bahan sambal"
- " Bawang putih"
- " Garam"
- " Cabe"
- " Kecap"
recipeinstructions:
- "Rebus ayam sampe empuk, iris kentang dicuci dan rendam pake air hangat kemudian di goreng"
- "Tumis bumbu halus sampe wangi kemudian masukkan daun salam daun jeruk jahe geprek dan lengkuas, masukkan kaldu ayam (bekas rebuasan ayam) aduk dan masukkam totole, gula pasir, garam dan cek rasa..dan masukkan ayamnya kedalam kuah soto"
- "Kemudian buat sambal soto, rebus bawang putih, cabe tiriskan dan diulek, masukkan kecap manis"
- "Wortel, kecambang, kubis di rebus sendiri2 kemudian tiriskan"
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Lunch

---


![Soto ayam kampung](https://img-global.cpcdn.com/recipes/9e23ddd8ba5b0b62/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyajikan panganan nikmat bagi keluarga tercinta adalah hal yang menyenangkan bagi kita sendiri. Tanggung jawab seorang  wanita bukan cuman mengerjakan pekerjaan rumah saja, namun anda pun harus memastikan kebutuhan gizi tercukupi dan juga santapan yang dimakan keluarga tercinta mesti sedap.

Di masa  saat ini, kita sebenarnya dapat membeli panganan jadi walaupun tanpa harus repot mengolahnya terlebih dahulu. Tapi banyak juga lho orang yang memang ingin menghidangkan yang terenak bagi orang yang dicintainya. Lantaran, menghidangkan masakan sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Apakah anda adalah seorang penikmat soto ayam kampung?. Asal kamu tahu, soto ayam kampung merupakan hidangan khas di Nusantara yang kini disukai oleh banyak orang dari hampir setiap wilayah di Indonesia. Anda dapat memasak soto ayam kampung sendiri di rumah dan boleh jadi hidangan favoritmu di akhir pekanmu.

Anda tidak perlu bingung jika kamu ingin menyantap soto ayam kampung, lantaran soto ayam kampung tidak sulit untuk dicari dan juga kamu pun dapat membuatnya sendiri di rumah. soto ayam kampung dapat diolah dengan berbagai cara. Saat ini telah banyak resep modern yang membuat soto ayam kampung semakin nikmat.

Resep soto ayam kampung juga mudah sekali untuk dibikin, lho. Anda tidak perlu repot-repot untuk memesan soto ayam kampung, lantaran Kalian dapat menyajikan di rumah sendiri. Bagi Kalian yang mau menyajikannya, inilah resep membuat soto ayam kampung yang nikamat yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Soto ayam kampung:

1. Sediakan  Kentang
1. Gunakan  Wortel
1. Sediakan  Kol/kobis
1. Gunakan  Sledri
1. Gunakan  Kecambah
1. Ambil  Ayam kampung
1. Siapkan  Bumbu halus
1. Sediakan  Bawang putih
1. Siapkan  Jahe
1. Sediakan  Ketumbar
1. Ambil  Kunyit
1. Siapkan  Merica
1. Siapkan  Kemiri
1. Sediakan  Bahan pelengkap
1. Siapkan  Daun salam
1. Gunakan  Jahe geprek
1. Siapkan  Lengkuas geprek
1. Ambil  Daun jeruk
1. Sediakan  Bahan sambal
1. Ambil  Bawang putih
1. Sediakan  Garam
1. Gunakan  Cabe
1. Sediakan  Kecap




<!--inarticleads2-->

##### Cara membuat Soto ayam kampung:

1. Rebus ayam sampe empuk, iris kentang dicuci dan rendam pake air hangat kemudian di goreng
1. Tumis bumbu halus sampe wangi - kemudian masukkan daun salam daun jeruk jahe geprek dan lengkuas, masukkan kaldu ayam (bekas rebuasan ayam) aduk dan masukkam totole, gula pasir, garam dan cek rasa..dan masukkan ayamnya kedalam kuah soto
1. Kemudian buat sambal soto, rebus bawang putih, cabe tiriskan dan diulek, masukkan kecap manis
1. Wortel, kecambang, kubis di rebus sendiri2 kemudian tiriskan




Ternyata cara buat soto ayam kampung yang lezat tidak rumit ini enteng banget ya! Kita semua mampu mencobanya. Cara Membuat soto ayam kampung Sesuai sekali untuk anda yang baru akan belajar memasak maupun bagi kamu yang sudah hebat dalam memasak.

Apakah kamu ingin mulai mencoba buat resep soto ayam kampung lezat tidak ribet ini? Kalau kalian ingin, ayo kamu segera siapin alat dan bahannya, lantas buat deh Resep soto ayam kampung yang mantab dan tidak ribet ini. Benar-benar gampang kan. 

Maka, ketimbang anda berlama-lama, maka langsung aja buat resep soto ayam kampung ini. Dijamin kalian tiidak akan menyesal sudah bikin resep soto ayam kampung nikmat tidak ribet ini! Selamat berkreasi dengan resep soto ayam kampung mantab tidak ribet ini di tempat tinggal kalian masing-masing,ya!.

