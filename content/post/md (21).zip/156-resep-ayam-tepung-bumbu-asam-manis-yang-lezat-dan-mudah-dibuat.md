---
description: "Resep Ayam tepung bumbu Asam Manis yang lezat dan Mudah Dibuat"
title: "Resep Ayam tepung bumbu Asam Manis yang lezat dan Mudah Dibuat"
slug: 156-resep-ayam-tepung-bumbu-asam-manis-yang-lezat-dan-mudah-dibuat
date: 2021-05-17T12:09:20.669Z
image: https://img-global.cpcdn.com/recipes/9c22cf78a372d9c9/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9c22cf78a372d9c9/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9c22cf78a372d9c9/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg
author: Frank McKinney
ratingvalue: 4.2
reviewcount: 5
recipeingredient:
- " Bahan ayam tepung"
- "1/2 kg dada ayam fillet potong kurleb ukuran 2cm"
- "4 sendok makan tepung terigu"
- "4 sendok makan tepung serba guna"
- "secukupnya Lada bubuk"
- "secukupnya Bawang putih bubuk bisa diganti dengan bawang putih yang dihaluskan uleg"
- "secukupnya Garam"
- " Bahan bumbu asam manis"
- "4 siung bawang merah"
- "1 buah bawang bombang"
- "4 siung bawang putih"
- "10 sachet saos tomat"
- "1 sendok kecap manis"
- "Secukupnya lada"
- "Secukupnya garam"
- "Secukupnya gula"
recipeinstructions:
- "Marinasi Ayam fillet yang sudah dipotong dengan lada bubuk, bawang putih bubuk dan garam. diamkan selama kurang lebih 10-15 menit."
- "Campur tepung terigu dan tepung serbaguna, perbandingan antara tepung terigu dan tepung serbaguna 1:1 (1 sendok tepung terigu : 1 sendok tepung serba guna)"
- "Bagi menjadi 2 mangkok campuran tepung diatas. 1 mangkok tepung dicampur air dan 1 mangkok tepung saja"
- "Masukkan potongan ayam ke adonan tepung cair kemudian ke adonan kering kemudian goreng"
- "Sambil menunggu semua potongan ayam digoreng kita buat saos asam manisnya ya"
- "Tumis bawang merah, bawang bombay dan bawang putih sampai harum"
- "Masukan saos tomat dan kecap"
- "Tambahkan garam, gula dan lada secukupnya"
- "Jika sudah tercampur semua masukan gorengan ayam"
categories:
- Resep
tags:
- ayam
- tepung
- bumbu

katakunci: ayam tepung bumbu 
nutrition: 209 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam tepung bumbu Asam Manis](https://img-global.cpcdn.com/recipes/9c22cf78a372d9c9/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan olahan enak untuk keluarga tercinta merupakan suatu hal yang mengasyikan bagi kita sendiri. Tanggung jawab seorang ibu Tidak sekedar menangani rumah saja, namun anda juga wajib memastikan kebutuhan nutrisi terpenuhi dan masakan yang dikonsumsi orang tercinta wajib enak.

Di era  saat ini, kamu sebenarnya dapat mengorder panganan praktis tanpa harus ribet membuatnya terlebih dahulu. Tapi banyak juga lho mereka yang selalu mau menyajikan yang terbaik bagi orang tercintanya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut berdasarkan kesukaan orang tercinta. 



Mungkinkah kamu seorang penikmat ayam tepung bumbu asam manis?. Asal kamu tahu, ayam tepung bumbu asam manis adalah hidangan khas di Indonesia yang kini disenangi oleh setiap orang dari hampir setiap daerah di Indonesia. Kamu bisa memasak ayam tepung bumbu asam manis buatan sendiri di rumahmu dan pasti jadi hidangan kesukaanmu di hari libur.

Anda tidak usah bingung jika kamu ingin memakan ayam tepung bumbu asam manis, lantaran ayam tepung bumbu asam manis gampang untuk didapatkan dan kalian pun boleh menghidangkannya sendiri di rumah. ayam tepung bumbu asam manis dapat diolah dengan bermacam cara. Kini telah banyak cara kekinian yang membuat ayam tepung bumbu asam manis semakin nikmat.

Resep ayam tepung bumbu asam manis juga mudah untuk dibuat, lho. Kalian jangan ribet-ribet untuk membeli ayam tepung bumbu asam manis, lantaran Anda bisa membuatnya ditempatmu. Bagi Kita yang mau menghidangkannya, di bawah ini adalah resep untuk menyajikan ayam tepung bumbu asam manis yang mantab yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam tepung bumbu Asam Manis:

1. Siapkan  Bahan ayam tepung
1. Sediakan 1/2 kg dada ayam fillet potong kurleb ukuran 2cm
1. Ambil 4 sendok makan tepung terigu
1. Gunakan 4 sendok makan tepung serba guna
1. Sediakan secukupnya Lada bubuk
1. Siapkan secukupnya Bawang putih bubuk bisa diganti dengan bawang putih yang dihaluskan (uleg)
1. Sediakan secukupnya Garam
1. Sediakan  Bahan bumbu asam manis
1. Gunakan 4 siung bawang merah
1. Gunakan 1 buah bawang bombang
1. Sediakan 4 siung bawang putih
1. Ambil 10 sachet saos tomat
1. Siapkan 1 sendok kecap manis
1. Ambil Secukupnya lada
1. Sediakan Secukupnya garam
1. Sediakan Secukupnya gula




<!--inarticleads2-->

##### Cara membuat Ayam tepung bumbu Asam Manis:

1. Marinasi Ayam fillet yang sudah dipotong dengan lada bubuk, bawang putih bubuk dan garam. diamkan selama kurang lebih 10-15 menit.
1. Campur tepung terigu dan tepung serbaguna, perbandingan antara tepung terigu dan tepung serbaguna 1:1 (1 sendok tepung terigu : 1 sendok tepung serba guna)
1. Bagi menjadi 2 mangkok campuran tepung diatas. 1 mangkok tepung dicampur air dan 1 mangkok tepung saja
1. Masukkan potongan ayam ke adonan tepung cair kemudian ke adonan kering kemudian goreng
1. Sambil menunggu semua potongan ayam digoreng kita buat saos asam manisnya ya
1. Tumis bawang merah, bawang bombay dan bawang putih sampai harum
1. Masukan saos tomat dan kecap
1. Tambahkan garam, gula dan lada secukupnya
1. Jika sudah tercampur semua masukan gorengan ayam




Wah ternyata cara buat ayam tepung bumbu asam manis yang enak simple ini gampang banget ya! Semua orang mampu memasaknya. Resep ayam tepung bumbu asam manis Cocok sekali buat kalian yang sedang belajar memasak maupun juga untuk kalian yang telah ahli memasak.

Apakah kamu mau mencoba membuat resep ayam tepung bumbu asam manis nikmat tidak rumit ini? Kalau ingin, mending kamu segera buruan menyiapkan peralatan dan bahan-bahannya, maka bikin deh Resep ayam tepung bumbu asam manis yang mantab dan tidak ribet ini. Sangat mudah kan. 

Maka dari itu, ketimbang anda diam saja, ayo kita langsung hidangkan resep ayam tepung bumbu asam manis ini. Pasti kamu gak akan menyesal bikin resep ayam tepung bumbu asam manis enak simple ini! Selamat mencoba dengan resep ayam tepung bumbu asam manis mantab tidak ribet ini di rumah masing-masing,oke!.

