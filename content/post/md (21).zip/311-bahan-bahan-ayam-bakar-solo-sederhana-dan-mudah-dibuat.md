---
description: "Bahan-bahan Ayam Bakar Solo Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Ayam Bakar Solo Sederhana dan Mudah Dibuat"
slug: 311-bahan-bahan-ayam-bakar-solo-sederhana-dan-mudah-dibuat
date: 2021-06-21T16:32:16.341Z
image: https://img-global.cpcdn.com/recipes/bf07361bd9133a74/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf07361bd9133a74/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf07361bd9133a74/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
author: Susie Collier
ratingvalue: 3.5
reviewcount: 9
recipeingredient:
- "1 ekor ayam potong menjadi 4"
- "2 sdm Kecap manis"
- "1 sdm gula merah disisir"
- " Air kelapa untuk ungkep ayam"
- " Bumbu yang dihaluskan"
- "8 btr Bawang merah"
- "6 siung Bawang putih"
- "2 butir Kemiri sangrai"
- "Seruas kunyit"
- "secukupnya Garam"
recipeinstructions:
- "Bersihkan ayam dan haluskan bumbu. Balurkan bumbu yang telah dihaluskan ke ayam. Remas-remas sebentar dan diamkan kurang lebih 20 menit"
- "Tambahkan air kelapa, gula merah, kecap manis dan garam. Ungkep ayam sampai ayam empuk dan bumbu mengental."
- "Panggang ayam di atas arang/teflon sambil diolesi sisa bumbu. Sajikan"
categories:
- Resep
tags:
- ayam
- bakar
- solo

katakunci: ayam bakar solo 
nutrition: 152 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Bakar Solo](https://img-global.cpcdn.com/recipes/bf07361bd9133a74/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan santapan enak untuk keluarga merupakan hal yang menggembirakan untuk anda sendiri. Kewajiban seorang istri Tidak saja menangani rumah saja, namun anda juga wajib memastikan keperluan gizi terpenuhi dan juga masakan yang dimakan anak-anak harus nikmat.

Di zaman  sekarang, kamu sebenarnya bisa membeli santapan praktis meski tanpa harus susah membuatnya lebih dulu. Tetapi banyak juga lho mereka yang selalu ingin memberikan hidangan yang terlezat untuk keluarganya. Lantaran, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan selera famili. 



Apakah anda adalah salah satu penggemar ayam bakar solo?. Asal kamu tahu, ayam bakar solo merupakan makanan khas di Indonesia yang sekarang digemari oleh setiap orang di berbagai wilayah di Indonesia. Anda dapat membuat ayam bakar solo hasil sendiri di rumahmu dan pasti jadi makanan kesenanganmu di hari liburmu.

Kamu tidak usah bingung jika kamu ingin menyantap ayam bakar solo, sebab ayam bakar solo mudah untuk ditemukan dan anda pun bisa mengolahnya sendiri di rumah. ayam bakar solo bisa dimasak lewat berbagai cara. Kini telah banyak resep kekinian yang menjadikan ayam bakar solo semakin enak.

Resep ayam bakar solo pun mudah dibuat, lho. Kita tidak usah capek-capek untuk memesan ayam bakar solo, tetapi Kita bisa membuatnya sendiri di rumah. Bagi Anda yang akan menghidangkannya, di bawah ini adalah resep menyajikan ayam bakar solo yang nikamat yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Bakar Solo:

1. Siapkan 1 ekor ayam, potong menjadi 4
1. Ambil 2 sdm Kecap manis
1. Sediakan 1 sdm gula merah disisir
1. Siapkan  Air kelapa untuk ungkep ayam
1. Gunakan  Bumbu yang dihaluskan:
1. Siapkan 8 btr Bawang merah
1. Gunakan 6 siung Bawang putih
1. Gunakan 2 butir Kemiri, sangrai
1. Sediakan Seruas kunyit
1. Sediakan secukupnya Garam




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Bakar Solo:

1. Bersihkan ayam dan haluskan bumbu. Balurkan bumbu yang telah dihaluskan ke ayam. Remas-remas sebentar dan diamkan kurang lebih 20 menit
<img src="https://img-global.cpcdn.com/steps/6ce6128f8b325226/160x128cq70/ayam-bakar-solo-langkah-memasak-1-foto.jpg" alt="Ayam Bakar Solo"><img src="https://img-global.cpcdn.com/steps/0a7f39f472da75be/160x128cq70/ayam-bakar-solo-langkah-memasak-1-foto.jpg" alt="Ayam Bakar Solo"><img src="https://img-global.cpcdn.com/steps/586a94d9d7f7d81a/160x128cq70/ayam-bakar-solo-langkah-memasak-1-foto.jpg" alt="Ayam Bakar Solo">1. Tambahkan air kelapa, gula merah, kecap manis dan garam. Ungkep ayam sampai ayam empuk dan bumbu mengental.
1. Panggang ayam di atas arang/teflon sambil diolesi sisa bumbu. Sajikan




Wah ternyata resep ayam bakar solo yang mantab tidak rumit ini gampang sekali ya! Kamu semua mampu mencobanya. Cara Membuat ayam bakar solo Sangat sesuai sekali untuk kamu yang baru mau belajar memasak ataupun juga bagi kalian yang telah ahli dalam memasak.

Apakah kamu tertarik mencoba membuat resep ayam bakar solo nikmat sederhana ini? Kalau tertarik, ayo kamu segera siapkan alat dan bahan-bahannya, lalu buat deh Resep ayam bakar solo yang lezat dan sederhana ini. Sungguh gampang kan. 

Maka dari itu, ketimbang kalian diam saja, yuk langsung aja hidangkan resep ayam bakar solo ini. Pasti kamu tiidak akan nyesel sudah membuat resep ayam bakar solo enak sederhana ini! Selamat mencoba dengan resep ayam bakar solo enak tidak rumit ini di tempat tinggal kalian masing-masing,ya!.

