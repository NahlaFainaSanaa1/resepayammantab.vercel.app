---
description: "Cara memasak 12. Koloke Ayam Asam Manis yang lezat Untuk Jualan"
title: "Cara memasak 12. Koloke Ayam Asam Manis yang lezat Untuk Jualan"
slug: 144-cara-memasak-12-koloke-ayam-asam-manis-yang-lezat-untuk-jualan
date: 2021-05-15T13:10:33.633Z
image: https://img-global.cpcdn.com/recipes/d1d1372a20083f37/680x482cq70/12-koloke-ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d1d1372a20083f37/680x482cq70/12-koloke-ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d1d1372a20083f37/680x482cq70/12-koloke-ayam-asam-manis-foto-resep-utama.jpg
author: Grace Gardner
ratingvalue: 4.5
reviewcount: 11
recipeingredient:
- " Bahan Utama"
- "500 gr dada ayam potong sesuai selera saya potong kecilkecil"
- "2 siung bawang putih haluskan"
- "1 sdt garam"
- "1/4 sdt merica bubuk"
- " lumuri bumbu ke ayam diamkan sebentar"
- " Bahan pelapis"
- "7 sdm tepung terigu"
- "2 sdm tepung maizena"
- "1 sdt kaldu bubuk"
- "1 sdt garam"
- "1 butir telur kocok lepas"
- " Bahan saus"
- "2 siung bawang putih cincang halus"
- "1 buah bawang bombay potongpotong"
- "7 sdm saus tomat saya 5 sdm  1 buah tomat cincang kasar"
- "2 sdm saus sambal"
- "1 sdm kecap inggris"
- "1/2 gelas air"
- "2 sdm gula pasir"
- "1/2 sdt garam halus"
- "1/2 buah wortel potong korek api"
- "1/2 buah timun buang bijinya lalu potong korek api"
- " Nanas secukupnya potongpotong kecil"
recipeinstructions:
- "Bahan pelapis campur jadi satu, kecuali telur."
- "Masukkan ayam yang telah dilumuri bumbu ke dalam kocokan telur. Lalu masukkan dalam bahan pelapis, sambil cubit-cubit ayam supaya keriting. Pastikan semua ayam tertutup oleh tepung."
- "Goreng ayam dalam minyak panas sampai matang berwarna kuning kecokelatan. Angkat dan tiriskan."
- "Tumis bawang putih dan bombay sampai harum."
- "Masukkan saus tomat, saus sambal, kecap inggris, dan buah tomat yang telah dicincang. Tambahkan air, gula, dan garam."
- "Masukkan wortel, masak sampai agak empuk. Dan saus sedikit mengental."
- "Masukkan timun dan nanas. Masak sebentar. Koreksi rasa."
- "Tuang saus ke ayam yang tadi telah digoreng."
- "Sajikan."
categories:
- Resep
tags:
- 12
- koloke
- ayam

katakunci: 12 koloke ayam 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![12. Koloke Ayam Asam Manis](https://img-global.cpcdn.com/recipes/d1d1372a20083f37/680x482cq70/12-koloke-ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyajikan panganan mantab untuk keluarga adalah hal yang membahagiakan bagi kita sendiri. Kewajiban seorang  wanita Tidak cuman mengatur rumah saja, namun kamu juga wajib menyediakan kebutuhan nutrisi terpenuhi dan hidangan yang dimakan orang tercinta mesti menggugah selera.

Di waktu  saat ini, kita memang dapat memesan panganan praktis meski tidak harus capek memasaknya dahulu. Namun banyak juga orang yang selalu mau memberikan makanan yang terenak untuk orang yang dicintainya. Sebab, menghidangkan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga tercinta. 



Apakah anda adalah seorang penggemar 12. koloke ayam asam manis?. Tahukah kamu, 12. koloke ayam asam manis merupakan sajian khas di Nusantara yang sekarang digemari oleh setiap orang di hampir setiap tempat di Nusantara. Anda dapat menghidangkan 12. koloke ayam asam manis sendiri di rumahmu dan pasti jadi camilan kegemaranmu di hari libur.

Kita tidak usah bingung untuk memakan 12. koloke ayam asam manis, lantaran 12. koloke ayam asam manis tidak sulit untuk dicari dan kamu pun dapat membuatnya sendiri di rumah. 12. koloke ayam asam manis bisa dimasak dengan bermacam cara. Kini sudah banyak banget cara kekinian yang membuat 12. koloke ayam asam manis semakin lezat.

Resep 12. koloke ayam asam manis juga mudah untuk dibuat, lho. Anda tidak usah repot-repot untuk memesan 12. koloke ayam asam manis, tetapi Anda dapat menyajikan sendiri di rumah. Untuk Anda yang ingin menghidangkannya, dibawah ini merupakan resep untuk membuat 12. koloke ayam asam manis yang nikamat yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan 12. Koloke Ayam Asam Manis:

1. Sediakan  Bahan Utama:
1. Gunakan 500 gr dada ayam, potong sesuai selera (saya potong kecil-kecil)
1. Ambil 2 siung bawang putih, haluskan
1. Ambil 1 sdt garam
1. Siapkan 1/4 sdt merica bubuk
1. Ambil  lumuri bumbu ke ayam, diamkan sebentar
1. Ambil  Bahan pelapis:
1. Gunakan 7 sdm tepung terigu
1. Siapkan 2 sdm tepung maizena
1. Sediakan 1 sdt kaldu bubuk
1. Gunakan 1 sdt garam
1. Ambil 1 butir telur kocok lepas
1. Siapkan  Bahan saus:
1. Siapkan 2 siung bawang putih, cincang halus
1. Sediakan 1 buah bawang bombay, potong-potong
1. Siapkan 7 sdm saus tomat (saya 5 sdm &amp; 1 buah tomat cincang kasar)
1. Sediakan 2 sdm saus sambal
1. Gunakan 1 sdm kecap inggris
1. Siapkan 1/2 gelas air
1. Ambil 2 sdm gula pasir
1. Gunakan 1/2 sdt garam halus
1. Gunakan 1/2 buah wortel, potong korek api
1. Siapkan 1/2 buah timun, buang bijinya lalu potong korek api
1. Siapkan  Nanas secukupnya, potong-potong kecil




<!--inarticleads2-->

##### Cara membuat 12. Koloke Ayam Asam Manis:

1. Bahan pelapis campur jadi satu, kecuali telur.
1. Masukkan ayam yang telah dilumuri bumbu ke dalam kocokan telur. Lalu masukkan dalam bahan pelapis, sambil cubit-cubit ayam supaya keriting. Pastikan semua ayam tertutup oleh tepung.
1. Goreng ayam dalam minyak panas sampai matang berwarna kuning kecokelatan. Angkat dan tiriskan.
1. Tumis bawang putih dan bombay sampai harum.
1. Masukkan saus tomat, saus sambal, kecap inggris, dan buah tomat yang telah dicincang. Tambahkan air, gula, dan garam.
1. Masukkan wortel, masak sampai agak empuk. Dan saus sedikit mengental.
1. Masukkan timun dan nanas. Masak sebentar. Koreksi rasa.
1. Tuang saus ke ayam yang tadi telah digoreng.
1. Sajikan.




Wah ternyata cara buat 12. koloke ayam asam manis yang mantab tidak rumit ini enteng banget ya! Kamu semua dapat membuatnya. Cara Membuat 12. koloke ayam asam manis Sangat sesuai banget buat kalian yang baru mau belajar memasak atau juga untuk kamu yang telah hebat memasak.

Tertarik untuk mulai mencoba membuat resep 12. koloke ayam asam manis mantab tidak rumit ini? Kalau anda ingin, ayo kamu segera buruan menyiapkan alat-alat dan bahannya, kemudian buat deh Resep 12. koloke ayam asam manis yang mantab dan simple ini. Benar-benar taidak sulit kan. 

Maka dari itu, daripada kita berlama-lama, yuk kita langsung sajikan resep 12. koloke ayam asam manis ini. Pasti anda tiidak akan nyesel sudah bikin resep 12. koloke ayam asam manis mantab simple ini! Selamat berkreasi dengan resep 12. koloke ayam asam manis lezat tidak ribet ini di tempat tinggal sendiri,oke!.

