---
description: "Cara memasak Coto Ayam yang nikmat Untuk Jualan"
title: "Cara memasak Coto Ayam yang nikmat Untuk Jualan"
slug: 49-cara-memasak-coto-ayam-yang-nikmat-untuk-jualan
date: 2021-01-20T18:40:24.749Z
image: https://img-global.cpcdn.com/recipes/e665170785947757/680x482cq70/coto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e665170785947757/680x482cq70/coto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e665170785947757/680x482cq70/coto-ayam-foto-resep-utama.jpg
author: Mike Jordan
ratingvalue: 3.7
reviewcount: 3
recipeingredient:
- "1 ekor ayam"
- "2 L air untuk presto"
- "1 L air cucian beras"
- "100 gr kacang tanah sangrai dihaluskan"
- "1 sdm garam"
- "1/2 sdt gula pasir"
- "1 sdt kaldu bubuk"
- " Bumbu halus"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "4 butir kemiri"
- "1/2 sdm ketumbar bubuk disangrai"
- "1/2 sdm jintan bubuk disangrai"
- "1 sdt lada bubuk"
- "3 batang serai ambil putihnya iris halus"
- "2 sdm minyak sayur"
- " Bumbu daun"
- "5 cm jahe digeprek"
- "5 cm lengkuas digeprek"
- "2 batang serai digeprek"
- "3 lembar daun jeruk"
- "3 lembar daun salam"
recipeinstructions:
- "Masukkan 2 L air dan semua bahan bumbu daun pada panci presto. Kemudian, presto 1 ekor ayam yang telah dipotong menjadi 8 bagian. Setelah dipresto, tiriskan ayam dan biarkan pada suhu ruang. Potong kecil/suir ayam."
- "Blender semua bahan bumbu halus. Panaskan 2 sdm minyak sayur dan tumis bumbu halus hingga wangi."
- "Didihkan kembali air kaldu ayam. Masukkan bumbu yang telah ditumis, aduk rata."
- "Tuang air cucian beras dan aduk kembali hingga rata."
- "Masukkan kacang yang telah dihaluskan, ayam yang telah dipotong kecil/disuir, garam, gula pasir dan kaldu bubuk. Aduk lagi hingga rata."
- "Sajikan coto ayam sesuai selera. Selamat menikmati."
categories:
- Resep
tags:
- coto
- ayam

katakunci: coto ayam 
nutrition: 125 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert

---


![Coto Ayam](https://img-global.cpcdn.com/recipes/e665170785947757/680x482cq70/coto-ayam-foto-resep-utama.jpg)

Andai kalian seorang orang tua, mempersiapkan hidangan mantab buat keluarga merupakan hal yang menggembirakan untuk kita sendiri. Kewajiban seorang  wanita bukan cuman mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib memastikan kebutuhan nutrisi tercukupi dan juga panganan yang dimakan anak-anak mesti nikmat.

Di zaman  saat ini, kita memang dapat mengorder olahan praktis tanpa harus susah memasaknya dahulu. Tapi banyak juga lho mereka yang selalu mau memberikan makanan yang terlezat untuk orang yang dicintainya. Sebab, memasak sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan keluarga. 



Apakah kamu seorang penggemar coto ayam?. Asal kamu tahu, coto ayam merupakan sajian khas di Nusantara yang saat ini disenangi oleh banyak orang di hampir setiap wilayah di Indonesia. Anda bisa membuat coto ayam olahan sendiri di rumahmu dan boleh jadi santapan kesukaanmu di hari libur.

Anda tidak perlu bingung jika kamu ingin memakan coto ayam, lantaran coto ayam sangat mudah untuk didapatkan dan juga kamu pun bisa mengolahnya sendiri di rumah. coto ayam bisa dimasak dengan beragam cara. Kini pun sudah banyak banget resep modern yang membuat coto ayam semakin lebih enak.

Resep coto ayam pun mudah dibuat, lho. Kalian tidak perlu ribet-ribet untuk memesan coto ayam, tetapi Kita bisa menghidangkan sendiri di rumah. Bagi Kamu yang akan mencobanya, berikut ini cara untuk membuat coto ayam yang mantab yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Coto Ayam:

1. Gunakan 1 ekor ayam
1. Ambil 2 L air untuk presto
1. Sediakan 1 L air cucian beras
1. Gunakan 100 gr kacang tanah sangrai (dihaluskan)
1. Sediakan 1 sdm garam
1. Ambil 1/2 sdt gula pasir
1. Ambil 1 sdt kaldu bubuk
1. Gunakan  Bumbu halus:
1. Siapkan 8 siung bawang merah
1. Ambil 5 siung bawang putih
1. Sediakan 4 butir kemiri
1. Siapkan 1/2 sdm ketumbar bubuk (disangrai)
1. Siapkan 1/2 sdm jintan bubuk (disangrai)
1. Ambil 1 sdt lada bubuk
1. Sediakan 3 batang serai (ambil putihnya, iris halus)
1. Ambil 2 sdm minyak sayur
1. Gunakan  Bumbu daun:
1. Siapkan 5 cm jahe (digeprek)
1. Siapkan 5 cm lengkuas (digeprek)
1. Sediakan 2 batang serai (digeprek)
1. Siapkan 3 lembar daun jeruk
1. Ambil 3 lembar daun salam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Coto Ayam:

1. Masukkan 2 L air dan semua bahan bumbu daun pada panci presto. Kemudian, presto 1 ekor ayam yang telah dipotong menjadi 8 bagian. Setelah dipresto, tiriskan ayam dan biarkan pada suhu ruang. Potong kecil/suir ayam.
1. Blender semua bahan bumbu halus. Panaskan 2 sdm minyak sayur dan tumis bumbu halus hingga wangi.
1. Didihkan kembali air kaldu ayam. Masukkan bumbu yang telah ditumis, aduk rata.
1. Tuang air cucian beras dan aduk kembali hingga rata.
1. Masukkan kacang yang telah dihaluskan, ayam yang telah dipotong kecil/disuir, garam, gula pasir dan kaldu bubuk. Aduk lagi hingga rata.
1. Sajikan coto ayam sesuai selera. Selamat menikmati.




Ternyata cara membuat coto ayam yang mantab simple ini mudah banget ya! Kamu semua dapat mencobanya. Cara Membuat coto ayam Cocok sekali buat kamu yang baru belajar memasak maupun bagi kamu yang telah jago memasak.

Apakah kamu ingin mulai mencoba buat resep coto ayam nikmat tidak rumit ini? Kalau tertarik, ayo kalian segera buruan siapin alat dan bahan-bahannya, setelah itu bikin deh Resep coto ayam yang enak dan simple ini. Benar-benar gampang kan. 

Oleh karena itu, ketimbang anda berlama-lama, maka kita langsung saja hidangkan resep coto ayam ini. Pasti kalian tak akan menyesal sudah buat resep coto ayam nikmat simple ini! Selamat mencoba dengan resep coto ayam mantab tidak ribet ini di rumah masing-masing,ya!.

