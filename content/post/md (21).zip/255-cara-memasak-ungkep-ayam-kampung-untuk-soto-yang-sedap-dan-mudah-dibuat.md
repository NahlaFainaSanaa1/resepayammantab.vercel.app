---
description: "Cara memasak Ungkep Ayam Kampung (untuk Soto) yang sedap dan Mudah Dibuat"
title: "Cara memasak Ungkep Ayam Kampung (untuk Soto) yang sedap dan Mudah Dibuat"
slug: 255-cara-memasak-ungkep-ayam-kampung-untuk-soto-yang-sedap-dan-mudah-dibuat
date: 2021-04-09T13:05:44.560Z
image: https://img-global.cpcdn.com/recipes/2fa3070674ab23b0/680x482cq70/ungkep-ayam-kampung-untuk-soto-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2fa3070674ab23b0/680x482cq70/ungkep-ayam-kampung-untuk-soto-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2fa3070674ab23b0/680x482cq70/ungkep-ayam-kampung-untuk-soto-foto-resep-utama.jpg
author: Owen Craig
ratingvalue: 5
reviewcount: 15
recipeingredient:
- "1 ekor ayam kampung"
- "2 sdm bumbu dasar kuning           lihat resep"
- "1 sdm garam"
- "2 gelas air"
- "3 lembar daun salam"
- "2 batang serai"
- "1 lembar besar daun jeruk"
recipeinstructions:
- "Cuci ayam hingga bersih. Siapkan panci. Masukkan ayam dan air. Tumis bumbu dasar kuning sebentar, lalu masukkan ke dalam panci. Masukkan bumbu yang lainnya juga."
- "Masak dengan api besar hingga mendidih. Kemudian kecilkan api. Tutup pancinya. Masak selama 30 menit. Kemudian buka tutup panci, tunggu 30 menit. Lalu matikan api. Biarkan hingga dingin. Dengan begitu, bumbu akan meresap ke dalam daging ayam. Setelah dingin, goreng ayam."
- "Jika ingin membuat Soto, kuah kaldu tadi, ditambah dengan 1 liter air. Masak hingga mendidih. Tambahkan garam dan kaldu bubuk. Kuah Soto siap disajikan bersama pelengkap lainnya."
categories:
- Resep
tags:
- ungkep
- ayam
- kampung

katakunci: ungkep ayam kampung 
nutrition: 202 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Ungkep Ayam Kampung (untuk Soto)](https://img-global.cpcdn.com/recipes/2fa3070674ab23b0/680x482cq70/ungkep-ayam-kampung-untuk-soto-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyajikan masakan lezat untuk orang tercinta adalah suatu hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang  wanita Tidak cuma mengatur rumah saja, namun anda juga wajib menyediakan keperluan nutrisi tercukupi dan hidangan yang disantap keluarga tercinta wajib enak.

Di waktu  saat ini, kalian sebenarnya bisa memesan masakan jadi tidak harus ribet memasaknya lebih dulu. Tetapi ada juga lho orang yang memang mau memberikan yang terenak untuk keluarganya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai makanan kesukaan keluarga. 



Apakah kamu salah satu penyuka ungkep ayam kampung (untuk soto)?. Asal kamu tahu, ungkep ayam kampung (untuk soto) merupakan hidangan khas di Indonesia yang saat ini disenangi oleh setiap orang dari hampir setiap tempat di Indonesia. Kalian dapat menyajikan ungkep ayam kampung (untuk soto) sendiri di rumahmu dan boleh dijadikan santapan kesukaanmu di hari libur.

Anda tidak usah bingung untuk menyantap ungkep ayam kampung (untuk soto), karena ungkep ayam kampung (untuk soto) gampang untuk ditemukan dan juga kalian pun boleh mengolahnya sendiri di tempatmu. ungkep ayam kampung (untuk soto) bisa dimasak lewat beragam cara. Sekarang ada banyak cara modern yang membuat ungkep ayam kampung (untuk soto) lebih nikmat.

Resep ungkep ayam kampung (untuk soto) juga mudah sekali untuk dibuat, lho. Kamu tidak usah capek-capek untuk membeli ungkep ayam kampung (untuk soto), karena Kamu mampu menyajikan ditempatmu. Bagi Kamu yang akan membuatnya, di bawah ini adalah cara untuk membuat ungkep ayam kampung (untuk soto) yang lezat yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ungkep Ayam Kampung (untuk Soto):

1. Ambil 1 ekor ayam kampung
1. Ambil 2 sdm bumbu dasar kuning           (lihat resep)
1. Sediakan 1 sdm garam
1. Siapkan 2 gelas air
1. Sediakan 3 lembar daun salam
1. Ambil 2 batang serai
1. Sediakan 1 lembar besar daun jeruk




<!--inarticleads2-->

##### Langkah-langkah membuat Ungkep Ayam Kampung (untuk Soto):

1. Cuci ayam hingga bersih. Siapkan panci. Masukkan ayam dan air. Tumis bumbu dasar kuning sebentar, lalu masukkan ke dalam panci. Masukkan bumbu yang lainnya juga.
1. Masak dengan api besar hingga mendidih. Kemudian kecilkan api. Tutup pancinya. Masak selama 30 menit. Kemudian buka tutup panci, tunggu 30 menit. Lalu matikan api. Biarkan hingga dingin. Dengan begitu, bumbu akan meresap ke dalam daging ayam. Setelah dingin, goreng ayam.
1. Jika ingin membuat Soto, kuah kaldu tadi, ditambah dengan 1 liter air. Masak hingga mendidih. Tambahkan garam dan kaldu bubuk. Kuah Soto siap disajikan bersama pelengkap lainnya.




Ternyata cara membuat ungkep ayam kampung (untuk soto) yang nikamt simple ini gampang banget ya! Kita semua mampu mencobanya. Cara Membuat ungkep ayam kampung (untuk soto) Sangat sesuai banget buat anda yang baru mau belajar memasak maupun juga untuk kalian yang telah lihai memasak.

Apakah kamu ingin mulai mencoba buat resep ungkep ayam kampung (untuk soto) nikmat sederhana ini? Kalau kamu ingin, yuk kita segera buruan siapkan peralatan dan bahannya, maka bikin deh Resep ungkep ayam kampung (untuk soto) yang enak dan tidak ribet ini. Benar-benar gampang kan. 

Maka, ketimbang kita diam saja, hayo kita langsung saja bikin resep ungkep ayam kampung (untuk soto) ini. Pasti kalian tiidak akan menyesal sudah membuat resep ungkep ayam kampung (untuk soto) nikmat sederhana ini! Selamat mencoba dengan resep ungkep ayam kampung (untuk soto) nikmat simple ini di rumah kalian sendiri,ya!.

