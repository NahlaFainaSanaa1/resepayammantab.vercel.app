---
description: "Bahan-bahan Steak ayam &amp;amp; potato wedges yang sedap dan Mudah Dibuat"
title: "Bahan-bahan Steak ayam &amp;amp; potato wedges yang sedap dan Mudah Dibuat"
slug: 292-bahan-bahan-steak-ayam-and-amp-potato-wedges-yang-sedap-dan-mudah-dibuat
date: 2021-03-12T13:51:10.427Z
image: https://img-global.cpcdn.com/recipes/b7e0b031e5112eba/680x482cq70/steak-ayam-potato-wedges-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b7e0b031e5112eba/680x482cq70/steak-ayam-potato-wedges-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b7e0b031e5112eba/680x482cq70/steak-ayam-potato-wedges-foto-resep-utama.jpg
author: Roger Parker
ratingvalue: 3.7
reviewcount: 3
recipeingredient:
- " Bahansteak ayam"
- "1/4 kg ayam fillet"
- " Bahan A marinasi"
- "1/2 sdt garam"
- "2 bawang putih haluskan"
- "1/2 sdt lada"
- "1/2 jeruk nipis"
- " Bahan B basah"
- "1 butir telur"
- " Bahan C kering"
- "2 sdm maizena"
- "6 sdm tepung bumbu serbaguna"
- "  bahan potato wedges"
- "1 buah kentang iris sesuai gambar"
- " Bahan D rebus kentang"
- "1 bawang putih geprek dan cincang"
- "Secukupnya garam"
- "Secukupnya lada"
- " Bahan E kering"
- "1 sdm maizena"
- "1 sdm tepung bumbu"
- "1/2 sdm nori boncabe  oregano sledri"
- " bahan saus"
- "1/4 bawang bombay cincang"
- "2 bawang putih ukuran sedang cincang"
- "4 bawang merah ukuran sedang cincang"
- "1 buah tomat ukuran besar rebus hingga empuk"
- "1 sdt pala"
- "1 sdm saori tiram"
- "1 sdt kecap"
- "1 sdt saus tomat"
- "1 sdt saus pedas"
- "Secukupnya garam"
- "Secukupnya lada"
- "Secukupnya masako"
- "Secukupnya gula"
- "1 sdm maizena campur air"
- "Secukupnya air"
recipeinstructions:
- "Pertama, Marinasi ayam fillet dengan bumbu A diamkan dalam kulkas/ frezeer."
- "Kedua. Sembari menunggu marinasi. Rebus kentang udah di iris-iris dan masukan bumbu D, rebus 8 menit dan tiriskan. Lalu lumuri kentang dengan bahan E. Dan simpan dalam frezeer."
- "Ketiga, masak saus. Siapkan semua bahan saus. Rebus tomat hingga empuk lalu iris2. Tumis bawang bombay hingga layu lalu masukan bawang merah dan bawang putih hingga wangi dan layu lalu masukan pala, tomat, saori, kecap, saus pedas dan tomat aduk aduk hingga tercampur lalu masukan air tunggu hingga mendidih, lalu masukan larutan maizena dan tunggu blubuk-blubuk. Test rasa."
- "Keempat. Kluarkan fillet ayam dan lumuri dengan bahan B dan C, cubit cubit adonan lalu goreng."
- "Kelima. Kluarkan kentang lalu goreng di minyak jgn terlalu panas 3 menit tiriskan, lalu goreng lg di minya panas hingga kering. Lalu angkat"
- "Sudah siap"
categories:
- Resep
tags:
- steak
- ayam
- 

katakunci: steak ayam  
nutrition: 115 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Steak ayam &amp; potato wedges](https://img-global.cpcdn.com/recipes/b7e0b031e5112eba/680x482cq70/steak-ayam-potato-wedges-foto-resep-utama.jpg)

Apabila kalian seorang istri, mempersiapkan hidangan nikmat untuk famili merupakan hal yang mengasyikan bagi anda sendiri. Kewajiban seorang istri Tidak sekedar mengurus rumah saja, namun anda pun wajib memastikan kebutuhan gizi tercukupi dan olahan yang dimakan anak-anak mesti lezat.

Di zaman  saat ini, kita memang bisa mengorder santapan jadi tidak harus susah membuatnya dahulu. Namun banyak juga orang yang memang mau menyajikan yang terlezat bagi orang tercintanya. Sebab, memasak yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Mungkinkah anda seorang penyuka steak ayam &amp; potato wedges?. Tahukah kamu, steak ayam &amp; potato wedges merupakan hidangan khas di Indonesia yang sekarang digemari oleh banyak orang di berbagai tempat di Nusantara. Kalian bisa menyajikan steak ayam &amp; potato wedges kreasi sendiri di rumah dan boleh dijadikan camilan kesenanganmu di hari liburmu.

Anda tak perlu bingung jika kamu ingin menyantap steak ayam &amp; potato wedges, sebab steak ayam &amp; potato wedges tidak sulit untuk ditemukan dan juga kamu pun boleh mengolahnya sendiri di tempatmu. steak ayam &amp; potato wedges boleh dimasak dengan bermacam cara. Kini pun ada banyak resep kekinian yang membuat steak ayam &amp; potato wedges lebih lezat.

Resep steak ayam &amp; potato wedges pun mudah untuk dibikin, lho. Anda tidak perlu capek-capek untuk membeli steak ayam &amp; potato wedges, tetapi Kalian bisa menyiapkan sendiri di rumah. Bagi Kita yang akan menghidangkannya, dibawah ini merupakan cara untuk membuat steak ayam &amp; potato wedges yang mantab yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Steak ayam &amp; potato wedges:

1. Ambil  ✨Bahansteak ayam
1. Ambil 1/4 kg ayam fillet
1. Ambil  Bahan A (marinasi)
1. Siapkan 1/2 sdt garam
1. Ambil 2 bawang putih haluskan
1. Sediakan 1/2 sdt lada
1. Ambil 1/2 jeruk nipis
1. Gunakan  Bahan B (basah)
1. Sediakan 1 butir telur
1. Ambil  Bahan C (kering)
1. Ambil 2 sdm maizena
1. Gunakan 6 sdm tepung bumbu serbaguna
1. Sediakan  ✨ bahan potato wedges
1. Ambil 1 buah kentang iris sesuai gambar
1. Ambil  Bahan D (rebus kentang)
1. Gunakan 1 bawang putih geprek dan cincang
1. Siapkan Secukupnya garam
1. Gunakan Secukupnya lada
1. Ambil  Bahan E (kering)
1. Gunakan 1 sdm maizena
1. Sediakan 1 sdm tepung bumbu
1. Gunakan 1/2 sdm nori boncabe / oregano/ sledri
1. Gunakan  ✨bahan saus
1. Ambil 1/4 bawang bombay cincang
1. Siapkan 2 bawang putih ukuran sedang cincang
1. Sediakan 4 bawang merah ukuran sedang cincang
1. Sediakan 1 buah tomat ukuran besar rebus hingga empuk
1. Sediakan 1 sdt pala
1. Gunakan 1 sdm saori tiram
1. Siapkan 1 sdt kecap
1. Gunakan 1 sdt saus tomat
1. Sediakan 1 sdt saus pedas
1. Sediakan Secukupnya garam
1. Sediakan Secukupnya lada
1. Sediakan Secukupnya masako
1. Siapkan Secukupnya gula
1. Sediakan 1 sdm maizena campur air
1. Ambil Secukupnya air




<!--inarticleads2-->

##### Cara membuat Steak ayam &amp; potato wedges:

1. Pertama, Marinasi ayam fillet dengan bumbu A diamkan dalam kulkas/ frezeer.
1. Kedua. Sembari menunggu marinasi. Rebus kentang udah di iris-iris dan masukan bumbu D, rebus 8 menit dan tiriskan. Lalu lumuri kentang dengan bahan E. Dan simpan dalam frezeer.
1. Ketiga, masak saus. Siapkan semua bahan saus. Rebus tomat hingga empuk lalu iris2. Tumis bawang bombay hingga layu lalu masukan bawang merah dan bawang putih hingga wangi dan layu lalu masukan pala, tomat, saori, kecap, saus pedas dan tomat aduk aduk hingga tercampur lalu masukan air tunggu hingga mendidih, lalu masukan larutan maizena dan tunggu blubuk-blubuk. Test rasa.
1. Keempat. Kluarkan fillet ayam dan lumuri dengan bahan B dan C, cubit cubit adonan lalu goreng.
1. Kelima. Kluarkan kentang lalu goreng di minyak jgn terlalu panas 3 menit tiriskan, lalu goreng lg di minya panas hingga kering. Lalu angkat
1. Sudah siap




Wah ternyata cara buat steak ayam &amp; potato wedges yang lezat sederhana ini mudah banget ya! Semua orang mampu menghidangkannya. Cara Membuat steak ayam &amp; potato wedges Cocok sekali untuk kamu yang sedang belajar memasak ataupun juga bagi kamu yang telah jago dalam memasak.

Apakah kamu mau mencoba membikin resep steak ayam &amp; potato wedges enak sederhana ini? Kalau anda mau, ayo kalian segera buruan siapin alat dan bahannya, lalu bikin deh Resep steak ayam &amp; potato wedges yang enak dan tidak ribet ini. Benar-benar gampang kan. 

Jadi, daripada anda berfikir lama-lama, yuk langsung aja hidangkan resep steak ayam &amp; potato wedges ini. Pasti anda gak akan nyesel membuat resep steak ayam &amp; potato wedges nikmat tidak ribet ini! Selamat mencoba dengan resep steak ayam &amp; potato wedges lezat sederhana ini di rumah kalian masing-masing,ya!.

