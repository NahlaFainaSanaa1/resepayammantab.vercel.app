---
description: "Resep Ayam bumbu asam manis pedas yang nikmat Untuk Jualan"
title: "Resep Ayam bumbu asam manis pedas yang nikmat Untuk Jualan"
slug: 160-resep-ayam-bumbu-asam-manis-pedas-yang-nikmat-untuk-jualan
date: 2021-04-15T11:36:27.373Z
image: https://img-global.cpcdn.com/recipes/0d56c3884ca4ec9c/680x482cq70/ayam-bumbu-asam-manis-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0d56c3884ca4ec9c/680x482cq70/ayam-bumbu-asam-manis-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0d56c3884ca4ec9c/680x482cq70/ayam-bumbu-asam-manis-pedas-foto-resep-utama.jpg
author: Amanda Shaw
ratingvalue: 3.5
reviewcount: 5
recipeingredient:
- "1/2 Kg Dada Ayam Fillet"
- "1 Bungkus Tepung Bumbu Sasa"
- "1/2 SDT Garam"
- "1/2 Botol Saus Tomat"
- "2 SDM Saus Tiram"
- "5 Butir Cabai Rawit"
- "1 Buah lemon  Sedikit Cuka"
- "1/2 SDT Gula"
- "1 SDT Royco"
- "5-10 SDM Saus Sambal"
- "3 Siung Bawang Putih"
- "1 Buah Bawang Bombay"
- "1 Buah Tomat"
- "1 SDT Tepung Maizena"
recipeinstructions:
- "Cuci ayam menggunakan air bersih"
- "Potong-potong Bawang putih, bawang bombay, tomat dan cabai rawit"
- "Letakkan tepung bumbu sasa pada wadah yang diisi sedikit air"
- "Letakkan tepung bumbu sasa pada wadah yang TIDAK diisi air"
- "Celupkan ayam pada tepung bumbu sasa yang berisikan air lalu celupkan ditepung yang kering (lakukan sebanyak 2x agar tepung terasa tebal)"
- "Tuang minyak kedalam wajan, tunggu hingga panas"
- "Masukkan ayam yang sudah dilumuri tepung kendalam minyak panas"
- "Tunggu hingga ayam berwarna kecoklatan lalu angkat dan tiriskan"
- "Tuangkan sedikit minyak kedalam wajan, tumis bawang bombay, bawang putih dan tomat yang sudah dipotong-potong lalu tunggu hingga layu"
- "Masukkan air kedalam wajan, tunggu hingga mendidik"
- "Masukkan saus tomat, saus sambal, saus tiram lalu aduk hingga merata"
- "Masukkan royco, garam, gula aduk hingga merata. Angkat jika merasa sudah selesai (rasanya pas)"
- "Hidangkan ayam dengan bumbu yang sudah ditumis.."
categories:
- Resep
tags:
- ayam
- bumbu
- asam

katakunci: ayam bumbu asam 
nutrition: 248 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam bumbu asam manis pedas](https://img-global.cpcdn.com/recipes/0d56c3884ca4ec9c/680x482cq70/ayam-bumbu-asam-manis-pedas-foto-resep-utama.jpg)

Jika kamu seorang yang hobi memasak, menyajikan masakan sedap untuk orang tercinta adalah suatu hal yang menyenangkan bagi anda sendiri. Tanggung jawab seorang istri Tidak saja mengatur rumah saja, tapi anda pun wajib memastikan keperluan nutrisi terpenuhi dan santapan yang disantap keluarga tercinta mesti lezat.

Di era  sekarang, kita sebenarnya bisa mengorder masakan jadi tanpa harus capek membuatnya dahulu. Tetapi ada juga mereka yang memang mau menyajikan yang terenak untuk keluarganya. Karena, memasak sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai selera keluarga. 

Resep Ayam Bakar Teflon Bumbu Rujak. Masak ini aja bun, ayam saos asam manis pedas dijamin sekeluarga pasti suka semua. Setelah ayam dipotong-potong, sebaiknya cuci terlebih dahulu ayam untuk.

Apakah anda adalah salah satu penyuka ayam bumbu asam manis pedas?. Asal kamu tahu, ayam bumbu asam manis pedas adalah hidangan khas di Indonesia yang saat ini disukai oleh orang-orang di berbagai wilayah di Indonesia. Kamu dapat memasak ayam bumbu asam manis pedas olahan sendiri di rumah dan boleh jadi makanan kegemaranmu di hari liburmu.

Kita tidak perlu bingung untuk memakan ayam bumbu asam manis pedas, karena ayam bumbu asam manis pedas mudah untuk ditemukan dan anda pun bisa membuatnya sendiri di tempatmu. ayam bumbu asam manis pedas bisa dibuat dengan bermacam cara. Saat ini sudah banyak resep kekinian yang membuat ayam bumbu asam manis pedas semakin enak.

Resep ayam bumbu asam manis pedas pun gampang dibikin, lho. Kalian tidak usah capek-capek untuk memesan ayam bumbu asam manis pedas, karena Anda dapat membuatnya sendiri di rumah. Bagi Kalian yang hendak menghidangkannya, berikut cara membuat ayam bumbu asam manis pedas yang nikamat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam bumbu asam manis pedas:

1. Sediakan 1/2 Kg Dada Ayam Fillet
1. Gunakan 1 Bungkus Tepung Bumbu Sasa
1. Ambil 1/2 SDT Garam
1. Ambil 1/2 Botol Saus Tomat
1. Siapkan 2 SDM Saus Tiram
1. Ambil 5 Butir Cabai Rawit
1. Ambil 1 Buah lemon / Sedikit Cuka
1. Ambil 1/2 SDT Gula
1. Ambil 1 SDT Royco
1. Ambil 5-10 SDM Saus Sambal
1. Ambil 3 Siung Bawang Putih
1. Gunakan 1 Buah Bawang Bombay
1. Gunakan 1 Buah Tomat
1. Siapkan 1 SDT Tepung Maizena


Perlu diketahui bahwa bumbu masakan ayam fillet yakni bawang bombay, bawang putih, saus tomat, dan beberapa bahan bumbu lainnya yangmudah anda beli di pasar maupun supermarket terdekat. Padukan nikmatnya hidangan ayam bumbu kecap dengan rasa manis, gurih, dan pedas. Asam manis pedas lebih kepada saus yang benar-benar menggugah selera. Resep ayam asam pedas merupakan kombinasi unik penghibur lidah yang Baik dari bumbu halus, bahan pilihan hingga cara mengolahnya yang benar-benar dari hati. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam bumbu asam manis pedas:

1. Cuci ayam menggunakan air bersih
1. Potong-potong Bawang putih, bawang bombay, tomat dan cabai rawit
1. Letakkan tepung bumbu sasa pada wadah yang diisi sedikit air
1. Letakkan tepung bumbu sasa pada wadah yang TIDAK diisi air
1. Celupkan ayam pada tepung bumbu sasa yang berisikan air lalu celupkan ditepung yang kering (lakukan sebanyak 2x agar tepung terasa tebal)
1. Tuang minyak kedalam wajan, tunggu hingga panas
1. Masukkan ayam yang sudah dilumuri tepung kendalam minyak panas
1. Tunggu hingga ayam berwarna kecoklatan lalu angkat dan tiriskan
1. Tuangkan sedikit minyak kedalam wajan, tumis bawang bombay, bawang putih dan tomat yang sudah dipotong-potong lalu tunggu hingga layu
1. Masukkan air kedalam wajan, tunggu hingga mendidik
1. Masukkan saus tomat, saus sambal, saus tiram lalu aduk hingga merata
1. Masukkan royco, garam, gula aduk hingga merata. Angkat jika merasa sudah selesai (rasanya pas)
1. Hidangkan ayam dengan bumbu yang sudah ditumis..


Resep yang dimasak dari hati akan sampai ke hati. Ayam bakar bumbu rujak merupakan salah satu masakan yang mempunyai cita rasa khas pedas manis. Pengolahan saos asam manis bila ingin terasa lebih pedas bisa ditambahkan cabai rawit atau cabe yang pedas. Saus di Indonesia terkadang juga disebut saos, sedangkan dalam bahasa inggris sauce. Saus asam manis berfungsi serbaguna dan multi fungsi, seperti untuk bahan campuran aneka. 

Wah ternyata cara membuat ayam bumbu asam manis pedas yang mantab simple ini gampang banget ya! Kalian semua mampu memasaknya. Cara buat ayam bumbu asam manis pedas Sangat cocok sekali untuk kita yang baru mau belajar memasak ataupun juga bagi anda yang sudah jago dalam memasak.

Tertarik untuk mencoba membuat resep ayam bumbu asam manis pedas nikmat sederhana ini? Kalau anda tertarik, yuk kita segera menyiapkan peralatan dan bahannya, setelah itu buat deh Resep ayam bumbu asam manis pedas yang lezat dan sederhana ini. Betul-betul mudah kan. 

Oleh karena itu, ketimbang anda diam saja, maka kita langsung buat resep ayam bumbu asam manis pedas ini. Pasti anda tiidak akan nyesel sudah membuat resep ayam bumbu asam manis pedas lezat simple ini! Selamat mencoba dengan resep ayam bumbu asam manis pedas lezat sederhana ini di rumah sendiri,oke!.

