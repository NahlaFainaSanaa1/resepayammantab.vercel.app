---
description: "Cara membuat Coto Ayam Makassar yang nikmat Untuk Jualan"
title: "Cara membuat Coto Ayam Makassar yang nikmat Untuk Jualan"
slug: 52-cara-membuat-coto-ayam-makassar-yang-nikmat-untuk-jualan
date: 2021-06-08T22:06:46.207Z
image: https://img-global.cpcdn.com/recipes/9822600f8ca7213d/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9822600f8ca7213d/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9822600f8ca7213d/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Lottie Buchanan
ratingvalue: 4.1
reviewcount: 15
recipeingredient:
- "500 gram daging ayam"
- "2 helai daun salam"
- "2 helai daun jeruk"
- "Secukupnya garam"
- "Secukupnya Kaldu ayam"
- "1/2 sdt merica bubuk"
- "1 sdt ketumbar bubuk"
- "1/2 sdt pala bubuk"
- "1/2 sdt Jintan bubuk saya skip"
- "2 sdm air asam jawa"
- "2 sdm gula merah bisa pakai gula pasir"
- " Minyak untuk menumis bumbu"
- "2 liter Air bisa pakai air cucian beras"
- " Bumbu halus"
- "150 gr kacang tanah sangrai"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "2 btang serai potong potong"
- "Seruas jahe"
- "Seruas lengkuas"
- "Seruas kunyit boleh di skip"
- " Air"
- " Bumbu pelengkap"
- " Daun bawang potong potong"
- " Bawang goreng"
- " Jeruk nipis"
- " Sambel"
- " Kecap"
recipeinstructions:
- "Siapkan bumbu, Cuci bersih ayam, potong kotak kotak atau sesuai selera, masak sampai dagingnya empuk."
- "Sangrai kacang tanah sampai matang. Kemudian haluskan bersama bumbu halus."
- "Panaskan minyak kemudian tumis bumbu halus, masukkan daun salam, daun jeruk, merica bubuk, ketumbar, pala dan jintan. Tumis sampai minyak tanak."
- "Masukkan bumbu kedalam rebusan ayam, beri garam, gula, kaldu bubuk dan air asam. Aduk rata. Masak sampai kuah mengental. Cek rasa"
- "Sajikan bersama bumbu pelengkap."
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 180 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert

---


![Coto Ayam Makassar](https://img-global.cpcdn.com/recipes/9822600f8ca7213d/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Andai kamu seorang wanita, mempersiapkan santapan enak bagi orang tercinta merupakan suatu hal yang memuaskan untuk anda sendiri. Peran seorang istri bukan sekedar menangani rumah saja, namun anda pun harus menyediakan keperluan nutrisi tercukupi dan masakan yang dikonsumsi anak-anak wajib enak.

Di waktu  sekarang, anda memang bisa membeli olahan instan meski tanpa harus repot mengolahnya dulu. Namun banyak juga lho orang yang selalu mau menghidangkan yang terlezat untuk orang yang dicintainya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penyuka coto ayam makassar?. Tahukah kamu, coto ayam makassar merupakan hidangan khas di Indonesia yang sekarang disenangi oleh orang-orang dari hampir setiap daerah di Indonesia. Kamu dapat membuat coto ayam makassar sendiri di rumahmu dan pasti jadi santapan kegemaranmu di hari liburmu.

Kamu jangan bingung untuk mendapatkan coto ayam makassar, karena coto ayam makassar tidak sulit untuk dicari dan kita pun bisa membuatnya sendiri di tempatmu. coto ayam makassar boleh dimasak lewat beraneka cara. Saat ini sudah banyak cara modern yang menjadikan coto ayam makassar semakin lebih nikmat.

Resep coto ayam makassar pun sangat mudah dibuat, lho. Kamu tidak usah ribet-ribet untuk membeli coto ayam makassar, tetapi Kita bisa menyajikan di rumah sendiri. Untuk Kalian yang hendak mencobanya, dibawah ini merupakan resep untuk membuat coto ayam makassar yang mantab yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Coto Ayam Makassar:

1. Sediakan 500 gram daging ayam
1. Ambil 2 helai daun salam
1. Siapkan 2 helai daun jeruk
1. Sediakan Secukupnya garam
1. Ambil Secukupnya Kaldu ayam
1. Sediakan 1/2 sdt merica bubuk
1. Gunakan 1 sdt ketumbar bubuk
1. Gunakan 1/2 sdt pala bubuk
1. Siapkan 1/2 sdt Jintan bubuk, saya skip
1. Siapkan 2 sdm air asam jawa
1. Gunakan 2 sdm gula merah, bisa pakai gula pasir
1. Siapkan  Minyak untuk menumis bumbu
1. Sediakan 2 liter Air, bisa pakai air cucian beras
1. Gunakan  Bumbu halus
1. Siapkan 150 gr kacang tanah, sangrai
1. Gunakan 6 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Sediakan 2 btang serai, potong potong
1. Sediakan Seruas jahe
1. Sediakan Seruas lengkuas
1. Gunakan Seruas kunyit, boleh di skip
1. Siapkan  Air
1. Siapkan  Bumbu pelengkap
1. Sediakan  Daun bawang, potong potong
1. Siapkan  Bawang goreng
1. Sediakan  Jeruk nipis
1. Siapkan  Sambel
1. Siapkan  Kecap




<!--inarticleads2-->

##### Cara menyiapkan Coto Ayam Makassar:

1. Siapkan bumbu, Cuci bersih ayam, potong kotak kotak atau sesuai selera, masak sampai dagingnya empuk.
1. Sangrai kacang tanah sampai matang. Kemudian haluskan bersama bumbu halus.
1. Panaskan minyak kemudian tumis bumbu halus, masukkan daun salam, daun jeruk, merica bubuk, ketumbar, pala dan jintan. Tumis sampai minyak tanak.
1. Masukkan bumbu kedalam rebusan ayam, beri garam, gula, kaldu bubuk dan air asam. Aduk rata. Masak sampai kuah mengental. Cek rasa
1. Sajikan bersama bumbu pelengkap.




Wah ternyata resep coto ayam makassar yang mantab tidak ribet ini enteng banget ya! Anda Semua bisa mencobanya. Resep coto ayam makassar Cocok banget buat kalian yang baru belajar memasak ataupun untuk kamu yang sudah ahli dalam memasak.

Apakah kamu mau mulai mencoba buat resep coto ayam makassar lezat sederhana ini? Kalau anda mau, mending kamu segera siapin alat dan bahan-bahannya, maka buat deh Resep coto ayam makassar yang lezat dan sederhana ini. Benar-benar gampang kan. 

Maka, ketimbang kalian berfikir lama-lama, yuk langsung aja hidangkan resep coto ayam makassar ini. Dijamin kamu tiidak akan menyesal sudah membuat resep coto ayam makassar nikmat simple ini! Selamat berkreasi dengan resep coto ayam makassar enak tidak ribet ini di rumah sendiri,oke!.

