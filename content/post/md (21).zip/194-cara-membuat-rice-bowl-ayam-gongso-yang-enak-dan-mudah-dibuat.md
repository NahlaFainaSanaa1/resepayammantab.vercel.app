---
description: "Cara membuat Rice Bowl Ayam Gongso yang enak dan Mudah Dibuat"
title: "Cara membuat Rice Bowl Ayam Gongso yang enak dan Mudah Dibuat"
slug: 194-cara-membuat-rice-bowl-ayam-gongso-yang-enak-dan-mudah-dibuat
date: 2021-05-09T15:37:10.269Z
image: https://img-global.cpcdn.com/recipes/490db79f45b52317/680x482cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/490db79f45b52317/680x482cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/490db79f45b52317/680x482cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg
author: Jean Benson
ratingvalue: 4
reviewcount: 15
recipeingredient:
- "300 gr dada ayam"
- "50 gr kol potongpotong"
- "2 buah tomat kecil potongpotong"
- "5 buah cabe rawit utuh sesuai selera"
- "2 buah cabe merah iris serong"
- "1 mangkuk Nasi putih"
- "1 butir telur ceplok 12 matang"
- "2 lembar daun salam"
- "1 ruas lengkuas geprek"
- "1 sdt lada bubuk"
- "1/2 sdt garam"
- "1 sdt kaldu jamurpenyedap"
- "3 sdm kecap manis"
- "200 ml air"
- " Minyak goreng"
- " Bumbu halus"
- "4 siung bawang putih"
- "2 siung bawang merah"
- "2 butir kemiri"
- "1 buah cabe rawit"
recipeinstructions:
- "Bersihkan dada ayam, rebus selama 10 menit, angkat dan tiriskan, potong dadu/suwir-suwir, sisihkan."
- "Tumis bumbu halus sampai wangi, tambahkan salam dan lengkuas, masukkan ayam suwir aduk, bumbui kecap, garam, lada dan penyedap."
- "Tuang air, masukkan kol, cabe rawit dan tomat aduk rata, masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa."
- "Sajikan dengan nasi hangat dan telur ceplok 1/2 matang. Selamat menikmati. 😊"
categories:
- Resep
tags:
- rice
- bowl
- ayam

katakunci: rice bowl ayam 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dessert

---


![Rice Bowl Ayam Gongso](https://img-global.cpcdn.com/recipes/490db79f45b52317/680x482cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg)

Apabila anda seorang ibu, menyuguhkan masakan enak pada famili adalah hal yang memuaskan bagi anda sendiri. Peran seorang istri Tidak cuma mengerjakan pekerjaan rumah saja, tapi anda juga wajib menyediakan keperluan gizi terpenuhi dan juga olahan yang dikonsumsi orang tercinta harus mantab.

Di masa  sekarang, kamu sebenarnya mampu memesan olahan yang sudah jadi walaupun tanpa harus ribet mengolahnya terlebih dahulu. Tetapi banyak juga orang yang memang mau menghidangkan yang terbaik bagi orang yang dicintainya. Sebab, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera keluarga tercinta. 



Apakah anda merupakan seorang penikmat rice bowl ayam gongso?. Asal kamu tahu, rice bowl ayam gongso adalah hidangan khas di Indonesia yang saat ini disenangi oleh banyak orang di hampir setiap wilayah di Indonesia. Anda bisa membuat rice bowl ayam gongso sendiri di rumah dan pasti jadi santapan favorit di hari liburmu.

Anda tidak perlu bingung untuk mendapatkan rice bowl ayam gongso, sebab rice bowl ayam gongso tidak sukar untuk dicari dan juga kalian pun bisa mengolahnya sendiri di rumah. rice bowl ayam gongso boleh dimasak memalui berbagai cara. Kini sudah banyak cara modern yang menjadikan rice bowl ayam gongso semakin lebih mantap.

Resep rice bowl ayam gongso pun sangat gampang dibikin, lho. Anda tidak perlu capek-capek untuk membeli rice bowl ayam gongso, tetapi Kalian dapat menghidangkan sendiri di rumah. Bagi Kita yang mau menghidangkannya, dibawah ini merupakan cara menyajikan rice bowl ayam gongso yang mantab yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Rice Bowl Ayam Gongso:

1. Sediakan 300 gr dada ayam
1. Ambil 50 gr kol, potong-potong
1. Sediakan 2 buah tomat kecil, potong-potong
1. Siapkan 5 buah cabe rawit utuh (sesuai selera)
1. Gunakan 2 buah cabe merah, iris serong
1. Sediakan 1 mangkuk Nasi putih
1. Siapkan 1 butir telur ceplok 1/2 matang
1. Siapkan 2 lembar daun salam
1. Siapkan 1 ruas lengkuas, geprek
1. Sediakan 1 sdt lada bubuk
1. Ambil 1/2 sdt garam
1. Ambil 1 sdt kaldu jamur/penyedap
1. Siapkan 3 sdm kecap manis
1. Siapkan 200 ml air
1. Sediakan  Minyak goreng
1. Siapkan  Bumbu halus
1. Gunakan 4 siung bawang putih
1. Siapkan 2 siung bawang merah
1. Sediakan 2 butir kemiri
1. Siapkan 1 buah cabe rawit




<!--inarticleads2-->

##### Cara menyiapkan Rice Bowl Ayam Gongso:

1. Bersihkan dada ayam, rebus selama 10 menit, angkat dan tiriskan, potong dadu/suwir-suwir, sisihkan.
1. Tumis bumbu halus sampai wangi, tambahkan salam dan lengkuas, masukkan ayam suwir aduk, bumbui kecap, garam, lada dan penyedap.
1. Tuang air, masukkan kol, cabe rawit dan tomat aduk rata, masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa.
1. Sajikan dengan nasi hangat dan telur ceplok 1/2 matang. Selamat menikmati. 😊




Wah ternyata cara buat rice bowl ayam gongso yang enak sederhana ini gampang banget ya! Kamu semua bisa memasaknya. Resep rice bowl ayam gongso Sesuai sekali buat kamu yang baru akan belajar memasak maupun bagi anda yang telah jago memasak.

Tertarik untuk mencoba bikin resep rice bowl ayam gongso lezat tidak ribet ini? Kalau kamu tertarik, mending kamu segera buruan menyiapkan peralatan dan bahan-bahannya, kemudian buat deh Resep rice bowl ayam gongso yang mantab dan sederhana ini. Benar-benar gampang kan. 

Maka, daripada anda berfikir lama-lama, hayo kita langsung saja sajikan resep rice bowl ayam gongso ini. Dijamin kamu tak akan menyesal membuat resep rice bowl ayam gongso nikmat simple ini! Selamat berkreasi dengan resep rice bowl ayam gongso nikmat sederhana ini di tempat tinggal kalian masing-masing,ya!.

