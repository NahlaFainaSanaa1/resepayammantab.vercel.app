---
description: "Bahan-bahan Ayam Paha Crispy Pedas Asam Lemon / Spicy &amp;amp; Lemon Sauce yang sedap dan Mudah Dibuat"
title: "Bahan-bahan Ayam Paha Crispy Pedas Asam Lemon / Spicy &amp;amp; Lemon Sauce yang sedap dan Mudah Dibuat"
slug: 344-bahan-bahan-ayam-paha-crispy-pedas-asam-lemon-spicy-and-amp-lemon-sauce-yang-sedap-dan-mudah-dibuat
date: 2021-05-10T04:44:11.320Z
image: https://img-global.cpcdn.com/recipes/38b423589f432354/680x482cq70/ayam-paha-crispy-pedas-asam-lemon-spicy-lemon-sauce-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/38b423589f432354/680x482cq70/ayam-paha-crispy-pedas-asam-lemon-spicy-lemon-sauce-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/38b423589f432354/680x482cq70/ayam-paha-crispy-pedas-asam-lemon-spicy-lemon-sauce-foto-resep-utama.jpg
author: Franklin Maldonado
ratingvalue: 3.6
reviewcount: 6
recipeingredient:
- "750 gr ayam bag paha blh ganti dgn wings  bag sesuai selera"
- " Bahan marinasi"
- "3 siung bawang putih parut"
- "1/2 sdm kecap asin  garam"
- "1 sdt perasan lemon"
- "1 sdt lada bubuk"
- " Tepung crispy"
- "8 sdm tepung terigu"
- "3 sdm tepung maizena"
- "1/2 sdt garam"
- " Bumbu saus"
- "5 buah cabe merah keriting cincang kasar"
- "Sesuai selera cabe rawit cincang kasar"
- "1 siung bawang bombay ukuran besar potong2 kecil"
- "5 sdm saus tomat  2 buah tomat haluskan dgn sedikit air"
- "1,5 sdm saus tiram"
- "1 sdm saus hot lava optional"
- "1 sdm perasan jeruk lemon"
- "Sedikit zest jeruk lemon"
- "1 sdm gula"
- "Secukupnya garam"
- "Secukupnya minyak"
- "Sedikit air"
recipeinstructions:
- "Campurkan ayam dgn seluruh bahan2 marinasi, marinasi ayam min 20 menit."
- "Campurkan semua bahan tepung crispy, baluri ayam dgn tepung hingga rata (terus bolak balik), goreng ayam hingga matang &amp; kecoklatan, tiriskan"
- "Tumis bawang bombay, cabe keriting &amp; cabe rawit hingga wangi. Masukkan seluruh sisa bahan saus. Aduk2 hingga mengental."
- "Masukkan ayam satu persatu, sambil diaduk hingga ayam terbaluti saus. Sajikan.. happy cooking! 😊"
categories:
- Resep
tags:
- ayam
- paha
- crispy

katakunci: ayam paha crispy 
nutrition: 112 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Paha Crispy Pedas Asam Lemon / Spicy &amp; Lemon Sauce](https://img-global.cpcdn.com/recipes/38b423589f432354/680x482cq70/ayam-paha-crispy-pedas-asam-lemon-spicy-lemon-sauce-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan panganan lezat pada famili adalah hal yang menggembirakan bagi kita sendiri. Peran seorang ibu bukan saja menangani rumah saja, tetapi kamu juga wajib memastikan kebutuhan nutrisi terpenuhi dan juga masakan yang dimakan keluarga tercinta mesti mantab.

Di masa  saat ini, kamu sebenarnya dapat mengorder hidangan instan meski tidak harus susah mengolahnya dahulu. Tapi banyak juga orang yang selalu ingin menyajikan yang terbaik untuk orang yang dicintainya. Lantaran, memasak yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan orang tercinta. 



Apakah anda seorang penikmat ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce?. Asal kamu tahu, ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce merupakan hidangan khas di Nusantara yang saat ini digemari oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Anda dapat membuat ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce sendiri di rumahmu dan boleh dijadikan makanan kesenanganmu di akhir pekanmu.

Anda tak perlu bingung jika kamu ingin memakan ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce, sebab ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce tidak sukar untuk didapatkan dan juga kita pun dapat memasaknya sendiri di tempatmu. ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce boleh dimasak lewat beraneka cara. Kini ada banyak cara modern yang menjadikan ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce semakin lezat.

Resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce pun mudah sekali untuk dibikin, lho. Kamu jangan ribet-ribet untuk membeli ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce, lantaran Kalian dapat menghidangkan ditempatmu. Bagi Anda yang mau menyajikannya, berikut cara untuk menyajikan ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce yang nikamat yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Paha Crispy Pedas Asam Lemon / Spicy &amp; Lemon Sauce:

1. Ambil 750 gr ayam (bag paha, blh ganti dgn wings / bag sesuai selera)
1. Ambil  Bahan marinasi:
1. Gunakan 3 siung bawang putih (parut)
1. Ambil 1/2 sdm kecap asin / garam
1. Ambil 1 sdt perasan lemon
1. Ambil 1 sdt lada bubuk
1. Siapkan  Tepung crispy:
1. Sediakan 8 sdm tepung terigu
1. Siapkan 3 sdm tepung maizena
1. Ambil 1/2 sdt garam
1. Sediakan  Bumbu saus:
1. Ambil 5 buah cabe merah keriting (cincang kasar)
1. Siapkan Sesuai selera cabe rawit (cincang kasar)
1. Sediakan 1 siung bawang bombay (ukuran besar, potong2 kecil)
1. Sediakan 5 sdm saus tomat / 2 buah tomat (haluskan dgn sedikit air)
1. Ambil 1,5 sdm saus tiram
1. Gunakan 1 sdm saus hot lava (optional)
1. Gunakan 1 sdm perasan jeruk lemon
1. Siapkan Sedikit zest jeruk lemon
1. Sediakan 1 sdm gula
1. Gunakan Secukupnya garam
1. Siapkan Secukupnya minyak
1. Gunakan Sedikit air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Paha Crispy Pedas Asam Lemon / Spicy &amp; Lemon Sauce:

1. Campurkan ayam dgn seluruh bahan2 marinasi, marinasi ayam min 20 menit.
1. Campurkan semua bahan tepung crispy, baluri ayam dgn tepung hingga rata (terus bolak balik), goreng ayam hingga matang &amp; kecoklatan, tiriskan
1. Tumis bawang bombay, cabe keriting &amp; cabe rawit hingga wangi. Masukkan seluruh sisa bahan saus. Aduk2 hingga mengental.
1. Masukkan ayam satu persatu, sambil diaduk hingga ayam terbaluti saus. Sajikan.. happy cooking! 😊




Ternyata cara buat ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce yang nikamt tidak rumit ini gampang sekali ya! Anda Semua bisa mencobanya. Cara Membuat ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce Sesuai sekali untuk kamu yang baru akan belajar memasak atau juga untuk kamu yang telah pandai dalam memasak.

Tertarik untuk mencoba buat resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce mantab simple ini? Kalau kalian ingin, yuk kita segera buruan siapkan peralatan dan bahannya, lantas bikin deh Resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce yang nikmat dan tidak rumit ini. Sangat gampang kan. 

Maka dari itu, ketimbang anda diam saja, hayo kita langsung bikin resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce ini. Dijamin anda tak akan menyesal sudah buat resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce mantab tidak rumit ini! Selamat berkreasi dengan resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce enak simple ini di tempat tinggal kalian masing-masing,oke!.

