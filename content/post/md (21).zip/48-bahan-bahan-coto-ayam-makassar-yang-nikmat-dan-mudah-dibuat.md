---
description: "Bahan-bahan Coto Ayam Makassar yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Coto Ayam Makassar yang nikmat dan Mudah Dibuat"
slug: 48-bahan-bahan-coto-ayam-makassar-yang-nikmat-dan-mudah-dibuat
date: 2021-07-05T04:46:39.369Z
image: https://img-global.cpcdn.com/recipes/ab97aff97f6a1565/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab97aff97f6a1565/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab97aff97f6a1565/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Leo Ball
ratingvalue: 3.3
reviewcount: 15
recipeingredient:
- "250 gr dada ayam tanpa tulang"
- "100 gr kacang tanah goreng haluskan"
- " Air cucian beras"
- "3 lbr daun jeruk"
- "2 lbr daun salam"
- "1 ruas lengkuas geprek"
- "1 ruas kayu manis"
- "2 batang sereh ambil putihnya geprek"
- "Secukupnya garam kaldu bubukgula"
- " Bumbu Halus "
- "5 butir bawang merah"
- "3 siung bawang putih"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 sdt ketumbar sangrai sebentar"
- "1/2 sdt merica"
- "2 butir kemiri sangrai"
- "1/2 sdt pala bubuk"
- " Pelengkap "
- " Bihun Rebus"
- "Irisan Seledri dan daun bawang"
- " Bawang merah goreng"
- " Sambal cabe rawit"
- " Jeruk nipis"
- " Lontong bisa pake nasi jg opsional"
recipeinstructions:
- "Haluskan bumbu halus, lalu tumis bersama sereh, daun salam, daun jeruk, kayu manis dan kacang tanah yg sudah dihaluskan sampai harum dan terlihat mengering kecokelatan. Sisihkan sebentar."
- "Rebus ayam, lalu tiriskan. Goreng sebentar suwir². Sisihkan. Tuang tumisan tadi ke air rebusan ayam. Beri garam, gula, kaldu bubuk. Tes rasa. Masak sampai mendidih. Matikan kompor. Ambil mangkok saji."
- "Penyajian : tata potongan lontong/nasi, lalu bihun, ayam suwir, irisan daun bawang, bawang goreng dan seledri, lalu siram dgn kuah coto. Sajikan bersama sambal cabe rawit dan perasan jeruk nipis."
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 118 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Lunch

---


![Coto Ayam Makassar](https://img-global.cpcdn.com/recipes/ab97aff97f6a1565/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Andai anda seorang yang hobi masak, menyajikan hidangan sedap kepada orang tercinta merupakan hal yang membahagiakan bagi kita sendiri. Peran seorang istri bukan hanya menjaga rumah saja, tetapi kamu pun wajib menyediakan keperluan gizi terpenuhi dan panganan yang dikonsumsi anak-anak harus menggugah selera.

Di masa  saat ini, kalian sebenarnya bisa memesan hidangan praktis walaupun tidak harus ribet mengolahnya dulu. Tapi banyak juga lho orang yang memang mau menghidangkan yang terenak untuk keluarganya. Sebab, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai selera orang tercinta. 



Apakah anda salah satu penyuka coto ayam makassar?. Asal kamu tahu, coto ayam makassar adalah sajian khas di Nusantara yang kini digemari oleh kebanyakan orang di hampir setiap wilayah di Nusantara. Kamu dapat membuat coto ayam makassar sendiri di rumah dan pasti jadi makanan favorit di hari liburmu.

Anda tidak perlu bingung jika kamu ingin menyantap coto ayam makassar, lantaran coto ayam makassar tidak sukar untuk dicari dan juga kamu pun dapat menghidangkannya sendiri di tempatmu. coto ayam makassar dapat diolah lewat bermacam cara. Saat ini telah banyak banget cara kekinian yang membuat coto ayam makassar semakin lebih enak.

Resep coto ayam makassar juga sangat mudah dibikin, lho. Kamu tidak usah ribet-ribet untuk memesan coto ayam makassar, tetapi Kalian mampu menghidangkan di rumah sendiri. Bagi Anda yang ingin menyajikannya, berikut ini resep untuk membuat coto ayam makassar yang lezat yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Coto Ayam Makassar:

1. Sediakan 250 gr dada ayam tanpa tulang
1. Gunakan 100 gr kacang tanah, goreng, haluskan
1. Sediakan  Air cucian beras
1. Siapkan 3 lbr daun jeruk
1. Sediakan 2 lbr daun salam
1. Gunakan 1 ruas lengkuas, geprek
1. Gunakan 1 ruas kayu manis
1. Gunakan 2 batang sereh, ambil putihnya, geprek
1. Ambil Secukupnya garam, kaldu bubuk,gula
1. Siapkan  Bumbu Halus :
1. Siapkan 5 butir bawang merah
1. Ambil 3 siung bawang putih
1. Gunakan 1 ruas jahe
1. Gunakan 1 ruas lengkuas
1. Siapkan 1 sdt ketumbar, sangrai sebentar
1. Sediakan 1/2 sdt merica
1. Gunakan 2 butir kemiri sangrai
1. Gunakan 1/2 sdt pala bubuk
1. Siapkan  Pelengkap :
1. Sediakan  Bihun Rebus
1. Sediakan Irisan Seledri dan daun bawang
1. Siapkan  Bawang merah goreng
1. Sediakan  Sambal cabe rawit
1. Siapkan  Jeruk nipis
1. Ambil  Lontong (bisa pake nasi jg, opsional)




<!--inarticleads2-->

##### Cara menyiapkan Coto Ayam Makassar:

1. Haluskan bumbu halus, lalu tumis bersama sereh, daun salam, daun jeruk, kayu manis dan kacang tanah yg sudah dihaluskan sampai harum dan terlihat mengering kecokelatan. Sisihkan sebentar.
1. Rebus ayam, lalu tiriskan. Goreng sebentar suwir². Sisihkan. Tuang tumisan tadi ke air rebusan ayam. Beri garam, gula, kaldu bubuk. Tes rasa. Masak sampai mendidih. Matikan kompor. Ambil mangkok saji.
1. Penyajian : tata potongan lontong/nasi, lalu bihun, ayam suwir, irisan daun bawang, bawang goreng dan seledri, lalu siram dgn kuah coto. Sajikan bersama sambal cabe rawit dan perasan jeruk nipis.




Ternyata resep coto ayam makassar yang nikamt tidak rumit ini enteng sekali ya! Kita semua mampu memasaknya. Cara Membuat coto ayam makassar Cocok sekali untuk kita yang baru akan belajar memasak ataupun juga bagi kamu yang sudah jago dalam memasak.

Tertarik untuk mencoba buat resep coto ayam makassar nikmat tidak ribet ini? Kalau kalian mau, ayo kamu segera siapin peralatan dan bahannya, kemudian bikin deh Resep coto ayam makassar yang enak dan tidak rumit ini. Sungguh mudah kan. 

Maka, daripada anda berfikir lama-lama, yuk kita langsung saja bikin resep coto ayam makassar ini. Pasti kalian tak akan nyesel membuat resep coto ayam makassar lezat simple ini! Selamat berkreasi dengan resep coto ayam makassar lezat tidak rumit ini di rumah kalian sendiri,oke!.

