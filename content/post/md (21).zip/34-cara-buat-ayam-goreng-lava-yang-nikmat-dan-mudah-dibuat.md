---
description: "Cara buat Ayam Goreng Lava yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam Goreng Lava yang nikmat dan Mudah Dibuat"
slug: 34-cara-buat-ayam-goreng-lava-yang-nikmat-dan-mudah-dibuat
date: 2021-02-09T22:14:09.104Z
image: https://img-global.cpcdn.com/recipes/36a28b77617f4150/680x482cq70/ayam-goreng-lava-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/36a28b77617f4150/680x482cq70/ayam-goreng-lava-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/36a28b77617f4150/680x482cq70/ayam-goreng-lava-foto-resep-utama.jpg
author: Nelle Kelley
ratingvalue: 4.5
reviewcount: 15
recipeingredient:
- " Bahan adonan ayam "
- "200 gr daging ayam blender"
- "1 buah wortel parut"
- "2 helai daun bawang iris"
- "2 sdm bawang putih halus"
- "Sejumput garam"
- " Bahan lava "
- "3 sdm mayones"
- "3 sdm saos tomat  saos sambal"
- " Bahan celup "
- "1 sachet tepung bumbu sajiku"
- "2 butir telur"
- "Secukupnya tepung panir  tepung roti"
recipeinstructions:
- "Campurkan semua bahan adonan ayam hingga tercampur rata."
- "Di wadah lain campurkan mayones dan saus tomat, aduk rata"
- "Bagi adonan ayam menjadi 20 gr, lalu bulat&#34;kan kemudian pipihkan, dan beri saos lava, bulat&#34;kan kembali lakukan hingga adonan habis."
- "Siapkan adonan celup, kocok telur dalam mangkok, masukkan tepung bumbu dalam mangkok lain, masukkan juga tepung panir dalam mangkok lain."
- "Lalu masukkan adoan ayam kedalam tepung bumbu hingga semua adonan tertutup tepung, angkat masukkan dalam kocokan telur, angkat masukkan dalam tepung panir, sisihkan, lakukan hingga semua adonan habis"
- "Masukkan semua adonan kedalam freezer kurang lebih selma 15 menit, lalu goreng dalam minyak panas menggunakan api kecil, hingga berwarna kuning keemasan, angkat dan sajikan."
categories:
- Resep
tags:
- ayam
- goreng
- lava

katakunci: ayam goreng lava 
nutrition: 156 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Goreng Lava](https://img-global.cpcdn.com/recipes/36a28b77617f4150/680x482cq70/ayam-goreng-lava-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan santapan mantab kepada keluarga tercinta adalah hal yang menyenangkan bagi anda sendiri. Kewajiban seorang istri Tidak hanya menjaga rumah saja, tetapi kamu pun wajib menyediakan kebutuhan gizi terpenuhi dan hidangan yang dimakan anak-anak harus sedap.

Di era  saat ini, kalian sebenarnya bisa mengorder panganan praktis walaupun tanpa harus repot memasaknya dulu. Namun ada juga lho mereka yang memang mau memberikan hidangan yang terlezat bagi orang yang dicintainya. Lantaran, menyajikan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga. 



Apakah anda merupakan seorang penikmat ayam goreng lava?. Tahukah kamu, ayam goreng lava adalah hidangan khas di Nusantara yang kini disenangi oleh setiap orang dari berbagai tempat di Nusantara. Anda bisa membuat ayam goreng lava sendiri di rumah dan boleh dijadikan makanan favoritmu di akhir pekan.

Kita jangan bingung untuk mendapatkan ayam goreng lava, sebab ayam goreng lava gampang untuk ditemukan dan juga anda pun boleh menghidangkannya sendiri di rumah. ayam goreng lava boleh diolah lewat beragam cara. Kini ada banyak sekali cara kekinian yang menjadikan ayam goreng lava semakin enak.

Resep ayam goreng lava juga sangat mudah dihidangkan, lho. Kamu tidak usah ribet-ribet untuk membeli ayam goreng lava, tetapi Kita mampu menyajikan di rumahmu. Untuk Anda yang akan menghidangkannya, dibawah ini merupakan cara untuk menyajikan ayam goreng lava yang mantab yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Goreng Lava:

1. Gunakan  Bahan adonan ayam :
1. Siapkan 200 gr daging ayam blender
1. Siapkan 1 buah wortel parut
1. Gunakan 2 helai daun bawang iris&#34;
1. Gunakan 2 sdm bawang putih halus
1. Gunakan Sejumput garam
1. Gunakan  Bahan lava :
1. Sediakan 3 sdm mayones
1. Gunakan 3 sdm saos tomat / saos sambal
1. Gunakan  Bahan celup :
1. Ambil 1 sachet tepung bumbu sajiku
1. Sediakan 2 butir telur
1. Siapkan Secukupnya tepung panir / tepung roti




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Lava:

1. Campurkan semua bahan adonan ayam hingga tercampur rata.
1. Di wadah lain campurkan mayones dan saus tomat, aduk rata
1. Bagi adonan ayam menjadi 20 gr, lalu bulat&#34;kan kemudian pipihkan, dan beri saos lava, bulat&#34;kan kembali lakukan hingga adonan habis.
1. Siapkan adonan celup, kocok telur dalam mangkok, masukkan tepung bumbu dalam mangkok lain, masukkan juga tepung panir dalam mangkok lain.
1. Lalu masukkan adoan ayam kedalam tepung bumbu hingga semua adonan tertutup tepung, angkat masukkan dalam kocokan telur, angkat masukkan dalam tepung panir, sisihkan, lakukan hingga semua adonan habis
1. Masukkan semua adonan kedalam freezer kurang lebih selma 15 menit, lalu goreng dalam minyak panas menggunakan api kecil, hingga berwarna kuning keemasan, angkat dan sajikan.




Ternyata resep ayam goreng lava yang mantab sederhana ini enteng banget ya! Kita semua mampu membuatnya. Resep ayam goreng lava Sangat cocok banget buat kita yang baru mau belajar memasak maupun juga untuk kalian yang telah jago memasak.

Apakah kamu ingin mulai mencoba membuat resep ayam goreng lava mantab sederhana ini? Kalau kalian ingin, mending kamu segera siapin alat-alat dan bahan-bahannya, lalu bikin deh Resep ayam goreng lava yang mantab dan simple ini. Benar-benar gampang kan. 

Jadi, ketimbang kalian berlama-lama, ayo kita langsung saja hidangkan resep ayam goreng lava ini. Pasti kamu gak akan menyesal membuat resep ayam goreng lava mantab tidak rumit ini! Selamat berkreasi dengan resep ayam goreng lava mantab tidak rumit ini di rumah kalian sendiri,oke!.

