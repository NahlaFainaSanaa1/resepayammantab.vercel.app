---
description: "Resep Soto Ayam Kampung yang enak Untuk Jualan"
title: "Resep Soto Ayam Kampung yang enak Untuk Jualan"
slug: 251-resep-soto-ayam-kampung-yang-enak-untuk-jualan
date: 2021-03-09T08:29:19.761Z
image: https://img-global.cpcdn.com/recipes/200b823360563b58/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/200b823360563b58/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/200b823360563b58/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
author: Mike Delgado
ratingvalue: 4.2
reviewcount: 10
recipeingredient:
- "1 ekor ayam kampung klo ta ada boleh ganti ayam pejantan"
- " Bumbu"
- "5 siung bawang putih"
- "8 siung bawang merah"
- "1/4 sdt jinten"
- "1/2 sdt lada"
- "1 sdt ketumbar"
- "2 cm kunyit"
- "2 cm jahe"
- "4 cm laos"
- "2 batang serai"
- "4 lb daun jeruk"
- "5 bt kemiri"
- "1,5-2 sdm garam"
- "1 sdt gula"
- "1 sdt kaldu jamur boleh skip"
- " Pelengkap"
- " Telur rebus"
- " Mie soun"
- " Kubis iris halus"
- "1 cm Daun bawang prei potong2"
- " Seledri iris halus"
- " Koya krupuk udang"
- " Jeruk nipis"
- " Sambal"
recipeinstructions:
- "Potong ayam jadi 4, rebus dg 3L air (sy rebus 30 menit dg api kecil hingga agak empuk)"
- "Siapkan bumbu Bawang putih, bawang merah, jinten, ketumbar, lada, kunyit, kemiri dihaluskan, tambahkan jahe, laos n daun serai geprek serta daun jeruk buang tulang daunnya, tumis dg 2 sdm minyak sayur"
- "Masukkan bumbu yg uda ditumis, garam n gula. Rebus lg 30 menit koreksi rasa. Jika suka asin bs tambah garam. (Cek uda empuk ato blm, tergantung klo ayam tua butuh waktu lbh lama proses rebusnya). Masukkan daun bawang prei n kaldu jamur 5 menit sblm api dimatikan"
- "Sajikan soto ayam dg pelengkap soun, kubis, telor, koyah, daun seledri, jeruk nipis, sambal"
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam Kampung](https://img-global.cpcdn.com/recipes/200b823360563b58/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyajikan olahan lezat buat keluarga tercinta merupakan suatu hal yang menyenangkan bagi kita sendiri. Kewajiban seorang ibu Tidak sekadar menjaga rumah saja, tetapi kamu pun wajib memastikan keperluan nutrisi terpenuhi dan olahan yang disantap orang tercinta harus lezat.

Di masa  sekarang, kamu sebenarnya dapat mengorder olahan siap saji meski tanpa harus capek memasaknya terlebih dahulu. Tapi banyak juga mereka yang memang ingin menghidangkan yang terenak bagi orang yang dicintainya. Karena, menyajikan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga. 



Apakah anda merupakan salah satu penikmat soto ayam kampung?. Tahukah kamu, soto ayam kampung adalah sajian khas di Nusantara yang kini digemari oleh kebanyakan orang di hampir setiap daerah di Indonesia. Kita dapat menyajikan soto ayam kampung hasil sendiri di rumah dan boleh jadi makanan kesenanganmu di hari liburmu.

Anda tidak usah bingung untuk memakan soto ayam kampung, lantaran soto ayam kampung mudah untuk didapatkan dan juga kita pun dapat mengolahnya sendiri di rumah. soto ayam kampung boleh diolah memalui beraneka cara. Kini pun sudah banyak resep modern yang membuat soto ayam kampung semakin lebih nikmat.

Resep soto ayam kampung juga gampang sekali untuk dibuat, lho. Kamu jangan capek-capek untuk memesan soto ayam kampung, karena Kalian bisa membuatnya di rumah sendiri. Untuk Kita yang ingin menyajikannya, di bawah ini adalah cara menyajikan soto ayam kampung yang nikamat yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Kampung:

1. Sediakan 1 ekor ayam kampung (klo ta ada boleh ganti ayam pejantan)
1. Siapkan  Bumbu:
1. Sediakan 5 siung bawang putih
1. Siapkan 8 siung bawang merah
1. Siapkan 1/4 sdt jinten
1. Siapkan 1/2 sdt lada
1. Sediakan 1 sdt ketumbar
1. Gunakan 2 cm kunyit
1. Gunakan 2 cm jahe
1. Ambil 4 cm laos
1. Gunakan 2 batang serai
1. Siapkan 4 lb daun jeruk
1. Siapkan 5 bt kemiri
1. Gunakan 1,5-2 sdm garam
1. Sediakan 1 sdt gula
1. Gunakan 1 sdt kaldu jamur (boleh skip)
1. Siapkan  Pelengkap
1. Siapkan  Telur rebus
1. Ambil  Mie soun
1. Ambil  Kubis iris halus
1. Ambil 1 cm Daun bawang prei potong2
1. Sediakan  Seledri iris halus
1. Ambil  Koya krupuk udang
1. Siapkan  Jeruk nipis
1. Gunakan  Sambal




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Kampung:

1. Potong ayam jadi 4, rebus dg 3L air (sy rebus 30 menit dg api kecil hingga agak empuk)
1. Siapkan bumbu - Bawang putih, bawang merah, jinten, ketumbar, lada, kunyit, kemiri dihaluskan, tambahkan jahe, laos n daun serai geprek serta daun jeruk buang tulang daunnya, tumis dg 2 sdm minyak sayur
1. Masukkan bumbu yg uda ditumis, garam n gula. Rebus lg 30 menit koreksi rasa. Jika suka asin bs tambah garam. - (Cek uda empuk ato blm, tergantung klo ayam tua butuh waktu lbh lama proses rebusnya). Masukkan daun bawang prei n kaldu jamur 5 menit sblm api dimatikan
1. Sajikan soto ayam dg pelengkap soun, kubis, telor, koyah, daun seledri, jeruk nipis, sambal




Ternyata cara buat soto ayam kampung yang enak tidak ribet ini gampang sekali ya! Anda Semua dapat mencobanya. Cara buat soto ayam kampung Sangat cocok sekali buat kalian yang baru mau belajar memasak atau juga untuk kalian yang telah jago memasak.

Tertarik untuk mulai mencoba membikin resep soto ayam kampung lezat sederhana ini? Kalau tertarik, ayo kalian segera siapkan alat dan bahannya, lalu bikin deh Resep soto ayam kampung yang nikmat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Oleh karena itu, daripada kita berfikir lama-lama, maka kita langsung saja buat resep soto ayam kampung ini. Pasti kamu gak akan nyesel sudah membuat resep soto ayam kampung mantab tidak rumit ini! Selamat mencoba dengan resep soto ayam kampung lezat sederhana ini di tempat tinggal masing-masing,ya!.

