---
description: "Cara memasak Ampela ayam bumbu manis asam pedas yang lezat dan Mudah Dibuat"
title: "Cara memasak Ampela ayam bumbu manis asam pedas yang lezat dan Mudah Dibuat"
slug: 158-cara-memasak-ampela-ayam-bumbu-manis-asam-pedas-yang-lezat-dan-mudah-dibuat
date: 2021-07-01T00:49:39.277Z
image: https://img-global.cpcdn.com/recipes/2a2fcea6764c12a4/680x482cq70/ampela-ayam-bumbu-manis-asam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2a2fcea6764c12a4/680x482cq70/ampela-ayam-bumbu-manis-asam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2a2fcea6764c12a4/680x482cq70/ampela-ayam-bumbu-manis-asam-pedas-foto-resep-utama.jpg
author: Chase Thornton
ratingvalue: 4
reviewcount: 8
recipeingredient:
- "10 bji ampela ungkep"
- "4 ptong ayam ungkep"
- " Masako"
- " Garam"
- " Merica"
- "2 sdm air asam jawa"
- " Kecap"
- " Gula merah parut"
- " Daun bawang"
- " Bumbu halus"
- "4 bawang merah"
- "3 bawang putih"
- "1/2 ruas jahe"
- "1/2 ruas kunyit"
- "2 cabai keriting"
recipeinstructions:
- "Goreng ampela dan ayam yg sudah di ungkep terlebih dahulu. Setelah matang lalu tiriskan"
- "Buat bumbu. Ulek semua bahan (bumbu halus) sampai halus lalu tumis sampai wangi."
- "Masukkan 2 sdm air asam jawa,kecap dan parutan gula merahnya."
- "Jgn lupa masukkan garam,merica,masako kedalam bumbu lalu masukkan ampela dan ayam yg sdh digoreng tadi lalu aduk sampai tercampur semua bumbunya"
- "Icip rasanya jika sudah pas masukkan irisan daun bawang. Lalu sajikan"
categories:
- Resep
tags:
- ampela
- ayam
- bumbu

katakunci: ampela ayam bumbu 
nutrition: 221 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dessert

---


![Ampela ayam bumbu manis asam pedas](https://img-global.cpcdn.com/recipes/2a2fcea6764c12a4/680x482cq70/ampela-ayam-bumbu-manis-asam-pedas-foto-resep-utama.jpg)

Selaku seorang ibu, menyajikan panganan menggugah selera kepada orang tercinta adalah suatu hal yang memuaskan untuk kita sendiri. Kewajiban seorang ibu Tidak sekedar menjaga rumah saja, tapi kamu pun harus menyediakan keperluan gizi tercukupi dan juga panganan yang dimakan keluarga tercinta mesti lezat.

Di era  saat ini, kalian sebenarnya dapat memesan panganan praktis meski tanpa harus susah mengolahnya lebih dulu. Tetapi ada juga orang yang memang ingin menghidangkan yang terlezat bagi keluarganya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga tercinta. 



Mungkinkah kamu seorang penyuka ampela ayam bumbu manis asam pedas?. Asal kamu tahu, ampela ayam bumbu manis asam pedas adalah makanan khas di Indonesia yang sekarang disenangi oleh orang-orang di berbagai daerah di Nusantara. Kalian bisa menghidangkan ampela ayam bumbu manis asam pedas buatan sendiri di rumahmu dan boleh jadi hidangan favoritmu di akhir pekanmu.

Kita jangan bingung jika kamu ingin memakan ampela ayam bumbu manis asam pedas, karena ampela ayam bumbu manis asam pedas sangat mudah untuk didapatkan dan kalian pun boleh memasaknya sendiri di tempatmu. ampela ayam bumbu manis asam pedas bisa diolah lewat beraneka cara. Kini sudah banyak cara modern yang menjadikan ampela ayam bumbu manis asam pedas semakin mantap.

Resep ampela ayam bumbu manis asam pedas juga mudah untuk dibuat, lho. Kamu tidak usah capek-capek untuk memesan ampela ayam bumbu manis asam pedas, tetapi Anda dapat menyiapkan di rumah sendiri. Bagi Anda yang ingin menyajikannya, dibawah ini merupakan cara untuk membuat ampela ayam bumbu manis asam pedas yang lezat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ampela ayam bumbu manis asam pedas:

1. Sediakan 10 bji ampela ungkep
1. Sediakan 4 ptong ayam ungkep
1. Ambil  Masako
1. Ambil  Garam
1. Gunakan  Merica
1. Ambil 2 sdm air asam jawa
1. Ambil  Kecap
1. Sediakan  Gula merah parut
1. Siapkan  Daun bawang
1. Gunakan  Bumbu halus
1. Gunakan 4 bawang merah
1. Siapkan 3 bawang putih
1. Ambil 1/2 ruas jahe
1. Sediakan 1/2 ruas kunyit
1. Sediakan 2 cabai keriting




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ampela ayam bumbu manis asam pedas:

1. Goreng ampela dan ayam yg sudah di ungkep terlebih dahulu. Setelah matang lalu tiriskan
1. Buat bumbu. Ulek semua bahan (bumbu halus) sampai halus lalu tumis sampai wangi.
1. Masukkan 2 sdm air asam jawa,kecap dan parutan gula merahnya.
1. Jgn lupa masukkan garam,merica,masako kedalam bumbu lalu masukkan ampela dan ayam yg sdh digoreng tadi lalu aduk sampai tercampur semua bumbunya
1. Icip rasanya jika sudah pas masukkan irisan daun bawang. Lalu sajikan




Ternyata cara membuat ampela ayam bumbu manis asam pedas yang lezat tidak rumit ini mudah sekali ya! Kita semua bisa membuatnya. Cara Membuat ampela ayam bumbu manis asam pedas Sangat cocok banget buat kita yang baru belajar memasak ataupun bagi kamu yang telah jago dalam memasak.

Tertarik untuk mulai mencoba buat resep ampela ayam bumbu manis asam pedas nikmat tidak rumit ini? Kalau kalian tertarik, yuk kita segera buruan menyiapkan alat-alat dan bahan-bahannya, lantas buat deh Resep ampela ayam bumbu manis asam pedas yang mantab dan tidak ribet ini. Sangat mudah kan. 

Maka, ketimbang kita diam saja, maka kita langsung saja buat resep ampela ayam bumbu manis asam pedas ini. Dijamin kamu gak akan nyesel sudah buat resep ampela ayam bumbu manis asam pedas enak tidak ribet ini! Selamat berkreasi dengan resep ampela ayam bumbu manis asam pedas enak simple ini di tempat tinggal kalian masing-masing,ya!.

