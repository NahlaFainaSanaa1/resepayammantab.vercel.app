---
description: "Cara membuat Soto Ayam Kampung#PekanPosbarSoto Sederhana dan Mudah Dibuat"
title: "Cara membuat Soto Ayam Kampung#PekanPosbarSoto Sederhana dan Mudah Dibuat"
slug: 257-cara-membuat-soto-ayam-kampungpekanposbarsoto-sederhana-dan-mudah-dibuat
date: 2021-03-15T15:26:12.606Z
image: https://img-global.cpcdn.com/recipes/bd48d401b899ff55/680x482cq70/soto-ayam-kampungpekanposbarsoto-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bd48d401b899ff55/680x482cq70/soto-ayam-kampungpekanposbarsoto-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bd48d401b899ff55/680x482cq70/soto-ayam-kampungpekanposbarsoto-foto-resep-utama.jpg
author: Mable Hunter
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "1 ekor ayam kampung"
- "1 sendok teh Merica bubuk"
- "2 siung Bawang putih halus"
- "10 butir bawang merah"
- "1 ruas Jahe halus"
- "2-3 lembar Daun jeruk purut"
- "5 buah Kunyit haluskan"
- "5 batang serai digeprek"
- "500 gram kerupuk udang dihaluskan Sebagai bubuk koya"
- " Sabel Cabe"
- "500 gram cabe rawit"
- "2 butir bawang putih"
- "2 butir bawang merah"
- "secukupnya Penyedap rasa"
- "secukupnya Garam"
- "1/2 sendok makan Gula"
- " Tambahan lain"
- "500 gram soun"
- "500 gram Nasi putih"
- "500 gram Tomat Potong sesuai selera"
- "500 kol dipotong halus cuci bersihrebus 3 menit dalam air mendidih angkat tiriskan"
- "500 gram Tauge dibersihkan cuci rebus dalam air mendidih selama 3 menit angkat tiriskan"
- "1-2 Jeruklemonjeruk nipis"
- "500 gram Bawang goreng"
- " Rp 2000 daun bawang cuci bersih iris halus"
- "8 butir Asam kandis"
- "6 butir telur rebus kupas kulitnya belah dua opsional"
recipeinstructions:
- "Bersihkan ayam, cuci bersih bersih, potong 4 bagian, rebus dalam panci besar, air 2000 ml"
- "Masukan semua bumbu halus (jahe, kunyit, bawang merah, bawang putih, merica, daun jeruk 3 lembar, serai geprek 5 batang, asam kandis 8 biji) kedalam panci rebusan isi ayam, masak hingga ayam matang, lembut, dan empuk"
- "Jika air sudah mulai sedikit tambah air lagi secukupnya, kira kira sebanyak yg kita inginkan."
- "Setelah ayam lembut dan empuk, masukan garam dan penyedap rasa secukupnya, sampai terasa pas di lidah ya"
- "Angkat ayam yg sudah empuk dan lembut, teruskan. Supir supir daging nya, sisihkan dalam wadah tupperware atau wadah kaca."
- "Tulang tulang dari sisa ayam yg disuwir dimasukkan ke dalam kuah di panci, agar kaldu soto nya berasa banget, masak kuah soto nya tersebut sampai mendidih. (waktu suwir ayam yg sudah masak menggunakan sarung tangan plastik atau karet ya, biar enak dilihat)"
- "Sekarang kita buat sambil cabe nya, rebus cabe, bawang merah 2 butir, bawang putih 2 butir, setelah direbus mari kita dinginkan, setelah itu blender dengan ditambah garam, penyedap rasa, dan gula 1/2 sendok makan. Tambah cuka 1/2 sendok makan, atau air lemon/jeruk limo peras 1 sendok makan. Tara sambil nya jadi deh"
- "Siapkan soun dengan di rebus dalam air mendidih sampai matang, terus tiriskan, cuci dengan air es atau air galon."
- "Sajikan, soto bisa dinikmati dengan soun atau nasi putih"
- "Siapkan mangkuk, isi dg soun, kol, tauge, tomat, ayam suwir, taburi serbuk koya, bawang goreng, daun bawang, kemudian siram dg kuah soto yg masih mendidih, Taruh 1/2 potong telur rebus, sedap dimakan pas lagi cuaca dingin atau saat hujan. Tambahkan sepiring nasi kalau suka, tambahkan sampel cabe, kecap."
categories:
- Resep
tags:
- soto
- ayam
- kampungpekanposbarsoto

katakunci: soto ayam kampungpekanposbarsoto 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Soto Ayam Kampung#PekanPosbarSoto](https://img-global.cpcdn.com/recipes/bd48d401b899ff55/680x482cq70/soto-ayam-kampungpekanposbarsoto-foto-resep-utama.jpg)

Apabila kamu seorang ibu, mempersiapkan olahan enak kepada keluarga tercinta adalah hal yang mengasyikan untuk anda sendiri. Tanggung jawab seorang ibu Tidak cuman mengurus rumah saja, namun kamu pun wajib menyediakan keperluan gizi terpenuhi dan juga hidangan yang disantap orang tercinta wajib enak.

Di zaman  sekarang, kita sebenarnya dapat membeli panganan siap saji walaupun tanpa harus ribet memasaknya lebih dulu. Tetapi banyak juga lho mereka yang selalu ingin memberikan yang terbaik untuk orang yang dicintainya. Lantaran, memasak yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan keluarga tercinta. 



Apakah kamu salah satu penggemar soto ayam kampung#pekanposbarsoto?. Tahukah kamu, soto ayam kampung#pekanposbarsoto merupakan sajian khas di Nusantara yang sekarang disukai oleh banyak orang di berbagai wilayah di Nusantara. Kita bisa membuat soto ayam kampung#pekanposbarsoto sendiri di rumahmu dan boleh jadi santapan kesenanganmu di akhir pekan.

Kalian tidak perlu bingung jika kamu ingin menyantap soto ayam kampung#pekanposbarsoto, lantaran soto ayam kampung#pekanposbarsoto tidak sukar untuk dicari dan juga anda pun bisa memasaknya sendiri di tempatmu. soto ayam kampung#pekanposbarsoto bisa dimasak lewat berbagai cara. Sekarang telah banyak sekali cara kekinian yang menjadikan soto ayam kampung#pekanposbarsoto semakin lebih mantap.

Resep soto ayam kampung#pekanposbarsoto pun gampang sekali dibikin, lho. Kita tidak perlu repot-repot untuk memesan soto ayam kampung#pekanposbarsoto, tetapi Kita mampu menyajikan sendiri di rumah. Bagi Kita yang ingin menghidangkannya, inilah resep untuk membuat soto ayam kampung#pekanposbarsoto yang mantab yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Soto Ayam Kampung#PekanPosbarSoto:

1. Sediakan 1 ekor ayam kampung
1. Gunakan 1 sendok teh Merica bubuk
1. Siapkan 2 siung Bawang putih halus
1. Siapkan 10 butir bawang merah
1. Sediakan 1 ruas Jahe halus
1. Gunakan 2-3 lembar Daun jeruk purut
1. Ambil 5 buah Kunyit haluskan
1. Sediakan 5 batang serai digeprek
1. Siapkan 500 gram kerupuk udang dihaluskan Sebagai bubuk koya
1. Gunakan  Sabel Cabe
1. Gunakan 500 gram cabe rawit
1. Ambil 2 butir bawang putih
1. Sediakan 2 butir bawang merah
1. Sediakan secukupnya Penyedap rasa
1. Sediakan secukupnya Garam
1. Siapkan 1/2 sendok makan Gula
1. Siapkan  Tambahan lain
1. Sediakan 500 gram soun
1. Gunakan 500 gram Nasi putih
1. Sediakan 500 gram Tomat Potong sesuai selera
1. Gunakan 500 kol dipotong halus cuci bersih,rebus 3 menit dalam air mendidih angkat, tiriskan
1. Gunakan 500 gram Tauge, dibersihkan, cuci, rebus dalam air mendidih selama 3 menit, angkat tiriskan
1. Siapkan 1-2 Jeruk/lemon/jeruk nipis
1. Ambil 500 gram Bawang goreng
1. Sediakan  Rp 2.000 daun bawang, cuci bersih, iris halus
1. Ambil 8 butir Asam kandis
1. Gunakan 6 butir telur rebus, kupas kulitnya, belah dua (opsional)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Kampung#PekanPosbarSoto:

1. Bersihkan ayam, cuci bersih bersih, potong 4 bagian, rebus dalam panci besar, air 2000 ml
1. Masukan semua bumbu halus (jahe, kunyit, bawang merah, bawang putih, merica, daun jeruk 3 lembar, serai geprek 5 batang, asam kandis 8 biji) kedalam panci rebusan isi ayam, masak hingga ayam matang, lembut, dan empuk
1. Jika air sudah mulai sedikit tambah air lagi secukupnya, kira kira sebanyak yg kita inginkan.
1. Setelah ayam lembut dan empuk, masukan garam dan penyedap rasa secukupnya, sampai terasa pas di lidah ya
1. Angkat ayam yg sudah empuk dan lembut, teruskan. Supir supir daging nya, sisihkan dalam wadah tupperware atau wadah kaca.
1. Tulang tulang dari sisa ayam yg disuwir dimasukkan ke dalam kuah di panci, agar kaldu soto nya berasa banget, masak kuah soto nya tersebut sampai mendidih. (waktu suwir ayam yg sudah masak menggunakan sarung tangan plastik atau karet ya, biar enak dilihat)
1. Sekarang kita buat sambil cabe nya, rebus cabe, bawang merah 2 butir, bawang putih 2 butir, setelah direbus mari kita dinginkan, setelah itu blender dengan ditambah garam, penyedap rasa, dan gula 1/2 sendok makan. Tambah cuka 1/2 sendok makan, atau air lemon/jeruk limo peras 1 sendok makan. Tara sambil nya jadi deh
1. Siapkan soun dengan di rebus dalam air mendidih sampai matang, terus tiriskan, cuci dengan air es atau air galon.
1. Sajikan, soto bisa dinikmati dengan soun atau nasi putih
1. Siapkan mangkuk, isi dg soun, kol, tauge, tomat, ayam suwir, taburi serbuk koya, bawang goreng, daun bawang, kemudian siram dg kuah soto yg masih mendidih, Taruh 1/2 potong telur rebus, sedap dimakan pas lagi cuaca dingin atau saat hujan. Tambahkan sepiring nasi kalau suka, tambahkan sampel cabe, kecap.




Wah ternyata cara membuat soto ayam kampung#pekanposbarsoto yang enak sederhana ini gampang sekali ya! Kita semua dapat membuatnya. Cara buat soto ayam kampung#pekanposbarsoto Cocok banget untuk kita yang baru akan belajar memasak maupun juga bagi anda yang telah lihai memasak.

Tertarik untuk mulai mencoba bikin resep soto ayam kampung#pekanposbarsoto enak sederhana ini? Kalau anda mau, yuk kita segera buruan siapin peralatan dan bahan-bahannya, kemudian buat deh Resep soto ayam kampung#pekanposbarsoto yang enak dan simple ini. Betul-betul mudah kan. 

Maka, ketimbang kamu berlama-lama, ayo langsung aja hidangkan resep soto ayam kampung#pekanposbarsoto ini. Dijamin kalian tak akan nyesel sudah bikin resep soto ayam kampung#pekanposbarsoto nikmat tidak ribet ini! Selamat berkreasi dengan resep soto ayam kampung#pekanposbarsoto lezat tidak ribet ini di tempat tinggal kalian sendiri,ya!.

