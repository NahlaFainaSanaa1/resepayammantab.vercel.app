---
description: "Resep memasak 80. Ayam Bakar Wong Solo yang enak dan Mudah Dibuat"
title: "Resep memasak 80. Ayam Bakar Wong Solo yang enak dan Mudah Dibuat"
slug: 312-resep-memasak-80-ayam-bakar-wong-solo-yang-enak-dan-mudah-dibuat
date: 2021-01-14T09:33:10.424Z
image: https://img-global.cpcdn.com/recipes/28fb239a33dc281c/680x482cq70/80-ayam-bakar-wong-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/28fb239a33dc281c/680x482cq70/80-ayam-bakar-wong-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/28fb239a33dc281c/680x482cq70/80-ayam-bakar-wong-solo-foto-resep-utama.jpg
author: Maria Reyes
ratingvalue: 5
reviewcount: 8
recipeingredient:
- "1/2 kg ayam potong"
- "800 ml air"
- " Bumbu Halus untuk Ungkep"
- "8 lembar daun salam 4 lembar bentuk angka 8"
- "1 batang sereh geprek"
- "5 siung bawang putih haluskan"
- "2 ruas kunyit haluskan"
- "1 ruas jahe haluskan"
- "3 sdt ketumbar bubuk"
- "2,5 sdt garam"
- "1/2 sdt kaldu bubuk"
- " Bumbu Olesan"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "5 buah cabe merah besar buang isinya karena saya ga suka pedas"
- "3 sdm minyak goreng"
- "2,5 sdm gula jawa serut"
- "1 sdt garam"
- "60 ml air"
- " Tambahan utk olesan"
- "1 sdm margarin aku skip"
- "8 sdm kecap manis"
- "3 sdm air"
recipeinstructions:
- "Cuci bersih ayam. Sisihkan."
- "Campuran semua bumbu untuk ungkep ayam. Aduk merata. Masak sampai air susut supaya bumbu meresap. Jika sudah susut, matikan."
- "Sambil menunggu air rebusan ayam ungkepnya susut, kita buat bumbu olesan."
- "Haluskan bawang merah, bawang putih, cabe menggunakan copper atau blender bumbu. Masak dengan minyak, masukkan gula merah, garam &amp; air. Masak hingga matang &amp; mengental. Jika sudah matang, pindahkan ke mangkok."
- "Bumbu olesan di mangkok tambahkan kecap manis &amp; air."
- "Sebelum dibakar diatas teflon, olesi dengan margarin. Aku pakai minyak goreng sedikit saja. Lumuri ayam dengan bumbu olesan. Bakar sesuai selera. Aku sampai ada gosong2nya sedikit. Bisa diolesi lagi dengan kuas selama proses bakar."
- "Sajikan.."
categories:
- Resep
tags:
- 80
- ayam
- bakar

katakunci: 80 ayam bakar 
nutrition: 251 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dessert

---


![80. Ayam Bakar Wong Solo](https://img-global.cpcdn.com/recipes/28fb239a33dc281c/680x482cq70/80-ayam-bakar-wong-solo-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan masakan lezat kepada keluarga tercinta merupakan suatu hal yang menyenangkan bagi anda sendiri. Tugas seorang ibu Tidak cuma mengatur rumah saja, tetapi kamu juga wajib menyediakan keperluan gizi terpenuhi dan masakan yang dikonsumsi anak-anak wajib nikmat.

Di waktu  saat ini, kalian sebenarnya dapat membeli masakan yang sudah jadi meski tanpa harus ribet memasaknya lebih dulu. Namun ada juga lho mereka yang selalu ingin memberikan hidangan yang terbaik bagi keluarganya. Pasalnya, memasak yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai selera keluarga. 



Apakah kamu seorang penikmat 80. ayam bakar wong solo?. Asal kamu tahu, 80. ayam bakar wong solo merupakan sajian khas di Nusantara yang sekarang disukai oleh setiap orang di berbagai tempat di Indonesia. Kamu bisa memasak 80. ayam bakar wong solo sendiri di rumahmu dan boleh jadi camilan kegemaranmu di akhir pekan.

Anda tidak perlu bingung jika kamu ingin memakan 80. ayam bakar wong solo, karena 80. ayam bakar wong solo tidak sukar untuk didapatkan dan juga kita pun bisa memasaknya sendiri di tempatmu. 80. ayam bakar wong solo dapat dimasak dengan beraneka cara. Kini sudah banyak sekali cara kekinian yang membuat 80. ayam bakar wong solo semakin enak.

Resep 80. ayam bakar wong solo pun mudah dihidangkan, lho. Kamu jangan capek-capek untuk membeli 80. ayam bakar wong solo, lantaran Kamu mampu menyajikan ditempatmu. Bagi Kamu yang hendak menyajikannya, inilah resep membuat 80. ayam bakar wong solo yang lezat yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan 80. Ayam Bakar Wong Solo:

1. Sediakan 1/2 kg ayam potong
1. Sediakan 800 ml air
1. Gunakan  Bumbu Halus untuk Ungkep
1. Gunakan 8 lembar daun salam (4 lembar bentuk angka 8)
1. Gunakan 1 batang sereh, geprek
1. Ambil 5 siung bawang putih (haluskan)
1. Siapkan 2 ruas kunyit, haluskan
1. Ambil 1 ruas jahe, haluskan
1. Siapkan 3 sdt ketumbar bubuk
1. Siapkan 2,5 sdt garam
1. Gunakan 1/2 sdt kaldu bubuk
1. Ambil  Bumbu Olesan
1. Siapkan 3 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Ambil 5 buah cabe merah besar (buang isinya karena saya ga suka pedas)
1. Ambil 3 sdm minyak goreng
1. Sediakan 2,5 sdm gula jawa serut
1. Ambil 1 sdt garam
1. Siapkan 60 ml air
1. Ambil  Tambahan utk olesan
1. Gunakan 1 sdm margarin (aku skip)
1. Ambil 8 sdm kecap manis
1. Ambil 3 sdm air




<!--inarticleads2-->

##### Langkah-langkah membuat 80. Ayam Bakar Wong Solo:

1. Cuci bersih ayam. Sisihkan.
1. Campuran semua bumbu untuk ungkep ayam. Aduk merata. Masak sampai air susut supaya bumbu meresap. Jika sudah susut, matikan.
1. Sambil menunggu air rebusan ayam ungkepnya susut, kita buat bumbu olesan.
1. Haluskan bawang merah, bawang putih, cabe menggunakan copper atau blender bumbu. Masak dengan minyak, masukkan gula merah, garam &amp; air. Masak hingga matang &amp; mengental. Jika sudah matang, pindahkan ke mangkok.
1. Bumbu olesan di mangkok tambahkan kecap manis &amp; air.
1. Sebelum dibakar diatas teflon, olesi dengan margarin. Aku pakai minyak goreng sedikit saja. Lumuri ayam dengan bumbu olesan. Bakar sesuai selera. Aku sampai ada gosong2nya sedikit. Bisa diolesi lagi dengan kuas selama proses bakar.
1. Sajikan..




Wah ternyata resep 80. ayam bakar wong solo yang nikamt tidak ribet ini enteng banget ya! Kalian semua mampu memasaknya. Cara buat 80. ayam bakar wong solo Sesuai sekali untuk anda yang baru mau belajar memasak ataupun juga bagi anda yang telah lihai dalam memasak.

Apakah kamu mau mencoba buat resep 80. ayam bakar wong solo mantab sederhana ini? Kalau kamu mau, ayo kalian segera menyiapkan alat-alat dan bahan-bahannya, lantas buat deh Resep 80. ayam bakar wong solo yang mantab dan tidak ribet ini. Sangat gampang kan. 

Maka dari itu, ketimbang anda diam saja, yuk kita langsung sajikan resep 80. ayam bakar wong solo ini. Pasti kalian tak akan menyesal sudah membuat resep 80. ayam bakar wong solo lezat tidak rumit ini! Selamat mencoba dengan resep 80. ayam bakar wong solo lezat simple ini di tempat tinggal kalian masing-masing,oke!.

