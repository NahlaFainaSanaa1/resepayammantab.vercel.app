---
description: "Cara memasak Freid chicken kriuk renyah tahan lama yang sedap dan Mudah Dibuat"
title: "Cara memasak Freid chicken kriuk renyah tahan lama yang sedap dan Mudah Dibuat"
slug: 207-cara-memasak-freid-chicken-kriuk-renyah-tahan-lama-yang-sedap-dan-mudah-dibuat
date: 2021-04-20T16:56:59.350Z
image: https://img-global.cpcdn.com/recipes/2bcc8372d885cdf6/680x482cq70/freid-chicken-kriuk-renyah-tahan-lama-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2bcc8372d885cdf6/680x482cq70/freid-chicken-kriuk-renyah-tahan-lama-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2bcc8372d885cdf6/680x482cq70/freid-chicken-kriuk-renyah-tahan-lama-foto-resep-utama.jpg
author: Lillie Cunningham
ratingvalue: 3.6
reviewcount: 9
recipeingredient:
- "500 gr ayam potong jadi 8 bagian"
- "250 gr tepung terigu segitiga"
- "Secukupnya Masako rasa apa aja me rasa sapi 12 sdm"
- "1/2 sdt garam  secukupnya"
- "1 sdt soda kue"
- " Air es secukupnya untuk merendam"
- "1 sdm oregano kering opsional"
- "1 sdt ketumbar bubuk"
- "secukupnya Minyak"
- " Bahan Marinasi"
- "1 sachet masako"
- "1 sdt garam"
- "1 sdt ketumbar bubuk"
- "1/4 sdt merica bubuk"
recipeinstructions:
- "Ayam yang sudah dicuci bersih campur dengan bahan marinasi aduk rata. Masukan kulkas min 2 - 3 jam. Klo mau lebih enak semalaman nyimpennya"
- "Campur tepung terigu, masako, merica, oregano, ketumbar, garam. Cek rasa, sisihkan. Siapkan air es yang dicampur soda kue"
- "Ayam yg sudah dimarinasi masukan ke dalam adonan tepung tadi sambil di aduk dengan kedua tangan (jangan ditekan) kurleb 1 menit."
- "Masukan ke dalam air es rendam sebentar lalu angkat dan masukan kembali ke adonan tepung aduk2 lagi (sekitar 2-3 menit) dan pastinya jangan ditekan2 ya nanti keras"
- "Apabila sudah keliatan kriwilnya, siap digoreng dengan api sedang saja ya klo sudah kecoklatan angkat dan siap dihidangkan. (Klo belum mengeras pada saat menggoreng jangan dibolak balik)"
- "Catatan : air es harus dikasih soda kue ya karena ini yg membuat renyahnya tahan lama"
categories:
- Resep
tags:
- freid
- chicken
- kriuk

katakunci: freid chicken kriuk 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Freid chicken kriuk renyah tahan lama](https://img-global.cpcdn.com/recipes/2bcc8372d885cdf6/680x482cq70/freid-chicken-kriuk-renyah-tahan-lama-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyediakan olahan lezat kepada famili adalah hal yang menyenangkan bagi anda sendiri. Peran seorang ibu Tidak saja mengatur rumah saja, tapi kamu pun wajib memastikan keperluan nutrisi terpenuhi dan masakan yang dimakan keluarga tercinta harus enak.

Di zaman  saat ini, kita sebenarnya mampu memesan panganan yang sudah jadi walaupun tidak harus capek membuatnya dulu. Tapi ada juga lho mereka yang selalu mau memberikan hidangan yang terbaik bagi orang tercintanya. Lantaran, menghidangkan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan seorang penggemar freid chicken kriuk renyah tahan lama?. Tahukah kamu, freid chicken kriuk renyah tahan lama adalah sajian khas di Indonesia yang kini disukai oleh setiap orang dari hampir setiap tempat di Indonesia. Anda dapat menghidangkan freid chicken kriuk renyah tahan lama sendiri di rumahmu dan boleh dijadikan makanan kegemaranmu di hari liburmu.

Anda jangan bingung untuk menyantap freid chicken kriuk renyah tahan lama, lantaran freid chicken kriuk renyah tahan lama tidak sulit untuk dicari dan kalian pun boleh menghidangkannya sendiri di rumah. freid chicken kriuk renyah tahan lama bisa dibuat memalui beragam cara. Kini pun ada banyak banget resep modern yang menjadikan freid chicken kriuk renyah tahan lama semakin lebih mantap.

Resep freid chicken kriuk renyah tahan lama pun gampang dibuat, lho. Kita tidak usah ribet-ribet untuk membeli freid chicken kriuk renyah tahan lama, sebab Kita bisa menghidangkan di rumahmu. Untuk Kita yang ingin menghidangkannya, inilah resep untuk menyajikan freid chicken kriuk renyah tahan lama yang lezat yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Freid chicken kriuk renyah tahan lama:

1. Gunakan 500 gr ayam potong jadi 8 bagian
1. Gunakan 250 gr tepung terigu segitiga
1. Gunakan Secukupnya Masako rasa apa aja (me: rasa sapi 1/2 sdm)
1. Gunakan 1/2 sdt garam / secukupnya
1. Ambil 1 sdt soda kue
1. Ambil  Air es secukupnya untuk merendam
1. Ambil 1 sdm oregano kering (opsional)
1. Gunakan 1 sdt ketumbar bubuk
1. Ambil secukupnya Minyak
1. Siapkan  Bahan Marinasi
1. Gunakan 1 sachet masako
1. Ambil 1 sdt garam
1. Gunakan 1 sdt ketumbar bubuk
1. Ambil 1/4 sdt merica bubuk




<!--inarticleads2-->

##### Cara membuat Freid chicken kriuk renyah tahan lama:

1. Ayam yang sudah dicuci bersih campur dengan bahan marinasi aduk rata. Masukan kulkas min 2 - 3 jam. Klo mau lebih enak semalaman nyimpennya
1. Campur tepung terigu, masako, merica, oregano, ketumbar, garam. Cek rasa, sisihkan. Siapkan air es yang dicampur soda kue
1. Ayam yg sudah dimarinasi masukan ke dalam adonan tepung tadi sambil di aduk dengan kedua tangan (jangan ditekan) kurleb 1 menit.
1. Masukan ke dalam air es rendam sebentar lalu angkat dan masukan kembali ke adonan tepung aduk2 lagi (sekitar 2-3 menit) dan pastinya jangan ditekan2 ya nanti keras
1. Apabila sudah keliatan kriwilnya, siap digoreng dengan api sedang saja ya klo sudah kecoklatan angkat dan siap dihidangkan. (Klo belum mengeras pada saat menggoreng jangan dibolak balik)
1. Catatan : air es harus dikasih soda kue ya karena ini yg membuat renyahnya tahan lama




Wah ternyata resep freid chicken kriuk renyah tahan lama yang mantab sederhana ini gampang sekali ya! Semua orang mampu menghidangkannya. Cara buat freid chicken kriuk renyah tahan lama Sesuai banget buat kamu yang sedang belajar memasak maupun bagi kamu yang telah ahli memasak.

Tertarik untuk mulai mencoba bikin resep freid chicken kriuk renyah tahan lama lezat sederhana ini? Kalau kamu tertarik, ayo kalian segera menyiapkan alat dan bahan-bahannya, lalu bikin deh Resep freid chicken kriuk renyah tahan lama yang nikmat dan simple ini. Benar-benar mudah kan. 

Jadi, ketimbang kita berlama-lama, ayo kita langsung saja buat resep freid chicken kriuk renyah tahan lama ini. Dijamin kamu gak akan nyesel sudah membuat resep freid chicken kriuk renyah tahan lama lezat sederhana ini! Selamat berkreasi dengan resep freid chicken kriuk renyah tahan lama nikmat simple ini di rumah sendiri,oke!.

