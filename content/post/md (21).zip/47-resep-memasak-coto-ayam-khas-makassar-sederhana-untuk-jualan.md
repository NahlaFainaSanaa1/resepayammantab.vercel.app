---
description: "Resep memasak Coto ayam khas makassar Sederhana Untuk Jualan"
title: "Resep memasak Coto ayam khas makassar Sederhana Untuk Jualan"
slug: 47-resep-memasak-coto-ayam-khas-makassar-sederhana-untuk-jualan
date: 2021-03-21T16:23:05.171Z
image: https://img-global.cpcdn.com/recipes/7681ce7d9b0eacdb/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7681ce7d9b0eacdb/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7681ce7d9b0eacdb/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
author: Jerome Yates
ratingvalue: 3.1
reviewcount: 15
recipeingredient:
- "1 ekor ayam"
- "mangkok sereh yg sudah diiris"
- "1 mangkok lengkuas yg sdh diiris kurangi sedikit dr porsi sereh"
- "3 bawang putih"
- "1 sendok merica bubuk kurangi bila tdk suka pedasnya"
- "1/2 kg kacang sangrai yg sudah di haluskan"
- " Santan kelapa dr 1 butir kelapa"
- " Bumbu penyedap"
recipeinstructions:
- "Haluskan bumbu lalu tumis  2.Potong potong kecil ayam bersama dgn tulang tulangnya sebesar 1 ruas jari 3.Masak daging ayam yg sudah di potong potong dalam bumbu Coto 4.jika sudah empuk masukkan santan dan kacang sangrai yg sudah dihaluskan 5. Masukkan bumbu penyedap dan bila sudah mendidih Coto siap disajikan bersama dgn ketupat"
- "Potong potong kecil ayam bersama dgn tulang tulangnya sebesar 1 ruas jari"
- "Masak daging ayam yg sudah di potong potong dalam bumbu Coto"
- "Jika sudah empuk masukkan santan dan kacang sangrai yg sudah dihaluskan"
- "Masukkan bumbu penyedap dan bila sudah mendidih Coto siap disajikan bersama dgn ketupat"
- "Jangan lupa taburkan bawang goreng dan daun seledri sebelum di sajikan.selamat mencoba"
categories:
- Resep
tags:
- coto
- ayam
- khas

katakunci: coto ayam khas 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dessert

---


![Coto ayam khas makassar](https://img-global.cpcdn.com/recipes/7681ce7d9b0eacdb/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg)

Sebagai seorang wanita, menyuguhkan panganan enak buat keluarga adalah hal yang mengasyikan bagi kita sendiri. Tanggung jawab seorang ibu bukan sekedar mengatur rumah saja, tapi kamu pun wajib menyediakan keperluan nutrisi terpenuhi dan masakan yang dimakan anak-anak harus lezat.

Di waktu  sekarang, kamu memang dapat memesan masakan praktis meski tanpa harus ribet mengolahnya terlebih dahulu. Tetapi ada juga mereka yang memang mau menghidangkan yang terenak bagi keluarganya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan famili. 



Apakah anda merupakan salah satu penyuka coto ayam khas makassar?. Tahukah kamu, coto ayam khas makassar adalah makanan khas di Indonesia yang sekarang disenangi oleh banyak orang di berbagai tempat di Indonesia. Kalian dapat menghidangkan coto ayam khas makassar sendiri di rumah dan boleh jadi camilan kegemaranmu di akhir pekanmu.

Anda tak perlu bingung untuk mendapatkan coto ayam khas makassar, karena coto ayam khas makassar gampang untuk dicari dan kita pun bisa menghidangkannya sendiri di rumah. coto ayam khas makassar boleh dimasak memalui bermacam cara. Kini pun telah banyak banget cara modern yang menjadikan coto ayam khas makassar semakin lebih nikmat.

Resep coto ayam khas makassar juga gampang sekali dibuat, lho. Kalian jangan repot-repot untuk membeli coto ayam khas makassar, tetapi Anda mampu membuatnya di rumah sendiri. Untuk Kita yang hendak menghidangkannya, berikut resep menyajikan coto ayam khas makassar yang nikamat yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Coto ayam khas makassar:

1. Siapkan 1 ekor ayam
1. Sediakan mangkok sereh yg sudah diiris
1. Sediakan 1 mangkok lengkuas yg sdh diiris kurangi sedikit dr porsi sereh
1. Ambil 3 bawang putih
1. Gunakan 1 sendok merica bubuk, kurangi bila tdk suka pedasnya
1. Ambil 1/2 kg kacang sangrai yg sudah di haluskan
1. Siapkan  Santan kelapa dr 1 butir kelapa
1. Sediakan  Bumbu penyedap




<!--inarticleads2-->

##### Cara menyiapkan Coto ayam khas makassar:

1. Haluskan bumbu lalu tumis  - 2.Potong potong kecil ayam bersama dgn tulang tulangnya sebesar 1 ruas jari - 3.Masak daging ayam yg sudah di potong potong dalam bumbu Coto - 4.jika sudah empuk masukkan santan dan kacang sangrai yg sudah dihaluskan - 5. Masukkan bumbu penyedap dan bila sudah mendidih Coto siap disajikan bersama dgn ketupat
1. Potong potong kecil ayam bersama dgn tulang tulangnya sebesar 1 ruas jari
1. Masak daging ayam yg sudah di potong potong dalam bumbu Coto
1. Jika sudah empuk masukkan santan dan kacang sangrai yg sudah dihaluskan
1. Masukkan bumbu penyedap dan bila sudah mendidih Coto siap disajikan bersama dgn ketupat
1. Jangan lupa taburkan bawang goreng dan daun seledri sebelum di sajikan.selamat mencoba




Ternyata cara buat coto ayam khas makassar yang nikamt simple ini mudah banget ya! Semua orang dapat memasaknya. Cara buat coto ayam khas makassar Sesuai sekali buat kita yang baru mau belajar memasak maupun bagi anda yang telah jago dalam memasak.

Apakah kamu ingin mencoba membikin resep coto ayam khas makassar nikmat tidak rumit ini? Kalau kamu ingin, ayo kamu segera siapin alat dan bahannya, setelah itu buat deh Resep coto ayam khas makassar yang mantab dan tidak ribet ini. Sangat mudah kan. 

Maka, daripada kalian berfikir lama-lama, yuk kita langsung hidangkan resep coto ayam khas makassar ini. Pasti kalian tak akan menyesal membuat resep coto ayam khas makassar enak simple ini! Selamat berkreasi dengan resep coto ayam khas makassar lezat tidak rumit ini di tempat tinggal masing-masing,oke!.

