---
description: "Cara membuat Ayam Geprek yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Geprek yang lezat dan Mudah Dibuat"
slug: 377-cara-membuat-ayam-geprek-yang-lezat-dan-mudah-dibuat
date: 2021-06-29T20:21:04.617Z
image: https://img-global.cpcdn.com/recipes/1649f951defcba8a/680x482cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1649f951defcba8a/680x482cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1649f951defcba8a/680x482cq70/ayam-geprek-foto-resep-utama.jpg
author: Florence Blair
ratingvalue: 3.4
reviewcount: 9
recipeingredient:
- "1/2 Ekor ayam bagian dada"
- "1 ons cabe rawit merah"
- "1 Bongkol bawang putih"
- " Tepung krispi kuntucky"
- " Penyedap rasa masako"
recipeinstructions:
- "Filet dada ayam terlebih dulu jadi biar matangnya maksimal"
- "Lakukan marinasi pada ayam kurleb 2 jam biar ayam meresap ke dalam tepung marinasi"
- "Masukkan dada ayam yg sudah dimarinasi ke dalam tepung krispy (kentucky) yg tersedia di dlm baskom"
- "Lalu gulirkan ayam ke dalam tepung krispy (kuntucky) masukkan lagi ke dlm bumbu adonan marinasi ulang lagi biar tepungnya bsa nempel lbh tebal"
- "Ulangi lagi ayam yg sudah di masukkan ke dalam adonan marinasi masukkan lagi ayam ke dlm tepung krispy (kuntucky) lalu siap digoreng"
- "Siapkan dulu apik yg benar-benar panas baru masukkan ayam lakukan penggorengan jangan dibolak balik ya bun nanti tepungnya jadi ambyar"
- "Goreng sampai ayam ke coklatan, ayam kuntucky siap dihidangkan selamat mencoba bunda semoga cocok dg resep ini"
categories:
- Resep
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 128 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/1649f951defcba8a/680x482cq70/ayam-geprek-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyediakan masakan mantab untuk keluarga tercinta adalah suatu hal yang menggembirakan bagi kamu sendiri. Tugas seorang ibu bukan cuman menangani rumah saja, tetapi anda pun harus menyediakan keperluan nutrisi tercukupi dan juga panganan yang disantap keluarga tercinta mesti menggugah selera.

Di masa  sekarang, kalian memang mampu mengorder hidangan jadi tanpa harus susah memasaknya terlebih dahulu. Tetapi banyak juga lho orang yang memang ingin memberikan hidangan yang terenak untuk orang yang dicintainya. Pasalnya, menyajikan masakan sendiri akan jauh lebih higienis dan bisa menyesuaikan berdasarkan makanan kesukaan orang tercinta. 



Apakah kamu seorang penikmat ayam geprek?. Tahukah kamu, ayam geprek merupakan makanan khas di Nusantara yang saat ini disenangi oleh banyak orang di berbagai daerah di Nusantara. Kalian dapat membuat ayam geprek olahan sendiri di rumah dan pasti jadi makanan favorit di hari liburmu.

Anda tak perlu bingung jika kamu ingin mendapatkan ayam geprek, lantaran ayam geprek sangat mudah untuk didapatkan dan juga anda pun dapat mengolahnya sendiri di rumah. ayam geprek dapat diolah memalui bermacam cara. Kini pun telah banyak banget resep kekinian yang menjadikan ayam geprek semakin lebih lezat.

Resep ayam geprek pun mudah untuk dibuat, lho. Kita tidak perlu capek-capek untuk memesan ayam geprek, tetapi Kamu bisa membuatnya di rumahmu. Bagi Anda yang hendak mencobanya, berikut cara menyajikan ayam geprek yang lezat yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Geprek:

1. Ambil 1/2 Ekor ayam bagian dada
1. Gunakan 1 ons cabe rawit merah
1. Ambil 1 Bongkol bawang putih
1. Sediakan  Tepung krispi kuntucky
1. Ambil  Penyedap rasa (masako)




<!--inarticleads2-->

##### Cara membuat Ayam Geprek:

1. Filet dada ayam terlebih dulu jadi biar matangnya maksimal
1. Lakukan marinasi pada ayam kurleb 2 jam biar ayam meresap ke dalam tepung marinasi
1. Masukkan dada ayam yg sudah dimarinasi ke dalam tepung krispy (kentucky) yg tersedia di dlm baskom
1. Lalu gulirkan ayam ke dalam tepung krispy (kuntucky) masukkan lagi ke dlm bumbu adonan marinasi ulang lagi biar tepungnya bsa nempel lbh tebal
1. Ulangi lagi ayam yg sudah di masukkan ke dalam adonan marinasi masukkan lagi ayam ke dlm tepung krispy (kuntucky) lalu siap digoreng
1. Siapkan dulu apik yg benar-benar panas baru masukkan ayam lakukan penggorengan jangan dibolak balik ya bun nanti tepungnya jadi ambyar
1. Goreng sampai ayam ke coklatan, ayam kuntucky siap dihidangkan selamat mencoba bunda semoga cocok dg resep ini




Wah ternyata resep ayam geprek yang nikamt tidak ribet ini enteng banget ya! Kamu semua bisa menghidangkannya. Resep ayam geprek Sangat cocok sekali buat kita yang sedang belajar memasak ataupun bagi anda yang sudah lihai dalam memasak.

Apakah kamu tertarik mencoba membikin resep ayam geprek nikmat simple ini? Kalau kamu mau, yuk kita segera siapkan peralatan dan bahan-bahannya, lantas bikin deh Resep ayam geprek yang mantab dan tidak rumit ini. Betul-betul gampang kan. 

Oleh karena itu, daripada kalian diam saja, ayo langsung aja bikin resep ayam geprek ini. Dijamin kamu tiidak akan nyesel sudah membuat resep ayam geprek mantab tidak rumit ini! Selamat berkreasi dengan resep ayam geprek lezat tidak ribet ini di tempat tinggal masing-masing,oke!.

