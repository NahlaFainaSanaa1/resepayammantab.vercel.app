---
description: "Resep Hati Ayam Masak Asam Manis yang nikmat dan Mudah Dibuat"
title: "Resep Hati Ayam Masak Asam Manis yang nikmat dan Mudah Dibuat"
slug: 337-resep-hati-ayam-masak-asam-manis-yang-nikmat-dan-mudah-dibuat
date: 2021-03-21T04:51:18.169Z
image: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
author: William Douglas
ratingvalue: 3.3
reviewcount: 3
recipeingredient:
- "3 bh Hati Ayam Kampung"
- "5 siung Bawang merah"
- "4 siung Bawang putih"
- "1 bh Bawang merah besar"
- "4 bh Cabe Hijau besar"
- "1 bh Tomat"
- "2 papan petai kupas"
- "1 bks Terasi larutkan dengan air"
- "1 sdm Gula merah serut"
- " Garam"
- " Gula pasir"
- " Penyedap rasa"
recipeinstructions:
- "Bersihkan hati ayam, potong persegi kecil. Beri perasan air jeruk nipis dan garam. Diamkan sebentar. Cuci bersih."
- "Rebus hati ayam sebentar, tiriskan. Sisihkan."
- "Siapkan bahan-bahan lainnya, iris bawang, cabe merah, cabe hijau, tomat, petai."
- "Tumis bumbu iris sampai harum dan layu"
- "Masukkan hati ayam, aduk rata. Tumis sebentar. Masukkan air terasi."
- "Masukkan petai dan Tambahkan sedikit air, beri garam, gula pasir, gula merah, dan penyedap. Aduk rata."
- "Masak sampai kuah menyusut dan hati matang, cek rasa, bila sudah pas, angkat. Sajikan."
categories:
- Resep
tags:
- hati
- ayam
- masak

katakunci: hati ayam masak 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Hati Ayam Masak Asam Manis](https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg)

Selaku seorang orang tua, menyajikan olahan lezat bagi keluarga merupakan hal yang menyenangkan untuk kamu sendiri. Tugas seorang ibu Tidak sekadar mengurus rumah saja, namun kamu juga wajib menyediakan kebutuhan gizi terpenuhi dan masakan yang dimakan keluarga tercinta mesti enak.

Di zaman  sekarang, anda memang dapat mengorder masakan yang sudah jadi meski tanpa harus capek membuatnya terlebih dahulu. Tapi banyak juga orang yang selalu mau memberikan hidangan yang terenak bagi orang yang dicintainya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai kesukaan keluarga. 



Apakah anda seorang penyuka hati ayam masak asam manis?. Asal kamu tahu, hati ayam masak asam manis merupakan sajian khas di Indonesia yang kini disenangi oleh banyak orang dari berbagai tempat di Indonesia. Kita dapat menghidangkan hati ayam masak asam manis kreasi sendiri di rumah dan dapat dijadikan santapan kesenanganmu di hari libur.

Kalian tidak usah bingung untuk memakan hati ayam masak asam manis, karena hati ayam masak asam manis tidak sukar untuk didapatkan dan juga kita pun boleh memasaknya sendiri di tempatmu. hati ayam masak asam manis bisa diolah memalui beragam cara. Saat ini ada banyak resep modern yang menjadikan hati ayam masak asam manis semakin lezat.

Resep hati ayam masak asam manis pun sangat gampang dihidangkan, lho. Anda jangan ribet-ribet untuk membeli hati ayam masak asam manis, sebab Kamu dapat menyajikan ditempatmu. Untuk Kamu yang mau membuatnya, di bawah ini adalah resep membuat hati ayam masak asam manis yang lezat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Hati Ayam Masak Asam Manis:

1. Sediakan 3 bh Hati Ayam Kampung
1. Sediakan 5 siung Bawang merah
1. Ambil 4 siung Bawang putih
1. Sediakan 1 bh Bawang merah besar
1. Ambil 4 bh Cabe Hijau besar
1. Siapkan 1 bh Tomat
1. Ambil 2 papan petai, kupas
1. Gunakan 1 bks Terasi, larutkan dengan air
1. Ambil 1 sdm Gula merah, serut
1. Sediakan  Garam
1. Siapkan  Gula pasir
1. Gunakan  Penyedap rasa




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Hati Ayam Masak Asam Manis:

1. Bersihkan hati ayam, potong persegi kecil. Beri perasan air jeruk nipis dan garam. Diamkan sebentar. Cuci bersih.
1. Rebus hati ayam sebentar, tiriskan. Sisihkan.
1. Siapkan bahan-bahan lainnya, iris bawang, cabe merah, cabe hijau, tomat, petai.
1. Tumis bumbu iris sampai harum dan layu
1. Masukkan hati ayam, aduk rata. Tumis sebentar. Masukkan air terasi.
1. Masukkan petai dan Tambahkan sedikit air, beri garam, gula pasir, gula merah, dan penyedap. Aduk rata.
1. Masak sampai kuah menyusut dan hati matang, cek rasa, bila sudah pas, angkat. Sajikan.




Wah ternyata cara membuat hati ayam masak asam manis yang mantab sederhana ini gampang sekali ya! Kalian semua dapat memasaknya. Cara Membuat hati ayam masak asam manis Cocok sekali untuk kita yang baru mau belajar memasak maupun juga untuk anda yang telah lihai dalam memasak.

Apakah kamu mau mencoba membikin resep hati ayam masak asam manis nikmat sederhana ini? Kalau anda tertarik, yuk kita segera menyiapkan alat dan bahannya, lantas bikin deh Resep hati ayam masak asam manis yang mantab dan tidak rumit ini. Sungguh mudah kan. 

Oleh karena itu, daripada kamu diam saja, yuk langsung aja bikin resep hati ayam masak asam manis ini. Pasti kalian gak akan menyesal sudah membuat resep hati ayam masak asam manis lezat simple ini! Selamat berkreasi dengan resep hati ayam masak asam manis enak sederhana ini di tempat tinggal sendiri,ya!.

