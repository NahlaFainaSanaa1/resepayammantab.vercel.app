---
description: "Cara memasak Coto Ayam Sederhana dan Mudah Dibuat"
title: "Cara memasak Coto Ayam Sederhana dan Mudah Dibuat"
slug: 51-cara-memasak-coto-ayam-sederhana-dan-mudah-dibuat
date: 2021-02-01T13:21:25.231Z
image: https://img-global.cpcdn.com/recipes/0e76a5c2ef318f7e/680x482cq70/coto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0e76a5c2ef318f7e/680x482cq70/coto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0e76a5c2ef318f7e/680x482cq70/coto-ayam-foto-resep-utama.jpg
author: Adrian Haynes
ratingvalue: 4.3
reviewcount: 11
recipeingredient:
- " 12 kg ayam"
- "1000 ml air"
- "Segenggam kacang mede sangraiSaya crushed kasar"
- " Bumbu halus"
- "10 bamer"
- "7 baput"
- "1 ruas jahe"
- "3 butir kemiri"
- "1 sdt bubuk ketumbar"
- "1/2 sdt merica bubuk"
- "1 sdt gula merah"
- "Secukupnya garam"
- "secukupnya Minyak goreng"
- " Bahan pelengkap"
- "4 lembar daun jeruk"
- "4 lembar daun salam"
- "2 batang sereh"
- " Bahan taburan"
- " Seledry daun bawang jeruk nipisme lemon"
- " Sambal krupuk"
recipeinstructions:
- "Rebus ayamnya sampai matang, sisihkan kaldunya"
- "Goreng ayamnya untuk disuir2, sisihkan"
- "Masukkan food processor bumbu halusnya"
- "Tumis sampai matang harum bumbu halusnya kurleb 15 menitan"
- "Masukkan bumbu pelengkap, masukkan juga kacang mede sangrai,koreksi rasa"
- "Masukkan bumbu halus ke dlm air kaldu ayam, masak aduk2"
- "Sajikan dgn nasi/ buras/ketupat. Beri taburannya."
categories:
- Resep
tags:
- coto
- ayam

katakunci: coto ayam 
nutrition: 239 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Coto Ayam](https://img-global.cpcdn.com/recipes/0e76a5c2ef318f7e/680x482cq70/coto-ayam-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan masakan mantab untuk famili adalah suatu hal yang memuaskan bagi anda sendiri. Peran seorang ibu Tidak cuman mengerjakan pekerjaan rumah saja, tapi kamu pun wajib menyediakan kebutuhan nutrisi tercukupi dan santapan yang disantap anak-anak harus enak.

Di waktu  sekarang, kita memang bisa memesan olahan instan tidak harus capek membuatnya terlebih dahulu. Tapi banyak juga orang yang selalu ingin memberikan hidangan yang terenak bagi keluarganya. Pasalnya, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga. 



Mungkinkah kamu salah satu penggemar coto ayam?. Asal kamu tahu, coto ayam adalah hidangan khas di Indonesia yang kini disenangi oleh banyak orang di berbagai tempat di Nusantara. Kamu bisa memasak coto ayam hasil sendiri di rumahmu dan pasti jadi hidangan kesukaanmu di hari libur.

Kita tidak usah bingung untuk mendapatkan coto ayam, karena coto ayam tidak sukar untuk didapatkan dan juga kita pun dapat membuatnya sendiri di rumah. coto ayam boleh dibuat lewat berbagai cara. Saat ini ada banyak sekali resep modern yang membuat coto ayam lebih enak.

Resep coto ayam pun gampang dihidangkan, lho. Anda tidak perlu ribet-ribet untuk membeli coto ayam, karena Kamu dapat menyajikan di rumah sendiri. Bagi Kita yang akan membuatnya, di bawah ini adalah resep menyajikan coto ayam yang enak yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Coto Ayam:

1. Siapkan  📎1/2 kg ayam
1. Sediakan 1000 ml air
1. Sediakan Segenggam kacang mede sangrai(Saya crushed kasar)
1. Gunakan  📎Bumbu halus:
1. Gunakan 10 bamer
1. Ambil 7 baput
1. Ambil 1 ruas jahe
1. Sediakan 3 butir kemiri
1. Siapkan 1 sdt bubuk ketumbar
1. Sediakan 1/2 sdt merica bubuk
1. Gunakan 1 sdt gula merah
1. Siapkan Secukupnya garam
1. Sediakan secukupnya Minyak goreng
1. Siapkan  📎Bahan pelengkap:
1. Siapkan 4 lembar daun jeruk
1. Sediakan 4 lembar daun salam
1. Ambil 2 batang sereh
1. Ambil  📎Bahan taburan:
1. Gunakan  Seledry, daun bawang, jeruk nipis,(me: lemon)
1. Ambil  Sambal, krupuk




<!--inarticleads2-->

##### Langkah-langkah membuat Coto Ayam:

1. Rebus ayamnya sampai matang, sisihkan kaldunya
1. Goreng ayamnya untuk disuir2, sisihkan
1. Masukkan food processor bumbu halusnya
1. Tumis sampai matang harum bumbu halusnya kurleb 15 menitan
1. Masukkan bumbu pelengkap, masukkan juga kacang mede sangrai,koreksi rasa
1. Masukkan bumbu halus ke dlm air kaldu ayam, masak aduk2
1. Sajikan dgn nasi/ buras/ketupat. Beri taburannya.




Wah ternyata cara membuat coto ayam yang mantab simple ini gampang sekali ya! Kita semua mampu memasaknya. Cara buat coto ayam Cocok sekali buat kamu yang sedang belajar memasak ataupun bagi kalian yang sudah hebat dalam memasak.

Tertarik untuk mencoba buat resep coto ayam mantab simple ini? Kalau anda mau, ayo kamu segera buruan siapin alat-alat dan bahan-bahannya, lantas bikin deh Resep coto ayam yang enak dan tidak rumit ini. Sangat taidak sulit kan. 

Jadi, ketimbang kalian berlama-lama, hayo langsung aja sajikan resep coto ayam ini. Dijamin kalian gak akan menyesal membuat resep coto ayam lezat tidak rumit ini! Selamat mencoba dengan resep coto ayam lezat sederhana ini di tempat tinggal sendiri,ya!.

