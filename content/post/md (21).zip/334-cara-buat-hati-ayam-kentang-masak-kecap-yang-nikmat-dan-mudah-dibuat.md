---
description: "Cara buat Hati ayam kentang masak kecap yang nikmat dan Mudah Dibuat"
title: "Cara buat Hati ayam kentang masak kecap yang nikmat dan Mudah Dibuat"
slug: 334-cara-buat-hati-ayam-kentang-masak-kecap-yang-nikmat-dan-mudah-dibuat
date: 2021-04-13T08:36:27.313Z
image: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
author: Celia Gibson
ratingvalue: 3
reviewcount: 9
recipeingredient:
- "4 bh hati ayam"
- "4 bh kentang"
- "3 bh bawang merah  1 bh bombay"
- "2 bh bawang putih"
- "secukupnya Merica"
- "2 helai daun bawang iris"
- "1 bh tomat besar iris"
- "1 ruas jahe"
- "2 sdm kecap manis"
- "1 sdt saori saus tiram"
- "secukupnya Garampenyedap"
- "secukupnya Air"
recipeinstructions:
- "Rebus hati ayam,stlh masak potong dan sisihkan"
- "Kupas dan potong kentang sesuai selera,lalu digoreng"
- "Iris bawang merah,geprek bawang putih dan jahe"
- "Tumis bawang,jahe dan merica hingga harum"
- "Tambahkan garam,penyedap dan air"
- "Lalu masukkan saori,dan kecap manis"
- "Masukkan hati ayam dan kentang,aduk rata dan diamkan sejenak sampai seluruh bumbu meresap."
- "Terakhir masukkan irisan daun bawang dan tomat sbg pelengkap,aduk rata"
- "Siap dihidangkan🤗"
categories:
- Resep
tags:
- hati
- ayam
- kentang

katakunci: hati ayam kentang 
nutrition: 201 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Hati ayam kentang masak kecap](https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg)

Jika anda seorang istri, mempersiapkan panganan menggugah selera kepada famili adalah hal yang membahagiakan bagi kita sendiri. Tanggung jawab seorang  wanita Tidak sekedar mengerjakan pekerjaan rumah saja, namun kamu juga harus menyediakan keperluan gizi terpenuhi dan juga panganan yang dikonsumsi keluarga tercinta mesti lezat.

Di zaman  saat ini, kita sebenarnya bisa mengorder hidangan siap saji meski tidak harus capek memasaknya terlebih dahulu. Tetapi banyak juga lho mereka yang selalu ingin menghidangkan yang terbaik bagi keluarganya. Lantaran, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan keluarga. 



Mungkinkah anda adalah seorang penyuka hati ayam kentang masak kecap?. Asal kamu tahu, hati ayam kentang masak kecap adalah sajian khas di Nusantara yang kini disukai oleh orang-orang dari hampir setiap daerah di Nusantara. Kalian bisa menghidangkan hati ayam kentang masak kecap buatan sendiri di rumah dan boleh dijadikan makanan favorit di akhir pekanmu.

Kita jangan bingung jika kamu ingin menyantap hati ayam kentang masak kecap, karena hati ayam kentang masak kecap tidak sulit untuk dicari dan juga kamu pun dapat memasaknya sendiri di rumah. hati ayam kentang masak kecap bisa dibuat dengan beraneka cara. Kini pun telah banyak sekali resep kekinian yang membuat hati ayam kentang masak kecap semakin lebih mantap.

Resep hati ayam kentang masak kecap pun gampang sekali dibikin, lho. Kalian tidak usah capek-capek untuk memesan hati ayam kentang masak kecap, sebab Kita mampu menyajikan di rumahmu. Bagi Kalian yang ingin membuatnya, berikut resep untuk menyajikan hati ayam kentang masak kecap yang mantab yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Hati ayam kentang masak kecap:

1. Ambil 4 bh hati ayam
1. Gunakan 4 bh kentang
1. Gunakan 3 bh bawang merah / 1 bh bombay
1. Gunakan 2 bh bawang putih
1. Siapkan secukupnya Merica
1. Ambil 2 helai daun bawang, iris
1. Gunakan 1 bh tomat besar, iris
1. Ambil 1 ruas jahe
1. Gunakan 2 sdm kecap manis
1. Siapkan 1 sdt saori saus tiram
1. Ambil secukupnya Garam,penyedap
1. Sediakan secukupnya Air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Hati ayam kentang masak kecap:

1. Rebus hati ayam,stlh masak potong dan sisihkan
1. Kupas dan potong kentang sesuai selera,lalu digoreng
1. Iris bawang merah,geprek bawang putih dan jahe
1. Tumis bawang,jahe dan merica hingga harum
1. Tambahkan garam,penyedap dan air
1. Lalu masukkan saori,dan kecap manis
1. Masukkan hati ayam dan kentang,aduk rata dan diamkan sejenak sampai seluruh bumbu meresap.
1. Terakhir masukkan irisan daun bawang dan tomat sbg pelengkap,aduk rata
1. Siap dihidangkan🤗




Wah ternyata cara membuat hati ayam kentang masak kecap yang enak tidak rumit ini gampang sekali ya! Semua orang bisa mencobanya. Cara buat hati ayam kentang masak kecap Sesuai sekali buat anda yang baru belajar memasak ataupun juga bagi kamu yang telah pandai memasak.

Apakah kamu ingin mulai mencoba membuat resep hati ayam kentang masak kecap lezat tidak ribet ini? Kalau anda mau, ayo kamu segera buruan menyiapkan peralatan dan bahannya, lalu buat deh Resep hati ayam kentang masak kecap yang lezat dan simple ini. Benar-benar taidak sulit kan. 

Maka, ketimbang kalian diam saja, maka kita langsung buat resep hati ayam kentang masak kecap ini. Pasti anda tak akan nyesel membuat resep hati ayam kentang masak kecap enak sederhana ini! Selamat berkreasi dengan resep hati ayam kentang masak kecap enak simple ini di rumah sendiri,ya!.

