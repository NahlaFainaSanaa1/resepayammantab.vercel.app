---
description: "Cara membuat Day. 260 Ati Ayam Masak Santan Berempah (14 month+) yang nikmat dan Mudah Dibuat"
title: "Cara membuat Day. 260 Ati Ayam Masak Santan Berempah (14 month+) yang nikmat dan Mudah Dibuat"
slug: 323-cara-membuat-day-260-ati-ayam-masak-santan-berempah-14-month-yang-nikmat-dan-mudah-dibuat
date: 2021-04-16T08:23:21.768Z
image: https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg
author: Herbert Murphy
ratingvalue: 4.8
reviewcount: 7
recipeingredient:
- "1 buah ati ayam ungkep           lihat resep"
- "1 batang kacang panjang potong2"
- "1/2 bagian oyong potong2"
- "1 siung bawang putih iris tipis"
- "2 buah bawang merah iris tipis"
- "1 batang serai geprek"
- "1/4 sdt kayumanis bubuk"
- "1/4 sdt pala bubuk"
- "1/4 sdt kunyit bubuk"
- "1/4 sdt ketumbar bubuk"
- "1 sdm minyak samin"
- "1 sdm santan instan"
- "1 batang seledri cincang halus"
- "Sejumput garam"
- "200 ml air"
recipeinstructions:
- "Lelehkan minyak samin. Tumis bawang merah dan bawang putih hingga harum. Masukkan serai, kayumanis bubuk, pala bubuk, kunyit bubuk, ketumbar bubuk dan sedikit air. Masak sekitar 1 menit. Tambahkan sisa air, masak hingga mendidih."
- "Masukkan kacang panjang. Masak hingga air berkurang setengahnya. Masukkan oyong dan ati ayam, masak hingga air hampir habis."
- "Tambahkan santan instan dan seledri. Aduk rata. Masak sebentar, matikan api. Tambahkan garam, aduk rata."
- "Sajikan dengan nasi putih hangat."
categories:
- Resep
tags:
- day
- 260
- ati

katakunci: day 260 ati 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dinner

---


![Day. 260 Ati Ayam Masak Santan Berempah (14 month+)](https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg)

Jika anda seorang istri, mempersiapkan panganan menggugah selera untuk keluarga merupakan suatu hal yang mengasyikan bagi kita sendiri. Kewajiban seorang istri bukan cuman mengerjakan pekerjaan rumah saja, tapi anda juga wajib menyediakan kebutuhan nutrisi terpenuhi dan masakan yang disantap orang tercinta wajib nikmat.

Di waktu  sekarang, anda memang dapat memesan santapan instan walaupun tidak harus susah mengolahnya terlebih dahulu. Tetapi banyak juga lho orang yang memang ingin memberikan yang terlezat bagi keluarganya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan kesukaan keluarga. 



Apakah kamu salah satu penyuka day. 260 ati ayam masak santan berempah (14 month+)?. Asal kamu tahu, day. 260 ati ayam masak santan berempah (14 month+) adalah makanan khas di Nusantara yang kini disenangi oleh setiap orang dari berbagai daerah di Indonesia. Kalian bisa menghidangkan day. 260 ati ayam masak santan berempah (14 month+) sendiri di rumah dan dapat dijadikan camilan kegemaranmu di akhir pekanmu.

Kalian jangan bingung untuk menyantap day. 260 ati ayam masak santan berempah (14 month+), sebab day. 260 ati ayam masak santan berempah (14 month+) tidak sulit untuk dicari dan anda pun bisa menghidangkannya sendiri di tempatmu. day. 260 ati ayam masak santan berempah (14 month+) dapat dimasak lewat bermacam cara. Kini ada banyak banget resep kekinian yang menjadikan day. 260 ati ayam masak santan berempah (14 month+) semakin lebih nikmat.

Resep day. 260 ati ayam masak santan berempah (14 month+) pun mudah dihidangkan, lho. Anda tidak perlu capek-capek untuk memesan day. 260 ati ayam masak santan berempah (14 month+), tetapi Anda dapat menyajikan ditempatmu. Bagi Kamu yang hendak membuatnya, berikut ini cara untuk membuat day. 260 ati ayam masak santan berempah (14 month+) yang nikamat yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Day. 260 Ati Ayam Masak Santan Berempah (14 month+):

1. Siapkan 1 buah ati ayam ungkep           (lihat resep)
1. Sediakan 1 batang kacang panjang, potong2
1. Gunakan 1/2 bagian oyong, potong2
1. Siapkan 1 siung bawang putih, iris tipis
1. Gunakan 2 buah bawang merah, iris tipis
1. Gunakan 1 batang serai, geprek
1. Ambil 1/4 sdt kayumanis bubuk
1. Ambil 1/4 sdt pala bubuk
1. Gunakan 1/4 sdt kunyit bubuk
1. Ambil 1/4 sdt ketumbar bubuk
1. Sediakan 1 sdm minyak samin
1. Siapkan 1 sdm santan instan
1. Siapkan 1 batang seledri, cincang halus
1. Ambil Sejumput garam
1. Siapkan 200 ml air




<!--inarticleads2-->

##### Langkah-langkah membuat Day. 260 Ati Ayam Masak Santan Berempah (14 month+):

1. Lelehkan minyak samin. Tumis bawang merah dan bawang putih hingga harum. Masukkan serai, kayumanis bubuk, pala bubuk, kunyit bubuk, ketumbar bubuk dan sedikit air. Masak sekitar 1 menit. Tambahkan sisa air, masak hingga mendidih.
1. Masukkan kacang panjang. Masak hingga air berkurang setengahnya. Masukkan oyong dan ati ayam, masak hingga air hampir habis.
1. Tambahkan santan instan dan seledri. Aduk rata. Masak sebentar, matikan api. Tambahkan garam, aduk rata.
1. Sajikan dengan nasi putih hangat.




Wah ternyata resep day. 260 ati ayam masak santan berempah (14 month+) yang enak tidak rumit ini gampang sekali ya! Anda Semua mampu menghidangkannya. Cara buat day. 260 ati ayam masak santan berempah (14 month+) Sangat cocok banget untuk anda yang baru akan belajar memasak ataupun bagi kalian yang telah ahli dalam memasak.

Apakah kamu ingin mencoba bikin resep day. 260 ati ayam masak santan berempah (14 month+) nikmat simple ini? Kalau anda mau, ayo kalian segera menyiapkan alat-alat dan bahan-bahannya, kemudian buat deh Resep day. 260 ati ayam masak santan berempah (14 month+) yang lezat dan tidak rumit ini. Sangat gampang kan. 

Maka dari itu, ketimbang anda berlama-lama, ayo langsung aja bikin resep day. 260 ati ayam masak santan berempah (14 month+) ini. Pasti kalian tak akan nyesel sudah bikin resep day. 260 ati ayam masak santan berempah (14 month+) lezat sederhana ini! Selamat mencoba dengan resep day. 260 ati ayam masak santan berempah (14 month+) lezat tidak rumit ini di tempat tinggal kalian sendiri,ya!.

