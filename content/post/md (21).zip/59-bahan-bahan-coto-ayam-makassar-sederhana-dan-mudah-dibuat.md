---
description: "Bahan-bahan Coto Ayam Makassar Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Coto Ayam Makassar Sederhana dan Mudah Dibuat"
slug: 59-bahan-bahan-coto-ayam-makassar-sederhana-dan-mudah-dibuat
date: 2021-01-24T21:47:33.043Z
image: https://img-global.cpcdn.com/recipes/15bedd810deba4a6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/15bedd810deba4a6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/15bedd810deba4a6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Adele Foster
ratingvalue: 5
reviewcount: 12
recipeingredient:
- "1/2 ekor ayam"
- "2 batang daun bawang"
- "2-3 buah jeruk nipis"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "1 liter air"
- "Secukupnya minyak goreng"
- "Secukupnya gula pasir dan garam"
- "1/2 bulat gula merah"
- " 1 Bumbu halus"
- "10 butir bawang merah"
- "5 siung bawang putih"
- "2 butir kemiri sangrai"
- "1 sdt ketumbar sangrai"
- "2 ruas kunyit bakar"
- " 2 Bumbu halus"
- "5 sdm kacang tanah goreng sy 2 sdm"
- " Bahan tambahan lain"
- " Sambal cabai"
- " Kecap manis"
- " Tomat"
- " Sayur kol iris halus"
- " Kentang goreng"
- " Jeruk nipis"
recipeinstructions:
- "Siapkan bahan, cuci bersih ayam dan semua bahan, baluri ayam dengan jeruk nipis selama 10 menit, bilas sisihkan."
- "Rebus air, tunggu mendidih, masukkan ayam, masak sampai kaldu ayam keluar."
- "Haluskan bumbu, tambahkan sedikit sereh, haluskan, kemudian haluskan juga kacang goreng. Sisihkan."
- "Panaskan secukupnya minyak, tumis bumbu halus, masukkan sereh, lengkuas, daun jeruk, daun salam, masak sampai harum, masukkan kacang, masak sampai mengental. Matikan kompor."
- "Masukkan bumbu yg sudah ditumis ke dalam rebusan air, masak kurang lebih 15 menit agar ayam terasa sedikit berbumbu, lalu tiriskan ayam."
- "Tambahkan irisan daun bawang, gula dan garam, masak smpai air agak menyusut, sambil sesekali diaduk, tes rasa."
- "Goreng ayam sampai kuning kecokelatan. Angakt tiriskan."
- "Penyajian. Suir suir ayam, tambahkan sayur kol, siram kuah coto, tambahkan tomat, irisan daun bawang dan kentang goreng. Siap dinikmati selagi hangat."
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 121 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner

---


![Coto Ayam Makassar](https://img-global.cpcdn.com/recipes/15bedd810deba4a6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyajikan olahan menggugah selera kepada orang tercinta adalah hal yang memuaskan untuk kita sendiri. Tugas seorang ibu Tidak hanya menjaga rumah saja, tapi kamu pun harus memastikan keperluan nutrisi terpenuhi dan hidangan yang dimakan anak-anak harus lezat.

Di era  sekarang, kamu sebenarnya dapat memesan olahan instan walaupun tidak harus susah membuatnya terlebih dahulu. Namun ada juga lho orang yang selalu ingin menghidangkan yang terbaik bagi orang yang dicintainya. Sebab, memasak yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan selera keluarga. 



Apakah anda merupakan seorang penggemar coto ayam makassar?. Asal kamu tahu, coto ayam makassar merupakan sajian khas di Nusantara yang sekarang disenangi oleh banyak orang di hampir setiap wilayah di Indonesia. Kamu bisa menghidangkan coto ayam makassar sendiri di rumahmu dan boleh dijadikan camilan favoritmu di akhir pekan.

Kita tidak usah bingung untuk menyantap coto ayam makassar, lantaran coto ayam makassar sangat mudah untuk didapatkan dan kalian pun dapat membuatnya sendiri di tempatmu. coto ayam makassar bisa dimasak memalui beraneka cara. Kini pun ada banyak resep kekinian yang menjadikan coto ayam makassar semakin lebih mantap.

Resep coto ayam makassar juga mudah untuk dibikin, lho. Anda tidak perlu ribet-ribet untuk memesan coto ayam makassar, lantaran Anda mampu menghidangkan ditempatmu. Untuk Kamu yang ingin menghidangkannya, di bawah ini adalah cara untuk menyajikan coto ayam makassar yang mantab yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Coto Ayam Makassar:

1. Siapkan 1/2 ekor ayam
1. Siapkan 2 batang daun bawang
1. Ambil 2-3 buah jeruk nipis
1. Siapkan 3 lembar daun salam
1. Gunakan 3 lembar daun jeruk
1. Sediakan 1 liter air
1. Ambil Secukupnya minyak goreng
1. Sediakan Secukupnya gula pasir dan garam
1. Ambil 1/2 bulat gula merah
1. Ambil  1 Bumbu halus
1. Sediakan 10 butir bawang merah
1. Sediakan 5 siung bawang putih
1. Siapkan 2 butir kemiri (sangrai)
1. Siapkan 1 sdt ketumbar (sangrai)
1. Siapkan 2 ruas kunyit (bakar)
1. Ambil  2 Bumbu halus
1. Siapkan 5 sdm kacang tanah (goreng) (sy 2 sdm)
1. Gunakan  Bahan tambahan lain
1. Ambil  Sambal cabai
1. Ambil  Kecap manis
1. Ambil  Tomat
1. Siapkan  Sayur kol (iris halus)
1. Gunakan  Kentang goreng
1. Gunakan  Jeruk nipis




<!--inarticleads2-->

##### Langkah-langkah membuat Coto Ayam Makassar:

1. Siapkan bahan, cuci bersih ayam dan semua bahan, baluri ayam dengan jeruk nipis selama 10 menit, bilas sisihkan.
1. Rebus air, tunggu mendidih, masukkan ayam, masak sampai kaldu ayam keluar.
1. Haluskan bumbu, tambahkan sedikit sereh, haluskan, kemudian haluskan juga kacang goreng. Sisihkan.
1. Panaskan secukupnya minyak, tumis bumbu halus, masukkan sereh, lengkuas, daun jeruk, daun salam, masak sampai harum, masukkan kacang, masak sampai mengental. Matikan kompor.
1. Masukkan bumbu yg sudah ditumis ke dalam rebusan air, masak kurang lebih 15 menit agar ayam terasa sedikit berbumbu, lalu tiriskan ayam.
1. Tambahkan irisan daun bawang, gula dan garam, masak smpai air agak menyusut, sambil sesekali diaduk, tes rasa.
1. Goreng ayam sampai kuning kecokelatan. Angakt tiriskan.
1. Penyajian. Suir suir ayam, tambahkan sayur kol, siram kuah coto, tambahkan tomat, irisan daun bawang dan kentang goreng. Siap dinikmati selagi hangat.




Wah ternyata cara buat coto ayam makassar yang enak tidak rumit ini enteng banget ya! Kita semua bisa memasaknya. Cara buat coto ayam makassar Cocok sekali buat kita yang baru akan belajar memasak ataupun juga untuk kalian yang telah lihai dalam memasak.

Tertarik untuk mencoba membuat resep coto ayam makassar lezat tidak rumit ini? Kalau tertarik, ayo kalian segera buruan siapkan peralatan dan bahan-bahannya, lantas buat deh Resep coto ayam makassar yang mantab dan tidak rumit ini. Betul-betul taidak sulit kan. 

Oleh karena itu, daripada anda berfikir lama-lama, maka kita langsung hidangkan resep coto ayam makassar ini. Dijamin kamu tiidak akan menyesal bikin resep coto ayam makassar lezat tidak ribet ini! Selamat berkreasi dengan resep coto ayam makassar mantab tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

