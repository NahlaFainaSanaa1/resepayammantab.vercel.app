---
description: "Bahan-bahan Eggplant Lasagna yang lezat Untuk Jualan"
title: "Bahan-bahan Eggplant Lasagna yang lezat Untuk Jualan"
slug: 177-bahan-bahan-eggplant-lasagna-yang-lezat-untuk-jualan
date: 2021-06-06T02:20:13.660Z
image: https://img-global.cpcdn.com/recipes/afec631ccd3b08cf/680x482cq70/eggplant-lasagna-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/afec631ccd3b08cf/680x482cq70/eggplant-lasagna-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/afec631ccd3b08cf/680x482cq70/eggplant-lasagna-foto-resep-utama.jpg
author: Lulu Walker
ratingvalue: 3.3
reviewcount: 12
recipeingredient:
- "7-8 buah terong ungu ukuran sedang cuci bersih iris2 tipis vertikal"
- "6-7 buah jamur champignon segar cuci bersih iris2 tipis vertikal"
- "250 gr mozzarella cheese iris2 tipis vertikal"
- "Secukupnya bubuk Parmesan cheese"
- " Marinara Sauce"
- "15 buah tomat ukuran sedang cuci bersih iris2 kecil blender kasar"
- "1 buah bawang bombay kupas cuci cincang halus"
- "3 buah bawang putih kupas cuci cincang halus"
- "3 buah cabe rawit cuci cincang tipis"
- "Secukupnya Dried thyme"
- "Secukupnya dried basil"
- "Secukupnya Dried parsley"
- "Secukupnya Dried rosemary"
- "Secukupnya pala bubuk"
- "Secukupnya Bubuk black pepper"
- "secukupnya Kaldu sapi bubuk saya pakai pura"
- "Secukupnya garam"
- "secukupnya Gula"
- "Secukupnya minyak untuk menumis"
- " Layer Daging Tumis"
- "450 gr daging cacah"
- "Secukupnya pala bubuk"
- "Secukupnya garam"
- "Secukupnya minyak untuk menumis"
- " White Ricotta Sauce"
- "250 gr Ricotta cheese"
- "1 butir telur ayam"
- "Secukupnya dried thyme"
- "Secukupnya pala bubuk"
recipeinstructions:
- "Tata terong di atas loyang. Taburi dengan sejumput garam secara merata. Diamkan 30 menit untuk masing2 sisinya. Panaskan oven dengan api bawah 180 derajat celcius. Masukkan terong ke dalam oven, panggang kurleb 5-10 menit. Sisihkan."
- "Lanjutkan dengan membuat marinara sauce. Tumis bawang putih sampai harum, masukkan bawang bombay, tumis sampai kecoklatan. Masukkan cabai rawit. Tambahkan tomat hingga mendidih. Tambahkan dried thyme, dried parsley, dried basil, dried rosemary, pala, black pepper, kaldu sapi, garam dan gula. Cicipi, koreksi rasa. Lanjutkan merebus sauce dengan api kecil hingga air berkurang 1/3. Sisihkan."
- "Tumis daging cacah, tambahkan pala dan garam. Tambahkan 4 sendok sayur sauce marinara. Tumis hingga rata dan daging matang, sisihkan."
- "Lanjutkan dengan membuat white ricotta sauce. Campurkan ricotta cheese, telur dan tambahkan dried thyme dan bubuk pala. Aduk hingga merata. Sisihkan."
- "Siapkan pyrex ukuran sedang. Susun terong dengan merata di dasar pyrex. Layer dengan sauce marinara. Kemudian layer dengan daging tumisan. Kemudian susun jamur champignon secara merata diatas tumisan daging. Susun rapi mozarella cheese di atas jamur. Selanjutnya layer dengan white ricotta sauce diatasnya. Taburi parmesan cheese diatas sauce ricotta hingga merata. Ulangi proses layering hingga semua bahan habis. Tutup pyrex dengan aluminium foil."
- "Masukkan pyrex ke dalam oven yang sudah dipanaskan selama 15 menit dengan suhu api atas bawah 180 derajat. Panggang lasagna selama 45 menit, buka aluminium foil dan lanjutkan panggang selama 15 menit atau hingga lapisan ricotta sauce yg paling atas berwarna kecoklatan."
categories:
- Resep
tags:
- eggplant
- lasagna

katakunci: eggplant lasagna 
nutrition: 200 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dinner

---


![Eggplant Lasagna](https://img-global.cpcdn.com/recipes/afec631ccd3b08cf/680x482cq70/eggplant-lasagna-foto-resep-utama.jpg)

Jika kalian seorang ibu, menyuguhkan olahan enak buat famili adalah suatu hal yang mengasyikan untuk anda sendiri. Tugas seorang istri Tidak cuma menjaga rumah saja, tapi kamu pun harus menyediakan keperluan nutrisi terpenuhi dan juga panganan yang dimakan orang tercinta wajib nikmat.

Di waktu  saat ini, anda memang mampu membeli hidangan yang sudah jadi meski tanpa harus repot membuatnya terlebih dahulu. Tetapi ada juga orang yang memang ingin memberikan yang terenak bagi orang tercintanya. Pasalnya, memasak yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai makanan kesukaan orang tercinta. 



Mungkinkah anda seorang penyuka eggplant lasagna?. Tahukah kamu, eggplant lasagna merupakan sajian khas di Indonesia yang kini disukai oleh kebanyakan orang di berbagai daerah di Nusantara. Kamu dapat memasak eggplant lasagna sendiri di rumahmu dan pasti jadi makanan kesukaanmu di akhir pekanmu.

Kita tak perlu bingung untuk mendapatkan eggplant lasagna, lantaran eggplant lasagna gampang untuk dicari dan kamu pun boleh membuatnya sendiri di rumah. eggplant lasagna boleh dibuat dengan bermacam cara. Kini ada banyak sekali resep modern yang membuat eggplant lasagna semakin lebih enak.

Resep eggplant lasagna juga mudah sekali dibikin, lho. Anda jangan capek-capek untuk membeli eggplant lasagna, sebab Kamu mampu membuatnya ditempatmu. Bagi Kamu yang hendak mencobanya, berikut cara untuk membuat eggplant lasagna yang lezat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Eggplant Lasagna:

1. Sediakan 7-8 buah terong ungu ukuran sedang, cuci bersih, iris2 tipis vertikal
1. Ambil 6-7 buah jamur champignon segar, cuci bersih, iris2 tipis vertikal
1. Ambil 250 gr mozzarella cheese, iris2 tipis vertikal
1. Ambil Secukupnya bubuk Parmesan cheese
1. Ambil  Marinara Sauce
1. Siapkan 15 buah tomat ukuran sedang, cuci bersih, iris2 kecil, blender kasar
1. Sediakan 1 buah bawang bombay, kupas, cuci, cincang halus
1. Gunakan 3 buah bawang putih, kupas, cuci, cincang halus
1. Sediakan 3 buah cabe rawit, cuci, cincang tipis
1. Gunakan Secukupnya Dried thyme
1. Siapkan Secukupnya dried basil
1. Gunakan Secukupnya Dried parsley
1. Gunakan Secukupnya Dried rosemary
1. Siapkan Secukupnya pala bubuk
1. Ambil Secukupnya Bubuk black pepper
1. Ambil secukupnya Kaldu sapi bubuk (saya pakai pura)
1. Sediakan Secukupnya garam
1. Sediakan secukupnya Gula
1. Sediakan Secukupnya minyak untuk menumis
1. Gunakan  Layer Daging Tumis
1. Gunakan 450 gr daging cacah
1. Sediakan Secukupnya pala bubuk
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya minyak untuk menumis
1. Gunakan  White Ricotta Sauce
1. Gunakan 250 gr Ricotta cheese
1. Sediakan 1 butir telur ayam
1. Ambil Secukupnya dried thyme
1. Sediakan Secukupnya pala bubuk




<!--inarticleads2-->

##### Cara membuat Eggplant Lasagna:

1. Tata terong di atas loyang. Taburi dengan sejumput garam secara merata. Diamkan 30 menit untuk masing2 sisinya. Panaskan oven dengan api bawah 180 derajat celcius. Masukkan terong ke dalam oven, panggang kurleb 5-10 menit. Sisihkan.
1. Lanjutkan dengan membuat marinara sauce. Tumis bawang putih sampai harum, masukkan bawang bombay, tumis sampai kecoklatan. Masukkan cabai rawit. Tambahkan tomat hingga mendidih. Tambahkan dried thyme, dried parsley, dried basil, dried rosemary, pala, black pepper, kaldu sapi, garam dan gula. Cicipi, koreksi rasa. Lanjutkan merebus sauce dengan api kecil hingga air berkurang 1/3. Sisihkan.
1. Tumis daging cacah, tambahkan pala dan garam. Tambahkan 4 sendok sayur sauce marinara. Tumis hingga rata dan daging matang, sisihkan.
1. Lanjutkan dengan membuat white ricotta sauce. Campurkan ricotta cheese, telur dan tambahkan dried thyme dan bubuk pala. Aduk hingga merata. Sisihkan.
1. Siapkan pyrex ukuran sedang. Susun terong dengan merata di dasar pyrex. Layer dengan sauce marinara. Kemudian layer dengan daging tumisan. Kemudian susun jamur champignon secara merata diatas tumisan daging. Susun rapi mozarella cheese di atas jamur. Selanjutnya layer dengan white ricotta sauce diatasnya. Taburi parmesan cheese diatas sauce ricotta hingga merata. Ulangi proses layering hingga semua bahan habis. Tutup pyrex dengan aluminium foil.
1. Masukkan pyrex ke dalam oven yang sudah dipanaskan selama 15 menit dengan suhu api atas bawah 180 derajat. Panggang lasagna selama 45 menit, buka aluminium foil dan lanjutkan panggang selama 15 menit atau hingga lapisan ricotta sauce yg paling atas berwarna kecoklatan.




Wah ternyata cara membuat eggplant lasagna yang enak tidak ribet ini gampang sekali ya! Semua orang mampu mencobanya. Cara Membuat eggplant lasagna Sangat cocok banget buat kalian yang baru mau belajar memasak maupun untuk anda yang sudah jago dalam memasak.

Tertarik untuk mencoba membikin resep eggplant lasagna enak tidak ribet ini? Kalau kamu mau, ayo kamu segera buruan siapin alat dan bahan-bahannya, kemudian buat deh Resep eggplant lasagna yang lezat dan simple ini. Benar-benar gampang kan. 

Jadi, daripada kamu berfikir lama-lama, hayo langsung aja buat resep eggplant lasagna ini. Pasti anda tiidak akan nyesel sudah membuat resep eggplant lasagna enak simple ini! Selamat berkreasi dengan resep eggplant lasagna enak sederhana ini di tempat tinggal kalian masing-masing,oke!.

