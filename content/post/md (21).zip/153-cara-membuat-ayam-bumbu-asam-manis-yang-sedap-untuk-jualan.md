---
description: "Cara membuat Ayam bumbu asam manis yang sedap Untuk Jualan"
title: "Cara membuat Ayam bumbu asam manis yang sedap Untuk Jualan"
slug: 153-cara-membuat-ayam-bumbu-asam-manis-yang-sedap-untuk-jualan
date: 2021-06-30T21:02:54.971Z
image: https://img-global.cpcdn.com/recipes/81cead8d664d4c49/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/81cead8d664d4c49/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/81cead8d664d4c49/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
author: Celia George
ratingvalue: 4.1
reviewcount: 4
recipeingredient:
- "1/4 kg dada ayam fillet"
- "1/2 buah bawang bombay"
- "1 buah daun bawang"
- "3 buah bawang merah"
- "5 buah bawang putih"
- "5 sendok saus tomat"
- "5 sendok saus extra pedas"
- "5 cabai kecil"
- "5 cabai keriting"
- " Tepung terigu"
- "1 sdt garam"
- "1 butir telur"
recipeinstructions:
- "Potong ayam sesuai selera tanpa di bumbui dahulu."
- "Siapkan adonan tepung basah dan tepung kering untuk membalut ayam. Jangan menggunakan tepung serbaguna agar tidak terlalu keasinan. Masukan ayam ke telung basah kemudian tepung kering dan goreng dengan api sedang agar matang hingga kedalam dan tidak gosong diluar."
- "Potong bawang bombay, bawang merah, bawang putih, cabai kecil dan cabai keriting"
- "Panaskan minyak sedikit dan tumis semua bumbu yang dipotong tadi hingga harum"
- "Masukan ayam yang sudah digoreng ke dalam wajan."
- "Tambahkan saus tomat, saus extra pedas dan garam."
- "Jika rasanya sudah pas, hiasi dengan daun bawang."
categories:
- Resep
tags:
- ayam
- bumbu
- asam

katakunci: ayam bumbu asam 
nutrition: 140 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam bumbu asam manis](https://img-global.cpcdn.com/recipes/81cead8d664d4c49/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan santapan sedap buat orang tercinta merupakan hal yang membahagiakan untuk kamu sendiri. Peran seorang istri bukan sekadar menjaga rumah saja, tetapi kamu pun wajib memastikan keperluan gizi terpenuhi dan masakan yang dimakan orang tercinta harus menggugah selera.

Di era  sekarang, kamu sebenarnya dapat mengorder masakan instan meski tanpa harus ribet mengolahnya terlebih dahulu. Tapi ada juga lho mereka yang memang mau menyajikan yang terlezat untuk orang yang dicintainya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan masakan kesukaan orang tercinta. 



Apakah anda salah satu penyuka ayam bumbu asam manis?. Tahukah kamu, ayam bumbu asam manis adalah sajian khas di Nusantara yang sekarang disenangi oleh setiap orang di berbagai daerah di Indonesia. Anda dapat memasak ayam bumbu asam manis hasil sendiri di rumah dan pasti jadi makanan kesenanganmu di akhir pekanmu.

Kalian tidak usah bingung untuk memakan ayam bumbu asam manis, karena ayam bumbu asam manis tidak sulit untuk didapatkan dan kalian pun bisa membuatnya sendiri di tempatmu. ayam bumbu asam manis bisa dimasak memalui beraneka cara. Saat ini sudah banyak sekali cara modern yang menjadikan ayam bumbu asam manis lebih lezat.

Resep ayam bumbu asam manis pun gampang untuk dibikin, lho. Kalian tidak usah capek-capek untuk membeli ayam bumbu asam manis, lantaran Kita bisa menyiapkan ditempatmu. Bagi Anda yang mau mencobanya, berikut cara untuk menyajikan ayam bumbu asam manis yang lezat yang bisa Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam bumbu asam manis:

1. Siapkan 1/4 kg dada ayam fillet
1. Sediakan 1/2 buah bawang bombay
1. Gunakan 1 buah daun bawang
1. Gunakan 3 buah bawang merah
1. Ambil 5 buah bawang putih
1. Siapkan 5 sendok saus tomat
1. Siapkan 5 sendok saus extra pedas
1. Sediakan 5 cabai kecil
1. Ambil 5 cabai keriting
1. Siapkan  Tepung terigu
1. Ambil 1 sdt garam
1. Sediakan 1 butir telur




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam bumbu asam manis:

1. Potong ayam sesuai selera tanpa di bumbui dahulu.
1. Siapkan adonan tepung basah dan tepung kering untuk membalut ayam. Jangan menggunakan tepung serbaguna agar tidak terlalu keasinan. Masukan ayam ke telung basah kemudian tepung kering dan goreng dengan api sedang agar matang hingga kedalam dan tidak gosong diluar.
1. Potong bawang bombay, bawang merah, bawang putih, cabai kecil dan cabai keriting
1. Panaskan minyak sedikit dan tumis semua bumbu yang dipotong tadi hingga harum
1. Masukan ayam yang sudah digoreng ke dalam wajan.
1. Tambahkan saus tomat, saus extra pedas dan garam.
1. Jika rasanya sudah pas, hiasi dengan daun bawang.




Wah ternyata resep ayam bumbu asam manis yang lezat sederhana ini enteng sekali ya! Kita semua bisa memasaknya. Resep ayam bumbu asam manis Cocok sekali buat kita yang baru mau belajar memasak ataupun untuk kamu yang sudah hebat memasak.

Tertarik untuk mulai mencoba membikin resep ayam bumbu asam manis enak simple ini? Kalau tertarik, ayo kamu segera buruan siapkan peralatan dan bahan-bahannya, lalu buat deh Resep ayam bumbu asam manis yang nikmat dan sederhana ini. Benar-benar mudah kan. 

Maka dari itu, daripada anda berfikir lama-lama, maka kita langsung saja hidangkan resep ayam bumbu asam manis ini. Dijamin kalian tak akan nyesel membuat resep ayam bumbu asam manis mantab simple ini! Selamat mencoba dengan resep ayam bumbu asam manis enak simple ini di tempat tinggal kalian masing-masing,oke!.

