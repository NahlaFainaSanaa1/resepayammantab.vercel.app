---
description: "Resep Soto Ayam Kampung yang nikmat dan Mudah Dibuat"
title: "Resep Soto Ayam Kampung yang nikmat dan Mudah Dibuat"
slug: 246-resep-soto-ayam-kampung-yang-nikmat-dan-mudah-dibuat
date: 2021-06-17T20:49:51.445Z
image: https://img-global.cpcdn.com/recipes/b35fd156cd40aaf8/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b35fd156cd40aaf8/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b35fd156cd40aaf8/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
author: Bruce Carroll
ratingvalue: 4.8
reviewcount: 9
recipeingredient:
- "1 ekor ayam kampung potong cuci dan rebus sebentar utk membuang busanya potong2"
- "2 buah kentang potong dadu"
- "2 liter air matang"
- " Bumbu geprek "
- "2 buah serai"
- "5 cm jahe"
- "3 cm lengkuas"
- "4 lembar daun salam"
- "3 lembar daun jeruk purut"
- " Bumbu halus"
- "10 buah cabe besar"
- "1 ruas kunyit"
- "10 buah bawang merah"
- "8 buah bawang putih"
- "4 buah kemiri sangrai"
- "1 sdm ketumbar sangrai"
- "1/2 sdt merica putih sangrai"
- "secukupnya Minyak goreng"
- " Garam"
- " Gula"
- " Kaldu ayam"
recipeinstructions:
- "Siapkan bahan."
- "Didihkan air dan masukan ayam. Masak. Kemudian tumis bumbu dg api kecil hingga wangi dan agak kekuningan. Masukan ke dalam air dan ayam yg dididihkan."
- "Masak hingga ayam lembut dan beri garam serta bumbu lainnya.  Setelah matang maka bisa lgsg dimakan atau dicampur ke bihun."
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 171 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam Kampung](https://img-global.cpcdn.com/recipes/b35fd156cd40aaf8/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan santapan mantab pada orang tercinta merupakan hal yang memuaskan bagi anda sendiri. Kewajiban seorang  wanita Tidak saja menjaga rumah saja, namun anda pun harus menyediakan kebutuhan nutrisi terpenuhi dan juga masakan yang dikonsumsi keluarga tercinta wajib sedap.

Di masa  saat ini, kalian memang dapat mengorder santapan yang sudah jadi meski tanpa harus capek memasaknya dulu. Tetapi banyak juga mereka yang selalu ingin menyajikan yang terbaik untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai dengan selera orang tercinta. 



Apakah anda merupakan seorang penyuka soto ayam kampung?. Asal kamu tahu, soto ayam kampung merupakan sajian khas di Indonesia yang kini digemari oleh orang-orang di hampir setiap daerah di Nusantara. Kamu dapat membuat soto ayam kampung hasil sendiri di rumahmu dan boleh dijadikan camilan kegemaranmu di hari libur.

Anda tidak perlu bingung jika kamu ingin menyantap soto ayam kampung, karena soto ayam kampung tidak sukar untuk dicari dan juga kamu pun boleh membuatnya sendiri di tempatmu. soto ayam kampung dapat diolah dengan beragam cara. Kini ada banyak banget resep kekinian yang membuat soto ayam kampung semakin lebih lezat.

Resep soto ayam kampung juga gampang untuk dibikin, lho. Kalian tidak usah repot-repot untuk memesan soto ayam kampung, karena Anda dapat menyajikan sendiri di rumah. Untuk Kalian yang mau membuatnya, inilah resep membuat soto ayam kampung yang nikamat yang bisa Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Soto Ayam Kampung:

1. Gunakan 1 ekor ayam kampung, potong, cuci dan rebus sebentar utk membuang busanya, potong2
1. Ambil 2 buah kentang, potong dadu
1. Sediakan 2 liter air matang
1. Siapkan  Bumbu geprek :
1. Siapkan 2 buah serai
1. Sediakan 5 cm jahe
1. Sediakan 3 cm lengkuas
1. Sediakan 4 lembar daun salam
1. Siapkan 3 lembar daun jeruk purut
1. Sediakan  Bumbu halus
1. Gunakan 10 buah cabe besar
1. Ambil 1 ruas kunyit
1. Sediakan 10 buah bawang merah
1. Ambil 8 buah bawang putih
1. Siapkan 4 buah kemiri, sangrai
1. Sediakan 1 sdm ketumbar, sangrai
1. Siapkan 1/2 sdt merica putih, sangrai
1. Sediakan secukupnya Minyak goreng
1. Ambil  Garam
1. Ambil  Gula
1. Gunakan  Kaldu ayam




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Kampung:

1. Siapkan bahan.
1. Didihkan air dan masukan ayam. Masak. Kemudian tumis bumbu dg api kecil hingga wangi dan agak kekuningan. Masukan ke dalam air dan ayam yg dididihkan.
1. Masak hingga ayam lembut dan beri garam serta bumbu lainnya.  - Setelah matang maka bisa lgsg dimakan atau dicampur ke bihun.




Wah ternyata cara buat soto ayam kampung yang lezat sederhana ini enteng banget ya! Kamu semua mampu membuatnya. Cara buat soto ayam kampung Sesuai sekali buat kita yang baru akan belajar memasak ataupun juga untuk kalian yang telah hebat dalam memasak.

Apakah kamu ingin mulai mencoba membuat resep soto ayam kampung mantab simple ini? Kalau anda tertarik, ayo kalian segera menyiapkan alat-alat dan bahannya, lantas buat deh Resep soto ayam kampung yang enak dan tidak ribet ini. Sungguh gampang kan. 

Maka, daripada kalian berfikir lama-lama, maka kita langsung saja sajikan resep soto ayam kampung ini. Dijamin anda tak akan menyesal bikin resep soto ayam kampung lezat sederhana ini! Selamat berkreasi dengan resep soto ayam kampung nikmat tidak rumit ini di rumah sendiri,oke!.

