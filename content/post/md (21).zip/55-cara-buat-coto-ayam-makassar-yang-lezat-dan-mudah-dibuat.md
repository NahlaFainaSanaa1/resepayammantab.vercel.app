---
description: "Cara buat Coto ayam makassar yang lezat dan Mudah Dibuat"
title: "Cara buat Coto ayam makassar yang lezat dan Mudah Dibuat"
slug: 55-cara-buat-coto-ayam-makassar-yang-lezat-dan-mudah-dibuat
date: 2021-04-18T04:27:17.250Z
image: https://img-global.cpcdn.com/recipes/8893af18e7df99c6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8893af18e7df99c6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8893af18e7df99c6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Jorge Hall
ratingvalue: 3
reviewcount: 3
recipeingredient:
- "1 ekor ayam recom ayam kampung"
- "1/2 liter kacang tanah goreng kLw mw Lbh kental blh tambah"
- "10 siung bawang putih"
- "14 siung bawang merah"
- "8 batang sereh lbh banyak lbih harum dan enak"
- "2 ruas Lengkuas 1 d geprek 1 nya diiris spya mudah d haluskan"
- "4 biji kemiri"
- "2 sdm ketumbar"
- "1 sdm jintan putih"
- " sdikit jahe"
- " sdikit kencur"
- "1 butir pala"
- " kayu manis"
- " daun salam"
- " garam"
- " gula"
- " penyedap rasa"
- " minyak untuk menumis"
- " air untuk merebus"
- "1 bungkus bihun jagung"
- " bawang goreng"
- " daun seledri"
- " daun sup"
recipeinstructions:
- "Ayam di belah mnjadi 4 kemudian di rebus d dalam 3 Liter air. jngan Lupa kasih daun salam saat merebus, 2 lembar."
- "Setelah matang, angkat lalu tiriskan. air sisa rebusan jngn dibuang, krna itu akan jd kuahnya. masukkan 1 butir pala, lengkuas yg digeprek dan kayu manis ke dalam air rebusan. sisihkan"
- "Setelah ayamx dingin, potong sesuai selera, ambiL dagingnya saja. tuLangnya kembaLikan ke kuah bekas rebusan yg tadi."
- "Ayam yg sudah dipotong, kaLau sy potong dadu (boleh d suir kasar), digoreng tp jngn smPai kering. sisihkan."
- "Haluskan kacang tanah goreng, sisihkan."
- "Sangrai ketumbar, jintan, dan kemiri."
- "Haluskan bawang merah, bawang putih, lengkuas, sereh, ketumbar, jintan, kemiri, jahe, dan kencur."
- "Tumis bumbu halus, masukkan daun salam. setelah harum, tambahkan garam, gula, penyedap rasa."
- "Sementara itu, panaskan kembali air sisa rebusan ayam tadi."
- "Setelah bumbunya matang, masukkan kacang yg sudah dihaluskan td. Aduk hingga rata."
- "Setelah bumbu dan kacang menyatu, matikan api. kaLau airnya sdh mndidih, masukkan bumbu yg sdh di tumis tadi ke dalam kuah rebusan. aduk hingga rata."
- "Setelah mendidih, matikan api. saatnya pLating 😂"
- "Letakkan ayam goreng dan bihun d atas piring. Tuangkan kuah coto. hiasi dngan bawang goreng, daun seledri, dan daun bawang. mmmmmmm selamat makan 😉"
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 298 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dessert

---


![Coto ayam makassar](https://img-global.cpcdn.com/recipes/8893af18e7df99c6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Jika kamu seorang orang tua, menyediakan santapan lezat buat keluarga tercinta adalah hal yang mengasyikan bagi anda sendiri. Kewajiban seorang ibu Tidak cuma mengatur rumah saja, namun anda juga wajib menyediakan keperluan nutrisi tercukupi dan juga olahan yang dimakan orang tercinta wajib mantab.

Di masa  saat ini, anda memang mampu membeli panganan instan meski tanpa harus ribet membuatnya dahulu. Tapi ada juga lho orang yang selalu mau menghidangkan yang terenak bagi keluarganya. Sebab, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan selera orang tercinta. 



Mungkinkah kamu salah satu penyuka coto ayam makassar?. Tahukah kamu, coto ayam makassar merupakan makanan khas di Indonesia yang saat ini disenangi oleh banyak orang di berbagai daerah di Nusantara. Kalian bisa menghidangkan coto ayam makassar sendiri di rumahmu dan pasti jadi santapan kegemaranmu di hari liburmu.

Kita tidak perlu bingung untuk memakan coto ayam makassar, lantaran coto ayam makassar sangat mudah untuk ditemukan dan anda pun bisa membuatnya sendiri di tempatmu. coto ayam makassar dapat dibuat lewat berbagai cara. Sekarang ada banyak banget cara kekinian yang membuat coto ayam makassar semakin enak.

Resep coto ayam makassar pun mudah dibikin, lho. Kalian jangan repot-repot untuk memesan coto ayam makassar, lantaran Kalian mampu membuatnya sendiri di rumah. Untuk Kamu yang hendak menghidangkannya, di bawah ini adalah cara untuk menyajikan coto ayam makassar yang lezat yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Coto ayam makassar:

1. Gunakan 1 ekor ayam (recom ayam kampung)
1. Siapkan 1/2 liter kacang tanah goreng (kLw mw Lbh kental, blh tambah)
1. Gunakan 10 siung bawang putih
1. Ambil 14 siung bawang merah
1. Gunakan 8 batang sereh (lbh banyak lbih harum dan enak)
1. Sediakan 2 ruas Lengkuas (1 d geprek, 1 nya diiris spya mudah d haluskan)
1. Ambil 4 biji kemiri
1. Sediakan 2 sdm ketumbar
1. Siapkan 1 sdm jintan putih
1. Ambil  sdikit jahe
1. Gunakan  sdikit kencur
1. Sediakan 1 butir pala
1. Gunakan  kayu manis
1. Ambil  daun salam
1. Siapkan  garam
1. Ambil  gula
1. Ambil  penyedap rasa
1. Ambil  minyak untuk menumis
1. Sediakan  air untuk merebus
1. Sediakan 1 bungkus bihun jagung
1. Gunakan  bawang goreng
1. Siapkan  daun seledri
1. Siapkan  daun sup




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Coto ayam makassar:

1. Ayam di belah mnjadi 4 kemudian di rebus d dalam 3 Liter air. jngan Lupa kasih daun salam saat merebus, 2 lembar.
1. Setelah matang, angkat lalu tiriskan. air sisa rebusan jngn dibuang, krna itu akan jd kuahnya. masukkan 1 butir pala, lengkuas yg digeprek dan kayu manis ke dalam air rebusan. sisihkan
1. Setelah ayamx dingin, potong sesuai selera, ambiL dagingnya saja. tuLangnya kembaLikan ke kuah bekas rebusan yg tadi.
1. Ayam yg sudah dipotong, kaLau sy potong dadu (boleh d suir kasar), digoreng tp jngn smPai kering. sisihkan.
1. Haluskan kacang tanah goreng, sisihkan.
1. Sangrai ketumbar, jintan, dan kemiri.
1. Haluskan bawang merah, bawang putih, lengkuas, sereh, ketumbar, jintan, kemiri, jahe, dan kencur.
1. Tumis bumbu halus, masukkan daun salam. setelah harum, tambahkan garam, gula, penyedap rasa.
1. Sementara itu, panaskan kembali air sisa rebusan ayam tadi.
1. Setelah bumbunya matang, masukkan kacang yg sudah dihaluskan td. Aduk hingga rata.
1. Setelah bumbu dan kacang menyatu, matikan api. kaLau airnya sdh mndidih, masukkan bumbu yg sdh di tumis tadi ke dalam kuah rebusan. aduk hingga rata.
1. Setelah mendidih, matikan api. saatnya pLating 😂
1. Letakkan ayam goreng dan bihun d atas piring. Tuangkan kuah coto. hiasi dngan bawang goreng, daun seledri, dan daun bawang. mmmmmmm selamat makan 😉




Ternyata cara buat coto ayam makassar yang lezat tidak rumit ini gampang banget ya! Semua orang mampu mencobanya. Resep coto ayam makassar Sangat cocok banget buat kalian yang baru belajar memasak maupun untuk kalian yang sudah ahli memasak.

Tertarik untuk mulai mencoba buat resep coto ayam makassar nikmat tidak rumit ini? Kalau anda ingin, ayo kalian segera buruan menyiapkan peralatan dan bahannya, kemudian bikin deh Resep coto ayam makassar yang lezat dan simple ini. Sangat mudah kan. 

Oleh karena itu, daripada kita berlama-lama, hayo langsung aja hidangkan resep coto ayam makassar ini. Dijamin anda gak akan menyesal sudah buat resep coto ayam makassar mantab tidak rumit ini! Selamat berkreasi dengan resep coto ayam makassar enak tidak rumit ini di rumah masing-masing,ya!.

