---
description: "Cara buat Soto santan ayam kampung yang nikmat dan Mudah Dibuat"
title: "Cara buat Soto santan ayam kampung yang nikmat dan Mudah Dibuat"
slug: 254-cara-buat-soto-santan-ayam-kampung-yang-nikmat-dan-mudah-dibuat
date: 2021-04-21T08:17:36.699Z
image: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
author: Fred Allen
ratingvalue: 5
reviewcount: 5
recipeingredient:
- "1/2 kg ayam kampung"
- "1 bks santan cair"
- " Bahan tambahan"
- "1/2 ons soun rebus"
- "1 rb toge rebus sbntr"
- "2 rb kol rebus sebentar"
- "4 btr telor ayam rebus 20 menit"
- "1 batang sledri iris kecil"
- "2 buah jeruk limo"
- "1 buah tomat iris kasar"
- "3 batang daun bawangb iris"
- " Bawang goreng untuk taburan"
- " Bumbu halus"
- "7 siung bawang merah"
- "6 siung bawang putih"
- "4 butir kemiri"
- "1 ruas jahe"
- "1/2 ruas kunyit"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt merica biji"
- "1/2 bks ketumbar biji 500 rupiah"
- "1/2 bks jinten 500 rupiah"
- "1/2 sdt pala biji"
- "3 butir cengkeh"
- "2 butir kapulaga"
- " Bumbu cemplung"
- "1 lmbr daun salam"
- "5 lmbr daun jeruk"
- "1 buah bunga lawang"
- "1/2 potong kayu manis"
- "1/2 ruas lengkuas"
- " Sambal nya"
- "10 biji cabe rawit merah"
- " Gulagaram"
- " Dibikin goang aja"
recipeinstructions:
- "Cuci bersih ayam nya potong2 sesuai keinginan"
- "Didihkan air dan klau sdh bersih ayam ny tinggal masukan ke rebusan air tadi geplek diapi sedang slma 20 menit lalu matikan kompor ny"
- "Haluskan bumbunya boleh pkai blender atau manual aja pke coet biar wanginya nampol klo diulek sendiri mah."
- "Kalo sudah halus semua siapkan minyak di ketel tumis2 hingga harum dan klo dah setengah mateng masukan bumbu cemplung nya dan aduk2 sampe mateng dan kalo sudah mateng kasih air sedikit aja segelas misal ny"
- "Lalu hidup kan lg kompor yg ayam tdi lalu masukan si bumbu ke ayam ny bila kurang air nya boleh tambah lg sesuai selera aja dan koreksi rasa ya bun"
- "Kalo sudah siap siapkan mangkok dan masukan soto nya tata semua bahan tambahan nya.maaf aku juga pke suwiran ayam lgi biar enak aj😁"
- "Siap dihidangkan deh bunda2"
categories:
- Resep
tags:
- soto
- santan
- ayam

katakunci: soto santan ayam 
nutrition: 238 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto santan ayam kampung](https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan masakan nikmat buat keluarga adalah suatu hal yang mengasyikan bagi kita sendiri. Kewajiban seorang  wanita bukan hanya menjaga rumah saja, tapi anda juga harus memastikan kebutuhan nutrisi terpenuhi dan olahan yang dimakan orang tercinta harus menggugah selera.

Di era  sekarang, kalian sebenarnya dapat mengorder masakan yang sudah jadi walaupun tanpa harus ribet mengolahnya terlebih dahulu. Tapi banyak juga mereka yang memang ingin memberikan makanan yang terenak bagi orang yang dicintainya. Karena, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai selera keluarga tercinta. 



Mungkinkah kamu salah satu penikmat soto santan ayam kampung?. Tahukah kamu, soto santan ayam kampung merupakan hidangan khas di Indonesia yang saat ini disukai oleh orang-orang dari hampir setiap wilayah di Nusantara. Kamu bisa memasak soto santan ayam kampung buatan sendiri di rumahmu dan pasti jadi hidangan favorit di akhir pekan.

Kita tidak usah bingung jika kamu ingin menyantap soto santan ayam kampung, lantaran soto santan ayam kampung tidak sulit untuk ditemukan dan juga kalian pun boleh membuatnya sendiri di rumah. soto santan ayam kampung dapat dibuat lewat beragam cara. Kini sudah banyak banget resep kekinian yang membuat soto santan ayam kampung lebih mantap.

Resep soto santan ayam kampung juga gampang sekali dibikin, lho. Anda tidak perlu capek-capek untuk memesan soto santan ayam kampung, tetapi Kita mampu menyajikan sendiri di rumah. Bagi Anda yang ingin membuatnya, berikut ini cara untuk membuat soto santan ayam kampung yang lezat yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto santan ayam kampung:

1. Ambil 1/2 kg ayam kampung
1. Gunakan 1 bks santan cair
1. Sediakan  Bahan tambahan
1. Gunakan 1/2 ons soun rebus
1. Siapkan 1 rb toge rebus sbntr
1. Sediakan 2 rb kol rebus sebentar
1. Gunakan 4 btr telor ayam rebus 20 menit
1. Gunakan 1 batang sledri iris kecil
1. Siapkan 2 buah jeruk limo
1. Siapkan 1 buah tomat iris kasar
1. Gunakan 3 batang daun bawangb iris
1. Ambil  Bawang goreng untuk taburan
1. Gunakan  Bumbu halus
1. Siapkan 7 siung bawang merah
1. Ambil 6 siung bawang putih
1. Ambil 4 butir kemiri
1. Siapkan 1 ruas jahe
1. Siapkan 1/2 ruas kunyit
1. Gunakan 1/2 sdt kunyit bubuk
1. Gunakan 1/2 sdt merica biji
1. Sediakan 1/2 bks ketumbar biji 500 rupiah
1. Sediakan 1/2 bks jinten 500 rupiah
1. Siapkan 1/2 sdt pala biji
1. Sediakan 3 butir cengkeh
1. Sediakan 2 butir kapulaga
1. Siapkan  Bumbu cemplung
1. Siapkan 1 lmbr daun salam
1. Siapkan 5 lmbr daun jeruk
1. Sediakan 1 buah bunga lawang
1. Ambil 1/2 potong kayu manis
1. Sediakan 1/2 ruas lengkuas
1. Ambil  Sambal nya
1. Gunakan 10 biji cabe rawit merah
1. Ambil  Gula+garam
1. Siapkan  Dibikin goang aja👍🏻




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto santan ayam kampung:

1. Cuci bersih ayam nya potong2 sesuai keinginan
1. Didihkan air dan klau sdh bersih ayam ny tinggal masukan ke rebusan air tadi geplek diapi sedang slma 20 menit lalu matikan kompor ny
1. Haluskan bumbunya boleh pkai blender atau manual aja pke coet biar wanginya nampol klo diulek sendiri mah.
1. Kalo sudah halus semua siapkan minyak di ketel tumis2 hingga harum dan klo dah setengah mateng masukan bumbu cemplung nya dan aduk2 sampe mateng dan kalo sudah mateng kasih air sedikit aja segelas misal ny
1. Lalu hidup kan lg kompor yg ayam tdi lalu masukan si bumbu ke ayam ny bila kurang air nya boleh tambah lg sesuai selera aja dan koreksi rasa ya bun
1. Kalo sudah siap siapkan mangkok dan masukan soto nya tata semua bahan tambahan nya.maaf aku juga pke suwiran ayam lgi biar enak aj😁
1. Siap dihidangkan deh bunda2




Wah ternyata cara membuat soto santan ayam kampung yang enak sederhana ini gampang banget ya! Kamu semua dapat memasaknya. Resep soto santan ayam kampung Sangat sesuai sekali untuk kalian yang baru belajar memasak maupun juga bagi anda yang sudah lihai dalam memasak.

Apakah kamu mau mencoba buat resep soto santan ayam kampung nikmat simple ini? Kalau tertarik, mending kamu segera siapin alat-alat dan bahan-bahannya, maka buat deh Resep soto santan ayam kampung yang nikmat dan sederhana ini. Betul-betul taidak sulit kan. 

Maka dari itu, ketimbang anda berfikir lama-lama, yuk kita langsung buat resep soto santan ayam kampung ini. Pasti kamu tak akan nyesel membuat resep soto santan ayam kampung lezat tidak rumit ini! Selamat mencoba dengan resep soto santan ayam kampung mantab tidak rumit ini di rumah kalian sendiri,oke!.

