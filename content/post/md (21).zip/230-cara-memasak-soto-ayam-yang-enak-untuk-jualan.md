---
description: "Cara memasak Soto Ayam yang enak Untuk Jualan"
title: "Cara memasak Soto Ayam yang enak Untuk Jualan"
slug: 230-cara-memasak-soto-ayam-yang-enak-untuk-jualan
date: 2021-02-21T09:54:00.664Z
image: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Max Frazier
ratingvalue: 5
reviewcount: 7
recipeingredient:
- "1 ekor ayam potong 8 bagian"
- "1 sdt ketumbar"
- "2 cm jahe"
- "2 cm lengkuas"
- "2 cm kunyit"
- "15 bawang merah"
- "10 bawang putih"
- "1 sdt merica"
- "5 butir kemiri"
- "100 gr toge"
- "2 bungkus kecil soun"
- "2 batang daun bawang"
- "5 batang seledri"
- "3 daun jeruk 3 daun salam 3 batang sereh"
- " Sambal  15 cabe rawit  2 bawang putih"
- "2 lt air 5 sdm minyak untuk menumis"
- " Garam dan penyedap rasa opsional"
- " Jeruk nipis dipotong kecil2"
recipeinstructions:
- "Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri."
- "Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  Kemudian tambahkan air 1lt.  Tutup panci"
- "Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit."
- "Setelah bumbu meresap, keluarkan ayam dari panci.  Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2."
- "Goreng ayam di minyak panas, tiriskan.  Lalu potong kecil2 / suwir.  Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa."
- "Bahan pelengkap : Potong/iris tipis kol.  Cuci kol dan toge. Lalu di panci lain, rebus air hingga mendidih.  Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. Siapkan di mangkok."
- "Bahan tabur : Potong/iris daun bawang, seledri. Siapkan di piring kecil"
- "Sambal soto : Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal."
- "Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. Silahkan mencoba"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 116 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Sebagai seorang istri, menyuguhkan santapan menggugah selera buat keluarga merupakan hal yang membahagiakan bagi kamu sendiri. Tugas seorang  wanita Tidak sekedar mengerjakan pekerjaan rumah saja, tetapi kamu pun harus memastikan kebutuhan nutrisi tercukupi dan santapan yang dimakan anak-anak harus nikmat.

Di waktu  saat ini, kita memang mampu membeli masakan yang sudah jadi tidak harus capek memasaknya dulu. Tapi banyak juga mereka yang memang ingin memberikan yang terlezat untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan famili. 



Apakah anda merupakan salah satu penyuka soto ayam?. Asal kamu tahu, soto ayam merupakan sajian khas di Indonesia yang sekarang disenangi oleh kebanyakan orang dari berbagai tempat di Indonesia. Kalian dapat menghidangkan soto ayam sendiri di rumah dan pasti jadi hidangan kesenanganmu di hari liburmu.

Kalian jangan bingung untuk mendapatkan soto ayam, sebab soto ayam tidak sulit untuk dicari dan juga kita pun boleh memasaknya sendiri di rumah. soto ayam boleh dibuat lewat bermacam cara. Saat ini ada banyak resep modern yang membuat soto ayam lebih nikmat.

Resep soto ayam pun mudah sekali dibikin, lho. Kita tidak usah capek-capek untuk membeli soto ayam, tetapi Kita bisa menyiapkan sendiri di rumah. Bagi Kita yang hendak menyajikannya, berikut ini cara untuk membuat soto ayam yang nikamat yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto Ayam:

1. Sediakan 1 ekor ayam potong 8 bagian
1. Sediakan 1 sdt ketumbar
1. Ambil 2 cm jahe
1. Gunakan 2 cm lengkuas
1. Sediakan 2 cm kunyit
1. Siapkan 15 bawang merah
1. Ambil 10 bawang putih
1. Siapkan 1 sdt merica
1. Sediakan 5 butir kemiri
1. Ambil 100 gr toge
1. Siapkan 2 bungkus kecil soun
1. Sediakan 2 batang daun bawang
1. Siapkan 5 batang seledri
1. Ambil 3 daun jeruk, 3 daun salam, 3 batang sereh
1. Siapkan  Sambal : 15 cabe rawit + 2 bawang putih
1. Ambil 2 lt air, 5 sdm minyak untuk menumis
1. Gunakan  Garam dan penyedap rasa (opsional)
1. Sediakan  Jeruk nipis dipotong kecil2




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam:

1. Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri.
1. Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  - Kemudian tambahkan air 1lt.  - Tutup panci
1. Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit.
1. Setelah bumbu meresap, keluarkan ayam dari panci.  - Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2.
1. Goreng ayam di minyak panas, tiriskan.  - Lalu potong kecil2 / suwir.  - Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  - Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa.
1. Bahan pelengkap : - Potong/iris tipis kol.  - Cuci kol dan toge. - Lalu di panci lain, rebus air hingga mendidih.  - Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. - Siapkan di mangkok.
1. Bahan tabur : - Potong/iris daun bawang, seledri. Siapkan di piring kecil
1. Sambal soto : - Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  - Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal.
1. Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. - Silahkan mencoba




Wah ternyata cara membuat soto ayam yang lezat tidak rumit ini mudah banget ya! Semua orang bisa memasaknya. Cara Membuat soto ayam Sangat sesuai banget untuk anda yang baru mau belajar memasak maupun juga bagi kalian yang telah hebat dalam memasak.

Apakah kamu ingin mencoba membikin resep soto ayam lezat sederhana ini? Kalau kalian tertarik, mending kamu segera menyiapkan alat dan bahannya, maka bikin deh Resep soto ayam yang mantab dan tidak ribet ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada anda berfikir lama-lama, yuk kita langsung sajikan resep soto ayam ini. Pasti kamu tiidak akan menyesal sudah membuat resep soto ayam lezat sederhana ini! Selamat mencoba dengan resep soto ayam enak tidak rumit ini di rumah masing-masing,ya!.

