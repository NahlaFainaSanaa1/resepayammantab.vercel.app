---
description: "Resep Ayam Geprek yang enak dan Mudah Dibuat"
title: "Resep Ayam Geprek yang enak dan Mudah Dibuat"
slug: 372-resep-ayam-geprek-yang-enak-dan-mudah-dibuat
date: 2021-04-05T17:02:01.170Z
image: https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg
author: Olga Burke
ratingvalue: 3.9
reviewcount: 9
recipeingredient:
- "1/2 kg Ayam Segar"
- "1 buah Jeruk Nipis"
- "1 sdt ketumbar"
- "1 sdt merica"
- "5 siung bawang putih"
- "10 buah cabai segar"
- "2 sdt kaldu jamur"
- "2 bungkus tepung Bumbu Sajiku"
- "secukupnya Air"
recipeinstructions:
- "Cuci ayam hingga bersih. Lalu masukkan perasan jeruk nipis. Aduk2 hingga bau amisnya hilang, lalu cuci kembali"
- "Haluskan 4 siung bawang putih &amp; ketumbar, lalu lumuri ke ayam yg sdh dibersihkan. Tambahkan merica &amp; kaldu jamur. Diamkan selama 1 jam hingga bumbunya meresap"
- "Siapkan 2 mangkuk untuk tepung bumbu Sajiku. Mangkuk pertama adonan kental, dan mangkuk kedua adonan kering (tanpa air)"
- "Setelah bumbu ayam meresap, celupkan ayam ke dalam adonan kental, lalu angkat dan masukkan ke dalam adonan kering (tepung terigu). Bolak balik hingga semua ayam terselimuti oleh tepung terigu"
- "Masukkan ayam ke dlm minyak yg sudah sedikit panas, masak dengan menggunakan api kecil agar matang sampai dalam"
- "Selanjutnya kita buat sambal geprek andalan"
- "Siapkan cabai dan 1 siung bawang putih, tambahkan Penyedap Rasa (sesuai selera) lalu ulek kasar. Setelah itu siram dengan minyak panas"
- "Angkat ayam, lalu tiriskan. Setelah itu geprek ayam tsb dan langsung baluri dengan sambal diatasnya"
- "Ayam geprek siap dihidangkan"
categories:
- Resep
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 125 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan santapan nikmat buat orang tercinta adalah suatu hal yang menyenangkan bagi kita sendiri. Tugas seorang istri Tidak sekadar menjaga rumah saja, tapi kamu pun wajib menyediakan kebutuhan nutrisi terpenuhi dan juga hidangan yang dimakan keluarga tercinta mesti sedap.

Di masa  saat ini, kita sebenarnya bisa membeli hidangan praktis walaupun tanpa harus susah membuatnya dulu. Tapi banyak juga lho mereka yang selalu mau memberikan makanan yang terenak untuk keluarganya. Lantaran, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai dengan makanan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penyuka ayam geprek?. Tahukah kamu, ayam geprek merupakan makanan khas di Indonesia yang kini disenangi oleh setiap orang di berbagai wilayah di Nusantara. Kita dapat membuat ayam geprek sendiri di rumah dan pasti jadi camilan kegemaranmu di akhir pekanmu.

Anda tidak usah bingung untuk memakan ayam geprek, sebab ayam geprek mudah untuk dicari dan juga kita pun boleh membuatnya sendiri di tempatmu. ayam geprek boleh dibuat dengan beraneka cara. Saat ini telah banyak banget cara modern yang menjadikan ayam geprek semakin lebih mantap.

Resep ayam geprek pun sangat mudah untuk dibikin, lho. Kita tidak usah capek-capek untuk membeli ayam geprek, lantaran Anda bisa membuatnya di rumah sendiri. Bagi Kita yang ingin menghidangkannya, dibawah ini merupakan resep untuk membuat ayam geprek yang mantab yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Geprek:

1. Ambil 1/2 kg Ayam Segar
1. Gunakan 1 buah Jeruk Nipis
1. Siapkan 1 sdt ketumbar
1. Siapkan 1 sdt merica
1. Gunakan 5 siung bawang putih
1. Ambil 10 buah cabai segar
1. Gunakan 2 sdt kaldu jamur
1. Gunakan 2 bungkus tepung Bumbu Sajiku
1. Ambil secukupnya Air




<!--inarticleads2-->

##### Cara menyiapkan Ayam Geprek:

1. Cuci ayam hingga bersih. Lalu masukkan perasan jeruk nipis. Aduk2 hingga bau amisnya hilang, lalu cuci kembali
1. Haluskan 4 siung bawang putih &amp; ketumbar, lalu lumuri ke ayam yg sdh dibersihkan. Tambahkan merica &amp; kaldu jamur. Diamkan selama 1 jam hingga bumbunya meresap
1. Siapkan 2 mangkuk untuk tepung bumbu Sajiku. Mangkuk pertama adonan kental, dan mangkuk kedua adonan kering (tanpa air)
1. Setelah bumbu ayam meresap, celupkan ayam ke dalam adonan kental, lalu angkat dan masukkan ke dalam adonan kering (tepung terigu). Bolak balik hingga semua ayam terselimuti oleh tepung terigu
1. Masukkan ayam ke dlm minyak yg sudah sedikit panas, masak dengan menggunakan api kecil agar matang sampai dalam
1. Selanjutnya kita buat sambal geprek andalan
1. Siapkan cabai dan 1 siung bawang putih, tambahkan Penyedap Rasa (sesuai selera) lalu ulek kasar. Setelah itu siram dengan minyak panas
1. Angkat ayam, lalu tiriskan. Setelah itu geprek ayam tsb dan langsung baluri dengan sambal diatasnya
1. Ayam geprek siap dihidangkan




Wah ternyata cara buat ayam geprek yang nikamt simple ini gampang sekali ya! Kamu semua dapat mencobanya. Resep ayam geprek Sangat sesuai banget buat kalian yang baru belajar memasak maupun untuk anda yang sudah ahli memasak.

Apakah kamu ingin mencoba bikin resep ayam geprek nikmat tidak ribet ini? Kalau tertarik, yuk kita segera buruan menyiapkan alat dan bahan-bahannya, kemudian bikin deh Resep ayam geprek yang lezat dan tidak ribet ini. Sangat mudah kan. 

Maka dari itu, daripada kalian diam saja, yuk kita langsung saja sajikan resep ayam geprek ini. Dijamin kalian gak akan nyesel bikin resep ayam geprek enak simple ini! Selamat mencoba dengan resep ayam geprek lezat tidak ribet ini di rumah kalian sendiri,ya!.

