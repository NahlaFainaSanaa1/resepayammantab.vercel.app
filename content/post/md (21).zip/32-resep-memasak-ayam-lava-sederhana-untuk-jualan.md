---
description: "Resep memasak Ayam Lava Sederhana Untuk Jualan"
title: "Resep memasak Ayam Lava Sederhana Untuk Jualan"
slug: 32-resep-memasak-ayam-lava-sederhana-untuk-jualan
date: 2021-01-24T12:42:03.630Z
image: https://img-global.cpcdn.com/recipes/66ab10b5563ef547/680x482cq70/ayam-lava-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/66ab10b5563ef547/680x482cq70/ayam-lava-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/66ab10b5563ef547/680x482cq70/ayam-lava-foto-resep-utama.jpg
author: Eugenia Aguilar
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "2-3 potong ayam bagian apapun saya pake bagian sayap"
- "1/2 siung bawang bombay"
- "2 siung bawang putih"
- "15-20 buah cabai boleh di kurangi"
- "1 buah tomat"
- "1/2 batang daun bawang"
- "2 sdm mentega"
- "secukupnya garam  penyedap"
- "1/2 sdm saus tiram"
- "2 sdm kecap manis"
- " saos hot lava saya pakai yg merk mama suka"
recipeinstructions:
- "Iris bawang bombay, bawang putih tipis-tipis, untuk tomat dan cabai di iris kasar"
- "Goreng ayam yg sudah di ungkep setengah matang dengan api kecil"
- "Siapkan wajan, lalu masukan mentega dan tuang semua bumbu yg telah diiris. tumis hingga wangi ya moms ☺"
- "Setelah bumbu sudah mulai menguning dan wangi, masukan ayam yg telah di goreng setengah matang lalu aduk perlahan."
- "Setelah tercampur, masukan saus tiram, kecap manis, garam/penyedap secukupnya."
- "Tuang saos lava secukupnya, hingga bewarna merah ya moms. lalu langsung matikan api kompor. di aduk dalam keadaan hangat biar saos lava nya ga kering yaa moms 🤗"
- "Siap di sajikan ke piring dan di taburi irisan daun bawang, selamaat makan 💕"
categories:
- Resep
tags:
- ayam
- lava

katakunci: ayam lava 
nutrition: 175 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Lava](https://img-global.cpcdn.com/recipes/66ab10b5563ef547/680x482cq70/ayam-lava-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan hidangan sedap buat famili adalah hal yang mengasyikan bagi kita sendiri. Peran seorang  wanita Tidak cuman menangani rumah saja, tapi anda pun wajib menyediakan kebutuhan gizi tercukupi dan juga panganan yang dimakan orang tercinta mesti mantab.

Di waktu  sekarang, anda sebenarnya bisa membeli olahan yang sudah jadi tidak harus susah memasaknya terlebih dahulu. Tapi ada juga lho orang yang selalu ingin memberikan yang terenak bagi orang tercintanya. Lantaran, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan berdasarkan kesukaan keluarga tercinta. 



Mungkinkah kamu seorang penikmat ayam lava?. Asal kamu tahu, ayam lava merupakan sajian khas di Indonesia yang saat ini digemari oleh orang-orang di berbagai tempat di Indonesia. Kalian bisa memasak ayam lava buatan sendiri di rumahmu dan dapat dijadikan camilan favorit di akhir pekan.

Kamu tidak usah bingung jika kamu ingin menyantap ayam lava, karena ayam lava sangat mudah untuk ditemukan dan juga kita pun dapat membuatnya sendiri di rumah. ayam lava bisa dimasak lewat bermacam cara. Kini pun sudah banyak sekali cara modern yang membuat ayam lava lebih mantap.

Resep ayam lava pun sangat gampang dibikin, lho. Kita jangan repot-repot untuk membeli ayam lava, tetapi Anda mampu menghidangkan ditempatmu. Untuk Kita yang akan menyajikannya, di bawah ini adalah cara membuat ayam lava yang lezat yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Lava:

1. Sediakan 2-3 potong ayam bagian apapun (saya pake bagian sayap)
1. Siapkan 1/2 siung bawang bombay
1. Siapkan 2 siung bawang putih
1. Sediakan 15-20 buah cabai (boleh di kurangi)
1. Gunakan 1 buah tomat
1. Sediakan 1/2 batang daun bawang
1. Siapkan 2 sdm mentega
1. Siapkan secukupnya garam / penyedap
1. Siapkan 1/2 sdm saus tiram
1. Ambil 2 sdm kecap manis
1. Ambil  saos hot lava (saya pakai yg merk mama suka)




<!--inarticleads2-->

##### Cara menyiapkan Ayam Lava:

1. Iris bawang bombay, bawang putih tipis-tipis, untuk tomat dan cabai di iris kasar
1. Goreng ayam yg sudah di ungkep setengah matang dengan api kecil
1. Siapkan wajan, lalu masukan mentega dan tuang semua bumbu yg telah diiris. tumis hingga wangi ya moms ☺
1. Setelah bumbu sudah mulai menguning dan wangi, masukan ayam yg telah di goreng setengah matang lalu aduk perlahan.
1. Setelah tercampur, masukan saus tiram, kecap manis, garam/penyedap secukupnya.
1. Tuang saos lava secukupnya, hingga bewarna merah ya moms. lalu langsung matikan api kompor. di aduk dalam keadaan hangat biar saos lava nya ga kering yaa moms 🤗
1. Siap di sajikan ke piring dan di taburi irisan daun bawang, selamaat makan 💕




Wah ternyata cara buat ayam lava yang enak tidak rumit ini mudah banget ya! Kalian semua bisa memasaknya. Resep ayam lava Sangat sesuai sekali untuk kamu yang baru belajar memasak ataupun untuk anda yang sudah lihai dalam memasak.

Tertarik untuk mencoba buat resep ayam lava enak sederhana ini? Kalau anda ingin, ayo kamu segera siapkan alat-alat dan bahan-bahannya, maka buat deh Resep ayam lava yang enak dan tidak rumit ini. Sungguh taidak sulit kan. 

Jadi, daripada kamu berlama-lama, yuk kita langsung saja bikin resep ayam lava ini. Pasti kalian gak akan nyesel bikin resep ayam lava mantab simple ini! Selamat berkreasi dengan resep ayam lava nikmat tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

