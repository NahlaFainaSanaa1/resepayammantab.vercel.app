---
description: "Resep Soto Ayam Kampung Kuah Santan yang sedap dan Mudah Dibuat"
title: "Resep Soto Ayam Kampung Kuah Santan yang sedap dan Mudah Dibuat"
slug: 258-resep-soto-ayam-kampung-kuah-santan-yang-sedap-dan-mudah-dibuat
date: 2021-02-22T09:20:29.119Z
image: https://img-global.cpcdn.com/recipes/7bc9114093dd08c4/680x482cq70/soto-ayam-kampung-kuah-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7bc9114093dd08c4/680x482cq70/soto-ayam-kampung-kuah-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7bc9114093dd08c4/680x482cq70/soto-ayam-kampung-kuah-santan-foto-resep-utama.jpg
author: Glen West
ratingvalue: 4.6
reviewcount: 5
recipeingredient:
- "1/2 ekor ayam kampung"
- "200 gram taoge rendam sebentar dlm air mendidih"
- "100 grm soun aku pake vermicelli rendam sebentar dlm air mendidih"
- "7 lmbr daun salam"
- "4 iris lengkuas"
- "2 btg serai"
- "2 lmbr daun jeruk"
- " bawang goreng dan daun bawang utk taburan"
- "500 ml santan dr 12 butir kelapa"
- "1500 ml air"
- "3/4 sdt garam"
- "1 sdt kaldu jamur bubuk saya  totole"
- "1/4 sdt merica bubuk"
- "1/2 sdt gula pasir"
- "1/2 sdt gula merah"
- " Bumbubumbu yg dihaluskan"
- "4 siung bawang putih"
- "3 siung bawang merah"
- "5 butir kemiri"
- "1 sdt ketumbar butir"
- "1 cm jahe kupas lalu geprek"
- "1 cm kunyit kupas"
- " Pelengkap  Ketupat taoge soun telur kecaptelur pindang bumbu kacang sambel jeruk nipis           lihat resep"
- " Hati  kepala goreng"
recipeinstructions:
- "Rebus air dg panci dan beri 3 lmbr daun salam. Sambil menunggu air mendidih, cuci bersih ayam dg air yg diberi sedikit cuka, bilas dg air lalu tiriskan airnya. Setelah air mendidih, masukkan ayam dan masak hingga kotorannya keluar (+/- 10 menit). Matikan api, buang airnya dan bilas dg air bersih hingga kotorannya hilang."
- "Rebus 1500ml air, sambil menunggu air mendidih, haluskan bumbu (saya diuleg manual/bisa juga diblender). Bila air mendidih masukkan 4 lmbr daun salam dan ayamnya."
- "Tumis bumbu halus dg sedikit minyak hingga harum, masukkan laos, sereh dan jahe. Aduk² agar tidak gosong, tumis bumbu hingga benar² matang lalu matikan api."
- "Masukkan tumisan bumbu kedalam panci yg berisi rebusan ayam. Bumbui garam, kaldu jamur, gula pasir dan merica bubuk, aduk rata. Tuang santan dan tambahkan gula merah, aduk rata. Masak dg api kecil dan sesekali diaduk agar santan tdk pecah. Lakukan test rasa."
- "Bila ayam sudah empuk, angkat, tiriskan airnya. Goreng sebentar lalu suwir² (anak² saya lebih suka yg tdk dogoreng, jadi saya tdk menggorengnya). Siapkan juga soun dan taoge."
- "Sajikan soto: ketupat-soun-tauge- ayam suwir -telur-tuang kuah-bumbu kacang-kecap-kerupuk. Taburi dgn irisan daun bawang dan bawang goreng. Sajikan dg 💕💕 (resep bumbu kacang ada dilampiran)           (lihat resep)"
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 295 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto Ayam Kampung Kuah Santan](https://img-global.cpcdn.com/recipes/7bc9114093dd08c4/680x482cq70/soto-ayam-kampung-kuah-santan-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyajikan masakan nikmat pada orang tercinta merupakan hal yang sangat menyenangkan untuk kita sendiri. Tugas seorang istri bukan cuma mengurus rumah saja, namun kamu pun harus menyediakan keperluan nutrisi terpenuhi dan juga panganan yang disantap keluarga tercinta wajib enak.

Di zaman  saat ini, kita memang mampu mengorder panganan siap saji walaupun tanpa harus capek memasaknya terlebih dahulu. Namun banyak juga lho orang yang memang mau menyajikan yang terbaik bagi keluarganya. Karena, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penggemar soto ayam kampung kuah santan?. Asal kamu tahu, soto ayam kampung kuah santan adalah hidangan khas di Indonesia yang saat ini digemari oleh orang-orang di hampir setiap tempat di Nusantara. Kita dapat membuat soto ayam kampung kuah santan olahan sendiri di rumah dan boleh jadi camilan kegemaranmu di hari liburmu.

Anda tidak usah bingung jika kamu ingin memakan soto ayam kampung kuah santan, karena soto ayam kampung kuah santan mudah untuk ditemukan dan kamu pun boleh mengolahnya sendiri di rumah. soto ayam kampung kuah santan boleh dibuat lewat beragam cara. Saat ini ada banyak resep modern yang menjadikan soto ayam kampung kuah santan lebih lezat.

Resep soto ayam kampung kuah santan pun mudah sekali dibikin, lho. Kalian jangan repot-repot untuk memesan soto ayam kampung kuah santan, tetapi Kita mampu menyajikan di rumahmu. Untuk Anda yang ingin membuatnya, di bawah ini adalah resep menyajikan soto ayam kampung kuah santan yang enak yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Soto Ayam Kampung Kuah Santan:

1. Siapkan 1/2 ekor ayam kampung
1. Gunakan 200 gram taoge, rendam sebentar dlm air mendidih
1. Gunakan 100 grm soun (aku pake vermicelli), rendam sebentar dlm air mendidih
1. Sediakan 7 lmbr daun salam
1. Gunakan 4 iris lengkuas
1. Ambil 2 btg serai
1. Gunakan 2 lmbr daun jeruk
1. Siapkan  bawang goreng dan daun bawang utk taburan
1. Ambil 500 ml santan dr 1/2 butir kelapa
1. Siapkan 1500 ml air
1. Ambil 3/4 sdt garam
1. Ambil 1 sdt kaldu jamur bubuk (saya : totole)
1. Ambil 1/4 sdt merica bubuk
1. Siapkan 1/2 sdt gula pasir
1. Gunakan 1/2 sdt gula merah
1. Siapkan  Bumbu-bumbu yg dihaluskan
1. Gunakan 4 siung bawang putih
1. Siapkan 3 siung bawang merah
1. Siapkan 5 butir kemiri
1. Ambil 1 sdt ketumbar butir
1. Gunakan 1 cm jahe, kupas lalu geprek
1. Gunakan 1 cm kunyit, kupas
1. Ambil  Pelengkap : Ketupat, taoge, soun, telur kecap/telur pindang, bumbu kacang, sambel, jeruk nipis           (lihat resep)
1. Gunakan  Hati &amp; kepala goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Kampung Kuah Santan:

1. Rebus air dg panci dan beri 3 lmbr daun salam. Sambil menunggu air mendidih, cuci bersih ayam dg air yg diberi sedikit cuka, bilas dg air lalu tiriskan airnya. Setelah air mendidih, masukkan ayam dan masak hingga kotorannya keluar (+/- 10 menit). Matikan api, buang airnya dan bilas dg air bersih hingga kotorannya hilang.
1. Rebus 1500ml air, sambil menunggu air mendidih, haluskan bumbu (saya diuleg manual/bisa juga diblender). Bila air mendidih masukkan 4 lmbr daun salam dan ayamnya.
1. Tumis bumbu halus dg sedikit minyak hingga harum, masukkan laos, sereh dan jahe. Aduk² agar tidak gosong, tumis bumbu hingga benar² matang lalu matikan api.
1. Masukkan tumisan bumbu kedalam panci yg berisi rebusan ayam. Bumbui garam, kaldu jamur, gula pasir dan merica bubuk, aduk rata. Tuang santan dan tambahkan gula merah, aduk rata. Masak dg api kecil dan sesekali diaduk agar santan tdk pecah. Lakukan test rasa.
1. Bila ayam sudah empuk, angkat, tiriskan airnya. Goreng sebentar lalu suwir² (anak² saya lebih suka yg tdk dogoreng, jadi saya tdk menggorengnya). Siapkan juga soun dan taoge.
1. Sajikan soto: ketupat-soun-tauge- ayam suwir -telur-tuang kuah-bumbu kacang-kecap-kerupuk. Taburi dgn irisan daun bawang dan bawang goreng. Sajikan dg 💕💕 (resep bumbu kacang ada dilampiran) -           (lihat resep)




Wah ternyata cara buat soto ayam kampung kuah santan yang mantab tidak rumit ini enteng banget ya! Kalian semua mampu memasaknya. Cara buat soto ayam kampung kuah santan Sangat cocok sekali untuk kita yang baru akan belajar memasak maupun juga bagi kalian yang sudah pandai memasak.

Apakah kamu tertarik mencoba membikin resep soto ayam kampung kuah santan lezat sederhana ini? Kalau kamu mau, yuk kita segera menyiapkan peralatan dan bahan-bahannya, lalu bikin deh Resep soto ayam kampung kuah santan yang nikmat dan tidak ribet ini. Sungguh mudah kan. 

Maka dari itu, ketimbang anda diam saja, hayo langsung aja bikin resep soto ayam kampung kuah santan ini. Pasti kamu gak akan menyesal membuat resep soto ayam kampung kuah santan mantab simple ini! Selamat berkreasi dengan resep soto ayam kampung kuah santan lezat sederhana ini di rumah kalian sendiri,oke!.

