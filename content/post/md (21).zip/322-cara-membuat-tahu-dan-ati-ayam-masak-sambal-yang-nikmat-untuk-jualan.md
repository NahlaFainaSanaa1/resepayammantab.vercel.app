---
description: "Cara membuat Tahu dan Ati Ayam Masak Sambal yang nikmat Untuk Jualan"
title: "Cara membuat Tahu dan Ati Ayam Masak Sambal yang nikmat Untuk Jualan"
slug: 322-cara-membuat-tahu-dan-ati-ayam-masak-sambal-yang-nikmat-untuk-jualan
date: 2021-02-20T07:25:47.334Z
image: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
author: Minnie Gross
ratingvalue: 4.6
reviewcount: 12
recipeingredient:
- "4 buah Tahu ukuran sedang goreng"
- "250 gram Hati ayam rebus lalu goreng"
- "2 cm lengkuas geprek"
- "2 lembar daun salam"
- "1 sdt Garam"
- "1 sdt Gula"
- "1/2 sdt Merica"
- "2 sdm Kecap manis jika suka"
- " Kaldu udang 1 sdt bisa juga kaldu jamur atau lainnya           lihat resep"
- " Bumbu halus "
- "6 buah Bawang merah"
- "3 siung Bawang putih"
- "3 buah Cabe merah besar"
- "15 buah cabe rawit sesuai selera"
recipeinstructions:
- "Siapkan bahan : Goreng tahu. Rebus dan goreng hati sapi. Haluskan bumbu."
- "Tumis bumbu dengan sedikit minyak, masukkan Lengkuas dan daun salam. Aduk rata biarkan hingga harum, selagi menunggu, potong² hati sapi. Setelah bumbu harum masukkan kedua bahan utama. Aduk rata."
- "Beri sedikit air, masukkan, gula, garam, merica, kaldu udang, kecap. Aduk rata. Test rasa. Masak hingga air menyusut dan bumbu meresap."
- "Tahu dan Ati Ayam masak sambal, siap di sajikan dengan nasi hangat. Selamat mencoba. Praktis dan enak."
categories:
- Resep
tags:
- tahu
- dan
- ati

katakunci: tahu dan ati 
nutrition: 300 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Tahu dan Ati Ayam Masak Sambal](https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg)

Apabila kalian seorang ibu, menyuguhkan hidangan nikmat bagi famili merupakan suatu hal yang mengasyikan untuk kita sendiri. Tugas seorang ibu Tidak sekadar mengerjakan pekerjaan rumah saja, tetapi kamu pun harus menyediakan kebutuhan nutrisi terpenuhi dan santapan yang dimakan orang tercinta wajib sedap.

Di zaman  sekarang, kamu sebenarnya dapat mengorder hidangan jadi meski tidak harus susah mengolahnya dahulu. Tapi ada juga orang yang memang ingin menyajikan yang terlezat untuk keluarganya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga. 



Apakah anda merupakan salah satu penggemar tahu dan ati ayam masak sambal?. Asal kamu tahu, tahu dan ati ayam masak sambal adalah sajian khas di Indonesia yang saat ini digemari oleh setiap orang di hampir setiap wilayah di Nusantara. Kita dapat menyajikan tahu dan ati ayam masak sambal buatan sendiri di rumah dan dapat dijadikan santapan kegemaranmu di akhir pekanmu.

Kita tidak usah bingung jika kamu ingin menyantap tahu dan ati ayam masak sambal, karena tahu dan ati ayam masak sambal tidak sulit untuk ditemukan dan juga kamu pun dapat memasaknya sendiri di tempatmu. tahu dan ati ayam masak sambal bisa diolah dengan bermacam cara. Kini pun ada banyak sekali resep modern yang membuat tahu dan ati ayam masak sambal semakin enak.

Resep tahu dan ati ayam masak sambal pun sangat mudah untuk dibuat, lho. Kamu jangan ribet-ribet untuk membeli tahu dan ati ayam masak sambal, sebab Anda dapat membuatnya di rumah sendiri. Bagi Anda yang akan menyajikannya, berikut ini resep membuat tahu dan ati ayam masak sambal yang enak yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Tahu dan Ati Ayam Masak Sambal:

1. Siapkan 4 buah Tahu ukuran sedang (goreng)
1. Siapkan 250 gram Hati ayam (rebus lalu goreng)
1. Siapkan 2 cm lengkuas geprek
1. Sediakan 2 lembar daun salam
1. Sediakan 1 sdt Garam
1. Gunakan 1 sdt Gula
1. Sediakan 1/2 sdt Merica
1. Ambil 2 sdm Kecap manis (jika suka)
1. Sediakan  Kaldu udang 1 sdt (bisa juga kaldu jamur atau lainnya)           (lihat resep)
1. Siapkan  Bumbu halus :
1. Ambil 6 buah Bawang merah
1. Gunakan 3 siung Bawang putih
1. Sediakan 3 buah Cabe merah besar
1. Gunakan 15 buah cabe rawit (sesuai selera)




<!--inarticleads2-->

##### Langkah-langkah membuat Tahu dan Ati Ayam Masak Sambal:

1. Siapkan bahan : Goreng tahu. Rebus dan goreng hati sapi. Haluskan bumbu.
<img src="https://img-global.cpcdn.com/steps/8726268525b4a5b5/160x128cq70/tahu-dan-ati-ayam-masak-sambal-langkah-memasak-1-foto.jpg" alt="Tahu dan Ati Ayam Masak Sambal"><img src="https://img-global.cpcdn.com/steps/90448fce54548c1e/160x128cq70/tahu-dan-ati-ayam-masak-sambal-langkah-memasak-1-foto.jpg" alt="Tahu dan Ati Ayam Masak Sambal">1. Tumis bumbu dengan sedikit minyak, masukkan Lengkuas dan daun salam. Aduk rata biarkan hingga harum, selagi menunggu, potong² hati sapi. Setelah bumbu harum masukkan kedua bahan utama. Aduk rata.
1. Beri sedikit air, masukkan, gula, garam, merica, kaldu udang, kecap. Aduk rata. Test rasa. Masak hingga air menyusut dan bumbu meresap.
1. Tahu dan Ati Ayam masak sambal, siap di sajikan dengan nasi hangat. Selamat mencoba. Praktis dan enak.




Ternyata cara membuat tahu dan ati ayam masak sambal yang mantab simple ini mudah sekali ya! Semua orang bisa mencobanya. Cara Membuat tahu dan ati ayam masak sambal Sesuai banget buat kalian yang baru mau belajar memasak ataupun untuk kamu yang telah hebat memasak.

Apakah kamu mau mulai mencoba buat resep tahu dan ati ayam masak sambal mantab tidak ribet ini? Kalau kamu ingin, ayo kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep tahu dan ati ayam masak sambal yang nikmat dan sederhana ini. Betul-betul gampang kan. 

Oleh karena itu, ketimbang kamu berfikir lama-lama, hayo kita langsung saja hidangkan resep tahu dan ati ayam masak sambal ini. Dijamin kalian tiidak akan nyesel sudah buat resep tahu dan ati ayam masak sambal mantab sederhana ini! Selamat berkreasi dengan resep tahu dan ati ayam masak sambal lezat sederhana ini di rumah masing-masing,oke!.

