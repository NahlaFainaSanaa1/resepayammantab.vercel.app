---
description: "Bahan-bahan Rice Bowl Ayam Suir Daun Jeruk dan Sambal Terong Terasi yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Rice Bowl Ayam Suir Daun Jeruk dan Sambal Terong Terasi yang nikmat dan Mudah Dibuat"
slug: 192-bahan-bahan-rice-bowl-ayam-suir-daun-jeruk-dan-sambal-terong-terasi-yang-nikmat-dan-mudah-dibuat
date: 2021-02-05T23:38:48.303Z
image: https://img-global.cpcdn.com/recipes/06bfae28f130984c/680x482cq70/rice-bowl-ayam-suir-daun-jeruk-dan-sambal-terong-terasi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/06bfae28f130984c/680x482cq70/rice-bowl-ayam-suir-daun-jeruk-dan-sambal-terong-terasi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/06bfae28f130984c/680x482cq70/rice-bowl-ayam-suir-daun-jeruk-dan-sambal-terong-terasi-foto-resep-utama.jpg
author: Curtis Osborne
ratingvalue: 4.3
reviewcount: 3
recipeingredient:
- " Bahan ayam suir"
- "250 gr ayam"
- "2 lembar daun salam"
- "2 cm lengkuas geprek"
- "1 batang serai"
- "3 lembar daun jeruk"
- "1 sdt kunyit bubuk"
- "1/2 sdt lada bubuk"
- "sesuai selera Gula dan garam"
- "Secukupnya air kaldu rebusan ayam"
- " Bumbu halus ayam suir"
- "2 bawang putih"
- "6 bawang merah"
- "1/2 sdt ketumbar"
- "1 butir kemiri"
- " Bahan sambal terong"
- "2 buah terong ungu"
- "2 buah tomat"
- "2 siung bawang putih"
- "7 buah bawang merah"
- "5 buah cabai rawit"
- "Sesuai selera terasi"
- "Sesuai selera kaldu bubuk"
- "sesuai selera Gula dan garam"
- " Bahan lain"
- "Secukupnya timun"
- "Secukupnya irisan daun jeruk"
- "Secukupnya nasi putih hangat"
recipeinstructions:
- "Membuat ayam suir.Didihkan secukupnya air.Setelah mendidih masukkan daun salam, lengkuas dan ayam yang sebelumnya sudah dibersihkan.Rebus hingga empuk.Tiriskan dan suir suir."
- "Haluskan bahan bumbu ayam suir.Tumis hingga harum bersama 3 lembar daun jeruk (sobek sobek) dan serai.Masukkan ayam suir, tambahkan secukupnya air kaldu rebusan ayam tadi.Tambahkan gula, garam, kunyit bubuk dan lada bubuk.Masak hingga bumbu meresap dan sat."
- "Untuk membuat sambal, potong potong terong sesuai selera.Rendam dalam air.Kemudian goreng hingga kecoklatan."
- "Potong potong tomat, terasi,cabai, bawang merah dan bawang putih.Goreng hingga layu.Kemudian anggkat dan ulek bersama gula dan garam."
- "Panaskan minyak sisa menggoreng tadi.Masukkan sambal yang sudah halus dan potongan terong goreng.Beri secukupnya kaldu bubuk.Masak hingga matang."
- "Tata nasi dalam mangkuk.Beri sambal terong terasi dan ayam suir.Tambahkan irisan daun jeruk pada ayam suir.Beri juga potongan timun."
categories:
- Resep
tags:
- rice
- bowl
- ayam

katakunci: rice bowl ayam 
nutrition: 274 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dinner

---


![Rice Bowl Ayam Suir Daun Jeruk dan Sambal Terong Terasi](https://img-global.cpcdn.com/recipes/06bfae28f130984c/680x482cq70/rice-bowl-ayam-suir-daun-jeruk-dan-sambal-terong-terasi-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan olahan enak kepada orang tercinta merupakan hal yang mengasyikan untuk anda sendiri. Tugas seorang ibu bukan hanya mengatur rumah saja, tetapi kamu juga wajib memastikan keperluan gizi tercukupi dan juga santapan yang disantap keluarga tercinta harus nikmat.

Di zaman  saat ini, kita sebenarnya bisa mengorder olahan yang sudah jadi walaupun tanpa harus repot memasaknya lebih dulu. Namun ada juga lho mereka yang memang ingin memberikan hidangan yang terenak untuk keluarganya. Pasalnya, menyajikan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan famili. 



Apakah anda adalah salah satu penikmat rice bowl ayam suir daun jeruk dan sambal terong terasi?. Asal kamu tahu, rice bowl ayam suir daun jeruk dan sambal terong terasi merupakan sajian khas di Nusantara yang sekarang disenangi oleh setiap orang dari berbagai wilayah di Nusantara. Anda dapat menyajikan rice bowl ayam suir daun jeruk dan sambal terong terasi sendiri di rumah dan pasti jadi camilan favorit di hari liburmu.

Anda tidak usah bingung untuk menyantap rice bowl ayam suir daun jeruk dan sambal terong terasi, lantaran rice bowl ayam suir daun jeruk dan sambal terong terasi gampang untuk didapatkan dan juga kalian pun dapat membuatnya sendiri di rumah. rice bowl ayam suir daun jeruk dan sambal terong terasi dapat diolah memalui beraneka cara. Kini sudah banyak sekali resep kekinian yang membuat rice bowl ayam suir daun jeruk dan sambal terong terasi semakin lebih nikmat.

Resep rice bowl ayam suir daun jeruk dan sambal terong terasi juga sangat gampang untuk dibikin, lho. Kamu jangan ribet-ribet untuk membeli rice bowl ayam suir daun jeruk dan sambal terong terasi, lantaran Kamu bisa membuatnya di rumahmu. Untuk Kalian yang mau membuatnya, inilah cara untuk membuat rice bowl ayam suir daun jeruk dan sambal terong terasi yang nikamat yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Rice Bowl Ayam Suir Daun Jeruk dan Sambal Terong Terasi:

1. Siapkan  Bahan ayam suir
1. Sediakan 250 gr ayam
1. Gunakan 2 lembar daun salam
1. Sediakan 2 cm lengkuas geprek
1. Ambil 1 batang serai
1. Siapkan 3 lembar daun jeruk
1. Sediakan 1 sdt kunyit bubuk
1. Gunakan 1/2 sdt lada bubuk
1. Sediakan sesuai selera Gula dan garam
1. Siapkan Secukupnya air kaldu rebusan ayam
1. Ambil  Bumbu halus ayam suir
1. Gunakan 2 bawang putih
1. Siapkan 6 bawang merah
1. Gunakan 1/2 sdt ketumbar
1. Gunakan 1 butir kemiri
1. Ambil  Bahan sambal terong
1. Siapkan 2 buah terong ungu
1. Gunakan 2 buah tomat
1. Ambil 2 siung bawang putih
1. Siapkan 7 buah bawang merah
1. Siapkan 5 buah cabai rawit
1. Siapkan Sesuai selera terasi
1. Gunakan Sesuai selera kaldu bubuk
1. Gunakan sesuai selera Gula dan garam
1. Ambil  Bahan lain
1. Siapkan Secukupnya timun
1. Ambil Secukupnya irisan daun jeruk
1. Gunakan Secukupnya nasi putih hangat




<!--inarticleads2-->

##### Langkah-langkah membuat Rice Bowl Ayam Suir Daun Jeruk dan Sambal Terong Terasi:

1. Membuat ayam suir.Didihkan secukupnya air.Setelah mendidih masukkan daun salam, lengkuas dan ayam yang sebelumnya sudah dibersihkan.Rebus hingga empuk.Tiriskan dan suir suir.
1. Haluskan bahan bumbu ayam suir.Tumis hingga harum bersama 3 lembar daun jeruk (sobek sobek) dan serai.Masukkan ayam suir, tambahkan secukupnya air kaldu rebusan ayam tadi.Tambahkan gula, garam, kunyit bubuk dan lada bubuk.Masak hingga bumbu meresap dan sat.
1. Untuk membuat sambal, potong potong terong sesuai selera.Rendam dalam air.Kemudian goreng hingga kecoklatan.
1. Potong potong tomat, terasi,cabai, bawang merah dan bawang putih.Goreng hingga layu.Kemudian anggkat dan ulek bersama gula dan garam.
1. Panaskan minyak sisa menggoreng tadi.Masukkan sambal yang sudah halus dan potongan terong goreng.Beri secukupnya kaldu bubuk.Masak hingga matang.
1. Tata nasi dalam mangkuk.Beri sambal terong terasi dan ayam suir.Tambahkan irisan daun jeruk pada ayam suir.Beri juga potongan timun.




Wah ternyata cara membuat rice bowl ayam suir daun jeruk dan sambal terong terasi yang lezat sederhana ini mudah banget ya! Kita semua mampu menghidangkannya. Cara Membuat rice bowl ayam suir daun jeruk dan sambal terong terasi Sesuai banget untuk anda yang baru belajar memasak ataupun bagi kalian yang telah lihai memasak.

Apakah kamu mau mencoba membuat resep rice bowl ayam suir daun jeruk dan sambal terong terasi enak tidak rumit ini? Kalau mau, ayo kalian segera buruan siapkan alat-alat dan bahannya, maka buat deh Resep rice bowl ayam suir daun jeruk dan sambal terong terasi yang enak dan simple ini. Sungguh gampang kan. 

Maka, daripada kalian berlama-lama, hayo langsung aja bikin resep rice bowl ayam suir daun jeruk dan sambal terong terasi ini. Dijamin kalian tiidak akan menyesal bikin resep rice bowl ayam suir daun jeruk dan sambal terong terasi enak tidak ribet ini! Selamat berkreasi dengan resep rice bowl ayam suir daun jeruk dan sambal terong terasi enak tidak rumit ini di tempat tinggal masing-masing,ya!.

