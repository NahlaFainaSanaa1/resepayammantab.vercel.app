---
description: "Resep Ayam Bakar Solo yang lezat dan Mudah Dibuat"
title: "Resep Ayam Bakar Solo yang lezat dan Mudah Dibuat"
slug: 314-resep-ayam-bakar-solo-yang-lezat-dan-mudah-dibuat
date: 2021-04-19T15:57:40.530Z
image: https://img-global.cpcdn.com/recipes/c3b2665fef108d69/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c3b2665fef108d69/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c3b2665fef108d69/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
author: Kyle Cole
ratingvalue: 4
reviewcount: 3
recipeingredient:
- "3 potong ayam"
- "500 ml air kelapa muda"
- "4 sdm bumbu dasar kuning           lihat resep"
- "2 sdm gula merah"
- "Secukupnya garam"
- "1 batang serai"
- "2 lembar daun salam"
- "1 lembar daun jeruk"
- "2 sdm kecap manis"
recipeinstructions:
- "Potong dan cuci bersih ayam. Siapkan bumbu dasar kuning. Baluri rata ke ayam. Diamkan sebentar dalam kulkas."
- "Kemudian tambahkan air kelapa dalam panci. Masukkan ayam dan bumbu. Tambahkan serai,daun salam dan daun jeruk. Beri garam."
- "Masukkan gula merah dan kecap manis. Masak hingga kuah menyusut. Kemudian panggang ayam d teflon sambil disiram sisa bumbu. Gunakan api kecil ya."
- "Ayam bakar solo siap disajikan."
categories:
- Resep
tags:
- ayam
- bakar
- solo

katakunci: ayam bakar solo 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Bakar Solo](https://img-global.cpcdn.com/recipes/c3b2665fef108d69/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyuguhkan santapan menggugah selera kepada keluarga adalah suatu hal yang sangat menyenangkan bagi anda sendiri. Peran seorang ibu bukan cuman mengatur rumah saja, tapi anda juga wajib memastikan kebutuhan gizi terpenuhi dan santapan yang dimakan orang tercinta mesti mantab.

Di zaman  sekarang, kita memang bisa mengorder hidangan siap saji walaupun tanpa harus ribet membuatnya dahulu. Tetapi ada juga orang yang selalu mau memberikan hidangan yang terbaik untuk orang yang dicintainya. Sebab, memasak sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai makanan kesukaan keluarga. 



Mungkinkah anda adalah seorang penikmat ayam bakar solo?. Tahukah kamu, ayam bakar solo adalah makanan khas di Indonesia yang kini disenangi oleh banyak orang dari berbagai daerah di Indonesia. Kita dapat menyajikan ayam bakar solo sendiri di rumah dan dapat dijadikan camilan kegemaranmu di hari liburmu.

Kita tidak perlu bingung untuk memakan ayam bakar solo, karena ayam bakar solo tidak sulit untuk didapatkan dan anda pun dapat menghidangkannya sendiri di tempatmu. ayam bakar solo bisa dibuat memalui berbagai cara. Sekarang ada banyak sekali resep modern yang membuat ayam bakar solo semakin lebih lezat.

Resep ayam bakar solo juga gampang sekali dihidangkan, lho. Kamu tidak usah ribet-ribet untuk membeli ayam bakar solo, karena Kalian mampu menghidangkan sendiri di rumah. Untuk Kita yang ingin menghidangkannya, inilah cara membuat ayam bakar solo yang enak yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Bakar Solo:

1. Gunakan 3 potong ayam
1. Sediakan 500 ml air kelapa muda
1. Sediakan 4 sdm bumbu dasar kuning           (lihat resep)
1. Ambil 2 sdm gula merah
1. Sediakan Secukupnya garam
1. Sediakan 1 batang serai
1. Ambil 2 lembar daun salam
1. Ambil 1 lembar daun jeruk
1. Ambil 2 sdm kecap manis




<!--inarticleads2-->

##### Cara membuat Ayam Bakar Solo:

1. Potong dan cuci bersih ayam. Siapkan bumbu dasar kuning. Baluri rata ke ayam. Diamkan sebentar dalam kulkas.
<img src="https://img-global.cpcdn.com/steps/9e080be17b89eb30/160x128cq70/ayam-bakar-solo-langkah-memasak-1-foto.jpg" alt="Ayam Bakar Solo"><img src="https://img-global.cpcdn.com/steps/a24c5cb45575b525/160x128cq70/ayam-bakar-solo-langkah-memasak-1-foto.jpg" alt="Ayam Bakar Solo"><img src="https://img-global.cpcdn.com/steps/69fd75a0e337c010/160x128cq70/ayam-bakar-solo-langkah-memasak-1-foto.jpg" alt="Ayam Bakar Solo">1. Kemudian tambahkan air kelapa dalam panci. Masukkan ayam dan bumbu. Tambahkan serai,daun salam dan daun jeruk. Beri garam.
1. Masukkan gula merah dan kecap manis. Masak hingga kuah menyusut. Kemudian panggang ayam d teflon sambil disiram sisa bumbu. Gunakan api kecil ya.
1. Ayam bakar solo siap disajikan.




Ternyata resep ayam bakar solo yang lezat tidak rumit ini mudah banget ya! Kita semua bisa menghidangkannya. Cara buat ayam bakar solo Sangat cocok sekali buat kita yang baru mau belajar memasak maupun bagi kamu yang sudah jago dalam memasak.

Tertarik untuk mencoba membikin resep ayam bakar solo enak tidak ribet ini? Kalau kamu ingin, yuk kita segera menyiapkan alat dan bahan-bahannya, setelah itu bikin deh Resep ayam bakar solo yang enak dan simple ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang kamu berlama-lama, hayo kita langsung hidangkan resep ayam bakar solo ini. Pasti kamu tak akan nyesel membuat resep ayam bakar solo mantab simple ini! Selamat berkreasi dengan resep ayam bakar solo mantab tidak ribet ini di tempat tinggal sendiri,oke!.

