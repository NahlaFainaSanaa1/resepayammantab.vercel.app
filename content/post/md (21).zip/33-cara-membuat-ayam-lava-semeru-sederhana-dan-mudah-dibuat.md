---
description: "Cara membuat Ayam Lava Semeru Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam Lava Semeru Sederhana dan Mudah Dibuat"
slug: 33-cara-membuat-ayam-lava-semeru-sederhana-dan-mudah-dibuat
date: 2021-01-17T22:32:04.655Z
image: https://img-global.cpcdn.com/recipes/ab50c5fe8b8f724d/680x482cq70/ayam-lava-semeru-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab50c5fe8b8f724d/680x482cq70/ayam-lava-semeru-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab50c5fe8b8f724d/680x482cq70/ayam-lava-semeru-foto-resep-utama.jpg
author: Connor Mason
ratingvalue: 5
reviewcount: 6
recipeingredient:
- " Bahan"
- " Ayam bagian paha 12kg isi 4"
- "1 ruas jari laos"
- "4 Bawang putih"
- "8 Bawang merah"
- "sesuai selera Cabe rawit setan"
- "secukupnya Garam"
- "secukupnya Merica"
- "secukupnya Kaldu jamur"
recipeinstructions:
- "Cuci bersih ayam kemudian rebus sampai matang, tambahkan garam, merica, kaldu jamur secukupnya"
- "Sambil lalu ulek bawang merah, bawang putih, cabe rawit setan, jgn lupa geprek laosnya"
- "Setelah ayam matang sempurna, goreng ayam jangan sampai garing, cukup digoreng hingga warna luar berubah kecoklatan lalu angkat tiriskan"
- "Panaskan sedikit minyak, masukkan laos terlebih dahulu tunggu sampai wanginya keluar lalu masukkan bumbu ulekan yg tadi sudah disiapkan"
- "Setelah bumbu matang masukkan sedikit kaldu dr sisa rebusan ayam tadi tunggu hingga menyatu dan masukkan ayam yg sudah digoreng tadi"
- "Tambahkan garam, kaldu jamur dan merica, koreksi rasa daaan siap dinikmati dg nasi panas. Dijamin makin nambah nafsu makan. Selamat mencoba"
categories:
- Resep
tags:
- ayam
- lava
- semeru

katakunci: ayam lava semeru 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Lava Semeru](https://img-global.cpcdn.com/recipes/ab50c5fe8b8f724d/680x482cq70/ayam-lava-semeru-foto-resep-utama.jpg)

Jika kamu seorang ibu, menyuguhkan masakan sedap untuk famili adalah suatu hal yang menggembirakan bagi kamu sendiri. Kewajiban seorang ibu Tidak sekadar menangani rumah saja, tetapi kamu juga harus memastikan keperluan gizi tercukupi dan santapan yang dimakan keluarga tercinta wajib enak.

Di era  sekarang, anda memang bisa mengorder hidangan siap saji walaupun tidak harus susah memasaknya dahulu. Namun banyak juga orang yang selalu mau memberikan yang terlezat untuk keluarganya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai dengan masakan kesukaan keluarga tercinta. 



Mungkinkah kamu seorang penikmat ayam lava semeru?. Tahukah kamu, ayam lava semeru merupakan sajian khas di Indonesia yang saat ini digemari oleh kebanyakan orang di berbagai wilayah di Indonesia. Kalian dapat memasak ayam lava semeru sendiri di rumah dan boleh jadi santapan favorit di akhir pekanmu.

Kita tak perlu bingung untuk menyantap ayam lava semeru, karena ayam lava semeru tidak sukar untuk didapatkan dan juga kamu pun bisa membuatnya sendiri di tempatmu. ayam lava semeru bisa dimasak dengan berbagai cara. Sekarang sudah banyak sekali resep modern yang menjadikan ayam lava semeru lebih nikmat.

Resep ayam lava semeru pun mudah dibuat, lho. Anda jangan capek-capek untuk memesan ayam lava semeru, sebab Kita bisa menghidangkan ditempatmu. Bagi Kita yang ingin mencobanya, berikut ini cara untuk membuat ayam lava semeru yang lezat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Lava Semeru:

1. Gunakan  Bahan
1. Sediakan  Ayam bagian paha 1/2kg isi 4
1. Gunakan 1 ruas jari laos
1. Ambil 4 Bawang putih
1. Gunakan 8 Bawang merah
1. Sediakan sesuai selera Cabe rawit setan
1. Sediakan secukupnya Garam
1. Sediakan secukupnya Merica
1. Gunakan secukupnya Kaldu jamur




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Lava Semeru:

1. Cuci bersih ayam kemudian rebus sampai matang, tambahkan garam, merica, kaldu jamur secukupnya
1. Sambil lalu ulek bawang merah, bawang putih, cabe rawit setan, jgn lupa geprek laosnya
1. Setelah ayam matang sempurna, goreng ayam jangan sampai garing, cukup digoreng hingga warna luar berubah kecoklatan lalu angkat tiriskan
1. Panaskan sedikit minyak, masukkan laos terlebih dahulu tunggu sampai wanginya keluar lalu masukkan bumbu ulekan yg tadi sudah disiapkan
1. Setelah bumbu matang masukkan sedikit kaldu dr sisa rebusan ayam tadi tunggu hingga menyatu dan masukkan ayam yg sudah digoreng tadi
1. Tambahkan garam, kaldu jamur dan merica, koreksi rasa daaan siap dinikmati dg nasi panas. Dijamin makin nambah nafsu makan. Selamat mencoba




Ternyata resep ayam lava semeru yang mantab tidak ribet ini enteng sekali ya! Kalian semua mampu memasaknya. Resep ayam lava semeru Cocok sekali untuk kita yang baru akan belajar memasak maupun bagi kamu yang sudah lihai dalam memasak.

Tertarik untuk mencoba buat resep ayam lava semeru nikmat tidak ribet ini? Kalau kalian mau, ayo kamu segera buruan siapin alat-alat dan bahannya, lantas bikin deh Resep ayam lava semeru yang nikmat dan tidak rumit ini. Betul-betul mudah kan. 

Jadi, daripada kita berlama-lama, maka kita langsung saja hidangkan resep ayam lava semeru ini. Dijamin anda tiidak akan menyesal bikin resep ayam lava semeru lezat tidak rumit ini! Selamat mencoba dengan resep ayam lava semeru mantab tidak rumit ini di rumah masing-masing,ya!.

