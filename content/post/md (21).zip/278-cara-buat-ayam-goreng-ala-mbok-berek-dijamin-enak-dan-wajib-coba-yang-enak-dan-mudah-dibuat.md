---
description: "Cara buat Ayam Goreng Ala Mbok Berek (Dijamin Enak dan Wajib Coba) yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Goreng Ala Mbok Berek (Dijamin Enak dan Wajib Coba) yang enak dan Mudah Dibuat"
slug: 278-cara-buat-ayam-goreng-ala-mbok-berek-dijamin-enak-dan-wajib-coba-yang-enak-dan-mudah-dibuat
date: 2021-03-28T04:28:15.778Z
image: https://img-global.cpcdn.com/recipes/c171cc18b001a08f/680x482cq70/ayam-goreng-ala-mbok-berek-dijamin-enak-dan-wajib-coba-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c171cc18b001a08f/680x482cq70/ayam-goreng-ala-mbok-berek-dijamin-enak-dan-wajib-coba-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c171cc18b001a08f/680x482cq70/ayam-goreng-ala-mbok-berek-dijamin-enak-dan-wajib-coba-foto-resep-utama.jpg
author: Mabel Patterson
ratingvalue: 3.9
reviewcount: 14
recipeingredient:
- "1 Ekor Ayam Kampung Saya Pakai Ayam Negri"
- "1 Buah Jeruk Nipis"
- "3 lbr Daun Salam"
- "1 Batang Sereh di Geprek"
- "100 ml Santan Instan dicampur dengan 400 ml Air"
- " Bumbu Halus"
- "9 Siung Bawang Merah"
- "6 Siung Bawang Putih"
- "4 Butir Kemiri"
- "1 sdt Ketumbar"
- "1 cm Kunyit optional"
- "1 sdt Gula"
- "Secukupnya garam me  2 sdt"
- " Adonan Kremesan"
- "300 ml Sisa Air Ungkep Ayam"
- "2 sdm Munjung Tepung Beras"
- "125 gr Tepung Sagu"
- "1/2 sdt Baking Soda"
- "1 Butir Kuning Telur"
recipeinstructions:
- "Siapkan Bahan Bahan"
- "Cuci bersih ayam lalu kucuri dengan perasan air Jeruk Nipis, diamkan selama 15 menit kemudian bilas kembali hingga bersih dan sisihkan."
- "Siapkan wajan, lalu masukkan bumbu halus + sereh + daun salam + garam + gula dan Santan"
- "Aduk agar bumbu tercampur rata, kemudian masukkan ayam yg sudaj dibersihkan hingga ayam terendam. Masak dengan api kecil dan hingga air menyusut dan ayam empuk."
- "Setelah itu angkat ayam dan pisahkan dari airnya. Sisa air ungkep akan digunakan sebagai bahan kremesan."
- "Panaskan minyak, kemudian buat adonan kremesan. Masukkan Telur kedalam sisa air ungkep + tepung beras + tepung sagu, aduk hingga adonan tercampur rata. *NOTE* : Untuk baking Soda dimasukkan saat minyak sdh benar2 panas dan ayam siap di goreng."
- "Setelah minyak panas, masukkan baking soda kedalam adonan kremesan, aduk rata dan celupkan ayam kedalam adonannya."
- "Goreng ayam lalu kucuri dengan teknik melingkar dengan tangan. Nanti akan membuyar sndiri kremesannya. Jika sudah kaku balik ayamnya"
- "Masak hingga kuning kecoklatan angkat dan tiriskan."
- "Ayam Goreng Ala Mbok Berek siap disajikan. Rasanya endesssss cocol sambel dan lalapan oke. Selesai 😊"
categories:
- Resep
tags:
- ayam
- goreng
- ala

katakunci: ayam goreng ala 
nutrition: 149 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Goreng Ala Mbok Berek (Dijamin Enak dan Wajib Coba)](https://img-global.cpcdn.com/recipes/c171cc18b001a08f/680x482cq70/ayam-goreng-ala-mbok-berek-dijamin-enak-dan-wajib-coba-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan santapan menggugah selera pada keluarga merupakan suatu hal yang memuaskan bagi kamu sendiri. Kewajiban seorang istri bukan sekedar menangani rumah saja, namun anda pun wajib menyediakan keperluan gizi tercukupi dan santapan yang dikonsumsi orang tercinta mesti enak.

Di era  saat ini, anda memang bisa membeli hidangan instan tidak harus capek membuatnya terlebih dahulu. Namun ada juga mereka yang selalu mau menghidangkan yang terlezat untuk orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan kesukaan orang tercinta. 



Mungkinkah anda adalah seorang penyuka ayam goreng ala mbok berek (dijamin enak dan wajib coba)?. Asal kamu tahu, ayam goreng ala mbok berek (dijamin enak dan wajib coba) merupakan makanan khas di Nusantara yang sekarang disukai oleh orang-orang di hampir setiap wilayah di Indonesia. Kita dapat memasak ayam goreng ala mbok berek (dijamin enak dan wajib coba) olahan sendiri di rumahmu dan boleh dijadikan camilan kesenanganmu di akhir pekan.

Kalian tidak perlu bingung untuk mendapatkan ayam goreng ala mbok berek (dijamin enak dan wajib coba), sebab ayam goreng ala mbok berek (dijamin enak dan wajib coba) gampang untuk ditemukan dan kamu pun boleh menghidangkannya sendiri di tempatmu. ayam goreng ala mbok berek (dijamin enak dan wajib coba) bisa dibuat memalui beraneka cara. Kini pun telah banyak sekali cara modern yang menjadikan ayam goreng ala mbok berek (dijamin enak dan wajib coba) semakin lebih mantap.

Resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) pun gampang sekali dibikin, lho. Kita jangan repot-repot untuk memesan ayam goreng ala mbok berek (dijamin enak dan wajib coba), lantaran Kamu dapat membuatnya di rumah sendiri. Bagi Kalian yang ingin mencobanya, berikut ini cara membuat ayam goreng ala mbok berek (dijamin enak dan wajib coba) yang lezat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Goreng Ala Mbok Berek (Dijamin Enak dan Wajib Coba):

1. Siapkan 1 Ekor Ayam Kampung (Saya Pakai Ayam Negri)
1. Siapkan 1 Buah Jeruk Nipis
1. Siapkan 3 lbr Daun Salam
1. Siapkan 1 Batang Sereh di Geprek
1. Siapkan 100 ml Santan Instan (dicampur dengan 400 ml Air)
1. Ambil  Bumbu Halus
1. Ambil 9 Siung Bawang Merah
1. Ambil 6 Siung Bawang Putih
1. Sediakan 4 Butir Kemiri
1. Gunakan 1 sdt Ketumbar
1. Sediakan 1 cm Kunyit (optional)
1. Sediakan 1 sdt Gula
1. Gunakan Secukupnya garam (me : 2 sdt)
1. Ambil  Adonan Kremesan
1. Gunakan 300 ml Sisa Air Ungkep Ayam
1. Sediakan 2 sdm Munjung Tepung Beras
1. Siapkan 125 gr Tepung Sagu
1. Siapkan 1/2 sdt Baking Soda
1. Ambil 1 Butir Kuning Telur




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Ala Mbok Berek (Dijamin Enak dan Wajib Coba):

1. Siapkan Bahan Bahan
1. Cuci bersih ayam lalu kucuri dengan perasan air Jeruk Nipis, diamkan selama 15 menit kemudian bilas kembali hingga bersih dan sisihkan.
1. Siapkan wajan, lalu masukkan bumbu halus + sereh + daun salam + garam + gula dan Santan
1. Aduk agar bumbu tercampur rata, kemudian masukkan ayam yg sudaj dibersihkan hingga ayam terendam. Masak dengan api kecil dan hingga air menyusut dan ayam empuk.
1. Setelah itu angkat ayam dan pisahkan dari airnya. Sisa air ungkep akan digunakan sebagai bahan kremesan.
1. Panaskan minyak, kemudian buat adonan kremesan. Masukkan Telur kedalam sisa air ungkep + tepung beras + tepung sagu, aduk hingga adonan tercampur rata. *NOTE* : Untuk baking Soda dimasukkan saat minyak sdh benar2 panas dan ayam siap di goreng.
1. Setelah minyak panas, masukkan baking soda kedalam adonan kremesan, aduk rata dan celupkan ayam kedalam adonannya.
1. Goreng ayam lalu kucuri dengan teknik melingkar dengan tangan. Nanti akan membuyar sndiri kremesannya. Jika sudah kaku balik ayamnya
1. Masak hingga kuning kecoklatan angkat dan tiriskan.
1. Ayam Goreng Ala Mbok Berek siap disajikan. Rasanya endesssss cocol sambel dan lalapan oke. Selesai 😊




Wah ternyata resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) yang mantab tidak ribet ini mudah sekali ya! Anda Semua bisa menghidangkannya. Cara buat ayam goreng ala mbok berek (dijamin enak dan wajib coba) Sesuai banget buat kalian yang sedang belajar memasak ataupun juga untuk anda yang telah hebat dalam memasak.

Apakah kamu tertarik mencoba membuat resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) mantab tidak ribet ini? Kalau anda ingin, ayo kamu segera siapkan alat dan bahannya, lalu buat deh Resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) yang nikmat dan sederhana ini. Betul-betul gampang kan. 

Oleh karena itu, ketimbang kita berlama-lama, ayo langsung aja bikin resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) ini. Pasti kamu tak akan nyesel sudah buat resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) enak sederhana ini! Selamat mencoba dengan resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) nikmat tidak ribet ini di tempat tinggal masing-masing,ya!.

