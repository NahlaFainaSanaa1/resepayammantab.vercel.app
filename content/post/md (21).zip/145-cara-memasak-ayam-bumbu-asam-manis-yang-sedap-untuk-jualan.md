---
description: "Cara memasak Ayam bumbu asam manis yang sedap Untuk Jualan"
title: "Cara memasak Ayam bumbu asam manis yang sedap Untuk Jualan"
slug: 145-cara-memasak-ayam-bumbu-asam-manis-yang-sedap-untuk-jualan
date: 2021-06-12T21:54:59.083Z
image: https://img-global.cpcdn.com/recipes/bff517ddc7b03a33/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bff517ddc7b03a33/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bff517ddc7b03a33/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
author: Tillie Peterson
ratingvalue: 3.4
reviewcount: 15
recipeingredient:
- "500 Gram ayam"
- "1 Buah wortel"
- "2 Buah daun bawang"
- "5 Buah cabe merah"
- "1 Siung bawang bombay"
- "2 Siung bawang putih"
- "1 Buah Tomat"
- "5 Sendok saus tomat"
- "3 Sendok saus sambal"
- "1 Butir telur ayam"
- " Tepung bumbu"
- " merica"
- " garam"
- " gula pasir"
- " Air"
recipeinstructions:
- "Buang tulang ayam, lalu potong kecil - kecil sesuai selera. Campurkan dengan merica dan garam sampai merata. Lalu diamkan selama 10 menit."
- "Setelah 10 Menit, masukkan telur lalu tambahkan tepung bumbu. Ratakan."
- "Goreng ayam yang telah dibaluri tepung bumbu hingga matang. Tiriskan."
- "Tumis bawang putih yang dicincang kasar. Setelah berbau harus, masukkan bawang bombay dan cabe merah."
- "Setelah layu, masukkan wortel yang sudah dipotong korek api. Masukkan saus asam dan saus sambal. Tambahkan air. Masak hingga meletup letup."
- "Setelah air menyusut, masukkan daun bawang. Lalu tambahkan ayam yang telah digoreng tadi."
- "Tambahkan gula pasir, garam dan merica."
- "Koreksi rasa."
- "Matang deh......."
categories:
- Resep
tags:
- ayam
- bumbu
- asam

katakunci: ayam bumbu asam 
nutrition: 103 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam bumbu asam manis](https://img-global.cpcdn.com/recipes/bff517ddc7b03a33/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg)

Apabila anda seorang orang tua, menyuguhkan masakan nikmat kepada orang tercinta adalah suatu hal yang memuaskan untuk kita sendiri. Tugas seorang ibu bukan cuma menangani rumah saja, tetapi kamu juga harus memastikan kebutuhan gizi tercukupi dan santapan yang disantap orang tercinta mesti lezat.

Di waktu  sekarang, anda sebenarnya bisa membeli hidangan siap saji walaupun tanpa harus repot memasaknya dahulu. Namun banyak juga lho mereka yang memang mau memberikan hidangan yang terenak untuk keluarganya. Sebab, menyajikan masakan sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan selera famili. 



Apakah anda merupakan salah satu penikmat ayam bumbu asam manis?. Asal kamu tahu, ayam bumbu asam manis adalah sajian khas di Indonesia yang sekarang disenangi oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Kamu bisa membuat ayam bumbu asam manis hasil sendiri di rumah dan boleh jadi hidangan kegemaranmu di akhir pekanmu.

Kalian tidak perlu bingung untuk mendapatkan ayam bumbu asam manis, sebab ayam bumbu asam manis tidak sulit untuk ditemukan dan kita pun dapat membuatnya sendiri di rumah. ayam bumbu asam manis dapat diolah memalui beragam cara. Kini sudah banyak banget resep kekinian yang menjadikan ayam bumbu asam manis lebih lezat.

Resep ayam bumbu asam manis juga gampang sekali dibikin, lho. Anda tidak usah repot-repot untuk memesan ayam bumbu asam manis, sebab Anda dapat membuatnya sendiri di rumah. Bagi Kalian yang hendak membuatnya, berikut ini resep menyajikan ayam bumbu asam manis yang mantab yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam bumbu asam manis:

1. Ambil 500 Gram ayam
1. Siapkan 1 Buah wortel
1. Gunakan 2 Buah daun bawang
1. Siapkan 5 Buah cabe merah
1. Ambil 1 Siung bawang bombay
1. Siapkan 2 Siung bawang putih
1. Gunakan 1 Buah Tomat
1. Ambil 5 Sendok saus tomat
1. Gunakan 3 Sendok saus sambal
1. Gunakan 1 Butir telur ayam
1. Sediakan  Tepung bumbu
1. Siapkan  merica
1. Sediakan  garam
1. Ambil  gula pasir
1. Ambil  Air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam bumbu asam manis:

1. Buang tulang ayam, lalu potong kecil - kecil sesuai selera. Campurkan dengan merica dan garam sampai merata. Lalu diamkan selama 10 menit.
1. Setelah 10 Menit, masukkan telur lalu tambahkan tepung bumbu. Ratakan.
1. Goreng ayam yang telah dibaluri tepung bumbu hingga matang. Tiriskan.
1. Tumis bawang putih yang dicincang kasar. Setelah berbau harus, masukkan bawang bombay dan cabe merah.
1. Setelah layu, masukkan wortel yang sudah dipotong korek api. Masukkan saus asam dan saus sambal. Tambahkan air. Masak hingga meletup letup.
1. Setelah air menyusut, masukkan daun bawang. Lalu tambahkan ayam yang telah digoreng tadi.
1. Tambahkan gula pasir, garam dan merica.
1. Koreksi rasa.
1. Matang deh.......




Ternyata cara membuat ayam bumbu asam manis yang mantab tidak ribet ini enteng sekali ya! Semua orang dapat mencobanya. Cara Membuat ayam bumbu asam manis Sangat cocok sekali untuk anda yang baru belajar memasak maupun untuk anda yang sudah lihai memasak.

Tertarik untuk mulai mencoba membuat resep ayam bumbu asam manis lezat simple ini? Kalau ingin, ayo kalian segera menyiapkan peralatan dan bahannya, kemudian bikin deh Resep ayam bumbu asam manis yang nikmat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Maka, ketimbang anda berlama-lama, ayo langsung aja bikin resep ayam bumbu asam manis ini. Dijamin anda tiidak akan menyesal sudah bikin resep ayam bumbu asam manis nikmat simple ini! Selamat berkreasi dengan resep ayam bumbu asam manis mantab tidak rumit ini di tempat tinggal sendiri,ya!.

