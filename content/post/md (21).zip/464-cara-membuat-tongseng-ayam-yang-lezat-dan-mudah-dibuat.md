---
description: "Cara membuat Tongseng Ayam yang lezat dan Mudah Dibuat"
title: "Cara membuat Tongseng Ayam yang lezat dan Mudah Dibuat"
slug: 464-cara-membuat-tongseng-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-04-29T09:24:54.236Z
image: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
author: Walter Mathis
ratingvalue: 3.5
reviewcount: 10
recipeingredient:
- "1/2 kg ayam aku campur sama fillet dada"
- "750 ml air matang"
- "200 gr kol"
- "1 buah tomat ukuran sedang"
- "1 batang daun bawang"
- "10 cabai rawit"
- " Bumbu halus"
- "10 butir bawang merah iris 2 butir"
- "4 bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "3 butir kemiri"
- "1 sdm ketumbar bubuk"
- " Bahan cemplung"
- "4 lembar daun salam"
- "4 lembar daun jeruk"
- "2 batang serai"
- "2 ruas lengkuas"
- "750 ml air"
- "1 1/2 sdt garam"
- "1 sdt penyedap"
- "Secukupnya kecap"
- "1 sdt gula pasir"
- "25 ml santan"
recipeinstructions:
- "Persiapkan semua bahan"
- "Tumis irisan bawang merah hingga harum"
- "Masukan bumbu halus, beserta bumbu cemplung, tumis hingga matang, berwarna kecoklatan. Kemudian masukan ayam aduk hingga rata"
- "Tuangkan air matang, tunggu higga mendidih kemudian masukan kecap, garam, gula, penyedap aduk rata"
- "Masukan santan dan tunggu air hingga menyusut"
- "Apabil air sudah menyusut, masukan cabai rawit, kol, tomat dan daun bawang. Tunggu hingga sayur agak layu. Tes rasa dan siap di santap"
categories:
- Resep
tags:
- tongseng
- ayam

katakunci: tongseng ayam 
nutrition: 276 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Lunch

---


![Tongseng Ayam](https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg)

Apabila kamu seorang yang hobi memasak, menyuguhkan panganan lezat buat keluarga tercinta adalah hal yang sangat menyenangkan bagi anda sendiri. Kewajiban seorang ibu Tidak cuman menjaga rumah saja, namun anda juga harus menyediakan keperluan gizi tercukupi dan juga panganan yang disantap keluarga tercinta mesti lezat.

Di masa  saat ini, anda memang bisa mengorder santapan instan walaupun tanpa harus susah mengolahnya dulu. Tetapi banyak juga lho orang yang memang mau menyajikan yang terenak untuk keluarganya. Lantaran, memasak yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai selera orang tercinta. 



Apakah anda merupakan seorang penggemar tongseng ayam?. Asal kamu tahu, tongseng ayam adalah hidangan khas di Nusantara yang saat ini disenangi oleh banyak orang di berbagai tempat di Nusantara. Anda dapat menghidangkan tongseng ayam buatan sendiri di rumah dan pasti jadi hidangan favorit di hari libur.

Kita jangan bingung untuk memakan tongseng ayam, karena tongseng ayam sangat mudah untuk ditemukan dan kamu pun dapat mengolahnya sendiri di rumah. tongseng ayam bisa diolah memalui berbagai cara. Kini pun sudah banyak cara modern yang menjadikan tongseng ayam semakin enak.

Resep tongseng ayam pun mudah sekali untuk dibuat, lho. Kalian tidak perlu ribet-ribet untuk memesan tongseng ayam, sebab Kita bisa menyajikan di rumahmu. Bagi Kita yang ingin menghidangkannya, berikut cara untuk membuat tongseng ayam yang lezat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Tongseng Ayam:

1. Sediakan 1/2 kg ayam, aku campur sama fillet dada
1. Siapkan 750 ml air matang
1. Siapkan 200 gr kol
1. Ambil 1 buah tomat ukuran sedang
1. Ambil 1 batang daun bawang
1. Ambil 10 cabai rawit
1. Gunakan  Bumbu halus
1. Siapkan 10 butir bawang merah, iris 2 butir
1. Siapkan 4 bawang putih
1. Sediakan 1 ruas jahe
1. Sediakan 1 ruas kunyit
1. Ambil 3 butir kemiri
1. Siapkan 1 sdm ketumbar bubuk
1. Sediakan  Bahan cemplung
1. Gunakan 4 lembar daun salam
1. Siapkan 4 lembar daun jeruk
1. Sediakan 2 batang serai
1. Siapkan 2 ruas lengkuas
1. Siapkan 750 ml air
1. Sediakan 1 1/2 sdt garam
1. Ambil 1 sdt penyedap
1. Ambil Secukupnya kecap
1. Siapkan 1 sdt gula pasir
1. Gunakan 25 ml santan




<!--inarticleads2-->

##### Cara membuat Tongseng Ayam:

1. Persiapkan semua bahan
1. Tumis irisan bawang merah hingga harum
1. Masukan bumbu halus, beserta bumbu cemplung, tumis hingga matang, berwarna kecoklatan. Kemudian masukan ayam aduk hingga rata
1. Tuangkan air matang, tunggu higga mendidih kemudian masukan kecap, garam, gula, penyedap aduk rata
1. Masukan santan dan tunggu air hingga menyusut
1. Apabil air sudah menyusut, masukan cabai rawit, kol, tomat dan daun bawang. Tunggu hingga sayur agak layu. Tes rasa dan siap di santap




Ternyata resep tongseng ayam yang enak tidak rumit ini enteng sekali ya! Kalian semua dapat memasaknya. Resep tongseng ayam Cocok banget buat kita yang baru akan belajar memasak ataupun untuk anda yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba buat resep tongseng ayam mantab simple ini? Kalau anda ingin, ayo kamu segera siapkan alat-alat dan bahannya, lantas bikin deh Resep tongseng ayam yang enak dan tidak rumit ini. Sangat gampang kan. 

Maka dari itu, daripada kamu diam saja, maka langsung aja buat resep tongseng ayam ini. Dijamin anda gak akan nyesel sudah buat resep tongseng ayam lezat simple ini! Selamat mencoba dengan resep tongseng ayam lezat sederhana ini di rumah kalian sendiri,ya!.

