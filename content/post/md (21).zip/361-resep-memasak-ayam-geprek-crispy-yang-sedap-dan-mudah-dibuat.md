---
description: "Resep memasak Ayam Geprek / Crispy yang sedap dan Mudah Dibuat"
title: "Resep memasak Ayam Geprek / Crispy yang sedap dan Mudah Dibuat"
slug: 361-resep-memasak-ayam-geprek-crispy-yang-sedap-dan-mudah-dibuat
date: 2021-06-11T23:04:05.950Z
image: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
author: Alta Perkins
ratingvalue: 3.5
reviewcount: 8
recipeingredient:
- "Secukupnya ayam fillet garam jeniper"
- " Bumbu marinasi "
- "5 Bawang putih yg sudah dihaluskan"
- "1 sdt Lada bubuk"
- "1 sdm Kaldu bubuk"
- "1 sdm Garam"
- "1 sdm Cabe bubuk optional"
- "1 sdm Ketumbar"
- " Bumbu Baluran Tepung "
- " Tepung terigu agak banyakan"
- "1 sdm garam"
- "1 sdm kaldu bubuk"
- "1 sdm lada bubuk"
- "1 sdm ketumbar bubuk"
- "1 sdt baking powder  kalo gk ada boleh pake baking soda"
- " Bahan celupan air "
- " Air dingin  es"
- "1 sdt baking powder  baking soda"
- "1 sdt kaldu bubuk"
- "1 sdt garam"
recipeinstructions:
- "Bersihkan ayam, baluri jeniper dan garam, biarkan sebentar"
- "Siapkan bumbu marinasi, tambahkan ke ayam, aduk rata, biarkan selama semalaman di kulkas."
- "Siapkan bahan tepung balur, aduk rata. Sisihkan."
- "Siapkan bahan celupan air, aduk hingga merata semua."
- "Balurkan ayam yg sudah di marinasi ke dalam tepung, aduk dengan dibalik2 spt di gulung2, jangan di tekan2, lakukan selama 1-2 mnit"
- "Celupkan ke dalam campuran air es, angkat, lalu tiriskan airnya, usahakan air nya benar2 tertiriskan, supaya tepung nya tidak bergumpal2"
- "Lalu baluri lagi dg tepung tadi, guling2kan ayam nya sampai tepung nya terbentuk kriwil2 dn banyak"
- "Jika di rasa tepung kurang tebal, bisa di celupkan lagi ke air es, lalu baluri lg dg tepung"
- "Sambil masih di aduk ayamnya, panas kan minyak, stelah selesai proses baluran tepung, goreng ayam dengan posisi ayam bener2 tenggelam ke dlm minyak, minyak nya harus banyak dan bener2 udah panas pas di celupin ayam nya ke minyak"
- "Kalo sudah keemasan, balik ayamnya. Cukup 1 x balik saja. Stelah matang keemasan, angkat dn tiriskan"
- "Geprek ayam nya sedikit, baluri sambal di atasnya"
- "Siap di nikmati dengan nasi hangat :)"
categories:
- Resep
tags:
- ayam
- geprek
- 

katakunci: ayam geprek  
nutrition: 236 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Geprek / Crispy](https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg)

Jika kita seorang yang hobi masak, mempersiapkan santapan nikmat buat famili adalah suatu hal yang membahagiakan bagi anda sendiri. Tanggung jawab seorang  wanita bukan sekedar mengatur rumah saja, tetapi kamu juga wajib memastikan kebutuhan gizi terpenuhi dan juga masakan yang dikonsumsi orang tercinta wajib enak.

Di masa  sekarang, kamu memang dapat membeli hidangan jadi meski tidak harus repot membuatnya dahulu. Tetapi banyak juga mereka yang memang mau menyajikan yang terlezat untuk keluarganya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai makanan kesukaan orang tercinta. 



Mungkinkah anda adalah salah satu penyuka ayam geprek / crispy?. Asal kamu tahu, ayam geprek / crispy merupakan makanan khas di Indonesia yang kini digemari oleh orang-orang di berbagai wilayah di Nusantara. Kalian bisa menyajikan ayam geprek / crispy sendiri di rumahmu dan dapat dijadikan camilan favoritmu di akhir pekanmu.

Kita tidak usah bingung jika kamu ingin memakan ayam geprek / crispy, sebab ayam geprek / crispy tidak sukar untuk ditemukan dan juga kamu pun bisa mengolahnya sendiri di tempatmu. ayam geprek / crispy dapat dibuat dengan bermacam cara. Sekarang sudah banyak sekali resep modern yang menjadikan ayam geprek / crispy semakin lebih mantap.

Resep ayam geprek / crispy pun gampang dihidangkan, lho. Kita tidak perlu repot-repot untuk memesan ayam geprek / crispy, lantaran Kita bisa membuatnya sendiri di rumah. Bagi Anda yang akan menghidangkannya, inilah resep untuk membuat ayam geprek / crispy yang lezat yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Geprek / Crispy:

1. Ambil Secukupnya ayam fillet, garam, jeniper
1. Siapkan  Bumbu marinasi :
1. Sediakan 5 Bawang putih yg sudah dihaluskan
1. Siapkan 1 sdt Lada bubuk
1. Sediakan 1 sdm Kaldu bubuk
1. Gunakan 1 sdm Garam
1. Gunakan 1 sdm Cabe bubuk (optional)
1. Sediakan 1 sdm Ketumbar
1. Ambil  Bumbu Baluran Tepung :
1. Ambil  Tepung terigu (agak banyakan)
1. Sediakan 1 sdm garam
1. Sediakan 1 sdm kaldu bubuk
1. Gunakan 1 sdm lada bubuk
1. Ambil 1 sdm ketumbar bubuk
1. Siapkan 1 sdt baking powder / kalo gk ada boleh pake baking soda
1. Siapkan  Bahan celupan air :
1. Gunakan  Air dingin + es
1. Sediakan 1 sdt baking powder / baking soda
1. Sediakan 1 sdt kaldu bubuk
1. Ambil 1 sdt garam




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Geprek / Crispy:

1. Bersihkan ayam, baluri jeniper dan garam, biarkan sebentar
1. Siapkan bumbu marinasi, tambahkan ke ayam, aduk rata, biarkan selama semalaman di kulkas.
1. Siapkan bahan tepung balur, aduk rata. Sisihkan.
1. Siapkan bahan celupan air, aduk hingga merata semua.
1. Balurkan ayam yg sudah di marinasi ke dalam tepung, aduk dengan dibalik2 spt di gulung2, jangan di tekan2, lakukan selama 1-2 mnit
1. Celupkan ke dalam campuran air es, angkat, lalu tiriskan airnya, usahakan air nya benar2 tertiriskan, supaya tepung nya tidak bergumpal2
1. Lalu baluri lagi dg tepung tadi, guling2kan ayam nya sampai tepung nya terbentuk kriwil2 dn banyak
1. Jika di rasa tepung kurang tebal, bisa di celupkan lagi ke air es, lalu baluri lg dg tepung
1. Sambil masih di aduk ayamnya, panas kan minyak, stelah selesai proses baluran tepung, goreng ayam dengan posisi ayam bener2 tenggelam ke dlm minyak, minyak nya harus banyak dan bener2 udah panas pas di celupin ayam nya ke minyak
1. Kalo sudah keemasan, balik ayamnya. Cukup 1 x balik saja. - Stelah matang keemasan, angkat dn tiriskan
1. Geprek ayam nya sedikit, baluri sambal di atasnya
1. Siap di nikmati dengan nasi hangat :)




Ternyata cara membuat ayam geprek / crispy yang lezat simple ini enteng sekali ya! Semua orang bisa memasaknya. Resep ayam geprek / crispy Sesuai sekali untuk kamu yang baru mau belajar memasak ataupun juga untuk kalian yang telah lihai memasak.

Tertarik untuk mencoba buat resep ayam geprek / crispy nikmat simple ini? Kalau anda ingin, yuk kita segera buruan siapkan peralatan dan bahannya, lantas bikin deh Resep ayam geprek / crispy yang lezat dan tidak ribet ini. Betul-betul taidak sulit kan. 

Maka dari itu, ketimbang kamu berlama-lama, maka kita langsung sajikan resep ayam geprek / crispy ini. Dijamin kalian gak akan nyesel sudah membuat resep ayam geprek / crispy lezat tidak rumit ini! Selamat mencoba dengan resep ayam geprek / crispy enak simple ini di rumah kalian sendiri,ya!.

