---
description: "Cara buat Sempol Ayam tanpa tusukan yang nikmat dan Mudah Dibuat"
title: "Cara buat Sempol Ayam tanpa tusukan yang nikmat dan Mudah Dibuat"
slug: 161-cara-buat-sempol-ayam-tanpa-tusukan-yang-nikmat-dan-mudah-dibuat
date: 2021-06-13T15:04:46.227Z
image: https://img-global.cpcdn.com/recipes/d21d8ce6f3c01a0e/680x482cq70/sempol-ayam-tanpa-tusukan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d21d8ce6f3c01a0e/680x482cq70/sempol-ayam-tanpa-tusukan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d21d8ce6f3c01a0e/680x482cq70/sempol-ayam-tanpa-tusukan-foto-resep-utama.jpg
author: Mitchell Baker
ratingvalue: 3.1
reviewcount: 6
recipeingredient:
- "370-400 gram ayam giling"
- "3 sendok makan tepung tapioka"
- "1 sendok makan tepung terigu"
- "1 butir telur"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "1,5 sendok teh garam"
- "1/4 sendok teh kaldu bubuk"
- " Air untuk merebus"
- " Minyak untuk menggoreng"
- " Pencelup"
- "2 butir telur kocok lepas"
recipeinstructions:
- "Kupas lalu goreng bawang merah dan bawang putij sampai harum. Setelah digoreng, haluskan."
- "Campurkan ayam giling, tepung tapioka, tepung terigu, bawang merah bawang putih halus, telur, garam, kaldu bubuk. Campur rata."
- "Olesi tangan dengan minyak goreng agar tidak lengket. Ambil sesendok adonan dan bentuk memanjang"
- "Panaskan air sampai mendidih. Masukkan sempol ke dalam air tersebut"
- "Tunggu sampai sempol matang. Kalau sudah matang, sempol akan mengapung. Kalau sudah mengampung angkat dan tiriskan. Biarkan hingga dingin"
- "Panaskan minyak goreng, ambil sempol dan celupkan ke dalam kocokan telur. Goreng hingga telur memutih. Angkat"
- "Masukkan kembali sempol yang sudah digoreng tadi ke dalam kocokan telur (jadi dua kali celup agar terbalut tebal), lalu goreng lagi hingga kecoklatan. Angkat dan sajikan dengan saus sambal."
categories:
- Resep
tags:
- sempol
- ayam
- tanpa

katakunci: sempol ayam tanpa 
nutrition: 254 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Sempol Ayam tanpa tusukan](https://img-global.cpcdn.com/recipes/d21d8ce6f3c01a0e/680x482cq70/sempol-ayam-tanpa-tusukan-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan masakan menggugah selera bagi keluarga tercinta adalah suatu hal yang memuaskan untuk kita sendiri. Kewajiban seorang  wanita bukan sekadar menangani rumah saja, tapi kamu pun harus menyediakan keperluan nutrisi tercukupi dan panganan yang dimakan anak-anak mesti sedap.

Di masa  sekarang, kamu memang bisa memesan santapan instan walaupun tanpa harus susah mengolahnya dulu. Tetapi ada juga lho mereka yang memang ingin memberikan yang terlezat bagi orang tercintanya. Sebab, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai kesukaan famili. 



Mungkinkah anda adalah salah satu penyuka sempol ayam tanpa tusukan?. Asal kamu tahu, sempol ayam tanpa tusukan adalah makanan khas di Indonesia yang kini disenangi oleh orang-orang dari berbagai tempat di Nusantara. Kita dapat menghidangkan sempol ayam tanpa tusukan sendiri di rumah dan dapat dijadikan santapan kesukaanmu di akhir pekan.

Kamu tak perlu bingung jika kamu ingin menyantap sempol ayam tanpa tusukan, karena sempol ayam tanpa tusukan mudah untuk ditemukan dan kalian pun boleh mengolahnya sendiri di rumah. sempol ayam tanpa tusukan bisa dibuat dengan berbagai cara. Kini pun sudah banyak sekali cara kekinian yang membuat sempol ayam tanpa tusukan lebih mantap.

Resep sempol ayam tanpa tusukan juga gampang dihidangkan, lho. Kamu jangan repot-repot untuk membeli sempol ayam tanpa tusukan, tetapi Kalian bisa menyiapkan di rumahmu. Bagi Kita yang ingin menghidangkannya, di bawah ini adalah cara menyajikan sempol ayam tanpa tusukan yang enak yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Sempol Ayam tanpa tusukan:

1. Siapkan 370-400 gram ayam giling
1. Gunakan 3 sendok makan tepung tapioka
1. Siapkan 1 sendok makan tepung terigu
1. Sediakan 1 butir telur
1. Ambil 3 siung bawang putih
1. Ambil 5 siung bawang merah
1. Ambil 1,5 sendok teh garam
1. Ambil 1/4 sendok teh kaldu bubuk
1. Siapkan  Air untuk merebus
1. Siapkan  Minyak untuk menggoreng
1. Ambil  Pencelup
1. Sediakan 2 butir telur kocok lepas




<!--inarticleads2-->

##### Langkah-langkah membuat Sempol Ayam tanpa tusukan:

1. Kupas lalu goreng bawang merah dan bawang putij sampai harum. Setelah digoreng, haluskan.
<img src="https://img-global.cpcdn.com/steps/647623b786134c53/160x128cq70/sempol-ayam-tanpa-tusukan-langkah-memasak-1-foto.jpg" alt="Sempol Ayam tanpa tusukan">1. Campurkan ayam giling, tepung tapioka, tepung terigu, bawang merah bawang putih halus, telur, garam, kaldu bubuk. Campur rata.
1. Olesi tangan dengan minyak goreng agar tidak lengket. Ambil sesendok adonan dan bentuk memanjang
1. Panaskan air sampai mendidih. Masukkan sempol ke dalam air tersebut
1. Tunggu sampai sempol matang. Kalau sudah matang, sempol akan mengapung. Kalau sudah mengampung angkat dan tiriskan. Biarkan hingga dingin
1. Panaskan minyak goreng, ambil sempol dan celupkan ke dalam kocokan telur. Goreng hingga telur memutih. Angkat
1. Masukkan kembali sempol yang sudah digoreng tadi ke dalam kocokan telur (jadi dua kali celup agar terbalut tebal), lalu goreng lagi hingga kecoklatan. Angkat dan sajikan dengan saus sambal.




Wah ternyata resep sempol ayam tanpa tusukan yang mantab sederhana ini gampang sekali ya! Anda Semua dapat membuatnya. Cara buat sempol ayam tanpa tusukan Sesuai sekali untuk kamu yang baru belajar memasak ataupun juga untuk anda yang sudah ahli dalam memasak.

Apakah kamu mau mencoba bikin resep sempol ayam tanpa tusukan mantab sederhana ini? Kalau anda tertarik, ayo kamu segera siapin alat-alat dan bahannya, maka bikin deh Resep sempol ayam tanpa tusukan yang lezat dan tidak rumit ini. Sungguh taidak sulit kan. 

Oleh karena itu, daripada anda berfikir lama-lama, ayo kita langsung saja buat resep sempol ayam tanpa tusukan ini. Pasti anda gak akan menyesal membuat resep sempol ayam tanpa tusukan lezat tidak rumit ini! Selamat berkreasi dengan resep sempol ayam tanpa tusukan nikmat tidak rumit ini di tempat tinggal sendiri,oke!.

