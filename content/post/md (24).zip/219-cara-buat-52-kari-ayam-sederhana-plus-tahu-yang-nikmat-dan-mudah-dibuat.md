---
description: "Cara buat 52. Kari Ayam Sederhana plus Tahu yang nikmat dan Mudah Dibuat"
title: "Cara buat 52. Kari Ayam Sederhana plus Tahu yang nikmat dan Mudah Dibuat"
slug: 219-cara-buat-52-kari-ayam-sederhana-plus-tahu-yang-nikmat-dan-mudah-dibuat
date: 2021-04-18T11:22:20.925Z
image: https://img-global.cpcdn.com/recipes/330daa346bab8864/680x482cq70/52-kari-ayam-sederhana-plus-tahu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/330daa346bab8864/680x482cq70/52-kari-ayam-sederhana-plus-tahu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/330daa346bab8864/680x482cq70/52-kari-ayam-sederhana-plus-tahu-foto-resep-utama.jpg
author: Lucile Nichols
ratingvalue: 3.3
reviewcount: 5
recipeingredient:
- "1/2 ekor Ayam"
- "6 potong Tahu Putih"
- "1 bks santan Kara 65ml"
- "4 bh Cabe Merah Keriting"
- "10 bh Cabe Rawit Hijau"
- "10 siung Bawang Merah"
- "5 siung Bawang Putih"
- "Seruas jari Lengkuas"
- "Seruas jari Kunyit"
- "Seruas jari Jahe"
- "5 butir Kemiri"
- "1 sdm ketumbar"
- "1 batang Serai"
- "2 lembar Daun Salam"
- "2 lembar Daun Jeruk"
- "secukupnya Air Garam dan Gula"
recipeinstructions:
- "Siapkan dan bersihkan semua bahan. Ayam dipotong sesuai selera, tahu putih rendam diair garam."
- "Haluskan/blender semua bahan bumbu kecuali serai, daun salam dan daun jeruk"
- "Panaskan minyak dan tumis bumbu halus tadi. Aduk sampai harum, masukkan serai, daun salam dan daun jeruk."
- "Setelah harum. Masukkan potongan ayam. Aduk bolak balik. Lalu masukkan santan dan air secukupnya."
- "Goreng tahu putih dan masukkan ke dalam santan tadi. Aduk sampai santan dan ayam matang. Masukkan garam dan gula secukupnya."
- "Sajikan sebagai santapan bersama keluarga."
categories:
- Resep
tags:
- 52
- kari
- ayam

katakunci: 52 kari ayam 
nutrition: 153 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner

---


![52. Kari Ayam Sederhana plus Tahu](https://img-global.cpcdn.com/recipes/330daa346bab8864/680x482cq70/52-kari-ayam-sederhana-plus-tahu-foto-resep-utama.jpg)

Jika anda seorang orang tua, menyuguhkan masakan lezat untuk famili merupakan suatu hal yang menggembirakan bagi anda sendiri. Tugas seorang ibu Tidak sekadar menangani rumah saja, namun anda pun wajib memastikan keperluan gizi tercukupi dan juga panganan yang dikonsumsi orang tercinta harus menggugah selera.

Di zaman  sekarang, kita memang dapat memesan panganan praktis tidak harus repot membuatnya terlebih dahulu. Namun banyak juga mereka yang memang ingin menyajikan yang terlezat bagi orang tercintanya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan famili. 



Apakah anda merupakan seorang penyuka 52. kari ayam sederhana plus tahu?. Asal kamu tahu, 52. kari ayam sederhana plus tahu merupakan sajian khas di Indonesia yang sekarang disukai oleh kebanyakan orang di hampir setiap wilayah di Nusantara. Kamu bisa menyajikan 52. kari ayam sederhana plus tahu hasil sendiri di rumahmu dan pasti jadi camilan kesenanganmu di akhir pekanmu.

Anda jangan bingung untuk memakan 52. kari ayam sederhana plus tahu, sebab 52. kari ayam sederhana plus tahu tidak sulit untuk ditemukan dan anda pun bisa menghidangkannya sendiri di tempatmu. 52. kari ayam sederhana plus tahu bisa diolah lewat beragam cara. Kini pun telah banyak banget resep modern yang menjadikan 52. kari ayam sederhana plus tahu semakin enak.

Resep 52. kari ayam sederhana plus tahu pun mudah sekali untuk dibuat, lho. Anda tidak perlu capek-capek untuk memesan 52. kari ayam sederhana plus tahu, karena Kamu bisa menghidangkan ditempatmu. Bagi Anda yang akan menyajikannya, inilah cara menyajikan 52. kari ayam sederhana plus tahu yang enak yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan 52. Kari Ayam Sederhana plus Tahu:

1. Gunakan 1/2 ekor Ayam
1. Sediakan 6 potong Tahu Putih
1. Siapkan 1 bks santan Kara 65ml
1. Ambil 4 bh Cabe Merah Keriting
1. Gunakan 10 bh Cabe Rawit Hijau
1. Sediakan 10 siung Bawang Merah
1. Sediakan 5 siung Bawang Putih
1. Siapkan Seruas jari Lengkuas
1. Ambil Seruas jari Kunyit
1. Sediakan Seruas jari Jahe
1. Gunakan 5 butir Kemiri
1. Gunakan 1 sdm ketumbar
1. Sediakan 1 batang Serai
1. Ambil 2 lembar Daun Salam
1. Gunakan 2 lembar Daun Jeruk
1. Siapkan secukupnya Air, Garam dan Gula




<!--inarticleads2-->

##### Cara membuat 52. Kari Ayam Sederhana plus Tahu:

1. Siapkan dan bersihkan semua bahan. Ayam dipotong sesuai selera, tahu putih rendam diair garam.
1. Haluskan/blender semua bahan bumbu kecuali serai, daun salam dan daun jeruk
1. Panaskan minyak dan tumis bumbu halus tadi. Aduk sampai harum, masukkan serai, daun salam dan daun jeruk.
1. Setelah harum. Masukkan potongan ayam. Aduk bolak balik. Lalu masukkan santan dan air secukupnya.
1. Goreng tahu putih dan masukkan ke dalam santan tadi. Aduk sampai santan dan ayam matang. Masukkan garam dan gula secukupnya.
1. Sajikan sebagai santapan bersama keluarga.




Ternyata resep 52. kari ayam sederhana plus tahu yang enak sederhana ini enteng sekali ya! Semua orang bisa mencobanya. Cara buat 52. kari ayam sederhana plus tahu Sangat sesuai sekali buat kamu yang sedang belajar memasak atau juga untuk anda yang telah hebat dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep 52. kari ayam sederhana plus tahu nikmat sederhana ini? Kalau kamu tertarik, ayo kamu segera buruan menyiapkan peralatan dan bahan-bahannya, maka bikin deh Resep 52. kari ayam sederhana plus tahu yang lezat dan tidak rumit ini. Sungguh gampang kan. 

Oleh karena itu, daripada kita berlama-lama, maka langsung aja sajikan resep 52. kari ayam sederhana plus tahu ini. Pasti kalian gak akan nyesel sudah membuat resep 52. kari ayam sederhana plus tahu enak sederhana ini! Selamat berkreasi dengan resep 52. kari ayam sederhana plus tahu mantab sederhana ini di tempat tinggal kalian masing-masing,ya!.

