---
description: "Bahan-bahan Hati Ayam Masak Asam Manis yang lezat Untuk Jualan"
title: "Bahan-bahan Hati Ayam Masak Asam Manis yang lezat Untuk Jualan"
slug: 325-bahan-bahan-hati-ayam-masak-asam-manis-yang-lezat-untuk-jualan
date: 2021-05-03T07:11:30.370Z
image: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
author: Ernest Walters
ratingvalue: 4.4
reviewcount: 12
recipeingredient:
- "3 bh Hati Ayam Kampung"
- "5 siung Bawang merah"
- "4 siung Bawang putih"
- "1 bh Bawang merah besar"
- "4 bh Cabe Hijau besar"
- "1 bh Tomat"
- "2 papan petai kupas"
- "1 bks Terasi larutkan dengan air"
- "1 sdm Gula merah serut"
- " Garam"
- " Gula pasir"
- " Penyedap rasa"
recipeinstructions:
- "Bersihkan hati ayam, potong persegi kecil. Beri perasan air jeruk nipis dan garam. Diamkan sebentar. Cuci bersih."
- "Rebus hati ayam sebentar, tiriskan. Sisihkan."
- "Siapkan bahan-bahan lainnya, iris bawang, cabe merah, cabe hijau, tomat, petai."
- "Tumis bumbu iris sampai harum dan layu"
- "Masukkan hati ayam, aduk rata. Tumis sebentar. Masukkan air terasi."
- "Masukkan petai dan Tambahkan sedikit air, beri garam, gula pasir, gula merah, dan penyedap. Aduk rata."
- "Masak sampai kuah menyusut dan hati matang, cek rasa, bila sudah pas, angkat. Sajikan."
categories:
- Resep
tags:
- hati
- ayam
- masak

katakunci: hati ayam masak 
nutrition: 129 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dessert

---


![Hati Ayam Masak Asam Manis](https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg)

Jika kalian seorang istri, menyuguhkan hidangan menggugah selera bagi orang tercinta adalah suatu hal yang mengasyikan untuk anda sendiri. Peran seorang ibu bukan cuman mengurus rumah saja, tapi kamu pun harus menyediakan kebutuhan gizi terpenuhi dan panganan yang dimakan anak-anak mesti enak.

Di masa  saat ini, kalian sebenarnya dapat mengorder masakan instan walaupun tidak harus capek memasaknya dahulu. Namun ada juga lho mereka yang selalu ingin memberikan makanan yang terbaik untuk orang yang dicintainya. Lantaran, menghidangkan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga. 



Mungkinkah anda adalah seorang penyuka hati ayam masak asam manis?. Tahukah kamu, hati ayam masak asam manis merupakan hidangan khas di Indonesia yang sekarang digemari oleh setiap orang dari hampir setiap tempat di Indonesia. Kalian dapat membuat hati ayam masak asam manis sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di hari libur.

Anda tak perlu bingung untuk memakan hati ayam masak asam manis, lantaran hati ayam masak asam manis tidak sulit untuk didapatkan dan juga anda pun boleh membuatnya sendiri di tempatmu. hati ayam masak asam manis bisa dibuat lewat bermacam cara. Sekarang ada banyak banget cara kekinian yang membuat hati ayam masak asam manis lebih nikmat.

Resep hati ayam masak asam manis juga sangat mudah untuk dibuat, lho. Anda tidak usah ribet-ribet untuk membeli hati ayam masak asam manis, lantaran Kalian bisa menghidangkan di rumah sendiri. Bagi Kamu yang ingin mencobanya, dibawah ini merupakan cara menyajikan hati ayam masak asam manis yang enak yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Hati Ayam Masak Asam Manis:

1. Ambil 3 bh Hati Ayam Kampung
1. Siapkan 5 siung Bawang merah
1. Sediakan 4 siung Bawang putih
1. Gunakan 1 bh Bawang merah besar
1. Gunakan 4 bh Cabe Hijau besar
1. Sediakan 1 bh Tomat
1. Gunakan 2 papan petai, kupas
1. Ambil 1 bks Terasi, larutkan dengan air
1. Siapkan 1 sdm Gula merah, serut
1. Ambil  Garam
1. Ambil  Gula pasir
1. Gunakan  Penyedap rasa




<!--inarticleads2-->

##### Cara menyiapkan Hati Ayam Masak Asam Manis:

1. Bersihkan hati ayam, potong persegi kecil. Beri perasan air jeruk nipis dan garam. Diamkan sebentar. Cuci bersih.
1. Rebus hati ayam sebentar, tiriskan. Sisihkan.
1. Siapkan bahan-bahan lainnya, iris bawang, cabe merah, cabe hijau, tomat, petai.
1. Tumis bumbu iris sampai harum dan layu
1. Masukkan hati ayam, aduk rata. Tumis sebentar. Masukkan air terasi.
1. Masukkan petai dan Tambahkan sedikit air, beri garam, gula pasir, gula merah, dan penyedap. Aduk rata.
1. Masak sampai kuah menyusut dan hati matang, cek rasa, bila sudah pas, angkat. Sajikan.




Wah ternyata cara buat hati ayam masak asam manis yang mantab sederhana ini mudah sekali ya! Kamu semua dapat membuatnya. Cara buat hati ayam masak asam manis Sangat sesuai sekali untuk kita yang baru akan belajar memasak maupun untuk kalian yang sudah pandai memasak.

Tertarik untuk mulai mencoba bikin resep hati ayam masak asam manis enak tidak ribet ini? Kalau kalian mau, yuk kita segera siapkan alat dan bahannya, kemudian buat deh Resep hati ayam masak asam manis yang mantab dan tidak ribet ini. Sangat gampang kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, ayo kita langsung saja hidangkan resep hati ayam masak asam manis ini. Dijamin kamu tiidak akan menyesal sudah membuat resep hati ayam masak asam manis enak simple ini! Selamat berkreasi dengan resep hati ayam masak asam manis enak sederhana ini di rumah kalian masing-masing,ya!.

