---
description: "Cara membuat Sempol Tanpa Ayam Sederhana dan Mudah Dibuat"
title: "Cara membuat Sempol Tanpa Ayam Sederhana dan Mudah Dibuat"
slug: 168-cara-membuat-sempol-tanpa-ayam-sederhana-dan-mudah-dibuat
date: 2021-05-22T01:01:14.695Z
image: https://img-global.cpcdn.com/recipes/df643940b18b891b/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df643940b18b891b/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df643940b18b891b/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
author: Ola Moore
ratingvalue: 4.3
reviewcount: 6
recipeingredient:
- "8 sdm munjung tepung terigu"
- "5 sdm munjung tepung tapioka"
- "2 siung kecil bawang putih haluskan"
- "secukupnya Garam"
- "secukupnya Lada bubuk"
- "secukupnya Kaldu ayam"
- "secukupnya Air panas"
- "1 butir telur ayam"
- " Bahan cocolan "
- " Saus sambal optional"
recipeinstructions:
- "Campurkan tepung terigu, tepung tapioka, bawang putih yang dihaluskan, garam, lada dan kaldu bubuk. Aduk hingga rata"
- "Panaskan air, lalu masukan sedikit demi sedikit hingga terbentuk adonan"
- "Bentuk adonan bulat memanjang, lalu tusukan dengan tusuk sate."
- "Panaskan air yang banyak untuk merebus sempol(beri minyak sedikit ya bun)."
- "Rebus sempol sampai terapung, angkat tiriskan."
- "Kocok telur sampai agak berbusa. Tambahkan sedikit garam dan lada"
- "Panaskan wajan berisi minyak yang banyak"
- "Goreng sempol tanpa telur(30 detik saja biar dalemnya matang)"
- "Celupkan sempol pada telur, lalu gulung (Gunakan api sedang)"
- "Tunggu hingga sempol berwarna kecoklatan. Angkat dan tiriskan :)"
- "Sajikan dengan sambal atau bahan cocolan lainnya :)"
categories:
- Resep
tags:
- sempol
- tanpa
- ayam

katakunci: sempol tanpa ayam 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dinner

---


![Sempol Tanpa Ayam](https://img-global.cpcdn.com/recipes/df643940b18b891b/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg)

Andai kamu seorang yang hobi memasak, mempersiapkan panganan nikmat bagi keluarga merupakan suatu hal yang sangat menyenangkan bagi kita sendiri. Peran seorang  wanita Tidak sekadar menangani rumah saja, namun kamu pun harus memastikan kebutuhan gizi tercukupi dan panganan yang disantap orang tercinta wajib lezat.

Di era  sekarang, kita sebenarnya dapat membeli olahan praktis walaupun tidak harus ribet mengolahnya dahulu. Tetapi ada juga lho orang yang memang ingin menyajikan yang terlezat untuk orang yang dicintainya. Karena, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan seorang penggemar sempol tanpa ayam?. Tahukah kamu, sempol tanpa ayam adalah sajian khas di Indonesia yang sekarang disukai oleh kebanyakan orang dari berbagai wilayah di Nusantara. Kita dapat menyajikan sempol tanpa ayam sendiri di rumahmu dan boleh jadi santapan favoritmu di akhir pekanmu.

Kita tidak perlu bingung jika kamu ingin memakan sempol tanpa ayam, sebab sempol tanpa ayam mudah untuk dicari dan juga kamu pun boleh mengolahnya sendiri di tempatmu. sempol tanpa ayam dapat dibuat lewat bermacam cara. Kini pun sudah banyak sekali cara modern yang membuat sempol tanpa ayam lebih nikmat.

Resep sempol tanpa ayam pun sangat mudah untuk dibuat, lho. Kalian tidak perlu capek-capek untuk membeli sempol tanpa ayam, karena Kita bisa menghidangkan ditempatmu. Untuk Kamu yang ingin menghidangkannya, berikut ini cara membuat sempol tanpa ayam yang nikamat yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Sempol Tanpa Ayam:

1. Sediakan 8 sdm munjung tepung terigu
1. Siapkan 5 sdm munjung tepung tapioka
1. Gunakan 2 siung kecil bawang putih (haluskan)
1. Siapkan secukupnya Garam
1. Siapkan secukupnya Lada bubuk
1. Gunakan secukupnya Kaldu ayam
1. Siapkan secukupnya Air panas
1. Gunakan 1 butir telur ayam
1. Gunakan  Bahan cocolan :
1. Gunakan  Saus sambal (optional)




<!--inarticleads2-->

##### Langkah-langkah membuat Sempol Tanpa Ayam:

1. Campurkan tepung terigu, tepung tapioka, bawang putih yang dihaluskan, garam, lada dan kaldu bubuk. Aduk hingga rata
1. Panaskan air, lalu masukan sedikit demi sedikit hingga terbentuk adonan
1. Bentuk adonan bulat memanjang, lalu tusukan dengan tusuk sate.
1. Panaskan air yang banyak untuk merebus sempol(beri minyak sedikit ya bun).
1. Rebus sempol sampai terapung, angkat tiriskan.
1. Kocok telur sampai agak berbusa. Tambahkan sedikit garam dan lada
1. Panaskan wajan berisi minyak yang banyak
1. Goreng sempol tanpa telur(30 detik saja biar dalemnya matang)
1. Celupkan sempol pada telur, lalu gulung (Gunakan api sedang)
1. Tunggu hingga sempol berwarna kecoklatan. Angkat dan tiriskan :)
1. Sajikan dengan sambal atau bahan cocolan lainnya :)




Ternyata resep sempol tanpa ayam yang enak simple ini mudah banget ya! Semua orang bisa menghidangkannya. Cara Membuat sempol tanpa ayam Sesuai sekali untuk kalian yang baru mau belajar memasak ataupun juga bagi anda yang telah hebat dalam memasak.

Tertarik untuk mulai mencoba buat resep sempol tanpa ayam mantab simple ini? Kalau kamu ingin, ayo kamu segera menyiapkan alat dan bahan-bahannya, maka buat deh Resep sempol tanpa ayam yang enak dan tidak ribet ini. Benar-benar gampang kan. 

Jadi, daripada kalian diam saja, ayo kita langsung saja hidangkan resep sempol tanpa ayam ini. Pasti kamu tak akan nyesel sudah bikin resep sempol tanpa ayam mantab tidak ribet ini! Selamat berkreasi dengan resep sempol tanpa ayam mantab tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

