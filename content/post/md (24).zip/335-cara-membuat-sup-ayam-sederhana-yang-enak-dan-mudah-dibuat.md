---
description: "Cara membuat Sup ayam sederhana yang enak dan Mudah Dibuat"
title: "Cara membuat Sup ayam sederhana yang enak dan Mudah Dibuat"
slug: 335-cara-membuat-sup-ayam-sederhana-yang-enak-dan-mudah-dibuat
date: 2021-06-01T03:44:53.489Z
image: https://img-global.cpcdn.com/recipes/57939671a76ee043/680x482cq70/sup-ayam-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/57939671a76ee043/680x482cq70/sup-ayam-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/57939671a76ee043/680x482cq70/sup-ayam-sederhana-foto-resep-utama.jpg
author: Herman Blake
ratingvalue: 4
reviewcount: 10
recipeingredient:
- "25 gr ayam saya pakai bagian banyak tulang spt sayap dan ceker"
- "1 buah wortel"
- "1 buah kentang"
- "2 lembar kol"
- "1 batang daun bawang iris besar"
- "1/2 batang seledri"
- " Bumbu"
- "3 sium bwang merah iris"
- "2 sium bawang putih iris"
- "  buah tomat"
- "1 buah cabe keriting iris optional"
- "1 sdt garam"
- "1 sdt penyedap"
- "1/2 sdt lada"
- "  sdt gula"
- "700 ml air"
recipeinstructions:
- "Bersih kan wortel dan kentang, lalu bersihkan dan potong dadu."
- "Rebus ayam sebentar saja ±3 menit, supaya lemak kotornya keluar. Buang air sisa rebusan."
- "Didihkan air. Masukkan seledri, saya cuma di remas utuh saja. Masukkan ayam, wortel dan kentang sampai setengah matang."
- "Tumis bamer dan baput, setelah matang masukkan daun bawang dan tumis sebentar. Masukkan ke dalam kuah sup. Beri bumbu, koreksi rasa."
- "Masukkan kol, masak sebentar lalu masukkan cabe dan tomat sebelum kompor di matikan."
categories:
- Resep
tags:
- sup
- ayam
- sederhana

katakunci: sup ayam sederhana 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dessert

---


![Sup ayam sederhana](https://img-global.cpcdn.com/recipes/57939671a76ee043/680x482cq70/sup-ayam-sederhana-foto-resep-utama.jpg)

Jika anda seorang yang hobi masak, menyajikan santapan sedap untuk famili adalah hal yang menyenangkan bagi anda sendiri. Peran seorang ibu Tidak cuma mengerjakan pekerjaan rumah saja, tapi anda pun harus memastikan kebutuhan gizi terpenuhi dan olahan yang dikonsumsi orang tercinta mesti mantab.

Di zaman  sekarang, kita sebenarnya mampu mengorder olahan praktis tidak harus repot mengolahnya dulu. Tetapi banyak juga mereka yang memang ingin menyajikan yang terlezat untuk keluarganya. Lantaran, memasak sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 

Lihat juga resep Sup ayam suwir mudah dan sehat enak lainnya. Assalamualaikum, jumpa lagi di channel Dapur Bu Titin. Kali ini Dapur Bu Titin akan memasak Sup Ayam Sederhana.

Apakah anda seorang penyuka sup ayam sederhana?. Asal kamu tahu, sup ayam sederhana adalah makanan khas di Nusantara yang sekarang disenangi oleh banyak orang di hampir setiap wilayah di Indonesia. Kita dapat memasak sup ayam sederhana buatan sendiri di rumah dan boleh jadi hidangan favoritmu di akhir pekan.

Kamu tak perlu bingung jika kamu ingin menyantap sup ayam sederhana, karena sup ayam sederhana mudah untuk didapatkan dan anda pun bisa memasaknya sendiri di tempatmu. sup ayam sederhana bisa diolah dengan berbagai cara. Kini ada banyak sekali cara kekinian yang membuat sup ayam sederhana lebih mantap.

Resep sup ayam sederhana pun mudah untuk dibuat, lho. Kita tidak usah repot-repot untuk membeli sup ayam sederhana, karena Kita mampu menyiapkan ditempatmu. Bagi Kalian yang hendak menghidangkannya, di bawah ini adalah cara untuk membuat sup ayam sederhana yang mantab yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Sup ayam sederhana:

1. Ambil 25 gr ayam (saya pakai bagian banyak tulang spt sayap dan ceker)
1. Ambil 1 buah wortel
1. Siapkan 1 buah kentang
1. Siapkan 2 lembar kol
1. Ambil 1 batang daun bawang (iris besar)
1. Ambil 1/2 batang seledri
1. Sediakan  Bumbu
1. Gunakan 3 sium bwang merah (iris)
1. Gunakan 2 sium bawang putih (iris)
1. Siapkan  ¹/² buah tomat
1. Ambil 1 buah cabe keriting (iris) (optional)
1. Sediakan 1 sdt garam
1. Gunakan 1 sdt penyedap
1. Siapkan 1/2 sdt lada
1. Siapkan  ¹/² sdt gula
1. Gunakan 700 ml air


Resep sup ayam bening ini takkan pernah salah disajikan sebagai menu andalan setiap minggu. Selebihnya hanya menunggu matang dan sup ayam sederhana ini siap dinikmati seluruh keluarga. Sup ceker ayam ini kaldunya bening dan bumbunya sederhana. Ceker ayam juga populer diolah sebagai sup. 

<!--inarticleads2-->

##### Langkah-langkah membuat Sup ayam sederhana:

1. Bersih kan wortel dan kentang, lalu bersihkan dan potong dadu.
1. Rebus ayam sebentar saja ±3 menit, supaya lemak kotornya keluar. Buang air sisa rebusan.
1. Didihkan air. Masukkan seledri, saya cuma di remas utuh saja. Masukkan ayam, wortel dan kentang sampai setengah matang.
1. Tumis bamer dan baput, setelah matang masukkan daun bawang dan tumis sebentar. Masukkan ke dalam kuah sup. Beri bumbu, koreksi rasa.
1. Masukkan kol, masak sebentar lalu masukkan cabe dan tomat sebelum kompor di matikan.


Ini karena ceker ayam punya lapisan lemak dan otot yang lembut saat dimasak hingga. Rasa supnya yang sedap dengan irisan ayam membuat rasanya makin segar. Ternyata Sup / Sop Ayam adalah salah satu menu masakan rumahan yang cukup sederhana tetapi tidak kalah lezat dengan menu masakan restoran lainnya, cara bikinnya juga relatif cukup mudah. Resep sup ayam sederhana ala rumahan lengkap! Mulai dari resep bumbu sup ayam yg dibutuhkan hingga, cara membuat resep sup ayam rumahan sederhana yg spesial ala restoran itu! 

Wah ternyata cara buat sup ayam sederhana yang mantab tidak ribet ini mudah sekali ya! Semua orang mampu menghidangkannya. Cara buat sup ayam sederhana Sangat cocok banget untuk kalian yang baru akan belajar memasak maupun bagi anda yang sudah hebat memasak.

Apakah kamu ingin mencoba membikin resep sup ayam sederhana lezat sederhana ini? Kalau anda ingin, ayo kamu segera buruan siapin peralatan dan bahannya, maka bikin deh Resep sup ayam sederhana yang mantab dan simple ini. Betul-betul taidak sulit kan. 

Maka, daripada anda berfikir lama-lama, ayo kita langsung sajikan resep sup ayam sederhana ini. Pasti kalian gak akan menyesal sudah bikin resep sup ayam sederhana lezat tidak ribet ini! Selamat berkreasi dengan resep sup ayam sederhana lezat sederhana ini di tempat tinggal kalian sendiri,oke!.

