---
description: "Resep Lontong Opor Ayam yang lezat dan Mudah Dibuat"
title: "Resep Lontong Opor Ayam yang lezat dan Mudah Dibuat"
slug: 388-resep-lontong-opor-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-05-13T07:53:26.871Z
image: https://img-global.cpcdn.com/recipes/297bda335083d89f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/297bda335083d89f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/297bda335083d89f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
author: Edna Newman
ratingvalue: 3.6
reviewcount: 9
recipeingredient:
- "6 potong daging ayam"
- "1 btg serai"
- "1 lmbr daun jeruk"
- "1 lmbr daun salam"
- "1 bh lontong"
- "Secukupnya kerupuk udang"
- "Secukupnya bawang merah goreng"
- " Bumbu halus "
- "5 siung bamer"
- "2 siung baput"
- "1 bj kemiri"
- "1 cm jahe"
- "1/2 sdt ketumbar"
- "1/2 sdt merica"
- "Secukupnya garam"
recipeinstructions:
- "Rebus ayam yang telah dibersihkan terlebih dahulu. Setelah matang, ambil ayamnya saja. Kalo pakai ayam kampung, kaldu saya pakai. Tapi karena pakai ayam potong jadi tidak pakai kaldunya. Sesuaikan selera saja ya"
- "Haluskan bumbu. Kemudian tumis sampai harum"
- "Siapkan santan di panci. Masukkan ayam yg telah di rebus tadi. Masukkan juga bumbu."
- "Kemudian masak, sebelum mendidih, tes rasa dulu. Angkat setelah kuah mendidih."
- "Siapkan lontong di piring. Siram dg opornya. Taburi dg bawang merah goreng. Sajikan dg sambal dan kerupuk."
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 253 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Lunch

---


![Lontong Opor Ayam](https://img-global.cpcdn.com/recipes/297bda335083d89f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg)

Apabila kalian seorang ibu, menyajikan panganan sedap untuk orang tercinta adalah hal yang menggembirakan untuk anda sendiri. Tanggung jawab seorang  wanita Tidak hanya menangani rumah saja, tapi anda juga wajib memastikan kebutuhan nutrisi terpenuhi dan hidangan yang dikonsumsi anak-anak mesti nikmat.

Di waktu  sekarang, kamu memang dapat mengorder santapan praktis meski tidak harus ribet membuatnya dulu. Tapi ada juga mereka yang selalu ingin menghidangkan yang terlezat untuk keluarganya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera famili. 



Apakah anda adalah seorang penggemar lontong opor ayam?. Asal kamu tahu, lontong opor ayam adalah makanan khas di Indonesia yang sekarang disenangi oleh setiap orang di berbagai daerah di Nusantara. Kalian bisa memasak lontong opor ayam sendiri di rumah dan boleh dijadikan camilan favoritmu di hari liburmu.

Kalian tidak perlu bingung untuk memakan lontong opor ayam, sebab lontong opor ayam tidak sulit untuk ditemukan dan kamu pun dapat menghidangkannya sendiri di tempatmu. lontong opor ayam bisa dibuat lewat beragam cara. Saat ini sudah banyak cara kekinian yang menjadikan lontong opor ayam semakin mantap.

Resep lontong opor ayam juga sangat gampang dibuat, lho. Kalian jangan capek-capek untuk membeli lontong opor ayam, lantaran Kita dapat menyajikan di rumahmu. Bagi Kita yang hendak menghidangkannya, di bawah ini adalah cara menyajikan lontong opor ayam yang nikamat yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Lontong Opor Ayam:

1. Siapkan 6 potong daging ayam
1. Sediakan 1 btg serai
1. Ambil 1 lmbr daun jeruk
1. Siapkan 1 lmbr daun salam
1. Sediakan 1 bh lontong
1. Sediakan Secukupnya kerupuk udang
1. Sediakan Secukupnya bawang merah goreng
1. Ambil  Bumbu halus :
1. Gunakan 5 siung bamer
1. Sediakan 2 siung baput
1. Sediakan 1 bj kemiri
1. Siapkan 1 cm jahe
1. Gunakan 1/2 sdt ketumbar
1. Ambil 1/2 sdt merica
1. Sediakan Secukupnya garam




<!--inarticleads2-->

##### Cara membuat Lontong Opor Ayam:

1. Rebus ayam yang telah dibersihkan terlebih dahulu. Setelah matang, ambil ayamnya saja. Kalo pakai ayam kampung, kaldu saya pakai. Tapi karena pakai ayam potong jadi tidak pakai kaldunya. Sesuaikan selera saja ya
1. Haluskan bumbu. Kemudian tumis sampai harum
1. Siapkan santan di panci. Masukkan ayam yg telah di rebus tadi. Masukkan juga bumbu.
1. Kemudian masak, sebelum mendidih, tes rasa dulu. Angkat setelah kuah mendidih.
1. Siapkan lontong di piring. Siram dg opornya. Taburi dg bawang merah goreng. Sajikan dg sambal dan kerupuk.




Wah ternyata resep lontong opor ayam yang lezat sederhana ini enteng banget ya! Anda Semua dapat membuatnya. Resep lontong opor ayam Cocok sekali untuk kita yang baru mau belajar memasak maupun juga untuk anda yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba membuat resep lontong opor ayam enak tidak ribet ini? Kalau kamu ingin, yuk kita segera siapin alat-alat dan bahannya, setelah itu buat deh Resep lontong opor ayam yang mantab dan tidak ribet ini. Betul-betul gampang kan. 

Oleh karena itu, ketimbang kamu berlama-lama, ayo langsung aja sajikan resep lontong opor ayam ini. Dijamin anda tiidak akan nyesel sudah buat resep lontong opor ayam enak tidak ribet ini! Selamat berkreasi dengan resep lontong opor ayam enak sederhana ini di tempat tinggal sendiri,oke!.

