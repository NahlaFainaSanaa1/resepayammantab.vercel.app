---
description: "Resep Hati ayam kentang masak kecap yang enak dan Mudah Dibuat"
title: "Resep Hati ayam kentang masak kecap yang enak dan Mudah Dibuat"
slug: 322-resep-hati-ayam-kentang-masak-kecap-yang-enak-dan-mudah-dibuat
date: 2021-03-13T19:03:05.862Z
image: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
author: Sadie Campbell
ratingvalue: 5
reviewcount: 5
recipeingredient:
- "4 bh hati ayam"
- "4 bh kentang"
- "3 bh bawang merah  1 bh bombay"
- "2 bh bawang putih"
- "secukupnya Merica"
- "2 helai daun bawang iris"
- "1 bh tomat besar iris"
- "1 ruas jahe"
- "2 sdm kecap manis"
- "1 sdt saori saus tiram"
- "secukupnya Garampenyedap"
- "secukupnya Air"
recipeinstructions:
- "Rebus hati ayam,stlh masak potong dan sisihkan"
- "Kupas dan potong kentang sesuai selera,lalu digoreng"
- "Iris bawang merah,geprek bawang putih dan jahe"
- "Tumis bawang,jahe dan merica hingga harum"
- "Tambahkan garam,penyedap dan air"
- "Lalu masukkan saori,dan kecap manis"
- "Masukkan hati ayam dan kentang,aduk rata dan diamkan sejenak sampai seluruh bumbu meresap."
- "Terakhir masukkan irisan daun bawang dan tomat sbg pelengkap,aduk rata"
- "Siap dihidangkan🤗"
categories:
- Resep
tags:
- hati
- ayam
- kentang

katakunci: hati ayam kentang 
nutrition: 123 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dinner

---


![Hati ayam kentang masak kecap](https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan hidangan menggugah selera bagi keluarga adalah suatu hal yang memuaskan bagi anda sendiri. Peran seorang  wanita Tidak sekadar mengerjakan pekerjaan rumah saja, tetapi anda juga harus memastikan keperluan nutrisi terpenuhi dan masakan yang dimakan keluarga tercinta mesti mantab.

Di masa  sekarang, anda sebenarnya mampu memesan masakan siap saji walaupun tanpa harus susah memasaknya dulu. Tapi ada juga lho mereka yang selalu ingin memberikan hidangan yang terlezat untuk keluarganya. Lantaran, menghidangkan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai makanan kesukaan orang tercinta. 



Mungkinkah anda salah satu penikmat hati ayam kentang masak kecap?. Asal kamu tahu, hati ayam kentang masak kecap adalah makanan khas di Nusantara yang kini disenangi oleh banyak orang di berbagai wilayah di Indonesia. Kamu dapat memasak hati ayam kentang masak kecap sendiri di rumah dan boleh dijadikan camilan favorit di akhir pekan.

Anda tidak perlu bingung untuk mendapatkan hati ayam kentang masak kecap, lantaran hati ayam kentang masak kecap tidak sukar untuk ditemukan dan kita pun boleh membuatnya sendiri di rumah. hati ayam kentang masak kecap bisa dibuat lewat beraneka cara. Sekarang ada banyak cara modern yang menjadikan hati ayam kentang masak kecap semakin lebih nikmat.

Resep hati ayam kentang masak kecap pun mudah sekali dihidangkan, lho. Anda jangan repot-repot untuk memesan hati ayam kentang masak kecap, sebab Kita mampu membuatnya sendiri di rumah. Untuk Kita yang hendak menyajikannya, berikut cara membuat hati ayam kentang masak kecap yang nikamat yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Hati ayam kentang masak kecap:

1. Ambil 4 bh hati ayam
1. Gunakan 4 bh kentang
1. Siapkan 3 bh bawang merah / 1 bh bombay
1. Ambil 2 bh bawang putih
1. Siapkan secukupnya Merica
1. Ambil 2 helai daun bawang, iris
1. Siapkan 1 bh tomat besar, iris
1. Ambil 1 ruas jahe
1. Siapkan 2 sdm kecap manis
1. Siapkan 1 sdt saori saus tiram
1. Siapkan secukupnya Garam,penyedap
1. Gunakan secukupnya Air




<!--inarticleads2-->

##### Cara membuat Hati ayam kentang masak kecap:

1. Rebus hati ayam,stlh masak potong dan sisihkan
1. Kupas dan potong kentang sesuai selera,lalu digoreng
1. Iris bawang merah,geprek bawang putih dan jahe
1. Tumis bawang,jahe dan merica hingga harum
1. Tambahkan garam,penyedap dan air
1. Lalu masukkan saori,dan kecap manis
1. Masukkan hati ayam dan kentang,aduk rata dan diamkan sejenak sampai seluruh bumbu meresap.
1. Terakhir masukkan irisan daun bawang dan tomat sbg pelengkap,aduk rata
1. Siap dihidangkan🤗




Wah ternyata cara membuat hati ayam kentang masak kecap yang nikamt simple ini mudah banget ya! Kalian semua mampu membuatnya. Cara Membuat hati ayam kentang masak kecap Sangat sesuai sekali buat anda yang baru akan belajar memasak maupun juga bagi kalian yang sudah jago dalam memasak.

Apakah kamu mau mencoba membikin resep hati ayam kentang masak kecap mantab simple ini? Kalau ingin, ayo kalian segera siapkan alat dan bahan-bahannya, maka buat deh Resep hati ayam kentang masak kecap yang lezat dan tidak ribet ini. Sungguh mudah kan. 

Maka, daripada kalian berlama-lama, maka kita langsung saja buat resep hati ayam kentang masak kecap ini. Pasti anda tiidak akan nyesel bikin resep hati ayam kentang masak kecap enak tidak ribet ini! Selamat berkreasi dengan resep hati ayam kentang masak kecap enak simple ini di tempat tinggal sendiri,ya!.

