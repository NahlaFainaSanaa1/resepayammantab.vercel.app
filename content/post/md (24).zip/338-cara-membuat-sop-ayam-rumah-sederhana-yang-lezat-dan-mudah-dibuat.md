---
description: "Cara membuat Sop Ayam Rumah Sederhana yang lezat dan Mudah Dibuat"
title: "Cara membuat Sop Ayam Rumah Sederhana yang lezat dan Mudah Dibuat"
slug: 338-cara-membuat-sop-ayam-rumah-sederhana-yang-lezat-dan-mudah-dibuat
date: 2021-03-11T01:10:15.646Z
image: https://img-global.cpcdn.com/recipes/0020aeecb3497e3d/680x482cq70/sop-ayam-rumah-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0020aeecb3497e3d/680x482cq70/sop-ayam-rumah-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0020aeecb3497e3d/680x482cq70/sop-ayam-rumah-sederhana-foto-resep-utama.jpg
author: Alejandro Roberson
ratingvalue: 4.5
reviewcount: 14
recipeingredient:
- "1/2 ekor ayam"
- "1 buah wortel"
- "2 lembar kol tambahan saya sendiri"
- "1 buah kentang tambahan saya sendiri"
- "Secukupnya daun seledri"
- "700 ml air"
- " Bumbu halus"
- "4 butir bawang merah"
- "2 siung bawang putih"
- "5 butir lada"
- "Secukupnya jahe"
- "Secukupnya kaskas"
- "Secukupnya pala"
- "  Bumbu Cemplung"
- "3 buah cengkeh"
- "2 kelopak bunga lawang"
- "1 buah kapulaga"
- "1/2 ruas kayu manis"
- "1/2 sdt garam secukupnya"
- "1/2 sdm gula pasir secukupnya"
- "Secukupnya penyedap rasa saya kaldu jamur"
- " Pelengkap"
- " Jeruk nipis"
- " Cabe rawit"
recipeinstructions:
- "Didihkan air, rebus ayam yang sudah dibersihkan dan dipotong-potong. Rebus sampai kotoran dan lemak-lemak nya keluar, lalu buang air rebusannya."
- "Tambahkan air yang baru kurleb 700ml, rebus."
- "Sambil menunggu ayam mendidih haluskan bumbu dan siapkan bumbu cemplung nya."
- "Setelah bumbu halus sudah jadi, tumis bumbu halus hingga harum dengan secukupnya minyak goreng."
- "Masukkan bumbu halus, bumbu cemplung, gula, garam dan kaldu jamur, aduk rata dan test rasa."
- "Terakhir masukkan kentang, wortel dan kol, masak hingga ayam empuk dan kentang wortel kol matang."
- "Sajikan dengan nasi hangat dan pelengkap."
categories:
- Resep
tags:
- sop
- ayam
- rumah

katakunci: sop ayam rumah 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Sop Ayam Rumah Sederhana](https://img-global.cpcdn.com/recipes/0020aeecb3497e3d/680x482cq70/sop-ayam-rumah-sederhana-foto-resep-utama.jpg)

Apabila anda seorang yang hobi memasak, mempersiapkan olahan nikmat pada famili adalah hal yang membahagiakan bagi anda sendiri. Peran seorang  wanita bukan saja mengerjakan pekerjaan rumah saja, tapi anda juga harus menyediakan kebutuhan gizi tercukupi dan juga santapan yang dikonsumsi orang tercinta harus nikmat.

Di masa  sekarang, kalian sebenarnya dapat mengorder panganan instan tidak harus repot mengolahnya dulu. Namun banyak juga lho orang yang memang ingin menyajikan yang terbaik bagi orang yang dicintainya. Pasalnya, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera famili. 



Mungkinkah anda salah satu penyuka sop ayam rumah sederhana?. Tahukah kamu, sop ayam rumah sederhana merupakan hidangan khas di Indonesia yang kini digemari oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Kamu dapat menghidangkan sop ayam rumah sederhana sendiri di rumahmu dan pasti jadi makanan favoritmu di akhir pekanmu.

Anda tidak usah bingung untuk memakan sop ayam rumah sederhana, karena sop ayam rumah sederhana sangat mudah untuk ditemukan dan anda pun boleh memasaknya sendiri di rumah. sop ayam rumah sederhana bisa diolah dengan beragam cara. Kini pun ada banyak banget resep modern yang membuat sop ayam rumah sederhana lebih mantap.

Resep sop ayam rumah sederhana pun mudah dibuat, lho. Kita tidak perlu capek-capek untuk membeli sop ayam rumah sederhana, tetapi Kita dapat menyajikan di rumah sendiri. Bagi Kalian yang ingin menghidangkannya, berikut cara membuat sop ayam rumah sederhana yang lezat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Sop Ayam Rumah Sederhana:

1. Siapkan 1/2 ekor ayam
1. Siapkan 1 buah wortel
1. Ambil 2 lembar kol (tambahan saya sendiri)
1. Ambil 1 buah kentang (tambahan saya sendiri)
1. Ambil Secukupnya daun seledri
1. Siapkan 700 ml air
1. Gunakan  🧅Bumbu halus:
1. Gunakan 4 butir bawang merah
1. Gunakan 2 siung bawang putih
1. Sediakan 5 butir lada
1. Ambil Secukupnya jahe
1. Gunakan Secukupnya kas-kas
1. Siapkan Secukupnya pala
1. Ambil  🧅 Bumbu Cemplung:
1. Gunakan 3 buah cengkeh
1. Gunakan 2 kelopak bunga lawang
1. Ambil 1 buah kapulaga
1. Siapkan 1/2 ruas kayu manis
1. Siapkan 1/2 sdt garam (secukupnya)
1. Ambil 1/2 sdm gula pasir (secukupnya)
1. Ambil Secukupnya penyedap rasa (saya: kaldu jamur)
1. Sediakan  Pelengkap:
1. Ambil  Jeruk nipis
1. Sediakan  Cabe rawit




<!--inarticleads2-->

##### Cara membuat Sop Ayam Rumah Sederhana:

1. Didihkan air, rebus ayam yang sudah dibersihkan dan dipotong-potong. Rebus sampai kotoran dan lemak-lemak nya keluar, lalu buang air rebusannya.
1. Tambahkan air yang baru kurleb 700ml, rebus.
1. Sambil menunggu ayam mendidih haluskan bumbu dan siapkan bumbu cemplung nya.
1. Setelah bumbu halus sudah jadi, tumis bumbu halus hingga harum dengan secukupnya minyak goreng.
1. Masukkan bumbu halus, bumbu cemplung, gula, garam dan kaldu jamur, aduk rata dan test rasa.
1. Terakhir masukkan kentang, wortel dan kol, masak hingga ayam empuk dan kentang wortel kol matang.
1. Sajikan dengan nasi hangat dan pelengkap.




Ternyata cara buat sop ayam rumah sederhana yang mantab sederhana ini enteng banget ya! Kita semua bisa membuatnya. Cara Membuat sop ayam rumah sederhana Sangat cocok banget untuk anda yang sedang belajar memasak ataupun untuk kamu yang sudah hebat dalam memasak.

Tertarik untuk mencoba membuat resep sop ayam rumah sederhana nikmat simple ini? Kalau anda ingin, yuk kita segera buruan menyiapkan alat dan bahan-bahannya, maka bikin deh Resep sop ayam rumah sederhana yang enak dan simple ini. Sungguh mudah kan. 

Maka, daripada kita berlama-lama, ayo langsung aja buat resep sop ayam rumah sederhana ini. Dijamin kalian tiidak akan menyesal bikin resep sop ayam rumah sederhana mantab tidak ribet ini! Selamat mencoba dengan resep sop ayam rumah sederhana enak tidak rumit ini di rumah masing-masing,oke!.

