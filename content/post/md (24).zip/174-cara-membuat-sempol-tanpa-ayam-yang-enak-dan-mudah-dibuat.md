---
description: "Cara membuat Sempol tanpa ayam yang enak dan Mudah Dibuat"
title: "Cara membuat Sempol tanpa ayam yang enak dan Mudah Dibuat"
slug: 174-cara-membuat-sempol-tanpa-ayam-yang-enak-dan-mudah-dibuat
date: 2021-07-01T00:47:30.392Z
image: https://img-global.cpcdn.com/recipes/096306ffd9caa1c6/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/096306ffd9caa1c6/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/096306ffd9caa1c6/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg
author: Trevor Matthews
ratingvalue: 3.5
reviewcount: 13
recipeingredient:
- "10 sdm terigu"
- "6 sdm kanji"
- "3 siung bawang putih  gorenghancurkan"
- "3 siung bawang merah  gorenghancurkan"
- "1 batang daun bawang  iris tipis"
- "secukupnya garampenyedap"
- "100 ml air  kira2 aja smpai bisa di bulatkan"
- "1 buah wortel parut tambahan bisa dikasih"
- "1 buah telur ayamkocok lepas"
recipeinstructions:
- "Campur semua bahan kecuali air sampai rata"
- "Tambahan air sedikit demi sedikit,uleni kalis(ga lengket ditangan)"
- "Bentuk bulat atau sesuai selera,me lonjong gini..."
- "Rebus di air mendidih sampai ngapung,angkat,dinginkan"
- "Baru di tusuk pake lidi"
- "Masukan ke kocokan telur,goreng Kalau mau telurnya lebih tebal,masukan lagi ke kocokan telur dan goreng smp warna kecoklatan"
categories:
- Resep
tags:
- sempol
- tanpa
- ayam

katakunci: sempol tanpa ayam 
nutrition: 245 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Lunch

---


![Sempol tanpa ayam](https://img-global.cpcdn.com/recipes/096306ffd9caa1c6/680x482cq70/sempol-tanpa-ayam-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan hidangan enak kepada famili adalah suatu hal yang membahagiakan untuk kamu sendiri. Peran seorang istri Tidak hanya mengatur rumah saja, tapi anda pun wajib memastikan kebutuhan nutrisi terpenuhi dan juga panganan yang dimakan keluarga tercinta wajib lezat.

Di zaman  sekarang, kamu memang bisa membeli olahan yang sudah jadi meski tanpa harus susah memasaknya lebih dulu. Namun ada juga lho mereka yang selalu ingin memberikan makanan yang terenak bagi orang tercintanya. Sebab, memasak sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan famili. 



Apakah anda merupakan salah satu penyuka sempol tanpa ayam?. Tahukah kamu, sempol tanpa ayam merupakan sajian khas di Indonesia yang kini digemari oleh orang-orang dari berbagai tempat di Nusantara. Kamu dapat membuat sempol tanpa ayam sendiri di rumah dan boleh dijadikan hidangan kesukaanmu di hari libur.

Kamu tidak usah bingung jika kamu ingin menyantap sempol tanpa ayam, lantaran sempol tanpa ayam tidak sulit untuk didapatkan dan juga anda pun dapat memasaknya sendiri di rumah. sempol tanpa ayam dapat diolah dengan bermacam cara. Saat ini ada banyak cara modern yang membuat sempol tanpa ayam lebih enak.

Resep sempol tanpa ayam pun mudah untuk dibuat, lho. Kita tidak usah capek-capek untuk membeli sempol tanpa ayam, sebab Kamu bisa menghidangkan ditempatmu. Bagi Kamu yang hendak menghidangkannya, di bawah ini adalah cara untuk menyajikan sempol tanpa ayam yang mantab yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Sempol tanpa ayam:

1. Siapkan 10 sdm terigu
1. Siapkan 6 sdm kanji
1. Ambil 3 siung bawang putih  goreng,hancurkan
1. Siapkan 3 siung bawang merah  goreng,hancurkan
1. Siapkan 1 batang daun bawang  iris tipis
1. Gunakan secukupnya garam,penyedap
1. Sediakan 100 ml air  (kira2 aja smpai bisa di bulatkan)
1. Siapkan 1 buah wortel parut tambahan bisa dikasih
1. Sediakan 1 buah telur ayam,kocok lepas




<!--inarticleads2-->

##### Langkah-langkah membuat Sempol tanpa ayam:

1. Campur semua bahan kecuali air sampai rata
1. Tambahan air sedikit demi sedikit,uleni kalis(ga lengket ditangan)
1. Bentuk bulat atau sesuai selera,me lonjong gini...
<img src="https://img-global.cpcdn.com/steps/cb649b3e7d91f866/160x128cq70/sempol-tanpa-ayam-langkah-memasak-3-foto.jpg" alt="Sempol tanpa ayam">1. Rebus di air mendidih sampai ngapung,angkat,dinginkan
1. Baru di tusuk pake lidi
1. Masukan ke kocokan telur,goreng Kalau mau telurnya lebih tebal,masukan lagi ke kocokan telur dan goreng smp warna kecoklatan




Ternyata resep sempol tanpa ayam yang nikamt sederhana ini enteng banget ya! Kamu semua mampu membuatnya. Cara Membuat sempol tanpa ayam Sangat sesuai sekali buat kita yang baru akan belajar memasak ataupun bagi kamu yang sudah jago dalam memasak.

Apakah kamu ingin mencoba membikin resep sempol tanpa ayam nikmat tidak ribet ini? Kalau tertarik, ayo kamu segera menyiapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep sempol tanpa ayam yang mantab dan simple ini. Betul-betul gampang kan. 

Maka, daripada anda berlama-lama, yuk kita langsung saja hidangkan resep sempol tanpa ayam ini. Dijamin kamu tak akan nyesel sudah bikin resep sempol tanpa ayam mantab tidak ribet ini! Selamat berkreasi dengan resep sempol tanpa ayam mantab sederhana ini di rumah masing-masing,oke!.

