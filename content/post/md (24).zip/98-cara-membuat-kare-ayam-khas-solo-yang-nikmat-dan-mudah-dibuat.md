---
description: "Cara membuat Kare Ayam khas Solo yang nikmat dan Mudah Dibuat"
title: "Cara membuat Kare Ayam khas Solo yang nikmat dan Mudah Dibuat"
slug: 98-cara-membuat-kare-ayam-khas-solo-yang-nikmat-dan-mudah-dibuat
date: 2021-06-04T20:29:26.305Z
image: https://img-global.cpcdn.com/recipes/57542923a7730c22/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/57542923a7730c22/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/57542923a7730c22/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
author: Curtis Barker
ratingvalue: 4.7
reviewcount: 6
recipeingredient:
- "1 ekor ayam"
- "2 batang serai geprek"
- "1 ruas lengkuas geprek"
- "5 lembar daun jeruk"
- "3 lembar daun salam"
- "1 liter air"
- "secukupnya Garam"
- "1 sdt lada bubuk"
- "secukupnya Kaldu bubuk"
- "2 sdm munjung fibercreme"
- " Bumbu Halus"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "3 butir kemiri"
- "1 ruas kunyit"
- "1 sdt ketumbar bubuk"
- " Bahan Pelengkap"
- " Soun"
- " Wortel rebus"
- " Keripik kentang"
- " Seledri"
- " Sambal"
- " Kecambah  tauge"
recipeinstructions:
- "Tumis bumbu halus, serai, lengkuas, daun jeruk dan daun salam hingga harum."
- "Masukan ayam, aduk rata"
- "Tambahkan air, garam, lada, kaldu bubuk dan fibercreme. Aduk rata kembali, masak hingga matang dan ayam empuk."
- "Setelah kare matang, angkat ayam lalu suwir- suwir."
- "Tata nasi, soun, ayam suwir dan wortel rebus dalam mangkok."
- "Lalu siram dengan kuah kare, beri taburan kecambah, daun sledri dan keripik kentang. Sajikan hangat."
categories:
- Resep
tags:
- kare
- ayam
- khas

katakunci: kare ayam khas 
nutrition: 113 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Lunch

---


![Kare Ayam khas Solo](https://img-global.cpcdn.com/recipes/57542923a7730c22/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan panganan menggugah selera buat orang tercinta adalah suatu hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang ibu Tidak sekedar mengurus rumah saja, tapi anda juga harus menyediakan kebutuhan nutrisi terpenuhi dan juga masakan yang dikonsumsi orang tercinta harus enak.

Di era  saat ini, kita memang dapat memesan panganan siap saji meski tidak harus capek memasaknya dulu. Namun banyak juga orang yang selalu ingin memberikan hidangan yang terbaik untuk orang yang dicintainya. Lantaran, menyajikan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan famili. 



Mungkinkah kamu salah satu penikmat kare ayam khas solo?. Asal kamu tahu, kare ayam khas solo merupakan sajian khas di Nusantara yang saat ini digemari oleh kebanyakan orang dari hampir setiap wilayah di Indonesia. Kita bisa membuat kare ayam khas solo sendiri di rumahmu dan boleh jadi hidangan kesenanganmu di akhir pekanmu.

Anda tidak usah bingung untuk mendapatkan kare ayam khas solo, sebab kare ayam khas solo tidak sulit untuk dicari dan juga kamu pun boleh menghidangkannya sendiri di rumah. kare ayam khas solo dapat dibuat lewat beraneka cara. Sekarang ada banyak sekali cara kekinian yang menjadikan kare ayam khas solo lebih enak.

Resep kare ayam khas solo pun gampang dibuat, lho. Kamu jangan capek-capek untuk membeli kare ayam khas solo, lantaran Kita mampu menyajikan sendiri di rumah. Untuk Kita yang mau membuatnya, dibawah ini merupakan cara untuk menyajikan kare ayam khas solo yang lezat yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Kare Ayam khas Solo:

1. Ambil 1 ekor ayam
1. Ambil 2 batang serai, geprek
1. Ambil 1 ruas lengkuas, geprek
1. Siapkan 5 lembar daun jeruk
1. Sediakan 3 lembar daun salam
1. Ambil 1 liter air
1. Siapkan secukupnya Garam
1. Sediakan 1 sdt lada bubuk
1. Ambil secukupnya Kaldu bubuk
1. Ambil 2 sdm munjung fibercreme
1. Siapkan  Bumbu Halus
1. Gunakan 8 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Gunakan 3 butir kemiri
1. Sediakan 1 ruas kunyit
1. Ambil 1 sdt ketumbar bubuk
1. Siapkan  Bahan Pelengkap
1. Siapkan  Soun
1. Siapkan  Wortel rebus
1. Gunakan  Keripik kentang
1. Siapkan  Seledri
1. Siapkan  Sambal
1. Gunakan  Kecambah / tauge




<!--inarticleads2-->

##### Cara membuat Kare Ayam khas Solo:

1. Tumis bumbu halus, serai, lengkuas, daun jeruk dan daun salam hingga harum.
1. Masukan ayam, aduk rata
1. Tambahkan air, garam, lada, kaldu bubuk dan fibercreme. Aduk rata kembali, masak hingga matang dan ayam empuk.
1. Setelah kare matang, angkat ayam lalu suwir- suwir.
1. Tata nasi, soun, ayam suwir dan wortel rebus dalam mangkok.
1. Lalu siram dengan kuah kare, beri taburan kecambah, daun sledri dan keripik kentang. Sajikan hangat.




Wah ternyata cara buat kare ayam khas solo yang enak sederhana ini mudah sekali ya! Kita semua bisa mencobanya. Resep kare ayam khas solo Sangat cocok sekali untuk kita yang baru akan belajar memasak ataupun juga untuk anda yang telah ahli memasak.

Apakah kamu ingin mencoba buat resep kare ayam khas solo nikmat sederhana ini? Kalau anda tertarik, mending kamu segera siapin alat dan bahannya, setelah itu buat deh Resep kare ayam khas solo yang mantab dan tidak ribet ini. Sungguh taidak sulit kan. 

Maka dari itu, ketimbang kamu berlama-lama, ayo kita langsung hidangkan resep kare ayam khas solo ini. Pasti kalian gak akan menyesal sudah buat resep kare ayam khas solo nikmat tidak ribet ini! Selamat mencoba dengan resep kare ayam khas solo lezat tidak ribet ini di tempat tinggal kalian masing-masing,ya!.

