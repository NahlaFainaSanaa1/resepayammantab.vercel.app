---
description: "Cara membuat Lontong Opor ayam yang nikmat dan Mudah Dibuat"
title: "Cara membuat Lontong Opor ayam yang nikmat dan Mudah Dibuat"
slug: 394-cara-membuat-lontong-opor-ayam-yang-nikmat-dan-mudah-dibuat
date: 2021-05-06T21:09:02.933Z
image: https://img-global.cpcdn.com/recipes/231647816347c8f1/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/231647816347c8f1/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/231647816347c8f1/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
author: Betty Hale
ratingvalue: 4.8
reviewcount: 10
recipeingredient:
- "10 potong ayam"
- "200 ml santan kental"
- "1 liter air"
- " Bumbu halus "
- "7 siung bamer"
- "5 siung baput"
- "1 ruas jahe"
- "1 sdt jinten"
- "1 sdt ketumbar"
- "5 biji kemiri sangrai"
- " Bahan lain "
- "2 batang serai geprak"
- "Secukupnya laos geprak"
- "5 lembar daun jeruk"
- "3 lembar daun salam"
recipeinstructions:
- "Panaskan wajan beri minyak sedikit, lalu masukkan ayam hingga berubah warna dan kulitnya kecoklatan."
- "Tumis bumbu halus dan bahan lain hingga harum dan matang. Masukkan air dan ayam, masak hingga matang lalu tambahkan garam, gula, kaldu jamur dan merica bubuk, test rasa lalu tambahkan santan kental. Masak hingga mendidih jangan lupa diaduk agar santan tidak pecah, matikan api jika sudah mendidih"
- "Sajikan bersama lauk pelengkap lainnya."
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 219 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Lontong Opor ayam](https://img-global.cpcdn.com/recipes/231647816347c8f1/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan masakan nikmat kepada keluarga adalah suatu hal yang sangat menyenangkan bagi anda sendiri. Tugas seorang istri bukan saja mengatur rumah saja, tapi anda pun wajib memastikan kebutuhan nutrisi tercukupi dan juga masakan yang disantap keluarga tercinta harus nikmat.

Di masa  saat ini, kamu memang dapat membeli olahan instan tidak harus repot membuatnya terlebih dahulu. Namun ada juga lho orang yang selalu mau memberikan hidangan yang terenak bagi orang tercintanya. Karena, menghidangkan masakan sendiri jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan selera orang tercinta. 



Mungkinkah anda salah satu penikmat lontong opor ayam?. Tahukah kamu, lontong opor ayam adalah hidangan khas di Nusantara yang kini disenangi oleh kebanyakan orang dari berbagai wilayah di Nusantara. Kamu dapat menyajikan lontong opor ayam sendiri di rumahmu dan boleh dijadikan santapan kesukaanmu di hari liburmu.

Kalian tak perlu bingung untuk menyantap lontong opor ayam, sebab lontong opor ayam sangat mudah untuk ditemukan dan kita pun dapat menghidangkannya sendiri di rumah. lontong opor ayam boleh dibuat lewat berbagai cara. Kini telah banyak cara kekinian yang menjadikan lontong opor ayam lebih lezat.

Resep lontong opor ayam pun sangat gampang dihidangkan, lho. Kalian tidak perlu repot-repot untuk memesan lontong opor ayam, sebab Anda bisa menyiapkan di rumahmu. Bagi Kita yang akan menghidangkannya, berikut cara untuk menyajikan lontong opor ayam yang enak yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Lontong Opor ayam:

1. Ambil 10 potong ayam
1. Ambil 200 ml santan kental
1. Sediakan 1 liter air
1. Gunakan  Bumbu halus :
1. Siapkan 7 siung bamer
1. Siapkan 5 siung baput
1. Siapkan 1 ruas jahe
1. Siapkan 1 sdt jinten
1. Gunakan 1 sdt ketumbar
1. Ambil 5 biji kemiri sangrai
1. Sediakan  Bahan lain :
1. Sediakan 2 batang serai geprak
1. Gunakan Secukupnya laos geprak
1. Siapkan 5 lembar daun jeruk
1. Ambil 3 lembar daun salam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Lontong Opor ayam:

1. Panaskan wajan beri minyak sedikit, lalu masukkan ayam hingga berubah warna dan kulitnya kecoklatan.
1. Tumis bumbu halus dan bahan lain hingga harum dan matang. Masukkan air dan ayam, masak hingga matang lalu tambahkan garam, gula, kaldu jamur dan merica bubuk, test rasa lalu tambahkan santan kental. Masak hingga mendidih jangan lupa diaduk agar santan tidak pecah, matikan api jika sudah mendidih
1. Sajikan bersama lauk pelengkap lainnya.




Ternyata resep lontong opor ayam yang enak tidak rumit ini enteng sekali ya! Kita semua dapat menghidangkannya. Cara buat lontong opor ayam Sangat sesuai banget buat anda yang baru belajar memasak maupun untuk kamu yang telah jago memasak.

Apakah kamu mau mulai mencoba membuat resep lontong opor ayam enak tidak rumit ini? Kalau anda ingin, ayo kalian segera menyiapkan alat-alat dan bahan-bahannya, lalu buat deh Resep lontong opor ayam yang mantab dan tidak ribet ini. Sungguh taidak sulit kan. 

Oleh karena itu, ketimbang kamu diam saja, ayo langsung aja bikin resep lontong opor ayam ini. Pasti kalian gak akan nyesel sudah buat resep lontong opor ayam nikmat simple ini! Selamat mencoba dengan resep lontong opor ayam mantab sederhana ini di rumah masing-masing,oke!.

