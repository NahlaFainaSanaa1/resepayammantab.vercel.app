---
description: "Cara buat Lontong sayur opor ayam yang nikmat dan Mudah Dibuat"
title: "Cara buat Lontong sayur opor ayam yang nikmat dan Mudah Dibuat"
slug: 402-cara-buat-lontong-sayur-opor-ayam-yang-nikmat-dan-mudah-dibuat
date: 2021-05-16T16:46:59.371Z
image: https://img-global.cpcdn.com/recipes/58ff001d14bebb31/680x482cq70/lontong-sayur-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/58ff001d14bebb31/680x482cq70/lontong-sayur-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/58ff001d14bebb31/680x482cq70/lontong-sayur-opor-ayam-foto-resep-utama.jpg
author: Callie Potter
ratingvalue: 3.3
reviewcount: 5
recipeingredient:
- "1/2 ekor ayam kampung ptg 6 sy ayam negri"
- "1 bh labu siam sy pake 12 bh buah pepaya muda ptg korek api"
- "4 bh tahu segitiga potong goreng setgh matang"
- "4 butir telur rebus"
- "800 ml air sy 800 ml santan segar"
- "5 sdm fiber cream sy skip"
- "2 lbr daunsalam"
- "1 btg sere"
- "1 ruas lengkoas"
- "1 sdt gula"
- "1 sdt lada bubuk"
- "1 sdt kaldu jamur"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "4 bh cabe merah keriting"
- "1 ruas kunyit"
- "2 cm jahe"
- "3 butir kemiri"
- "1 sdm ketumbar"
- " Pelengkap"
- " Lontong ketupat siap pakai"
- " Secekupnya bawang goreng"
- " Kerupuk"
recipeinstructions:
- "Haluskan bumbu, boleh di blender lalu tumis bumbu hingga layu dan wangi + sere, laos, salam"
- "Masukkan dlm panci santan yg berisi ayam lalu masak dgn api kecil sampai ayam empuk, jika ayam sdh empuk tuang santan biarkan mendidih masukkan labu/ pepaya muda, tahu dan telur rebus masak sampai semua empuk, +garam, kaldu jamur dan gula lalu aduk hingga tercampur rata"
- "Cek rasa, matang angkat"
- "Penyajian : potong2 lontong lalu siram dgn kuah opor sayur + telur, potongan ayam beri bawang goreng"
- "Siap di santap"
categories:
- Resep
tags:
- lontong
- sayur
- opor

katakunci: lontong sayur opor 
nutrition: 288 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Lunch

---


![Lontong sayur opor ayam](https://img-global.cpcdn.com/recipes/58ff001d14bebb31/680x482cq70/lontong-sayur-opor-ayam-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan santapan enak untuk keluarga merupakan hal yang menggembirakan bagi kamu sendiri. Tanggung jawab seorang istri bukan cuman mengatur rumah saja, tetapi anda pun wajib memastikan kebutuhan nutrisi terpenuhi dan panganan yang dikonsumsi anak-anak mesti menggugah selera.

Di era  saat ini, kita sebenarnya bisa mengorder hidangan praktis tanpa harus capek membuatnya dahulu. Tapi ada juga mereka yang memang ingin memberikan yang terbaik bagi orang yang dicintainya. Pasalnya, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan famili. 

Icho rajin sangat.ini sudah setorannya yang kesekian. tetep kuereen dan mengunggah selera tentunya. terutama posisi ayamnya.kikikikik. Hai partners, Malah aku kok keranjingan buat lontong ya:)hehe.abis suka jg sih.udah aku pasang logonya di webku. Mudah membuat lontong sayur sendiri di rumah.

Mungkinkah anda seorang penggemar lontong sayur opor ayam?. Tahukah kamu, lontong sayur opor ayam merupakan makanan khas di Nusantara yang sekarang disukai oleh kebanyakan orang di berbagai tempat di Nusantara. Kalian bisa menghidangkan lontong sayur opor ayam sendiri di rumahmu dan dapat dijadikan santapan favorit di akhir pekanmu.

Kalian tidak usah bingung jika kamu ingin memakan lontong sayur opor ayam, lantaran lontong sayur opor ayam tidak sukar untuk didapatkan dan kalian pun bisa memasaknya sendiri di rumah. lontong sayur opor ayam bisa diolah lewat beraneka cara. Sekarang sudah banyak resep kekinian yang membuat lontong sayur opor ayam semakin nikmat.

Resep lontong sayur opor ayam pun sangat gampang untuk dibikin, lho. Kamu tidak usah capek-capek untuk membeli lontong sayur opor ayam, sebab Kalian bisa menghidangkan ditempatmu. Untuk Kita yang akan mencobanya, inilah cara menyajikan lontong sayur opor ayam yang nikamat yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Lontong sayur opor ayam:

1. Siapkan 1/2 ekor ayam kampung ptg 6 (sy ayam negri)
1. Sediakan 1 bh labu siam (sy pake 1/2 bh buah pepaya muda) ptg korek api
1. Sediakan 4 bh tahu segitiga potong (goreng setgh matang)
1. Gunakan 4 butir telur rebus
1. Ambil 800 ml air (sy 800 ml santan segar)
1. Sediakan 5 sdm fiber cream (sy skip)
1. Ambil 2 lbr daunsalam
1. Sediakan 1 btg sere
1. Ambil 1 ruas lengkoas
1. Gunakan 1 sdt gula
1. Gunakan 1 sdt lada bubuk
1. Ambil 1 sdt kaldu jamur
1. Siapkan  Bumbu halus
1. Siapkan 6 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Sediakan 4 bh cabe merah keriting
1. Ambil 1 ruas kunyit
1. Gunakan 2 cm jahe
1. Gunakan 3 butir kemiri
1. Ambil 1 sdm ketumbar
1. Sediakan  Pelengkap
1. Siapkan  Lontong /ketupat siap pakai
1. Sediakan  Secekupnya bawang goreng
1. Gunakan  Kerupuk


Kelezatan opor ayam, terletak pada perpaduan bumbu, kuah kental. Sebut saja masakan seperti lontong sayur, rendang, atau opor ayam. Opor ayam juga bisa dibuat untuk lidah-lidah yang suka dengan pedas. Kuah kental dengan kaldu pedas yang tercampur dengan ayam lembut pastinya akan membuat kamu selalu nambah. 

<!--inarticleads2-->

##### Cara menyiapkan Lontong sayur opor ayam:

1. Haluskan bumbu, boleh di blender lalu tumis bumbu hingga layu dan wangi + sere, laos, salam
1. Masukkan dlm panci santan yg berisi ayam lalu masak dgn api kecil sampai ayam empuk, jika ayam sdh empuk tuang santan biarkan mendidih masukkan labu/ pepaya muda, tahu dan telur rebus masak sampai semua empuk, +garam, kaldu jamur dan gula lalu aduk hingga tercampur rata
1. Cek rasa, matang angkat
1. Penyajian : potong2 lontong lalu siram dgn kuah opor sayur + telur, potongan ayam beri bawang goreng
1. Siap di santap


Lontong sayur (lit. vegetable rice cake) is an Indonesian traditional rice dish made of pieces of lontong served in coconut milk soup with shredded chayote, tempeh, tofu, hard-boiled egg, sambal and krupuk. Lontong sayur is related and quite similar to ketupat sayur and is a favourite breakfast menu next to. Rasanya gurih mirip opor ayam dengan sedikit aroma ketumbar. Selain ayam juga ditambah dengan tempe. Cita rasanya yang gurih ringan membuat makanan Rais,salah satu pedagang lontong tuyuhan menyebutkan, secara garis besar untuk memasak lontong tuyuhan menyerupai sayur opor. 

Wah ternyata resep lontong sayur opor ayam yang lezat tidak ribet ini enteng sekali ya! Anda Semua dapat memasaknya. Resep lontong sayur opor ayam Sangat sesuai banget untuk kita yang baru belajar memasak ataupun juga untuk kamu yang telah pandai dalam memasak.

Tertarik untuk mencoba buat resep lontong sayur opor ayam enak simple ini? Kalau tertarik, ayo kalian segera buruan menyiapkan peralatan dan bahan-bahannya, lalu buat deh Resep lontong sayur opor ayam yang mantab dan sederhana ini. Benar-benar gampang kan. 

Jadi, daripada anda berlama-lama, maka langsung aja hidangkan resep lontong sayur opor ayam ini. Pasti kamu tiidak akan menyesal bikin resep lontong sayur opor ayam mantab simple ini! Selamat berkreasi dengan resep lontong sayur opor ayam lezat tidak ribet ini di rumah sendiri,ya!.

