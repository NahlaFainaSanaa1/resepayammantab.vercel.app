---
description: "Bahan-bahan Hati Ayam,Kentang Masak Kuning yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Hati Ayam,Kentang Masak Kuning yang lezat dan Mudah Dibuat"
slug: 308-bahan-bahan-hati-ayam-kentang-masak-kuning-yang-lezat-dan-mudah-dibuat
date: 2021-01-13T18:44:35.820Z
image: https://img-global.cpcdn.com/recipes/8b094f0c06ff4e63/680x482cq70/hati-ayamkentang-masak-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b094f0c06ff4e63/680x482cq70/hati-ayamkentang-masak-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b094f0c06ff4e63/680x482cq70/hati-ayamkentang-masak-kuning-foto-resep-utama.jpg
author: Mario Steele
ratingvalue: 3.2
reviewcount: 4
recipeingredient:
- "250 gram hati ayamAmpela"
- "1 buah Kentang"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 buah tomat"
- "4-5 biji Cabe Rawit"
- "1 sdm Bumbu Dasar kuning           lihat resep"
- "1 sdt garam"
- "1 sdt kaldu jamur"
- "1/2 sdt gula"
- "1 ruas Jahe geprek"
- "1 batang serai geprek"
- "Secukupnya Minyak untuk menumis bumbu"
recipeinstructions:
- "Ungkep hati ayam dengan 1sdt bumbu dasar kuning Tambahkan daun jeruk daun salam tambahkan juga 1sdt garam."
- "Jika sudah angkat tiriskan,potong² hati ayam sesuai selera,tomat dan juga kentang."
- "Goreng kentang yang sudah di potong dadu sebentar saja, angkat sisihkan"
- "Tumis bumbu Dasar kuning hingga harum,masukan daun jeruk,daun salam masukan lagi serai dan jahe geprek aduk rata Masukan potongan hati serta kentang,tambahkan kaldu jamur,dan beri sedikit air aduk rata terakhir masukan potongan tomat."
- "Setelah dirasa cukup matikan kompor."
categories:
- Resep
tags:
- hati
- ayamkentang
- masak

katakunci: hati ayamkentang masak 
nutrition: 121 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner

---


![Hati Ayam,Kentang Masak Kuning](https://img-global.cpcdn.com/recipes/8b094f0c06ff4e63/680x482cq70/hati-ayamkentang-masak-kuning-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, mempersiapkan santapan enak pada keluarga tercinta adalah suatu hal yang mengasyikan bagi kita sendiri. Peran seorang  wanita bukan cuman mengurus rumah saja, tapi kamu pun harus menyediakan keperluan gizi tercukupi dan panganan yang disantap keluarga tercinta harus nikmat.

Di masa  sekarang, kamu memang bisa memesan olahan instan meski tanpa harus susah memasaknya dahulu. Tetapi ada juga lho orang yang selalu ingin memberikan yang terenak untuk keluarganya. Sebab, menyajikan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan famili. 



Mungkinkah anda merupakan salah satu penikmat hati ayam,kentang masak kuning?. Tahukah kamu, hati ayam,kentang masak kuning adalah makanan khas di Indonesia yang sekarang digemari oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Kita bisa menyajikan hati ayam,kentang masak kuning buatan sendiri di rumahmu dan boleh dijadikan santapan favorit di akhir pekanmu.

Kita tak perlu bingung untuk menyantap hati ayam,kentang masak kuning, lantaran hati ayam,kentang masak kuning tidak sulit untuk didapatkan dan anda pun boleh membuatnya sendiri di tempatmu. hati ayam,kentang masak kuning bisa dibuat lewat berbagai cara. Sekarang sudah banyak banget resep modern yang menjadikan hati ayam,kentang masak kuning lebih lezat.

Resep hati ayam,kentang masak kuning juga sangat mudah dihidangkan, lho. Kita tidak usah repot-repot untuk membeli hati ayam,kentang masak kuning, lantaran Anda mampu membuatnya di rumahmu. Untuk Kita yang akan menyajikannya, berikut ini cara menyajikan hati ayam,kentang masak kuning yang enak yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Hati Ayam,Kentang Masak Kuning:

1. Gunakan 250 gram hati ayam+Ampela
1. Gunakan 1 buah Kentang
1. Siapkan 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Gunakan 1 buah tomat
1. Sediakan 4-5 biji Cabe Rawit
1. Gunakan 1 sdm Bumbu Dasar kuning           (lihat resep)
1. Gunakan 1 sdt garam
1. Gunakan 1 sdt kaldu jamur
1. Sediakan 1/2 sdt gula
1. Ambil 1 ruas Jahe (geprek)
1. Gunakan 1 batang serai (geprek)
1. Sediakan Secukupnya Minyak untuk menumis bumbu




<!--inarticleads2-->

##### Cara menyiapkan Hati Ayam,Kentang Masak Kuning:

1. Ungkep hati ayam dengan 1sdt bumbu dasar kuning - Tambahkan daun jeruk daun salam tambahkan juga 1sdt garam.
1. Jika sudah angkat tiriskan,potong² hati ayam sesuai selera,tomat dan juga kentang.
1. Goreng kentang yang sudah di potong dadu sebentar saja, angkat sisihkan
1. Tumis bumbu Dasar kuning hingga harum,masukan daun jeruk,daun salam masukan lagi serai dan jahe geprek aduk rata - Masukan potongan hati serta kentang,tambahkan kaldu jamur,dan beri sedikit air aduk rata terakhir masukan potongan tomat.
1. Setelah dirasa cukup matikan kompor.




Wah ternyata cara membuat hati ayam,kentang masak kuning yang mantab sederhana ini gampang banget ya! Kita semua dapat menghidangkannya. Cara Membuat hati ayam,kentang masak kuning Sangat cocok sekali untuk kita yang baru belajar memasak maupun juga bagi kalian yang sudah ahli memasak.

Tertarik untuk mencoba bikin resep hati ayam,kentang masak kuning mantab tidak rumit ini? Kalau kalian mau, mending kamu segera menyiapkan alat dan bahannya, lantas buat deh Resep hati ayam,kentang masak kuning yang nikmat dan tidak rumit ini. Benar-benar gampang kan. 

Jadi, daripada kalian berlama-lama, yuk kita langsung sajikan resep hati ayam,kentang masak kuning ini. Dijamin kamu gak akan nyesel membuat resep hati ayam,kentang masak kuning mantab tidak ribet ini! Selamat mencoba dengan resep hati ayam,kentang masak kuning mantab sederhana ini di tempat tinggal masing-masing,ya!.

