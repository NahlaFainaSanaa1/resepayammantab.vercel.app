---
description: "Bahan-bahan Kare Ayam Solo yang enak dan Mudah Dibuat"
title: "Bahan-bahan Kare Ayam Solo yang enak dan Mudah Dibuat"
slug: 90-bahan-bahan-kare-ayam-solo-yang-enak-dan-mudah-dibuat
date: 2021-03-03T18:54:27.393Z
image: https://img-global.cpcdn.com/recipes/74a6593e37bad594/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/74a6593e37bad594/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/74a6593e37bad594/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Matilda Adams
ratingvalue: 3.4
reviewcount: 9
recipeingredient:
- " Bahan A"
- "1 kg daging ayam"
- "1500 ml air"
- "300 ml santan kental"
- "2 batang sereh geprek"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang kayu manis"
- "5 butir kapulaga geprek"
- "2 butir pekakbunga lawang"
- "3 butir cengkeh"
- "Secukupnya minyak"
- "Secukupnya garam"
- "1 sdt gula pasir atau sesuaikan selera"
- "Secukupnya penyedap"
- " B bumbu halus"
- "9 siung bawang putih"
- "5 siung bawang merah"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 butir kemiri sangrai sebentar dulu"
- "1/2 sdt jintan"
- "1 sdt ketumbar"
- "1/2 sdt merica butir"
- " C Pelengkap"
- "Secukupnya irisan wortel rebus"
- "Secukupnya keripik kentangkentang iris tipis lalu goreng"
- "Secukupnya Soun atau bihun jagung"
- "Secukupnya irisan daun bawang"
- "Secukupnya irisan daun seledri saya gak pakai"
- "Secukupnya bawang goreng"
- " Toge saya ga pakai"
recipeinstructions:
- "Dalam panci, panaskan minyak sekitar 4.sdm masukkan bumbu halus, tumis hingga harum, masukkan sereh, daun jeruk, daun salam, kayu manis, pekak, cengkeh, kapulaga, aduk tumis lagi hingga rempah harum, masukkan potong ayam, garam dan penyedap, aduk rata dan tumis beberapa saat, lalu Tutup pancinya biarkan ayam berubah warna dan sedikit mengeluarkan air kaldu dengan sendirinya (gunakan api kecil agar tidak gosong)"
- "Masukkan air, masak dengan api besar, biarkan hingga mendidih, setelah mendidih, tutup pancinya, kecilkan api biarkan terus masak hingga ayam empuk."
- "Setelah ayam empuk, masukkan santan kental, masak sambil diaduk ya agar santan tidak pecah, masak hingga dirasa santan matang, dan kuah menyusut, test rasa tambahkan gula pasir, aduk rata, jika kurang asin bisa ditambah garam sesuai selera. Angkat ayamnya, goreng, lalu suwir suwir untuk penyajian nanti"
- "Penyajian = dalam mangkuk, tata nasi, lalu soun/bihun, lalu toge, suwiran ayam goreng, irisan wortel rebus, keripik kentang, siram dengan kuah Kare, taburi dengan irisan daun bawang, daun seledri dan juga bawang goreng, sajikan dengan sambal, jika suka kucuri dengan perasan jeruk nipis. Syegerrr 🍲 😍"
- "Jika ada sisa kuah Kare jangan dibuang ya, bisa disaring lalu dibikin kremesan yang gurih (resep kremesan sudah ada)"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dinner

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/74a6593e37bad594/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Apabila kita seorang wanita, menyediakan olahan menggugah selera kepada orang tercinta merupakan suatu hal yang sangat menyenangkan untuk anda sendiri. Tugas seorang istri bukan cuma mengurus rumah saja, tapi kamu juga wajib memastikan keperluan gizi tercukupi dan hidangan yang disantap orang tercinta mesti enak.

Di era  saat ini, kalian sebenarnya mampu membeli hidangan instan meski tanpa harus capek memasaknya dulu. Tetapi ada juga lho mereka yang memang ingin memberikan hidangan yang terlezat untuk keluarganya. Pasalnya, memasak yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan masakan kesukaan famili. 



Mungkinkah anda merupakan salah satu penyuka kare ayam solo?. Tahukah kamu, kare ayam solo adalah hidangan khas di Indonesia yang saat ini disenangi oleh kebanyakan orang dari berbagai daerah di Indonesia. Anda bisa menyajikan kare ayam solo sendiri di rumahmu dan boleh dijadikan makanan kesukaanmu di akhir pekanmu.

Kita tidak usah bingung untuk memakan kare ayam solo, lantaran kare ayam solo tidak sulit untuk didapatkan dan kamu pun boleh mengolahnya sendiri di rumah. kare ayam solo boleh diolah lewat beragam cara. Sekarang sudah banyak cara kekinian yang menjadikan kare ayam solo semakin lezat.

Resep kare ayam solo pun mudah sekali untuk dibikin, lho. Anda tidak perlu capek-capek untuk memesan kare ayam solo, sebab Kalian mampu menyajikan ditempatmu. Untuk Kalian yang akan mencobanya, inilah cara menyajikan kare ayam solo yang enak yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Kare Ayam Solo:

1. Gunakan  Bahan= A)
1. Siapkan 1 .kg. daging ayam
1. Ambil 1500 .ml. air
1. Sediakan 300 .ml. santan kental
1. Gunakan 2 .batang. sereh geprek
1. Gunakan 4 .lembar. daun jeruk
1. Sediakan 2 .lembar. daun salam
1. Gunakan 1 .batang. kayu manis
1. Ambil 5 .butir. kapulaga geprek
1. Sediakan 2 .butir. pekak/bunga lawang
1. Siapkan 3 .butir. cengkeh
1. Siapkan Secukupnya minyak
1. Siapkan Secukupnya garam
1. Siapkan 1 .sdt gula pasir atau sesuaikan selera
1. Sediakan Secukupnya penyedap
1. Ambil  B). bumbu halus=
1. Ambil 9 .siung. bawang putih
1. Siapkan 5 .siung. bawang merah
1. Gunakan 1 .ruas. kunyit
1. Sediakan 1 .ruas. jahe
1. Siapkan 3 .butir. kemiri (sangrai sebentar dulu)
1. Sediakan 1/2 .sdt. jintan
1. Ambil 1 .sdt. ketumbar
1. Siapkan 1/2 .sdt. merica butir
1. Ambil  C). Pelengkap=
1. Gunakan Secukupnya irisan wortel rebus
1. Ambil Secukupnya keripik kentang/kentang iris tipis lalu goreng
1. Siapkan Secukupnya Soun (atau bihun jagung)
1. Sediakan Secukupnya irisan daun bawang
1. Siapkan Secukupnya irisan daun seledri (saya gak pakai)
1. Sediakan Secukupnya bawang goreng
1. Sediakan  Toge (saya ga pakai)




<!--inarticleads2-->

##### Cara menyiapkan Kare Ayam Solo:

1. Dalam panci, panaskan minyak sekitar 4.sdm masukkan bumbu halus, tumis hingga harum, masukkan sereh, daun jeruk, daun salam, kayu manis, pekak, cengkeh, kapulaga, aduk tumis lagi hingga rempah harum, masukkan potong ayam, garam dan penyedap, aduk rata dan tumis beberapa saat, lalu Tutup pancinya biarkan ayam berubah warna dan sedikit mengeluarkan air kaldu dengan sendirinya (gunakan api kecil agar tidak gosong)
1. Masukkan air, masak dengan api besar, biarkan hingga mendidih, setelah mendidih, tutup pancinya, kecilkan api biarkan terus masak hingga ayam empuk.
1. Setelah ayam empuk, masukkan santan kental, masak sambil diaduk ya agar santan tidak pecah, masak hingga dirasa santan matang, dan kuah menyusut, test rasa tambahkan gula pasir, aduk rata, jika kurang asin bisa ditambah garam sesuai selera. Angkat ayamnya, goreng, lalu suwir suwir untuk penyajian nanti
1. Penyajian = dalam mangkuk, tata nasi, lalu soun/bihun, lalu toge, suwiran ayam goreng, irisan wortel rebus, keripik kentang, siram dengan kuah Kare, taburi dengan irisan daun bawang, daun seledri dan juga bawang goreng, sajikan dengan sambal, jika suka kucuri dengan perasan jeruk nipis. Syegerrr 🍲 😍
1. Jika ada sisa kuah Kare jangan dibuang ya, bisa disaring lalu dibikin kremesan yang gurih (resep kremesan sudah ada)




Ternyata cara membuat kare ayam solo yang lezat tidak ribet ini gampang sekali ya! Semua orang dapat membuatnya. Cara buat kare ayam solo Sesuai sekali untuk kamu yang baru akan belajar memasak atau juga untuk anda yang sudah lihai memasak.

Tertarik untuk mulai mencoba bikin resep kare ayam solo nikmat tidak ribet ini? Kalau tertarik, ayo kalian segera menyiapkan alat-alat dan bahannya, setelah itu bikin deh Resep kare ayam solo yang mantab dan tidak ribet ini. Sangat taidak sulit kan. 

Maka, ketimbang kita berfikir lama-lama, maka kita langsung sajikan resep kare ayam solo ini. Pasti anda gak akan nyesel sudah buat resep kare ayam solo enak simple ini! Selamat berkreasi dengan resep kare ayam solo lezat tidak rumit ini di rumah sendiri,oke!.

