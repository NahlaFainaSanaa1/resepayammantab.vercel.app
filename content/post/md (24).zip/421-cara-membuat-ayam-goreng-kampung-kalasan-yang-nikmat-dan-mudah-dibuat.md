---
description: "Cara membuat Ayam Goreng Kampung Kalasan yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Goreng Kampung Kalasan yang nikmat dan Mudah Dibuat"
slug: 421-cara-membuat-ayam-goreng-kampung-kalasan-yang-nikmat-dan-mudah-dibuat
date: 2021-04-11T17:34:26.302Z
image: https://img-global.cpcdn.com/recipes/75eaada8fccf92b9/680x482cq70/ayam-goreng-kampung-kalasan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/75eaada8fccf92b9/680x482cq70/ayam-goreng-kampung-kalasan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/75eaada8fccf92b9/680x482cq70/ayam-goreng-kampung-kalasan-foto-resep-utama.jpg
author: Leila Morton
ratingvalue: 4.3
reviewcount: 15
recipeingredient:
- "2 ekor Ayam Kampung"
- "2 liter Air Kelapa"
- "20 siung bawang merah"
- "10 siung bawang putih"
- "2 sdm Ketumbar bubuk"
- "4 bh kemiri"
- " Gula merah ukuran sesuai selera diiris tipis"
- "secukupnya Garam"
- "secukupnya Penyedap"
- "4 lbr Daun salam"
- "1 ruas jari Lengkuas"
recipeinstructions:
- "Potong ayam ukuran sesuai selera dan bersihkan"
- "Haluskan bumbu, kecuali daun salam, lengkuas gula merah, penyedap"
- "Siapkan wajan..masukan ayam potong dan balurkan bumbu halus dengan rata..nyalakan api"
- "Masukan Air Kelapa, daun salam, lengkuas..aduk hingga rata dan air mendidih"
- "Setelah mendidih, masukan gula merah..aduk hingga rata"
- "Masukan penyedap, aduk rata..kecilkan api..masak hingga ayam empuk dan air menyusut dan aduk sesekali agar tidak gosong dibawah"
- "Koreksi rasa..setelah empuk dan air menyusut.matikan api..angkat"
- "Panas minyak goreng diatas wajan, goreng ayam kalasan, masak sebentar saja krn cepat gosong."
- "Sajikan dengan Nasi Panas, Lalapan dan Sambal goreng lebih enak (resep sambal goreng di resep berikutnya)"
categories:
- Resep
tags:
- ayam
- goreng
- kampung

katakunci: ayam goreng kampung 
nutrition: 222 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Goreng Kampung Kalasan](https://img-global.cpcdn.com/recipes/75eaada8fccf92b9/680x482cq70/ayam-goreng-kampung-kalasan-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan masakan enak kepada keluarga merupakan suatu hal yang sangat menyenangkan untuk kamu sendiri. Peran seorang  wanita bukan cuma mengatur rumah saja, tetapi kamu pun wajib menyediakan kebutuhan nutrisi terpenuhi dan juga olahan yang dimakan orang tercinta mesti menggugah selera.

Di masa  sekarang, kita sebenarnya mampu memesan santapan siap saji tidak harus susah mengolahnya terlebih dahulu. Tapi banyak juga orang yang memang mau memberikan hidangan yang terenak bagi orang yang dicintainya. Sebab, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai selera keluarga. 



Mungkinkah anda salah satu penggemar ayam goreng kampung kalasan?. Asal kamu tahu, ayam goreng kampung kalasan merupakan sajian khas di Nusantara yang sekarang disenangi oleh kebanyakan orang di hampir setiap daerah di Indonesia. Kamu bisa memasak ayam goreng kampung kalasan buatan sendiri di rumahmu dan dapat dijadikan makanan favorit di akhir pekan.

Anda tidak usah bingung jika kamu ingin menyantap ayam goreng kampung kalasan, karena ayam goreng kampung kalasan tidak sulit untuk didapatkan dan kalian pun dapat membuatnya sendiri di rumah. ayam goreng kampung kalasan boleh dibuat lewat berbagai cara. Saat ini sudah banyak banget resep kekinian yang menjadikan ayam goreng kampung kalasan lebih mantap.

Resep ayam goreng kampung kalasan pun mudah sekali untuk dibikin, lho. Kalian jangan capek-capek untuk memesan ayam goreng kampung kalasan, karena Kalian dapat menyajikan sendiri di rumah. Bagi Kita yang akan menyajikannya, dibawah ini merupakan cara membuat ayam goreng kampung kalasan yang lezat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Goreng Kampung Kalasan:

1. Siapkan 2 ekor Ayam Kampung
1. Gunakan 2 liter Air Kelapa
1. Ambil 20 siung bawang merah
1. Ambil 10 siung bawang putih
1. Sediakan 2 sdm Ketumbar bubuk
1. Ambil 4 bh kemiri
1. Sediakan  Gula merah (ukuran sesuai selera) diiris tipis
1. Ambil secukupnya Garam
1. Sediakan secukupnya Penyedap
1. Siapkan 4 lbr Daun salam
1. Ambil 1 ruas jari Lengkuas




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Kampung Kalasan:

1. Potong ayam ukuran sesuai selera dan bersihkan
<img src="https://img-global.cpcdn.com/steps/8a37b2f495e32e9a/160x128cq70/ayam-goreng-kampung-kalasan-langkah-memasak-1-foto.jpg" alt="Ayam Goreng Kampung Kalasan"><img src="https://img-global.cpcdn.com/steps/747e160a01a8c489/160x128cq70/ayam-goreng-kampung-kalasan-langkah-memasak-1-foto.jpg" alt="Ayam Goreng Kampung Kalasan">1. Haluskan bumbu, kecuali daun salam, lengkuas gula merah, penyedap
1. Siapkan wajan..masukan ayam potong dan balurkan bumbu halus dengan rata..nyalakan api
1. Masukan Air Kelapa, daun salam, lengkuas..aduk hingga rata dan air mendidih
1. Setelah mendidih, masukan gula merah..aduk hingga rata
1. Masukan penyedap, aduk rata..kecilkan api..masak hingga ayam empuk dan air menyusut dan aduk sesekali agar tidak gosong dibawah
1. Koreksi rasa..setelah empuk dan air menyusut.matikan api..angkat
1. Panas minyak goreng diatas wajan, goreng ayam kalasan, masak sebentar saja krn cepat gosong.
1. Sajikan dengan Nasi Panas, Lalapan dan Sambal goreng lebih enak (resep sambal goreng di resep berikutnya)




Ternyata cara buat ayam goreng kampung kalasan yang mantab tidak rumit ini gampang banget ya! Kalian semua dapat mencobanya. Resep ayam goreng kampung kalasan Sesuai sekali untuk kita yang baru mau belajar memasak maupun juga untuk kalian yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba buat resep ayam goreng kampung kalasan mantab simple ini? Kalau tertarik, mending kamu segera buruan menyiapkan peralatan dan bahan-bahannya, lalu buat deh Resep ayam goreng kampung kalasan yang nikmat dan simple ini. Sangat gampang kan. 

Oleh karena itu, ketimbang kita berlama-lama, hayo kita langsung saja buat resep ayam goreng kampung kalasan ini. Pasti kalian gak akan nyesel sudah membuat resep ayam goreng kampung kalasan enak simple ini! Selamat berkreasi dengan resep ayam goreng kampung kalasan mantab tidak ribet ini di rumah masing-masing,ya!.

