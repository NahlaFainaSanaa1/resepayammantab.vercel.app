---
description: "Resep Ayam Goreng Kalasan yang enak Untuk Jualan"
title: "Resep Ayam Goreng Kalasan yang enak Untuk Jualan"
slug: 71-resep-ayam-goreng-kalasan-yang-enak-untuk-jualan
date: 2021-06-26T12:34:33.270Z
image: https://img-global.cpcdn.com/recipes/685eecdc14608330/680x482cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/685eecdc14608330/680x482cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/685eecdc14608330/680x482cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
author: Millie Hopkins
ratingvalue: 3.6
reviewcount: 12
recipeingredient:
- "1/2 kg ayam potong bagian apa saja me sayap"
- "500 ml air kelapa"
- "1/2 buah jeruk nipis"
- "Secukupnya minyak goreng"
- " Bumbu Halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1/2 sdt lada butiran me bubuk"
- "1 ruas lengkuas muda"
- " Bumbu Cemplung"
- "2 lbr daun salam"
- "2 lbr daun jeruk"
- "1 batang sereh"
- " Bumbubumbu Lain"
- "100 gr gula merah"
- "1,5 sdm kecap manis"
- "1 sdm gula pasir"
- "Secukupnya garam dan kaldu jamur"
- " Bahan Pelengkap"
- " Timun Lalap"
- " Sambal tomat terasi matang"
recipeinstructions:
- "Siapkan semua bahan. Cuci bersih ayam, lumuri dg perasan jeruk nipis lalu diamkan selama 15 menit. Cuci kembali hingga bersih."
- "Haluskan bumbu."
- "Lumuri ayam dg bumbu yg telah dihaluskan. Marinasi ayam selama kurleb 30 menit."
- "Didihkan air kelapa dan bumbu cemplung. Masukkan ayam yg telah dimarinasi, masak ayam hingga empuk."
- "Tambahkan gula merah, kecap, garam dan kaldu bubuk. Aduk pelan-pelan. Masak hingga merata dan menyusut airnya. Angkat dan tiriskan."
- "Panaskan minyak, goreng ayam hingga matang kecoklatan (warna sesuai selera ya, kalau saga dan suami suka yg agak gosong), angkat dan tiriskan."
- "Ayam goreng kalasan siap disajikan ditemani lalapan dan sambal. Selamat mencoba dan semoga bermanfaat."
categories:
- Resep
tags:
- ayam
- goreng
- kalasan

katakunci: ayam goreng kalasan 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Goreng Kalasan](https://img-global.cpcdn.com/recipes/685eecdc14608330/680x482cq70/ayam-goreng-kalasan-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyuguhkan santapan sedap pada keluarga tercinta adalah suatu hal yang sangat menyenangkan bagi anda sendiri. Kewajiban seorang istri bukan hanya mengurus rumah saja, namun anda juga wajib memastikan keperluan gizi tercukupi dan juga santapan yang dimakan anak-anak wajib lezat.

Di waktu  saat ini, kita sebenarnya mampu mengorder hidangan instan meski tanpa harus susah memasaknya terlebih dahulu. Tapi ada juga lho mereka yang memang ingin memberikan yang terbaik bagi keluarganya. Lantaran, menghidangkan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan masakan kesukaan keluarga. 



Apakah anda salah satu penikmat ayam goreng kalasan?. Tahukah kamu, ayam goreng kalasan adalah sajian khas di Indonesia yang kini digemari oleh banyak orang dari berbagai tempat di Nusantara. Kamu bisa menghidangkan ayam goreng kalasan olahan sendiri di rumahmu dan dapat dijadikan makanan favoritmu di akhir pekan.

Kita tidak perlu bingung jika kamu ingin mendapatkan ayam goreng kalasan, lantaran ayam goreng kalasan gampang untuk dicari dan kita pun bisa membuatnya sendiri di tempatmu. ayam goreng kalasan dapat dibuat lewat bermacam cara. Sekarang ada banyak cara modern yang menjadikan ayam goreng kalasan semakin lebih enak.

Resep ayam goreng kalasan juga gampang sekali untuk dibikin, lho. Anda tidak usah capek-capek untuk memesan ayam goreng kalasan, tetapi Kalian mampu menyajikan di rumah sendiri. Bagi Kamu yang hendak menghidangkannya, berikut resep untuk membuat ayam goreng kalasan yang nikamat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Goreng Kalasan:

1. Siapkan 1/2 kg ayam potong bagian apa saja (me. sayap)
1. Ambil 500 ml air kelapa
1. Ambil 1/2 buah jeruk nipis
1. Ambil Secukupnya minyak goreng
1. Gunakan  Bumbu Halus:
1. Ambil 6 siung bawang merah
1. Ambil 4 siung bawang putih
1. Siapkan 1/2 sdt lada butiran (me. bubuk)
1. Siapkan 1 ruas lengkuas muda
1. Ambil  Bumbu Cemplung:
1. Siapkan 2 lbr daun salam
1. Gunakan 2 lbr daun jeruk
1. Sediakan 1 batang sereh
1. Gunakan  Bumbu-bumbu Lain:
1. Ambil 100 gr gula merah
1. Siapkan 1,5 sdm kecap manis
1. Ambil 1 sdm gula pasir
1. Gunakan Secukupnya garam, dan kaldu jamur
1. Gunakan  Bahan Pelengkap:
1. Sediakan  Timun Lalap
1. Siapkan  Sambal tomat terasi matang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Goreng Kalasan:

1. Siapkan semua bahan. - Cuci bersih ayam, lumuri dg perasan jeruk nipis lalu diamkan selama 15 menit. Cuci kembali hingga bersih.
1. Haluskan bumbu.
1. Lumuri ayam dg bumbu yg telah dihaluskan. Marinasi ayam selama kurleb 30 menit.
1. Didihkan air kelapa dan bumbu cemplung. Masukkan ayam yg telah dimarinasi, masak ayam hingga empuk.
1. Tambahkan gula merah, kecap, garam dan kaldu bubuk. Aduk pelan-pelan. Masak hingga merata dan menyusut airnya. Angkat dan tiriskan.
1. Panaskan minyak, goreng ayam hingga matang kecoklatan (warna sesuai selera ya, kalau saga dan suami suka yg agak gosong), angkat dan tiriskan.
1. Ayam goreng kalasan siap disajikan ditemani lalapan dan sambal. Selamat mencoba dan semoga bermanfaat.




Ternyata cara buat ayam goreng kalasan yang nikamt tidak ribet ini mudah sekali ya! Semua orang mampu membuatnya. Cara buat ayam goreng kalasan Cocok banget buat kita yang baru akan belajar memasak ataupun bagi anda yang sudah pandai memasak.

Tertarik untuk mencoba membuat resep ayam goreng kalasan nikmat tidak ribet ini? Kalau kalian mau, yuk kita segera siapin alat dan bahan-bahannya, kemudian buat deh Resep ayam goreng kalasan yang lezat dan sederhana ini. Betul-betul gampang kan. 

Maka, ketimbang kamu berlama-lama, maka langsung aja sajikan resep ayam goreng kalasan ini. Dijamin anda tak akan nyesel bikin resep ayam goreng kalasan enak tidak rumit ini! Selamat mencoba dengan resep ayam goreng kalasan enak sederhana ini di rumah masing-masing,oke!.

