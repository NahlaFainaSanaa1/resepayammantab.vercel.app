---
description: "Cara buat Ungkep ayam goreng bumbu rempah Sederhana dan Mudah Dibuat"
title: "Cara buat Ungkep ayam goreng bumbu rempah Sederhana dan Mudah Dibuat"
slug: 492-cara-buat-ungkep-ayam-goreng-bumbu-rempah-sederhana-dan-mudah-dibuat
date: 2021-01-19T16:02:47.821Z
image: https://img-global.cpcdn.com/recipes/9d63e12ddd391432/680x482cq70/ungkep-ayam-goreng-bumbu-rempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d63e12ddd391432/680x482cq70/ungkep-ayam-goreng-bumbu-rempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d63e12ddd391432/680x482cq70/ungkep-ayam-goreng-bumbu-rempah-foto-resep-utama.jpg
author: Claudia Perry
ratingvalue: 3.6
reviewcount: 12
recipeingredient:
- "1 ekor ayam potong 8 bagian"
- "1 buah jeruk nipis"
- "1/2 sdm garam"
- "500 ml air kelapa aku ganti dg 65 ml santan instan  400 ml air"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "2 sdm air asam jawa"
- "2-3 sdt garam"
- " Bumbu halus"
- "1 bonggol lengkuas"
- "3 batang serai ambil bagian putihnya"
- "1/2 cm jahe"
- "3 cm kunyit"
- "1 sdm ketumbar sangrai"
- "5 butir kemiri sangrai"
- "6 siung bawang merah"
- "4 siung bawang putih"
recipeinstructions:
- "Siapkan ayam, remas dengan garam dan air perasan jeruk nipis. Diamkan 15 menit lalu cuci bersih."
- "Haluskan semua bumbu."
- "Siapkan wajan. Masukan potongan ayam dan beri bumbu halus, remas dan aduk ayam bersama bumbu. Diamkan selama 15 menit."
- "Tuangkan santan instan dan 400 ml air kedalam wajan, tuang semua bumbu lainnya. Kemudian rebus ayam dengan api sedang. Aduk sesekali masak hingga matang, air habis dan kering. *tambahkan air jika ayam belum matang."
- "Goreng ayam atau bisa sebagai stok lauk dikulkas pindahkan dalam wadah kedap udara utk disimpan."
categories:
- Resep
tags:
- ungkep
- ayam
- goreng

katakunci: ungkep ayam goreng 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Lunch

---


![Ungkep ayam goreng bumbu rempah](https://img-global.cpcdn.com/recipes/9d63e12ddd391432/680x482cq70/ungkep-ayam-goreng-bumbu-rempah-foto-resep-utama.jpg)

Andai anda seorang istri, menyajikan santapan menggugah selera bagi orang tercinta adalah hal yang menyenangkan untuk anda sendiri. Peran seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib memastikan keperluan nutrisi terpenuhi dan juga panganan yang disantap anak-anak harus menggugah selera.

Di zaman  saat ini, kamu memang bisa memesan olahan instan meski tanpa harus ribet mengolahnya terlebih dahulu. Namun ada juga mereka yang memang mau menyajikan yang terenak untuk orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan orang tercinta. 



Mungkinkah anda salah satu penikmat ungkep ayam goreng bumbu rempah?. Tahukah kamu, ungkep ayam goreng bumbu rempah adalah makanan khas di Nusantara yang kini disenangi oleh banyak orang dari hampir setiap daerah di Nusantara. Kamu dapat menghidangkan ungkep ayam goreng bumbu rempah sendiri di rumah dan boleh jadi camilan favorit di hari libur.

Kamu tak perlu bingung untuk mendapatkan ungkep ayam goreng bumbu rempah, lantaran ungkep ayam goreng bumbu rempah tidak sulit untuk dicari dan anda pun bisa mengolahnya sendiri di tempatmu. ungkep ayam goreng bumbu rempah bisa dimasak dengan beraneka cara. Kini pun sudah banyak resep modern yang menjadikan ungkep ayam goreng bumbu rempah semakin mantap.

Resep ungkep ayam goreng bumbu rempah pun sangat mudah untuk dibikin, lho. Kalian tidak usah ribet-ribet untuk memesan ungkep ayam goreng bumbu rempah, tetapi Kamu mampu menghidangkan di rumahmu. Untuk Kalian yang akan membuatnya, di bawah ini adalah cara menyajikan ungkep ayam goreng bumbu rempah yang nikamat yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ungkep ayam goreng bumbu rempah:

1. Siapkan 1 ekor ayam, potong 8 bagian
1. Sediakan 1 buah jeruk nipis
1. Siapkan 1/2 sdm garam
1. Sediakan 500 ml air kelapa *aku ganti dg 65 ml santan instan + 400 ml air
1. Gunakan 3 lembar daun salam
1. Gunakan 3 lembar daun jeruk
1. Gunakan 2 sdm air asam jawa
1. Ambil 2-3 sdt garam
1. Sediakan  Bumbu halus
1. Gunakan 1 bonggol lengkuas
1. Gunakan 3 batang serai, ambil bagian putihnya
1. Ambil 1/2 cm jahe
1. Gunakan 3 cm kunyit
1. Gunakan 1 sdm ketumbar, sangrai
1. Ambil 5 butir kemiri, sangrai
1. Gunakan 6 siung bawang merah
1. Sediakan 4 siung bawang putih




<!--inarticleads2-->

##### Cara membuat Ungkep ayam goreng bumbu rempah:

1. Siapkan ayam, remas dengan garam dan air perasan jeruk nipis. Diamkan 15 menit lalu cuci bersih.
1. Haluskan semua bumbu.
1. Siapkan wajan. Masukan potongan ayam dan beri bumbu halus, remas dan aduk ayam bersama bumbu. Diamkan selama 15 menit.
1. Tuangkan santan instan dan 400 ml air kedalam wajan, tuang semua bumbu lainnya. Kemudian rebus ayam dengan api sedang. Aduk sesekali masak hingga matang, air habis dan kering. *tambahkan air jika ayam belum matang.
1. Goreng ayam atau bisa sebagai stok lauk dikulkas pindahkan dalam wadah kedap udara utk disimpan.




Ternyata resep ungkep ayam goreng bumbu rempah yang nikamt simple ini enteng sekali ya! Kita semua mampu menghidangkannya. Cara Membuat ungkep ayam goreng bumbu rempah Sangat cocok banget untuk kalian yang baru belajar memasak maupun bagi anda yang sudah hebat memasak.

Apakah kamu ingin mencoba bikin resep ungkep ayam goreng bumbu rempah nikmat tidak rumit ini? Kalau kamu mau, yuk kita segera siapin peralatan dan bahan-bahannya, lalu bikin deh Resep ungkep ayam goreng bumbu rempah yang nikmat dan simple ini. Sungguh gampang kan. 

Maka dari itu, daripada anda diam saja, yuk langsung aja hidangkan resep ungkep ayam goreng bumbu rempah ini. Dijamin kamu tiidak akan nyesel sudah membuat resep ungkep ayam goreng bumbu rempah lezat tidak ribet ini! Selamat mencoba dengan resep ungkep ayam goreng bumbu rempah enak sederhana ini di rumah kalian masing-masing,oke!.

