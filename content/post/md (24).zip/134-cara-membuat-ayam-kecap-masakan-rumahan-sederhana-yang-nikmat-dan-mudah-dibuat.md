---
description: "Cara membuat Ayam kecap (masakan rumahan sederhana) yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam kecap (masakan rumahan sederhana) yang nikmat dan Mudah Dibuat"
slug: 134-cara-membuat-ayam-kecap-masakan-rumahan-sederhana-yang-nikmat-dan-mudah-dibuat
date: 2021-06-14T20:28:27.642Z
image: https://img-global.cpcdn.com/recipes/08f99ed5717b6803/680x482cq70/ayam-kecap-masakan-rumahan-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/08f99ed5717b6803/680x482cq70/ayam-kecap-masakan-rumahan-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/08f99ed5717b6803/680x482cq70/ayam-kecap-masakan-rumahan-sederhana-foto-resep-utama.jpg
author: Don Ramirez
ratingvalue: 4.4
reviewcount: 13
recipeingredient:
- "1/2 kg ayam potong menjadi beberapa bagian"
- " Minyak goreng"
- " air bersih"
- " Bumbu A "
- "4 siung bawang merah"
- "3 siung bawang putih"
- "1 sdt ketumbar"
- "1 sdt merica"
- "1 buah kemiri"
- " Bumbu B "
- "3 sdm makan gula merah yg telah disisir"
- "2 sdm kecap manis"
- " Royco"
- " Rempah "
- "2 ruas lengkuas geprek"
- "1 batang serai memarkan"
- "2 helai daun salam"
- "Sedikit asam jawa"
recipeinstructions:
- "Goreng setengah matang ayam, tiriskan (supaya bumbu menyerap sampai ke dalam daging dan tekstur daging lembut)"
- "Ulek halus bawang2, merica dan ketumbar. Lalu oseng bumbu dengan menggunakan 4 sdm minyak goreng"
- "Masukkan lengkuas, salam dan serai. Oseng bumbu sampai harum"
- "Setelah bumbu harum, tambahkan 3 gelas air putih bersih. Tunggu mendidih sambil di aduk"
- "Setelah mendidih, masukkan ayam. Tambahkan juga gula merah dan royco juga asam jawa"
- "Aduk lagi lalu tutup wajan supaya ayamnya makin empuk dan aroma mya tidak kabur. Kecilkan nyala api nya."
- "Setelah 5 menit, balikkan ayam agar bumbu nya merata ke bagian ayam yang lain."
- "Koreksi rasa lalu tambahkan kecap. tunggu sampai air nya surut"
- "Ketika air nya surut dan mengental, aduk sebentar. Lalu matikan kompor dan ayam kecap siap di nikmati ^^"
categories:
- Resep
tags:
- ayam
- kecap
- masakan

katakunci: ayam kecap masakan 
nutrition: 201 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam kecap (masakan rumahan sederhana)](https://img-global.cpcdn.com/recipes/08f99ed5717b6803/680x482cq70/ayam-kecap-masakan-rumahan-sederhana-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyajikan masakan menggugah selera kepada keluarga merupakan suatu hal yang sangat menyenangkan bagi kita sendiri. Peran seorang istri Tidak sekadar mengerjakan pekerjaan rumah saja, tapi anda juga wajib memastikan kebutuhan nutrisi tercukupi dan hidangan yang dikonsumsi anak-anak harus lezat.

Di era  saat ini, kamu memang bisa memesan hidangan jadi meski tanpa harus ribet membuatnya lebih dulu. Tapi ada juga orang yang selalu ingin memberikan makanan yang terlezat bagi orang yang dicintainya. Karena, memasak sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga. 



Mungkinkah anda seorang penikmat ayam kecap (masakan rumahan sederhana)?. Tahukah kamu, ayam kecap (masakan rumahan sederhana) adalah sajian khas di Indonesia yang sekarang disukai oleh orang-orang di hampir setiap wilayah di Nusantara. Kamu bisa membuat ayam kecap (masakan rumahan sederhana) sendiri di rumahmu dan dapat dijadikan camilan favoritmu di akhir pekanmu.

Kalian tidak perlu bingung jika kamu ingin menyantap ayam kecap (masakan rumahan sederhana), sebab ayam kecap (masakan rumahan sederhana) gampang untuk didapatkan dan kalian pun dapat membuatnya sendiri di rumah. ayam kecap (masakan rumahan sederhana) bisa dimasak lewat beraneka cara. Kini pun ada banyak sekali resep modern yang membuat ayam kecap (masakan rumahan sederhana) semakin lebih nikmat.

Resep ayam kecap (masakan rumahan sederhana) juga sangat gampang dihidangkan, lho. Kamu jangan repot-repot untuk membeli ayam kecap (masakan rumahan sederhana), lantaran Kita mampu menghidangkan di rumah sendiri. Bagi Kamu yang ingin menyajikannya, inilah resep menyajikan ayam kecap (masakan rumahan sederhana) yang mantab yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam kecap (masakan rumahan sederhana):

1. Siapkan 1/2 kg ayam (potong menjadi beberapa bagian)
1. Siapkan  Minyak goreng
1. Sediakan  air bersih
1. Sediakan  Bumbu A :
1. Sediakan 4 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Gunakan 1 sdt ketumbar
1. Ambil 1 sdt merica
1. Ambil 1 buah kemiri
1. Gunakan  Bumbu B :
1. Sediakan 3 sdm makan gula merah yg telah disisir
1. Sediakan 2 sdm kecap manis
1. Gunakan  Royco
1. Ambil  Rempah :
1. Gunakan 2 ruas lengkuas (geprek)
1. Gunakan 1 batang serai (memarkan)
1. Sediakan 2 helai daun salam
1. Sediakan Sedikit asam jawa




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kecap (masakan rumahan sederhana):

1. Goreng setengah matang ayam, tiriskan (supaya bumbu menyerap sampai ke dalam daging dan tekstur daging lembut)
1. Ulek halus bawang2, merica dan ketumbar. Lalu oseng bumbu dengan menggunakan 4 sdm minyak goreng
1. Masukkan lengkuas, salam dan serai. Oseng bumbu sampai harum
1. Setelah bumbu harum, tambahkan 3 gelas air putih bersih. Tunggu mendidih sambil di aduk
1. Setelah mendidih, masukkan ayam. Tambahkan juga gula merah dan royco juga asam jawa
1. Aduk lagi lalu tutup wajan supaya ayamnya makin empuk dan aroma mya tidak kabur. Kecilkan nyala api nya.
1. Setelah 5 menit, balikkan ayam agar bumbu nya merata ke bagian ayam yang lain.
1. Koreksi rasa lalu tambahkan kecap. tunggu sampai air nya surut
1. Ketika air nya surut dan mengental, aduk sebentar. Lalu matikan kompor dan ayam kecap siap di nikmati ^^




Ternyata cara buat ayam kecap (masakan rumahan sederhana) yang enak simple ini mudah sekali ya! Semua orang bisa membuatnya. Resep ayam kecap (masakan rumahan sederhana) Sangat sesuai banget untuk kita yang baru akan belajar memasak maupun juga untuk kalian yang sudah jago dalam memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam kecap (masakan rumahan sederhana) enak tidak rumit ini? Kalau kamu mau, ayo kamu segera buruan siapin alat-alat dan bahan-bahannya, lalu buat deh Resep ayam kecap (masakan rumahan sederhana) yang enak dan tidak rumit ini. Sangat taidak sulit kan. 

Maka dari itu, daripada kamu berlama-lama, hayo kita langsung saja sajikan resep ayam kecap (masakan rumahan sederhana) ini. Pasti anda tak akan nyesel membuat resep ayam kecap (masakan rumahan sederhana) mantab sederhana ini! Selamat berkreasi dengan resep ayam kecap (masakan rumahan sederhana) mantab sederhana ini di rumah masing-masing,ya!.

