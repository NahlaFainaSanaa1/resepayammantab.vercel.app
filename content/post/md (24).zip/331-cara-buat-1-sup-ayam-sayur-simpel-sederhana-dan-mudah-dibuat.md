---
description: "Cara buat #1 Sup Ayam Sayur Simpel Sederhana dan Mudah Dibuat"
title: "Cara buat #1 Sup Ayam Sayur Simpel Sederhana dan Mudah Dibuat"
slug: 331-cara-buat-1-sup-ayam-sayur-simpel-sederhana-dan-mudah-dibuat
date: 2021-05-02T06:48:10.983Z
image: https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg
author: Landon Rivera
ratingvalue: 4.8
reviewcount: 6
recipeingredient:
- " Isi Sup"
- "1 buah wortel irisiris"
- "12 buah buncis potong memanjang"
- "2 buah kentang kecil kalau besar 1 aja potong dadu"
- "potong dadu Daging dada ayam secukupnya"
- " Kol  dibuka lembarannya robek sebesar selera masing2"
- " Bawang putih 8 siung kalau ga suka boleh kurangi"
- "1,5 L Air"
- " Bumbu"
- " Daun bawang"
- "sesuai selera Garam"
- "sesuai selera Lada"
- " Royco ayam sesuai selera ga pakai juga ok"
- " Opsional"
- "Iris bawang merah dan buat bawang goreng makin enak"
recipeinstructions:
- "Siapkan semua bahan dulu."
- "Didihkan air di panci."
- "Masukan potongan ayam, rebus hingga putih dan mulai matang sekitar 2-3 menit."
- "Masukkan bawang putih, kentang, dan wortel. Biarkan sekitar 5-8 menit."
- "Masukkan buncis dan ketika terlihat sudah mulai matang (agak mengembang dan mengambang), masukkan kol."
- "Tambahkan garam sampai asinnya pas."
- "Masukkan daun bawang, aduk sebentar sekitar 30 detik, lalu matikan kompor."
- "Masukkan Royco dan lada di sendok sayur, cairkan dengan sedikit air di panci lalu aduk merata di sup."
- "Siap disajikan dengan bawang goreng, resep menyusul."
categories:
- Resep
tags:
- 1
- sup
- ayam

katakunci: 1 sup ayam 
nutrition: 208 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dessert

---


![#1 Sup Ayam Sayur Simpel](https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg)

Jika anda seorang orang tua, mempersiapkan olahan sedap kepada orang tercinta adalah suatu hal yang memuaskan untuk kita sendiri. Kewajiban seorang istri Tidak sekadar menjaga rumah saja, tetapi anda juga harus menyediakan kebutuhan gizi terpenuhi dan masakan yang dikonsumsi keluarga tercinta mesti lezat.

Di zaman  sekarang, kita sebenarnya mampu membeli santapan instan meski tanpa harus susah memasaknya dulu. Tapi banyak juga lho orang yang selalu mau memberikan yang terlezat bagi orang tercintanya. Lantaran, memasak yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai masakan kesukaan famili. 



Apakah anda adalah salah satu penggemar #1 sup ayam sayur simpel?. Tahukah kamu, #1 sup ayam sayur simpel merupakan sajian khas di Nusantara yang saat ini disukai oleh banyak orang di hampir setiap daerah di Indonesia. Kita dapat memasak #1 sup ayam sayur simpel hasil sendiri di rumah dan boleh dijadikan santapan favoritmu di hari libur.

Kita tak perlu bingung untuk mendapatkan #1 sup ayam sayur simpel, karena #1 sup ayam sayur simpel mudah untuk ditemukan dan kamu pun dapat mengolahnya sendiri di rumah. #1 sup ayam sayur simpel boleh dimasak lewat beragam cara. Saat ini sudah banyak resep kekinian yang membuat #1 sup ayam sayur simpel semakin lebih lezat.

Resep #1 sup ayam sayur simpel juga gampang sekali dibuat, lho. Kita jangan capek-capek untuk membeli #1 sup ayam sayur simpel, lantaran Kalian dapat menyiapkan di rumah sendiri. Bagi Anda yang hendak mencobanya, dibawah ini merupakan cara untuk membuat #1 sup ayam sayur simpel yang nikamat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan #1 Sup Ayam Sayur Simpel:

1. Ambil  Isi Sup
1. Gunakan 1 buah wortel, iris-iris
1. Gunakan 12 buah buncis, potong memanjang
1. Ambil 2 buah kentang kecil (kalau besar 1 aja), potong dadu
1. Sediakan potong dadu Daging dada ayam secukupnya,
1. Ambil  Kol ¼, dibuka lembarannya, robek sebesar selera masing2
1. Siapkan  Bawang putih 8 siung (kalau ga suka boleh kurangi)
1. Ambil 1,5 L Air
1. Sediakan  Bumbu
1. Ambil  Daun bawang
1. Siapkan sesuai selera Garam
1. Ambil sesuai selera Lada
1. Sediakan  Royco ayam sesuai selera, ga pakai juga ok
1. Ambil  Opsional
1. Gunakan Iris bawang merah dan buat bawang goreng, makin enak




<!--inarticleads2-->

##### Langkah-langkah menyiapkan #1 Sup Ayam Sayur Simpel:

1. Siapkan semua bahan dulu.
1. Didihkan air di panci.
1. Masukan potongan ayam, rebus hingga putih dan mulai matang sekitar 2-3 menit.
1. Masukkan bawang putih, kentang, dan wortel. Biarkan sekitar 5-8 menit.
1. Masukkan buncis dan ketika terlihat sudah mulai matang (agak mengembang dan mengambang), masukkan kol.
1. Tambahkan garam sampai asinnya pas.
1. Masukkan daun bawang, aduk sebentar sekitar 30 detik, lalu matikan kompor.
1. Masukkan Royco dan lada di sendok sayur, cairkan dengan sedikit air di panci lalu aduk merata di sup.
1. Siap disajikan dengan bawang goreng, resep menyusul.




Wah ternyata cara buat #1 sup ayam sayur simpel yang lezat tidak ribet ini mudah banget ya! Kamu semua dapat menghidangkannya. Cara buat #1 sup ayam sayur simpel Sesuai sekali untuk kalian yang sedang belajar memasak maupun juga bagi kalian yang sudah ahli memasak.

Apakah kamu mau mulai mencoba membikin resep #1 sup ayam sayur simpel mantab tidak rumit ini? Kalau anda ingin, mending kamu segera buruan siapkan alat dan bahan-bahannya, kemudian bikin deh Resep #1 sup ayam sayur simpel yang nikmat dan tidak ribet ini. Sangat mudah kan. 

Jadi, daripada kita berlama-lama, maka langsung aja hidangkan resep #1 sup ayam sayur simpel ini. Dijamin kamu tak akan nyesel bikin resep #1 sup ayam sayur simpel enak tidak rumit ini! Selamat berkreasi dengan resep #1 sup ayam sayur simpel mantab sederhana ini di rumah kalian masing-masing,oke!.

