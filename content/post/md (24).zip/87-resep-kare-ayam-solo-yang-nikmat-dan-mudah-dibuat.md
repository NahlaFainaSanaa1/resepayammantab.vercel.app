---
description: "Resep Kare Ayam Solo yang nikmat dan Mudah Dibuat"
title: "Resep Kare Ayam Solo yang nikmat dan Mudah Dibuat"
slug: 87-resep-kare-ayam-solo-yang-nikmat-dan-mudah-dibuat
date: 2021-03-28T20:50:19.681Z
image: https://img-global.cpcdn.com/recipes/2c03d5469091e736/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2c03d5469091e736/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2c03d5469091e736/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Erik Edwards
ratingvalue: 4.5
reviewcount: 8
recipeingredient:
- "1/2 kg daging ayampotong"
- "1 lmbr daun salam"
- "3 lmbr daun jerukbuang tulang tengahnyasobek"
- "1 jempol lengkuasgeprek"
- "1 btng seraigeprek"
- "1 liter air"
- "1 sachet santan instan 65 ml"
- "1 sdt munjung gula pasir"
- "1/2 sdt kaldu bubuk"
- "secukupnya garam"
- "secukupnya minyak goreng"
- " Bumbu halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "2 cm kunyit"
- "1 sdt ketumbar bubuk"
- "1/4 sdt lada bubuk"
- "1/4 sdt jinten sy skip"
- "2 cm jahe tambahan sy"
- " Pelengkap "
- "2 bh wortelpotongrebus"
- "1 mangkuk taugeseduh dengan air panas"
- "1 btng daun bawangiris halus"
- "2 sdm bawang merah goreng"
recipeinstructions:
- "Cuci bersih ayam,lumuri garam,diamkan 10 menit,bilas kembali. Lalu rebus dlm air mendidih sampai berubah warna saja,angkat &amp; tiriskan. Buang air rebusannya."
- "Panaskan minyak goreng,tumis bumbu halus sampai matang &amp; harum,tambahkan serai,lengkuas,daun salam &amp; daun jeruk,aduk rata. Masukkan juga ayam yg telah direbus,aduk rata."
- "Tuang air,didihkan. Bumbui garam,gula pasir &amp; kaldu bubuk. Masukkan santan instan,aduk kembali sampai mendidih. Masak sampai ayam empuk &amp; bumbu menyatu. Jgn lupa koreksi rasanya."
- "Siapkan bahan pelengkapnya."
- "Tata sayuran di piring saji,masukkan potongan ayam,siram dgn kuah,taburi bawang goreng &amp; sajikan."
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 276 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dessert

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/2c03d5469091e736/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan santapan mantab kepada famili merupakan hal yang membahagiakan untuk kita sendiri. Kewajiban seorang istri bukan sekadar menangani rumah saja, tetapi anda juga wajib memastikan kebutuhan gizi tercukupi dan hidangan yang dikonsumsi keluarga tercinta mesti mantab.

Di waktu  saat ini, kalian memang dapat memesan olahan jadi meski tidak harus capek memasaknya dulu. Namun ada juga lho orang yang selalu ingin menghidangkan yang terenak bagi orang yang dicintainya. Lantaran, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan selera orang tercinta. 



Mungkinkah kamu seorang penggemar kare ayam solo?. Tahukah kamu, kare ayam solo adalah hidangan khas di Indonesia yang kini digemari oleh kebanyakan orang dari berbagai wilayah di Indonesia. Kalian dapat menghidangkan kare ayam solo sendiri di rumah dan dapat dijadikan camilan favorit di hari libur.

Kamu tidak perlu bingung untuk mendapatkan kare ayam solo, karena kare ayam solo mudah untuk dicari dan anda pun bisa memasaknya sendiri di rumah. kare ayam solo dapat diolah dengan bermacam cara. Kini pun sudah banyak banget resep kekinian yang membuat kare ayam solo lebih enak.

Resep kare ayam solo pun sangat mudah untuk dibuat, lho. Kita jangan ribet-ribet untuk membeli kare ayam solo, lantaran Anda dapat menyajikan di rumah sendiri. Untuk Kita yang ingin menyajikannya, berikut ini cara membuat kare ayam solo yang enak yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Kare Ayam Solo:

1. Gunakan 1/2 kg daging ayam,potong²
1. Sediakan 1 lmbr daun salam
1. Ambil 3 lmbr daun jeruk,buang tulang tengahnya,sobek²
1. Sediakan 1 jempol lengkuas,geprek
1. Gunakan 1 btng serai,geprek
1. Siapkan 1 liter air
1. Ambil 1 sachet santan instan (65 ml)
1. Ambil 1 sdt munjung gula pasir
1. Ambil 1/2 sdt kaldu bubuk
1. Gunakan secukupnya garam
1. Ambil secukupnya minyak goreng
1. Gunakan  Bumbu halus :
1. Gunakan 5 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Siapkan 3 butir kemiri
1. Ambil 2 cm kunyit
1. Gunakan 1 sdt ketumbar bubuk
1. Gunakan 1/4 sdt lada bubuk
1. Sediakan 1/4 sdt jinten (sy skip)
1. Gunakan 2 cm jahe (tambahan sy)
1. Siapkan  Pelengkap :
1. Ambil 2 bh wortel,potong²,rebus
1. Siapkan 1 mangkuk tauge,seduh dengan air panas
1. Ambil 1 btng daun bawang,iris halus
1. Siapkan 2 sdm bawang merah goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Kare Ayam Solo:

1. Cuci bersih ayam,lumuri garam,diamkan 10 menit,bilas kembali. Lalu rebus dlm air mendidih sampai berubah warna saja,angkat &amp; tiriskan. Buang air rebusannya.
1. Panaskan minyak goreng,tumis bumbu halus sampai matang &amp; harum,tambahkan serai,lengkuas,daun salam &amp; daun jeruk,aduk rata. Masukkan juga ayam yg telah direbus,aduk rata.
1. Tuang air,didihkan. Bumbui garam,gula pasir &amp; kaldu bubuk. Masukkan santan instan,aduk kembali sampai mendidih. Masak sampai ayam empuk &amp; bumbu menyatu. Jgn lupa koreksi rasanya.
1. Siapkan bahan pelengkapnya.
1. Tata sayuran di piring saji,masukkan potongan ayam,siram dgn kuah,taburi bawang goreng &amp; sajikan.




Ternyata resep kare ayam solo yang lezat tidak ribet ini gampang sekali ya! Kalian semua mampu menghidangkannya. Cara buat kare ayam solo Sesuai banget untuk kita yang sedang belajar memasak maupun bagi kamu yang telah jago dalam memasak.

Tertarik untuk mulai mencoba bikin resep kare ayam solo mantab sederhana ini? Kalau anda ingin, mending kamu segera buruan menyiapkan alat dan bahannya, lalu buat deh Resep kare ayam solo yang mantab dan tidak rumit ini. Betul-betul mudah kan. 

Jadi, ketimbang kamu diam saja, yuk langsung aja bikin resep kare ayam solo ini. Pasti kamu gak akan nyesel bikin resep kare ayam solo enak sederhana ini! Selamat mencoba dengan resep kare ayam solo enak sederhana ini di tempat tinggal sendiri,ya!.

