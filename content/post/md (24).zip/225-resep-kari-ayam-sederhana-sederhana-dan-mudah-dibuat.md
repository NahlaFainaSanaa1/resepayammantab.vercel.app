---
description: "Resep Kari Ayam Sederhana Sederhana dan Mudah Dibuat"
title: "Resep Kari Ayam Sederhana Sederhana dan Mudah Dibuat"
slug: 225-resep-kari-ayam-sederhana-sederhana-dan-mudah-dibuat
date: 2021-03-19T10:39:00.411Z
image: https://img-global.cpcdn.com/recipes/2bfe508fbc17cd24/680x482cq70/kari-ayam-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2bfe508fbc17cd24/680x482cq70/kari-ayam-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2bfe508fbc17cd24/680x482cq70/kari-ayam-sederhana-foto-resep-utama.jpg
author: Chester Stephens
ratingvalue: 5
reviewcount: 6
recipeingredient:
- "900 gr ayam kampung potong kecil2"
- "10 butir bawang merah"
- "5 butir bawang putih"
- "4 butir kemiri"
- "2 ruas jari lengkuas digeprek"
- "2 ruas jari jahe digeprek"
- "3 ruas jari kunyit"
- "3 batang sereh digeprek"
- "5 lbr daun jeruk"
- "3 lbr daun salam"
- "5 cabe merah besar"
- "5 cabe rawit selera ya bunda"
- "2 santan kara 60ml"
- "1 sdt ketumbar"
- "1/2 sdt merica butiran"
- "1/2 sdt jinten"
- "3000 ml air"
- "secukupnya Garam gula dan kayu manis"
recipeinstructions:
- "Bersihkan ayam dan potong agak kecil2."
- "Didihkan air, masukkan ayam beserta jahe dan lengkuas"
- "Sambil menunggu ayam empuk, haluskan Bamer, baput, merica, ketumbar, jinten, cabe merah, cabe rawit dan kemiri."
- "Panaskan minyak, tumis bumbu halus dan masukkan daun jeruk dan daun salam"
- "Setelah bumbu matang, masukkan ke dalam rebusan ayam lalu dan tuangi santan sambil terus diaduk agar santan tidak pecah. Koreksi rasa, jika sudah mendidih. Angkat."
categories:
- Resep
tags:
- kari
- ayam
- sederhana

katakunci: kari ayam sederhana 
nutrition: 253 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Kari Ayam Sederhana](https://img-global.cpcdn.com/recipes/2bfe508fbc17cd24/680x482cq70/kari-ayam-sederhana-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan panganan nikmat kepada orang tercinta merupakan suatu hal yang sangat menyenangkan bagi anda sendiri. Tanggung jawab seorang  wanita Tidak sekadar mengatur rumah saja, tapi kamu pun harus memastikan kebutuhan nutrisi terpenuhi dan juga santapan yang dimakan keluarga tercinta mesti nikmat.

Di zaman  saat ini, anda sebenarnya dapat memesan panganan yang sudah jadi tanpa harus repot mengolahnya lebih dulu. Tetapi ada juga lho mereka yang selalu ingin menghidangkan yang terenak untuk keluarganya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan orang tercinta. 



Mungkinkah anda merupakan salah satu penikmat kari ayam sederhana?. Asal kamu tahu, kari ayam sederhana merupakan sajian khas di Indonesia yang saat ini disukai oleh setiap orang di berbagai tempat di Indonesia. Kalian dapat menyajikan kari ayam sederhana hasil sendiri di rumah dan dapat dijadikan santapan favorit di hari liburmu.

Kalian tidak perlu bingung jika kamu ingin mendapatkan kari ayam sederhana, karena kari ayam sederhana mudah untuk ditemukan dan juga kalian pun boleh mengolahnya sendiri di rumah. kari ayam sederhana boleh diolah dengan berbagai cara. Kini ada banyak resep modern yang membuat kari ayam sederhana lebih enak.

Resep kari ayam sederhana pun sangat mudah untuk dibuat, lho. Anda tidak usah ribet-ribet untuk memesan kari ayam sederhana, lantaran Kamu mampu membuatnya di rumahmu. Bagi Kalian yang ingin menghidangkannya, berikut resep membuat kari ayam sederhana yang enak yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Kari Ayam Sederhana:

1. Siapkan 900 gr ayam kampung, potong kecil2
1. Sediakan 10 butir bawang merah
1. Sediakan 5 butir bawang putih
1. Sediakan 4 butir kemiri
1. Ambil 2 ruas jari lengkuas, digeprek
1. Siapkan 2 ruas jari jahe, digeprek
1. Siapkan 3 ruas jari kunyit
1. Siapkan 3 batang sereh, digeprek
1. Sediakan 5 lbr daun jeruk
1. Ambil 3 lbr daun salam
1. Sediakan 5 cabe merah besar
1. Ambil 5 cabe rawit (selera ya bunda)
1. Ambil 2 santan kara 60ml
1. Ambil 1 sdt ketumbar
1. Ambil 1/2 sdt merica butiran
1. Ambil 1/2 sdt jinten
1. Gunakan 3000 ml air
1. Gunakan secukupnya Garam, gula dan kayu manis




<!--inarticleads2-->

##### Cara menyiapkan Kari Ayam Sederhana:

1. Bersihkan ayam dan potong agak kecil2.
1. Didihkan air, masukkan ayam beserta jahe dan lengkuas
1. Sambil menunggu ayam empuk, haluskan Bamer, baput, merica, ketumbar, jinten, cabe merah, cabe rawit dan kemiri.
1. Panaskan minyak, tumis bumbu halus dan masukkan daun jeruk dan daun salam
1. Setelah bumbu matang, masukkan ke dalam rebusan ayam lalu dan tuangi santan sambil terus diaduk agar santan tidak pecah. Koreksi rasa, jika sudah mendidih. Angkat.




Wah ternyata cara membuat kari ayam sederhana yang enak simple ini enteng banget ya! Kalian semua bisa membuatnya. Cara buat kari ayam sederhana Sangat cocok banget untuk kalian yang baru belajar memasak ataupun juga untuk anda yang telah hebat dalam memasak.

Apakah kamu ingin mencoba membuat resep kari ayam sederhana mantab tidak rumit ini? Kalau tertarik, ayo kalian segera siapin peralatan dan bahannya, lantas bikin deh Resep kari ayam sederhana yang nikmat dan tidak ribet ini. Sungguh mudah kan. 

Oleh karena itu, daripada kalian diam saja, hayo kita langsung saja bikin resep kari ayam sederhana ini. Pasti anda gak akan menyesal membuat resep kari ayam sederhana lezat tidak rumit ini! Selamat mencoba dengan resep kari ayam sederhana mantab simple ini di tempat tinggal masing-masing,ya!.

