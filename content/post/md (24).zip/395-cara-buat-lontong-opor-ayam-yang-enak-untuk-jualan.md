---
description: "Cara buat Lontong Opor Ayam yang enak Untuk Jualan"
title: "Cara buat Lontong Opor Ayam yang enak Untuk Jualan"
slug: 395-cara-buat-lontong-opor-ayam-yang-enak-untuk-jualan
date: 2021-04-05T16:06:54.816Z
image: https://img-global.cpcdn.com/recipes/b8d01768f013f25f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b8d01768f013f25f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b8d01768f013f25f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
author: Lura Harrington
ratingvalue: 3.6
reviewcount: 15
recipeingredient:
- " Bahan Opor Ayam"
- "1 ekor ayam ukuran 1 kg"
- "8 butir telur ayam"
- "100 ml santan kental pasta santan"
- " Bumbu Opor ayam"
- "1 bungkus bumbu opor ayam putih dari bamboo"
- "3 butir kemiri"
- "1/2 buah bawang bombai merah"
- "3 butir bawang putih"
- "1 batang serai"
- "2 cm lengkuas"
- "4 lembar daun salam"
- "4 lembar daun jeruk buang tulang daunnya"
- "1 sdt ketumbar bubuk"
- "1/2 sdt kunyit bubuk"
- " Lontong Nasi"
- "8 cup beras"
- " Pelengkap"
- " Sambal teri"
- " Teri goreng dan kacang tanah goreng untuk anakanak"
- " Bawang merah goreng"
- " Kerupuk Udang"
recipeinstructions:
- "Cara membuat opor: -Haluskan bawang putih, bombai merah, dan kemiri lalu tumis dengan bumbu lainnya sampai harum."
- "Masukkan ayam yang sudah di potong menjadi 16 bagian, tumis dengan bumbu."
- "Dipanci lain didihkan air 1,5 liter. Setelah mendidih masukkan ayam berbumbu tadi, dan tambahkan santan aduk jangan sampai pecah santannya."
- "Masukkan telur rebus yang sudah di kupas masak sebentar saja asal mendidih lagi. Opor siap dinikmati."
- "Lontong: Cuci beras kemudian tiriskan. Masukkan beras kedalam plastik. Karena berasnya ga mekar jadi saya isi 1/2 lebih dikit. Kalau berasnya mekar di isi 1/2 sudah cukup. Masukkan kebanci dengam cara disusun berjejer lalu isi dengan air sampai terendam. Masak di api sedang sampai mendidih setelah mendidih kecilkan api sampai 4 jam. Saya merebusnya pakai pemenas ruangan karena sekalian menghabiskan sisa minyak tanah🤭."
- "Setelah lontong matang angkat dan tiriskan, ikatkan dengam kuat bagian kosong dengam cara diputar-putar agar lontong padat. Tata dengan posisi terbalik. Tunggu sampai dingin agar lontong menjadi padat. Setelah padat iris sesuai selera. Si lontong jadi padet dan lembut."
- "Penyajian: Tata lontong dibagian bawah piring, Beri bawang merah goreng tuang, ayam dan telur lalu tuang kuah opor. Tambahkan sambal teri dan kerupuk di atasnya. Nikmat😋😋."
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 156 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dinner

---


![Lontong Opor Ayam](https://img-global.cpcdn.com/recipes/b8d01768f013f25f/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg)

Andai anda seorang yang hobi memasak, menyediakan hidangan menggugah selera pada famili adalah suatu hal yang menggembirakan bagi anda sendiri. Tanggung jawab seorang istri bukan sekadar mengurus rumah saja, tapi kamu juga wajib memastikan keperluan nutrisi tercukupi dan juga santapan yang dimakan orang tercinta harus enak.

Di zaman  sekarang, kalian memang bisa mengorder santapan praktis tanpa harus susah memasaknya lebih dulu. Tetapi banyak juga lho orang yang memang ingin menghidangkan yang terbaik bagi orang tercintanya. Karena, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penikmat lontong opor ayam?. Asal kamu tahu, lontong opor ayam merupakan hidangan khas di Indonesia yang sekarang disenangi oleh kebanyakan orang di berbagai daerah di Nusantara. Kalian dapat menyajikan lontong opor ayam hasil sendiri di rumahmu dan pasti jadi hidangan favorit di hari liburmu.

Anda jangan bingung jika kamu ingin menyantap lontong opor ayam, karena lontong opor ayam tidak sulit untuk dicari dan anda pun bisa memasaknya sendiri di rumah. lontong opor ayam dapat diolah lewat bermacam cara. Sekarang sudah banyak banget resep modern yang membuat lontong opor ayam semakin lebih mantap.

Resep lontong opor ayam pun sangat gampang untuk dibikin, lho. Kamu tidak perlu capek-capek untuk membeli lontong opor ayam, tetapi Kalian mampu menyiapkan di rumahmu. Bagi Kamu yang hendak menghidangkannya, berikut cara menyajikan lontong opor ayam yang nikamat yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Lontong Opor Ayam:

1. Ambil  Bahan Opor Ayam
1. Gunakan 1 ekor ayam ukuran 1 kg
1. Sediakan 8 butir telur ayam
1. Sediakan 100 ml santan kental (pasta santan)
1. Siapkan  Bumbu Opor ayam
1. Gunakan 1 bungkus bumbu opor ayam putih dari bamboo
1. Ambil 3 butir kemiri
1. Sediakan 1/2 buah bawang bombai merah
1. Siapkan 3 butir bawang putih
1. Gunakan 1 batang serai
1. Gunakan 2 cm lengkuas
1. Sediakan 4 lembar daun salam
1. Sediakan 4 lembar daun jeruk buang tulang daunnya
1. Sediakan 1 sdt ketumbar bubuk
1. Ambil 1/2 sdt kunyit bubuk
1. Siapkan  Lontong Nasi
1. Siapkan 8 cup beras
1. Siapkan  Pelengkap:
1. Gunakan  Sambal teri
1. Sediakan  Teri goreng dan kacang tanah goreng untuk anak-anak
1. Gunakan  Bawang merah goreng
1. Gunakan  Kerupuk Udang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Lontong Opor Ayam:

1. Cara membuat opor: -Haluskan bawang putih, bombai merah, dan kemiri lalu tumis dengan bumbu lainnya sampai harum.
1. Masukkan ayam yang sudah di potong menjadi 16 bagian, tumis dengan bumbu.
1. Dipanci lain didihkan air 1,5 liter. Setelah mendidih masukkan ayam berbumbu tadi, dan tambahkan santan aduk jangan sampai pecah santannya.
1. Masukkan telur rebus yang sudah di kupas masak sebentar saja asal mendidih lagi. Opor siap dinikmati.
1. Lontong: Cuci beras kemudian tiriskan. Masukkan beras kedalam plastik. Karena berasnya ga mekar jadi saya isi 1/2 lebih dikit. Kalau berasnya mekar di isi 1/2 sudah cukup. Masukkan kebanci dengam cara disusun berjejer lalu isi dengan air sampai terendam. Masak di api sedang sampai mendidih setelah mendidih kecilkan api sampai 4 jam. Saya merebusnya pakai pemenas ruangan karena sekalian menghabiskan sisa minyak tanah🤭.
1. Setelah lontong matang angkat dan tiriskan, ikatkan dengam kuat bagian kosong dengam cara diputar-putar agar lontong padat. Tata dengan posisi terbalik. Tunggu sampai dingin agar lontong menjadi padat. Setelah padat iris sesuai selera. Si lontong jadi padet dan lembut.
1. Penyajian: Tata lontong dibagian bawah piring, Beri bawang merah goreng tuang, ayam dan telur lalu tuang kuah opor. Tambahkan sambal teri dan kerupuk di atasnya. Nikmat😋😋.




Ternyata resep lontong opor ayam yang enak simple ini enteng banget ya! Semua orang bisa menghidangkannya. Cara buat lontong opor ayam Sesuai banget buat kita yang baru belajar memasak atau juga untuk anda yang telah pandai memasak.

Tertarik untuk mulai mencoba buat resep lontong opor ayam lezat simple ini? Kalau mau, ayo kalian segera buruan menyiapkan alat dan bahannya, lalu buat deh Resep lontong opor ayam yang nikmat dan sederhana ini. Betul-betul mudah kan. 

Maka, ketimbang kita berfikir lama-lama, yuk kita langsung saja buat resep lontong opor ayam ini. Dijamin kalian tiidak akan menyesal bikin resep lontong opor ayam lezat sederhana ini! Selamat berkreasi dengan resep lontong opor ayam enak simple ini di rumah kalian sendiri,oke!.

