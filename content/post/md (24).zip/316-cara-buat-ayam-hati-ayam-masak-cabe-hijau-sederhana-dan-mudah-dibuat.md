---
description: "Cara buat Ayam + hati ayam masak cabe hijau Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam + hati ayam masak cabe hijau Sederhana dan Mudah Dibuat"
slug: 316-cara-buat-ayam-hati-ayam-masak-cabe-hijau-sederhana-dan-mudah-dibuat
date: 2021-06-12T08:41:41.002Z
image: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
author: Louise Lane
ratingvalue: 4.9
reviewcount: 8
recipeingredient:
- "1/2 ekor ayam"
- "3 hati ayam  ampela"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "8 cabe hijau besar bagusnya sih 15 cabe atau sesuai selera"
- "10 cabe rawit tergantung selera"
- "2 tomat merah ukuran sedang harus tomat hijau 34 buah"
- "2 batang serai geprek"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 lembar daun kunyit"
- "1 cm kunyit"
- "1 cm jahe"
- "1 cm lengkuas"
- "3 biji kemiri"
- "1/2 sdm ketumbar"
- "1/2 sdm merica"
- "2 asam gandis boleh pake air asam jawa"
- " Penyedap"
- " Gula"
- " Minyak goreng"
- " Air bersih"
recipeinstructions:
- "Bersihkan ayam dan jeroannya, lalu potong sesuai selera, saya rebus jeroannya dulu yah biar gak bau amis, bisa direbus langsung atau ditambah garam dan daun jeruk"
- "Haluskan bawang, jahe, lengkuas, kunyit, kemiri, tomat dan cabe lalu tumis hingga wangi lalu masukan serai, daun jeruk, daun salam tumis hingga mateng"
- "Masukan ayam dan jeroan, dan asam aduk hingga bumbu tercampur rata, lalu tambah air secukupnya, masak hingga air berkurang setengah tambahakn penyedap, garam, gula, ketumbar, merica (atau ini ditambah pas lagi numis bumbu juga gpp)"
- "Koreksi rasa, masak hingga matang dan daging ayam empuk, angkat dan sajikan dengan nasi hangat"
categories:
- Resep
tags:
- ayam
- 
- hati

katakunci: ayam  hati 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam + hati ayam masak cabe hijau](https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan panganan nikmat bagi keluarga merupakan hal yang sangat menyenangkan bagi anda sendiri. Tugas seorang  wanita Tidak sekedar mengatur rumah saja, tetapi anda pun wajib memastikan kebutuhan gizi tercukupi dan masakan yang dimakan anak-anak harus sedap.

Di era  saat ini, kita memang bisa membeli panganan jadi tidak harus susah mengolahnya lebih dulu. Tapi ada juga orang yang selalu mau menghidangkan yang terbaik untuk orang yang dicintainya. Pasalnya, memasak yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah kamu seorang penyuka ayam + hati ayam masak cabe hijau?. Asal kamu tahu, ayam + hati ayam masak cabe hijau adalah sajian khas di Indonesia yang kini disukai oleh kebanyakan orang di hampir setiap wilayah di Indonesia. Kalian dapat memasak ayam + hati ayam masak cabe hijau sendiri di rumah dan dapat dijadikan makanan kesenanganmu di akhir pekan.

Kalian tidak perlu bingung jika kamu ingin menyantap ayam + hati ayam masak cabe hijau, lantaran ayam + hati ayam masak cabe hijau tidak sukar untuk ditemukan dan juga kalian pun boleh menghidangkannya sendiri di rumah. ayam + hati ayam masak cabe hijau boleh dimasak memalui berbagai cara. Saat ini telah banyak sekali resep kekinian yang menjadikan ayam + hati ayam masak cabe hijau semakin enak.

Resep ayam + hati ayam masak cabe hijau juga sangat gampang dibuat, lho. Anda tidak perlu ribet-ribet untuk memesan ayam + hati ayam masak cabe hijau, karena Kamu dapat menghidangkan ditempatmu. Untuk Kita yang mau menyajikannya, berikut cara menyajikan ayam + hati ayam masak cabe hijau yang enak yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam + hati ayam masak cabe hijau:

1. Ambil 1/2 ekor ayam
1. Ambil 3 hati ayam + ampela
1. Siapkan 8 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Siapkan 8 cabe hijau besar (bagusnya sih 15 cabe atau sesuai selera)
1. Ambil 10 cabe rawit (tergantung selera)
1. Sediakan 2 tomat merah ukuran sedang (harus tomat hijau 3-4 buah)
1. Ambil 2 batang serai (geprek)
1. Gunakan 3 lembar daun salam
1. Gunakan 5 lembar daun jeruk
1. Sediakan 1 lembar daun kunyit
1. Sediakan 1 cm kunyit
1. Gunakan 1 cm jahe
1. Siapkan 1 cm lengkuas
1. Siapkan 3 biji kemiri
1. Sediakan 1/2 sdm ketumbar
1. Siapkan 1/2 sdm merica
1. Siapkan 2 asam gandis (boleh pake air asam jawa)
1. Ambil  Penyedap
1. Sediakan  Gula
1. Gunakan  Minyak goreng
1. Ambil  Air bersih




<!--inarticleads2-->

##### Cara membuat Ayam + hati ayam masak cabe hijau:

1. Bersihkan ayam dan jeroannya, lalu potong sesuai selera, saya rebus jeroannya dulu yah biar gak bau amis, bisa direbus langsung atau ditambah garam dan daun jeruk
1. Haluskan bawang, jahe, lengkuas, kunyit, kemiri, tomat dan cabe lalu tumis hingga wangi lalu masukan serai, daun jeruk, daun salam tumis hingga mateng
1. Masukan ayam dan jeroan, dan asam aduk hingga bumbu tercampur rata, lalu tambah air secukupnya, masak hingga air berkurang setengah tambahakn penyedap, garam, gula, ketumbar, merica (atau ini ditambah pas lagi numis bumbu juga gpp)
1. Koreksi rasa, masak hingga matang dan daging ayam empuk, angkat dan sajikan dengan nasi hangat




Ternyata cara membuat ayam + hati ayam masak cabe hijau yang mantab sederhana ini mudah banget ya! Semua orang dapat menghidangkannya. Cara buat ayam + hati ayam masak cabe hijau Sesuai banget untuk kalian yang baru akan belajar memasak maupun untuk anda yang sudah pandai memasak.

Tertarik untuk mulai mencoba membuat resep ayam + hati ayam masak cabe hijau lezat simple ini? Kalau anda tertarik, mending kamu segera menyiapkan alat-alat dan bahannya, kemudian buat deh Resep ayam + hati ayam masak cabe hijau yang nikmat dan simple ini. Benar-benar mudah kan. 

Maka dari itu, ketimbang kamu diam saja, maka kita langsung bikin resep ayam + hati ayam masak cabe hijau ini. Dijamin kalian gak akan nyesel bikin resep ayam + hati ayam masak cabe hijau mantab tidak ribet ini! Selamat mencoba dengan resep ayam + hati ayam masak cabe hijau nikmat simple ini di rumah kalian sendiri,ya!.

