---
description: "Cara membuat Lontong Opor Ayam Kampung Kuah Putih yang nikmat dan Mudah Dibuat"
title: "Cara membuat Lontong Opor Ayam Kampung Kuah Putih yang nikmat dan Mudah Dibuat"
slug: 389-cara-membuat-lontong-opor-ayam-kampung-kuah-putih-yang-nikmat-dan-mudah-dibuat
date: 2021-02-10T09:07:35.593Z
image: https://img-global.cpcdn.com/recipes/f0ecf9dada6b7d13/680x482cq70/lontong-opor-ayam-kampung-kuah-putih-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f0ecf9dada6b7d13/680x482cq70/lontong-opor-ayam-kampung-kuah-putih-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f0ecf9dada6b7d13/680x482cq70/lontong-opor-ayam-kampung-kuah-putih-foto-resep-utama.jpg
author: Louis Shaw
ratingvalue: 3
reviewcount: 14
recipeingredient:
- "1/2 ekor ayam kampung"
- "4 lbr daun salam"
- "3 cm lengkuas irisgeprek"
- "3 bh daun jeruk purut"
- "2 bh sereh geprek"
- "1 bh santan instan 65 ml"
- "Secukupnya Gula dan Garam"
- "Secukupnya Air"
- " Bumbu halus"
- "5 siung bawang putih"
- "3 siung bawang merah"
- "1/2 sdt ketumbar"
- "1/2 sdt merica sangrai"
- "3 bh kemiri sangrai"
- "1 cm jahe"
- "1 jumput jintan"
- " Bahan tambahan"
- " Bawang goreng"
- " Sambel kacang           lihat resep"
- " Kerupuk udang"
recipeinstructions:
- "Potong ayam kamlung, cuci bersih, blansir sampai kotoran hilang, lalu cuci kembali."
- "Siapkan bumbu opor, sangrai kemiri, merica dan ketumbar, haluskan bersama bumbu lainnya."
- "Tumis bumbu sampai harum dan matang, tambahkan air. Masukkan ayam rebus sampai air setengah susut. Tambahkan gula dan garam dan air santan, aduk-aduk sampai merata."
- "Masak ayam hingga matang dan empuk, taburi bawang goreng. Sajikan dengan lontong, sambel kacang (bisa lihat di resep soto saya), dan kerupuk."
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 277 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dinner

---


![Lontong Opor Ayam Kampung Kuah Putih](https://img-global.cpcdn.com/recipes/f0ecf9dada6b7d13/680x482cq70/lontong-opor-ayam-kampung-kuah-putih-foto-resep-utama.jpg)

Andai kita seorang wanita, mempersiapkan olahan mantab pada keluarga tercinta adalah suatu hal yang mengasyikan untuk kamu sendiri. Tanggung jawab seorang istri bukan sekedar mengatur rumah saja, namun kamu pun harus memastikan kebutuhan gizi tercukupi dan juga olahan yang dimakan anak-anak wajib lezat.

Di era  saat ini, kamu sebenarnya dapat membeli panganan praktis tidak harus capek memasaknya lebih dulu. Namun ada juga mereka yang selalu ingin menyajikan yang terlezat untuk orang tercintanya. Karena, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan famili. 



Mungkinkah anda seorang penggemar lontong opor ayam kampung kuah putih?. Asal kamu tahu, lontong opor ayam kampung kuah putih adalah sajian khas di Indonesia yang saat ini disenangi oleh banyak orang di berbagai daerah di Nusantara. Kalian bisa membuat lontong opor ayam kampung kuah putih hasil sendiri di rumah dan boleh dijadikan santapan favoritmu di akhir pekan.

Kalian tak perlu bingung jika kamu ingin memakan lontong opor ayam kampung kuah putih, sebab lontong opor ayam kampung kuah putih tidak sukar untuk ditemukan dan juga kalian pun boleh menghidangkannya sendiri di tempatmu. lontong opor ayam kampung kuah putih bisa dimasak memalui beraneka cara. Kini pun ada banyak banget resep kekinian yang membuat lontong opor ayam kampung kuah putih lebih lezat.

Resep lontong opor ayam kampung kuah putih juga mudah sekali dibuat, lho. Anda tidak perlu ribet-ribet untuk memesan lontong opor ayam kampung kuah putih, sebab Kita dapat menyajikan ditempatmu. Untuk Anda yang ingin mencobanya, inilah resep untuk menyajikan lontong opor ayam kampung kuah putih yang nikamat yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Lontong Opor Ayam Kampung Kuah Putih:

1. Ambil 1/2 ekor ayam kampung
1. Siapkan 4 lbr daun salam
1. Siapkan 3 cm lengkuas (iris/geprek)
1. Sediakan 3 bh daun jeruk purut
1. Sediakan 2 bh sereh (geprek)
1. Ambil 1 bh santan (instan) 65 ml
1. Gunakan Secukupnya Gula dan Garam
1. Sediakan Secukupnya Air
1. Ambil  Bumbu halus:
1. Siapkan 5 siung bawang putih
1. Siapkan 3 siung bawang merah
1. Siapkan 1/2 sdt ketumbar
1. Gunakan 1/2 sdt merica (sangrai)
1. Siapkan 3 bh kemiri (sangrai)
1. Siapkan 1 cm jahe
1. Sediakan 1 jumput jintan
1. Gunakan  Bahan tambahan:
1. Gunakan  Bawang goreng
1. Ambil  Sambel kacang           (lihat resep)
1. Gunakan  Kerupuk udang




<!--inarticleads2-->

##### Langkah-langkah membuat Lontong Opor Ayam Kampung Kuah Putih:

1. Potong ayam kamlung, cuci bersih, blansir sampai kotoran hilang, lalu cuci kembali.
1. Siapkan bumbu opor, sangrai kemiri, merica dan ketumbar, haluskan bersama bumbu lainnya.
1. Tumis bumbu sampai harum dan matang, tambahkan air. Masukkan ayam rebus sampai air setengah susut. Tambahkan gula dan garam dan air santan, aduk-aduk sampai merata.
1. Masak ayam hingga matang dan empuk, taburi bawang goreng. Sajikan dengan lontong, sambel kacang (bisa lihat di resep soto saya), dan kerupuk.




Wah ternyata cara buat lontong opor ayam kampung kuah putih yang mantab simple ini mudah banget ya! Anda Semua dapat memasaknya. Cara Membuat lontong opor ayam kampung kuah putih Sangat cocok sekali buat kamu yang baru belajar memasak atau juga untuk anda yang sudah ahli memasak.

Apakah kamu tertarik mulai mencoba membuat resep lontong opor ayam kampung kuah putih enak simple ini? Kalau mau, mending kamu segera menyiapkan peralatan dan bahannya, lantas buat deh Resep lontong opor ayam kampung kuah putih yang nikmat dan tidak ribet ini. Sangat gampang kan. 

Maka, daripada kamu berlama-lama, ayo kita langsung sajikan resep lontong opor ayam kampung kuah putih ini. Dijamin kamu gak akan nyesel sudah buat resep lontong opor ayam kampung kuah putih lezat tidak rumit ini! Selamat mencoba dengan resep lontong opor ayam kampung kuah putih mantab sederhana ini di rumah kalian masing-masing,oke!.

