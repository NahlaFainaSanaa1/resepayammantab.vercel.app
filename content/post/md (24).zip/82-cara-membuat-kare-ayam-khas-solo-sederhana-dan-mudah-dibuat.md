---
description: "Cara membuat Kare Ayam khas Solo Sederhana dan Mudah Dibuat"
title: "Cara membuat Kare Ayam khas Solo Sederhana dan Mudah Dibuat"
slug: 82-cara-membuat-kare-ayam-khas-solo-sederhana-dan-mudah-dibuat
date: 2021-04-02T21:06:22.948Z
image: https://img-global.cpcdn.com/recipes/11f08e224f0c2817/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/11f08e224f0c2817/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/11f08e224f0c2817/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
author: Ruby Rhodes
ratingvalue: 3.2
reviewcount: 12
recipeingredient:
- "1/2 kg ayam fillet dada"
- "3 lembar Daun salam"
- "5 lembar Daun jeruk"
- "3 batang Sereh  geprek"
- "1 ruas jari Laos  geprek"
- " Garem"
- " Gula"
- " Merica bubuk"
- " Santan segitiga bisa pakai santan murni juga"
- " Bumbu Halus"
- "5 siung bawang putih"
- "5 siung bawang merah"
- "1/2 sdt Jinten"
- "1 sdt Ketumbar"
- "1 ruas Kunyit"
- "2 butir Kemiri"
- " Pelengkap"
- " Toge rebusrendam air panas"
- " Daun bawang"
- "1 buah Wortel"
- " Kering kentang parutiris tipis kentang dan goreng hingga kuning kecoklatan"
- "1 buah Jeruk nipis"
- " Sambel"
recipeinstructions:
- "Rebus ayam hingga air mendidih."
- "Blender/uleg bumbu halus, kemudian tumis hingga wangi. Masukkan laos, daun salam, daun sereh, daun jeruk."
- "Setelah wangi, tuang bumbu yang sudah ditumis ke dalam air rebusan ayam dengan ditambah air secukupnya. Koreksi rasa"
- "Setelah mendidih, tuang santan (saya tidak suka terlalu kental)"
- "Siap dihidangkan"
categories:
- Resep
tags:
- kare
- ayam
- khas

katakunci: kare ayam khas 
nutrition: 243 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Lunch

---


![Kare Ayam khas Solo](https://img-global.cpcdn.com/recipes/11f08e224f0c2817/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan masakan mantab buat orang tercinta adalah suatu hal yang menggembirakan bagi kita sendiri. Tugas seorang ibu bukan sekadar menjaga rumah saja, tapi anda pun wajib menyediakan kebutuhan gizi terpenuhi dan juga hidangan yang dikonsumsi keluarga tercinta mesti nikmat.

Di zaman  sekarang, kamu sebenarnya bisa memesan hidangan siap saji meski tidak harus repot mengolahnya terlebih dahulu. Tapi banyak juga mereka yang selalu ingin memberikan yang terlezat bagi orang yang dicintainya. Karena, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut berdasarkan selera keluarga. 



Mungkinkah anda merupakan seorang penyuka kare ayam khas solo?. Tahukah kamu, kare ayam khas solo adalah sajian khas di Indonesia yang saat ini disukai oleh setiap orang di berbagai wilayah di Indonesia. Kita bisa menghidangkan kare ayam khas solo sendiri di rumah dan dapat dijadikan hidangan kesenanganmu di akhir pekanmu.

Kamu tidak perlu bingung jika kamu ingin menyantap kare ayam khas solo, karena kare ayam khas solo gampang untuk ditemukan dan kamu pun bisa memasaknya sendiri di rumah. kare ayam khas solo bisa diolah dengan beraneka cara. Sekarang sudah banyak banget cara modern yang menjadikan kare ayam khas solo semakin lebih mantap.

Resep kare ayam khas solo pun sangat gampang dibikin, lho. Kalian tidak usah repot-repot untuk membeli kare ayam khas solo, tetapi Anda bisa membuatnya di rumahmu. Untuk Anda yang ingin membuatnya, inilah resep untuk membuat kare ayam khas solo yang nikamat yang bisa Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Kare Ayam khas Solo:

1. Sediakan 1/2 kg ayam fillet (dada)
1. Sediakan 3 lembar Daun salam
1. Ambil 5 lembar Daun jeruk
1. Gunakan 3 batang Sereh  (geprek)
1. Sediakan 1 ruas jari Laos  (geprek)
1. Sediakan  Garem
1. Gunakan  Gula
1. Siapkan  Merica bubuk
1. Ambil  Santan segitiga (bisa pakai santan murni juga)
1. Ambil  Bumbu Halus
1. Ambil 5 siung bawang putih
1. Gunakan 5 siung bawang merah
1. Ambil 1/2 sdt Jinten
1. Ambil 1 sdt Ketumbar
1. Gunakan 1 ruas Kunyit
1. Ambil 2 butir Kemiri
1. Siapkan  Pelengkap
1. Sediakan  Toge (rebus/rendam air panas)
1. Sediakan  Daun bawang
1. Ambil 1 buah Wortel
1. Gunakan  Kering kentang (parut/iris tipis kentang dan goreng hingga kuning kecoklatan)
1. Siapkan 1 buah Jeruk nipis
1. Gunakan  Sambel




<!--inarticleads2-->

##### Langkah-langkah membuat Kare Ayam khas Solo:

1. Rebus ayam hingga air mendidih.
1. Blender/uleg bumbu halus, kemudian tumis hingga wangi. Masukkan laos, daun salam, daun sereh, daun jeruk.
1. Setelah wangi, tuang bumbu yang sudah ditumis ke dalam air rebusan ayam dengan ditambah air secukupnya. Koreksi rasa
1. Setelah mendidih, tuang santan (saya tidak suka terlalu kental)
1. Siap dihidangkan




Ternyata cara membuat kare ayam khas solo yang enak simple ini enteng sekali ya! Kalian semua mampu membuatnya. Resep kare ayam khas solo Sangat sesuai sekali buat kita yang baru mau belajar memasak ataupun juga bagi anda yang telah pandai memasak.

Tertarik untuk mulai mencoba membuat resep kare ayam khas solo mantab sederhana ini? Kalau tertarik, ayo kamu segera siapkan alat-alat dan bahan-bahannya, maka bikin deh Resep kare ayam khas solo yang enak dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka dari itu, daripada kamu berfikir lama-lama, hayo langsung aja buat resep kare ayam khas solo ini. Dijamin anda tak akan menyesal sudah bikin resep kare ayam khas solo nikmat sederhana ini! Selamat berkreasi dengan resep kare ayam khas solo nikmat simple ini di rumah kalian masing-masing,ya!.

