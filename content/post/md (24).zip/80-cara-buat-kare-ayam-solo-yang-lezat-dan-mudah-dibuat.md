---
description: "Cara buat Kare Ayam Solo yang lezat dan Mudah Dibuat"
title: "Cara buat Kare Ayam Solo yang lezat dan Mudah Dibuat"
slug: 80-cara-buat-kare-ayam-solo-yang-lezat-dan-mudah-dibuat
date: 2021-04-18T12:15:28.918Z
image: https://img-global.cpcdn.com/recipes/ff15dd06b5294712/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff15dd06b5294712/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff15dd06b5294712/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Craig Hayes
ratingvalue: 4.5
reviewcount: 9
recipeingredient:
- "1/2 kg ayam dada"
- " Kecambah rendam air panas"
- " Kobis iris tipis2 rendam air panas"
- " Sledri"
- " Daun bawang"
- " Bawang Goreng"
- " Tomat"
- "500 ml Santan"
- " BUMBU HALUS"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "2 butir miri"
- "1/2 sdt tumbar"
- "2 helai serai geprek"
- "2 ruas kunyit"
- "secukupnya Laos"
- " Daun jeruk"
- " Daun salam"
recipeinstructions:
- "Potong ayam jadi 2 bagian"
- "Didihkan air, lalu rebus ayam sampai empuk. Setelah itu tiriskan ayam, dan goreng setengah matang."
- "Haluskan bumbu halus"
- "Panaskan minyak goreng secukupnya, tumis bumbu sampai layu"
- "Masukan air rebusan ayam pada tumisan bumbu, rebus hingga mendidih"
- "Setelah mendidih, masukan santan..tambahkan garam, gula dan kaldu jamur,.koreksi rasa. Apabila mau di angkat masukan irisan tomat, daun bawang, dan bawang goreng."
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 294 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Lunch

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/ff15dd06b5294712/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Apabila kalian seorang orang tua, mempersiapkan santapan sedap kepada orang tercinta merupakan hal yang memuaskan bagi kita sendiri. Tanggung jawab seorang istri bukan cuma mengatur rumah saja, tetapi kamu juga harus menyediakan kebutuhan gizi terpenuhi dan juga olahan yang dimakan orang tercinta mesti menggugah selera.

Di zaman  saat ini, kamu sebenarnya mampu mengorder santapan instan meski tanpa harus capek memasaknya lebih dulu. Namun ada juga orang yang selalu mau memberikan hidangan yang terenak untuk orang tercintanya. Karena, menghidangkan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut berdasarkan selera keluarga. 



Mungkinkah anda salah satu penyuka kare ayam solo?. Tahukah kamu, kare ayam solo adalah hidangan khas di Indonesia yang saat ini digemari oleh setiap orang di berbagai daerah di Indonesia. Anda dapat menyajikan kare ayam solo buatan sendiri di rumahmu dan pasti jadi makanan kegemaranmu di akhir pekan.

Kalian tak perlu bingung untuk mendapatkan kare ayam solo, karena kare ayam solo tidak sukar untuk dicari dan juga anda pun boleh membuatnya sendiri di rumah. kare ayam solo dapat dimasak lewat berbagai cara. Kini ada banyak resep kekinian yang membuat kare ayam solo semakin lebih lezat.

Resep kare ayam solo pun mudah sekali dibuat, lho. Kita jangan repot-repot untuk memesan kare ayam solo, tetapi Kamu bisa menghidangkan di rumah sendiri. Bagi Anda yang ingin menghidangkannya, berikut ini cara untuk menyajikan kare ayam solo yang nikamat yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Kare Ayam Solo:

1. Ambil 1/2 kg ayam dada
1. Siapkan  Kecambah (rendam air panas)
1. Gunakan  Kobis, iris tipis2 (rendam air panas)
1. Sediakan  Sledri
1. Gunakan  Daun bawang
1. Ambil  Bawang Goreng
1. Sediakan  Tomat
1. Ambil 500 ml Santan
1. Ambil  BUMBU HALUS
1. Gunakan 6 siung bawang merah
1. Gunakan 4 siung bawang putih
1. Sediakan 2 butir miri
1. Siapkan 1/2 sdt tumbar
1. Siapkan 2 helai serai, geprek
1. Siapkan 2 ruas kunyit
1. Gunakan secukupnya Laos
1. Sediakan  Daun jeruk
1. Siapkan  Daun salam




<!--inarticleads2-->

##### Langkah-langkah membuat Kare Ayam Solo:

1. Potong ayam jadi 2 bagian
1. Didihkan air, lalu rebus ayam sampai empuk. Setelah itu tiriskan ayam, dan goreng setengah matang.
1. Haluskan bumbu halus
1. Panaskan minyak goreng secukupnya, tumis bumbu sampai layu
1. Masukan air rebusan ayam pada tumisan bumbu, rebus hingga mendidih
1. Setelah mendidih, masukan santan..tambahkan garam, gula dan kaldu jamur,.koreksi rasa. Apabila mau di angkat masukan irisan tomat, daun bawang, dan bawang goreng.




Ternyata cara membuat kare ayam solo yang lezat simple ini gampang sekali ya! Kamu semua mampu memasaknya. Cara Membuat kare ayam solo Sesuai sekali buat kalian yang sedang belajar memasak ataupun untuk kalian yang sudah jago memasak.

Tertarik untuk mulai mencoba buat resep kare ayam solo mantab tidak rumit ini? Kalau kalian mau, mending kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep kare ayam solo yang lezat dan tidak ribet ini. Sangat gampang kan. 

Oleh karena itu, daripada anda diam saja, yuk langsung aja buat resep kare ayam solo ini. Dijamin kalian tiidak akan menyesal sudah membuat resep kare ayam solo mantab tidak rumit ini! Selamat mencoba dengan resep kare ayam solo enak tidak ribet ini di rumah kalian masing-masing,ya!.

