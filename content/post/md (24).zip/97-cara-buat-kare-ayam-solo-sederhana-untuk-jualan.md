---
description: "Cara buat Kare Ayam Solo Sederhana Untuk Jualan"
title: "Cara buat Kare Ayam Solo Sederhana Untuk Jualan"
slug: 97-cara-buat-kare-ayam-solo-sederhana-untuk-jualan
date: 2021-02-15T05:16:34.010Z
image: https://img-global.cpcdn.com/recipes/acbac7466299598c/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/acbac7466299598c/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/acbac7466299598c/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Delia Long
ratingvalue: 3.7
reviewcount: 7
recipeingredient:
- "1/4 kg dada ayam"
- "700 ml air"
- "150 ml santan"
- "secukupnya minyak untuk menggoreng dan menumis"
- " Bumbu Halus"
- "5 siung bawang putih"
- "4 siung bawang merah"
- "1/4 sdt merica bubuk"
- "1/2 sdt kunyit bubuk"
- "seujung sdt ketumbar bubuk"
- "3 butir kemiri"
- "seujung sdt jinten"
- "seujung sdt pala bubuk"
- "1 1/2 sdt garam"
- "1/2 sdt gula pasir"
- "sedikit penyedap rasa bs skip"
- " Bumbu Lainnya"
- "2 lembar daun salam sobek"
- "1 lembar daun jeruk sobek"
- "3 ruas lengkuas geprek"
- "2 ruas jahe geprek"
- "1 batang serai geprek"
- "2 buah cengkeh"
- "3 butir kapulaga"
- " Bahan Pelengkap"
- "secukupnya kol iris halus rebus"
- "secukupnya wortel iris korek api rebus"
- "secukupnya tauge rebus"
- "secukupnya bihun kaca rebus"
- "secukupnya keripik kentang goreng"
- "secukupnya seledri iris tipis"
- "secukupnya bawang goreng"
recipeinstructions:
- "Siapkan bumbu halus, kemudian tumis bumbu halus dengan 3 sdm minyak sayur. tambahkan &#34;bumbu lainnya&#34; lalu tumis sampai harum."
- "Masukkan air ke dalam tumisan bumbu. tambahkan dada ayam yg sdh di cuci bersih. rebus dgn api sedang hingga mendidih kemudian kecilkan api."
- "Tambahkan santan, aduk2 sampai mendidih agar santan tidak pecah. tes rasa. apabila sudah pas biarkan sebentar agar mendidih kembali. matikan api"
- "Tiriskan ayam dr kuah, kemudian goreng sebentar. sisihkan untuk bahan pelengkap (nantinya di suwir2 ya)"
- "Penyajian : siapkan mangkuk, beri nasi lalu tambahkan kol, tauge, wortel, bihun, seledri, dan ayam suwir. siram dengan kuah kare. lalu beri taburan bawang goreng."
- "Kare Ayam Solo siap disajikan. bs di santap bersama sambap kecap bila suka 😊"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 248 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dessert

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/acbac7466299598c/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, mempersiapkan olahan mantab bagi orang tercinta merupakan suatu hal yang memuaskan untuk anda sendiri. Kewajiban seorang ibu Tidak cuman mengurus rumah saja, namun anda pun harus memastikan keperluan gizi tercukupi dan juga santapan yang dikonsumsi keluarga tercinta mesti sedap.

Di waktu  sekarang, anda memang bisa membeli masakan siap saji walaupun tanpa harus susah membuatnya terlebih dahulu. Tetapi ada juga lho mereka yang selalu ingin menyajikan yang terenak bagi orang tercintanya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai selera keluarga tercinta. 



Apakah anda adalah salah satu penikmat kare ayam solo?. Tahukah kamu, kare ayam solo adalah sajian khas di Indonesia yang sekarang disenangi oleh banyak orang dari berbagai tempat di Nusantara. Anda dapat membuat kare ayam solo sendiri di rumahmu dan boleh dijadikan santapan kesenanganmu di hari libur.

Anda tidak perlu bingung untuk menyantap kare ayam solo, karena kare ayam solo tidak sukar untuk ditemukan dan kamu pun bisa memasaknya sendiri di tempatmu. kare ayam solo bisa diolah memalui beragam cara. Sekarang sudah banyak sekali cara kekinian yang menjadikan kare ayam solo semakin lezat.

Resep kare ayam solo pun sangat gampang dibikin, lho. Kita tidak usah ribet-ribet untuk memesan kare ayam solo, karena Kalian mampu membuatnya di rumahmu. Untuk Kalian yang akan menyajikannya, berikut resep untuk membuat kare ayam solo yang nikamat yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Kare Ayam Solo:

1. Ambil 1/4 kg dada ayam
1. Ambil 700 ml air
1. Siapkan 150 ml santan
1. Sediakan secukupnya minyak untuk menggoreng dan menumis
1. Gunakan  Bumbu Halus
1. Siapkan 5 siung bawang putih
1. Ambil 4 siung bawang merah
1. Ambil 1/4 sdt merica bubuk
1. Gunakan 1/2 sdt kunyit bubuk
1. Siapkan seujung sdt ketumbar bubuk
1. Gunakan 3 butir kemiri
1. Siapkan seujung sdt jinten
1. Gunakan seujung sdt pala bubuk
1. Sediakan 1 1/2 sdt garam
1. Sediakan 1/2 sdt gula pasir
1. Sediakan sedikit penyedap rasa (bs skip)
1. Ambil  Bumbu Lainnya
1. Gunakan 2 lembar daun salam sobek
1. Ambil 1 lembar daun jeruk sobek
1. Siapkan 3 ruas lengkuas geprek
1. Gunakan 2 ruas jahe geprek
1. Siapkan 1 batang serai geprek
1. Siapkan 2 buah cengkeh
1. Gunakan 3 butir kapulaga
1. Ambil  Bahan Pelengkap
1. Sediakan secukupnya kol iris halus, rebus
1. Siapkan secukupnya wortel iris korek api, rebus
1. Gunakan secukupnya tauge, rebus
1. Siapkan secukupnya bihun kaca, rebus
1. Gunakan secukupnya keripik kentang goreng
1. Sediakan secukupnya seledri iris tipis
1. Sediakan secukupnya bawang goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Kare Ayam Solo:

1. Siapkan bumbu halus, kemudian tumis bumbu halus dengan 3 sdm minyak sayur. tambahkan &#34;bumbu lainnya&#34; lalu tumis sampai harum.
1. Masukkan air ke dalam tumisan bumbu. tambahkan dada ayam yg sdh di cuci bersih. rebus dgn api sedang hingga mendidih kemudian kecilkan api.
1. Tambahkan santan, aduk2 sampai mendidih agar santan tidak pecah. tes rasa. apabila sudah pas biarkan sebentar agar mendidih kembali. matikan api
1. Tiriskan ayam dr kuah, kemudian goreng sebentar. sisihkan untuk bahan pelengkap (nantinya di suwir2 ya)
1. Penyajian : siapkan mangkuk, beri nasi lalu tambahkan kol, tauge, wortel, bihun, seledri, dan ayam suwir. siram dengan kuah kare. lalu beri taburan bawang goreng.
1. Kare Ayam Solo siap disajikan. bs di santap bersama sambap kecap bila suka 😊




Wah ternyata cara membuat kare ayam solo yang enak sederhana ini gampang banget ya! Kita semua bisa menghidangkannya. Cara Membuat kare ayam solo Sangat cocok banget buat anda yang baru belajar memasak atau juga bagi kamu yang telah hebat memasak.

Apakah kamu mau mulai mencoba membuat resep kare ayam solo mantab tidak ribet ini? Kalau kalian ingin, ayo kalian segera menyiapkan peralatan dan bahannya, lantas bikin deh Resep kare ayam solo yang lezat dan tidak ribet ini. Sungguh taidak sulit kan. 

Maka dari itu, daripada kita diam saja, maka kita langsung buat resep kare ayam solo ini. Pasti kamu tak akan nyesel sudah membuat resep kare ayam solo mantab simple ini! Selamat mencoba dengan resep kare ayam solo nikmat sederhana ini di rumah kalian masing-masing,oke!.

