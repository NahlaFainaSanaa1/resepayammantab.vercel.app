---
description: "Resep Kare Ayam Solo Sederhana dan Mudah Dibuat"
title: "Resep Kare Ayam Solo Sederhana dan Mudah Dibuat"
slug: 83-resep-kare-ayam-solo-sederhana-dan-mudah-dibuat
date: 2021-02-13T06:05:15.390Z
image: https://img-global.cpcdn.com/recipes/26f27d315689d0bb/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/26f27d315689d0bb/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/26f27d315689d0bb/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Marguerite Bryan
ratingvalue: 4.1
reviewcount: 3
recipeingredient:
- "250 gr dada ayam"
- "1.5 liter air"
- "1 lembar daun salam"
- "1 batang seraigeprek"
- "1 ruas lengkuasgeprek"
- "2 lembar daunjeruk"
- "Secukupnya kapulagakayu manis"
- "Secukupnya kaldu bubuk"
- "Secukupnya gulagaram"
- "2 bungkus santan kara 65ml"
- " Bumbu halus"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "2 butir kemiri"
- "Sejumput jintendikit aja"
- "1/2 sdt ketumbar bubuk"
- "1/4 sdt lada bubuk"
- "1 sdt kunyit bubuk"
- " Bahan pelengkap"
- " Toge rebus"
- " Bihun rebus"
- " Wortel rebus"
- " Keripik kentang"
- " Sambal bawang rebus           lihat resep"
recipeinstructions:
- "Rebus ayam,rebus bahan sambal,goreng keripik kentang sisihkan"
- "Uleg bumbu halus lalu tumis hingga harum.tambahkan sere,daun salam,daun jeruk,lengkuas,kapulaga,kayumanis.masukkan ayam yg sudah direbus,tambahkan air.Masukkan gula garam kaldu bubuk.koreksi rasa,jika sudah pas,masukkan santan,sering diaduk ya agar santan Tdk pecah.diidihkan kembali"
- "Siapkan semua bahan pelengkap"
- "Penyajian:tata dlm mangkok toge rebus,bihun rebus,wortel rebus,siram kuah kare,beri suwiran ayam diatasnya.taburi seledri dan bawang goreng.sajikan dgn sambal bawang rebus"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Dessert

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/26f27d315689d0bb/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan hidangan lezat untuk orang tercinta adalah suatu hal yang sangat menyenangkan bagi kita sendiri. Peran seorang  wanita bukan hanya mengerjakan pekerjaan rumah saja, namun anda pun wajib menyediakan kebutuhan gizi terpenuhi dan juga panganan yang dikonsumsi keluarga tercinta wajib enak.

Di waktu  saat ini, kita sebenarnya bisa membeli olahan praktis meski tidak harus susah membuatnya lebih dulu. Namun banyak juga mereka yang selalu ingin menyajikan yang terbaik untuk keluarganya. Sebab, memasak yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan famili. 



Apakah anda merupakan salah satu penikmat kare ayam solo?. Asal kamu tahu, kare ayam solo adalah hidangan khas di Nusantara yang kini digemari oleh setiap orang dari hampir setiap wilayah di Nusantara. Kita dapat memasak kare ayam solo sendiri di rumahmu dan pasti jadi camilan kegemaranmu di hari libur.

Kita tak perlu bingung jika kamu ingin memakan kare ayam solo, lantaran kare ayam solo gampang untuk ditemukan dan juga anda pun bisa memasaknya sendiri di tempatmu. kare ayam solo boleh diolah lewat bermacam cara. Kini sudah banyak sekali cara modern yang membuat kare ayam solo lebih nikmat.

Resep kare ayam solo pun gampang dihidangkan, lho. Kalian tidak perlu ribet-ribet untuk memesan kare ayam solo, sebab Kamu bisa menghidangkan sendiri di rumah. Bagi Anda yang ingin mencobanya, berikut ini cara untuk menyajikan kare ayam solo yang mantab yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Kare Ayam Solo:

1. Gunakan 250 gr dada ayam
1. Sediakan 1.5 liter air
1. Ambil 1 lembar daun salam
1. Sediakan 1 batang serai,geprek
1. Siapkan 1 ruas lengkuas,geprek
1. Gunakan 2 lembar daunjeruk
1. Ambil Secukupnya kapulaga,kayu manis
1. Gunakan Secukupnya kaldu bubuk
1. Sediakan Secukupnya gula,garam
1. Siapkan 2 bungkus santan kara (@65ml)
1. Ambil  Bumbu halus:
1. Siapkan 5 siung bawang merah
1. Ambil 5 siung bawang putih
1. Gunakan 2 butir kemiri
1. Siapkan Sejumput jinten(dikit aja)
1. Gunakan 1/2 sdt ketumbar bubuk
1. Gunakan 1/4 sdt lada bubuk
1. Gunakan 1 sdt kunyit bubuk
1. Ambil  Bahan pelengkap:
1. Ambil  Toge rebus
1. Sediakan  Bihun rebus
1. Ambil  Wortel rebus
1. Ambil  Keripik kentang
1. Gunakan  Sambal bawang rebus           (lihat resep)




<!--inarticleads2-->

##### Langkah-langkah membuat Kare Ayam Solo:

1. Rebus ayam,rebus bahan sambal,goreng keripik kentang sisihkan
1. Uleg bumbu halus lalu tumis hingga harum.tambahkan sere,daun salam,daun jeruk,lengkuas,kapulaga,kayumanis.masukkan ayam yg sudah direbus,tambahkan air.Masukkan gula garam kaldu bubuk.koreksi rasa,jika sudah pas,masukkan santan,sering diaduk ya agar santan Tdk pecah.diidihkan kembali
1. Siapkan semua bahan pelengkap
1. Penyajian:tata dlm mangkok toge rebus,bihun rebus,wortel rebus,siram kuah kare,beri suwiran ayam diatasnya.taburi seledri dan bawang goreng.sajikan dgn sambal bawang rebus




Wah ternyata cara membuat kare ayam solo yang enak sederhana ini mudah sekali ya! Kita semua dapat memasaknya. Cara buat kare ayam solo Sangat sesuai sekali buat kamu yang baru mau belajar memasak maupun juga untuk anda yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba membuat resep kare ayam solo enak tidak rumit ini? Kalau kalian tertarik, yuk kita segera menyiapkan peralatan dan bahan-bahannya, kemudian buat deh Resep kare ayam solo yang mantab dan sederhana ini. Sangat gampang kan. 

Oleh karena itu, daripada kamu diam saja, yuk kita langsung saja sajikan resep kare ayam solo ini. Dijamin kalian tak akan menyesal bikin resep kare ayam solo mantab simple ini! Selamat mencoba dengan resep kare ayam solo mantab tidak rumit ini di rumah kalian sendiri,oke!.

