---
description: "Bahan-bahan Kare ayam Simpel yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Kare ayam Simpel yang nikmat dan Mudah Dibuat"
slug: 224-bahan-bahan-kare-ayam-simpel-yang-nikmat-dan-mudah-dibuat
date: 2021-02-21T07:36:58.304Z
image: https://img-global.cpcdn.com/recipes/beb488fcb130fb98/680x482cq70/kare-ayam-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/beb488fcb130fb98/680x482cq70/kare-ayam-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/beb488fcb130fb98/680x482cq70/kare-ayam-simpel-foto-resep-utama.jpg
author: Virginia Ray
ratingvalue: 3.1
reviewcount: 8
recipeingredient:
- "1/4 kg daging ayam  6 bh ceker ayam"
- "1 bks santan instan bubuk"
- " Bumbu cemplung "
- "1 lbr daun salam"
- "1 btng serai"
- "Sejempol lengkuas"
- "3 lbr daun jeruk"
- "1/4 sdt merica bubuk"
- " Garam gula kaldu bubuk bisa di skip"
- " Bumbu halus "
- "5 siung bawang merah"
- "2 siung bawang putih"
- "1/2 bh cabe merah besar"
- "3 btr kemiri"
- "1 sdt ketumbar"
- "1 cm kunyit"
- "2 cm jahe"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian sesuai selera. Cuci bersih."
- "Didihkan air dalam panci, setelah mendidih rebus ayam bersama daun salam sekitar 10 menit untuk menghilangkan bau amisnya. Buang airnya. Cuci kembali hingga bersih"
- "Ganti kembali airnya kemudian rebus lagi menggunakan api kecil."
- "Haluskan bumbu halus. Kemudian tumis hingga harum. Masukkan bumbu cemplungnya. Tumis lagi hingga bau langunya hilang."
- "Masukkan bumbu dalam rebusan ayam. Biarkan sebentar hingga bumbu meresap."
- "Tambahkan santan bubuk, aduk rata. Jangan lupa beri garam, gula dan merica bubuk. Tes rasa. Biarkan hingga kuah sedikit berkurang dan agak mengental."
categories:
- Resep
tags:
- kare
- ayam
- simpel

katakunci: kare ayam simpel 
nutrition: 298 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dessert

---


![Kare ayam Simpel](https://img-global.cpcdn.com/recipes/beb488fcb130fb98/680x482cq70/kare-ayam-simpel-foto-resep-utama.jpg)

Apabila anda seorang yang hobi memasak, menyajikan santapan sedap buat keluarga adalah hal yang menyenangkan bagi anda sendiri. Kewajiban seorang ibu Tidak sekedar menjaga rumah saja, tetapi anda juga wajib menyediakan keperluan nutrisi terpenuhi dan santapan yang disantap anak-anak mesti mantab.

Di waktu  saat ini, kita memang bisa mengorder panganan jadi tanpa harus susah mengolahnya dulu. Tetapi banyak juga lho mereka yang memang mau menghidangkan yang terlezat untuk orang tercintanya. Sebab, memasak sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan selera orang tercinta. 



Apakah anda seorang penikmat kare ayam simpel?. Asal kamu tahu, kare ayam simpel adalah makanan khas di Nusantara yang saat ini digemari oleh setiap orang di berbagai tempat di Nusantara. Kalian bisa membuat kare ayam simpel sendiri di rumahmu dan boleh jadi camilan kegemaranmu di hari liburmu.

Kalian jangan bingung untuk mendapatkan kare ayam simpel, sebab kare ayam simpel tidak sulit untuk dicari dan kita pun bisa mengolahnya sendiri di tempatmu. kare ayam simpel boleh diolah dengan beragam cara. Kini telah banyak banget cara modern yang membuat kare ayam simpel semakin lebih nikmat.

Resep kare ayam simpel pun gampang sekali untuk dibikin, lho. Kita tidak perlu ribet-ribet untuk membeli kare ayam simpel, lantaran Kita mampu membuatnya di rumahmu. Bagi Kita yang ingin menghidangkannya, berikut resep untuk membuat kare ayam simpel yang enak yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Kare ayam Simpel:

1. Sediakan 1/4 kg daging ayam + 6 bh ceker ayam
1. Siapkan 1 bks santan instan bubuk
1. Siapkan  Bumbu cemplung :
1. Gunakan 1 lbr daun salam
1. Ambil 1 btng serai
1. Gunakan Sejempol lengkuas
1. Ambil 3 lbr daun jeruk
1. Gunakan 1/4 sdt merica bubuk
1. Siapkan  Garam, gula, kaldu bubuk (bisa di skip)
1. Ambil  Bumbu halus :
1. Sediakan 5 siung bawang merah
1. Gunakan 2 siung bawang putih
1. Gunakan 1/2 bh cabe merah besar
1. Siapkan 3 btr kemiri
1. Siapkan 1 sdt ketumbar
1. Gunakan 1 cm kunyit
1. Gunakan 2 cm jahe




<!--inarticleads2-->

##### Cara menyiapkan Kare ayam Simpel:

1. Potong ayam menjadi beberapa bagian sesuai selera. Cuci bersih.
1. Didihkan air dalam panci, setelah mendidih rebus ayam bersama daun salam sekitar 10 menit untuk menghilangkan bau amisnya. Buang airnya. Cuci kembali hingga bersih
1. Ganti kembali airnya kemudian rebus lagi menggunakan api kecil.
1. Haluskan bumbu halus. Kemudian tumis hingga harum. Masukkan bumbu cemplungnya. Tumis lagi hingga bau langunya hilang.
1. Masukkan bumbu dalam rebusan ayam. Biarkan sebentar hingga bumbu meresap.
1. Tambahkan santan bubuk, aduk rata. Jangan lupa beri garam, gula dan merica bubuk. Tes rasa. Biarkan hingga kuah sedikit berkurang dan agak mengental.




Wah ternyata resep kare ayam simpel yang enak simple ini mudah banget ya! Kita semua mampu menghidangkannya. Cara Membuat kare ayam simpel Sesuai sekali untuk kita yang baru mau belajar memasak maupun juga untuk kamu yang telah pandai memasak.

Apakah kamu mau mencoba bikin resep kare ayam simpel mantab tidak ribet ini? Kalau anda tertarik, ayo kalian segera buruan menyiapkan peralatan dan bahan-bahannya, maka buat deh Resep kare ayam simpel yang nikmat dan sederhana ini. Sangat taidak sulit kan. 

Maka dari itu, ketimbang kalian berlama-lama, yuk kita langsung saja sajikan resep kare ayam simpel ini. Dijamin anda tak akan nyesel sudah bikin resep kare ayam simpel lezat simple ini! Selamat berkreasi dengan resep kare ayam simpel mantab tidak rumit ini di tempat tinggal kalian sendiri,oke!.

