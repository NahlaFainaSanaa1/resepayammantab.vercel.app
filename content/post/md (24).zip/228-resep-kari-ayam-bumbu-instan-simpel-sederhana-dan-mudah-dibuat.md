---
description: "Resep Kari Ayam Bumbu Instan Simpel Sederhana dan Mudah Dibuat"
title: "Resep Kari Ayam Bumbu Instan Simpel Sederhana dan Mudah Dibuat"
slug: 228-resep-kari-ayam-bumbu-instan-simpel-sederhana-dan-mudah-dibuat
date: 2021-03-27T07:03:08.996Z
image: https://img-global.cpcdn.com/recipes/d9364f35f99fa226/680x482cq70/kari-ayam-bumbu-instan-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d9364f35f99fa226/680x482cq70/kari-ayam-bumbu-instan-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d9364f35f99fa226/680x482cq70/kari-ayam-bumbu-instan-simpel-foto-resep-utama.jpg
author: Gilbert Duncan
ratingvalue: 3.2
reviewcount: 9
recipeingredient:
- "1/2 kg ayam"
- "3 buah kentang sedang"
- "1 sachet bumbu kari instan"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "5 batang cabe merah"
- "10 lembar daun kari"
- "1 sdt jahe bubuk"
- "1 sachet santan kara"
- "1 liter air"
- "Secukupnya minyak"
recipeinstructions:
- "Potong ayam menjadi ukuran sedang/kecil (sesuai selera), cuci bersih lalu berikan perasan jeruk nipis agar tidak amis. Biarkan 5 menit."
- "Blender dan tumis bawang merah, bawang putih dan cabai merah lalu masukkan juga bumbu instan, jahe bubuk dan daun kari kedalam tumisan."
- "Setelah tumisan harum masukkan ayam dan kentang yang sudah dipotong dadu lalu aduk-aduk sedikit kemudian masukkan air."
- "Setelah ayam matang dan kentang lunak, masukkan santan lalu aduk-aduk dan tunggu lagi sampai sekitar 7 menit."
- "Jangan lupa menambahkan gula, garam dan penyedap lalu koreksi rasa. Apabila rasanya sudah pas maka siap disajikan. Selamat mencoba!"
categories:
- Resep
tags:
- kari
- ayam
- bumbu

katakunci: kari ayam bumbu 
nutrition: 191 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch

---


![Kari Ayam Bumbu Instan Simpel](https://img-global.cpcdn.com/recipes/d9364f35f99fa226/680x482cq70/kari-ayam-bumbu-instan-simpel-foto-resep-utama.jpg)

Apabila kamu seorang yang hobi memasak, menyajikan panganan mantab buat keluarga tercinta adalah hal yang sangat menyenangkan bagi kita sendiri. Kewajiban seorang  wanita bukan cuma mengurus rumah saja, tapi anda juga harus menyediakan kebutuhan nutrisi tercukupi dan juga santapan yang disantap keluarga tercinta mesti mantab.

Di zaman  sekarang, kalian memang bisa memesan santapan yang sudah jadi meski tidak harus repot mengolahnya lebih dulu. Tapi ada juga orang yang memang mau menyajikan yang terbaik bagi orang yang dicintainya. Karena, memasak yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan makanan kesukaan keluarga tercinta. 



Apakah anda seorang penikmat kari ayam bumbu instan simpel?. Asal kamu tahu, kari ayam bumbu instan simpel merupakan hidangan khas di Indonesia yang kini disenangi oleh setiap orang dari hampir setiap daerah di Indonesia. Kalian bisa membuat kari ayam bumbu instan simpel kreasi sendiri di rumah dan boleh dijadikan camilan kesukaanmu di hari libur.

Anda tak perlu bingung jika kamu ingin menyantap kari ayam bumbu instan simpel, karena kari ayam bumbu instan simpel sangat mudah untuk dicari dan kalian pun dapat mengolahnya sendiri di tempatmu. kari ayam bumbu instan simpel boleh dibuat memalui bermacam cara. Sekarang ada banyak sekali resep modern yang menjadikan kari ayam bumbu instan simpel semakin nikmat.

Resep kari ayam bumbu instan simpel pun gampang untuk dibikin, lho. Kalian jangan repot-repot untuk membeli kari ayam bumbu instan simpel, tetapi Kalian mampu menyiapkan sendiri di rumah. Untuk Kamu yang ingin membuatnya, berikut cara untuk membuat kari ayam bumbu instan simpel yang lezat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Kari Ayam Bumbu Instan Simpel:

1. Sediakan 1/2 kg ayam
1. Siapkan 3 buah kentang sedang
1. Gunakan 1 sachet bumbu kari instan
1. Ambil 4 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Ambil 5 batang cabe merah
1. Sediakan 10 lembar daun kari
1. Sediakan 1 sdt jahe bubuk
1. Ambil 1 sachet santan kara
1. Sediakan 1 liter air
1. Sediakan Secukupnya minyak




<!--inarticleads2-->

##### Langkah-langkah membuat Kari Ayam Bumbu Instan Simpel:

1. Potong ayam menjadi ukuran sedang/kecil (sesuai selera), cuci bersih lalu berikan perasan jeruk nipis agar tidak amis. Biarkan 5 menit.
1. Blender dan tumis bawang merah, bawang putih dan cabai merah lalu masukkan juga bumbu instan, jahe bubuk dan daun kari kedalam tumisan.
1. Setelah tumisan harum masukkan ayam dan kentang yang sudah dipotong dadu lalu aduk-aduk sedikit kemudian masukkan air.
1. Setelah ayam matang dan kentang lunak, masukkan santan lalu aduk-aduk dan tunggu lagi sampai sekitar 7 menit.
1. Jangan lupa menambahkan gula, garam dan penyedap lalu koreksi rasa. Apabila rasanya sudah pas maka siap disajikan. Selamat mencoba!




Wah ternyata cara buat kari ayam bumbu instan simpel yang nikamt tidak ribet ini enteng banget ya! Kalian semua bisa menghidangkannya. Resep kari ayam bumbu instan simpel Cocok banget buat kalian yang baru belajar memasak ataupun juga untuk anda yang telah pandai memasak.

Tertarik untuk mulai mencoba bikin resep kari ayam bumbu instan simpel mantab tidak rumit ini? Kalau kamu mau, ayo kamu segera buruan siapin alat-alat dan bahan-bahannya, lalu bikin deh Resep kari ayam bumbu instan simpel yang lezat dan tidak ribet ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kita berfikir lama-lama, hayo langsung aja sajikan resep kari ayam bumbu instan simpel ini. Pasti kalian tiidak akan nyesel sudah buat resep kari ayam bumbu instan simpel enak tidak ribet ini! Selamat mencoba dengan resep kari ayam bumbu instan simpel enak tidak rumit ini di rumah sendiri,oke!.

