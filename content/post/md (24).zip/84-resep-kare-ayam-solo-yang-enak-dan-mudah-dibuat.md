---
description: "Resep Kare Ayam Solo yang enak dan Mudah Dibuat"
title: "Resep Kare Ayam Solo yang enak dan Mudah Dibuat"
slug: 84-resep-kare-ayam-solo-yang-enak-dan-mudah-dibuat
date: 2021-06-02T22:27:55.798Z
image: https://img-global.cpcdn.com/recipes/73c44ee4979ff875/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/73c44ee4979ff875/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/73c44ee4979ff875/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Frank Spencer
ratingvalue: 3.8
reviewcount: 10
recipeingredient:
- "800 gram ayam broilersekitar 8 potongan"
- "500 ml santan kekentalan sedang"
- "1 batang daun bawang"
- "1 ikat kecil daun seledri"
- "2 buah tomat"
- "sesuai selera Cabe rawit"
- "1 buah wortel ukuran sedang"
- "1/2 lingkaran kol"
- "secukupnya Air"
- " Minyak untuk menumis"
- " Bahan pelengkap"
- " Keripik kentang"
- " Bihun  sohun"
- " Bumbu halus"
- "10 butir bawang merah"
- "5 butir bawang putih"
- "1/2 sdt jinten"
- "1 sdt ketumbar bubuk"
- "1 sdt kunyit halus"
- "3 butir kemiri sangrai"
- " Bumbu cemplung"
- "1 jempol lengkuas geprek"
- "3 lbr daun salam"
- "1 btg sereh geprek simpulkan"
- "1-2 sdt garam"
- "1 sdt kaldu bubuk"
- "2 sdt gula pasir"
recipeinstructions:
- "Siapkan semua bahan. Cuci cuci bersih."
- "Iris2 tomat, wortel, kol daun bawang dan seledri. Cabe rawit biarkan wutuhan. Siapkan santan kekentalan sedang."
- "Rebus ayam, buang dulu air rebusan pertama. Kemudian rebus lagi hingga keluar kaldu/minyaknya. Sisihkan"
- "Haluskan bumbu halus. Panaskan 2 sdm minyak goreng di api sedang. Tumis bumbu halus, osreng sebentar, masukkan daun salam, lengkuas, sereh, kayu manis. Tumis hingga harum dan tanak."
- "Kemudian masukkan ayam yg telah direbus beserta air rebusannya. Tambahkan garam, gula pasir, kaldu bubuk. Masak hingga mendidih."
- "Lalu masukkan air santan, masak hingga mendidih dengan terus diaduk ya agar santan tidak pecah. Jika dirasa terlalu kental kuahnya bisa ditambahkan sedikit air lagi."
- "Setelah mendidih, masukkan potongan kol, wortel, tomat, daun bawang. Bolak balik. Sambil cek rasa ya. Terakhir masukkan daun seledri dan cabe rawit. Masak hingga kekentalan kuah yg diinginkan. Siap disajikan."
- "Jangan lupa pelengkapnya bihun (sohun) dan keripik kentang. Jika ada taburi juga bawang goreng agar tambah sedeeep. Happy cooking..."
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Lunch

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/73c44ee4979ff875/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan olahan mantab untuk orang tercinta merupakan hal yang sangat menyenangkan bagi kita sendiri. Kewajiban seorang ibu Tidak saja mengerjakan pekerjaan rumah saja, tapi anda pun wajib memastikan keperluan nutrisi tercukupi dan juga santapan yang dimakan orang tercinta mesti nikmat.

Di waktu  saat ini, kita memang bisa mengorder hidangan yang sudah jadi meski tanpa harus ribet membuatnya lebih dulu. Tapi ada juga orang yang memang ingin memberikan hidangan yang terenak bagi orang yang dicintainya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai selera keluarga. 



Mungkinkah anda adalah seorang penggemar kare ayam solo?. Asal kamu tahu, kare ayam solo adalah hidangan khas di Nusantara yang sekarang digemari oleh banyak orang di hampir setiap tempat di Nusantara. Kalian bisa menyajikan kare ayam solo hasil sendiri di rumahmu dan dapat dijadikan santapan kesenanganmu di akhir pekan.

Anda jangan bingung jika kamu ingin mendapatkan kare ayam solo, sebab kare ayam solo mudah untuk ditemukan dan juga kita pun dapat membuatnya sendiri di tempatmu. kare ayam solo dapat diolah memalui bermacam cara. Saat ini sudah banyak resep kekinian yang menjadikan kare ayam solo lebih enak.

Resep kare ayam solo juga sangat gampang untuk dibuat, lho. Kita tidak perlu repot-repot untuk membeli kare ayam solo, tetapi Kalian mampu menghidangkan di rumah sendiri. Untuk Kita yang mau menghidangkannya, inilah resep menyajikan kare ayam solo yang enak yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Kare Ayam Solo:

1. Siapkan 800 gram ayam broiler/sekitar 8 potongan
1. Gunakan 500 ml santan kekentalan sedang
1. Sediakan 1 batang daun bawang
1. Siapkan 1 ikat kecil daun seledri
1. Sediakan 2 buah tomat
1. Sediakan sesuai selera Cabe rawit
1. Sediakan 1 buah wortel ukuran sedang
1. Gunakan 1/2 lingkaran kol
1. Ambil secukupnya Air
1. Gunakan  Minyak untuk menumis
1. Ambil  Bahan pelengkap
1. Gunakan  Keripik kentang
1. Siapkan  Bihun / sohun
1. Siapkan  Bumbu halus
1. Ambil 10 butir bawang merah
1. Gunakan 5 butir bawang putih
1. Siapkan 1/2 sdt jinten
1. Sediakan 1 sdt ketumbar bubuk
1. Gunakan 1 sdt kunyit halus
1. Gunakan 3 butir kemiri sangrai
1. Gunakan  Bumbu cemplung
1. Gunakan 1 jempol lengkuas, geprek
1. Sediakan 3 lbr daun salam
1. Ambil 1 btg sereh, geprek, simpulkan
1. Siapkan 1-2 sdt garam
1. Siapkan 1 sdt kaldu bubuk
1. Gunakan 2 sdt gula pasir




<!--inarticleads2-->

##### Cara membuat Kare Ayam Solo:

1. Siapkan semua bahan. Cuci cuci bersih.
1. Iris2 tomat, wortel, kol daun bawang dan seledri. Cabe rawit biarkan wutuhan. Siapkan santan kekentalan sedang.
1. Rebus ayam, buang dulu air rebusan pertama. Kemudian rebus lagi hingga keluar kaldu/minyaknya. Sisihkan
1. Haluskan bumbu halus. Panaskan 2 sdm minyak goreng di api sedang. Tumis bumbu halus, osreng sebentar, masukkan daun salam, lengkuas, sereh, kayu manis. Tumis hingga harum dan tanak.
1. Kemudian masukkan ayam yg telah direbus beserta air rebusannya. Tambahkan garam, gula pasir, kaldu bubuk. Masak hingga mendidih.
1. Lalu masukkan air santan, masak hingga mendidih dengan terus diaduk ya agar santan tidak pecah. Jika dirasa terlalu kental kuahnya bisa ditambahkan sedikit air lagi.
1. Setelah mendidih, masukkan potongan kol, wortel, tomat, daun bawang. Bolak balik. Sambil cek rasa ya. Terakhir masukkan daun seledri dan cabe rawit. Masak hingga kekentalan kuah yg diinginkan. Siap disajikan.
1. Jangan lupa pelengkapnya bihun (sohun) dan keripik kentang. Jika ada taburi juga bawang goreng agar tambah sedeeep. Happy cooking...




Ternyata cara buat kare ayam solo yang lezat tidak rumit ini gampang banget ya! Kamu semua dapat mencobanya. Cara Membuat kare ayam solo Cocok sekali untuk kalian yang sedang belajar memasak maupun bagi kalian yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba buat resep kare ayam solo enak sederhana ini? Kalau ingin, mending kamu segera siapin alat dan bahannya, maka buat deh Resep kare ayam solo yang enak dan tidak ribet ini. Betul-betul gampang kan. 

Maka, ketimbang kamu berlama-lama, maka langsung aja bikin resep kare ayam solo ini. Dijamin kamu tak akan menyesal sudah buat resep kare ayam solo nikmat simple ini! Selamat berkreasi dengan resep kare ayam solo mantab simple ini di rumah kalian masing-masing,ya!.

