---
description: "Resep Kare Ayam Solo yang lezat Untuk Jualan"
title: "Resep Kare Ayam Solo yang lezat Untuk Jualan"
slug: 86-resep-kare-ayam-solo-yang-lezat-untuk-jualan
date: 2021-03-28T23:00:10.680Z
image: https://img-global.cpcdn.com/recipes/496033d2873eaf3d/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/496033d2873eaf3d/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/496033d2873eaf3d/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Frank Lowe
ratingvalue: 4.2
reviewcount: 8
recipeingredient:
- "1/2 kg ayam potong 2 me dada buang kulit"
- "1 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "1 liter air"
- "1 sachet santan instan 65 ml"
- "1 sdt munjung gulpas"
- "1/2 sdt kaldu bubuk"
- " Garam"
- " Bumbu Halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "1/2 sdt kunyit bubuk"
- "1 sdt ketumbar bubuk"
- "1/4 sdt Lada bubuk"
- "1/4 sdt jinten"
- "1 cm jahe"
- " Pelengkap "
- "2 buah wortel potong2 lalu rebus"
- " Tauge seduh air panas saya skip"
- "2 batang daun bawang iris"
recipeinstructions:
- "Cuci bersih ayam, lumuri dengan garam. Diamkan 10 menit, lalu bilas hingga bersih. Rebus ayam dalam air mendidih, sampai berubah warna. (saya sampai benar2 matang). Angkat, buang air rebusan."
- "Panaskan minyak, tumis bumbu Halus, masukkan serai, daun Jeruk, daun salam, lengkuas. Masak hingga wangi dan matang. Masukkan ayam, aduk rata."
- "Tuang air, didihkan. Bumbui dengan garam, gula pasir, kaldu bubuk, merica. Masukkan santan. Masak hingga ayam empuk, koreksi rasa."
- "Masukkan wortel dan daun bawang, aduk sebentar. Matikan kompor. Note :sebetulnya cara penyajian, wortel dan tauge ditata di piring saji, masukkan ayam, siram dengan kuah. Kalau saya pakai cara praktis saja."
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 257 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dinner

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/496033d2873eaf3d/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan hidangan menggugah selera untuk keluarga merupakan hal yang membahagiakan bagi kita sendiri. Tugas seorang ibu Tidak cuma mengatur rumah saja, tetapi kamu pun wajib memastikan kebutuhan gizi tercukupi dan juga panganan yang dimakan anak-anak harus mantab.

Di waktu  sekarang, kamu sebenarnya dapat mengorder hidangan yang sudah jadi meski tidak harus repot mengolahnya lebih dulu. Tapi ada juga orang yang selalu ingin menghidangkan yang terlezat bagi keluarganya. Sebab, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga tercinta. 



Mungkinkah anda adalah seorang penikmat kare ayam solo?. Tahukah kamu, kare ayam solo adalah hidangan khas di Nusantara yang sekarang digemari oleh setiap orang di berbagai tempat di Indonesia. Kita dapat menghidangkan kare ayam solo sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di hari libur.

Kita jangan bingung untuk mendapatkan kare ayam solo, karena kare ayam solo tidak sukar untuk ditemukan dan juga kalian pun bisa membuatnya sendiri di rumah. kare ayam solo boleh diolah lewat bermacam cara. Kini pun sudah banyak sekali cara kekinian yang menjadikan kare ayam solo semakin lebih lezat.

Resep kare ayam solo pun sangat mudah dibuat, lho. Kita tidak usah capek-capek untuk membeli kare ayam solo, karena Kalian dapat menyiapkan di rumahmu. Untuk Kamu yang mau membuatnya, inilah cara untuk menyajikan kare ayam solo yang lezat yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Kare Ayam Solo:

1. Gunakan 1/2 kg ayam, potong 2 (me :dada, buang kulit)
1. Siapkan 1 lembar daun salam
1. Sediakan 3 lembar daun jeruk
1. Siapkan 1 batang serai, geprek
1. Siapkan 1 liter air
1. Gunakan 1 sachet santan instan (65 ml)
1. Ambil 1 sdt munjung gulpas
1. Sediakan 1/2 sdt kaldu bubuk
1. Siapkan  Garam
1. Siapkan  Bumbu Halus :
1. Ambil 5 siung bawang merah
1. Ambil 3 siung bawang putih
1. Ambil 3 butir kemiri
1. Siapkan 1/2 sdt kunyit bubuk
1. Siapkan 1 sdt ketumbar bubuk
1. Sediakan 1/4 sdt Lada bubuk
1. Sediakan 1/4 sdt jinten
1. Sediakan 1 cm jahe
1. Sediakan  Pelengkap :
1. Gunakan 2 buah wortel, potong2, lalu rebus
1. Siapkan  Tauge, seduh air panas (saya skip)
1. Gunakan 2 batang daun bawang, iris




<!--inarticleads2-->

##### Langkah-langkah membuat Kare Ayam Solo:

1. Cuci bersih ayam, lumuri dengan garam. Diamkan 10 menit, lalu bilas hingga bersih. Rebus ayam dalam air mendidih, sampai berubah warna. (saya sampai benar2 matang). Angkat, buang air rebusan.
1. Panaskan minyak, tumis bumbu Halus, masukkan serai, daun Jeruk, daun salam, lengkuas. Masak hingga wangi dan matang. Masukkan ayam, aduk rata.
1. Tuang air, didihkan. Bumbui dengan garam, gula pasir, kaldu bubuk, merica. Masukkan santan. Masak hingga ayam empuk, koreksi rasa.
1. Masukkan wortel dan daun bawang, aduk sebentar. Matikan kompor. Note :sebetulnya cara penyajian, wortel dan tauge ditata di piring saji, masukkan ayam, siram dengan kuah. Kalau saya pakai cara praktis saja.




Wah ternyata cara buat kare ayam solo yang enak simple ini enteng banget ya! Anda Semua bisa memasaknya. Resep kare ayam solo Sangat sesuai sekali buat kalian yang sedang belajar memasak maupun bagi anda yang telah pandai memasak.

Tertarik untuk mulai mencoba bikin resep kare ayam solo enak simple ini? Kalau kalian ingin, ayo kalian segera buruan siapkan alat dan bahan-bahannya, kemudian bikin deh Resep kare ayam solo yang nikmat dan simple ini. Sungguh gampang kan. 

Oleh karena itu, ketimbang kalian berfikir lama-lama, maka kita langsung saja sajikan resep kare ayam solo ini. Pasti kamu tiidak akan menyesal sudah buat resep kare ayam solo nikmat sederhana ini! Selamat berkreasi dengan resep kare ayam solo nikmat sederhana ini di rumah kalian masing-masing,ya!.

