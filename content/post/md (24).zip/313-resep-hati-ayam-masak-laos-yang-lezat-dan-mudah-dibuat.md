---
description: "Resep Hati Ayam Masak Laos yang lezat dan Mudah Dibuat"
title: "Resep Hati Ayam Masak Laos yang lezat dan Mudah Dibuat"
slug: 313-resep-hati-ayam-masak-laos-yang-lezat-dan-mudah-dibuat
date: 2021-04-09T12:02:46.780Z
image: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
author: Peter Kennedy
ratingvalue: 4.5
reviewcount: 8
recipeingredient:
- "300 gr Hati Ayam"
- "1 buah jeruk nipis"
- "2 lembar daun salam"
- "2 batang sereh keprek"
- "Secukupnya garamgulakaldu bubuk"
- "50 g laos  lengkuas diblender"
- "Secukupnya air dan minyak goreng"
- " Bumbu halus"
- "5 bawang merah"
- "3 bawang putih"
- "3 buah kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "Sejumput jinten"
- "1 sdm ketumbar"
recipeinstructions:
- "Cuci bersih hati ayam, beri air jeruk nipis, ratakan dan diamkan 5 menit, kemudian bilas hingga bersih."
- "Blender laos atau diparut. Ukek atau proses bumbu halusnya."
- "Panaskan minyak dan tumis bumbu halus hingga tercium aroma yang harum, lalu masukkan serai dan daun salam, dan laos parut."
- "Masukkan hati ayam, aduk perlahan jingga hati ayam berubah warna dan kaku. Setelah itu beri air, garam, gula dan kaldu bubuk. Cek rasa.. Masak hingga airnya sat."
- "Kemudian goreng hati ayam hingga kecoklatan dan bumbu laosnya mengering. Jadi deh🥰"
categories:
- Resep
tags:
- hati
- ayam
- masak

katakunci: hati ayam masak 
nutrition: 160 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dinner

---


![Hati Ayam Masak Laos](https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, mempersiapkan hidangan lezat pada keluarga merupakan hal yang memuaskan bagi kita sendiri. Kewajiban seorang  wanita Tidak sekedar mengurus rumah saja, tetapi anda pun harus menyediakan keperluan nutrisi terpenuhi dan juga masakan yang disantap orang tercinta mesti lezat.

Di masa  sekarang, kalian sebenarnya bisa memesan panganan praktis meski tidak harus capek mengolahnya dulu. Namun ada juga lho orang yang memang ingin memberikan makanan yang terbaik untuk keluarganya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai kesukaan famili. 



Apakah anda adalah seorang penikmat hati ayam masak laos?. Asal kamu tahu, hati ayam masak laos adalah makanan khas di Nusantara yang kini disukai oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Anda bisa memasak hati ayam masak laos buatan sendiri di rumahmu dan dapat dijadikan makanan kesukaanmu di hari liburmu.

Kita tak perlu bingung untuk memakan hati ayam masak laos, karena hati ayam masak laos sangat mudah untuk ditemukan dan kita pun bisa membuatnya sendiri di rumah. hati ayam masak laos dapat dibuat lewat beraneka cara. Saat ini sudah banyak sekali resep modern yang menjadikan hati ayam masak laos semakin mantap.

Resep hati ayam masak laos pun gampang sekali dibikin, lho. Kalian jangan capek-capek untuk membeli hati ayam masak laos, tetapi Kita dapat membuatnya di rumahmu. Bagi Anda yang akan menghidangkannya, inilah resep untuk menyajikan hati ayam masak laos yang mantab yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Hati Ayam Masak Laos:

1. Gunakan 300 gr Hati Ayam
1. Gunakan 1 buah jeruk nipis
1. Ambil 2 lembar daun salam
1. Siapkan 2 batang sereh keprek
1. Sediakan Secukupnya garam,gula,kaldu bubuk
1. Sediakan 50 g laos / lengkuas diblender
1. Siapkan Secukupnya air dan minyak goreng
1. Gunakan  Bumbu halus:
1. Sediakan 5 bawang merah
1. Gunakan 3 bawang putih
1. Ambil 3 buah kemiri
1. Siapkan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Siapkan Sejumput jinten
1. Ambil 1 sdm ketumbar




<!--inarticleads2-->

##### Langkah-langkah membuat Hati Ayam Masak Laos:

1. Cuci bersih hati ayam, beri air jeruk nipis, ratakan dan diamkan 5 menit, kemudian bilas hingga bersih.
1. Blender laos atau diparut. Ukek atau proses bumbu halusnya.
1. Panaskan minyak dan tumis bumbu halus hingga tercium aroma yang harum, lalu masukkan serai dan daun salam, dan laos parut.
1. Masukkan hati ayam, aduk perlahan jingga hati ayam berubah warna dan kaku. Setelah itu beri air, garam, gula dan kaldu bubuk. Cek rasa.. Masak hingga airnya sat.
1. Kemudian goreng hati ayam hingga kecoklatan dan bumbu laosnya mengering. Jadi deh🥰




Ternyata cara buat hati ayam masak laos yang enak tidak rumit ini enteng sekali ya! Kita semua dapat memasaknya. Resep hati ayam masak laos Sesuai banget buat kamu yang baru belajar memasak ataupun juga bagi anda yang telah lihai dalam memasak.

Apakah kamu ingin mencoba membuat resep hati ayam masak laos nikmat tidak ribet ini? Kalau ingin, mending kamu segera siapkan alat dan bahan-bahannya, lalu buat deh Resep hati ayam masak laos yang nikmat dan tidak ribet ini. Benar-benar mudah kan. 

Jadi, ketimbang kita diam saja, yuk kita langsung saja sajikan resep hati ayam masak laos ini. Dijamin kamu gak akan nyesel sudah buat resep hati ayam masak laos nikmat tidak rumit ini! Selamat berkreasi dengan resep hati ayam masak laos mantab sederhana ini di rumah masing-masing,ya!.

