---
description: "Cara membuat Ayam Kecap ala Simple Rudy Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam Kecap ala Simple Rudy Sederhana dan Mudah Dibuat"
slug: 121-cara-membuat-ayam-kecap-ala-simple-rudy-sederhana-dan-mudah-dibuat
date: 2021-04-18T19:07:29.260Z
image: https://img-global.cpcdn.com/recipes/7d03a5b02589a374/680x482cq70/ayam-kecap-ala-simple-rudy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7d03a5b02589a374/680x482cq70/ayam-kecap-ala-simple-rudy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7d03a5b02589a374/680x482cq70/ayam-kecap-ala-simple-rudy-foto-resep-utama.jpg
author: Dorothy Turner
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "500 gr ayam aku filet"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "3 cm jahe"
- "2 lembar daun salam"
- "1/2 bawang bombay tambahan saya sendiri"
- "secukupnya Air"
- " Campur dalam mangkok"
- "6 sdm kecap manis"
- "1 sdm kecap asin"
- "1 sdt gula"
- "1 sdt garam"
- "1 sdt lada"
recipeinstructions:
- "Tumis bawang merah dan bawang putih yang sudah diiris tipis hingga harum. Kemudian masukkan jahe geprek dan daun salam. Masak hingga harum dan layu"
- "Masukan ayam (jika pakai ayam bertulang lebih baik digoreng setengah matang dulu agar tidak terlihat putih mulus nanti saat ketemu kecap). Aduk-aduk hingga ayam setengah matang"
- "Masukkan pasukan kecap yang sudah dicampur dalam satu mangkok. Aduk rata tunggu hingga kecap berbuih."
- "Setelah berbuih tambahkan air sesuai selera dan bawang bombay. Tutup hingga air menyusut sesuai selera."
- "Ayam kecap siap disajikan"
categories:
- Resep
tags:
- ayam
- kecap
- ala

katakunci: ayam kecap ala 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Kecap ala Simple Rudy](https://img-global.cpcdn.com/recipes/7d03a5b02589a374/680x482cq70/ayam-kecap-ala-simple-rudy-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan santapan enak bagi orang tercinta adalah hal yang mengasyikan bagi kita sendiri. Kewajiban seorang istri bukan sekedar mengerjakan pekerjaan rumah saja, tetapi anda juga harus menyediakan kebutuhan nutrisi tercukupi dan masakan yang disantap keluarga tercinta mesti mantab.

Di waktu  sekarang, kita sebenarnya bisa membeli masakan jadi walaupun tanpa harus repot memasaknya dahulu. Tapi banyak juga lho mereka yang selalu mau menyajikan yang terbaik untuk orang tercintanya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 



Apakah anda seorang penggemar ayam kecap ala simple rudy?. Asal kamu tahu, ayam kecap ala simple rudy merupakan hidangan khas di Indonesia yang kini digemari oleh orang-orang dari berbagai tempat di Indonesia. Kita bisa menyajikan ayam kecap ala simple rudy sendiri di rumah dan pasti jadi hidangan favorit di hari libur.

Kalian tak perlu bingung jika kamu ingin memakan ayam kecap ala simple rudy, sebab ayam kecap ala simple rudy gampang untuk dicari dan juga kita pun bisa menghidangkannya sendiri di rumah. ayam kecap ala simple rudy boleh diolah dengan berbagai cara. Kini telah banyak resep modern yang menjadikan ayam kecap ala simple rudy semakin mantap.

Resep ayam kecap ala simple rudy juga gampang sekali untuk dibikin, lho. Kalian jangan capek-capek untuk memesan ayam kecap ala simple rudy, karena Kita bisa menyajikan di rumahmu. Untuk Kalian yang akan menyajikannya, berikut cara membuat ayam kecap ala simple rudy yang lezat yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Kecap ala Simple Rudy:

1. Sediakan 500 gr ayam (aku filet)
1. Gunakan 5 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Siapkan 3 cm jahe
1. Siapkan 2 lembar daun salam
1. Siapkan 1/2 bawang bombay (tambahan saya sendiri)
1. Sediakan secukupnya Air
1. Gunakan  Campur dalam mangkok
1. Siapkan 6 sdm kecap manis
1. Ambil 1 sdm kecap asin
1. Gunakan 1 sdt gula
1. Siapkan 1 sdt garam
1. Sediakan 1 sdt lada




<!--inarticleads2-->

##### Cara membuat Ayam Kecap ala Simple Rudy:

1. Tumis bawang merah dan bawang putih yang sudah diiris tipis hingga harum. Kemudian masukkan jahe geprek dan daun salam. Masak hingga harum dan layu
1. Masukan ayam (jika pakai ayam bertulang lebih baik digoreng setengah matang dulu agar tidak terlihat putih mulus nanti saat ketemu kecap). Aduk-aduk hingga ayam setengah matang
1. Masukkan pasukan kecap yang sudah dicampur dalam satu mangkok. Aduk rata tunggu hingga kecap berbuih.
1. Setelah berbuih tambahkan air sesuai selera dan bawang bombay. Tutup hingga air menyusut sesuai selera.
1. Ayam kecap siap disajikan




Ternyata cara membuat ayam kecap ala simple rudy yang mantab tidak rumit ini mudah banget ya! Kita semua mampu memasaknya. Resep ayam kecap ala simple rudy Sesuai banget buat kamu yang baru mau belajar memasak ataupun untuk kalian yang telah pandai memasak.

Apakah kamu ingin mulai mencoba bikin resep ayam kecap ala simple rudy mantab tidak ribet ini? Kalau kamu ingin, ayo kalian segera siapin alat-alat dan bahan-bahannya, kemudian bikin deh Resep ayam kecap ala simple rudy yang lezat dan simple ini. Sangat mudah kan. 

Maka dari itu, daripada kamu diam saja, hayo kita langsung buat resep ayam kecap ala simple rudy ini. Dijamin anda tak akan menyesal sudah buat resep ayam kecap ala simple rudy nikmat sederhana ini! Selamat mencoba dengan resep ayam kecap ala simple rudy enak tidak rumit ini di rumah masing-masing,ya!.

