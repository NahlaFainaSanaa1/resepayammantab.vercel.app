---
description: "Bahan-bahan Ayam Goreng Bumbu ungkep empuk yang enak dan Mudah Dibuat"
title: "Bahan-bahan Ayam Goreng Bumbu ungkep empuk yang enak dan Mudah Dibuat"
slug: 493-bahan-bahan-ayam-goreng-bumbu-ungkep-empuk-yang-enak-dan-mudah-dibuat
date: 2021-03-25T09:03:24.527Z
image: https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg
author: Aaron Daniels
ratingvalue: 4.5
reviewcount: 13
recipeingredient:
- "2 kilo ayam biasa"
- "1 kilo dipotong 12 potong"
- "2 buah jeruk nipis"
- "4 batang sereh geprek"
- "4 lembar daun salam"
- "6 lembar daun jeruk"
- "Secukupnya garam"
- "Secukupnya penyedap rasa ayam  kaldu Jamur"
- "300 ml air"
- " Bumbu halus "
- "20 siung bawang merah"
- "10 siung bawang putih"
- "1 jempol jahe"
- "1 jempol kunyit"
- "1 jmpol lengkuas"
- "2 sdm ketumbar bubuk"
- "1 sdm ladabubuk"
recipeinstructions:
- "Cuci bersih ayam,Marinasi dngan jeruk nipis diamkan 15 mnt,lalu Cuci bersih ayam tiriskan"
- "Haluskan bumbu lalu balurkan bumbu halus ke potongan ayam. Tambahkan sereh, daun salam, daun jeruk, garam dan penyedap rasa ayam. Aduk rata. Lalu beri air."
- "Masak atau ungkep ayam dengan api kecil sampai ayam matang. Jangan lupa ditutup agar matang sempurna. Angkat."
- ""
- "Goreng ayam sampai berwarna coklat keemasan."
- "Sajikan dengan nasi panas Dan sambal goreng nikmat alhamdulillh 😍🥰❤️💋"
categories:
- Resep
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 293 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Goreng Bumbu ungkep empuk](https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyediakan olahan sedap buat orang tercinta merupakan hal yang membahagiakan bagi kita sendiri. Tanggung jawab seorang istri bukan cuma mengatur rumah saja, namun kamu juga harus memastikan keperluan nutrisi tercukupi dan panganan yang disantap keluarga tercinta wajib nikmat.

Di zaman  sekarang, kita memang dapat memesan santapan jadi walaupun tidak harus susah membuatnya lebih dulu. Namun ada juga lho orang yang memang mau memberikan hidangan yang terlezat untuk orang yang dicintainya. Pasalnya, menyajikan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan kesukaan orang tercinta. 



Mungkinkah anda adalah seorang penyuka ayam goreng bumbu ungkep empuk?. Tahukah kamu, ayam goreng bumbu ungkep empuk adalah makanan khas di Nusantara yang sekarang disukai oleh kebanyakan orang di hampir setiap daerah di Nusantara. Kalian dapat menghidangkan ayam goreng bumbu ungkep empuk sendiri di rumahmu dan boleh jadi makanan favorit di akhir pekan.

Kamu tak perlu bingung untuk menyantap ayam goreng bumbu ungkep empuk, lantaran ayam goreng bumbu ungkep empuk tidak sulit untuk ditemukan dan juga kalian pun dapat memasaknya sendiri di rumah. ayam goreng bumbu ungkep empuk dapat dimasak memalui beraneka cara. Kini pun sudah banyak banget cara kekinian yang membuat ayam goreng bumbu ungkep empuk lebih mantap.

Resep ayam goreng bumbu ungkep empuk juga mudah sekali dibuat, lho. Anda jangan capek-capek untuk memesan ayam goreng bumbu ungkep empuk, karena Kamu dapat menyiapkan di rumah sendiri. Bagi Kalian yang mau menyajikannya, dibawah ini merupakan cara membuat ayam goreng bumbu ungkep empuk yang nikamat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Goreng Bumbu ungkep empuk:

1. Ambil 2 kilo ayam biasa
1. Siapkan 1 kilo dipotong 12 potong
1. Gunakan 2 buah jeruk nipis
1. Ambil 4 batang sereh, geprek
1. Siapkan 4 lembar daun salam
1. Ambil 6 lembar daun jeruk
1. Gunakan Secukupnya garam
1. Sediakan Secukupnya penyedap rasa ayam / kaldu Jamur
1. Ambil 300 ml air
1. Ambil  Bumbu halus :
1. Ambil 20 siung bawang merah
1. Sediakan 10 siung bawang putih
1. Ambil 1 jempol jahe
1. Sediakan 1 jempol kunyit
1. Siapkan 1 jmpol lengkuas
1. Siapkan 2 sdm ketumbar bubuk
1. Ambil 1 sdm ladabubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Bumbu ungkep empuk:

1. Cuci bersih ayam,Marinasi dngan jeruk nipis diamkan 15 mnt,lalu Cuci bersih ayam tiriskan
1. Haluskan bumbu lalu balurkan bumbu halus ke potongan ayam. Tambahkan sereh, daun salam, daun jeruk, garam dan penyedap rasa ayam. Aduk rata. Lalu beri air.
1. Masak atau ungkep ayam dengan api kecil sampai ayam matang. Jangan lupa ditutup agar matang sempurna. Angkat.
1. 
1. Goreng ayam sampai berwarna coklat keemasan.
1. Sajikan dengan nasi panas Dan sambal goreng nikmat alhamdulillh 😍🥰❤️💋




Ternyata resep ayam goreng bumbu ungkep empuk yang lezat sederhana ini enteng banget ya! Anda Semua bisa menghidangkannya. Cara buat ayam goreng bumbu ungkep empuk Sangat sesuai sekali buat anda yang baru belajar memasak ataupun bagi kamu yang telah hebat dalam memasak.

Apakah kamu mau mulai mencoba buat resep ayam goreng bumbu ungkep empuk enak sederhana ini? Kalau tertarik, ayo kamu segera siapin alat-alat dan bahan-bahannya, setelah itu bikin deh Resep ayam goreng bumbu ungkep empuk yang lezat dan simple ini. Betul-betul gampang kan. 

Jadi, daripada anda diam saja, maka langsung aja buat resep ayam goreng bumbu ungkep empuk ini. Dijamin kamu tiidak akan menyesal sudah membuat resep ayam goreng bumbu ungkep empuk nikmat tidak rumit ini! Selamat mencoba dengan resep ayam goreng bumbu ungkep empuk enak sederhana ini di tempat tinggal sendiri,oke!.

