---
description: "Cara buat Lontong Opor Ayam dan Sambal Goreng Ati Ampela yang nikmat Untuk Jualan"
title: "Cara buat Lontong Opor Ayam dan Sambal Goreng Ati Ampela yang nikmat Untuk Jualan"
slug: 399-cara-buat-lontong-opor-ayam-dan-sambal-goreng-ati-ampela-yang-nikmat-untuk-jualan
date: 2021-06-05T02:54:24.729Z
image: https://img-global.cpcdn.com/recipes/896180bc7c86fc47/680x482cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/896180bc7c86fc47/680x482cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/896180bc7c86fc47/680x482cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-foto-resep-utama.jpg
author: Myrtie Armstrong
ratingvalue: 3.6
reviewcount: 9
recipeingredient:
- "500 gr beras"
- "1 lbr daun pandan"
- "10 pcs cetakan lontong"
- "10 lbr daun pisangpotong sesuai cetakan"
- "3-4 ltr air"
- " Pelengkap Resep Opor Ayam            lihat resep"
- "2 bh santan instan tambahkan pada Opor"
- " Pelengkap Resep Sambal Goreng Ati Ampela Kentang Tahu           lihat resep"
recipeinstructions:
- "Cuci bersih beras. Rendam beras sebentar."
- "Bentuk pola pada daun mengikuti cetakan. Terdiri dari pola persegi panjang (untuk badan) dan pola lingkaran (untuk tutup). Kemudian masukkan daun pada cetakan. Masukkan beras sekitar 3/4 cetakan (untuk beras biasa/pulen) dan 1/2 cetakan (untuk beras pera)."
- "Panaskan air dalam pressure cooker, masukkan cetakan lontong berisi beras tadi hingga terendam semua. Lalu tutup rapat, dan lanjutkan memasak lontong hingga 30 menit. Matikan api, biarkan hingga pressure cooker tidak mengeluarkan uap lagi. Baru tutup dibuka dan keluarkan lontong dari dalam panci."
- "Setelah agak hangat, keluarkan lontong dari cetakan. Lontong siap dinikmati dengan sayur kesukaan."
- "Sajikan lontong bersama Opor Ayam (yang sudah ditambahkan santan kali ini).           (lihat resep)"
- "Tambahkan sambal goreng ati ampela kentang tahu.           (lihat resep)"
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 263 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dinner

---


![Lontong Opor Ayam dan Sambal Goreng Ati Ampela](https://img-global.cpcdn.com/recipes/896180bc7c86fc47/680x482cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan olahan lezat kepada keluarga adalah suatu hal yang mengasyikan untuk kita sendiri. Peran seorang istri bukan sekadar menangani rumah saja, tetapi kamu juga harus memastikan kebutuhan gizi tercukupi dan masakan yang dimakan keluarga tercinta harus menggugah selera.

Di era  sekarang, kalian memang mampu mengorder masakan instan tanpa harus ribet memasaknya dahulu. Tetapi ada juga lho mereka yang memang ingin memberikan hidangan yang terenak untuk orang yang dicintainya. Karena, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penyuka lontong opor ayam dan sambal goreng ati ampela?. Tahukah kamu, lontong opor ayam dan sambal goreng ati ampela adalah makanan khas di Indonesia yang saat ini disukai oleh banyak orang dari hampir setiap wilayah di Indonesia. Kalian bisa menghidangkan lontong opor ayam dan sambal goreng ati ampela hasil sendiri di rumah dan boleh jadi makanan favoritmu di hari libur.

Kita jangan bingung jika kamu ingin menyantap lontong opor ayam dan sambal goreng ati ampela, lantaran lontong opor ayam dan sambal goreng ati ampela gampang untuk didapatkan dan kamu pun dapat memasaknya sendiri di tempatmu. lontong opor ayam dan sambal goreng ati ampela boleh dimasak lewat berbagai cara. Saat ini sudah banyak banget cara kekinian yang membuat lontong opor ayam dan sambal goreng ati ampela lebih lezat.

Resep lontong opor ayam dan sambal goreng ati ampela juga sangat gampang dihidangkan, lho. Kalian tidak usah capek-capek untuk membeli lontong opor ayam dan sambal goreng ati ampela, lantaran Kita dapat menyajikan di rumahmu. Untuk Kamu yang akan menghidangkannya, berikut cara membuat lontong opor ayam dan sambal goreng ati ampela yang lezat yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Lontong Opor Ayam dan Sambal Goreng Ati Ampela:

1. Ambil 500 gr beras
1. Siapkan 1 lbr daun pandan
1. Sediakan 10 pcs cetakan lontong
1. Ambil 10 lbr daun pisang,potong sesuai cetakan
1. Siapkan 3-4 ltr air
1. Gunakan  Pelengkap Resep Opor Ayam :           (lihat resep)
1. Siapkan 2 bh santan instan (tambahkan pada Opor)
1. Sediakan  Pelengkap Resep Sambal Goreng Ati Ampela Kentang Tahu:           (lihat resep)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Lontong Opor Ayam dan Sambal Goreng Ati Ampela:

1. Cuci bersih beras. Rendam beras sebentar.
<img src="https://img-global.cpcdn.com/steps/d8c4b4dd4a08816d/160x128cq70/lontong-opor-ayam-dan-sambal-goreng-ati-ampela-langkah-memasak-1-foto.jpg" alt="Lontong Opor Ayam dan Sambal Goreng Ati Ampela">1. Bentuk pola pada daun mengikuti cetakan. Terdiri dari pola persegi panjang (untuk badan) dan pola lingkaran (untuk tutup). Kemudian masukkan daun pada cetakan. Masukkan beras sekitar 3/4 cetakan (untuk beras biasa/pulen) dan 1/2 cetakan (untuk beras pera).
1. Panaskan air dalam pressure cooker, masukkan cetakan lontong berisi beras tadi hingga terendam semua. Lalu tutup rapat, dan lanjutkan memasak lontong hingga 30 menit. Matikan api, biarkan hingga pressure cooker tidak mengeluarkan uap lagi. Baru tutup dibuka dan keluarkan lontong dari dalam panci.
1. Setelah agak hangat, keluarkan lontong dari cetakan. Lontong siap dinikmati dengan sayur kesukaan.
1. Sajikan lontong bersama Opor Ayam (yang sudah ditambahkan santan kali ini). -           (lihat resep)
1. Tambahkan sambal goreng ati ampela kentang tahu. -           (lihat resep)




Ternyata resep lontong opor ayam dan sambal goreng ati ampela yang lezat simple ini mudah sekali ya! Anda Semua dapat membuatnya. Resep lontong opor ayam dan sambal goreng ati ampela Sangat cocok sekali buat anda yang baru mau belajar memasak ataupun juga bagi kalian yang sudah jago dalam memasak.

Apakah kamu mau mulai mencoba bikin resep lontong opor ayam dan sambal goreng ati ampela nikmat simple ini? Kalau kalian tertarik, yuk kita segera siapkan alat dan bahannya, lalu bikin deh Resep lontong opor ayam dan sambal goreng ati ampela yang mantab dan simple ini. Sungguh mudah kan. 

Oleh karena itu, daripada kalian berfikir lama-lama, yuk langsung aja buat resep lontong opor ayam dan sambal goreng ati ampela ini. Dijamin kamu tiidak akan nyesel sudah bikin resep lontong opor ayam dan sambal goreng ati ampela mantab tidak rumit ini! Selamat berkreasi dengan resep lontong opor ayam dan sambal goreng ati ampela lezat tidak rumit ini di tempat tinggal masing-masing,ya!.

