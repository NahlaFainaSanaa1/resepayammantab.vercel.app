---
description: "Bahan-bahan Kare Ayam Solo yang enak dan Mudah Dibuat"
title: "Bahan-bahan Kare Ayam Solo yang enak dan Mudah Dibuat"
slug: 85-bahan-bahan-kare-ayam-solo-yang-enak-dan-mudah-dibuat
date: 2021-05-10T02:26:29.009Z
image: https://img-global.cpcdn.com/recipes/a5fc6aceb2e2f1cf/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a5fc6aceb2e2f1cf/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a5fc6aceb2e2f1cf/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Micheal Davis
ratingvalue: 3.9
reviewcount: 10
recipeingredient:
- "1/2 kg ayam potong2"
- "1 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "1 ruas lengkuas geprek"
- "65 ml santan instan"
- "secukupnya Garam gula dan kaldu bubuk"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "1 sdt ketumbar bubuk"
- "1/4 sdt jintan"
- "1/4 sdt lada bubuk"
- "2 cm kunyit"
- " Bahan pelengkap"
- " Wortel diiris rebus"
- " Toge diseduh dengan air panas tiriskan"
- " Daun bawang"
- " Bawang goreng"
recipeinstructions:
- "Didihkan air. Rebus ayam hingga berubah warna/setengah matang. Tiriskan ayam. Buang air rebusan nya. Didihkan kembali ayam dengan air yang baru.."
- "Tumis bumbu halus dan rempah2 sampai harum"
- "Tuang tumisan ke rebusan ayam. Beri garam gula dan kaldu bubuk. Test rasa. Masukkan santan. Aduk2, test rasa"
- "Siapkan sayuran"
- "Tata sayuran di mangkok/piring. Tuang ayam dan kuahnya. Beri taburan daun bawang dan bawang goreng. Sajikan hangat 😋"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 176 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Dessert

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/a5fc6aceb2e2f1cf/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan masakan sedap untuk orang tercinta adalah suatu hal yang memuaskan bagi kamu sendiri. Kewajiban seorang istri Tidak sekadar mengurus rumah saja, tetapi anda pun wajib memastikan kebutuhan gizi terpenuhi dan panganan yang dikonsumsi anak-anak mesti lezat.

Di masa  sekarang, kamu memang dapat memesan santapan jadi meski tidak harus capek membuatnya terlebih dahulu. Namun banyak juga orang yang memang ingin memberikan makanan yang terenak untuk orang yang dicintainya. Sebab, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan orang tercinta. 

Assalmualaikum moms.alhamdulillah anggota rumah baru flu semua, tandanya Alloh masih sayang kita disuruh mengistirahatkan badan sejenak spy pulih lg tenaganya. Karena tenggorokan pd lagi radang dan batuk juga, akhirnya saya buat rebusan nanas buat semua, tp si kecil. Salah satu makanan khas kota kelahiran yg selalu ngangenin.

Mungkinkah kamu salah satu penggemar kare ayam solo?. Asal kamu tahu, kare ayam solo merupakan sajian khas di Indonesia yang saat ini disenangi oleh orang-orang dari berbagai tempat di Nusantara. Kamu bisa menyajikan kare ayam solo sendiri di rumahmu dan dapat dijadikan camilan kesukaanmu di hari liburmu.

Kalian tak perlu bingung untuk menyantap kare ayam solo, lantaran kare ayam solo sangat mudah untuk didapatkan dan juga kamu pun dapat memasaknya sendiri di rumah. kare ayam solo boleh dibuat memalui bermacam cara. Saat ini sudah banyak banget cara kekinian yang membuat kare ayam solo semakin lezat.

Resep kare ayam solo pun mudah sekali dibikin, lho. Kita jangan ribet-ribet untuk membeli kare ayam solo, karena Kalian bisa membuatnya ditempatmu. Bagi Kita yang hendak membuatnya, berikut cara untuk menyajikan kare ayam solo yang enak yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Kare Ayam Solo:

1. Ambil 1/2 kg ayam, potong2
1. Ambil 1 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Sediakan 1 batang serai, geprek
1. Siapkan 1 ruas lengkuas, geprek
1. Siapkan 65 ml santan instan
1. Gunakan secukupnya Garam gula dan kaldu bubuk
1. Sediakan  Bumbu halus
1. Siapkan 5 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Siapkan 3 butir kemiri
1. Sediakan 1 sdt ketumbar bubuk
1. Gunakan 1/4 sdt jintan
1. Sediakan 1/4 sdt lada bubuk
1. Ambil 2 cm kunyit
1. Gunakan  Bahan pelengkap
1. Ambil  Wortel, diiris, rebus
1. Ambil  Toge, diseduh dengan air panas, tiriskan
1. Gunakan  Daun bawang
1. Siapkan  Bawang goreng


Kare Ayam siap disajikan dengan suiran ayam di atasnya dan Taburkan daun Seledri. Com - Kari ayam merupakan makanan khas Indonesia yang memiliki rasa gurih dan cocok untuk dijadikan hidangan menu buka puasa. Salah satu menu yang sangat populer dikalangan masyarakat yaitu kari ayam khas Solo. Lihat juga resep Kare Ayam Solo enak lainnya. 

<!--inarticleads2-->

##### Cara membuat Kare Ayam Solo:

1. Didihkan air. Rebus ayam hingga berubah warna/setengah matang. Tiriskan ayam. Buang air rebusan nya. Didihkan kembali ayam dengan air yang baru..
1. Tumis bumbu halus dan rempah2 sampai harum
1. Tuang tumisan ke rebusan ayam. Beri garam gula dan kaldu bubuk. Test rasa. Masukkan santan. Aduk2, test rasa
1. Siapkan sayuran
1. Tata sayuran di mangkok/piring. Tuang ayam dan kuahnya. Beri taburan daun bawang dan bawang goreng. Sajikan hangat 😋


Hidangan ayam memang selalu menggugah selera dan menggoda. Sudahkan anda memasak hidangan untuk berbuka nanti? jika belum, kali ini vemale akan membagikan resep super sedap berbahan dasar ayam. Berikut resep kare ayam khas Solo Resep Buka Puasa, Kare Ayam Khas Solo Sedap. Sudah mempersiapkan menu berbuka puasa apa untuk nanti sore? Ada satu menu kare ayam yang khas Solo. 

Ternyata cara membuat kare ayam solo yang lezat tidak rumit ini enteng banget ya! Anda Semua mampu menghidangkannya. Cara buat kare ayam solo Sesuai banget untuk kamu yang baru belajar memasak atau juga bagi anda yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba buat resep kare ayam solo mantab sederhana ini? Kalau kalian tertarik, mending kamu segera buruan menyiapkan alat-alat dan bahannya, kemudian bikin deh Resep kare ayam solo yang lezat dan tidak ribet ini. Betul-betul taidak sulit kan. 

Oleh karena itu, daripada kamu berlama-lama, yuk langsung aja buat resep kare ayam solo ini. Dijamin kamu tak akan menyesal sudah buat resep kare ayam solo lezat sederhana ini! Selamat berkreasi dengan resep kare ayam solo lezat sederhana ini di rumah kalian masing-masing,oke!.

