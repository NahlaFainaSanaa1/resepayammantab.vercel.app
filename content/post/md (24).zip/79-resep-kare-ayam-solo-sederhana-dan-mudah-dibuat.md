---
description: "Resep Kare Ayam Solo Sederhana dan Mudah Dibuat"
title: "Resep Kare Ayam Solo Sederhana dan Mudah Dibuat"
slug: 79-resep-kare-ayam-solo-sederhana-dan-mudah-dibuat
date: 2021-06-03T04:53:54.615Z
image: https://img-global.cpcdn.com/recipes/e43b53776f6d643e/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e43b53776f6d643e/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e43b53776f6d643e/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Jay Lane
ratingvalue: 4.2
reviewcount: 13
recipeingredient:
- "1/2 kg dada ayam rebus  daun salam sisihkan"
- "3 lembar daun salam"
- "2 batang sereh geprek"
- "3 lembar daun jeruk"
- "500 ml air"
- "500 ml santan yg diperas pakai air matang hangat"
- "1 sdt gula pasir"
- "1/2 sdt kaldu jamur"
- "secukupnya Garam"
- " Bumbu halus "
- "1/2 sdt merica"
- "1/2 sdt ketumbar"
- "3 butir kemiri"
- "3 siung baput"
- "5 siung bamer"
- "1 ruas jempol jahe"
- "1 ruas kelingking kunyit"
- " Bahan sayur rebusan "
- "1 buah wortel besar iris"
- "100 gr kecambah"
- "1/4 kubis iris tipis"
- "1 daun sledri cincang"
recipeinstructions:
- "Rebus dada ayam dalam air mendidih sampai matang sisihkan"
- "Blender/uleg semua bumbu halus, lalu tumis menggunakan sedikit santan sampai harum"
- "Masukkan air beserta kaldu jamur, garam, gula serta bumbu² cemplung lainya"
- "Koreksi rasa, lalu matikan kompor kemudian masukkan santan yg sdh diperas pakai air matang hangat dan koreksi rasa lagi, kl dirasa ada yg kurang boleh ditambah"
- "Tata diatas piring semua sayuran rebus tadi dan tambahkan dada ayam suwir² diatasnya, tuang kuah kare diatasnya dan taburi bawang goreng dan seledri cincang"
- "Selamat mencoba 😘"
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 174 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Lunch

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/e43b53776f6d643e/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Apabila kamu seorang ibu, menyuguhkan hidangan sedap bagi keluarga tercinta merupakan hal yang membahagiakan untuk kita sendiri. Kewajiban seorang istri bukan sekedar mengatur rumah saja, tapi kamu pun wajib memastikan keperluan nutrisi terpenuhi dan hidangan yang dikonsumsi orang tercinta mesti enak.

Di era  saat ini, kita sebenarnya bisa mengorder masakan yang sudah jadi meski tanpa harus ribet mengolahnya dahulu. Tapi ada juga orang yang memang ingin menyajikan yang terenak untuk keluarganya. Sebab, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan selera famili. 



Mungkinkah anda adalah seorang penggemar kare ayam solo?. Tahukah kamu, kare ayam solo merupakan hidangan khas di Nusantara yang saat ini digemari oleh setiap orang dari hampir setiap daerah di Indonesia. Kita dapat membuat kare ayam solo sendiri di rumahmu dan pasti jadi makanan favoritmu di akhir pekanmu.

Anda tak perlu bingung jika kamu ingin mendapatkan kare ayam solo, sebab kare ayam solo mudah untuk dicari dan kamu pun dapat mengolahnya sendiri di rumah. kare ayam solo boleh dibuat lewat bermacam cara. Kini sudah banyak banget cara kekinian yang menjadikan kare ayam solo lebih nikmat.

Resep kare ayam solo pun sangat gampang untuk dibikin, lho. Kalian jangan ribet-ribet untuk membeli kare ayam solo, lantaran Anda bisa membuatnya ditempatmu. Bagi Anda yang ingin mencobanya, berikut cara untuk menyajikan kare ayam solo yang mantab yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Kare Ayam Solo:

1. Ambil 1/2 kg dada ayam, rebus + daun salam, sisihkan
1. Ambil 3 lembar daun salam
1. Ambil 2 batang sereh geprek
1. Siapkan 3 lembar daun jeruk
1. Gunakan 500 ml air
1. Ambil 500 ml santan yg diperas pakai air matang hangat
1. Siapkan 1 sdt gula pasir
1. Gunakan 1/2 sdt kaldu jamur
1. Sediakan secukupnya Garam
1. Ambil  Bumbu halus :
1. Siapkan 1/2 sdt merica
1. Ambil 1/2 sdt ketumbar
1. Ambil 3 butir kemiri
1. Siapkan 3 siung baput
1. Sediakan 5 siung bamer
1. Sediakan 1 ruas jempol jahe
1. Sediakan 1 ruas kelingking kunyit
1. Ambil  Bahan sayur rebusan :
1. Sediakan 1 buah wortel besar iris²
1. Ambil 100 gr kecambah
1. Ambil 1/4 kubis iris tipis²
1. Sediakan 1 daun sledri cincang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Kare Ayam Solo:

1. Rebus dada ayam dalam air mendidih sampai matang sisihkan
1. Blender/uleg semua bumbu halus, lalu tumis menggunakan sedikit santan sampai harum
1. Masukkan air beserta kaldu jamur, garam, gula serta bumbu² cemplung lainya
1. Koreksi rasa, lalu matikan kompor kemudian masukkan santan yg sdh diperas pakai air matang hangat dan koreksi rasa lagi, kl dirasa ada yg kurang boleh ditambah
1. Tata diatas piring semua sayuran rebus tadi dan tambahkan dada ayam suwir² diatasnya, tuang kuah kare diatasnya dan taburi bawang goreng dan seledri cincang
1. Selamat mencoba 😘




Ternyata resep kare ayam solo yang mantab tidak rumit ini mudah sekali ya! Kamu semua mampu membuatnya. Cara buat kare ayam solo Sangat cocok banget buat kita yang sedang belajar memasak ataupun juga untuk kamu yang telah ahli dalam memasak.

Apakah kamu mau mulai mencoba membuat resep kare ayam solo nikmat sederhana ini? Kalau kalian tertarik, ayo kalian segera buruan siapkan peralatan dan bahannya, lantas bikin deh Resep kare ayam solo yang lezat dan sederhana ini. Benar-benar mudah kan. 

Jadi, daripada kita diam saja, hayo kita langsung buat resep kare ayam solo ini. Pasti kalian gak akan nyesel sudah membuat resep kare ayam solo nikmat tidak ribet ini! Selamat berkreasi dengan resep kare ayam solo mantab simple ini di tempat tinggal sendiri,ya!.

