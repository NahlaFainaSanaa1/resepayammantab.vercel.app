---
description: "Cara membuat Kare Ayam Solo Sederhana Untuk Jualan"
title: "Cara membuat Kare Ayam Solo Sederhana Untuk Jualan"
slug: 96-cara-membuat-kare-ayam-solo-sederhana-untuk-jualan
date: 2021-04-26T02:05:39.996Z
image: https://img-global.cpcdn.com/recipes/cd602235ce7c0707/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cd602235ce7c0707/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cd602235ce7c0707/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg
author: Adam May
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- "1/4 kg daging ayam"
- "1 Liter air"
- "1 bungkus santan instan"
- "1 batang serai"
- "8 lembar daun jeruk"
- "2 lembar daun salam"
- "1 jempol lengkuas"
- "2 ruas jahe"
- "1 buah tomat merah"
- "1 sdm gula"
- "4 sdm minyak goreng"
- " Bumbu halus"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "1 sdt merica bubuk"
- "1/2 sdt ketumbar bubuk"
- "3 butir kemiri"
- "2 ruas kunyit"
- "2 sdm garam"
- " Pelengkap"
- " Taoge"
- " Kubis"
- " Seledri"
- " Soun skip"
- " Keripik kentang skip"
- " Wortel skip"
- " Bawang goreng"
recipeinstructions:
- "Ulek bumbu hingga halus. Geprek jahe, serai, lengkuas. Panaskan 700ml air dalam panci, rebus daging ayam yg sdh dicuci bersih."
- "Panaskan sedikit minyak dalam wajan, tumis bumbu hingga harum. Masukkan jahe, serai, lengkuas, daun salam dan daun jeruk. Aduk rata. Tambahkan sedikit air, tumis lg hingga bumbu tanak."
- "Masukkan bumbu kedalam panci berisi rebusan daging ayam. Tambahkan gula pasir lalu aduk rata dan tunggu mendidih. Larutkan santan instan dg 300ml air, masukkan kedalam panci. Masukkan irisan tomat, aduk rata dan tunggu hingga mendidih kembali. Koreksi rasa."
- "Panaskan air dalam panci, rebus taoge hingga lunak (kurleb 5 menit), angkat dan tiriskan. Iris tipis2 kol dan daun seledri. Ambil daging ayam didalam panci berisi kuah, tiriskan lalu suwir2."
- "Tata kol, taoge dan suwiran ayam kedalam mangkuk, siram dg kuah kare lalu taburi daun seledri dan bawang goreng. Kare siap disajikan dg nasi hangat dan irisan cabe/sambal rebus jika suka pedas."
categories:
- Resep
tags:
- kare
- ayam
- solo

katakunci: kare ayam solo 
nutrition: 145 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dessert

---


![Kare Ayam Solo](https://img-global.cpcdn.com/recipes/cd602235ce7c0707/680x482cq70/kare-ayam-solo-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan santapan enak pada orang tercinta adalah suatu hal yang sangat menyenangkan untuk kita sendiri. Peran seorang istri bukan saja mengerjakan pekerjaan rumah saja, namun anda pun wajib memastikan kebutuhan nutrisi tercukupi dan juga santapan yang disantap anak-anak harus nikmat.

Di zaman  sekarang, kita memang dapat memesan hidangan jadi walaupun tanpa harus ribet membuatnya terlebih dahulu. Tapi banyak juga orang yang memang ingin menyajikan yang terbaik untuk keluarganya. Pasalnya, menyajikan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai selera keluarga. 



Apakah kamu seorang penggemar kare ayam solo?. Asal kamu tahu, kare ayam solo adalah makanan khas di Indonesia yang kini disenangi oleh banyak orang dari hampir setiap tempat di Nusantara. Kamu dapat menyajikan kare ayam solo sendiri di rumahmu dan dapat dijadikan makanan kesenanganmu di akhir pekanmu.

Kita tidak usah bingung jika kamu ingin mendapatkan kare ayam solo, karena kare ayam solo tidak sulit untuk ditemukan dan juga kamu pun bisa menghidangkannya sendiri di tempatmu. kare ayam solo bisa dimasak memalui beraneka cara. Saat ini telah banyak cara kekinian yang membuat kare ayam solo semakin enak.

Resep kare ayam solo pun gampang sekali dibuat, lho. Kalian jangan ribet-ribet untuk membeli kare ayam solo, sebab Kalian bisa menghidangkan ditempatmu. Untuk Anda yang hendak membuatnya, dibawah ini merupakan resep menyajikan kare ayam solo yang nikamat yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Kare Ayam Solo:

1. Siapkan 1/4 kg daging ayam
1. Gunakan 1 Liter air
1. Gunakan 1 bungkus santan instan
1. Ambil 1 batang serai
1. Siapkan 8 lembar daun jeruk
1. Sediakan 2 lembar daun salam
1. Gunakan 1 jempol lengkuas
1. Gunakan 2 ruas jahe
1. Siapkan 1 buah tomat merah
1. Siapkan 1 sdm gula
1. Ambil 4 sdm minyak goreng
1. Siapkan  Bumbu halus:
1. Sediakan 8 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Sediakan 1 sdt merica bubuk
1. Gunakan 1/2 sdt ketumbar bubuk
1. Siapkan 3 butir kemiri
1. Ambil 2 ruas kunyit
1. Siapkan 2 sdm garam
1. Ambil  Pelengkap:
1. Siapkan  Taoge
1. Siapkan  Kubis
1. Sediakan  Seledri
1. Ambil  Soun (skip)
1. Sediakan  Keripik kentang (skip)
1. Sediakan  Wortel (skip)
1. Ambil  Bawang goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Kare Ayam Solo:

1. Ulek bumbu hingga halus. Geprek jahe, serai, lengkuas. Panaskan 700ml air dalam panci, rebus daging ayam yg sdh dicuci bersih.
1. Panaskan sedikit minyak dalam wajan, tumis bumbu hingga harum. Masukkan jahe, serai, lengkuas, daun salam dan daun jeruk. Aduk rata. Tambahkan sedikit air, tumis lg hingga bumbu tanak.
1. Masukkan bumbu kedalam panci berisi rebusan daging ayam. Tambahkan gula pasir lalu aduk rata dan tunggu mendidih. Larutkan santan instan dg 300ml air, masukkan kedalam panci. Masukkan irisan tomat, aduk rata dan tunggu hingga mendidih kembali. Koreksi rasa.
1. Panaskan air dalam panci, rebus taoge hingga lunak (kurleb 5 menit), angkat dan tiriskan. Iris tipis2 kol dan daun seledri. Ambil daging ayam didalam panci berisi kuah, tiriskan lalu suwir2.
1. Tata kol, taoge dan suwiran ayam kedalam mangkuk, siram dg kuah kare lalu taburi daun seledri dan bawang goreng. Kare siap disajikan dg nasi hangat dan irisan cabe/sambal rebus jika suka pedas.




Wah ternyata resep kare ayam solo yang lezat sederhana ini enteng banget ya! Kamu semua bisa memasaknya. Cara buat kare ayam solo Cocok banget buat kalian yang baru belajar memasak ataupun juga bagi kamu yang sudah ahli dalam memasak.

Apakah kamu ingin mulai mencoba buat resep kare ayam solo enak simple ini? Kalau kalian mau, yuk kita segera buruan menyiapkan peralatan dan bahannya, maka buat deh Resep kare ayam solo yang lezat dan tidak rumit ini. Sungguh taidak sulit kan. 

Maka, ketimbang kalian berlama-lama, ayo kita langsung saja bikin resep kare ayam solo ini. Dijamin anda tak akan nyesel sudah membuat resep kare ayam solo mantab tidak ribet ini! Selamat berkreasi dengan resep kare ayam solo lezat simple ini di rumah masing-masing,oke!.

