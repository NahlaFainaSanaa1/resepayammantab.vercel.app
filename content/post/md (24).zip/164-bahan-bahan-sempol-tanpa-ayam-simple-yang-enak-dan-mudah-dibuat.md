---
description: "Bahan-bahan Sempol tanpa ayam simple yang enak dan Mudah Dibuat"
title: "Bahan-bahan Sempol tanpa ayam simple yang enak dan Mudah Dibuat"
slug: 164-bahan-bahan-sempol-tanpa-ayam-simple-yang-enak-dan-mudah-dibuat
date: 2021-05-13T12:39:21.715Z
image: https://img-global.cpcdn.com/recipes/cca84b7a00bf65e5/680x482cq70/sempol-tanpa-ayam-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cca84b7a00bf65e5/680x482cq70/sempol-tanpa-ayam-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cca84b7a00bf65e5/680x482cq70/sempol-tanpa-ayam-simple-foto-resep-utama.jpg
author: Abbie Reeves
ratingvalue: 3.8
reviewcount: 10
recipeingredient:
- "1/4 kg Tepung terigu"
- "1/4 kg Tepung tapiokakanji"
- "1 butir Telur ayam"
- "3 butir bawang putih haluskan"
- "secukupnya Garam"
- " Penyedap rasa roycomasako"
- " Gula sedikit sjaboleh di skip"
- "secukupnya Air panas"
- "1 butir Telur untuk lapisan menggoreng"
recipeinstructions:
- "Masukkan Tepung terigu, Tepung kanji, telur,garam,bawang putih,penyedap dan gula, aduk&#34; sebentar"
- "Kemudian masukkan air panas sedikit demi sedikit sambil di uleni hingga jadi adonan kayak pentol gitu, setelah dirasa cukup lalu bentuk adonan di lidi/tusuk sate hingga selesai"
- "Lalu siapkan panci dan air,rebus hingga mendidih kemudian masukkan sempol yg sudh di bentuk tadi,masak hingga kurlep 25 -30 menit,lalu angkat dan tiriskan"
- "Panaskan wajan untuk menggoreng sempol,sembari menunggu minyak panas, kocok telur (tanpa diberi garam yaa) lalu olesi sempol tdi dengan telur"
- "Setelah minyak panas,kecilkan api,Kemudian masukkan sempol yg telah di olesi telur dan goreng hingga setengah kecoklatan"
- "Tiriskan dan siapp di sajikan bersama saos sambal/apapun, Selamat menikmati 😋😚😍"
categories:
- Resep
tags:
- sempol
- tanpa
- ayam

katakunci: sempol tanpa ayam 
nutrition: 104 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner

---


![Sempol tanpa ayam simple](https://img-global.cpcdn.com/recipes/cca84b7a00bf65e5/680x482cq70/sempol-tanpa-ayam-simple-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan olahan enak pada keluarga tercinta adalah suatu hal yang menggembirakan untuk anda sendiri. Peran seorang istri Tidak cuman menjaga rumah saja, namun anda pun harus menyediakan keperluan nutrisi tercukupi dan juga masakan yang dikonsumsi orang tercinta wajib enak.

Di zaman  sekarang, anda sebenarnya bisa membeli panganan praktis meski tanpa harus susah memasaknya terlebih dahulu. Tapi banyak juga orang yang selalu ingin menghidangkan yang terenak untuk keluarganya. Sebab, memasak yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan famili. 



Apakah anda adalah seorang penikmat sempol tanpa ayam simple?. Asal kamu tahu, sempol tanpa ayam simple adalah sajian khas di Indonesia yang saat ini disukai oleh banyak orang dari hampir setiap tempat di Nusantara. Kalian bisa membuat sempol tanpa ayam simple sendiri di rumah dan pasti jadi camilan favoritmu di hari libur.

Anda jangan bingung untuk menyantap sempol tanpa ayam simple, sebab sempol tanpa ayam simple mudah untuk dicari dan juga anda pun dapat menghidangkannya sendiri di rumah. sempol tanpa ayam simple dapat dibuat memalui beraneka cara. Kini pun ada banyak banget cara kekinian yang menjadikan sempol tanpa ayam simple semakin lebih enak.

Resep sempol tanpa ayam simple pun sangat mudah untuk dibuat, lho. Kalian tidak perlu ribet-ribet untuk memesan sempol tanpa ayam simple, tetapi Kita dapat menyajikan di rumahmu. Bagi Kita yang mau membuatnya, inilah resep untuk menyajikan sempol tanpa ayam simple yang enak yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Sempol tanpa ayam simple:

1. Gunakan 1/4 kg Tepung terigu
1. Gunakan 1/4 kg Tepung tapioka/kanji
1. Sediakan 1 butir Telur ayam
1. Sediakan 3 butir bawang putih (haluskan)
1. Sediakan secukupnya Garam
1. Ambil  Penyedap rasa (royco/masako)
1. Ambil  Gula sedikit sja/boleh di skip
1. Ambil secukupnya Air panas
1. Siapkan 1 butir Telur (untuk lapisan menggoreng)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Sempol tanpa ayam simple:

1. Masukkan Tepung terigu, Tepung kanji, telur,garam,bawang putih,penyedap dan gula, aduk&#34; sebentar
1. Kemudian masukkan air panas sedikit demi sedikit sambil di uleni hingga jadi adonan kayak pentol gitu, setelah dirasa cukup lalu bentuk adonan di lidi/tusuk sate hingga selesai
1. Lalu siapkan panci dan air,rebus hingga mendidih kemudian masukkan sempol yg sudh di bentuk tadi,masak hingga kurlep 25 -30 menit,lalu angkat dan tiriskan
1. Panaskan wajan untuk menggoreng sempol,sembari menunggu minyak panas, kocok telur (tanpa diberi garam yaa) lalu olesi sempol tdi dengan telur
1. Setelah minyak panas,kecilkan api,Kemudian masukkan sempol yg telah di olesi telur dan goreng hingga setengah kecoklatan
1. Tiriskan dan siapp di sajikan bersama saos sambal/apapun, Selamat menikmati 😋😚😍




Ternyata cara buat sempol tanpa ayam simple yang enak tidak rumit ini enteng sekali ya! Semua orang bisa mencobanya. Cara buat sempol tanpa ayam simple Cocok banget buat kalian yang baru belajar memasak ataupun juga untuk anda yang sudah lihai memasak.

Apakah kamu tertarik mencoba buat resep sempol tanpa ayam simple lezat tidak ribet ini? Kalau kamu tertarik, ayo kalian segera menyiapkan peralatan dan bahan-bahannya, maka bikin deh Resep sempol tanpa ayam simple yang enak dan tidak ribet ini. Sungguh gampang kan. 

Maka dari itu, daripada kalian berfikir lama-lama, yuk langsung aja buat resep sempol tanpa ayam simple ini. Dijamin kalian tak akan menyesal sudah bikin resep sempol tanpa ayam simple lezat simple ini! Selamat berkreasi dengan resep sempol tanpa ayam simple mantab tidak ribet ini di tempat tinggal masing-masing,oke!.

