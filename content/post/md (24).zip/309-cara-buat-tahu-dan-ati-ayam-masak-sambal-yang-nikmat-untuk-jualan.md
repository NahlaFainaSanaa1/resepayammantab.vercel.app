---
description: "Cara buat Tahu dan Ati Ayam Masak Sambal yang nikmat Untuk Jualan"
title: "Cara buat Tahu dan Ati Ayam Masak Sambal yang nikmat Untuk Jualan"
slug: 309-cara-buat-tahu-dan-ati-ayam-masak-sambal-yang-nikmat-untuk-jualan
date: 2021-02-03T16:46:19.957Z
image: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
author: Della Jimenez
ratingvalue: 3.3
reviewcount: 7
recipeingredient:
- "4 buah Tahu ukuran sedang goreng"
- "250 gram Hati ayam rebus lalu goreng"
- "2 cm lengkuas geprek"
- "2 lembar daun salam"
- "1 sdt Garam"
- "1 sdt Gula"
- "1/2 sdt Merica"
- "2 sdm Kecap manis jika suka"
- " Kaldu udang 1 sdt bisa juga kaldu jamur atau lainnya           lihat resep"
- " Bumbu halus "
- "6 buah Bawang merah"
- "3 siung Bawang putih"
- "3 buah Cabe merah besar"
- "15 buah cabe rawit sesuai selera"
recipeinstructions:
- "Siapkan bahan : Goreng tahu. Rebus dan goreng hati sapi. Haluskan bumbu."
- "Tumis bumbu dengan sedikit minyak, masukkan Lengkuas dan daun salam. Aduk rata biarkan hingga harum, selagi menunggu, potong² hati sapi. Setelah bumbu harum masukkan kedua bahan utama. Aduk rata."
- "Beri sedikit air, masukkan, gula, garam, merica, kaldu udang, kecap. Aduk rata. Test rasa. Masak hingga air menyusut dan bumbu meresap."
- "Tahu dan Ati Ayam masak sambal, siap di sajikan dengan nasi hangat. Selamat mencoba. Praktis dan enak."
categories:
- Resep
tags:
- tahu
- dan
- ati

katakunci: tahu dan ati 
nutrition: 223 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Tahu dan Ati Ayam Masak Sambal](https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg)

Apabila kamu seorang orang tua, menyuguhkan panganan menggugah selera untuk keluarga tercinta merupakan suatu hal yang membahagiakan untuk kamu sendiri. Tugas seorang ibu bukan sekadar mengerjakan pekerjaan rumah saja, namun kamu juga wajib menyediakan keperluan nutrisi terpenuhi dan juga masakan yang disantap anak-anak harus enak.

Di waktu  saat ini, kamu sebenarnya dapat mengorder olahan praktis tanpa harus ribet membuatnya dahulu. Tapi banyak juga orang yang selalu ingin memberikan makanan yang terenak bagi orang tercintanya. Lantaran, memasak yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai kesukaan famili. 



Apakah anda merupakan seorang penyuka tahu dan ati ayam masak sambal?. Asal kamu tahu, tahu dan ati ayam masak sambal adalah makanan khas di Indonesia yang kini digemari oleh kebanyakan orang di berbagai wilayah di Indonesia. Kita dapat membuat tahu dan ati ayam masak sambal kreasi sendiri di rumah dan boleh jadi santapan kesenanganmu di hari libur.

Anda tidak perlu bingung jika kamu ingin memakan tahu dan ati ayam masak sambal, karena tahu dan ati ayam masak sambal gampang untuk didapatkan dan kalian pun dapat mengolahnya sendiri di rumah. tahu dan ati ayam masak sambal boleh dibuat dengan beragam cara. Kini pun telah banyak banget resep modern yang membuat tahu dan ati ayam masak sambal semakin lezat.

Resep tahu dan ati ayam masak sambal pun sangat gampang dibikin, lho. Kita tidak perlu ribet-ribet untuk membeli tahu dan ati ayam masak sambal, tetapi Anda bisa menyiapkan di rumah sendiri. Bagi Kita yang mau menghidangkannya, berikut resep menyajikan tahu dan ati ayam masak sambal yang mantab yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Tahu dan Ati Ayam Masak Sambal:

1. Siapkan 4 buah Tahu ukuran sedang (goreng)
1. Ambil 250 gram Hati ayam (rebus lalu goreng)
1. Ambil 2 cm lengkuas geprek
1. Ambil 2 lembar daun salam
1. Sediakan 1 sdt Garam
1. Sediakan 1 sdt Gula
1. Siapkan 1/2 sdt Merica
1. Siapkan 2 sdm Kecap manis (jika suka)
1. Siapkan  Kaldu udang 1 sdt (bisa juga kaldu jamur atau lainnya)           (lihat resep)
1. Siapkan  Bumbu halus :
1. Gunakan 6 buah Bawang merah
1. Ambil 3 siung Bawang putih
1. Sediakan 3 buah Cabe merah besar
1. Gunakan 15 buah cabe rawit (sesuai selera)




<!--inarticleads2-->

##### Langkah-langkah membuat Tahu dan Ati Ayam Masak Sambal:

1. Siapkan bahan : Goreng tahu. Rebus dan goreng hati sapi. Haluskan bumbu.
1. Tumis bumbu dengan sedikit minyak, masukkan Lengkuas dan daun salam. Aduk rata biarkan hingga harum, selagi menunggu, potong² hati sapi. Setelah bumbu harum masukkan kedua bahan utama. Aduk rata.
1. Beri sedikit air, masukkan, gula, garam, merica, kaldu udang, kecap. Aduk rata. Test rasa. Masak hingga air menyusut dan bumbu meresap.
1. Tahu dan Ati Ayam masak sambal, siap di sajikan dengan nasi hangat. Selamat mencoba. Praktis dan enak.




Wah ternyata cara membuat tahu dan ati ayam masak sambal yang nikamt simple ini enteng banget ya! Anda Semua mampu memasaknya. Cara buat tahu dan ati ayam masak sambal Sangat sesuai banget untuk kita yang baru belajar memasak maupun bagi kamu yang telah ahli dalam memasak.

Tertarik untuk mencoba bikin resep tahu dan ati ayam masak sambal nikmat tidak rumit ini? Kalau kamu tertarik, ayo kalian segera buruan siapkan peralatan dan bahan-bahannya, lalu buat deh Resep tahu dan ati ayam masak sambal yang mantab dan simple ini. Sungguh mudah kan. 

Jadi, ketimbang kalian berfikir lama-lama, hayo kita langsung bikin resep tahu dan ati ayam masak sambal ini. Dijamin kalian tiidak akan nyesel sudah buat resep tahu dan ati ayam masak sambal enak simple ini! Selamat mencoba dengan resep tahu dan ati ayam masak sambal nikmat sederhana ini di tempat tinggal kalian masing-masing,ya!.

