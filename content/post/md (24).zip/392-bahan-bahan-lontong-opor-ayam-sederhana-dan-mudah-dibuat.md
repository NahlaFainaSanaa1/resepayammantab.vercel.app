---
description: "Bahan-bahan Lontong Opor Ayam Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Lontong Opor Ayam Sederhana dan Mudah Dibuat"
slug: 392-bahan-bahan-lontong-opor-ayam-sederhana-dan-mudah-dibuat
date: 2021-05-28T03:46:19.019Z
image: https://img-global.cpcdn.com/recipes/0aef541c86847900/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0aef541c86847900/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0aef541c86847900/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
author: Jon Woods
ratingvalue: 3
reviewcount: 3
recipeingredient:
- " Lontong           lihat resep"
- "1 ekor ayam potong2 jadi 12 potong"
- "6 butir telur rebus lalu goreng sebentar"
- "6 potong tahu putih potong dadu goreng"
- "2 batang sereh memarkan"
- "2 lembar daun salam"
- "1 biji bunga lawang"
- "3 biji kapulaga"
- "1 ruas kayumanis"
- "1 pala geprek"
- "3 lembar daun jeruk purut"
- "400 ml santan kental"
- "200 ml air"
- " bawang merah goreng secukupnya untuk taburan"
- " Bumbu Halus"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "4 buah kemiri"
- "1-2 cabe merah tergantung selera"
- "1 sdt ketumbar bubuk"
- "1 sdt jinten"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt merica"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "Sedikit kaldu jamur skip"
- "secukupnya garam"
- "25 g gula merah menurut selera"
recipeinstructions:
- "Bersihkan ayam, tumis bumbu halus, sereh, daun jeruk purut dan daun salam sampai harum."
- "Masukkan ayam tuangi air, tutup panci, didihkan."
- "Kemudian masukkan santan kental, kembali didihkan sambil dididihkan masukkan tahu, telur kemudian beri garam, kaldu jamur, gula, koreksi rasa."
- "Tata lontong dalam mangkuk, siram dengan kuah opor tambahkan dgn taburan bawang merah goreng."
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 253 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Lunch

---


![Lontong Opor Ayam](https://img-global.cpcdn.com/recipes/0aef541c86847900/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyajikan santapan sedap buat orang tercinta adalah hal yang sangat menyenangkan untuk anda sendiri. Peran seorang istri bukan cuman mengatur rumah saja, namun anda pun harus menyediakan kebutuhan gizi tercukupi dan hidangan yang dikonsumsi anak-anak harus menggugah selera.

Di masa  sekarang, kalian sebenarnya mampu membeli santapan instan tidak harus ribet membuatnya lebih dulu. Namun banyak juga lho mereka yang selalu ingin menghidangkan yang terlezat bagi orang tercintanya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan makanan kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penggemar lontong opor ayam?. Asal kamu tahu, lontong opor ayam merupakan makanan khas di Nusantara yang kini disenangi oleh banyak orang dari berbagai tempat di Indonesia. Kita bisa membuat lontong opor ayam olahan sendiri di rumahmu dan pasti jadi hidangan kesenanganmu di akhir pekanmu.

Kamu jangan bingung jika kamu ingin memakan lontong opor ayam, lantaran lontong opor ayam mudah untuk ditemukan dan juga kamu pun bisa membuatnya sendiri di rumah. lontong opor ayam boleh dibuat lewat berbagai cara. Kini telah banyak sekali cara modern yang membuat lontong opor ayam semakin enak.

Resep lontong opor ayam juga sangat gampang dihidangkan, lho. Kalian tidak usah repot-repot untuk memesan lontong opor ayam, lantaran Kamu mampu menyajikan ditempatmu. Bagi Kalian yang hendak menyajikannya, di bawah ini adalah cara menyajikan lontong opor ayam yang nikamat yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Lontong Opor Ayam:

1. Siapkan  Lontong           (lihat resep)
1. Gunakan 1 ekor ayam potong2 jadi 12 potong
1. Ambil 6 butir telur rebus lalu goreng sebentar
1. Siapkan 6 potong tahu putih potong dadu goreng
1. Sediakan 2 batang sereh memarkan
1. Gunakan 2 lembar daun salam
1. Siapkan 1 biji bunga lawang
1. Siapkan 3 biji kapulaga
1. Gunakan 1 ruas kayumanis
1. Gunakan 1 pala geprek
1. Ambil 3 lembar daun jeruk purut
1. Gunakan 400 ml santan kental
1. Sediakan 200 ml air
1. Sediakan  bawang merah goreng secukupnya untuk taburan
1. Gunakan  Bumbu Halus
1. Gunakan 7 siung bawang merah
1. Ambil 4 siung bawang putih
1. Sediakan 4 buah kemiri
1. Ambil 1-2 cabe merah/ tergantung selera
1. Gunakan 1 sdt ketumbar bubuk
1. Siapkan 1 sdt jinten
1. Ambil 1/2 sdt kunyit bubuk
1. Gunakan 1/2 sdt merica
1. Siapkan 1 ruas jahe
1. Sediakan 1 ruas lengkuas
1. Siapkan Sedikit kaldu jamur (skip)
1. Ambil secukupnya garam
1. Ambil 25 g gula merah/ menurut selera




<!--inarticleads2-->

##### Langkah-langkah membuat Lontong Opor Ayam:

1. Bersihkan ayam, tumis bumbu halus, sereh, daun jeruk purut dan daun salam sampai harum.
1. Masukkan ayam tuangi air, tutup panci, didihkan.
1. Kemudian masukkan santan kental, kembali didihkan sambil dididihkan masukkan tahu, telur kemudian beri garam, kaldu jamur, gula, koreksi rasa.
1. Tata lontong dalam mangkuk, siram dengan kuah opor tambahkan dgn taburan bawang merah goreng.




Ternyata cara buat lontong opor ayam yang enak simple ini gampang banget ya! Kamu semua mampu menghidangkannya. Cara buat lontong opor ayam Sangat sesuai sekali untuk anda yang sedang belajar memasak ataupun juga bagi kamu yang telah hebat dalam memasak.

Tertarik untuk mulai mencoba membuat resep lontong opor ayam lezat tidak rumit ini? Kalau kamu tertarik, ayo kamu segera siapkan alat dan bahannya, lantas bikin deh Resep lontong opor ayam yang enak dan simple ini. Sangat mudah kan. 

Maka dari itu, ketimbang kalian diam saja, ayo kita langsung bikin resep lontong opor ayam ini. Dijamin kamu tak akan nyesel membuat resep lontong opor ayam nikmat tidak rumit ini! Selamat mencoba dengan resep lontong opor ayam nikmat tidak rumit ini di rumah kalian sendiri,ya!.

