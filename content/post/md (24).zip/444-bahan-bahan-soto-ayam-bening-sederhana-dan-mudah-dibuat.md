---
description: "Bahan-bahan Soto Ayam Bening Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Soto Ayam Bening Sederhana dan Mudah Dibuat"
slug: 444-bahan-bahan-soto-ayam-bening-sederhana-dan-mudah-dibuat
date: 2021-04-26T00:19:40.432Z
image: https://img-global.cpcdn.com/recipes/d2c414c549799079/680x482cq70/soto-ayam-bening-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d2c414c549799079/680x482cq70/soto-ayam-bening-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d2c414c549799079/680x482cq70/soto-ayam-bening-foto-resep-utama.jpg
author: Barry Jacobs
ratingvalue: 3.4
reviewcount: 8
recipeingredient:
- "300 gr Dada ayam fillet"
- "Secukupnya air untuk rebusan pertama"
- "1,5 liter airsesuai selera untuk rebusan berikutnya"
- "Secukupnya gulagaram"
- "Secukupnya minyak untuk menumis"
- " Rempah Daun"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "1 batang sereh"
- "2 ruas lengkuas"
- " Bumbu Halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "4 butir kemiri"
- "1,5 ruas kunyit"
- "1 ruas jahe"
- "1/2 sdt ketumbar"
- "1/2 sdt lada"
recipeinstructions:
- "Potong dada ayam beberapa bagian, cuci bersih, beri garam dan air perasan jeruk nipis, remas-remas, diamkan beberapa saat, lalu cuci bersih kembali, tiriskan."
- "Kemudian rebus ayam dalam air mendidih sebentar saja. Buang air rebusan pertama. Selanjutnya didihkan 1,5 Liter air. Lalu rebus kembali ayam tadi beserta rempah daun."
- "Sambil merebus ayam, tumis bumbu halus menggunakan minyak sayur sampai harum dan matang (supaya gak langu). Lalu beri sedikit air, aduk rata. Kemudian masukan tumisan tadi ke dalam rebusan ayam, Aduk rata. Beri garam dan gula. Masak sampai ayam matang. Tes rasa. Jika sudah pas. Matikan kompor. Kuah siap digunakan. Angkat potongan ayam, tiriskan. Lalu suwir-suwir. (Boleh juga digoreng dulu)."
- "Penyajian : nasi, irisan kol,ayam suwir, kentang goreng dan mie.  Lalu siram dgn kuah soto dan beri bawang goreng."
categories:
- Resep
tags:
- soto
- ayam
- bening

katakunci: soto ayam bening 
nutrition: 124 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto Ayam Bening](https://img-global.cpcdn.com/recipes/d2c414c549799079/680x482cq70/soto-ayam-bening-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyuguhkan hidangan enak pada famili adalah hal yang membahagiakan untuk kita sendiri. Tanggung jawab seorang  wanita bukan hanya menangani rumah saja, namun kamu pun wajib memastikan keperluan gizi terpenuhi dan juga hidangan yang dimakan anak-anak mesti enak.

Di era  saat ini, anda memang dapat memesan panganan instan meski tanpa harus susah memasaknya lebih dulu. Tetapi ada juga lho orang yang selalu ingin menyajikan yang terlezat untuk orang tercintanya. Pasalnya, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan selera keluarga. 



Apakah anda seorang penikmat soto ayam bening?. Asal kamu tahu, soto ayam bening merupakan hidangan khas di Indonesia yang sekarang disenangi oleh setiap orang di berbagai wilayah di Nusantara. Kamu dapat menyajikan soto ayam bening sendiri di rumahmu dan boleh dijadikan hidangan favorit di hari libur.

Kalian jangan bingung untuk menyantap soto ayam bening, sebab soto ayam bening sangat mudah untuk didapatkan dan juga anda pun dapat mengolahnya sendiri di rumah. soto ayam bening bisa diolah memalui berbagai cara. Saat ini telah banyak sekali cara kekinian yang menjadikan soto ayam bening semakin lezat.

Resep soto ayam bening pun sangat mudah dibikin, lho. Anda tidak perlu capek-capek untuk memesan soto ayam bening, tetapi Kita dapat menghidangkan di rumahmu. Bagi Kalian yang akan membuatnya, di bawah ini adalah resep untuk membuat soto ayam bening yang lezat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto Ayam Bening:

1. Sediakan 300 gr Dada ayam fillet
1. Sediakan Secukupnya air untuk rebusan pertama
1. Ambil 1,5 liter air/sesuai selera untuk rebusan berikutnya
1. Gunakan Secukupnya gula,garam
1. Gunakan Secukupnya minyak untuk menumis
1. Siapkan  Rempah Daun
1. Gunakan 2 lembar daun salam
1. Siapkan 4 lembar daun jeruk
1. Siapkan 1 batang sereh
1. Siapkan 2 ruas lengkuas
1. Ambil  Bumbu Halus
1. Ambil 6 siung bawang merah
1. Gunakan 4 siung bawang putih
1. Gunakan 4 butir kemiri
1. Siapkan 1,5 ruas kunyit
1. Gunakan 1 ruas jahe
1. Siapkan 1/2 sdt ketumbar
1. Sediakan 1/2 sdt lada




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Bening:

1. Potong dada ayam beberapa bagian, cuci bersih, beri garam dan air perasan jeruk nipis, remas-remas, diamkan beberapa saat, lalu cuci bersih kembali, tiriskan.
1. Kemudian rebus ayam dalam air mendidih sebentar saja. Buang air rebusan pertama. Selanjutnya didihkan 1,5 Liter air. Lalu rebus kembali ayam tadi beserta rempah daun.
1. Sambil merebus ayam, tumis bumbu halus menggunakan minyak sayur sampai harum dan matang (supaya gak langu). Lalu beri sedikit air, aduk rata. Kemudian masukan tumisan tadi ke dalam rebusan ayam, Aduk rata. Beri garam dan gula. Masak sampai ayam matang. Tes rasa. Jika sudah pas. Matikan kompor. Kuah siap digunakan. Angkat potongan ayam, tiriskan. Lalu suwir-suwir. (Boleh juga digoreng dulu).
1. Penyajian : nasi, irisan kol,ayam suwir, kentang goreng dan mie.  - Lalu siram dgn kuah soto dan beri bawang goreng.




Wah ternyata cara membuat soto ayam bening yang mantab simple ini gampang banget ya! Kalian semua bisa memasaknya. Cara buat soto ayam bening Sangat sesuai sekali untuk kalian yang sedang belajar memasak maupun juga untuk kalian yang telah lihai dalam memasak.

Apakah kamu mau mulai mencoba membuat resep soto ayam bening enak tidak ribet ini? Kalau kamu mau, ayo kamu segera menyiapkan alat-alat dan bahan-bahannya, lantas bikin deh Resep soto ayam bening yang nikmat dan tidak ribet ini. Sungguh taidak sulit kan. 

Jadi, daripada kita diam saja, ayo langsung aja buat resep soto ayam bening ini. Dijamin kalian gak akan menyesal sudah membuat resep soto ayam bening enak sederhana ini! Selamat mencoba dengan resep soto ayam bening enak tidak rumit ini di rumah sendiri,ya!.

