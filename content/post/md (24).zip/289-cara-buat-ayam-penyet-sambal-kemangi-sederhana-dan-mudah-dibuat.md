---
description: "Cara buat Ayam Penyet Sambal Kemangi Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam Penyet Sambal Kemangi Sederhana dan Mudah Dibuat"
slug: 289-cara-buat-ayam-penyet-sambal-kemangi-sederhana-dan-mudah-dibuat
date: 2021-03-28T06:38:58.395Z
image: https://img-global.cpcdn.com/recipes/13a62613fb439188/680x482cq70/ayam-penyet-sambal-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/13a62613fb439188/680x482cq70/ayam-penyet-sambal-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/13a62613fb439188/680x482cq70/ayam-penyet-sambal-kemangi-foto-resep-utama.jpg
author: Elijah Carroll
ratingvalue: 5
reviewcount: 15
recipeingredient:
- "1 kg ayampotong2"
- "secukupnya Minyak goreng"
- " Bahan marinasi"
- "5 siung bawang putihhaluskan"
- "1 sdt lada putih bubuk"
- "2 sdt garam"
- "20 ml air jeruk nipis"
- " Bahan tepung basah liquid"
- "150 ml air kekentalan sesuaikan"
- "5 sdm tepung bumbu ayam saa"
- "1 sdm tepung protein tinggi"
- "1 sdt lada"
- " Bahan tepung kering"
- "15 sdm tepung protein tinggi"
- "7 sdm tepung bumbu ayam saa"
- "2 sdt lada putih bubuk"
- "2 sdt paprika bubuk"
- "1 sdt baking powder"
- " Sambal kemangi"
- "4 buah cabai merah besar"
- "15 buah cabai rawit merah"
- "1 blok terasi ac bakar"
- "secukupnya Garam"
- "secukupnya Gula pasir"
- "1 ikat kecil kemangi"
- "1 sdm minyak panas"
recipeinstructions:
- "Cuci bersih ayam,rendam ayam dgn bumbu marinasi selama 15 menit."
- "Campurkan semua adonan basah,aduk rata &amp; sisihkan.Di wadah berbeda campurkan adonan tepung kering,aduk rata.Panaskan minyak goreng dgn api sedang."
- "Masukan ayam yg SDH di marinasi ke dalam tepung basah,lumuri yg tercampur rata,tiriskan.Masukan ke dalam tepung kering hingga rata.Ulangi 1x lagi.(TDK perlu di cubit2)"
- "Masukan ayam ke dalam minyak tadi,setelah ke 2 sisi nya kecokltan,kecilkan api (untuk menantang kan bagian dalam) angkat &amp; tiriskan.Lakukan hingga ayam habis."
- "Ulek cabai merah besar,cabai rawit,terasi bakar,gula &amp; garam,masukan bawang merah,memarkan.Kemudian masukan kemangi,tekan2 sedikit &amp; siram dgn minyak panas,aduk rata &amp; koreksi rasa. Ambil ayam,letakkan di dalam cobek,pennyet2.Sajikan"
categories:
- Resep
tags:
- ayam
- penyet
- sambal

katakunci: ayam penyet sambal 
nutrition: 113 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Penyet Sambal Kemangi](https://img-global.cpcdn.com/recipes/13a62613fb439188/680x482cq70/ayam-penyet-sambal-kemangi-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan hidangan mantab pada keluarga tercinta merupakan hal yang sangat menyenangkan bagi anda sendiri. Peran seorang ibu bukan cuman mengurus rumah saja, tapi anda juga harus menyediakan keperluan gizi tercukupi dan olahan yang dimakan keluarga tercinta wajib sedap.

Di zaman  sekarang, kalian sebenarnya bisa mengorder santapan instan tidak harus ribet membuatnya dulu. Tetapi banyak juga lho orang yang selalu ingin menyajikan yang terbaik bagi orang yang dicintainya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan kesukaan famili. 



Mungkinkah anda adalah seorang penikmat ayam penyet sambal kemangi?. Asal kamu tahu, ayam penyet sambal kemangi adalah makanan khas di Indonesia yang saat ini digemari oleh banyak orang dari hampir setiap daerah di Indonesia. Kita bisa membuat ayam penyet sambal kemangi sendiri di rumahmu dan dapat dijadikan hidangan favorit di akhir pekan.

Kita tidak usah bingung untuk menyantap ayam penyet sambal kemangi, karena ayam penyet sambal kemangi tidak sukar untuk ditemukan dan juga kita pun boleh membuatnya sendiri di tempatmu. ayam penyet sambal kemangi dapat dibuat dengan beragam cara. Kini pun ada banyak banget cara kekinian yang membuat ayam penyet sambal kemangi semakin mantap.

Resep ayam penyet sambal kemangi pun gampang sekali dibuat, lho. Kalian jangan repot-repot untuk memesan ayam penyet sambal kemangi, sebab Kamu mampu menyiapkan di rumahmu. Untuk Kita yang mau membuatnya, berikut resep menyajikan ayam penyet sambal kemangi yang lezat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Penyet Sambal Kemangi:

1. Gunakan 1 kg ayam,potong2
1. Ambil secukupnya Minyak goreng
1. Siapkan  Bahan marinasi:
1. Siapkan 5 siung bawang putih,haluskan
1. Gunakan 1 sdt lada putih bubuk
1. Sediakan 2 sdt garam
1. Ambil 20 ml air jeruk nipis
1. Sediakan  Bahan tepung basah (liquid)
1. Gunakan 150 ml air (kekentalan sesuaikan)
1. Sediakan 5 sdm tepung bumbu ayam sa*a
1. Sediakan 1 sdm tepung protein tinggi
1. Gunakan 1 sdt lada
1. Gunakan  Bahan tepung kering
1. Gunakan 15 sdm tepung protein tinggi
1. Gunakan 7 sdm tepung bumbu ayam sa*a
1. Gunakan 2 sdt lada putih bubuk
1. Siapkan 2 sdt paprika bubuk
1. Siapkan 1 sdt baking powder
1. Siapkan  Sambal kemangi
1. Gunakan 4 buah cabai merah besar
1. Gunakan 15 buah cabai rawit merah
1. Ambil 1 blok terasi a*c bakar
1. Gunakan secukupnya Garam
1. Gunakan secukupnya Gula pasir
1. Gunakan 1 ikat kecil kemangi
1. Gunakan 1 sdm minyak panas




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Penyet Sambal Kemangi:

1. Cuci bersih ayam,rendam ayam dgn bumbu marinasi selama 15 menit.
1. Campurkan semua adonan basah,aduk rata &amp; sisihkan.Di wadah berbeda campurkan adonan tepung kering,aduk rata.Panaskan minyak goreng dgn api sedang.
1. Masukan ayam yg SDH di marinasi ke dalam tepung basah,lumuri yg tercampur rata,tiriskan.Masukan ke dalam tepung kering hingga rata.Ulangi 1x lagi.(TDK perlu di cubit2)
1. Masukan ayam ke dalam minyak tadi,setelah ke 2 sisi nya kecokltan,kecilkan api (untuk menantang kan bagian dalam) angkat &amp; tiriskan.Lakukan hingga ayam habis.
1. Ulek cabai merah besar,cabai rawit,terasi bakar,gula &amp; garam,masukan bawang merah,memarkan.Kemudian masukan kemangi,tekan2 sedikit &amp; siram dgn minyak panas,aduk rata &amp; koreksi rasa. - Ambil ayam,letakkan di dalam cobek,pennyet2.Sajikan




Ternyata cara buat ayam penyet sambal kemangi yang mantab sederhana ini enteng sekali ya! Semua orang bisa memasaknya. Resep ayam penyet sambal kemangi Cocok sekali untuk anda yang baru akan belajar memasak maupun bagi anda yang sudah ahli dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam penyet sambal kemangi mantab sederhana ini? Kalau kamu tertarik, ayo kamu segera buruan siapkan alat dan bahannya, lalu buat deh Resep ayam penyet sambal kemangi yang lezat dan simple ini. Benar-benar mudah kan. 

Maka dari itu, daripada kamu diam saja, yuk kita langsung saja buat resep ayam penyet sambal kemangi ini. Dijamin anda gak akan menyesal sudah bikin resep ayam penyet sambal kemangi lezat tidak ribet ini! Selamat mencoba dengan resep ayam penyet sambal kemangi enak sederhana ini di rumah masing-masing,oke!.

