---
description: "Bahan-bahan *Ayam Penyet Sambel Ijo* yang lezat Untuk Jualan"
title: "Bahan-bahan *Ayam Penyet Sambel Ijo* yang lezat Untuk Jualan"
slug: 283-bahan-bahan-ayam-penyet-sambel-ijo-yang-lezat-untuk-jualan
date: 2021-03-09T17:04:49.926Z
image: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
author: Edgar Casey
ratingvalue: 4.4
reviewcount: 15
recipeingredient:
- "1/2 ekor ayam"
- "1 btg sereh"
- "2 lbr daun jeruk"
- " Bumbu ungkep ayam "
- "4 siung bwg merah Sy skip"
- "3 siung bwg putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt ketumbar"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya kaldu jamur sy skip"
- "Secukupnya air"
- " Bumbu sambel ijo "
- "8 cabe ijo keriting"
- "2 cabe ijo besar"
- "10 cabe rawit ijo"
- "1 buah tomat ijo"
- "3 siung bwg merah"
- "3 siung bwg putih"
- "2 sdm bumbu dasar cabe ijo tambahan sy           lihat resep"
recipeinstructions:
- "Cuci bersih ayam rebus hingga mendidih, angkat lalu rebus lagi bersama bumbu lainnya hingga bumbu meyerap dan airnya mengering. Lalu goreng hingga matang (sy, tidak terlalu kering), angkat sisihkan."
- "Cuci bahan sambal, potong2 lalu goreng hingga matang. Kemudian ulek kasar saja"
- "Tambahkan bumbu dasar cabe ijo, beri garam dan gula. Ulek hingga tercampur rata"
- "Taruh ayam goreng diatas.sambal lalu penyet dengan ulekan dan pindahkan dalam wadah saji"
- "Daan ayam penyet sambal ijo siap disajikan, ditambah perasan air jeruk nipis lebih enak"
categories:
- Resep
tags:
- ayam
- penyet
- sambel

katakunci: ayam penyet sambel 
nutrition: 210 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![*Ayam Penyet Sambel Ijo*](https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg)

Andai kalian seorang istri, menyuguhkan masakan mantab untuk famili adalah suatu hal yang membahagiakan bagi kita sendiri. Tugas seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, namun kamu pun harus memastikan kebutuhan nutrisi terpenuhi dan hidangan yang dikonsumsi anak-anak harus mantab.

Di era  saat ini, kalian sebenarnya bisa membeli masakan yang sudah jadi walaupun tidak harus repot mengolahnya lebih dulu. Namun banyak juga mereka yang selalu ingin memberikan hidangan yang terlezat bagi orang tercintanya. Lantaran, menyajikan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan sesuai dengan kesukaan keluarga. 



Mungkinkah kamu seorang penikmat *ayam penyet sambel ijo*?. Tahukah kamu, *ayam penyet sambel ijo* merupakan sajian khas di Indonesia yang saat ini disenangi oleh kebanyakan orang dari hampir setiap tempat di Indonesia. Kita bisa memasak *ayam penyet sambel ijo* sendiri di rumah dan boleh jadi hidangan favorit di hari liburmu.

Anda tak perlu bingung untuk menyantap *ayam penyet sambel ijo*, sebab *ayam penyet sambel ijo* gampang untuk ditemukan dan juga kita pun bisa membuatnya sendiri di rumah. *ayam penyet sambel ijo* dapat dibuat dengan bermacam cara. Saat ini sudah banyak sekali cara kekinian yang membuat *ayam penyet sambel ijo* semakin lebih nikmat.

Resep *ayam penyet sambel ijo* pun gampang sekali untuk dibuat, lho. Kamu tidak usah repot-repot untuk membeli *ayam penyet sambel ijo*, lantaran Kalian bisa menghidangkan ditempatmu. Bagi Kamu yang ingin mencobanya, inilah resep menyajikan *ayam penyet sambel ijo* yang mantab yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan *Ayam Penyet Sambel Ijo*:

1. Sediakan 1/2 ekor ayam
1. Sediakan 1 btg sereh
1. Siapkan 2 lbr daun jeruk
1. Sediakan  Bumbu ungkep ayam :
1. Gunakan 4 siung bwg merah (Sy, skip)
1. Sediakan 3 siung bwg putih
1. Gunakan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Gunakan 1 sdt ketumbar
1. Sediakan Secukupnya garam
1. Sediakan Secukupnya gula
1. Sediakan Secukupnya kaldu jamur (sy, skip)
1. Gunakan Secukupnya air
1. Gunakan  Bumbu sambel ijo :
1. Siapkan 8 cabe ijo keriting
1. Ambil 2 cabe ijo besar
1. Siapkan 10 cabe rawit ijo
1. Ambil 1 buah tomat ijo
1. Gunakan 3 siung bwg merah
1. Gunakan 3 siung bwg putih
1. Sediakan 2 sdm bumbu dasar cabe ijo (tambahan sy)           (lihat resep)




<!--inarticleads2-->

##### Cara menyiapkan *Ayam Penyet Sambel Ijo*:

1. Cuci bersih ayam rebus hingga mendidih, angkat lalu rebus lagi bersama bumbu lainnya hingga bumbu meyerap dan airnya mengering. Lalu goreng hingga matang (sy, tidak terlalu kering), angkat sisihkan.
1. Cuci bahan sambal, potong2 lalu goreng hingga matang. Kemudian ulek kasar saja
1. Tambahkan bumbu dasar cabe ijo, beri garam dan gula. Ulek hingga tercampur rata
1. Taruh ayam goreng diatas.sambal lalu penyet dengan ulekan dan pindahkan dalam wadah saji
1. Daan ayam penyet sambal ijo siap disajikan, ditambah perasan air jeruk nipis lebih enak




Ternyata resep *ayam penyet sambel ijo* yang lezat tidak rumit ini gampang banget ya! Kamu semua dapat memasaknya. Cara buat *ayam penyet sambel ijo* Sangat sesuai banget buat kalian yang sedang belajar memasak ataupun juga bagi kamu yang sudah lihai dalam memasak.

Tertarik untuk mulai mencoba membuat resep *ayam penyet sambel ijo* mantab simple ini? Kalau anda ingin, mending kamu segera menyiapkan alat-alat dan bahannya, setelah itu buat deh Resep *ayam penyet sambel ijo* yang nikmat dan tidak ribet ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, yuk kita langsung buat resep *ayam penyet sambel ijo* ini. Dijamin kamu gak akan nyesel membuat resep *ayam penyet sambel ijo* nikmat tidak ribet ini! Selamat berkreasi dengan resep *ayam penyet sambel ijo* nikmat tidak rumit ini di rumah masing-masing,ya!.

