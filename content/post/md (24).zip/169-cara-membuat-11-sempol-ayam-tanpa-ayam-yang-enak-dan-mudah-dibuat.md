---
description: "Cara membuat 11. Sempol Ayam tanpa Ayam yang enak dan Mudah Dibuat"
title: "Cara membuat 11. Sempol Ayam tanpa Ayam yang enak dan Mudah Dibuat"
slug: 169-cara-membuat-11-sempol-ayam-tanpa-ayam-yang-enak-dan-mudah-dibuat
date: 2021-01-15T22:27:45.714Z
image: https://img-global.cpcdn.com/recipes/a2b0b1f499b3db79/680x482cq70/11-sempol-ayam-tanpa-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a2b0b1f499b3db79/680x482cq70/11-sempol-ayam-tanpa-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a2b0b1f499b3db79/680x482cq70/11-sempol-ayam-tanpa-ayam-foto-resep-utama.jpg
author: Flora Austin
ratingvalue: 3
reviewcount: 13
recipeingredient:
- " Bahan A "
- "250 gr Tepung terigu"
- "100 gr Tepung tapioka"
- " Bahan B "
- "4 pcs Bawang merah"
- "3 siung Bawang putih"
- " Garam"
- " Gula"
- " Kaldu jamur"
- " Kaldu ayam bubuk"
- " Lada bubuk"
- " Bahan Tambahan "
- "2 butir Telor"
- " Air"
- " Minyak goreng"
recipeinstructions:
- "Panaskan air sampai mendidih"
- "Goreng bawang merah dan bawang putih, kemudian haluskan."
- "Basukkan bahan A dan bahan B yg sudah halus kedalam baskom. Aduk hingga tercampur rata. Masukkan air hangat sedikit demi sedikit, aduk hingga kalis. Uji rasa"
- "Adonan yg telah kalis di bentuk seperti pada gambar. Dan ditusuk dengan tusuk sate."
- "Didihkan air untuk merebus. Kemudian rebus adonan hingga mengapung (tandanya sempol sudah matang). Angkat dan tiriskan. Ulangi hingga adonan sempol habis."
- "Panaskan minyak. Kemudian goreng sempol di minyak yg telah panas (5 detik saja). Kemudian masukkan ke dalam telur yg sudah di kocok dan diberi sedikit garam dan sedikit air (biar gurih dan sedikit encer). Kemudian goreng lagi hingga coklat keemasan. Angkat dan tiriskan"
- "Telur kocok yg masih sisa bisa digoreng jd telor gulung yaa.. Selamat mencoba.."
categories:
- Resep
tags:
- 11
- sempol
- ayam

katakunci: 11 sempol ayam 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Lunch

---


![11. Sempol Ayam tanpa Ayam](https://img-global.cpcdn.com/recipes/a2b0b1f499b3db79/680x482cq70/11-sempol-ayam-tanpa-ayam-foto-resep-utama.jpg)

Andai kita seorang orang tua, mempersiapkan santapan nikmat kepada orang tercinta adalah suatu hal yang membahagiakan untuk kita sendiri. Kewajiban seorang  wanita bukan hanya menjaga rumah saja, tetapi kamu pun harus memastikan kebutuhan nutrisi tercukupi dan juga hidangan yang dikonsumsi keluarga tercinta harus sedap.

Di masa  saat ini, kamu sebenarnya dapat mengorder hidangan yang sudah jadi tidak harus capek mengolahnya lebih dulu. Tetapi banyak juga orang yang selalu ingin memberikan makanan yang terenak bagi orang yang dicintainya. Lantaran, memasak sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai masakan kesukaan keluarga. 



Mungkinkah anda adalah seorang penggemar 11. sempol ayam tanpa ayam?. Tahukah kamu, 11. sempol ayam tanpa ayam merupakan sajian khas di Nusantara yang saat ini disukai oleh orang-orang dari hampir setiap wilayah di Nusantara. Anda bisa menyajikan 11. sempol ayam tanpa ayam olahan sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di akhir pekan.

Anda tak perlu bingung jika kamu ingin memakan 11. sempol ayam tanpa ayam, lantaran 11. sempol ayam tanpa ayam gampang untuk dicari dan kalian pun bisa memasaknya sendiri di tempatmu. 11. sempol ayam tanpa ayam boleh diolah memalui bermacam cara. Saat ini sudah banyak banget resep modern yang membuat 11. sempol ayam tanpa ayam lebih enak.

Resep 11. sempol ayam tanpa ayam pun mudah sekali dibikin, lho. Kamu tidak usah ribet-ribet untuk membeli 11. sempol ayam tanpa ayam, sebab Kamu bisa menyajikan ditempatmu. Bagi Kita yang hendak menghidangkannya, inilah cara untuk membuat 11. sempol ayam tanpa ayam yang lezat yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan 11. Sempol Ayam tanpa Ayam:

1. Siapkan  Bahan A :
1. Ambil 250 gr Tepung terigu
1. Siapkan 100 gr Tepung tapioka
1. Sediakan  Bahan B :
1. Ambil 4 pcs Bawang merah
1. Gunakan 3 siung Bawang putih
1. Gunakan  Garam
1. Sediakan  Gula
1. Gunakan  Kaldu jamur
1. Ambil  Kaldu ayam bubuk
1. Gunakan  Lada bubuk
1. Sediakan  Bahan Tambahan :
1. Ambil 2 butir Telor
1. Siapkan  Air
1. Ambil  Minyak goreng




<!--inarticleads2-->

##### Cara membuat 11. Sempol Ayam tanpa Ayam:

1. Panaskan air sampai mendidih
1. Goreng bawang merah dan bawang putih, kemudian haluskan.
1. Basukkan bahan A dan bahan B yg sudah halus kedalam baskom. Aduk hingga tercampur rata. Masukkan air hangat sedikit demi sedikit, aduk hingga kalis. Uji rasa
1. Adonan yg telah kalis di bentuk seperti pada gambar. Dan ditusuk dengan tusuk sate.
1. Didihkan air untuk merebus. Kemudian rebus adonan hingga mengapung (tandanya sempol sudah matang). Angkat dan tiriskan. Ulangi hingga adonan sempol habis.
1. Panaskan minyak. Kemudian goreng sempol di minyak yg telah panas (5 detik saja). Kemudian masukkan ke dalam telur yg sudah di kocok dan diberi sedikit garam dan sedikit air (biar gurih dan sedikit encer). Kemudian goreng lagi hingga coklat keemasan. Angkat dan tiriskan
1. Telur kocok yg masih sisa bisa digoreng jd telor gulung yaa.. Selamat mencoba..




Ternyata resep 11. sempol ayam tanpa ayam yang nikamt simple ini enteng sekali ya! Kita semua bisa memasaknya. Cara buat 11. sempol ayam tanpa ayam Cocok sekali buat kita yang baru akan belajar memasak atau juga untuk kamu yang sudah pandai memasak.

Apakah kamu mau mencoba bikin resep 11. sempol ayam tanpa ayam lezat simple ini? Kalau kamu tertarik, yuk kita segera buruan menyiapkan alat dan bahannya, lantas buat deh Resep 11. sempol ayam tanpa ayam yang nikmat dan tidak ribet ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kalian diam saja, yuk kita langsung bikin resep 11. sempol ayam tanpa ayam ini. Dijamin anda gak akan nyesel sudah bikin resep 11. sempol ayam tanpa ayam nikmat tidak rumit ini! Selamat berkreasi dengan resep 11. sempol ayam tanpa ayam mantab tidak ribet ini di rumah kalian masing-masing,oke!.

