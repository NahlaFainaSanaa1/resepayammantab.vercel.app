---
description: "Bahan-bahan Kari Ayam Simple Sederhana Untuk Jualan"
title: "Bahan-bahan Kari Ayam Simple Sederhana Untuk Jualan"
slug: 223-bahan-bahan-kari-ayam-simple-sederhana-untuk-jualan
date: 2021-02-27T08:15:37.889Z
image: https://img-global.cpcdn.com/recipes/d09d0cf8db10adfc/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d09d0cf8db10adfc/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d09d0cf8db10adfc/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg
author: Millie Higgins
ratingvalue: 3.6
reviewcount: 11
recipeingredient:
- "1 ekor ayam"
- "150 ml santan kental"
- "200 ml air"
- "1 sendok teh garam"
- "1/2 sendok teh kaldu bubuk rasa ayam"
- "4 sendok makan minyak goreng"
- " Bahan Bumbu Halus"
- "10 siung bawang merah"
- "6 siung bawang putih"
- "10 buah cabai merah"
- "1 butir kemiri"
- "1 jari kunyit"
- "1/2 ibu jari jahe"
- "2 batang serai"
- "2 lembar daun jeruk"
- "5 butir kapulaga"
- "3 butir bunga lawang"
- "1/2 sendok teh jinten"
- "1 sendok teh ketumbar"
- "1 sendok teh merica"
recipeinstructions:
- "Siapkan ayam potong-potong seauai selera, cuci bersih kemudian rebus kira-kira 20 menit, lalu angkat dan tiriskan, sisahkan 200 ml air bekas merebus ayam."
- "Kemudian haluskan semua bahan bumbu halus, haluskan menggunakan belender, kemudian panaskan 4 sendok makan minyak, lalu tumis bumbu halus sampai harum."
- "Setelah bumbu tumis harum, masukan 200 ml air bekas merebus ayam, kemudian masukan santan, lalu masukan ayam yang sudah di rebus tadi, tambahkan garam dan kaldu bubuk, aduk rata, kecilkan api masak sampai kuah mengental, koreksi rasa, setelah di rasa cukup matikan api, angkat, taruh dalam wadah dan sajikan."
categories:
- Resep
tags:
- kari
- ayam
- simple

katakunci: kari ayam simple 
nutrition: 136 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Lunch

---


![Kari Ayam Simple](https://img-global.cpcdn.com/recipes/d09d0cf8db10adfc/680x482cq70/kari-ayam-simple-foto-resep-utama.jpg)

Andai anda seorang yang hobi memasak, mempersiapkan hidangan nikmat untuk famili merupakan suatu hal yang mengasyikan bagi anda sendiri. Tugas seorang  wanita bukan cuma menjaga rumah saja, namun kamu juga wajib menyediakan kebutuhan nutrisi tercukupi dan hidangan yang disantap keluarga tercinta wajib menggugah selera.

Di zaman  saat ini, kamu sebenarnya dapat mengorder masakan jadi meski tanpa harus ribet memasaknya terlebih dahulu. Tetapi ada juga lho mereka yang selalu mau menyajikan yang terlezat bagi orang tercintanya. Lantaran, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Mungkinkah kamu salah satu penikmat kari ayam simple?. Tahukah kamu, kari ayam simple adalah hidangan khas di Nusantara yang saat ini digemari oleh kebanyakan orang dari hampir setiap wilayah di Indonesia. Kalian bisa menghidangkan kari ayam simple sendiri di rumahmu dan boleh jadi makanan favorit di akhir pekan.

Kamu tak perlu bingung untuk menyantap kari ayam simple, karena kari ayam simple mudah untuk ditemukan dan juga kita pun boleh menghidangkannya sendiri di rumah. kari ayam simple bisa dibuat lewat berbagai cara. Kini pun telah banyak banget resep kekinian yang menjadikan kari ayam simple semakin lebih lezat.

Resep kari ayam simple pun mudah untuk dibuat, lho. Anda tidak usah ribet-ribet untuk membeli kari ayam simple, karena Kalian dapat menyiapkan sendiri di rumah. Bagi Anda yang mau menyajikannya, berikut ini resep membuat kari ayam simple yang enak yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Kari Ayam Simple:

1. Sediakan 1 ekor ayam
1. Gunakan 150 ml santan kental
1. Gunakan 200 ml air
1. Sediakan 1 sendok teh garam
1. Siapkan 1/2 sendok teh kaldu bubuk rasa ayam
1. Sediakan 4 sendok makan minyak goreng
1. Gunakan  Bahan Bumbu Halus
1. Ambil 10 siung bawang merah
1. Sediakan 6 siung bawang putih
1. Sediakan 10 buah cabai merah
1. Siapkan 1 butir kemiri
1. Sediakan 1 jari kunyit
1. Siapkan 1/2 ibu jari jahe
1. Siapkan 2 batang serai
1. Sediakan 2 lembar daun jeruk
1. Gunakan 5 butir kapulaga
1. Sediakan 3 butir bunga lawang
1. Sediakan 1/2 sendok teh jinten
1. Ambil 1 sendok teh ketumbar
1. Sediakan 1 sendok teh merica




<!--inarticleads2-->

##### Langkah-langkah membuat Kari Ayam Simple:

1. Siapkan ayam potong-potong seauai selera, cuci bersih kemudian rebus kira-kira 20 menit, lalu angkat dan tiriskan, sisahkan 200 ml air bekas merebus ayam.
1. Kemudian haluskan semua bahan bumbu halus, haluskan menggunakan belender, kemudian panaskan 4 sendok makan minyak, lalu tumis bumbu halus sampai harum.
1. Setelah bumbu tumis harum, masukan 200 ml air bekas merebus ayam, kemudian masukan santan, lalu masukan ayam yang sudah di rebus tadi, tambahkan garam dan kaldu bubuk, aduk rata, kecilkan api masak sampai kuah mengental, koreksi rasa, setelah di rasa cukup matikan api, angkat, taruh dalam wadah dan sajikan.




Ternyata cara buat kari ayam simple yang mantab simple ini enteng banget ya! Kalian semua mampu mencobanya. Resep kari ayam simple Sangat sesuai sekali untuk kalian yang baru mau belajar memasak ataupun bagi kalian yang telah lihai memasak.

Tertarik untuk mencoba buat resep kari ayam simple enak tidak rumit ini? Kalau kalian mau, ayo kalian segera buruan menyiapkan peralatan dan bahan-bahannya, lantas buat deh Resep kari ayam simple yang mantab dan tidak ribet ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kalian diam saja, maka langsung aja sajikan resep kari ayam simple ini. Dijamin kamu tak akan nyesel sudah membuat resep kari ayam simple mantab tidak rumit ini! Selamat mencoba dengan resep kari ayam simple enak tidak rumit ini di rumah kalian masing-masing,oke!.

