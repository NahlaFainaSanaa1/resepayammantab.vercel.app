---
description: "Cara buat Lontong Opor Ayam Sederhana dan Mudah Dibuat"
title: "Cara buat Lontong Opor Ayam Sederhana dan Mudah Dibuat"
slug: 401-cara-buat-lontong-opor-ayam-sederhana-dan-mudah-dibuat
date: 2021-03-02T11:46:04.435Z
image: https://img-global.cpcdn.com/recipes/dd7491563fa4a0c0/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dd7491563fa4a0c0/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dd7491563fa4a0c0/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
author: Ralph Henderson
ratingvalue: 4.4
reviewcount: 4
recipeingredient:
- "1/2 Kg Ayam pot sesuai selera"
- "3 bh Lontong"
- "1 sct Santan Instan"
- "1 L air"
- "Secukupnya garam  kaldu jamur"
- "2 lbr Daun Salam"
- "2 Lbr Daun Jeruk"
- " Bumbu halus "
- "7 bh bawang merah"
- "5 bh bawang putih"
- "4 bh kemiri"
- "1/2 sdt ketumbar"
- "1 ruas kunyit"
- "1 cm jahe"
recipeinstructions:
- "Cuci bersih ayam, sisihkan"
- "Panaskan minyak, tumis bumbu halus, daun salam dan daun jeruk hingga harum setelah itu masukan ayam aduk hingga ayam berubah warna beri air + santan instan aduk hingga tercampur rata, beri garam dan kaldu masak sambil terus di aduk biar santan tidak pecah setelah ayam empuk koreksi rasa dan selesai"
- "Siapkan potongan lontong di mangkok, beri ayam dan kuah secukupnya, beri sambal dan kerupuk sebagai pelengkap, siap di nikmati"
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 233 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dinner

---


![Lontong Opor Ayam](https://img-global.cpcdn.com/recipes/dd7491563fa4a0c0/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg)

Apabila anda seorang istri, menyuguhkan panganan lezat pada orang tercinta adalah hal yang mengasyikan untuk kita sendiri. Tugas seorang istri bukan sekadar menangani rumah saja, tapi anda juga wajib memastikan keperluan nutrisi tercukupi dan juga olahan yang dikonsumsi anak-anak mesti sedap.

Di zaman  saat ini, kamu sebenarnya mampu membeli santapan praktis meski tidak harus susah memasaknya dulu. Namun banyak juga orang yang selalu ingin memberikan makanan yang terlezat untuk orang tercintanya. Lantaran, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut berdasarkan selera famili. 



Mungkinkah anda adalah salah satu penggemar lontong opor ayam?. Asal kamu tahu, lontong opor ayam adalah makanan khas di Indonesia yang kini disukai oleh setiap orang di berbagai wilayah di Nusantara. Kamu bisa menyajikan lontong opor ayam olahan sendiri di rumah dan dapat dijadikan camilan favoritmu di akhir pekanmu.

Kamu jangan bingung jika kamu ingin memakan lontong opor ayam, karena lontong opor ayam tidak sukar untuk dicari dan juga kalian pun dapat menghidangkannya sendiri di rumah. lontong opor ayam dapat dibuat memalui berbagai cara. Saat ini ada banyak cara kekinian yang membuat lontong opor ayam semakin mantap.

Resep lontong opor ayam juga sangat mudah untuk dibikin, lho. Kalian tidak usah ribet-ribet untuk membeli lontong opor ayam, karena Kita mampu menghidangkan di rumah sendiri. Untuk Kamu yang akan menyajikannya, berikut ini cara untuk menyajikan lontong opor ayam yang enak yang bisa Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Lontong Opor Ayam:

1. Gunakan 1/2 Kg Ayam (pot sesuai selera)
1. Gunakan 3 bh Lontong
1. Sediakan 1 sct Santan Instan
1. Ambil 1 L air
1. Sediakan Secukupnya garam &amp; kaldu jamur
1. Siapkan 2 lbr Daun Salam
1. Sediakan 2 Lbr Daun Jeruk
1. Sediakan  Bumbu halus :
1. Siapkan 7 bh bawang merah
1. Siapkan 5 bh bawang putih
1. Ambil 4 bh kemiri
1. Sediakan 1/2 sdt ketumbar
1. Gunakan 1 ruas kunyit
1. Siapkan 1 cm jahe




<!--inarticleads2-->

##### Cara membuat Lontong Opor Ayam:

1. Cuci bersih ayam, sisihkan
1. Panaskan minyak, tumis bumbu halus, daun salam dan daun jeruk hingga harum setelah itu masukan ayam aduk hingga ayam berubah warna beri air + santan instan aduk hingga tercampur rata, beri garam dan kaldu masak sambil terus di aduk biar santan tidak pecah setelah ayam empuk koreksi rasa dan selesai
1. Siapkan potongan lontong di mangkok, beri ayam dan kuah secukupnya, beri sambal dan kerupuk sebagai pelengkap, siap di nikmati




Ternyata cara buat lontong opor ayam yang lezat tidak rumit ini enteng sekali ya! Kamu semua bisa menghidangkannya. Cara buat lontong opor ayam Sangat cocok banget buat kamu yang baru akan belajar memasak ataupun juga bagi kamu yang sudah lihai memasak.

Tertarik untuk mulai mencoba membuat resep lontong opor ayam lezat sederhana ini? Kalau kalian tertarik, ayo kalian segera buruan siapin alat dan bahannya, setelah itu buat deh Resep lontong opor ayam yang nikmat dan tidak ribet ini. Sangat gampang kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, ayo kita langsung saja sajikan resep lontong opor ayam ini. Dijamin kamu tak akan menyesal sudah buat resep lontong opor ayam mantab tidak rumit ini! Selamat berkreasi dengan resep lontong opor ayam nikmat tidak ribet ini di tempat tinggal kalian sendiri,ya!.

