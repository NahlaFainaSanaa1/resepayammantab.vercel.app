---
description: "Cara membuat Sempol Tanpa Ayam (Ekonomis dan Mudah) yang enak Untuk Jualan"
title: "Cara membuat Sempol Tanpa Ayam (Ekonomis dan Mudah) yang enak Untuk Jualan"
slug: 176-cara-membuat-sempol-tanpa-ayam-ekonomis-dan-mudah-yang-enak-untuk-jualan
date: 2021-02-22T04:21:39.036Z
image: https://img-global.cpcdn.com/recipes/072175789c887e9e/680x482cq70/sempol-tanpa-ayam-ekonomis-dan-mudah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/072175789c887e9e/680x482cq70/sempol-tanpa-ayam-ekonomis-dan-mudah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/072175789c887e9e/680x482cq70/sempol-tanpa-ayam-ekonomis-dan-mudah-foto-resep-utama.jpg
author: Lucille Burns
ratingvalue: 3.5
reviewcount: 6
recipeingredient:
- "250 gr tepung terigu"
- "250 gr tepung sagu merk merbabu"
- "250 ml air sesuaikan dengan adonan bisa ditambah"
- "1 sachet Royco ayam"
- "4 siung bawang putih haluskan"
- "secukupnya Garam dan lada"
- "3 butir telur kocok Untuk balutan"
recipeinstructions:
- "Panaskan air sampai mendidih lalu masukkan terigu, aduk sampai rata,  Lalu angkat."
- "Kemudian masukkan tepung sagu dan bawang putih serta bahan lainnya. Aduk kembali sampai kalis. Bisa ditambah air jika kurang."
- "Bentuk lonjong dan ditusuk sate. Kemudian direbus sampai mengapung. Angkat dan tiriskan."
- "Goreng adonan sampai setengah matang lalu angkat dan gulingkan di kocokan telur, lalu masukkan kembali di wajan. Lakukan 2x supaya lebih tebal dan crispy."
- "Setelah kecoklatan, angkat dan tiriskan. Siap disajikan pakai cocolan sambal. Lebih nikmat disantap saat hangat."
categories:
- Resep
tags:
- sempol
- tanpa
- ayam

katakunci: sempol tanpa ayam 
nutrition: 202 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Sempol Tanpa Ayam (Ekonomis dan Mudah)](https://img-global.cpcdn.com/recipes/072175789c887e9e/680x482cq70/sempol-tanpa-ayam-ekonomis-dan-mudah-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyajikan masakan enak buat keluarga merupakan suatu hal yang menyenangkan untuk kita sendiri. Peran seorang  wanita bukan hanya mengatur rumah saja, tetapi anda pun harus memastikan keperluan gizi tercukupi dan masakan yang disantap anak-anak mesti lezat.

Di zaman  sekarang, kalian memang bisa membeli santapan praktis meski tanpa harus capek memasaknya dulu. Namun ada juga lho mereka yang memang ingin memberikan makanan yang terenak bagi keluarganya. Sebab, memasak yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan famili. 



Apakah anda adalah salah satu penyuka sempol tanpa ayam (ekonomis dan mudah)?. Tahukah kamu, sempol tanpa ayam (ekonomis dan mudah) merupakan makanan khas di Indonesia yang kini digemari oleh banyak orang di berbagai wilayah di Nusantara. Kamu dapat membuat sempol tanpa ayam (ekonomis dan mudah) sendiri di rumah dan boleh dijadikan hidangan kesenanganmu di akhir pekanmu.

Kalian tidak perlu bingung untuk memakan sempol tanpa ayam (ekonomis dan mudah), sebab sempol tanpa ayam (ekonomis dan mudah) mudah untuk didapatkan dan juga kalian pun boleh menghidangkannya sendiri di rumah. sempol tanpa ayam (ekonomis dan mudah) boleh dimasak memalui beraneka cara. Kini pun telah banyak resep kekinian yang menjadikan sempol tanpa ayam (ekonomis dan mudah) semakin lebih mantap.

Resep sempol tanpa ayam (ekonomis dan mudah) juga mudah untuk dibuat, lho. Anda tidak perlu capek-capek untuk membeli sempol tanpa ayam (ekonomis dan mudah), sebab Anda dapat menghidangkan ditempatmu. Untuk Kita yang mau membuatnya, berikut ini cara untuk menyajikan sempol tanpa ayam (ekonomis dan mudah) yang lezat yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Sempol Tanpa Ayam (Ekonomis dan Mudah):

1. Sediakan 250 gr tepung terigu
1. Gunakan 250 gr tepung sagu (merk merbabu)
1. Siapkan 250 ml air (sesuaikan dengan adonan, bisa ditambah)
1. Sediakan 1 sachet Royco ayam
1. Gunakan 4 siung bawang putih, haluskan
1. Ambil secukupnya Garam dan lada
1. Sediakan 3 butir telur, kocok. Untuk balutan




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Sempol Tanpa Ayam (Ekonomis dan Mudah):

1. Panaskan air sampai mendidih lalu masukkan terigu, aduk sampai rata,  - Lalu angkat.
1. Kemudian masukkan tepung sagu dan bawang putih serta bahan lainnya. Aduk kembali sampai kalis. Bisa ditambah air jika kurang.
1. Bentuk lonjong dan ditusuk sate. Kemudian direbus sampai mengapung. Angkat dan tiriskan.
1. Goreng adonan sampai setengah matang lalu angkat dan gulingkan di kocokan telur, lalu masukkan kembali di wajan. Lakukan 2x supaya lebih tebal dan crispy.
1. Setelah kecoklatan, angkat dan tiriskan. Siap disajikan pakai cocolan sambal. Lebih nikmat disantap saat hangat.




Ternyata cara membuat sempol tanpa ayam (ekonomis dan mudah) yang lezat tidak ribet ini mudah banget ya! Kalian semua dapat menghidangkannya. Cara Membuat sempol tanpa ayam (ekonomis dan mudah) Sesuai sekali untuk anda yang baru akan belajar memasak maupun juga untuk anda yang sudah lihai dalam memasak.

Apakah kamu tertarik mencoba membikin resep sempol tanpa ayam (ekonomis dan mudah) lezat tidak ribet ini? Kalau kamu mau, mending kamu segera buruan siapkan alat-alat dan bahannya, lantas bikin deh Resep sempol tanpa ayam (ekonomis dan mudah) yang mantab dan tidak ribet ini. Benar-benar taidak sulit kan. 

Maka, ketimbang kamu berlama-lama, hayo kita langsung saja bikin resep sempol tanpa ayam (ekonomis dan mudah) ini. Dijamin anda tiidak akan menyesal bikin resep sempol tanpa ayam (ekonomis dan mudah) enak tidak rumit ini! Selamat mencoba dengan resep sempol tanpa ayam (ekonomis dan mudah) lezat tidak rumit ini di rumah sendiri,oke!.

