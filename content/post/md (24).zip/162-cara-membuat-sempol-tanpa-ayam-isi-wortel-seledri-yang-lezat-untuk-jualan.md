---
description: "Cara membuat Sempol tanpa ayam isi wortel seledri yang lezat Untuk Jualan"
title: "Cara membuat Sempol tanpa ayam isi wortel seledri yang lezat Untuk Jualan"
slug: 162-cara-membuat-sempol-tanpa-ayam-isi-wortel-seledri-yang-lezat-untuk-jualan
date: 2021-05-21T05:21:38.718Z
image: https://img-global.cpcdn.com/recipes/3ed423762e75df71/680x482cq70/sempol-tanpa-ayam-isi-wortel-seledri-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3ed423762e75df71/680x482cq70/sempol-tanpa-ayam-isi-wortel-seledri-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3ed423762e75df71/680x482cq70/sempol-tanpa-ayam-isi-wortel-seledri-foto-resep-utama.jpg
author: Marie Norman
ratingvalue: 3.3
reviewcount: 5
recipeingredient:
- "1/2 kg tepung kanjitapioka"
- "1/4 kg tepung terigu"
- "5 sdm garam"
- "3 sdm merica bubuk ladaku"
- "1 sachet masako ayam"
- "2 butir telur"
- "1 wortel besar"
- "3 siung bawang putih"
- " Seledri"
- " Air panas"
recipeinstructions:
- "Haluskan 3 siung bawang putih, lalu potong dadu kecil-kecil wortel dan seledri"
- "Masak air hingga mendidih (menggunakan air panas supaya nanti renyah tidak alot)"
- "Campur tepung terigu, tepung kanji, masako ayam secukupnya, 5 sdm garam, 3 sdm bubuk merica, dan bawang putih yg sudah dihaluskan sambil diulen dengan air panas hingga kalis (tidak lengket di tangan) masukkan potongan wortel dan seledri"
- "Siapkan &amp; kocok 2 telur untuk menggoreng adonan"
- "Sempol siap dihidangkan😊"
categories:
- Resep
tags:
- sempol
- tanpa
- ayam

katakunci: sempol tanpa ayam 
nutrition: 219 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Sempol tanpa ayam isi wortel seledri](https://img-global.cpcdn.com/recipes/3ed423762e75df71/680x482cq70/sempol-tanpa-ayam-isi-wortel-seledri-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan hidangan menggugah selera buat orang tercinta adalah hal yang mengasyikan untuk kamu sendiri. Tanggung jawab seorang ibu Tidak hanya mengatur rumah saja, namun kamu pun wajib memastikan kebutuhan gizi terpenuhi dan santapan yang dikonsumsi anak-anak wajib mantab.

Di zaman  sekarang, kamu memang dapat mengorder hidangan praktis walaupun tidak harus susah mengolahnya lebih dulu. Namun banyak juga lho orang yang selalu mau menghidangkan yang terenak bagi orang tercintanya. Sebab, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan selera famili. 



Mungkinkah anda adalah salah satu penyuka sempol tanpa ayam isi wortel seledri?. Tahukah kamu, sempol tanpa ayam isi wortel seledri merupakan sajian khas di Nusantara yang kini digemari oleh kebanyakan orang di berbagai wilayah di Indonesia. Kalian bisa menghidangkan sempol tanpa ayam isi wortel seledri sendiri di rumahmu dan boleh dijadikan hidangan kegemaranmu di hari libur.

Kalian jangan bingung untuk mendapatkan sempol tanpa ayam isi wortel seledri, karena sempol tanpa ayam isi wortel seledri gampang untuk ditemukan dan juga kamu pun boleh menghidangkannya sendiri di rumah. sempol tanpa ayam isi wortel seledri boleh diolah dengan beraneka cara. Sekarang sudah banyak sekali cara modern yang menjadikan sempol tanpa ayam isi wortel seledri semakin lebih nikmat.

Resep sempol tanpa ayam isi wortel seledri pun gampang untuk dibuat, lho. Anda tidak perlu capek-capek untuk membeli sempol tanpa ayam isi wortel seledri, lantaran Kita mampu menyiapkan sendiri di rumah. Bagi Kalian yang mau mencobanya, dibawah ini merupakan cara menyajikan sempol tanpa ayam isi wortel seledri yang nikamat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Sempol tanpa ayam isi wortel seledri:

1. Sediakan 1/2 kg tepung kanji/tapioka
1. Siapkan 1/4 kg tepung terigu
1. Ambil 5 sdm garam
1. Siapkan 3 sdm merica bubuk (ladaku)
1. Ambil 1 sachet masako ayam
1. Siapkan 2 butir telur
1. Siapkan 1 wortel besar
1. Siapkan 3 siung bawang putih
1. Sediakan  Seledri
1. Gunakan  Air panas




<!--inarticleads2-->

##### Langkah-langkah membuat Sempol tanpa ayam isi wortel seledri:

1. Haluskan 3 siung bawang putih, lalu potong dadu kecil-kecil wortel dan seledri
1. Masak air hingga mendidih (menggunakan air panas supaya nanti renyah tidak alot)
1. Campur tepung terigu, tepung kanji, masako ayam secukupnya, 5 sdm garam, 3 sdm bubuk merica, dan bawang putih yg sudah dihaluskan sambil diulen dengan air panas hingga kalis (tidak lengket di tangan) masukkan potongan wortel dan seledri
1. Siapkan &amp; kocok 2 telur untuk menggoreng adonan
1. Sempol siap dihidangkan😊




Wah ternyata cara membuat sempol tanpa ayam isi wortel seledri yang enak tidak rumit ini mudah banget ya! Semua orang bisa menghidangkannya. Cara buat sempol tanpa ayam isi wortel seledri Cocok sekali untuk kita yang sedang belajar memasak ataupun bagi kalian yang telah pandai dalam memasak.

Apakah kamu tertarik mencoba membikin resep sempol tanpa ayam isi wortel seledri lezat simple ini? Kalau anda mau, yuk kita segera buruan menyiapkan alat-alat dan bahannya, maka bikin deh Resep sempol tanpa ayam isi wortel seledri yang lezat dan simple ini. Benar-benar gampang kan. 

Jadi, daripada kamu berlama-lama, yuk kita langsung hidangkan resep sempol tanpa ayam isi wortel seledri ini. Pasti kamu tiidak akan menyesal sudah membuat resep sempol tanpa ayam isi wortel seledri enak tidak rumit ini! Selamat mencoba dengan resep sempol tanpa ayam isi wortel seledri nikmat tidak rumit ini di rumah masing-masing,ya!.

