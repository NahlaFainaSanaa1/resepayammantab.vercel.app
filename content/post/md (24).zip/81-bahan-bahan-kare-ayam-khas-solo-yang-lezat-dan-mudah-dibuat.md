---
description: "Bahan-bahan Kare Ayam khas Solo yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Kare Ayam khas Solo yang lezat dan Mudah Dibuat"
slug: 81-bahan-bahan-kare-ayam-khas-solo-yang-lezat-dan-mudah-dibuat
date: 2021-01-12T11:46:14.415Z
image: https://img-global.cpcdn.com/recipes/ff17a8d3a097dcfc/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff17a8d3a097dcfc/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff17a8d3a097dcfc/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg
author: Wayne Dunn
ratingvalue: 3.9
reviewcount: 14
recipeingredient:
- "1 ekor ayam"
- "2 batang sereh memarkan"
- "3 lbr Daun salam"
- "3 lbrbDaun jeruk"
- "2 rj Laos"
- "200 ml Kara"
- " Air"
- "1 jari kayu manis"
- "1 bks kapulaga 1k"
- " Kaldu bubuk"
- " Bumbu halus "
- "10 siung Bawang merah"
- "6 siung Bawang putih"
- "1 bks Jinten 1k"
- "1/2 sdt Ketumbar bubuk"
- "1/2 sdt lada bubuk"
- "1 sdt kunyit bubuk"
- "1/4 sdt Paladisisir"
- "3 buah Kemiridibakar dulu yaa"
- "1 sdm Garam"
- "1 sdt Gula"
- " Pelengkap "
- " Wortel rebusdipotongbulat tipisyg td direbus dikaldu"
- " Bihunrendam air hangatdigunting"
- " Keripik kentang           lihat resep"
- " Sambal dari cabe  bawang putih yg direbus           lihat resep"
- "1 bks kecambahdibilas air anget yaa"
- " Suiran ayam"
- " Bawang goreng           lihat resep"
recipeinstructions:
- "Siapkan semua bahan. Cuci bersih ayam dan bahan yang lain."
- "Didihkan air. Rebus ayam hingga berubah warna/setengah matang. Tiriskan ayam. Buang air rebusan nya.(diblansir) Rebus kembali ayam dengan air yang baru,tambahkan kayu manis, kapulaga dan 1 sdt garam. Tambahan diresepku : Tambahkan wortel utuh ya..rebus kembali sampai mendidih.saat merebus jika dirasa wotel udah masak angkat yaa dan sisihkan untuk topping.sementara rebus ayam kita menghaluskan dan menumis bumbu yaa."
- "Tumis bumbu yang sudah dihaluskan, tambahkan daun salam, daun jeruk, lengkuas, serai hingga harum dan matang.tambahkan ke dalam air kaldu.           (lihat tips)"
- "Tambahkan santan. Aduk rata, beri gula, garam, kaldu bubuk. Tunggu sampai mendidih, Koreksi rasa"
- "Aduk perlahan. Masak hingga ayam matang(ambil ayam,lalu disuir). Tambahkan santan,cek rasa. Siapkan bahan pelengkap yaa... Untuk sambal soto bisa liat disini yaa...           (lihat resep)"
- "Cara penyajian : Tata di piring saji nasi,wortel,keripik kentang,soun, suiran/potongan kecil ayam lalu disiram kuah karenya."
categories:
- Resep
tags:
- kare
- ayam
- khas

katakunci: kare ayam khas 
nutrition: 199 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Lunch

---


![Kare Ayam khas Solo](https://img-global.cpcdn.com/recipes/ff17a8d3a097dcfc/680x482cq70/kare-ayam-khas-solo-foto-resep-utama.jpg)

Andai kalian seorang ibu, menyuguhkan santapan sedap bagi keluarga tercinta merupakan suatu hal yang menggembirakan bagi kita sendiri. Kewajiban seorang istri bukan saja menangani rumah saja, tetapi anda juga harus memastikan kebutuhan nutrisi tercukupi dan juga hidangan yang dikonsumsi orang tercinta harus lezat.

Di era  saat ini, anda memang mampu mengorder panganan jadi tanpa harus ribet membuatnya lebih dulu. Namun banyak juga orang yang selalu mau memberikan hidangan yang terlezat untuk orang tercintanya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penyuka kare ayam khas solo?. Asal kamu tahu, kare ayam khas solo adalah makanan khas di Nusantara yang saat ini digemari oleh banyak orang di hampir setiap tempat di Indonesia. Kita dapat membuat kare ayam khas solo sendiri di rumahmu dan boleh jadi hidangan favorit di akhir pekan.

Anda tak perlu bingung untuk mendapatkan kare ayam khas solo, sebab kare ayam khas solo tidak sulit untuk dicari dan kalian pun dapat memasaknya sendiri di rumah. kare ayam khas solo bisa dimasak memalui beragam cara. Kini telah banyak cara kekinian yang membuat kare ayam khas solo semakin enak.

Resep kare ayam khas solo juga gampang untuk dibuat, lho. Anda tidak usah capek-capek untuk membeli kare ayam khas solo, lantaran Kita bisa menyiapkan ditempatmu. Bagi Kita yang hendak membuatnya, dibawah ini merupakan resep untuk menyajikan kare ayam khas solo yang lezat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Kare Ayam khas Solo:

1. Ambil 1 ekor ayam
1. Ambil 2 batang sereh, memarkan
1. Sediakan 3 lbr Daun salam
1. Sediakan 3 lbrbDaun jeruk
1. Siapkan 2 rj Laos
1. Sediakan 200 ml Kara
1. Ambil  Air
1. Sediakan 1 jari kayu manis
1. Sediakan 1 bks kapulaga @1k
1. Siapkan  Kaldu bubuk
1. Ambil  Bumbu halus :
1. Gunakan 10 siung Bawang merah
1. Ambil 6 siung Bawang putih
1. Sediakan 1 bks Jinten @1k
1. Ambil 1/2 sdt Ketumbar bubuk
1. Gunakan 1/2 sdt lada bubuk
1. Siapkan 1 sdt kunyit bubuk
1. Sediakan 1/4 sdt Pala,disisir
1. Sediakan 3 buah Kemiri,dibakar dulu yaa
1. Ambil 1 sdm Garam
1. Gunakan 1 sdt Gula
1. Gunakan  Pelengkap :
1. Sediakan  Wortel rebus,dipotong&#34;bulat tipis(yg td direbus dikaldu)
1. Ambil  Bihun,rendam air hangat,digunting&#34;
1. Ambil  Keripik kentang           (lihat resep)
1. Ambil  Sambal dari cabe &amp; bawang putih yg direbus           (lihat resep)
1. Ambil 1 bks kecambah,dibilas air anget yaa
1. Sediakan  Suiran ayam
1. Gunakan  Bawang goreng           (lihat resep)




<!--inarticleads2-->

##### Cara menyiapkan Kare Ayam khas Solo:

1. Siapkan semua bahan. Cuci bersih ayam dan bahan yang lain.
1. Didihkan air. Rebus ayam hingga berubah warna/setengah matang. Tiriskan ayam. Buang air rebusan nya.(diblansir) Rebus kembali ayam dengan air yang baru,tambahkan kayu manis, kapulaga dan 1 sdt garam. - Tambahan diresepku : Tambahkan wortel utuh ya..rebus kembali sampai mendidih.saat merebus jika dirasa wotel udah masak angkat yaa dan sisihkan untuk topping.sementara rebus ayam kita menghaluskan dan menumis bumbu yaa.
1. Tumis bumbu yang sudah dihaluskan, tambahkan daun salam, daun jeruk, lengkuas, serai hingga harum dan matang.tambahkan ke dalam air kaldu. -           (lihat tips)
1. Tambahkan santan. Aduk rata, beri gula, garam, kaldu bubuk. Tunggu sampai mendidih, Koreksi rasa
1. Aduk perlahan. Masak hingga ayam matang(ambil ayam,lalu disuir). Tambahkan santan,cek rasa. - Siapkan bahan pelengkap yaa... - Untuk sambal soto bisa liat disini yaa... -           (lihat resep)
1. Cara penyajian : - Tata di piring saji nasi,wortel,keripik kentang,soun, suiran/potongan kecil ayam lalu disiram kuah karenya.




Ternyata cara membuat kare ayam khas solo yang lezat simple ini mudah sekali ya! Kita semua bisa menghidangkannya. Cara buat kare ayam khas solo Sangat cocok sekali untuk kita yang sedang belajar memasak ataupun juga bagi anda yang sudah pandai dalam memasak.

Tertarik untuk mulai mencoba membuat resep kare ayam khas solo lezat simple ini? Kalau kamu ingin, ayo kamu segera siapkan alat-alat dan bahan-bahannya, kemudian bikin deh Resep kare ayam khas solo yang lezat dan tidak ribet ini. Sungguh taidak sulit kan. 

Maka, ketimbang kalian berfikir lama-lama, maka kita langsung saja buat resep kare ayam khas solo ini. Dijamin kamu tiidak akan menyesal bikin resep kare ayam khas solo mantab sederhana ini! Selamat berkreasi dengan resep kare ayam khas solo lezat tidak ribet ini di tempat tinggal masing-masing,ya!.

