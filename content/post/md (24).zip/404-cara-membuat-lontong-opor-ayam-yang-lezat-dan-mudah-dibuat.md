---
description: "Cara membuat Lontong Opor Ayam yang lezat dan Mudah Dibuat"
title: "Cara membuat Lontong Opor Ayam yang lezat dan Mudah Dibuat"
slug: 404-cara-membuat-lontong-opor-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-06-25T14:03:18.099Z
image: https://img-global.cpcdn.com/recipes/6201aa7d59fbc9e2/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6201aa7d59fbc9e2/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6201aa7d59fbc9e2/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg
author: Lillian Arnold
ratingvalue: 4.3
reviewcount: 12
recipeingredient:
- "500 gram ayam"
- "1 liter santan"
- "2 gelas air"
- "2 lembar daun salam"
- "1 batang sereh geprek"
- "1 ruas lengkuas geprek"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya kaldu bubuk"
- " Bumbu halus"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "2 butir kemiri"
- "1 sdt ketumbar"
- "1 sdt merica"
- " Bahan pelengkap"
- " Lontong"
- " Sambal"
- " Kerupuk"
- " Bawang goreng untuk taburan"
recipeinstructions:
- "Potong-potong ayam, cuci bersih lalu tiriskan."
- "Rebus ayam dalam panci. Sambil merebus ayam, tumis bumbu halus dalam wajan sampai harum. Lalu masukkan kedalam rebusan ayam, tambahkan daun salam, lengkuas, sereh. Masak sampai ayam empuk."
- "Masukkan santan. Tambahkan garam, gula pasir dan kaldu bubuk. Masak sampai Mendidih, sambil di aduk-aduk supaya santan tidak pecah."
- "Penyajian: Tata lontong dalam mangkuk, lalu tambahkan opor ayamnya. Beri taburan bawang goreng. Sajikan bersama kerupuk dan sambal bila suka pedas."
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 232 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dinner

---


![Lontong Opor Ayam](https://img-global.cpcdn.com/recipes/6201aa7d59fbc9e2/680x482cq70/lontong-opor-ayam-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan masakan lezat pada keluarga merupakan hal yang membahagiakan untuk anda sendiri. Tugas seorang istri Tidak cuma mengatur rumah saja, namun anda pun wajib menyediakan keperluan nutrisi terpenuhi dan juga masakan yang dikonsumsi anak-anak wajib menggugah selera.

Di waktu  saat ini, anda sebenarnya dapat membeli olahan siap saji tidak harus capek mengolahnya dahulu. Tapi ada juga lho orang yang selalu mau memberikan yang terenak untuk keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai masakan kesukaan keluarga tercinta. 



Apakah kamu salah satu penggemar lontong opor ayam?. Asal kamu tahu, lontong opor ayam adalah makanan khas di Nusantara yang kini disenangi oleh orang-orang dari berbagai wilayah di Nusantara. Kalian dapat memasak lontong opor ayam sendiri di rumahmu dan dapat dijadikan santapan kesukaanmu di akhir pekanmu.

Kita jangan bingung untuk memakan lontong opor ayam, lantaran lontong opor ayam mudah untuk ditemukan dan kamu pun bisa memasaknya sendiri di rumah. lontong opor ayam boleh dibuat memalui beragam cara. Kini pun sudah banyak resep modern yang membuat lontong opor ayam semakin lebih enak.

Resep lontong opor ayam pun mudah sekali untuk dibuat, lho. Kamu jangan capek-capek untuk memesan lontong opor ayam, sebab Kamu mampu menghidangkan sendiri di rumah. Untuk Kita yang ingin menghidangkannya, dibawah ini merupakan resep untuk membuat lontong opor ayam yang lezat yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Lontong Opor Ayam:

1. Ambil 500 gram ayam
1. Gunakan 1 liter santan
1. Ambil 2 gelas air
1. Ambil 2 lembar daun salam
1. Siapkan 1 batang sereh, geprek
1. Gunakan 1 ruas lengkuas, geprek
1. Gunakan Secukupnya garam
1. Siapkan Secukupnya gula pasir
1. Ambil Secukupnya kaldu bubuk
1. Gunakan  Bumbu halus:
1. Sediakan 4 siung bawang merah
1. Ambil 2 siung bawang putih
1. Gunakan 1 ruas kunyit
1. Gunakan 1 ruas jahe
1. Siapkan 2 butir kemiri
1. Ambil 1 sdt ketumbar
1. Sediakan 1 sdt merica
1. Sediakan  Bahan pelengkap:
1. Siapkan  Lontong
1. Gunakan  Sambal
1. Gunakan  Kerupuk
1. Sediakan  Bawang goreng untuk taburan




<!--inarticleads2-->

##### Cara membuat Lontong Opor Ayam:

1. Potong-potong ayam, cuci bersih lalu tiriskan.
1. Rebus ayam dalam panci. Sambil merebus ayam, tumis bumbu halus dalam wajan sampai harum. Lalu masukkan kedalam rebusan ayam, tambahkan daun salam, lengkuas, sereh. Masak sampai ayam empuk.
1. Masukkan santan. Tambahkan garam, gula pasir dan kaldu bubuk. Masak sampai Mendidih, sambil di aduk-aduk supaya santan tidak pecah.
1. Penyajian: Tata lontong dalam mangkuk, lalu tambahkan opor ayamnya. Beri taburan bawang goreng. Sajikan bersama kerupuk dan sambal bila suka pedas.




Ternyata resep lontong opor ayam yang lezat simple ini gampang banget ya! Kalian semua mampu menghidangkannya. Cara buat lontong opor ayam Sangat sesuai banget buat kamu yang baru akan belajar memasak ataupun juga bagi kamu yang sudah jago memasak.

Apakah kamu tertarik mulai mencoba membuat resep lontong opor ayam enak simple ini? Kalau kalian tertarik, ayo kalian segera siapkan peralatan dan bahan-bahannya, maka buat deh Resep lontong opor ayam yang enak dan sederhana ini. Sangat mudah kan. 

Maka, ketimbang anda berlama-lama, ayo kita langsung saja buat resep lontong opor ayam ini. Dijamin kamu tiidak akan nyesel membuat resep lontong opor ayam nikmat tidak rumit ini! Selamat berkreasi dengan resep lontong opor ayam mantab simple ini di rumah sendiri,ya!.

