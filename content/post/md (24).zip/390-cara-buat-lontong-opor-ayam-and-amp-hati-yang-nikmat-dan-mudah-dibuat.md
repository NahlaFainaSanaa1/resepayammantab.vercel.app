---
description: "Cara buat Lontong Opor Ayam &amp;amp; Hati yang nikmat dan Mudah Dibuat"
title: "Cara buat Lontong Opor Ayam &amp;amp; Hati yang nikmat dan Mudah Dibuat"
slug: 390-cara-buat-lontong-opor-ayam-and-amp-hati-yang-nikmat-dan-mudah-dibuat
date: 2021-02-12T18:24:54.047Z
image: https://img-global.cpcdn.com/recipes/07aa4f7c193c2933/680x482cq70/lontong-opor-ayam-hati-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/07aa4f7c193c2933/680x482cq70/lontong-opor-ayam-hati-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/07aa4f7c193c2933/680x482cq70/lontong-opor-ayam-hati-foto-resep-utama.jpg
author: Ryan Jenkins
ratingvalue: 4.2
reviewcount: 3
recipeingredient:
- "1/2 kg ayam"
- "5 buah hati ayam"
- "1 liter santan"
- "2 sdmgl pasir"
- " Garam sckp"
- " Kaldu jamur"
- "1/2 sdt lada bubuk"
- " Bumbu halus"
- "6 siung bamer"
- "3 siung baput"
- "Seruas jahe"
- "3 ruas kunyit"
- "1/2 sdt ketumbar"
- "5 biji kemiri"
- " Empon2"
- "1 batang serai"
- "4 daun salam"
- "3 ruas lengkuas"
- " Sambel kentang"
- "1/4 kg kentang goreng"
- "4 buah Rempola hati ayam potong"
- "4 bamer"
- "3 baput"
- " Garamgulakaldu sckp"
- "2 kemiri"
- "3 cabe merah"
- "5 cabe rawit"
- "Seruas loas"
- "Selembar daun salam"
- "2 daun jeruk"
- " Bahan pelengkap"
- " Lontong"
- " Bawang goreng"
recipeinstructions:
- "Sebelumnya rebus ayam dan hati ayam dgn daun salam selama 20 menit. Angkat tiriskan."
- "Tumis bumbu yg sdh dihaluskan tambahkan empon2..tumis sampaj harum dan agak kering. Masukan ayam dan hati ayam. Tambahkan santan, gula pasir, kaldu jamur dan garam. Cek rasa."
- "Sambel goreng kentang, tumis smua bumbunya yg sdh dihaluskan. Masukan kentang dan rempelo atinya..tambahkan bumbu2 lainya, cek rasa.angkat."
- "Sajikan di piring taruh potongan lontong, tambahkan sambel gorwng kentang dan hatinya, sambel goreng, masukan kuah opor dan taburi bawang goreng. Siap di nikmatii.. Hmm manttulll😍🤤"
categories:
- Resep
tags:
- lontong
- opor
- ayam

katakunci: lontong opor ayam 
nutrition: 131 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Lunch

---


![Lontong Opor Ayam &amp; Hati](https://img-global.cpcdn.com/recipes/07aa4f7c193c2933/680x482cq70/lontong-opor-ayam-hati-foto-resep-utama.jpg)

Jika anda seorang orang tua, mempersiapkan hidangan mantab untuk famili adalah suatu hal yang menggembirakan bagi anda sendiri. Kewajiban seorang ibu bukan sekadar mengurus rumah saja, namun kamu pun harus menyediakan keperluan nutrisi terpenuhi dan juga santapan yang dimakan anak-anak wajib enak.

Di masa  sekarang, kamu memang bisa membeli hidangan jadi walaupun tidak harus ribet membuatnya dahulu. Tetapi banyak juga lho orang yang selalu ingin memberikan yang terlezat bagi orang yang dicintainya. Karena, memasak sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan keluarga. 



Mungkinkah anda seorang penyuka lontong opor ayam &amp; hati?. Asal kamu tahu, lontong opor ayam &amp; hati adalah hidangan khas di Indonesia yang saat ini disenangi oleh setiap orang dari hampir setiap tempat di Nusantara. Anda dapat membuat lontong opor ayam &amp; hati sendiri di rumah dan boleh dijadikan santapan kesenanganmu di hari liburmu.

Kalian jangan bingung untuk menyantap lontong opor ayam &amp; hati, lantaran lontong opor ayam &amp; hati tidak sulit untuk didapatkan dan juga anda pun bisa memasaknya sendiri di tempatmu. lontong opor ayam &amp; hati bisa dimasak dengan beragam cara. Sekarang telah banyak banget cara kekinian yang menjadikan lontong opor ayam &amp; hati lebih mantap.

Resep lontong opor ayam &amp; hati pun gampang sekali untuk dibikin, lho. Kamu tidak usah ribet-ribet untuk memesan lontong opor ayam &amp; hati, sebab Kalian mampu menyiapkan sendiri di rumah. Untuk Kita yang akan membuatnya, berikut cara membuat lontong opor ayam &amp; hati yang lezat yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Lontong Opor Ayam &amp; Hati:

1. Sediakan 1/2 kg ayam
1. Sediakan 5 buah hati ayam
1. Siapkan 1 liter santan
1. Siapkan 2 sdmgl pasir
1. Gunakan  Garam sckp
1. Ambil  Kaldu jamur
1. Ambil 1/2 sdt lada bubuk
1. Siapkan  Bumbu halus:
1. Gunakan 6 siung bamer
1. Siapkan 3 siung baput
1. Ambil Seruas jahe
1. Gunakan 3 ruas kunyit
1. Ambil 1/2 sdt ketumbar
1. Gunakan 5 biji kemiri
1. Gunakan  Empon2:
1. Sediakan 1 batang serai
1. Siapkan 4 daun salam
1. Sediakan 3 ruas lengkuas
1. Gunakan  Sambel kentang:
1. Gunakan 1/4 kg kentang goreng
1. Siapkan 4 buah Rempola hati ayam potong
1. Sediakan 4 bamer
1. Ambil 3 baput
1. Siapkan  Garam,gula,kaldu sckp
1. Siapkan 2 kemiri
1. Ambil 3 cabe merah
1. Siapkan 5 cabe rawit
1. Siapkan Seruas loas
1. Siapkan Selembar daun salam
1. Siapkan 2 daun jeruk
1. Sediakan  Bahan pelengkap:
1. Ambil  Lontong
1. Ambil  Bawang goreng




<!--inarticleads2-->

##### Cara membuat Lontong Opor Ayam &amp; Hati:

1. Sebelumnya rebus ayam dan hati ayam dgn daun salam selama 20 menit. Angkat tiriskan.
1. Tumis bumbu yg sdh dihaluskan tambahkan empon2..tumis sampaj harum dan agak kering. Masukan ayam dan hati ayam. Tambahkan santan, gula pasir, kaldu jamur dan garam. Cek rasa.
1. Sambel goreng kentang, tumis smua bumbunya yg sdh dihaluskan. Masukan kentang dan rempelo atinya..tambahkan bumbu2 lainya, cek rasa.angkat.
1. Sajikan di piring taruh potongan lontong, tambahkan sambel gorwng kentang dan hatinya, sambel goreng, masukan kuah opor dan taburi bawang goreng. Siap di nikmatii.. Hmm manttulll😍🤤




Wah ternyata cara membuat lontong opor ayam &amp; hati yang enak tidak rumit ini gampang banget ya! Kamu semua bisa mencobanya. Cara buat lontong opor ayam &amp; hati Cocok sekali buat kamu yang baru belajar memasak atau juga untuk kamu yang telah ahli memasak.

Tertarik untuk mulai mencoba bikin resep lontong opor ayam &amp; hati lezat tidak rumit ini? Kalau kalian tertarik, yuk kita segera siapin alat-alat dan bahannya, lantas bikin deh Resep lontong opor ayam &amp; hati yang lezat dan simple ini. Benar-benar mudah kan. 

Jadi, ketimbang kalian berfikir lama-lama, maka kita langsung sajikan resep lontong opor ayam &amp; hati ini. Dijamin kalian gak akan menyesal sudah bikin resep lontong opor ayam &amp; hati lezat simple ini! Selamat mencoba dengan resep lontong opor ayam &amp; hati lezat tidak rumit ini di tempat tinggal sendiri,ya!.

