---
description: "Bahan-bahan Day. 260 Ati Ayam Masak Santan Berempah (14 month+) Sederhana Untuk Jualan"
title: "Bahan-bahan Day. 260 Ati Ayam Masak Santan Berempah (14 month+) Sederhana Untuk Jualan"
slug: 310-bahan-bahan-day-260-ati-ayam-masak-santan-berempah-14-month-sederhana-untuk-jualan
date: 2021-06-28T06:32:24.742Z
image: https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg
author: Johanna Greer
ratingvalue: 3.1
reviewcount: 5
recipeingredient:
- "1 buah ati ayam ungkep           lihat resep"
- "1 batang kacang panjang potong2"
- "1/2 bagian oyong potong2"
- "1 siung bawang putih iris tipis"
- "2 buah bawang merah iris tipis"
- "1 batang serai geprek"
- "1/4 sdt kayumanis bubuk"
- "1/4 sdt pala bubuk"
- "1/4 sdt kunyit bubuk"
- "1/4 sdt ketumbar bubuk"
- "1 sdm minyak samin"
- "1 sdm santan instan"
- "1 batang seledri cincang halus"
- "Sejumput garam"
- "200 ml air"
recipeinstructions:
- "Lelehkan minyak samin. Tumis bawang merah dan bawang putih hingga harum. Masukkan serai, kayumanis bubuk, pala bubuk, kunyit bubuk, ketumbar bubuk dan sedikit air. Masak sekitar 1 menit. Tambahkan sisa air, masak hingga mendidih."
- "Masukkan kacang panjang. Masak hingga air berkurang setengahnya. Masukkan oyong dan ati ayam, masak hingga air hampir habis."
- "Tambahkan santan instan dan seledri. Aduk rata. Masak sebentar, matikan api. Tambahkan garam, aduk rata."
- "Sajikan dengan nasi putih hangat."
categories:
- Resep
tags:
- day
- 260
- ati

katakunci: day 260 ati 
nutrition: 238 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dinner

---


![Day. 260 Ati Ayam Masak Santan Berempah (14 month+)](https://img-global.cpcdn.com/recipes/440cacf6619791e8/680x482cq70/day-260-ati-ayam-masak-santan-berempah-14-month-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyediakan santapan sedap pada keluarga merupakan suatu hal yang sangat menyenangkan untuk anda sendiri. Peran seorang ibu Tidak sekadar mengatur rumah saja, namun anda juga wajib memastikan kebutuhan gizi terpenuhi dan juga panganan yang dimakan orang tercinta wajib lezat.

Di era  saat ini, anda sebenarnya bisa memesan masakan instan walaupun tidak harus capek membuatnya terlebih dahulu. Tetapi banyak juga lho orang yang memang mau menyajikan yang terenak bagi keluarganya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai masakan kesukaan keluarga. 



Mungkinkah anda merupakan salah satu penggemar day. 260 ati ayam masak santan berempah (14 month+)?. Asal kamu tahu, day. 260 ati ayam masak santan berempah (14 month+) adalah sajian khas di Nusantara yang sekarang disenangi oleh kebanyakan orang dari berbagai wilayah di Indonesia. Kita bisa menghidangkan day. 260 ati ayam masak santan berempah (14 month+) hasil sendiri di rumahmu dan dapat dijadikan santapan favorit di akhir pekanmu.

Kamu tidak perlu bingung untuk mendapatkan day. 260 ati ayam masak santan berempah (14 month+), karena day. 260 ati ayam masak santan berempah (14 month+) gampang untuk ditemukan dan juga kalian pun dapat menghidangkannya sendiri di rumah. day. 260 ati ayam masak santan berempah (14 month+) bisa dimasak lewat berbagai cara. Kini sudah banyak resep kekinian yang membuat day. 260 ati ayam masak santan berempah (14 month+) semakin lebih nikmat.

Resep day. 260 ati ayam masak santan berempah (14 month+) pun mudah dibikin, lho. Kamu tidak usah repot-repot untuk memesan day. 260 ati ayam masak santan berempah (14 month+), tetapi Kamu bisa menyiapkan di rumah sendiri. Untuk Anda yang mau mencobanya, dibawah ini merupakan resep menyajikan day. 260 ati ayam masak santan berempah (14 month+) yang enak yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Day. 260 Ati Ayam Masak Santan Berempah (14 month+):

1. Ambil 1 buah ati ayam ungkep           (lihat resep)
1. Ambil 1 batang kacang panjang, potong2
1. Ambil 1/2 bagian oyong, potong2
1. Sediakan 1 siung bawang putih, iris tipis
1. Siapkan 2 buah bawang merah, iris tipis
1. Gunakan 1 batang serai, geprek
1. Siapkan 1/4 sdt kayumanis bubuk
1. Gunakan 1/4 sdt pala bubuk
1. Ambil 1/4 sdt kunyit bubuk
1. Gunakan 1/4 sdt ketumbar bubuk
1. Ambil 1 sdm minyak samin
1. Ambil 1 sdm santan instan
1. Ambil 1 batang seledri, cincang halus
1. Gunakan Sejumput garam
1. Siapkan 200 ml air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Day. 260 Ati Ayam Masak Santan Berempah (14 month+):

1. Lelehkan minyak samin. Tumis bawang merah dan bawang putih hingga harum. Masukkan serai, kayumanis bubuk, pala bubuk, kunyit bubuk, ketumbar bubuk dan sedikit air. Masak sekitar 1 menit. Tambahkan sisa air, masak hingga mendidih.
1. Masukkan kacang panjang. Masak hingga air berkurang setengahnya. Masukkan oyong dan ati ayam, masak hingga air hampir habis.
1. Tambahkan santan instan dan seledri. Aduk rata. Masak sebentar, matikan api. Tambahkan garam, aduk rata.
1. Sajikan dengan nasi putih hangat.




Wah ternyata resep day. 260 ati ayam masak santan berempah (14 month+) yang mantab tidak rumit ini gampang sekali ya! Kita semua dapat mencobanya. Resep day. 260 ati ayam masak santan berempah (14 month+) Sesuai banget buat kamu yang baru belajar memasak maupun untuk kamu yang sudah lihai memasak.

Apakah kamu mau mencoba bikin resep day. 260 ati ayam masak santan berempah (14 month+) mantab simple ini? Kalau tertarik, mending kamu segera siapin alat dan bahannya, setelah itu buat deh Resep day. 260 ati ayam masak santan berempah (14 month+) yang nikmat dan tidak ribet ini. Betul-betul gampang kan. 

Oleh karena itu, ketimbang kita berlama-lama, maka kita langsung saja bikin resep day. 260 ati ayam masak santan berempah (14 month+) ini. Dijamin kamu gak akan menyesal sudah membuat resep day. 260 ati ayam masak santan berempah (14 month+) enak tidak ribet ini! Selamat berkreasi dengan resep day. 260 ati ayam masak santan berempah (14 month+) mantab tidak rumit ini di tempat tinggal masing-masing,ya!.

