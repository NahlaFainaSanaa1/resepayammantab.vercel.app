---
description: "Cara membuat Opor ayam (untuk lontong cap go meh) yang enak dan Mudah Dibuat"
title: "Cara membuat Opor ayam (untuk lontong cap go meh) yang enak dan Mudah Dibuat"
slug: 397-cara-membuat-opor-ayam-untuk-lontong-cap-go-meh-yang-enak-dan-mudah-dibuat
date: 2021-04-02T17:18:04.886Z
image: https://img-global.cpcdn.com/recipes/a64dab9a61a16f09/680x482cq70/opor-ayam-untuk-lontong-cap-go-meh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a64dab9a61a16f09/680x482cq70/opor-ayam-untuk-lontong-cap-go-meh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a64dab9a61a16f09/680x482cq70/opor-ayam-untuk-lontong-cap-go-meh-foto-resep-utama.jpg
author: Nettie Haynes
ratingvalue: 4.8
reviewcount: 6
recipeingredient:
- "1 ekor ayam kurang lebih 1 kg potong sesuai selera aku potong 14 bagian"
- "1 sachet santan kara"
- "secukupnya Bawang goreng"
- "secukupnya Garam gula lada totole"
- "secukupnya Minyak untuk menumis"
- " Bumbu dihaluskan"
- "10 siung bawang merah"
- "8 siung bawang putih"
- "4 buah kemiri"
- "5 cm jahe"
- "1 cm kunyit"
- " Bumbu disangrai lalu dihaluskan jadi bubuk"
- "1/2 sdm ketumbar"
- "1/4 sdm merica"
- "1/4 sdm jinten"
- "1/4 biji pala"
- "3 biji cengkeh"
- " Bumbu cemplung"
- "2 biji bunga lawang"
- "3 biji kapulaga"
- "3 cm kayu manis"
- "5 cm lengkuas digeprek"
- "5 lembar daun jeruk"
- "2 lembar daun salam"
- "1 buah sereh digeprek"
recipeinstructions:
- "Tumis bumbu yang telah dihaluskan dengan minyak, masukkan juga bumbu bubuk dan bumbu cemplung. Tumis hingga airnya habis dan mengeluarkan minyak, hingga bumbu sudah tidak mentah lagi."
- "Masukkan ayam, ratakan bumbu hingga semua ayam tercampur. Masukkan air kurang lebih 1 L, beri garam, gula, lada dan totole secukupnya dan rebus hingga mendidih dan ayam matang. Jika ayam sudah matang, rebus hingga volume kuah sesuai yang diinginkan, jika ingin kental artinya sisakan air sekitar 500 mL."
- "Masukkan santan dan bawang goreng, aduk2 agar santan ga pecah, tunggu hingga mendidih sekali lagi, koreksi rasa juga hingga pas. Jika sudah pas semua, matikan api, opor siap dihidangkan. Selesai"
categories:
- Resep
tags:
- opor
- ayam
- untuk

katakunci: opor ayam untuk 
nutrition: 270 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Opor ayam (untuk lontong cap go meh)](https://img-global.cpcdn.com/recipes/a64dab9a61a16f09/680x482cq70/opor-ayam-untuk-lontong-cap-go-meh-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan masakan enak bagi famili merupakan suatu hal yang sangat menyenangkan bagi kamu sendiri. Tugas seorang istri Tidak sekedar menangani rumah saja, tapi anda pun harus memastikan kebutuhan gizi terpenuhi dan juga hidangan yang dimakan anak-anak mesti mantab.

Di era  saat ini, kita memang mampu mengorder hidangan yang sudah jadi walaupun tanpa harus ribet mengolahnya dulu. Namun banyak juga lho mereka yang memang ingin menghidangkan yang terbaik bagi orang tercintanya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan famili. 



Mungkinkah anda adalah salah satu penggemar opor ayam (untuk lontong cap go meh)?. Asal kamu tahu, opor ayam (untuk lontong cap go meh) adalah sajian khas di Nusantara yang kini digemari oleh banyak orang dari berbagai daerah di Nusantara. Anda dapat membuat opor ayam (untuk lontong cap go meh) buatan sendiri di rumahmu dan dapat dijadikan makanan favorit di hari liburmu.

Kamu tak perlu bingung untuk mendapatkan opor ayam (untuk lontong cap go meh), sebab opor ayam (untuk lontong cap go meh) sangat mudah untuk ditemukan dan kalian pun boleh mengolahnya sendiri di rumah. opor ayam (untuk lontong cap go meh) bisa diolah dengan beraneka cara. Kini ada banyak banget cara modern yang membuat opor ayam (untuk lontong cap go meh) semakin lebih enak.

Resep opor ayam (untuk lontong cap go meh) juga gampang sekali untuk dibuat, lho. Anda tidak perlu ribet-ribet untuk memesan opor ayam (untuk lontong cap go meh), tetapi Anda mampu membuatnya sendiri di rumah. Bagi Anda yang hendak menyajikannya, berikut ini resep menyajikan opor ayam (untuk lontong cap go meh) yang nikamat yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Opor ayam (untuk lontong cap go meh):

1. Siapkan 1 ekor ayam (kurang lebih 1 kg, potong sesuai selera, aku potong 14 bagian)
1. Ambil 1 sachet santan kara
1. Gunakan secukupnya Bawang goreng
1. Ambil secukupnya Garam, gula, lada, totole
1. Gunakan secukupnya Minyak untuk menumis
1. Gunakan  Bumbu dihaluskan
1. Gunakan 10 siung bawang merah
1. Siapkan 8 siung bawang putih
1. Siapkan 4 buah kemiri
1. Sediakan 5 cm jahe
1. Sediakan 1 cm kunyit
1. Sediakan  Bumbu disangrai lalu dihaluskan (jadi bubuk)
1. Sediakan 1/2 sdm ketumbar
1. Gunakan 1/4 sdm merica
1. Ambil 1/4 sdm jinten
1. Siapkan 1/4 biji pala
1. Gunakan 3 biji cengkeh
1. Sediakan  Bumbu cemplung
1. Siapkan 2 biji bunga lawang
1. Siapkan 3 biji kapulaga
1. Gunakan 3 cm kayu manis
1. Ambil 5 cm lengkuas digeprek
1. Siapkan 5 lembar daun jeruk
1. Siapkan 2 lembar daun salam
1. Ambil 1 buah sereh digeprek




<!--inarticleads2-->

##### Langkah-langkah membuat Opor ayam (untuk lontong cap go meh):

1. Tumis bumbu yang telah dihaluskan dengan minyak, masukkan juga bumbu bubuk dan bumbu cemplung. Tumis hingga airnya habis dan mengeluarkan minyak, hingga bumbu sudah tidak mentah lagi.
1. Masukkan ayam, ratakan bumbu hingga semua ayam tercampur. Masukkan air kurang lebih 1 L, beri garam, gula, lada dan totole secukupnya dan rebus hingga mendidih dan ayam matang. Jika ayam sudah matang, rebus hingga volume kuah sesuai yang diinginkan, jika ingin kental artinya sisakan air sekitar 500 mL.
1. Masukkan santan dan bawang goreng, aduk2 agar santan ga pecah, tunggu hingga mendidih sekali lagi, koreksi rasa juga hingga pas. Jika sudah pas semua, matikan api, opor siap dihidangkan. Selesai




Ternyata cara membuat opor ayam (untuk lontong cap go meh) yang nikamt sederhana ini mudah banget ya! Anda Semua dapat mencobanya. Cara Membuat opor ayam (untuk lontong cap go meh) Sangat sesuai sekali untuk kalian yang baru mau belajar memasak ataupun juga untuk kalian yang telah jago memasak.

Tertarik untuk mencoba membikin resep opor ayam (untuk lontong cap go meh) lezat tidak ribet ini? Kalau mau, ayo kamu segera buruan siapkan alat dan bahan-bahannya, kemudian buat deh Resep opor ayam (untuk lontong cap go meh) yang nikmat dan tidak ribet ini. Sangat mudah kan. 

Oleh karena itu, ketimbang kita berlama-lama, yuk langsung aja hidangkan resep opor ayam (untuk lontong cap go meh) ini. Dijamin anda tiidak akan nyesel membuat resep opor ayam (untuk lontong cap go meh) enak tidak ribet ini! Selamat mencoba dengan resep opor ayam (untuk lontong cap go meh) lezat sederhana ini di tempat tinggal kalian sendiri,ya!.

