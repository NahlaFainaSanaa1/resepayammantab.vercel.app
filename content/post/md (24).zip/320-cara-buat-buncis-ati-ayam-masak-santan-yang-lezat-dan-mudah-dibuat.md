---
description: "Cara buat Buncis Ati Ayam masak Santan yang lezat dan Mudah Dibuat"
title: "Cara buat Buncis Ati Ayam masak Santan yang lezat dan Mudah Dibuat"
slug: 320-cara-buat-buncis-ati-ayam-masak-santan-yang-lezat-dan-mudah-dibuat
date: 2021-01-24T08:55:46.184Z
image: https://img-global.cpcdn.com/recipes/2743336e11f89bc7/680x482cq70/buncis-ati-ayam-masak-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2743336e11f89bc7/680x482cq70/buncis-ati-ayam-masak-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2743336e11f89bc7/680x482cq70/buncis-ati-ayam-masak-santan-foto-resep-utama.jpg
author: Gary Patterson
ratingvalue: 3.6
reviewcount: 4
recipeingredient:
- "200 gr buncis kl sy diresep ini pakai baby buncis potong2"
- "6 buah ati ayam rebus potong2"
- "5 siung bawang merah iris halus"
- "4 siung bawang putih iris halus"
- "10 buah cabai merah potong2"
- "1 buah gula jawa sisir"
- "1 ruas lengkuas"
- "2 lembar daun salam"
- "300 ml santan"
recipeinstructions:
- "Tumis bawang merah, bawang putih, cabai merah, lengkuas, daun salam sampai wangi"
- "Tambahkan ati ayam, aduk2"
- "Masukkan gula jawa"
- "Masukkan santan, masak sampai mendidih, aduk supaya tidak pecah"
- "Masukkan garam dan gula pasir"
- "Setelah kuah agak menyusut, masukkan buncis. Tunggu sampai mendidih sekali lagi. Koreksi rasa dan matikan api"
- "Sajikan dengan tempe goreng, sungguh nikmat tiada tara"
categories:
- Resep
tags:
- buncis
- ati
- ayam

katakunci: buncis ati ayam 
nutrition: 239 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Lunch

---


![Buncis Ati Ayam masak Santan](https://img-global.cpcdn.com/recipes/2743336e11f89bc7/680x482cq70/buncis-ati-ayam-masak-santan-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan masakan menggugah selera untuk keluarga adalah suatu hal yang mengasyikan bagi anda sendiri. Peran seorang ibu bukan sekadar menjaga rumah saja, tapi kamu juga wajib menyediakan kebutuhan nutrisi terpenuhi dan panganan yang dikonsumsi anak-anak wajib enak.

Di waktu  sekarang, kalian sebenarnya bisa membeli panganan yang sudah jadi meski tidak harus capek membuatnya dahulu. Tetapi ada juga lho mereka yang memang mau menyajikan yang terlezat untuk orang tercintanya. Karena, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan selera orang tercinta. 



Mungkinkah anda merupakan salah satu penyuka buncis ati ayam masak santan?. Tahukah kamu, buncis ati ayam masak santan adalah sajian khas di Indonesia yang sekarang disenangi oleh setiap orang dari hampir setiap wilayah di Indonesia. Kalian bisa menyajikan buncis ati ayam masak santan kreasi sendiri di rumahmu dan boleh jadi camilan favoritmu di hari liburmu.

Kita tidak usah bingung jika kamu ingin memakan buncis ati ayam masak santan, lantaran buncis ati ayam masak santan gampang untuk dicari dan juga kalian pun bisa membuatnya sendiri di tempatmu. buncis ati ayam masak santan dapat dibuat dengan bermacam cara. Kini pun ada banyak sekali resep modern yang menjadikan buncis ati ayam masak santan semakin lebih mantap.

Resep buncis ati ayam masak santan pun mudah untuk dibuat, lho. Kalian jangan capek-capek untuk memesan buncis ati ayam masak santan, tetapi Kamu mampu menyajikan di rumah sendiri. Bagi Kita yang hendak menghidangkannya, inilah resep untuk menyajikan buncis ati ayam masak santan yang enak yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Buncis Ati Ayam masak Santan:

1. Ambil 200 gr buncis (kl sy diresep ini pakai baby buncis) potong2
1. Ambil 6 buah ati ayam, rebus, potong2
1. Ambil 5 siung bawang merah, iris halus
1. Sediakan 4 siung bawang putih, iris halus
1. Gunakan 10 buah cabai merah, potong2
1. Gunakan 1 buah gula jawa, sisir
1. Gunakan 1 ruas lengkuas
1. Ambil 2 lembar daun salam
1. Sediakan 300 ml santan




<!--inarticleads2-->

##### Langkah-langkah membuat Buncis Ati Ayam masak Santan:

1. Tumis bawang merah, bawang putih, cabai merah, lengkuas, daun salam sampai wangi
1. Tambahkan ati ayam, aduk2
1. Masukkan gula jawa
1. Masukkan santan, masak sampai mendidih, aduk supaya tidak pecah
1. Masukkan garam dan gula pasir
1. Setelah kuah agak menyusut, masukkan buncis. Tunggu sampai mendidih sekali lagi. Koreksi rasa dan matikan api
1. Sajikan dengan tempe goreng, sungguh nikmat tiada tara




Ternyata resep buncis ati ayam masak santan yang nikamt simple ini mudah banget ya! Kita semua bisa mencobanya. Cara Membuat buncis ati ayam masak santan Sangat cocok banget buat kita yang sedang belajar memasak maupun bagi anda yang telah lihai memasak.

Tertarik untuk mencoba membuat resep buncis ati ayam masak santan nikmat tidak ribet ini? Kalau ingin, yuk kita segera buruan siapkan peralatan dan bahan-bahannya, lalu buat deh Resep buncis ati ayam masak santan yang mantab dan tidak rumit ini. Betul-betul taidak sulit kan. 

Oleh karena itu, daripada kamu berlama-lama, hayo kita langsung saja buat resep buncis ati ayam masak santan ini. Pasti kamu tiidak akan menyesal membuat resep buncis ati ayam masak santan enak simple ini! Selamat mencoba dengan resep buncis ati ayam masak santan mantab sederhana ini di tempat tinggal sendiri,oke!.

