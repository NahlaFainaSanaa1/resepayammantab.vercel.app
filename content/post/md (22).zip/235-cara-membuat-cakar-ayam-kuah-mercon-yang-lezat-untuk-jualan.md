---
description: "Cara membuat Cakar Ayam Kuah Mercon yang lezat Untuk Jualan"
title: "Cara membuat Cakar Ayam Kuah Mercon yang lezat Untuk Jualan"
slug: 235-cara-membuat-cakar-ayam-kuah-mercon-yang-lezat-untuk-jualan
date: 2021-04-24T08:02:35.383Z
image: https://img-global.cpcdn.com/recipes/1aadebaf5a3fffc0/680x482cq70/cakar-ayam-kuah-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1aadebaf5a3fffc0/680x482cq70/cakar-ayam-kuah-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1aadebaf5a3fffc0/680x482cq70/cakar-ayam-kuah-mercon-foto-resep-utama.jpg
author: Hester May
ratingvalue: 5
reviewcount: 5
recipeingredient:
- "15 ceker ayam cuci bersih"
- "7 siung bawang putih"
- "4 siung bawang putih"
- "2 cabai besar"
- "30 buah cabai rawit"
- "1 buah tomat ukuran kecil"
- "1 lembar daun salam"
- "4 lembar daun jeruk"
- "1 ruas jari lengkuas"
- "1 buah sereh"
- "1,5 sdt garam"
- "1/2 sdt gula"
- "1/2 sdt kunyit bubuk"
- "750 ml air"
- "3 sdm minyak goreng"
recipeinstructions:
- "Haluskan : bawang merah, bawang putih, cabai merah besar, cabai rawit dan tomat."
- "Cuci bersih cakar ayam, rebus dan tunggu hingga mendidih. Buang air rebusan pertama, kemudian rebus lagi cakar ayam dengan 750ml air sampai cakar empuk."
- "Panaskan minyak, tumis bumbu halus dan bumbu daun hingga wangi. Tambahkan garam, gula dan 1/2 sdt kunyit bubuk."
- "Setelah bumbu harum dan tanak, masukan cakar yang sudah direbus. Beri sedikit air sisa rebusan cakar. Koreksi rasa. Tunggu hingga air mendidih dan menyusut."
- "Cakar kuah mercon siap disajikan. Bisa dijadikan kuah untuk seblak mie ala-ala (tanpa kencur) seperti saya 😁"
categories:
- Resep
tags:
- cakar
- ayam
- kuah

katakunci: cakar ayam kuah 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner

---


![Cakar Ayam Kuah Mercon](https://img-global.cpcdn.com/recipes/1aadebaf5a3fffc0/680x482cq70/cakar-ayam-kuah-mercon-foto-resep-utama.jpg)

Apabila kita seorang yang hobi memasak, menyuguhkan hidangan menggugah selera kepada keluarga tercinta adalah hal yang memuaskan bagi kamu sendiri. Tanggung jawab seorang istri bukan sekadar menangani rumah saja, namun anda juga harus memastikan kebutuhan gizi tercukupi dan juga panganan yang disantap orang tercinta wajib enak.

Di era  saat ini, kalian memang mampu membeli masakan siap saji tanpa harus susah memasaknya lebih dulu. Tapi ada juga lho mereka yang selalu mau memberikan makanan yang terenak untuk keluarganya. Lantaran, memasak yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga tercinta. 



Apakah anda adalah seorang penyuka cakar ayam kuah mercon?. Tahukah kamu, cakar ayam kuah mercon adalah sajian khas di Nusantara yang sekarang digemari oleh kebanyakan orang di berbagai wilayah di Indonesia. Anda dapat membuat cakar ayam kuah mercon sendiri di rumahmu dan pasti jadi santapan kesukaanmu di hari liburmu.

Kalian jangan bingung untuk memakan cakar ayam kuah mercon, karena cakar ayam kuah mercon mudah untuk ditemukan dan juga kamu pun boleh menghidangkannya sendiri di tempatmu. cakar ayam kuah mercon dapat diolah lewat beragam cara. Saat ini sudah banyak banget resep kekinian yang membuat cakar ayam kuah mercon lebih lezat.

Resep cakar ayam kuah mercon juga gampang sekali untuk dibikin, lho. Kamu jangan capek-capek untuk membeli cakar ayam kuah mercon, tetapi Kita bisa menghidangkan di rumahmu. Untuk Kita yang hendak menghidangkannya, berikut cara untuk membuat cakar ayam kuah mercon yang mantab yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Cakar Ayam Kuah Mercon:

1. Sediakan 15 ceker ayam (cuci bersih)
1. Sediakan 7 siung bawang putih
1. Ambil 4 siung bawang putih
1. Siapkan 2 cabai besar
1. Gunakan 30 buah cabai rawit
1. Gunakan 1 buah tomat ukuran kecil
1. Sediakan 1 lembar daun salam
1. Sediakan 4 lembar daun jeruk
1. Siapkan 1 ruas jari lengkuas
1. Gunakan 1 buah sereh
1. Ambil 1,5 sdt garam
1. Ambil 1/2 sdt gula
1. Siapkan 1/2 sdt kunyit bubuk
1. Ambil 750 ml air
1. Ambil 3 sdm minyak goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Cakar Ayam Kuah Mercon:

1. Haluskan : bawang merah, bawang putih, cabai merah besar, cabai rawit dan tomat.
1. Cuci bersih cakar ayam, rebus dan tunggu hingga mendidih. Buang air rebusan pertama, kemudian rebus lagi cakar ayam dengan 750ml air sampai cakar empuk.
1. Panaskan minyak, tumis bumbu halus dan bumbu daun hingga wangi. Tambahkan garam, gula dan 1/2 sdt kunyit bubuk.
1. Setelah bumbu harum dan tanak, masukan cakar yang sudah direbus. Beri sedikit air sisa rebusan cakar. Koreksi rasa. Tunggu hingga air mendidih dan menyusut.
1. Cakar kuah mercon siap disajikan. Bisa dijadikan kuah untuk seblak mie ala-ala (tanpa kencur) seperti saya 😁




Wah ternyata cara membuat cakar ayam kuah mercon yang lezat simple ini enteng banget ya! Kalian semua mampu membuatnya. Cara buat cakar ayam kuah mercon Cocok banget untuk anda yang baru mau belajar memasak atau juga bagi anda yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba buat resep cakar ayam kuah mercon mantab simple ini? Kalau anda mau, yuk kita segera siapin alat-alat dan bahannya, kemudian buat deh Resep cakar ayam kuah mercon yang mantab dan tidak rumit ini. Sangat mudah kan. 

Oleh karena itu, ketimbang kita berlama-lama, maka kita langsung saja bikin resep cakar ayam kuah mercon ini. Pasti kalian tak akan nyesel sudah buat resep cakar ayam kuah mercon enak simple ini! Selamat mencoba dengan resep cakar ayam kuah mercon enak tidak ribet ini di rumah sendiri,oke!.

