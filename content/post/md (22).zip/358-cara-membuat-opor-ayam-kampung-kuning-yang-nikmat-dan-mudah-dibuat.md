---
description: "Cara membuat Opor ayam kampung (kuning) yang nikmat dan Mudah Dibuat"
title: "Cara membuat Opor ayam kampung (kuning) yang nikmat dan Mudah Dibuat"
slug: 358-cara-membuat-opor-ayam-kampung-kuning-yang-nikmat-dan-mudah-dibuat
date: 2021-04-12T07:59:43.579Z
image: https://img-global.cpcdn.com/recipes/fccd17d918e9ec70/680x482cq70/opor-ayam-kampung-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fccd17d918e9ec70/680x482cq70/opor-ayam-kampung-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fccd17d918e9ec70/680x482cq70/opor-ayam-kampung-kuning-foto-resep-utama.jpg
author: Della Watkins
ratingvalue: 4.8
reviewcount: 4
recipeingredient:
- "1 ekor ayam kampung muda"
- "1 buah jeruk lemonnipis"
- " Bumbu halus"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "3 butir kemiri"
- "1 ruas kecil kunyit"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 sdt jintan"
- "1 sdt lada"
- "1 sdt ketumbar"
- "4 lembar daun salam"
- "4 lembar daun jeruk"
- "2 batang serai"
- "1 sdt asam kandis"
- "1 sdt garam"
- "1 sdt gula"
- "1 sdt kaldu bubuk penyedap"
- "1 butir kelapa 1 gelas santan kental4 gelas santan cair"
- " Minyak untuk menumis"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri dengan jeruk lemon tunggu selama 30 menit lalu bilas kembali"
- "Haluskan bumbu,lalu panaskan minyak dalam wajan masukkan bumbu beserta daun salam,daun jeruk dan serai hingga bumbu harum dan matang"
- "Setelah itu masukkan potongan ayam kedalam bumbu aduk rata masak hingga ayam berubah warna putih pucat lalu masukkan santan cair,aduk sesekali agar santan tidak pecah masak dengan api kecil.setelah kuah menyusut ayam mulai empuk masukkan santan kental,garam,gula,kaldu bubuk tes rasa masak kembali hingga ayam matang dan kuah mengental."
- "Setelah ayam matang pindahkan kedalam mangkuk saji lalu taburi dengan bawang goreng.opor ayam siap disajikan dengan pelengkap ketupat dan sambal goreng kentang."
categories:
- Resep
tags:
- opor
- ayam
- kampung

katakunci: opor ayam kampung 
nutrition: 165 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Dessert

---


![Opor ayam kampung (kuning)](https://img-global.cpcdn.com/recipes/fccd17d918e9ec70/680x482cq70/opor-ayam-kampung-kuning-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan santapan enak buat keluarga tercinta adalah hal yang mengasyikan bagi anda sendiri. Kewajiban seorang istri bukan cuman mengerjakan pekerjaan rumah saja, namun anda juga harus memastikan keperluan nutrisi tercukupi dan juga masakan yang dimakan keluarga tercinta harus lezat.

Di waktu  sekarang, kita memang bisa membeli olahan jadi meski tidak harus ribet mengolahnya lebih dulu. Tapi banyak juga mereka yang memang mau memberikan hidangan yang terbaik bagi keluarganya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan selera orang tercinta. 



Mungkinkah anda salah satu penggemar opor ayam kampung (kuning)?. Tahukah kamu, opor ayam kampung (kuning) adalah hidangan khas di Nusantara yang sekarang digemari oleh orang-orang dari hampir setiap daerah di Nusantara. Anda dapat memasak opor ayam kampung (kuning) sendiri di rumahmu dan pasti jadi hidangan favorit di akhir pekanmu.

Anda tidak perlu bingung untuk menyantap opor ayam kampung (kuning), karena opor ayam kampung (kuning) tidak sulit untuk dicari dan juga kalian pun boleh mengolahnya sendiri di rumah. opor ayam kampung (kuning) dapat dibuat lewat beragam cara. Kini pun ada banyak cara modern yang membuat opor ayam kampung (kuning) semakin nikmat.

Resep opor ayam kampung (kuning) pun mudah dihidangkan, lho. Anda tidak usah repot-repot untuk membeli opor ayam kampung (kuning), tetapi Kalian bisa menyajikan sendiri di rumah. Untuk Kita yang akan membuatnya, inilah resep untuk menyajikan opor ayam kampung (kuning) yang lezat yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Opor ayam kampung (kuning):

1. Ambil 1 ekor ayam kampung muda
1. Gunakan 1 buah jeruk lemon/nipis
1. Gunakan  Bumbu halus:
1. Gunakan 8 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Gunakan 3 butir kemiri
1. Gunakan 1 ruas kecil kunyit
1. Gunakan 1 ruas jahe
1. Sediakan 1 ruas lengkuas
1. Sediakan 1 sdt jintan
1. Ambil 1 sdt lada
1. Gunakan 1 sdt ketumbar
1. Ambil 4 lembar daun salam
1. Ambil 4 lembar daun jeruk
1. Gunakan 2 batang serai
1. Ambil 1 sdt asam kandis
1. Sediakan 1 sdt garam
1. Siapkan 1 sdt gula
1. Siapkan 1 sdt kaldu bubuk/ penyedap
1. Gunakan 1 butir kelapa (1 gelas santan kental+4 gelas santan cair)
1. Siapkan  Minyak untuk menumis




<!--inarticleads2-->

##### Cara membuat Opor ayam kampung (kuning):

1. Cuci bersih ayam lalu lumuri dengan jeruk lemon tunggu selama 30 menit lalu bilas kembali
1. Haluskan bumbu,lalu panaskan minyak dalam wajan masukkan bumbu beserta daun salam,daun jeruk dan serai hingga bumbu harum dan matang
1. Setelah itu masukkan potongan ayam kedalam bumbu aduk rata masak hingga ayam berubah warna putih pucat lalu masukkan santan cair,aduk sesekali agar santan tidak pecah masak dengan api kecil.setelah kuah menyusut ayam mulai empuk masukkan santan kental,garam,gula,kaldu bubuk tes rasa masak kembali hingga ayam matang dan kuah mengental.
1. Setelah ayam matang pindahkan kedalam mangkuk saji lalu taburi dengan bawang goreng.opor ayam siap disajikan dengan pelengkap ketupat dan sambal goreng kentang.




Wah ternyata cara membuat opor ayam kampung (kuning) yang nikamt simple ini gampang sekali ya! Kalian semua dapat membuatnya. Cara buat opor ayam kampung (kuning) Cocok banget buat anda yang sedang belajar memasak maupun juga untuk kalian yang telah jago memasak.

Apakah kamu ingin mulai mencoba membikin resep opor ayam kampung (kuning) enak simple ini? Kalau anda tertarik, ayo kalian segera siapin alat dan bahannya, lantas bikin deh Resep opor ayam kampung (kuning) yang mantab dan tidak rumit ini. Sangat mudah kan. 

Oleh karena itu, daripada kita berlama-lama, ayo langsung aja sajikan resep opor ayam kampung (kuning) ini. Pasti kamu tak akan menyesal bikin resep opor ayam kampung (kuning) mantab tidak ribet ini! Selamat berkreasi dengan resep opor ayam kampung (kuning) lezat simple ini di tempat tinggal kalian masing-masing,ya!.

