---
description: "Resep Soto Betawi Ayam (kuah santan susu) yang enak dan Mudah Dibuat"
title: "Resep Soto Betawi Ayam (kuah santan susu) yang enak dan Mudah Dibuat"
slug: 386-resep-soto-betawi-ayam-kuah-santan-susu-yang-enak-dan-mudah-dibuat
date: 2021-06-10T07:54:08.491Z
image: https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg
author: Adeline Delgado
ratingvalue: 3
reviewcount: 8
recipeingredient:
- " BAhan  bahan "
- "500 gr ayam bagian dada"
- "2000 ml santan"
- "500 ml susu cair full cream"
- "2 batang sereh geprek"
- "1 ruas lengkuas geprek"
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "Secukup nya garam gula dan kaldu bubuk"
- " Bumbu Halus "
- "6 bh bawang merah"
- "4 buah bawang putih"
- "Seruas kunyit"
- "Seruas jahe"
- "5 buah kemiri sangrai"
- "1 sdt lada butiran"
- " Bahan Pelengkap"
- " Emping goreng"
- "1/2 kg kentang iris tipis bulat goreng kering"
- " Daun bawang"
- " Tomat"
- " Jeruk limo"
- " Sambal"
- " Bawang goreng"
recipeinstructions:
- "Potong kecil2 ayam lalu cuci bersih dan beri kucuran air jeruk nipis diam kan sebentar lalu cuci bersih kembali tiriskan"
- "Tumis bumbu halus hingga harum lalu masukan salam, sereh, lengkuas dan daun jeruk aduk hingga bumbu matang"
- "Panaskan santan biarkan hingga mendidih lalu masukan bumbu halus dan masukan ayam aduk biar kan ayam matang. Masukan susu beri gula garam dan kaldu bubuk koreksi rasa matikan kompor"
- "Penyajian.. tuang soto di mangkuk lalu beri tambahan bahan pelengkap lain nya sajikam dengan nasi hangat.. mantaaappp 🤤"
categories:
- Resep
tags:
- soto
- betawi
- ayam

katakunci: soto betawi ayam 
nutrition: 222 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dinner

---


![Soto Betawi Ayam (kuah santan susu)](https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan olahan enak kepada famili adalah suatu hal yang sangat menyenangkan untuk anda sendiri. Tanggung jawab seorang  wanita Tidak cuman mengatur rumah saja, namun kamu juga harus menyediakan kebutuhan nutrisi tercukupi dan juga masakan yang dimakan anak-anak wajib sedap.

Di zaman  saat ini, kalian sebenarnya mampu mengorder panganan instan walaupun tanpa harus ribet memasaknya dahulu. Namun banyak juga lho mereka yang memang ingin memberikan hidangan yang terlezat bagi orang yang dicintainya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai dengan masakan kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penyuka soto betawi ayam (kuah santan susu)?. Tahukah kamu, soto betawi ayam (kuah santan susu) merupakan hidangan khas di Nusantara yang kini disukai oleh orang-orang di berbagai tempat di Indonesia. Kita bisa menghidangkan soto betawi ayam (kuah santan susu) sendiri di rumahmu dan boleh dijadikan makanan kegemaranmu di akhir pekan.

Kita tak perlu bingung untuk menyantap soto betawi ayam (kuah santan susu), sebab soto betawi ayam (kuah santan susu) gampang untuk dicari dan juga kita pun dapat mengolahnya sendiri di tempatmu. soto betawi ayam (kuah santan susu) bisa dibuat memalui beraneka cara. Sekarang telah banyak cara kekinian yang membuat soto betawi ayam (kuah santan susu) lebih enak.

Resep soto betawi ayam (kuah santan susu) pun mudah untuk dibikin, lho. Kamu tidak perlu repot-repot untuk memesan soto betawi ayam (kuah santan susu), tetapi Anda dapat menyiapkan di rumah sendiri. Bagi Kita yang hendak menghidangkannya, berikut ini resep untuk membuat soto betawi ayam (kuah santan susu) yang mantab yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Soto Betawi Ayam (kuah santan susu):

1. Gunakan  BAhan - bahan :
1. Siapkan 500 gr ayam bagian dada
1. Ambil 2000 ml santan
1. Gunakan 500 ml susu cair full cream
1. Gunakan 2 batang sereh geprek
1. Gunakan 1 ruas lengkuas geprek
1. Ambil 3 lembar daun salam
1. Sediakan 4 lembar daun jeruk
1. Sediakan Secukup nya garam, gula dan kaldu bubuk
1. Sediakan  Bumbu Halus :
1. Sediakan 6 bh bawang merah
1. Sediakan 4 buah bawang putih
1. Sediakan Seruas kunyit
1. Sediakan Seruas jahe
1. Siapkan 5 buah kemiri sangrai
1. Siapkan 1 sdt lada butiran
1. Ambil  Bahan Pelengkap
1. Sediakan  Emping goreng
1. Gunakan 1/2 kg kentang iris tipis bulat goreng kering
1. Gunakan  Daun bawang
1. Siapkan  Tomat
1. Sediakan  Jeruk limo
1. Gunakan  Sambal
1. Sediakan  Bawang goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Betawi Ayam (kuah santan susu):

1. Potong kecil2 ayam lalu cuci bersih dan beri kucuran air jeruk nipis diam kan sebentar lalu cuci bersih kembali tiriskan
1. Tumis bumbu halus hingga harum lalu masukan salam, sereh, lengkuas dan daun jeruk aduk hingga bumbu matang
1. Panaskan santan biarkan hingga mendidih lalu masukan bumbu halus dan masukan ayam aduk biar kan ayam matang. Masukan susu beri gula garam dan kaldu bubuk koreksi rasa matikan kompor
1. Penyajian.. tuang soto di mangkuk lalu beri tambahan bahan pelengkap lain nya sajikam dengan nasi hangat.. mantaaappp 🤤




Wah ternyata resep soto betawi ayam (kuah santan susu) yang nikamt sederhana ini enteng banget ya! Semua orang bisa menghidangkannya. Cara buat soto betawi ayam (kuah santan susu) Sangat cocok banget untuk kalian yang baru akan belajar memasak ataupun bagi anda yang sudah jago dalam memasak.

Tertarik untuk mulai mencoba membikin resep soto betawi ayam (kuah santan susu) enak tidak rumit ini? Kalau kalian mau, mending kamu segera siapin alat dan bahan-bahannya, kemudian bikin deh Resep soto betawi ayam (kuah santan susu) yang mantab dan sederhana ini. Betul-betul mudah kan. 

Jadi, daripada kita berfikir lama-lama, maka langsung aja hidangkan resep soto betawi ayam (kuah santan susu) ini. Pasti kamu gak akan nyesel sudah bikin resep soto betawi ayam (kuah santan susu) mantab sederhana ini! Selamat mencoba dengan resep soto betawi ayam (kuah santan susu) nikmat tidak ribet ini di rumah masing-masing,oke!.

