---
description: "Bahan-bahan Ayam Panggang Bumbu Rujak yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Panggang Bumbu Rujak yang lezat dan Mudah Dibuat"
slug: 311-bahan-bahan-ayam-panggang-bumbu-rujak-yang-lezat-dan-mudah-dibuat
date: 2021-06-20T09:18:09.751Z
image: https://img-global.cpcdn.com/recipes/b779c7425075dd80/680x482cq70/ayam-panggang-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b779c7425075dd80/680x482cq70/ayam-panggang-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b779c7425075dd80/680x482cq70/ayam-panggang-bumbu-rujak-foto-resep-utama.jpg
author: Marc Cole
ratingvalue: 4
reviewcount: 15
recipeingredient:
- "1 ekor ayam 16 potong"
- "1 sdt garam Selera"
- "30 gr gula merah"
- "400 ml air"
- " Bumbu halus"
- "6 bh bawang merah"
- "5 siung bawang putih"
- "4 bh cabai merah beaar"
- "12 bh cabai rawit selera"
- "7 bh kemiri"
- "1 sdm ketumbar"
- "2 ruas jari jahe"
- "2 ruas jari kunyit"
- " Bumbu Cemplung"
- "2 lbr daun jeruk"
- "4 lbr daun salam"
- "1 btg serai"
- "3 biji asam jawa"
recipeinstructions:
- "Siapkan bahan-bahannya. Ayam diberi garam dan perasan jeruk, setelah diaduk lalu biarkan selama 15 menit. Lalu bilas kembali ayamnya."
- "Tumis bumbu halus dan bumbu Cemplung, masukkan ayam aduk merata."
- "Tambahkan air, gula merah dan garam. Biarkan hingga ayam matang dan bumbu menyerap hingga airnya tinggal sedikit (gunakan api kompor kecil). Koreksi rasa."
- "Siapkan teflon beri olesan margarin lalu panggang ayam bumbu rujak diatasnya, sambil sesekali dioles dengan sisa kuah bumbu ayam. Biarkan sesaat sambil dibalik balik, hingga hasil pangganganterihat cantik dan kering peemukaannya."
- "Angkat dan sajikan bersama lalapan, sambal dan nasi putih. Pasti yummy nya😘😍"
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 230 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Panggang Bumbu Rujak](https://img-global.cpcdn.com/recipes/b779c7425075dd80/680x482cq70/ayam-panggang-bumbu-rujak-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan panganan sedap untuk keluarga tercinta adalah hal yang sangat menyenangkan bagi kamu sendiri. Tanggung jawab seorang ibu Tidak hanya mengurus rumah saja, namun anda juga wajib memastikan keperluan gizi terpenuhi dan juga santapan yang disantap anak-anak mesti sedap.

Di masa  saat ini, anda memang mampu membeli olahan instan meski tidak harus repot memasaknya dahulu. Tapi ada juga orang yang memang mau menyajikan yang terenak bagi orang yang dicintainya. Sebab, memasak yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera keluarga. 



Mungkinkah kamu salah satu penikmat ayam panggang bumbu rujak?. Tahukah kamu, ayam panggang bumbu rujak merupakan sajian khas di Indonesia yang kini disukai oleh orang-orang di berbagai tempat di Indonesia. Anda bisa membuat ayam panggang bumbu rujak sendiri di rumahmu dan pasti jadi hidangan kesukaanmu di hari libur.

Kita jangan bingung jika kamu ingin mendapatkan ayam panggang bumbu rujak, sebab ayam panggang bumbu rujak gampang untuk ditemukan dan juga anda pun dapat menghidangkannya sendiri di tempatmu. ayam panggang bumbu rujak boleh dibuat dengan beragam cara. Saat ini sudah banyak resep modern yang membuat ayam panggang bumbu rujak semakin lezat.

Resep ayam panggang bumbu rujak pun gampang sekali untuk dibuat, lho. Anda tidak usah repot-repot untuk memesan ayam panggang bumbu rujak, karena Kalian dapat menyajikan di rumah sendiri. Bagi Anda yang mau mencobanya, dibawah ini merupakan resep untuk menyajikan ayam panggang bumbu rujak yang lezat yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Panggang Bumbu Rujak:

1. Sediakan 1 ekor ayam (16 potong)
1. Siapkan 1 sdt garam (Selera)
1. Gunakan 30 gr gula merah
1. Ambil 400 ml air
1. Sediakan  Bumbu halus:
1. Siapkan 6 bh bawang merah
1. Gunakan 5 siung bawang putih
1. Gunakan 4 bh cabai merah beaar
1. Ambil 12 bh cabai rawit (selera)
1. Sediakan 7 bh kemiri
1. Siapkan 1 sdm ketumbar
1. Sediakan 2 ruas jari jahe
1. Siapkan 2 ruas jari kunyit
1. Sediakan  Bumbu Cemplung:
1. Gunakan 2 lbr daun jeruk
1. Ambil 4 lbr daun salam
1. Siapkan 1 btg serai
1. Sediakan 3 biji asam jawa




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Panggang Bumbu Rujak:

1. Siapkan bahan-bahannya. Ayam diberi garam dan perasan jeruk, setelah diaduk lalu biarkan selama 15 menit. Lalu bilas kembali ayamnya.
1. Tumis bumbu halus dan bumbu Cemplung, masukkan ayam aduk merata.
1. Tambahkan air, gula merah dan garam. Biarkan hingga ayam matang dan bumbu menyerap hingga airnya tinggal sedikit (gunakan api kompor kecil). Koreksi rasa.
1. Siapkan teflon beri olesan margarin lalu panggang ayam bumbu rujak diatasnya, sambil sesekali dioles dengan sisa kuah bumbu ayam. Biarkan sesaat sambil dibalik balik, hingga hasil pangganganterihat cantik dan kering peemukaannya.
1. Angkat dan sajikan bersama lalapan, sambal dan nasi putih. Pasti yummy nya😘😍




Ternyata cara membuat ayam panggang bumbu rujak yang enak simple ini mudah banget ya! Anda Semua mampu memasaknya. Cara Membuat ayam panggang bumbu rujak Sangat cocok banget buat anda yang baru mau belajar memasak maupun bagi kamu yang telah jago dalam memasak.

Tertarik untuk mencoba membikin resep ayam panggang bumbu rujak mantab tidak ribet ini? Kalau kalian mau, yuk kita segera siapkan alat-alat dan bahan-bahannya, lantas buat deh Resep ayam panggang bumbu rujak yang nikmat dan tidak ribet ini. Sangat gampang kan. 

Oleh karena itu, daripada kalian berlama-lama, yuk langsung aja bikin resep ayam panggang bumbu rujak ini. Dijamin kalian tak akan nyesel bikin resep ayam panggang bumbu rujak nikmat tidak rumit ini! Selamat mencoba dengan resep ayam panggang bumbu rujak nikmat sederhana ini di rumah masing-masing,oke!.

