---
description: "Cara buat Soto Ayam Sederhana dan Mudah Dibuat"
title: "Cara buat Soto Ayam Sederhana dan Mudah Dibuat"
slug: 181-cara-buat-soto-ayam-sederhana-dan-mudah-dibuat
date: 2021-03-03T03:08:02.557Z
image: https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Herbert Hines
ratingvalue: 4.2
reviewcount: 12
recipeingredient:
- "1 kg dada ayam"
- "2 liter air"
- "3 sdm minyak goreng untuk tumis"
- "secukupnya garam  lada"
- "sedikit gula"
- "secukupnya kaldu ayam optional"
- " Bumbu A"
- "3 batang serai putihny saja memarkan"
- "6 lembar daun jeruk purut buang tulangnya iris tipis daunnya"
- "1-1,5 sdm kunyit bubuk"
- " Bumbu halus"
- "10 bj bawang merah"
- "5 bj bawang putih"
- "4 bj kemiri Sangrai"
- "3 cm jahe"
- " Pelengkap"
- "1 buah kentang size sedang iris tipis goreng"
- "1/4 buah kembang kol iris tipis"
- "2 genggam mie bihun rendam di air panas hingga lemas"
- "Sedikit irisan bawang merah goreng"
- "Sedikit perasan jeruk nipis"
- "iris Telur rebus"
recipeinstructions:
- "Rebus 5 buah telur hingga matang. Sisihkan."
- "Cuci ayam hingga bersih. Sisihkan."
- "Rebusan ayam: Didihkan air, masukkan ayam. Masak dengan api kecil hingga keluar kaldunya, buang busanya."
- "Tumisan bumbu: Panaskan minyak goreng, tumis bumbu halus + bumbu A hingga harum. Matikan kompor."
- "Masukkan tumisan bumbu ke dalam rebusan ayam, tambahkan sesuai selera garam, lada, gula, kaldu bubuk. Masak hingga ayam empuk."
- "Jika ayam sudah empuk, panaskan minyak goreng, goreng ayam hingga kecoklatan, angkat, lalu suir."
- "Tata soto dalam mangkuk: Bihun + kol + telur rebus + ayam suir + kentang, lalu siram dengan kuah yg panas (hati-hati), beri bawang merah goreng + sedikit perasan jeruk nipis🤤🤤. Sajikan."
- "Photo hanya saran penyajian, ditambah sedikit irisan tomat dan daun bawang (warnanya tambah cakep)🤩"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 101 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Apabila kamu seorang wanita, mempersiapkan panganan nikmat kepada orang tercinta adalah hal yang menyenangkan bagi kita sendiri. Kewajiban seorang ibu bukan cuman mengurus rumah saja, namun anda pun wajib memastikan kebutuhan gizi tercukupi dan juga santapan yang dimakan orang tercinta mesti sedap.

Di era  saat ini, anda sebenarnya mampu mengorder santapan praktis walaupun tidak harus ribet memasaknya dulu. Tapi ada juga lho orang yang selalu mau menyajikan yang terlezat untuk orang yang dicintainya. Karena, menyajikan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera orang tercinta. 



Mungkinkah anda seorang penikmat soto ayam?. Tahukah kamu, soto ayam merupakan sajian khas di Indonesia yang sekarang disukai oleh banyak orang di berbagai daerah di Nusantara. Kalian bisa membuat soto ayam sendiri di rumah dan boleh jadi makanan favorit di akhir pekan.

Kita jangan bingung untuk memakan soto ayam, sebab soto ayam gampang untuk didapatkan dan juga kita pun boleh menghidangkannya sendiri di rumah. soto ayam boleh dimasak memalui bermacam cara. Kini pun telah banyak sekali resep modern yang menjadikan soto ayam semakin lebih mantap.

Resep soto ayam pun mudah dibikin, lho. Kalian tidak usah repot-repot untuk memesan soto ayam, lantaran Anda dapat membuatnya sendiri di rumah. Untuk Anda yang hendak mencobanya, berikut cara menyajikan soto ayam yang enak yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Soto Ayam:

1. Gunakan 1 kg dada ayam
1. Gunakan 2 liter air
1. Gunakan 3 sdm minyak goreng untuk tumis
1. Sediakan secukupnya garam &amp; lada
1. Sediakan sedikit gula
1. Gunakan secukupnya kaldu ayam (optional)
1. Sediakan  Bumbu A:
1. Ambil 3 batang serai, putihny saja, memarkan
1. Ambil 6 lembar daun jeruk purut, buang tulangnya, iris tipis daunnya
1. Siapkan 1-1,5 sdm kunyit bubuk
1. Ambil  Bumbu halus:
1. Gunakan 10 bj bawang merah
1. Sediakan 5 bj bawang putih
1. Ambil 4 bj kemiri Sangrai
1. Ambil 3 cm jahe
1. Ambil  Pelengkap:
1. Sediakan 1 buah kentang size sedang, iris tipis, goreng
1. Sediakan 1/4 buah kembang kol, iris tipis
1. Gunakan 2 genggam mie bihun, rendam di air panas hingga lemas
1. Sediakan Sedikit irisan bawang merah goreng
1. Gunakan Sedikit perasan jeruk nipis
1. Gunakan iris Telur rebus,




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam:

1. Rebus 5 buah telur hingga matang. Sisihkan.
1. Cuci ayam hingga bersih. Sisihkan.
1. Rebusan ayam: - Didihkan air, masukkan ayam. Masak dengan api kecil hingga keluar kaldunya, buang busanya.
1. Tumisan bumbu: - Panaskan minyak goreng, tumis bumbu halus + bumbu A hingga harum. Matikan kompor.
1. Masukkan tumisan bumbu ke dalam rebusan ayam, tambahkan sesuai selera garam, lada, gula, kaldu bubuk. Masak hingga ayam empuk.
1. Jika ayam sudah empuk, panaskan minyak goreng, goreng ayam hingga kecoklatan, angkat, lalu suir.
1. Tata soto dalam mangkuk: - Bihun + kol + telur rebus + ayam suir + kentang, lalu siram dengan kuah yg panas (hati-hati), beri bawang merah goreng + sedikit perasan jeruk nipis🤤🤤. Sajikan.
1. Photo hanya saran penyajian, ditambah sedikit irisan tomat dan daun bawang (warnanya tambah cakep)🤩




Ternyata cara buat soto ayam yang lezat tidak ribet ini mudah sekali ya! Semua orang mampu memasaknya. Resep soto ayam Sangat cocok banget buat kamu yang baru akan belajar memasak ataupun juga bagi anda yang telah ahli dalam memasak.

Apakah kamu ingin mulai mencoba bikin resep soto ayam mantab sederhana ini? Kalau kalian tertarik, ayo kalian segera siapin alat dan bahan-bahannya, setelah itu bikin deh Resep soto ayam yang mantab dan tidak ribet ini. Sungguh mudah kan. 

Maka dari itu, daripada kamu diam saja, hayo langsung aja hidangkan resep soto ayam ini. Dijamin kalian gak akan menyesal membuat resep soto ayam lezat tidak ribet ini! Selamat berkreasi dengan resep soto ayam enak sederhana ini di rumah masing-masing,ya!.

