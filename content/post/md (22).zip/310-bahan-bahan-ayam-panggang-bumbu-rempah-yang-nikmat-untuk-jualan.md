---
description: "Bahan-bahan Ayam Panggang Bumbu Rempah yang nikmat Untuk Jualan"
title: "Bahan-bahan Ayam Panggang Bumbu Rempah yang nikmat Untuk Jualan"
slug: 310-bahan-bahan-ayam-panggang-bumbu-rempah-yang-nikmat-untuk-jualan
date: 2021-04-29T04:30:01.529Z
image: https://img-global.cpcdn.com/recipes/9d6b93e914dd53b2/680x482cq70/ayam-panggang-bumbu-rempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d6b93e914dd53b2/680x482cq70/ayam-panggang-bumbu-rempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d6b93e914dd53b2/680x482cq70/ayam-panggang-bumbu-rempah-foto-resep-utama.jpg
author: Louise Drake
ratingvalue: 4.7
reviewcount: 15
recipeingredient:
- "2 ekor ayam kampung ukuran sedang"
- "200 ml air kelapa"
- "10 siung bawang merah"
- "1 bonggol bawang putih"
- "1 sdm tipis terasi"
- "1 sdm ketumbar sangrai"
- "6 butir kemiri sangrai"
- "1 blok bulat gula jawa"
- "10 cm jahe"
- "3 bh cabai merah besar buang biji"
- "10 cm lengkuas"
- "2 bh tomat"
- "Secukupnya kecap"
- "1,5 sdt garam"
- "Secukupnya minyak untuk menumis"
- "Secukupnya daun salam"
- "Secukupnya daun jeruk"
recipeinstructions:
- "Haluskan bawang2, jahe, lengkuas, tomat, cabai, terasi, kemiri &amp; ketumbar."
- "Tumis bumbu halus beserta dengan daun jeruk &amp; daun salam hingga harum"
- "Siapkan wajan untuk mengungkep, masukan ayam &amp; air kelapa, tambahkan air jika perlu, dan masukan tumisan bumbu dan gula jawa."
- "Masak ayam hingga bumbu meresap &amp; asat. Sambil panaskan oven 160 derajat."
- "Siapkan loyang yang telah dilapisi alumunium foil. Masukan ayam kedalam loyang"
- "Panggang ayam dalam oven yang sudah dipanaskan selama 15-20 menit."
- "Jika sudah matang, sajikan bersama dengan lalap dan sambal terasi."
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 200 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Panggang Bumbu Rempah](https://img-global.cpcdn.com/recipes/9d6b93e914dd53b2/680x482cq70/ayam-panggang-bumbu-rempah-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan santapan enak kepada keluarga tercinta merupakan hal yang mengasyikan untuk anda sendiri. Peran seorang ibu bukan saja mengurus rumah saja, tapi kamu pun wajib memastikan keperluan gizi tercukupi dan olahan yang disantap orang tercinta harus mantab.

Di waktu  sekarang, anda sebenarnya dapat mengorder panganan instan walaupun tidak harus susah mengolahnya terlebih dahulu. Namun banyak juga lho orang yang selalu mau menyajikan yang terbaik untuk orang tercintanya. Sebab, menyajikan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai kesukaan famili. 



Apakah anda merupakan seorang penggemar ayam panggang bumbu rempah?. Asal kamu tahu, ayam panggang bumbu rempah adalah makanan khas di Indonesia yang sekarang digemari oleh orang-orang di hampir setiap daerah di Indonesia. Kita dapat membuat ayam panggang bumbu rempah kreasi sendiri di rumahmu dan boleh jadi makanan favoritmu di hari libur.

Kamu tidak usah bingung jika kamu ingin menyantap ayam panggang bumbu rempah, sebab ayam panggang bumbu rempah sangat mudah untuk dicari dan anda pun dapat memasaknya sendiri di tempatmu. ayam panggang bumbu rempah bisa diolah lewat beragam cara. Sekarang sudah banyak resep kekinian yang menjadikan ayam panggang bumbu rempah lebih nikmat.

Resep ayam panggang bumbu rempah juga gampang sekali untuk dibikin, lho. Kamu tidak usah capek-capek untuk memesan ayam panggang bumbu rempah, karena Kalian dapat menyiapkan di rumahmu. Bagi Anda yang hendak menghidangkannya, berikut cara untuk menyajikan ayam panggang bumbu rempah yang mantab yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Panggang Bumbu Rempah:

1. Siapkan 2 ekor ayam kampung ukuran sedang
1. Gunakan 200 ml air kelapa
1. Gunakan 10 siung bawang merah
1. Gunakan 1 bonggol bawang putih
1. Siapkan 1 sdm tipis terasi
1. Siapkan 1 sdm ketumbar sangrai
1. Gunakan 6 butir kemiri sangrai
1. Sediakan 1 blok bulat gula jawa
1. Siapkan 10 cm jahe
1. Sediakan 3 bh cabai merah besar, buang biji
1. Siapkan 10 cm lengkuas
1. Sediakan 2 bh tomat
1. Gunakan Secukupnya kecap
1. Siapkan 1,5 sdt garam
1. Sediakan Secukupnya minyak untuk menumis
1. Sediakan Secukupnya daun salam
1. Ambil Secukupnya daun jeruk




<!--inarticleads2-->

##### Cara menyiapkan Ayam Panggang Bumbu Rempah:

1. Haluskan bawang2, jahe, lengkuas, tomat, cabai, terasi, kemiri &amp; ketumbar.
1. Tumis bumbu halus beserta dengan daun jeruk &amp; daun salam hingga harum
1. Siapkan wajan untuk mengungkep, masukan ayam &amp; air kelapa, tambahkan air jika perlu, dan masukan tumisan bumbu dan gula jawa.
1. Masak ayam hingga bumbu meresap &amp; asat. Sambil panaskan oven 160 derajat.
1. Siapkan loyang yang telah dilapisi alumunium foil. Masukan ayam kedalam loyang
1. Panggang ayam dalam oven yang sudah dipanaskan selama 15-20 menit.
1. Jika sudah matang, sajikan bersama dengan lalap dan sambal terasi.




Ternyata cara membuat ayam panggang bumbu rempah yang enak tidak rumit ini enteng sekali ya! Kita semua dapat menghidangkannya. Resep ayam panggang bumbu rempah Sesuai banget untuk kalian yang baru mau belajar memasak atau juga untuk kamu yang sudah pandai dalam memasak.

Apakah kamu mau mulai mencoba bikin resep ayam panggang bumbu rempah nikmat tidak rumit ini? Kalau kalian tertarik, ayo kalian segera siapin alat dan bahannya, maka bikin deh Resep ayam panggang bumbu rempah yang lezat dan tidak rumit ini. Sungguh gampang kan. 

Maka, daripada kalian diam saja, maka kita langsung sajikan resep ayam panggang bumbu rempah ini. Dijamin kamu gak akan menyesal membuat resep ayam panggang bumbu rempah mantab tidak rumit ini! Selamat mencoba dengan resep ayam panggang bumbu rempah lezat sederhana ini di rumah sendiri,ya!.

