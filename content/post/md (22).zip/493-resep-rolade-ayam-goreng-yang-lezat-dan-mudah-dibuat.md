---
description: "Resep Rolade Ayam Goreng yang lezat dan Mudah Dibuat"
title: "Resep Rolade Ayam Goreng yang lezat dan Mudah Dibuat"
slug: 493-resep-rolade-ayam-goreng-yang-lezat-dan-mudah-dibuat
date: 2021-01-30T11:46:25.658Z
image: https://img-global.cpcdn.com/recipes/a53eb8496494b685/680x482cq70/rolade-ayam-goreng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a53eb8496494b685/680x482cq70/rolade-ayam-goreng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a53eb8496494b685/680x482cq70/rolade-ayam-goreng-foto-resep-utama.jpg
author: Paul Jordan
ratingvalue: 4.8
reviewcount: 10
recipeingredient:
- " Bahan Isi"
- "200 gr ayam giling"
- "100 gr udang giling"
- "2 siung bawang putih dihaluskan"
- "1 batang daun bawang diiris halus"
- "1 buah wortel parut kasar"
- "1 sdt kecap ikan"
- "1/2 sdt minyak wijen"
- "1/2 sdt garam"
- "1/4 sdt merica bubuk"
- "3 sdm tepung sagutapioka"
- "2 butir telur dikocok lepas"
- " Bahan Kulit"
- "2 butir telur dikocok lepas"
- "1 sdm air"
- "1/8 sdt garam"
- " Bahan Pencelup aduk rata"
- "50 gr tepung terigu protein sedang"
- "1/2 sdm tepung sagu"
- "100 ml air"
- "1/4 sdt garam"
- "1/8 sdt merica bubuk"
- " Bahan bumbu saus"
- "2 siung bawang putih dicincang halus"
- "4 sdm saus tomat"
- "1 sdm kecap inggris"
- "1 1/2 sdt kecap manis"
- "300 ml air"
- "1 sdt gula pasir"
- "1/2 sdt garam"
- "1/4 sdt merica bubuk"
- "1/4 sdt pala bubuk"
- "2 sdt maizena larutkan dengan 2 sdt air untuk pengental"
- " Bahan Pelengkap"
- "100 gr kentang kupas rebus goreng"
- "50 gr buncis potong 2 ruas jari rebus"
- "50 gr wortel potong korek api sepanjang 2 ruas jari rebus"
recipeinstructions:
- "Bahan Isi. Aduk rata daging ayam giling, udang giling, bawang putih, daun bawang, wortel parut, kecap ikan, minyak wijen, garam, dan merica bubuk. Masukkan telur yang telah dikocok lepas sedikit-sedikit sambil diaduk. Disini aku mengaduknya menggunakan tangan. Awalnya tekstur adonan terpisah, namun terus saja aduk maka lama kelamaan adonan akan kalis. Masukkan Tepung sagu/tapioka. Aduk rata menggunakan spatula. Masukkan kedalam kulkas."
- "Bahan Kulit. Kocok lepas semua bahan kulit, lalu saring. Tuang tipis telur kedalam wajan anti lengket diameter bawah 18cm diatas api cenderung kecil. Kulit tidak perlu dibolak balik ya, krn adonan kulit tipis maka begitu bagian bawah matang, bagian atasnya pun matang. Angkat. Sisihkan. Disini akan dapat 3 lembar kulit."
- "Ambil 1 lembar kulit. Letakkan diatas plastik food grade. Berikan bahan isian, lalu ratakan. Gulung adonan, lalu padatkan dgn cara menekan ujung adonan dgn scrapper atau penggaris. Ikat ujung kanan dan kiri plastik dgn karet."
- "Tusuk-tusuk plastik dengan tusuk gigi supaya nanti pada saat dikukus, uap masuk kedalam adonan. Kukus adonan kedalam dandang yang telah panas diatas api sedang."
- "Kukus selama 30-40 mnt. Disini bisa dilihat adonan mengembang sedikit ya. Angkat. Biarkan dingin. Buka bungkus plastik. Lalu guling kan keatas bahan pencelup."
- "Goreng rolade kedalam minyak yang cukup panas diatas api sedang. Goreng sampai kesemua sisinya kuning kecoklatan. Angkat dan tiriskan. Sisihkan."
- "Bahan Saus. Panaskan secukupnya minyak diatas api sedang. Tumis bawang putih. Masukkan saus tomat, kecap inggris dan kecap manis. Aduk rata. Tuangkan air. Aduk rata. Biarkan mendidih dan sedikit menyusut. Lalu beri gula pasir, garam, merica dan pala bubuk. Aduk rata."
- "Masukkan larutan tepung maizena (masukkan separuh dulu, nanti cek konsistensinya). Aduk rata, biarkan mengental. Cicip dan koreksi rasa. Angkat.   Penyelesaian: Potong-potong Rolade. Tuangkan saus. Sajikan beserta kentang goreng, buncis dan wortel rebus."
categories:
- Resep
tags:
- rolade
- ayam
- goreng

katakunci: rolade ayam goreng 
nutrition: 144 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dinner

---


![Rolade Ayam Goreng](https://img-global.cpcdn.com/recipes/a53eb8496494b685/680x482cq70/rolade-ayam-goreng-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyediakan olahan sedap untuk orang tercinta merupakan suatu hal yang menggembirakan bagi kita sendiri. Tanggung jawab seorang istri Tidak saja mengurus rumah saja, namun kamu pun harus memastikan kebutuhan gizi terpenuhi dan panganan yang dikonsumsi orang tercinta mesti nikmat.

Di masa  saat ini, anda memang dapat mengorder olahan praktis tidak harus repot memasaknya terlebih dahulu. Tapi banyak juga orang yang selalu mau memberikan hidangan yang terenak bagi keluarganya. Karena, memasak sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan masakan kesukaan famili. 



Apakah anda merupakan salah satu penikmat rolade ayam goreng?. Asal kamu tahu, rolade ayam goreng adalah hidangan khas di Indonesia yang kini disukai oleh setiap orang dari berbagai wilayah di Indonesia. Anda bisa menyajikan rolade ayam goreng olahan sendiri di rumahmu dan pasti jadi makanan favoritmu di akhir pekan.

Kalian tak perlu bingung untuk menyantap rolade ayam goreng, karena rolade ayam goreng mudah untuk ditemukan dan kamu pun boleh memasaknya sendiri di tempatmu. rolade ayam goreng dapat diolah lewat beragam cara. Kini telah banyak sekali cara kekinian yang menjadikan rolade ayam goreng semakin enak.

Resep rolade ayam goreng juga gampang dihidangkan, lho. Kamu tidak usah capek-capek untuk memesan rolade ayam goreng, lantaran Kamu bisa membuatnya ditempatmu. Untuk Kita yang ingin membuatnya, inilah cara menyajikan rolade ayam goreng yang lezat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Rolade Ayam Goreng:

1. Gunakan  Bahan Isi
1. Gunakan 200 gr ayam giling
1. Sediakan 100 gr udang giling
1. Siapkan 2 siung bawang putih, dihaluskan
1. Gunakan 1 batang daun bawang, diiris halus
1. Siapkan 1 buah wortel, parut kasar
1. Siapkan 1 sdt kecap ikan
1. Ambil 1/2 sdt minyak wijen
1. Siapkan 1/2 sdt garam
1. Gunakan 1/4 sdt merica bubuk
1. Ambil 3 sdm tepung sagu/tapioka
1. Sediakan 2 butir telur, dikocok lepas
1. Siapkan  Bahan Kulit
1. Sediakan 2 butir telur, dikocok lepas
1. Ambil 1 sdm air
1. Gunakan 1/8 sdt garam
1. Sediakan  Bahan Pencelup (aduk rata)
1. Sediakan 50 gr tepung terigu protein sedang
1. Sediakan 1/2 sdm tepung sagu
1. Gunakan 100 ml air
1. Siapkan 1/4 sdt garam
1. Ambil 1/8 sdt merica bubuk
1. Gunakan  Bahan bumbu saus
1. Sediakan 2 siung bawang putih, dicincang halus
1. Gunakan 4 sdm saus tomat
1. Gunakan 1 sdm kecap inggris
1. Siapkan 1 1/2 sdt kecap manis
1. Siapkan 300 ml air
1. Gunakan 1 sdt gula pasir
1. Gunakan 1/2 sdt garam
1. Gunakan 1/4 sdt merica bubuk
1. Gunakan 1/4 sdt pala bubuk
1. Ambil 2 sdt maizena larutkan dengan 2 sdt air, untuk pengental
1. Gunakan  Bahan Pelengkap
1. Gunakan 100 gr kentang, kupas, rebus, goreng
1. Ambil 50 gr buncis, potong 2 ruas jari, rebus
1. Gunakan 50 gr wortel, potong korek api sepanjang 2 ruas jari, rebus




<!--inarticleads2-->

##### Langkah-langkah membuat Rolade Ayam Goreng:

1. Bahan Isi. Aduk rata daging ayam giling, udang giling, bawang putih, daun bawang, wortel parut, kecap ikan, minyak wijen, garam, dan merica bubuk. Masukkan telur yang telah dikocok lepas sedikit-sedikit sambil diaduk. Disini aku mengaduknya menggunakan tangan. Awalnya tekstur adonan terpisah, namun terus saja aduk maka lama kelamaan adonan akan kalis. Masukkan Tepung sagu/tapioka. Aduk rata menggunakan spatula. Masukkan kedalam kulkas.
1. Bahan Kulit. Kocok lepas semua bahan kulit, lalu saring. Tuang tipis telur kedalam wajan anti lengket diameter bawah 18cm diatas api cenderung kecil. Kulit tidak perlu dibolak balik ya, krn adonan kulit tipis maka begitu bagian bawah matang, bagian atasnya pun matang. Angkat. Sisihkan. Disini akan dapat 3 lembar kulit.
1. Ambil 1 lembar kulit. Letakkan diatas plastik food grade. Berikan bahan isian, lalu ratakan. Gulung adonan, lalu padatkan dgn cara menekan ujung adonan dgn scrapper atau penggaris. Ikat ujung kanan dan kiri plastik dgn karet.
1. Tusuk-tusuk plastik dengan tusuk gigi supaya nanti pada saat dikukus, uap masuk kedalam adonan. Kukus adonan kedalam dandang yang telah panas diatas api sedang.
1. Kukus selama 30-40 mnt. Disini bisa dilihat adonan mengembang sedikit ya. Angkat. Biarkan dingin. Buka bungkus plastik. Lalu guling kan keatas bahan pencelup.
1. Goreng rolade kedalam minyak yang cukup panas diatas api sedang. Goreng sampai kesemua sisinya kuning kecoklatan. Angkat dan tiriskan. Sisihkan.
1. Bahan Saus. Panaskan secukupnya minyak diatas api sedang. Tumis bawang putih. Masukkan saus tomat, kecap inggris dan kecap manis. Aduk rata. Tuangkan air. Aduk rata. Biarkan mendidih dan sedikit menyusut. Lalu beri gula pasir, garam, merica dan pala bubuk. Aduk rata.
1. Masukkan larutan tepung maizena (masukkan separuh dulu, nanti cek konsistensinya). Aduk rata, biarkan mengental. Cicip dan koreksi rasa. Angkat.  -  - Penyelesaian: Potong-potong Rolade. Tuangkan saus. Sajikan beserta kentang goreng, buncis dan wortel rebus.




Ternyata cara buat rolade ayam goreng yang enak sederhana ini enteng banget ya! Kalian semua dapat membuatnya. Cara Membuat rolade ayam goreng Sangat sesuai sekali untuk kamu yang baru mau belajar memasak atau juga bagi anda yang telah ahli dalam memasak.

Apakah kamu tertarik mulai mencoba membikin resep rolade ayam goreng enak tidak ribet ini? Kalau kalian tertarik, ayo kalian segera menyiapkan peralatan dan bahan-bahannya, maka bikin deh Resep rolade ayam goreng yang lezat dan simple ini. Sangat mudah kan. 

Maka dari itu, daripada kita diam saja, yuk kita langsung saja buat resep rolade ayam goreng ini. Pasti kalian gak akan nyesel sudah membuat resep rolade ayam goreng enak tidak rumit ini! Selamat mencoba dengan resep rolade ayam goreng lezat sederhana ini di tempat tinggal kalian sendiri,oke!.

