---
description: "Cara buat Soto Ayam Santan ala Violet Azalea yang enak dan Mudah Dibuat"
title: "Cara buat Soto Ayam Santan ala Violet Azalea yang enak dan Mudah Dibuat"
slug: 390-cara-buat-soto-ayam-santan-ala-violet-azalea-yang-enak-dan-mudah-dibuat
date: 2021-03-05T03:52:48.460Z
image: https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg
author: Jim Brady
ratingvalue: 3.3
reviewcount: 3
recipeingredient:
- "1 ekor ayam 15 kg"
- "1 1/2 liter air"
- "2 liter santan kekentalan sedang"
- "4 buah tomat ukuran besar potong"
- "2 batang serai geprek"
- "2 ruas jari lengkuas geprek"
- "5 lembar daun jeruk"
- "4 lembar daun salam"
- "secukupnya garam"
- "1 sachet kaldu bubuk rasa ayam"
- "secukupnya vetsin"
- "1 sdm gula pasir"
- " Bumbu Halus "
- "8 siung bawang merah"
- "5 siung bawang putih"
- "2 1/2 ruas jari kunyit bakar kupas kulit arinya"
- "1 1/2 ruas jahe"
- "4 buah kemiri sangrai"
- "1 sdm ketumbar butiran sangrai"
- " Pelengkap "
- " Perkedel Singkong           lihat resep"
- " Sambal           lihat resep"
- " Bawang goreng"
- "iris Daun bawang"
recipeinstructions:
- "Tumis bumbu halus, daun jeruk, daun salam, lengkuas dan serai hingga harum dan matang. Sisihkan."
- "Di dalam sebuah panci rebus ayam dan air. Masak hingga ayam lunak dan daging terlihat agak terlepas dari tulang. Beri santan dan tumisan bumbu."
- "Bumbui dengan kaldu bubuk rasa ayam, garam, vetsin dan gula. Aduk terus ya agar santan tak terpecah. Sesaat sebelum diangkat masukkan tomat iris. Angkat."
- "Angkat ayam. Tiriskan. Goreng sejenak saja di api besar cukup hingga agak nyoklat sedikit. Tidak usah sampai kering. Suwir-suwir daging ayam. Sisihkan."
- "Di dalam piring sendok nasi hangat. Sendokkan kuah ke dalam piring berisi nasi. Sajikan dengan pelengkap."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 182 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch

---


![Soto Ayam Santan ala Violet Azalea](https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyuguhkan hidangan nikmat buat keluarga tercinta merupakan hal yang mengasyikan untuk anda sendiri. Kewajiban seorang  wanita bukan sekedar mengerjakan pekerjaan rumah saja, tapi kamu juga harus memastikan keperluan nutrisi tercukupi dan juga santapan yang dikonsumsi keluarga tercinta harus sedap.

Di zaman  sekarang, anda sebenarnya mampu membeli hidangan jadi meski tanpa harus capek membuatnya dahulu. Tetapi ada juga lho orang yang memang mau menyajikan yang terbaik untuk keluarganya. Pasalnya, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan berdasarkan selera keluarga. 



Apakah kamu salah satu penikmat soto ayam santan ala violet azalea?. Asal kamu tahu, soto ayam santan ala violet azalea adalah hidangan khas di Indonesia yang saat ini digemari oleh kebanyakan orang di hampir setiap tempat di Indonesia. Kalian bisa menyajikan soto ayam santan ala violet azalea kreasi sendiri di rumahmu dan boleh jadi makanan favoritmu di akhir pekan.

Kita tak perlu bingung jika kamu ingin mendapatkan soto ayam santan ala violet azalea, karena soto ayam santan ala violet azalea tidak sukar untuk ditemukan dan kita pun dapat mengolahnya sendiri di tempatmu. soto ayam santan ala violet azalea boleh diolah lewat beraneka cara. Kini pun telah banyak banget cara modern yang membuat soto ayam santan ala violet azalea lebih nikmat.

Resep soto ayam santan ala violet azalea juga sangat gampang dibuat, lho. Kita tidak perlu ribet-ribet untuk membeli soto ayam santan ala violet azalea, sebab Anda bisa menyajikan di rumahmu. Bagi Anda yang hendak menghidangkannya, di bawah ini adalah cara membuat soto ayam santan ala violet azalea yang mantab yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Soto Ayam Santan ala Violet Azalea:

1. Siapkan 1 ekor ayam (1,5 kg)
1. Siapkan 1 1/2 liter air
1. Siapkan 2 liter santan kekentalan sedang
1. Gunakan 4 buah tomat ukuran besar, potong
1. Gunakan 2 batang serai, geprek
1. Ambil 2 ruas jari lengkuas, geprek
1. Siapkan 5 lembar daun jeruk
1. Siapkan 4 lembar daun salam
1. Gunakan secukupnya garam
1. Siapkan 1 sachet kaldu bubuk rasa ayam
1. Sediakan secukupnya vetsin
1. Siapkan 1 sdm gula pasir
1. Siapkan  Bumbu Halus :
1. Ambil 8 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Siapkan 2 1/2 ruas jari kunyit, bakar, kupas kulit arinya
1. Gunakan 1 1/2 ruas jahe
1. Sediakan 4 buah kemiri, sangrai
1. Siapkan 1 sdm ketumbar butiran, sangrai
1. Ambil  Pelengkap :
1. Gunakan  Perkedel Singkong           (lihat resep)
1. Siapkan  Sambal           (lihat resep)
1. Gunakan  Bawang goreng
1. Gunakan iris Daun bawang




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Santan ala Violet Azalea:

1. Tumis bumbu halus, daun jeruk, daun salam, lengkuas dan serai hingga harum dan matang. Sisihkan.
1. Di dalam sebuah panci rebus ayam dan air. Masak hingga ayam lunak dan daging terlihat agak terlepas dari tulang. Beri santan dan tumisan bumbu.
1. Bumbui dengan kaldu bubuk rasa ayam, garam, vetsin dan gula. Aduk terus ya agar santan tak terpecah. Sesaat sebelum diangkat masukkan tomat iris. Angkat.
1. Angkat ayam. Tiriskan. Goreng sejenak saja di api besar cukup hingga agak nyoklat sedikit. Tidak usah sampai kering. Suwir-suwir daging ayam. Sisihkan.
1. Di dalam piring sendok nasi hangat. Sendokkan kuah ke dalam piring berisi nasi. Sajikan dengan pelengkap.




Ternyata resep soto ayam santan ala violet azalea yang nikamt tidak rumit ini gampang sekali ya! Kita semua bisa menghidangkannya. Resep soto ayam santan ala violet azalea Sangat cocok banget buat kamu yang sedang belajar memasak ataupun bagi anda yang sudah hebat memasak.

Tertarik untuk mulai mencoba bikin resep soto ayam santan ala violet azalea lezat tidak rumit ini? Kalau kamu ingin, yuk kita segera buruan siapin alat dan bahan-bahannya, lalu buat deh Resep soto ayam santan ala violet azalea yang enak dan sederhana ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kalian berlama-lama, hayo kita langsung saja sajikan resep soto ayam santan ala violet azalea ini. Dijamin kamu tak akan nyesel sudah membuat resep soto ayam santan ala violet azalea lezat sederhana ini! Selamat berkreasi dengan resep soto ayam santan ala violet azalea enak simple ini di rumah kalian sendiri,ya!.

