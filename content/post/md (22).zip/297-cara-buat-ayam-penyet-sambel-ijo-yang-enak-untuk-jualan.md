---
description: "Cara buat *Ayam Penyet Sambel Ijo* yang enak Untuk Jualan"
title: "Cara buat *Ayam Penyet Sambel Ijo* yang enak Untuk Jualan"
slug: 297-cara-buat-ayam-penyet-sambel-ijo-yang-enak-untuk-jualan
date: 2021-07-07T03:47:16.307Z
image: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
author: Elizabeth Daniels
ratingvalue: 4.4
reviewcount: 13
recipeingredient:
- "1/2 ekor ayam"
- "1 btg sereh"
- "2 lbr daun jeruk"
- " Bumbu ungkep ayam "
- "4 siung bwg merah Sy skip"
- "3 siung bwg putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt ketumbar"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya kaldu jamur sy skip"
- "Secukupnya air"
- " Bumbu sambel ijo "
- "8 cabe ijo keriting"
- "2 cabe ijo besar"
- "10 cabe rawit ijo"
- "1 buah tomat ijo"
- "3 siung bwg merah"
- "3 siung bwg putih"
- "2 sdm bumbu dasar cabe ijo tambahan sy           lihat resep"
recipeinstructions:
- "Cuci bersih ayam rebus hingga mendidih, angkat lalu rebus lagi bersama bumbu lainnya hingga bumbu meyerap dan airnya mengering. Lalu goreng hingga matang (sy, tidak terlalu kering), angkat sisihkan."
- "Cuci bahan sambal, potong2 lalu goreng hingga matang. Kemudian ulek kasar saja"
- "Tambahkan bumbu dasar cabe ijo, beri garam dan gula. Ulek hingga tercampur rata"
- "Taruh ayam goreng diatas.sambal lalu penyet dengan ulekan dan pindahkan dalam wadah saji"
- "Daan ayam penyet sambal ijo siap disajikan, ditambah perasan air jeruk nipis lebih enak"
categories:
- Resep
tags:
- ayam
- penyet
- sambel

katakunci: ayam penyet sambel 
nutrition: 206 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dinner

---


![*Ayam Penyet Sambel Ijo*](https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan santapan nikmat untuk famili adalah suatu hal yang menggembirakan bagi kamu sendiri. Peran seorang  wanita bukan cuman mengurus rumah saja, tapi anda juga harus menyediakan kebutuhan gizi terpenuhi dan juga panganan yang dikonsumsi orang tercinta wajib enak.

Di zaman  saat ini, anda sebenarnya bisa membeli panganan instan meski tidak harus ribet mengolahnya dulu. Tetapi banyak juga lho mereka yang memang mau menyajikan yang terenak bagi keluarganya. Pasalnya, memasak sendiri jauh lebih higienis dan bisa menyesuaikan berdasarkan selera keluarga tercinta. 



Mungkinkah anda merupakan salah satu penggemar *ayam penyet sambel ijo*?. Asal kamu tahu, *ayam penyet sambel ijo* merupakan hidangan khas di Indonesia yang saat ini disenangi oleh banyak orang dari hampir setiap wilayah di Indonesia. Kalian dapat menghidangkan *ayam penyet sambel ijo* olahan sendiri di rumahmu dan dapat dijadikan hidangan favoritmu di akhir pekanmu.

Kamu jangan bingung jika kamu ingin memakan *ayam penyet sambel ijo*, lantaran *ayam penyet sambel ijo* tidak sulit untuk dicari dan kalian pun bisa menghidangkannya sendiri di rumah. *ayam penyet sambel ijo* dapat dimasak dengan beragam cara. Kini pun ada banyak sekali resep kekinian yang membuat *ayam penyet sambel ijo* lebih enak.

Resep *ayam penyet sambel ijo* pun sangat mudah dibuat, lho. Anda tidak perlu repot-repot untuk memesan *ayam penyet sambel ijo*, sebab Anda bisa menghidangkan ditempatmu. Bagi Anda yang hendak menghidangkannya, inilah resep menyajikan *ayam penyet sambel ijo* yang mantab yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan *Ayam Penyet Sambel Ijo*:

1. Gunakan 1/2 ekor ayam
1. Ambil 1 btg sereh
1. Sediakan 2 lbr daun jeruk
1. Ambil  Bumbu ungkep ayam :
1. Sediakan 4 siung bwg merah (Sy, skip)
1. Ambil 3 siung bwg putih
1. Sediakan 1 ruas jahe
1. Gunakan 1 ruas kunyit
1. Siapkan 1 sdt ketumbar
1. Gunakan Secukupnya garam
1. Sediakan Secukupnya gula
1. Sediakan Secukupnya kaldu jamur (sy, skip)
1. Sediakan Secukupnya air
1. Gunakan  Bumbu sambel ijo :
1. Ambil 8 cabe ijo keriting
1. Gunakan 2 cabe ijo besar
1. Sediakan 10 cabe rawit ijo
1. Sediakan 1 buah tomat ijo
1. Sediakan 3 siung bwg merah
1. Ambil 3 siung bwg putih
1. Ambil 2 sdm bumbu dasar cabe ijo (tambahan sy)           (lihat resep)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan *Ayam Penyet Sambel Ijo*:

1. Cuci bersih ayam rebus hingga mendidih, angkat lalu rebus lagi bersama bumbu lainnya hingga bumbu meyerap dan airnya mengering. Lalu goreng hingga matang (sy, tidak terlalu kering), angkat sisihkan.
1. Cuci bahan sambal, potong2 lalu goreng hingga matang. Kemudian ulek kasar saja
1. Tambahkan bumbu dasar cabe ijo, beri garam dan gula. Ulek hingga tercampur rata
1. Taruh ayam goreng diatas.sambal lalu penyet dengan ulekan dan pindahkan dalam wadah saji
1. Daan ayam penyet sambal ijo siap disajikan, ditambah perasan air jeruk nipis lebih enak




Wah ternyata cara buat *ayam penyet sambel ijo* yang mantab sederhana ini mudah sekali ya! Semua orang dapat memasaknya. Cara buat *ayam penyet sambel ijo* Sangat sesuai sekali untuk kamu yang baru mau belajar memasak ataupun untuk kamu yang sudah ahli memasak.

Apakah kamu ingin mulai mencoba buat resep *ayam penyet sambel ijo* enak sederhana ini? Kalau kamu ingin, mending kamu segera buruan siapkan peralatan dan bahannya, lantas buat deh Resep *ayam penyet sambel ijo* yang lezat dan tidak rumit ini. Sangat gampang kan. 

Oleh karena itu, daripada kita diam saja, yuk kita langsung saja sajikan resep *ayam penyet sambel ijo* ini. Dijamin anda gak akan menyesal sudah membuat resep *ayam penyet sambel ijo* enak tidak rumit ini! Selamat mencoba dengan resep *ayam penyet sambel ijo* lezat tidak rumit ini di rumah kalian sendiri,oke!.

