---
description: "Cara membuat Soto Ayam Santan Depok yang enak Untuk Jualan"
title: "Cara membuat Soto Ayam Santan Depok yang enak Untuk Jualan"
slug: 396-cara-membuat-soto-ayam-santan-depok-yang-enak-untuk-jualan
date: 2021-03-16T21:39:36.639Z
image: https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg
author: Ruth Rivera
ratingvalue: 4
reviewcount: 6
recipeingredient:
- "300 gr ayam filet"
- "300 gr kentang"
- "1 buah Belimbing Dewa manis"
- "800 ml air matang"
- "200 ml santan kental  instan"
- "  bumbu halus"
- "7 buah bawang merah"
- "5 siung bawang putih"
- "1 sdt ketumbar"
- "1/2 sdt jinten"
- "2 cm kencur"
- "  bumbu cemplung"
- "2 batang sere geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "2 cm lengkuas"
- "1 sdm peres garam"
- "  pelengkap"
- " Bawang merah goreng"
- " Sambel dari cabe rawit"
- " Emping"
- " Daun bawang"
recipeinstructions:
- "Siapkan bahan. Blender bumbu halus. Potong ayam dan kentang."
- "Tumis bumbu cemplung hingga harum. Kemudian masukan bumbu halus tumis hingga matang.           (lihat tips)"
- "Masukkan ayam aduk hingga ayam berubah warna."
- "Masukkan kentang, air dan garam."
- "Bila kentang sudah empuk maka masukkan santan. Setelah mendidih masukkan belimbing. Tes rasa dan tunggu mendidih matikan kompor."
- "Soto Ayam Santan Depok siap disajikan."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 264 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto Ayam Santan Depok](https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg)

Andai anda seorang ibu, menyediakan hidangan menggugah selera buat keluarga tercinta merupakan hal yang sangat menyenangkan bagi kita sendiri. Tugas seorang  wanita bukan cuma menjaga rumah saja, tapi kamu juga harus memastikan kebutuhan nutrisi tercukupi dan juga santapan yang disantap keluarga tercinta mesti sedap.

Di masa  sekarang, kalian sebenarnya dapat memesan olahan praktis tidak harus capek memasaknya dulu. Namun ada juga mereka yang memang ingin memberikan hidangan yang terenak bagi orang tercintanya. Lantaran, memasak sendiri jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan selera keluarga. 



Mungkinkah anda merupakan seorang penggemar soto ayam santan depok?. Tahukah kamu, soto ayam santan depok adalah sajian khas di Nusantara yang kini digemari oleh banyak orang di berbagai wilayah di Indonesia. Kalian bisa menghidangkan soto ayam santan depok olahan sendiri di rumahmu dan dapat dijadikan makanan kegemaranmu di akhir pekan.

Kamu jangan bingung jika kamu ingin menyantap soto ayam santan depok, karena soto ayam santan depok tidak sukar untuk ditemukan dan kita pun dapat mengolahnya sendiri di rumah. soto ayam santan depok boleh dibuat memalui bermacam cara. Sekarang telah banyak cara kekinian yang membuat soto ayam santan depok semakin enak.

Resep soto ayam santan depok pun mudah untuk dibuat, lho. Anda tidak perlu repot-repot untuk membeli soto ayam santan depok, lantaran Kalian dapat menyajikan ditempatmu. Untuk Kalian yang akan menyajikannya, berikut ini resep untuk menyajikan soto ayam santan depok yang mantab yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto Ayam Santan Depok:

1. Sediakan 300 gr ayam filet
1. Siapkan 300 gr kentang
1. Siapkan 1 buah Belimbing Dewa (manis)
1. Ambil 800 ml air matang
1. Sediakan 200 ml santan kental / instan
1. Gunakan  🧄🧄 bumbu halus
1. Ambil 7 buah bawang merah
1. Ambil 5 siung bawang putih
1. Siapkan 1 sdt ketumbar
1. Sediakan 1/2 sdt jinten
1. Ambil 2 cm kencur
1. Siapkan  🧄🧄 bumbu cemplung
1. Ambil 2 batang sere geprek
1. Gunakan 2 lembar daun salam
1. Ambil 2 lembar daun jeruk
1. Gunakan 2 cm lengkuas
1. Siapkan 1 sdm peres garam
1. Sediakan  🧄🧄 pelengkap
1. Ambil  Bawang merah goreng
1. Sediakan  Sambel dari cabe rawit
1. Gunakan  Emping
1. Siapkan  Daun bawang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Santan Depok:

1. Siapkan bahan. Blender bumbu halus. Potong ayam dan kentang.
1. Tumis bumbu cemplung hingga harum. Kemudian masukan bumbu halus tumis hingga matang. -           (lihat tips)
1. Masukkan ayam aduk hingga ayam berubah warna.
1. Masukkan kentang, air dan garam.
1. Bila kentang sudah empuk maka masukkan santan. Setelah mendidih masukkan belimbing. - Tes rasa dan tunggu mendidih matikan kompor.
1. Soto Ayam Santan Depok siap disajikan.




Wah ternyata cara buat soto ayam santan depok yang lezat tidak ribet ini mudah banget ya! Kamu semua mampu memasaknya. Cara buat soto ayam santan depok Sangat cocok sekali untuk kita yang sedang belajar memasak atau juga bagi anda yang telah ahli dalam memasak.

Apakah kamu tertarik mencoba membuat resep soto ayam santan depok lezat simple ini? Kalau mau, yuk kita segera buruan menyiapkan alat-alat dan bahan-bahannya, maka bikin deh Resep soto ayam santan depok yang mantab dan simple ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang anda berlama-lama, hayo kita langsung buat resep soto ayam santan depok ini. Dijamin anda tiidak akan nyesel sudah bikin resep soto ayam santan depok enak simple ini! Selamat berkreasi dengan resep soto ayam santan depok lezat simple ini di rumah masing-masing,ya!.

