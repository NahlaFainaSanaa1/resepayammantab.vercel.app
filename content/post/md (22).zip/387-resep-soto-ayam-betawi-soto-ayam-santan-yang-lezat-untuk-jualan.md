---
description: "Resep Soto ayam betawi | soto ayam santan yang lezat Untuk Jualan"
title: "Resep Soto ayam betawi | soto ayam santan yang lezat Untuk Jualan"
slug: 387-resep-soto-ayam-betawi-soto-ayam-santan-yang-lezat-untuk-jualan
date: 2021-06-03T09:50:23.100Z
image: https://img-global.cpcdn.com/recipes/ac15ef5cca44d8fd/680x482cq70/soto-ayam-betawi-soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ac15ef5cca44d8fd/680x482cq70/soto-ayam-betawi-soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ac15ef5cca44d8fd/680x482cq70/soto-ayam-betawi-soto-ayam-santan-foto-resep-utama.jpg
author: Lulu Thornton
ratingvalue: 3.5
reviewcount: 8
recipeingredient:
- "1/2 kg dada ayam"
- "4 buah kentang potong dadu"
- "4 buah tomat merah iris asal"
- " Beberapa batang daun seledri iris tipis"
- " Jeruk limau tambahan"
- " Bawang goreng tambahan"
- " Kerupuk melinjoemping tambahan"
- " Kecap manis tambahan"
- " Bumbu halus "
- "8 buah bawang merah"
- "5 buah bawang putih"
- "Seruas kunyit"
- "1 sendok teh lada"
- "Sedikit pala"
- "1 sendok teh ketumbar"
- "Seruas jahe"
- "5 buah kemiri"
- " Bumbu utuh "
- "1 batang serai geprek"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 batang kayu manis"
- "Seruas lengkuas geprek"
- "1 buah santan instan"
recipeinstructions:
- "Goreng potongan kentang, lalu sisihkan."
- "Tumis bumbu halus beserta serai, lengkuas, daun salam, daun jeruk. Tumis hingga harum."
- "Masukan air takaran 5 porsi, masukan ayam kedalam kuah dan masak hingga mendidih. Jika sudah mendidih, cemplungkan kayu manis lalu masak hingga ayam empuk."
- "Jika ayam sudah matang dan empuk, angkat lalu goreng ayam sebentar sampai kulit ayam kecoklatan."
- "Tambahkan santan, garam, kaldu bubuk, dan penyedap rasa kedalam kuah. Aduk hingga santan tercampur kuah dan masak hingga matang, lalu matikan kompor (cicip rasa terlebih dahulu)"
- "Siapkan mangkuk, sajikan ayam yg telah di suwir², kentang goreng, tomat, dan daun seledri kedalam mangkuk. Siram kuah kedalam mangkuk, lalu tambahkan perasan jeruk limau, bawang goreng dan kerupuk melinjo dan beri sedikit kecap manis. Soto ayam betawi siap disantap. (sambal bisa dibuat terpisah)"
categories:
- Resep
tags:
- soto
- ayam
- betawi

katakunci: soto ayam betawi 
nutrition: 291 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dessert

---


![Soto ayam betawi | soto ayam santan](https://img-global.cpcdn.com/recipes/ac15ef5cca44d8fd/680x482cq70/soto-ayam-betawi-soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyajikan santapan menggugah selera bagi keluarga tercinta merupakan hal yang menggembirakan bagi kita sendiri. Tanggung jawab seorang istri Tidak sekedar mengerjakan pekerjaan rumah saja, tapi kamu pun harus menyediakan keperluan gizi terpenuhi dan panganan yang disantap anak-anak mesti nikmat.

Di masa  saat ini, anda memang mampu memesan masakan praktis tanpa harus repot memasaknya lebih dulu. Tetapi ada juga lho orang yang selalu mau memberikan makanan yang terlezat bagi keluarganya. Karena, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan kesukaan orang tercinta. 



Apakah kamu salah satu penggemar soto ayam betawi | soto ayam santan?. Asal kamu tahu, soto ayam betawi | soto ayam santan adalah makanan khas di Indonesia yang sekarang disukai oleh kebanyakan orang di berbagai wilayah di Indonesia. Anda bisa membuat soto ayam betawi | soto ayam santan sendiri di rumahmu dan dapat dijadikan makanan kegemaranmu di akhir pekan.

Kamu tidak perlu bingung untuk memakan soto ayam betawi | soto ayam santan, lantaran soto ayam betawi | soto ayam santan sangat mudah untuk ditemukan dan anda pun boleh memasaknya sendiri di tempatmu. soto ayam betawi | soto ayam santan boleh dibuat memalui bermacam cara. Sekarang telah banyak banget cara kekinian yang membuat soto ayam betawi | soto ayam santan semakin enak.

Resep soto ayam betawi | soto ayam santan juga sangat mudah dihidangkan, lho. Kita jangan repot-repot untuk membeli soto ayam betawi | soto ayam santan, lantaran Kita dapat menyajikan sendiri di rumah. Untuk Kita yang mau membuatnya, berikut cara membuat soto ayam betawi | soto ayam santan yang enak yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Soto ayam betawi | soto ayam santan:

1. Ambil 1/2 kg dada ayam
1. Sediakan 4 buah kentang (potong dadu)
1. Sediakan 4 buah tomat merah (iris asal)
1. Gunakan  Beberapa batang daun seledri (iris tipis²)
1. Sediakan  Jeruk limau (tambahan)
1. Siapkan  Bawang goreng (tambahan)
1. Ambil  Kerupuk melinjo/emping (tambahan)
1. Sediakan  Kecap manis (tambahan)
1. Gunakan  Bumbu halus :
1. Siapkan 8 buah bawang merah
1. Siapkan 5 buah bawang putih
1. Sediakan Seruas kunyit
1. Siapkan 1 sendok teh lada
1. Gunakan Sedikit pala
1. Siapkan 1 sendok teh ketumbar
1. Siapkan Seruas jahe
1. Ambil 5 buah kemiri
1. Siapkan  Bumbu utuh :
1. Gunakan 1 batang serai (geprek)
1. Gunakan 3 lembar daun salam
1. Sediakan 5 lembar daun jeruk
1. Gunakan 1 batang kayu manis
1. Gunakan Seruas lengkuas (geprek)
1. Siapkan 1 buah santan instan




<!--inarticleads2-->

##### Cara membuat Soto ayam betawi | soto ayam santan:

1. Goreng potongan kentang, lalu sisihkan.
1. Tumis bumbu halus beserta serai, lengkuas, daun salam, daun jeruk. Tumis hingga harum.
1. Masukan air takaran 5 porsi, masukan ayam kedalam kuah dan masak hingga mendidih. Jika sudah mendidih, cemplungkan kayu manis lalu masak hingga ayam empuk.
1. Jika ayam sudah matang dan empuk, angkat lalu goreng ayam sebentar sampai kulit ayam kecoklatan.
1. Tambahkan santan, garam, kaldu bubuk, dan penyedap rasa kedalam kuah. Aduk hingga santan tercampur kuah dan masak hingga matang, lalu matikan kompor (cicip rasa terlebih dahulu)
1. Siapkan mangkuk, sajikan ayam yg telah di suwir², kentang goreng, tomat, dan daun seledri kedalam mangkuk. Siram kuah kedalam mangkuk, lalu tambahkan perasan jeruk limau, bawang goreng dan kerupuk melinjo dan beri sedikit kecap manis. Soto ayam betawi siap disantap. (sambal bisa dibuat terpisah)




Wah ternyata resep soto ayam betawi | soto ayam santan yang enak tidak rumit ini enteng sekali ya! Kamu semua dapat mencobanya. Resep soto ayam betawi | soto ayam santan Sangat cocok banget buat kalian yang baru mau belajar memasak atau juga bagi kamu yang sudah hebat dalam memasak.

Tertarik untuk mencoba buat resep soto ayam betawi | soto ayam santan lezat tidak ribet ini? Kalau kamu mau, yuk kita segera buruan siapkan peralatan dan bahan-bahannya, kemudian buat deh Resep soto ayam betawi | soto ayam santan yang enak dan simple ini. Betul-betul gampang kan. 

Jadi, daripada kalian diam saja, hayo langsung aja hidangkan resep soto ayam betawi | soto ayam santan ini. Pasti kamu tiidak akan nyesel sudah bikin resep soto ayam betawi | soto ayam santan mantab tidak rumit ini! Selamat berkreasi dengan resep soto ayam betawi | soto ayam santan lezat tidak rumit ini di rumah sendiri,ya!.

