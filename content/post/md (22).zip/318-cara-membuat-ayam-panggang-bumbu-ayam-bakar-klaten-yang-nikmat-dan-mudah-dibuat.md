---
description: "Cara membuat Ayam Panggang bumbu ayam bakar klaten yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Panggang bumbu ayam bakar klaten yang nikmat dan Mudah Dibuat"
slug: 318-cara-membuat-ayam-panggang-bumbu-ayam-bakar-klaten-yang-nikmat-dan-mudah-dibuat
date: 2021-06-02T02:54:07.546Z
image: https://img-global.cpcdn.com/recipes/fb90504ed07c49a0/680x482cq70/ayam-panggang-bumbu-ayam-bakar-klaten-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fb90504ed07c49a0/680x482cq70/ayam-panggang-bumbu-ayam-bakar-klaten-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fb90504ed07c49a0/680x482cq70/ayam-panggang-bumbu-ayam-bakar-klaten-foto-resep-utama.jpg
author: Adam Waters
ratingvalue: 3.1
reviewcount: 9
recipeingredient:
- "1 ekor 600700 gram ayam negri"
- "1 buah jeruk nipis"
- "1 sendok makan air asam jawa"
- "2 lembar daun salam"
- "2 cm lengkuas memarkan"
- "2 batang serai memarkan"
- "1/2 sendok makan garam"
- "1 sendok teh gula merah"
- "400 ml santan dari 1 bks santan kemasan 65 ml"
- "3 sendok makan minyak untuk menumis"
- " Bumbu halus"
- "15 butir bawang merah"
- "6 siung bawang putih"
- "1 buah cabe merah besar"
- "8 butir kemiri sangrai"
- "2 sendok teh ketumba"
- "2 cm kencur"
- "2 cm jahe"
recipeinstructions:
- "Ayam dibelah melebar utuh atau bisa dipotong2.  Lumuri ayam dengan air jeruk nipis. Diamkan 30 menit."
- "Tumis bumbu halus, daun salam, lengkuas, dan serai sampai harum."
- "Masukkan ayam. Aduk sampai berubah warna. Tambahkan garam, air asam jawa dan gula merah. Aduk rata. Tuang santan secara bertahap sambil diaduk perlahan. Masak sampai matang dan meresap."
- "Panggang ayam dalam oven di suhu 165C selama 30menit lalu balik dan panggang lagi selama 50 menit. Selama proses pemanggangan, oles ayam dg sisa bumbu yang dicampur dengan sedikit margarin"
- "Sajikan ayam dengan sambal dan lalapan. Matangnya sampai ke bagian dalam yaa..."
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Panggang bumbu ayam bakar klaten](https://img-global.cpcdn.com/recipes/fb90504ed07c49a0/680x482cq70/ayam-panggang-bumbu-ayam-bakar-klaten-foto-resep-utama.jpg)

Jika kalian seorang orang tua, menyajikan santapan menggugah selera untuk orang tercinta adalah hal yang memuaskan bagi anda sendiri. Kewajiban seorang istri Tidak hanya mengerjakan pekerjaan rumah saja, tetapi kamu pun harus memastikan kebutuhan gizi tercukupi dan juga panganan yang dikonsumsi orang tercinta harus nikmat.

Di masa  sekarang, kalian memang dapat mengorder masakan praktis meski tanpa harus repot membuatnya lebih dulu. Tetapi banyak juga lho orang yang selalu mau memberikan makanan yang terbaik bagi orang tercintanya. Pasalnya, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai makanan kesukaan keluarga. 



Apakah anda adalah salah satu penyuka ayam panggang bumbu ayam bakar klaten?. Asal kamu tahu, ayam panggang bumbu ayam bakar klaten merupakan makanan khas di Nusantara yang kini disenangi oleh setiap orang di hampir setiap wilayah di Indonesia. Anda bisa menyajikan ayam panggang bumbu ayam bakar klaten sendiri di rumahmu dan dapat dijadikan makanan kesenanganmu di hari liburmu.

Kamu jangan bingung jika kamu ingin menyantap ayam panggang bumbu ayam bakar klaten, karena ayam panggang bumbu ayam bakar klaten mudah untuk didapatkan dan kamu pun dapat menghidangkannya sendiri di rumah. ayam panggang bumbu ayam bakar klaten bisa diolah dengan berbagai cara. Saat ini telah banyak banget cara kekinian yang menjadikan ayam panggang bumbu ayam bakar klaten lebih lezat.

Resep ayam panggang bumbu ayam bakar klaten pun gampang dibikin, lho. Anda jangan repot-repot untuk membeli ayam panggang bumbu ayam bakar klaten, karena Kamu mampu membuatnya di rumah sendiri. Untuk Kita yang hendak menghidangkannya, inilah cara untuk menyajikan ayam panggang bumbu ayam bakar klaten yang enak yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Panggang bumbu ayam bakar klaten:

1. Ambil 1 ekor (600-700 gram) ayam negri
1. Gunakan 1 buah jeruk nipis
1. Gunakan 1 sendok makan air asam jawa
1. Sediakan 2 lembar daun salam
1. Siapkan 2 cm lengkuas, memarkan
1. Gunakan 2 batang serai, memarkan
1. Gunakan 1/2 sendok makan garam
1. Ambil 1 sendok teh gula merah
1. Ambil 400 ml santan, dari 1 bks santan kemasan 65 ml
1. Siapkan 3 sendok makan minyak untuk menumis
1. Gunakan  Bumbu halus:
1. Sediakan 15 butir bawang merah
1. Sediakan 6 siung bawang putih
1. Sediakan 1 buah cabe merah besar
1. Ambil 8 butir kemiri, sangrai
1. Ambil 2 sendok teh ketumba
1. Gunakan 2 cm kencur
1. Ambil 2 cm jahe




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Panggang bumbu ayam bakar klaten:

1. Ayam dibelah melebar utuh atau bisa dipotong2.  - Lumuri ayam dengan air jeruk nipis. Diamkan 30 menit.
1. Tumis bumbu halus, daun salam, lengkuas, dan serai sampai harum.
1. Masukkan ayam. Aduk sampai berubah warna. Tambahkan garam, air asam jawa dan gula merah. Aduk rata. Tuang santan secara bertahap sambil diaduk perlahan. Masak sampai matang dan meresap.
1. Panggang ayam dalam oven di suhu 165C selama 30menit lalu balik dan panggang lagi selama 50 menit. Selama proses pemanggangan, oles ayam dg sisa bumbu yang dicampur dengan sedikit margarin
1. Sajikan ayam dengan sambal dan lalapan. Matangnya sampai ke bagian dalam yaa...




Wah ternyata resep ayam panggang bumbu ayam bakar klaten yang nikamt sederhana ini gampang sekali ya! Kalian semua dapat mencobanya. Resep ayam panggang bumbu ayam bakar klaten Sesuai banget untuk kalian yang baru belajar memasak maupun untuk kamu yang telah ahli memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam panggang bumbu ayam bakar klaten nikmat sederhana ini? Kalau anda ingin, ayo kalian segera menyiapkan alat dan bahannya, setelah itu bikin deh Resep ayam panggang bumbu ayam bakar klaten yang nikmat dan tidak ribet ini. Benar-benar gampang kan. 

Jadi, daripada kalian diam saja, maka kita langsung hidangkan resep ayam panggang bumbu ayam bakar klaten ini. Dijamin kamu tak akan menyesal sudah buat resep ayam panggang bumbu ayam bakar klaten enak simple ini! Selamat berkreasi dengan resep ayam panggang bumbu ayam bakar klaten mantab simple ini di rumah kalian masing-masing,ya!.

