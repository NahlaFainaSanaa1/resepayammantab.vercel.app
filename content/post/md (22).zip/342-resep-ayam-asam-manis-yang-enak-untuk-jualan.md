---
description: "Resep Ayam asam manis yang enak Untuk Jualan"
title: "Resep Ayam asam manis yang enak Untuk Jualan"
slug: 342-resep-ayam-asam-manis-yang-enak-untuk-jualan
date: 2021-06-11T18:45:06.075Z
image: https://img-global.cpcdn.com/recipes/894cf634c830c2e3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/894cf634c830c2e3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/894cf634c830c2e3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Zachary Ferguson
ratingvalue: 4.1
reviewcount: 15
recipeingredient:
- " Marinasi"
- "500 g Ayam boneless and skinless"
- "1 sdt garam"
- "3 sdt gula"
- "3 sdt maizena"
- "2 sdt kecap asin"
- "2 sdt kaldu bubuk totole ayam atau jamur"
- "1 sdt saos tiram"
- " Tepung balur"
- "5 sdm terigu"
- "3 sdm maizena"
- " Bahan saos asam manis"
- "5 sdm saos tomat Indofood"
- "2 sdm saos sambal Indofood"
- "400 ml air"
- "1 sdm sagu aduh dengan sedikit air sekitar 12 tetes saja"
- "1 sdm kecap asin"
- "1 sdm saus tiram"
- "1 sdt garam"
- "2-3 sdm gula sesuai selera"
- "100 gr nanas potong2 dadu kotak"
- "1 sdt kaldu bubuk totole ayam atau jamur"
recipeinstructions:
- "Marinasi seluruh bahan. Diamkan selama 1-2 jam. Sisihkan"
- "Balurkan ayam ke dalam campuran terigu dan maizena. Goreng dengan minyak panas dan banyak hingga kecoklatan. Sisihkan"
- "Tuang air, saos tomat, saos sambal dan masak dengan api kecil. Aduk2, lalu masukkan garam gula totole dan saus tiram serta kecap asin. Aduk rata dan koreksi rasa. Terakhir masukkan sagu yg sdh dilarutkan"
- "Masukkan nanas. Masak sebentar lalu masukkan ayam. Aduk2 dan masak sebentar. Sajikan ❤❤❤"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 266 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam asam manis](https://img-global.cpcdn.com/recipes/894cf634c830c2e3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Jika kita seorang yang hobi memasak, menyediakan santapan menggugah selera bagi keluarga merupakan suatu hal yang membahagiakan bagi kita sendiri. Kewajiban seorang istri Tidak saja mengurus rumah saja, namun anda pun harus memastikan kebutuhan nutrisi tercukupi dan masakan yang dikonsumsi keluarga tercinta wajib enak.

Di era  saat ini, kamu sebenarnya dapat memesan panganan yang sudah jadi meski tanpa harus ribet mengolahnya dahulu. Namun banyak juga mereka yang selalu mau menyajikan yang terlezat bagi orang tercintanya. Lantaran, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai selera orang tercinta. 



Mungkinkah kamu salah satu penikmat ayam asam manis?. Tahukah kamu, ayam asam manis adalah hidangan khas di Indonesia yang sekarang disenangi oleh kebanyakan orang dari hampir setiap tempat di Indonesia. Anda dapat menghidangkan ayam asam manis sendiri di rumah dan dapat dijadikan santapan kesenanganmu di hari libur.

Kamu tak perlu bingung untuk menyantap ayam asam manis, lantaran ayam asam manis sangat mudah untuk didapatkan dan kalian pun boleh menghidangkannya sendiri di tempatmu. ayam asam manis bisa dimasak memalui beragam cara. Kini pun ada banyak sekali resep kekinian yang menjadikan ayam asam manis semakin lezat.

Resep ayam asam manis pun mudah untuk dibikin, lho. Anda jangan ribet-ribet untuk memesan ayam asam manis, tetapi Kita bisa menyajikan di rumahmu. Untuk Anda yang mau mencobanya, berikut ini resep membuat ayam asam manis yang mantab yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam asam manis:

1. Siapkan  Marinasi
1. Siapkan 500 g Ayam boneless and skinless
1. Gunakan 1 sdt garam
1. Gunakan 3 sdt gula
1. Siapkan 3 sdt maizena
1. Sediakan 2 sdt kecap asin
1. Ambil 2 sdt kaldu bubuk totole (ayam atau jamur)
1. Siapkan 1 sdt saos tiram
1. Siapkan  Tepung balur
1. Sediakan 5 sdm terigu
1. Ambil 3 sdm maizena
1. Siapkan  Bahan saos asam manis
1. Sediakan 5 sdm saos tomat Indofood
1. Gunakan 2 sdm saos sambal Indofood
1. Gunakan 400 ml air
1. Sediakan 1 sdm sagu (aduh dengan sedikit air, sekitar 1-2 tetes saja)
1. Gunakan 1 sdm kecap asin
1. Ambil 1 sdm saus tiram
1. Gunakan 1 sdt garam
1. Sediakan 2-3 sdm gula (sesuai selera)
1. Sediakan 100 gr nanas potong2 dadu kotak
1. Siapkan 1 sdt kaldu bubuk totole (ayam atau jamur)




<!--inarticleads2-->

##### Cara menyiapkan Ayam asam manis:

1. Marinasi seluruh bahan. Diamkan selama 1-2 jam. Sisihkan
1. Balurkan ayam ke dalam campuran terigu dan maizena. Goreng dengan minyak panas dan banyak hingga kecoklatan. Sisihkan
1. Tuang air, saos tomat, saos sambal dan masak dengan api kecil. Aduk2, lalu masukkan garam gula totole dan saus tiram serta kecap asin. Aduk rata dan koreksi rasa. Terakhir masukkan sagu yg sdh dilarutkan
1. Masukkan nanas. Masak sebentar lalu masukkan ayam. Aduk2 dan masak sebentar. Sajikan ❤❤❤




Ternyata resep ayam asam manis yang nikamt simple ini enteng sekali ya! Kamu semua bisa menghidangkannya. Resep ayam asam manis Sangat cocok sekali untuk kalian yang baru mau belajar memasak maupun juga untuk kamu yang sudah lihai memasak.

Tertarik untuk mencoba membuat resep ayam asam manis mantab tidak rumit ini? Kalau ingin, ayo kalian segera buruan siapin peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam asam manis yang nikmat dan tidak rumit ini. Sungguh mudah kan. 

Jadi, ketimbang kalian diam saja, maka kita langsung saja bikin resep ayam asam manis ini. Pasti kamu tiidak akan nyesel sudah membuat resep ayam asam manis enak simple ini! Selamat berkreasi dengan resep ayam asam manis lezat sederhana ini di rumah sendiri,ya!.

