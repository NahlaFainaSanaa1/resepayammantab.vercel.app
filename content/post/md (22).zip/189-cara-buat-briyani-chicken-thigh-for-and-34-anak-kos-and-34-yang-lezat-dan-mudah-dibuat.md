---
description: "Cara buat Briyani Chicken Thigh for &amp;#34;anak kos&amp;#34; yang lezat dan Mudah Dibuat"
title: "Cara buat Briyani Chicken Thigh for &amp;#34;anak kos&amp;#34; yang lezat dan Mudah Dibuat"
slug: 189-cara-buat-briyani-chicken-thigh-for-and-34-anak-kos-and-34-yang-lezat-dan-mudah-dibuat
date: 2021-02-07T08:02:44.275Z
image: https://img-global.cpcdn.com/recipes/7557895fc70e311b/680x482cq70/briyani-chicken-thigh-for-anak-kos-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7557895fc70e311b/680x482cq70/briyani-chicken-thigh-for-anak-kos-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7557895fc70e311b/680x482cq70/briyani-chicken-thigh-for-anak-kos-foto-resep-utama.jpg
author: Brian Curtis
ratingvalue: 4
reviewcount: 9
recipeingredient:
- "1/4 kg paha ayam"
- "1/2 buah bawang bombay"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "125 g beras basmati"
- "300 mL air"
- "2 buah cabai hijau besar"
- " Lada bubuk"
- " Garam"
- " Bumbu yamaanii rempahrempah khas"
- " Kismis"
- " Mentega"
- " Kecap manis"
recipeinstructions:
- "Rendam beras basmati sekitar 20-30 menit"
- "Sambil merendam, potong bawang merah dan bawang putih menjadi dadu-dadu kecil. Dan potong bawang bombay secara tipis."
- "Panaskan wajan, dan tumis bumbu-bumbu di atas hingga harum"
- "Setelah harum, tambahkan bumbu yaamanii. Tumis sekitar 2 menit, tambahkan sedikit air supaya tidak gosong"
- "Masukkan 300 mL air kemudian masukkan paha ayam yang sudah dipotong menjadi beberapa bagian dan telah ditaburi lada serta garam untuk memberikan rasa"
- "Ungkep atau tutup wajan sekitar 20 menit, hingga bumbu meresap. Atau tunggu hingga air surut."
- "Tiriskan ayam tsb. Lanjutkan dg menambah margarin secukupnya serta memasukkan beras basmati yang telah direndam. (Bisa menggunakan rice cooker) atau tetap menggunakan wajan. Apabila sudah hampir matang, masukkan cabai hijau besar yg sudah dibersihkan isinya (diseset sedikit) ke dalamnya. Tunggu sekitar 20 menit hingga matang."
- "Goreng ayam yg telah ditiriskan menggunakan margarin. Berin kecap manis supaya lebih berwarna."
- "Kedua nya siap disajikan. Dan taburkan kismis di atasnya."
categories:
- Resep
tags:
- briyani
- chicken
- thigh

katakunci: briyani chicken thigh 
nutrition: 112 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dinner

---


![Briyani Chicken Thigh for &#34;anak kos&#34;](https://img-global.cpcdn.com/recipes/7557895fc70e311b/680x482cq70/briyani-chicken-thigh-for-anak-kos-foto-resep-utama.jpg)

Apabila anda seorang istri, menyediakan olahan mantab bagi keluarga tercinta adalah suatu hal yang mengasyikan untuk kamu sendiri. Tanggung jawab seorang ibu Tidak sekedar menjaga rumah saja, tapi anda juga harus memastikan kebutuhan gizi terpenuhi dan juga masakan yang disantap keluarga tercinta harus lezat.

Di era  sekarang, kamu sebenarnya dapat membeli santapan instan meski tidak harus repot mengolahnya dahulu. Tetapi banyak juga orang yang memang ingin memberikan yang terenak untuk orang tercintanya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan sesuai dengan kesukaan keluarga tercinta. 



Apakah anda adalah salah satu penggemar briyani chicken thigh for &#34;anak kos&#34;?. Tahukah kamu, briyani chicken thigh for &#34;anak kos&#34; adalah sajian khas di Indonesia yang saat ini digemari oleh setiap orang dari hampir setiap wilayah di Nusantara. Kalian bisa memasak briyani chicken thigh for &#34;anak kos&#34; sendiri di rumah dan dapat dijadikan makanan kesukaanmu di akhir pekanmu.

Anda tidak usah bingung jika kamu ingin menyantap briyani chicken thigh for &#34;anak kos&#34;, karena briyani chicken thigh for &#34;anak kos&#34; gampang untuk dicari dan juga kita pun boleh memasaknya sendiri di tempatmu. briyani chicken thigh for &#34;anak kos&#34; bisa dimasak memalui berbagai cara. Kini ada banyak sekali resep modern yang membuat briyani chicken thigh for &#34;anak kos&#34; lebih nikmat.

Resep briyani chicken thigh for &#34;anak kos&#34; pun gampang untuk dibuat, lho. Anda jangan capek-capek untuk membeli briyani chicken thigh for &#34;anak kos&#34;, karena Kamu mampu membuatnya di rumah sendiri. Untuk Kita yang mau membuatnya, berikut ini resep membuat briyani chicken thigh for &#34;anak kos&#34; yang lezat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Briyani Chicken Thigh for &#34;anak kos&#34;:

1. Siapkan 1/4 kg paha ayam
1. Sediakan 1/2 buah bawang bombay
1. Sediakan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Siapkan 125 g beras basmati
1. Ambil 300 mL air
1. Ambil 2 buah cabai hijau besar
1. Ambil  Lada bubuk
1. Siapkan  Garam
1. Siapkan  Bumbu yamaanii (rempah-rempah khas)
1. Ambil  Kismis
1. Ambil  Mentega
1. Sediakan  Kecap manis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Briyani Chicken Thigh for &#34;anak kos&#34;:

1. Rendam beras basmati sekitar 20-30 menit
1. Sambil merendam, potong bawang merah dan bawang putih menjadi dadu-dadu kecil. Dan potong bawang bombay secara tipis.
1. Panaskan wajan, dan tumis bumbu-bumbu di atas hingga harum
1. Setelah harum, tambahkan bumbu yaamanii. Tumis sekitar 2 menit, tambahkan sedikit air supaya tidak gosong
1. Masukkan 300 mL air kemudian masukkan paha ayam yang sudah dipotong menjadi beberapa bagian dan telah ditaburi lada serta garam untuk memberikan rasa
1. Ungkep atau tutup wajan sekitar 20 menit, hingga bumbu meresap. Atau tunggu hingga air surut.
1. Tiriskan ayam tsb. Lanjutkan dg menambah margarin secukupnya serta memasukkan beras basmati yang telah direndam. (Bisa menggunakan rice cooker) atau tetap menggunakan wajan. Apabila sudah hampir matang, masukkan cabai hijau besar yg sudah dibersihkan isinya (diseset sedikit) ke dalamnya. Tunggu sekitar 20 menit hingga matang.
1. Goreng ayam yg telah ditiriskan menggunakan margarin. Berin kecap manis supaya lebih berwarna.
1. Kedua nya siap disajikan. Dan taburkan kismis di atasnya.




Ternyata resep briyani chicken thigh for &#34;anak kos&#34; yang lezat simple ini enteng banget ya! Anda Semua dapat memasaknya. Resep briyani chicken thigh for &#34;anak kos&#34; Sesuai banget untuk kita yang baru mau belajar memasak maupun untuk anda yang sudah jago dalam memasak.

Apakah kamu tertarik mulai mencoba bikin resep briyani chicken thigh for &#34;anak kos&#34; mantab simple ini? Kalau anda ingin, ayo kamu segera siapin alat dan bahan-bahannya, maka buat deh Resep briyani chicken thigh for &#34;anak kos&#34; yang nikmat dan tidak rumit ini. Sangat taidak sulit kan. 

Jadi, ketimbang kita diam saja, yuk kita langsung sajikan resep briyani chicken thigh for &#34;anak kos&#34; ini. Pasti kamu tak akan nyesel membuat resep briyani chicken thigh for &#34;anak kos&#34; lezat simple ini! Selamat mencoba dengan resep briyani chicken thigh for &#34;anak kos&#34; enak sederhana ini di tempat tinggal kalian masing-masing,oke!.

