---
description: "Bahan-bahan Opor ayam yang enak dan Mudah Dibuat"
title: "Bahan-bahan Opor ayam yang enak dan Mudah Dibuat"
slug: 77-bahan-bahan-opor-ayam-yang-enak-dan-mudah-dibuat
date: 2021-03-04T19:21:46.537Z
image: https://img-global.cpcdn.com/recipes/465ee2873e7fc5b9/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/465ee2873e7fc5b9/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/465ee2873e7fc5b9/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Helena Copeland
ratingvalue: 3.4
reviewcount: 4
recipeingredient:
- "1/2 ekor ayam"
- "2 Tahu putih"
- " Santan kara"
- " Daun salam"
- " Gula"
- " Garam"
- " Merica"
- " Bumbu penyedap"
- " Lengkuas geprek"
- " Serai geprek"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 buah kemiri"
- "1 ruas jahe"
- " Ketumbar"
- " Kunyit"
recipeinstructions:
- "Potong ayam jd beberapa baguan lalu cuci bersih ayam"
- "Didihkan air rebus ayam campur daun jeruk sebentar sampai empuk setelah masak jangan buang air rebusan ayamnya"
- "Tumis bumbu halus sama daun salam dan serai sampai harum lalu masukkan tahu dan ayam aduk” sebentar kemudian tuang air kaldu ayam tadi dan diamkan sampai mendidih"
- "Setelah mendidih masukkan gula,garam,merica,penyedap aduk” sebentar lalu masukkan santan kara"
- "Setelah semua bumbu sudah masuk aduk masak sebentar jangan lupa dicicipi biar pas rasanya, setelah masak angkat lalu sajikan taburi bawang goreng diatasnya agar rasanya semakin gurih"
- "Nb : Jika ingin masakan yg pedas bisa tinggal tambahin aja cabe dibumbu halusnya, sengaja gak pakai cabe biar anak bisa makan jug 😊😊"
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 165 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dessert

---


![Opor ayam](https://img-global.cpcdn.com/recipes/465ee2873e7fc5b9/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Selaku seorang orang tua, menyajikan masakan menggugah selera bagi keluarga tercinta adalah hal yang sangat menyenangkan bagi kamu sendiri. Tanggung jawab seorang  wanita Tidak saja mengatur rumah saja, namun kamu pun wajib menyediakan keperluan gizi terpenuhi dan olahan yang dikonsumsi orang tercinta mesti nikmat.

Di masa  sekarang, anda sebenarnya mampu mengorder santapan instan meski tidak harus ribet membuatnya lebih dulu. Namun ada juga lho orang yang memang mau menghidangkan yang terlezat untuk orang yang dicintainya. Pasalnya, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai selera famili. 



Apakah anda adalah salah satu penikmat opor ayam?. Asal kamu tahu, opor ayam adalah sajian khas di Indonesia yang kini digemari oleh banyak orang dari hampir setiap tempat di Nusantara. Kita bisa membuat opor ayam kreasi sendiri di rumahmu dan dapat dijadikan santapan kesenanganmu di hari liburmu.

Kalian jangan bingung untuk mendapatkan opor ayam, karena opor ayam tidak sukar untuk didapatkan dan kalian pun bisa memasaknya sendiri di rumah. opor ayam bisa dimasak lewat beragam cara. Kini pun sudah banyak sekali resep modern yang menjadikan opor ayam semakin nikmat.

Resep opor ayam pun mudah sekali dibikin, lho. Kita tidak usah ribet-ribet untuk memesan opor ayam, sebab Anda mampu membuatnya ditempatmu. Untuk Kita yang ingin menyajikannya, dibawah ini merupakan cara membuat opor ayam yang mantab yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Opor ayam:

1. Gunakan 1/2 ekor ayam
1. Ambil 2 Tahu putih
1. Siapkan  Santan kara
1. Gunakan  Daun salam
1. Siapkan  Gula
1. Siapkan  Garam
1. Sediakan  Merica
1. Gunakan  Bumbu penyedap
1. Siapkan  Lengkuas geprek
1. Ambil  Serai geprek
1. Siapkan  Bumbu halus
1. Sediakan 5 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Gunakan 2 buah kemiri
1. Ambil 1 ruas jahe
1. Sediakan  Ketumbar
1. Gunakan  Kunyit




<!--inarticleads2-->

##### Langkah-langkah membuat Opor ayam:

1. Potong ayam jd beberapa baguan lalu cuci bersih ayam
1. Didihkan air rebus ayam campur daun jeruk sebentar sampai empuk setelah masak jangan buang air rebusan ayamnya
1. Tumis bumbu halus sama daun salam dan serai sampai harum lalu masukkan tahu dan ayam aduk” sebentar kemudian tuang air kaldu ayam tadi dan diamkan sampai mendidih
1. Setelah mendidih masukkan gula,garam,merica,penyedap aduk” sebentar lalu masukkan santan kara
1. Setelah semua bumbu sudah masuk aduk masak sebentar jangan lupa dicicipi biar pas rasanya, setelah masak angkat lalu sajikan taburi bawang goreng diatasnya agar rasanya semakin gurih
1. Nb : Jika ingin masakan yg pedas bisa tinggal tambahin aja cabe dibumbu halusnya, sengaja gak pakai cabe biar anak bisa makan jug 😊😊




Wah ternyata cara membuat opor ayam yang mantab simple ini enteng banget ya! Kamu semua dapat mencobanya. Cara Membuat opor ayam Sangat sesuai sekali untuk anda yang sedang belajar memasak ataupun bagi kalian yang telah jago dalam memasak.

Apakah kamu mau mulai mencoba buat resep opor ayam enak tidak ribet ini? Kalau anda mau, ayo kalian segera siapin alat-alat dan bahannya, setelah itu bikin deh Resep opor ayam yang mantab dan simple ini. Betul-betul mudah kan. 

Maka dari itu, daripada kita diam saja, yuk kita langsung saja hidangkan resep opor ayam ini. Pasti kamu tak akan menyesal sudah bikin resep opor ayam nikmat tidak rumit ini! Selamat mencoba dengan resep opor ayam nikmat simple ini di rumah sendiri,oke!.

