---
description: "Bahan-bahan Ayam lodho yang enak dan Mudah Dibuat"
title: "Bahan-bahan Ayam lodho yang enak dan Mudah Dibuat"
slug: 208-bahan-bahan-ayam-lodho-yang-enak-dan-mudah-dibuat
date: 2021-04-13T21:18:24.981Z
image: https://img-global.cpcdn.com/recipes/485d75d573110fec/680x482cq70/ayam-lodho-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/485d75d573110fec/680x482cq70/ayam-lodho-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/485d75d573110fec/680x482cq70/ayam-lodho-foto-resep-utama.jpg
author: Jonathan Hammond
ratingvalue: 3.3
reviewcount: 15
recipeingredient:
- "1 kg ayam kampung potong sesuai selerame kecil2"
- "500 ml Air kl mau byk kuah tambahkan air sesuai selera"
- "1-2 bungkus santan instan"
- " Bahan yg di haluskan"
- "8 siung bawang merah"
- "7 siung bawang putih"
- "2 ruas jari jahe"
- "2 bh kencur"
- "1 ruas jari kunyitme bubuk"
- "1 sdm ketumbar me bubuk"
- "1 sdt merica bubukme bubuk"
- "1 sdt jinten bubukme bubuk"
- "4 buah Kemiri"
- "2 buah cabe merah besar"
- "10 buah cabe rawitsesuai selera"
- " Bahan yg d blender kasardi tumbuk"
- "1 btg sere"
- "1 ruas jari laos"
- "2 lembar daun jeruk"
- "1 lembar daun salam"
- " Bahan tambahan"
- "1 sdm garam"
- "50 gr gula merah"
- "Secukupnya penyedap rasa"
- "1 sdm air asam jawa"
recipeinstructions:
- "Bersihkan ayam lumuri dengan garam kemudian panggang ayam sampe setengah matang"
- "Tumis bumbu yg sdh d haluskan tambahkan bahan yg sdh d blender kasar masak sampe harum"
- "Masukan ayam aduk sebentar sampe ayam tercampur semua ke bumbu kemudian masukan air dan bahan tambahan(takaran bisa d tambahkan menurut selera)"
- "Masak dengan api kecil sampe ayam empuk setelah empuk masukan santan didihkan,setelah mendidih matikan api.ayam lodho siap d hidangkan"
categories:
- Resep
tags:
- ayam
- lodho

katakunci: ayam lodho 
nutrition: 195 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam lodho](https://img-global.cpcdn.com/recipes/485d75d573110fec/680x482cq70/ayam-lodho-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan masakan mantab pada keluarga tercinta merupakan suatu hal yang menyenangkan untuk kamu sendiri. Tanggung jawab seorang ibu Tidak sekadar mengatur rumah saja, tetapi kamu pun wajib menyediakan keperluan nutrisi tercukupi dan santapan yang dimakan orang tercinta mesti sedap.

Di era  saat ini, kita sebenarnya dapat mengorder olahan siap saji meski tanpa harus capek mengolahnya terlebih dahulu. Tetapi ada juga orang yang selalu ingin memberikan yang terenak untuk keluarganya. Pasalnya, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan sesuai dengan makanan kesukaan keluarga tercinta. 



Mungkinkah kamu salah satu penyuka ayam lodho?. Asal kamu tahu, ayam lodho adalah sajian khas di Nusantara yang kini digemari oleh setiap orang dari berbagai daerah di Indonesia. Kamu bisa menghidangkan ayam lodho sendiri di rumahmu dan pasti jadi santapan favoritmu di hari libur.

Kalian tidak usah bingung untuk mendapatkan ayam lodho, lantaran ayam lodho mudah untuk ditemukan dan kalian pun boleh menghidangkannya sendiri di tempatmu. ayam lodho boleh dimasak memalui beragam cara. Kini pun telah banyak resep modern yang menjadikan ayam lodho semakin lebih lezat.

Resep ayam lodho juga sangat mudah dibikin, lho. Kamu tidak usah ribet-ribet untuk memesan ayam lodho, karena Kamu mampu menyiapkan di rumah sendiri. Bagi Kalian yang hendak membuatnya, berikut ini resep untuk membuat ayam lodho yang enak yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam lodho:

1. Gunakan 1 kg ayam kampung potong sesuai selera(me kecil2)
1. Gunakan 500 ml Air kl mau byk kuah tambahkan air sesuai selera
1. Siapkan 1-2 bungkus santan instan
1. Gunakan  Bahan yg di haluskan
1. Gunakan 8 siung bawang merah
1. Gunakan 7 siung bawang putih
1. Sediakan 2 ruas jari jahe
1. Gunakan 2 bh kencur
1. Siapkan 1 ruas jari kunyit(me bubuk)
1. Siapkan 1 sdm ketumbar (me bubuk)
1. Gunakan 1 sdt merica bubuk(me bubuk)
1. Siapkan 1 sdt jinten bubuk(me bubuk)
1. Ambil 4 buah Kemiri
1. Ambil 2 buah cabe merah besar
1. Siapkan 10 buah cabe rawit(sesuai selera)
1. Ambil  Bahan yg d blender kasar/di tumbuk
1. Gunakan 1 btg sere,
1. Sediakan 1 ruas jari laos
1. Sediakan 2 lembar daun jeruk
1. Gunakan 1 lembar daun salam
1. Gunakan  Bahan tambahan
1. Sediakan 1 sdm garam
1. Ambil 50 gr gula merah
1. Gunakan Secukupnya penyedap rasa
1. Siapkan 1 sdm air asam jawa




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam lodho:

1. Bersihkan ayam lumuri dengan garam kemudian panggang ayam sampe setengah matang
1. Tumis bumbu yg sdh d haluskan tambahkan bahan yg sdh d blender kasar masak sampe harum
1. Masukan ayam aduk sebentar sampe ayam tercampur semua ke bumbu kemudian masukan air dan bahan tambahan(takaran bisa d tambahkan menurut selera)
1. Masak dengan api kecil sampe ayam empuk setelah empuk masukan santan didihkan,setelah mendidih matikan api.ayam lodho siap d hidangkan




Ternyata cara buat ayam lodho yang nikamt tidak ribet ini mudah sekali ya! Anda Semua bisa memasaknya. Cara Membuat ayam lodho Sesuai banget buat kamu yang baru mau belajar memasak maupun bagi kamu yang telah jago memasak.

Tertarik untuk mulai mencoba bikin resep ayam lodho mantab tidak ribet ini? Kalau tertarik, yuk kita segera buruan siapin peralatan dan bahan-bahannya, lalu bikin deh Resep ayam lodho yang lezat dan simple ini. Sungguh mudah kan. 

Jadi, ketimbang kamu diam saja, ayo kita langsung buat resep ayam lodho ini. Pasti anda gak akan menyesal sudah membuat resep ayam lodho lezat simple ini! Selamat mencoba dengan resep ayam lodho enak tidak rumit ini di rumah masing-masing,oke!.

