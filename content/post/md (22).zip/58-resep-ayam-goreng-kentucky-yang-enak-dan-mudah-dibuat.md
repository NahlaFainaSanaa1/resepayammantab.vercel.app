---
description: "Resep Ayam Goreng Kentucky yang enak dan Mudah Dibuat"
title: "Resep Ayam Goreng Kentucky yang enak dan Mudah Dibuat"
slug: 58-resep-ayam-goreng-kentucky-yang-enak-dan-mudah-dibuat
date: 2021-04-07T23:01:37.810Z
image: https://img-global.cpcdn.com/recipes/7b818b9e010c4ad8/680x482cq70/ayam-goreng-kentucky-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7b818b9e010c4ad8/680x482cq70/ayam-goreng-kentucky-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7b818b9e010c4ad8/680x482cq70/ayam-goreng-kentucky-foto-resep-utama.jpg
author: Corey Lyons
ratingvalue: 4.8
reviewcount: 4
recipeingredient:
- "6 potong ayam cuci bersih"
- "1 butir telur Uk kecil"
- "125 ml air es"
- "1/2 sdt soda kue"
- " Bambu Halus"
- "4 siung bawang putih"
- "1 ruas kunyit"
- "1/2 ruas jahe"
- "1/2 sdt kaldu bubuk"
- "1/2 sdt kaldu jamur"
- "1/2 sdt garam"
- "1/2 sdt ketumbar bubuk"
- " Tepung pelapis"
- "225 gr tepung terigu"
- "75 gr tepung maizena"
- "1/2 sdt kaldu jamur"
recipeinstructions:
- "Haluskan bawang putih, jahe dan kunyit, lalu masukan bumbu ke dalam wadah beirisi ayam, beri bumbu halus lainnya,Aduk rata, Marinasi ayam selama 2 jam di kulkas.   Keluarkan ayam dari kulkas, beri kocokan telur"
- "Aduk rata ayam dengan kocokan telur, ambil 2.5 sdm bahan tepung pelapis kemudian beri soda kue dan air es. Aduk hingga tidak ada yang menggumpal. Masukan 2 potong ayam ke dalam adonan nasah"
- "Kemudian masukkan ke adonan kering. Lalu celupkan lagi ke adonan basah sebentar. Kemudian masukkan ke adonan kering lagim tutupi seluruh permukaan ayam dengan tepung sambil dicubit - cubit. Lakukan pada kedua sisinya. Kibas kibaskan tepung sebelum masuk penggorengan"
- "Panaskan minyak agak banyak dan goreng ayam hingga matang keemasan"
- "Goreng dengan api kecil, jika sudah matang angkat dan tiriskan"
- "Ayam Goreng Kentucky siap disajikan"
categories:
- Resep
tags:
- ayam
- goreng
- kentucky

katakunci: ayam goreng kentucky 
nutrition: 179 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Kentucky](https://img-global.cpcdn.com/recipes/7b818b9e010c4ad8/680x482cq70/ayam-goreng-kentucky-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan panganan mantab untuk orang tercinta merupakan hal yang menyenangkan untuk anda sendiri. Tanggung jawab seorang  wanita Tidak sekedar menjaga rumah saja, tetapi anda juga harus memastikan keperluan gizi tercukupi dan juga olahan yang disantap anak-anak harus lezat.

Di waktu  saat ini, kalian memang bisa mengorder olahan instan walaupun tanpa harus capek memasaknya dahulu. Tetapi banyak juga lho orang yang memang mau memberikan yang terbaik untuk orang yang dicintainya. Lantaran, memasak yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan famili. 



Mungkinkah anda seorang penyuka ayam goreng kentucky?. Asal kamu tahu, ayam goreng kentucky merupakan hidangan khas di Nusantara yang sekarang disukai oleh setiap orang dari berbagai wilayah di Indonesia. Anda dapat membuat ayam goreng kentucky olahan sendiri di rumah dan boleh dijadikan hidangan kegemaranmu di hari libur.

Kamu jangan bingung untuk memakan ayam goreng kentucky, sebab ayam goreng kentucky sangat mudah untuk ditemukan dan anda pun boleh membuatnya sendiri di rumah. ayam goreng kentucky bisa diolah dengan beraneka cara. Saat ini ada banyak resep kekinian yang menjadikan ayam goreng kentucky lebih enak.

Resep ayam goreng kentucky pun gampang sekali untuk dibikin, lho. Kalian tidak usah repot-repot untuk membeli ayam goreng kentucky, tetapi Anda bisa menghidangkan di rumah sendiri. Bagi Kamu yang mau membuatnya, berikut ini resep untuk membuat ayam goreng kentucky yang lezat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Goreng Kentucky:

1. Sediakan 6 potong ayam (cuci bersih)
1. Gunakan 1 butir telur Uk kecil
1. Siapkan 125 ml air es
1. Gunakan 1/2 sdt soda kue
1. Ambil  Bambu Halus
1. Ambil 4 siung bawang putih
1. Siapkan 1 ruas kunyit
1. Sediakan 1/2 ruas jahe
1. Siapkan 1/2 sdt kaldu bubuk
1. Sediakan 1/2 sdt kaldu jamur
1. Ambil 1/2 sdt garam
1. Siapkan 1/2 sdt ketumbar bubuk
1. Ambil  Tepung pelapis
1. Gunakan 225 gr tepung terigu
1. Sediakan 75 gr tepung maizena
1. Sediakan 1/2 sdt kaldu jamur




<!--inarticleads2-->

##### Cara menyiapkan Ayam Goreng Kentucky:

1. Haluskan bawang putih, jahe dan kunyit, lalu masukan bumbu ke dalam wadah beirisi ayam, beri bumbu halus lainnya,Aduk rata, Marinasi ayam selama 2 jam di kulkas.  -  - Keluarkan ayam dari kulkas, beri kocokan telur
1. Aduk rata ayam dengan kocokan telur, ambil 2.5 sdm bahan tepung pelapis kemudian beri soda kue dan air es. Aduk hingga tidak ada yang menggumpal. Masukan 2 potong ayam ke dalam adonan nasah
1. Kemudian masukkan ke adonan kering. Lalu celupkan lagi ke adonan basah sebentar. Kemudian masukkan ke adonan kering lagim tutupi seluruh permukaan ayam dengan tepung sambil dicubit - cubit. Lakukan pada kedua sisinya. Kibas kibaskan tepung sebelum masuk penggorengan
1. Panaskan minyak agak banyak dan goreng ayam hingga matang keemasan
1. Goreng dengan api kecil, jika sudah matang angkat dan tiriskan
1. Ayam Goreng Kentucky siap disajikan




Ternyata cara buat ayam goreng kentucky yang lezat tidak rumit ini gampang sekali ya! Kalian semua bisa mencobanya. Cara Membuat ayam goreng kentucky Sangat sesuai banget buat kita yang baru akan belajar memasak ataupun juga bagi kamu yang sudah lihai memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam goreng kentucky enak tidak ribet ini? Kalau ingin, ayo kamu segera siapkan peralatan dan bahannya, lantas buat deh Resep ayam goreng kentucky yang lezat dan sederhana ini. Sungguh mudah kan. 

Maka dari itu, ketimbang kamu berfikir lama-lama, hayo kita langsung bikin resep ayam goreng kentucky ini. Dijamin kalian gak akan menyesal membuat resep ayam goreng kentucky lezat tidak ribet ini! Selamat berkreasi dengan resep ayam goreng kentucky lezat sederhana ini di tempat tinggal masing-masing,oke!.

