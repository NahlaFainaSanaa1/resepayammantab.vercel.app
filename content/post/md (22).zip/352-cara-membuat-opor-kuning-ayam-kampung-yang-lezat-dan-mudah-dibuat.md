---
description: "Cara membuat Opor Kuning Ayam Kampung yang lezat dan Mudah Dibuat"
title: "Cara membuat Opor Kuning Ayam Kampung yang lezat dan Mudah Dibuat"
slug: 352-cara-membuat-opor-kuning-ayam-kampung-yang-lezat-dan-mudah-dibuat
date: 2021-06-10T07:14:29.055Z
image: https://img-global.cpcdn.com/recipes/223536e38da844bf/680x482cq70/opor-kuning-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/223536e38da844bf/680x482cq70/opor-kuning-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/223536e38da844bf/680x482cq70/opor-kuning-ayam-kampung-foto-resep-utama.jpg
author: Amelia Leonard
ratingvalue: 3.7
reviewcount: 6
recipeingredient:
- "1 ekor ayam kampung"
- "250 ml santan kental"
- "750 ml santan sedang"
- " Bumbu"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "4 butir kemiri"
- "1 sdt ketumbar"
- "1/2 sdt jintan"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "2 batang serei"
- "2 lbr daun salam"
- "3 lbr daun jeruk"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya lada bubuk"
- "1 genggam kelapa parut Sangrai hingga kecokelatan lalu ulek halus optional"
- " Pelengkap optional"
- " Telur rebus"
- " Tahu goreng"
recipeinstructions:
- "Potong ayam sesuai selera. Rendam dalam air, beri cuka dan garam. Diamkan selama 15 menit lalu cuci bersih."
- "Haluskan duo bawang, kemiri, ketumbar, dan jinten. Tumis hingga matang lalu masukkan daun salam, serei, daun jeruk, jahe, dan lengkuas."
- "Masukkan ayam. Aduk-aduk hingga terbaluri bumbu. Masukkan santan sedang. Saya pindahkan dulu ke panci yang tutupnya rapat agar ayam empuk. Masak di atas api kecil dengan panci tertutup selama 1 jam atau hingga benar-benar empuk. Atau bisa juga dipresto selama 30 menit."
- "Saya pindahkan lagi ke wajan setelah empuk. Masukkan santan kental dan kelapa parut sangrai. Masak hingga mendidih. Jangan lupa diaduk biar santan tidak pecah. Beri garam, gula, dan lada bubuk. Koreksi rasa."
- "Tambahkan telur rebus dan bawang goreng sebagai pelengkap. Taburi bawang goreng. Siap disajikan."
categories:
- Resep
tags:
- opor
- kuning
- ayam

katakunci: opor kuning ayam 
nutrition: 105 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dinner

---


![Opor Kuning Ayam Kampung](https://img-global.cpcdn.com/recipes/223536e38da844bf/680x482cq70/opor-kuning-ayam-kampung-foto-resep-utama.jpg)

Jika kalian seorang orang tua, menyediakan hidangan lezat buat keluarga tercinta adalah hal yang sangat menyenangkan untuk kita sendiri. Tanggung jawab seorang  wanita bukan sekadar mengerjakan pekerjaan rumah saja, namun kamu juga wajib memastikan keperluan gizi terpenuhi dan juga panganan yang dikonsumsi keluarga tercinta wajib mantab.

Di waktu  saat ini, kamu sebenarnya dapat mengorder olahan siap saji tanpa harus capek membuatnya dahulu. Tapi ada juga mereka yang memang mau memberikan hidangan yang terlezat bagi keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan famili. 



Mungkinkah anda adalah seorang penikmat opor kuning ayam kampung?. Tahukah kamu, opor kuning ayam kampung adalah hidangan khas di Indonesia yang saat ini digemari oleh orang-orang di berbagai wilayah di Nusantara. Kamu dapat menyajikan opor kuning ayam kampung hasil sendiri di rumah dan boleh dijadikan santapan kegemaranmu di akhir pekanmu.

Kalian tak perlu bingung jika kamu ingin mendapatkan opor kuning ayam kampung, sebab opor kuning ayam kampung tidak sukar untuk dicari dan juga anda pun boleh membuatnya sendiri di rumah. opor kuning ayam kampung bisa dibuat memalui berbagai cara. Saat ini telah banyak sekali cara kekinian yang menjadikan opor kuning ayam kampung semakin lebih lezat.

Resep opor kuning ayam kampung juga gampang dibikin, lho. Kalian jangan ribet-ribet untuk memesan opor kuning ayam kampung, sebab Kamu dapat menyiapkan sendiri di rumah. Bagi Kamu yang akan mencobanya, di bawah ini adalah cara untuk menyajikan opor kuning ayam kampung yang enak yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Opor Kuning Ayam Kampung:

1. Ambil 1 ekor ayam kampung
1. Sediakan 250 ml santan kental
1. Gunakan 750 ml santan sedang
1. Ambil  Bumbu:
1. Ambil 5 siung bawang merah
1. Ambil 3 siung bawang putih
1. Gunakan 4 butir kemiri
1. Ambil 1 sdt ketumbar
1. Siapkan 1/2 sdt jintan
1. Gunakan 1 ruas kunyit
1. Ambil 1 ruas jahe
1. Ambil 1 ruas lengkuas
1. Sediakan 2 batang serei
1. Siapkan 2 lbr daun salam
1. Siapkan 3 lbr daun jeruk
1. Sediakan Secukupnya garam
1. Gunakan Secukupnya gula pasir
1. Gunakan Secukupnya lada bubuk
1. Sediakan 1 genggam kelapa parut. Sangrai hingga kecokelatan lalu ulek halus (optional)
1. Sediakan  Pelengkap (optional):
1. Ambil  Telur rebus
1. Ambil  Tahu goreng




<!--inarticleads2-->

##### Cara membuat Opor Kuning Ayam Kampung:

1. Potong ayam sesuai selera. Rendam dalam air, beri cuka dan garam. Diamkan selama 15 menit lalu cuci bersih.
1. Haluskan duo bawang, kemiri, ketumbar, dan jinten. Tumis hingga matang lalu masukkan daun salam, serei, daun jeruk, jahe, dan lengkuas.
1. Masukkan ayam. Aduk-aduk hingga terbaluri bumbu. Masukkan santan sedang. Saya pindahkan dulu ke panci yang tutupnya rapat agar ayam empuk. Masak di atas api kecil dengan panci tertutup selama 1 jam atau hingga benar-benar empuk. Atau bisa juga dipresto selama 30 menit.
1. Saya pindahkan lagi ke wajan setelah empuk. Masukkan santan kental dan kelapa parut sangrai. Masak hingga mendidih. Jangan lupa diaduk biar santan tidak pecah. Beri garam, gula, dan lada bubuk. Koreksi rasa.
1. Tambahkan telur rebus dan bawang goreng sebagai pelengkap. Taburi bawang goreng. Siap disajikan.




Wah ternyata resep opor kuning ayam kampung yang lezat sederhana ini enteng banget ya! Kamu semua mampu membuatnya. Cara Membuat opor kuning ayam kampung Sangat sesuai sekali untuk kalian yang baru akan belajar memasak maupun bagi kamu yang sudah hebat memasak.

Apakah kamu tertarik mulai mencoba membuat resep opor kuning ayam kampung mantab simple ini? Kalau anda ingin, ayo kalian segera buruan siapin peralatan dan bahan-bahannya, kemudian bikin deh Resep opor kuning ayam kampung yang lezat dan tidak ribet ini. Sangat taidak sulit kan. 

Maka, ketimbang kita diam saja, yuk langsung aja sajikan resep opor kuning ayam kampung ini. Dijamin kalian tak akan nyesel sudah bikin resep opor kuning ayam kampung mantab sederhana ini! Selamat mencoba dengan resep opor kuning ayam kampung mantab simple ini di rumah kalian sendiri,oke!.

