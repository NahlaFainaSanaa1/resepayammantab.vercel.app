---
description: "Cara membuat Ayam Goreng Kremes yang nikmat Untuk Jualan"
title: "Cara membuat Ayam Goreng Kremes yang nikmat Untuk Jualan"
slug: 39-cara-membuat-ayam-goreng-kremes-yang-nikmat-untuk-jualan
date: 2021-05-01T14:15:23.954Z
image: https://img-global.cpcdn.com/recipes/4fb81f11ba22ac2d/680x482cq70/ayam-goreng-kremes-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4fb81f11ba22ac2d/680x482cq70/ayam-goreng-kremes-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4fb81f11ba22ac2d/680x482cq70/ayam-goreng-kremes-foto-resep-utama.jpg
author: Travis Francis
ratingvalue: 3.2
reviewcount: 6
recipeingredient:
- "500 gr ayam bagian paha potong jadi beberapa bagian marinasi dengan air jeruk nipis dan secukupnya garam Diamkan 15 menit Bilas kembali"
- "250 gr kelapa parut yang tua"
- "350 ml air"
- "2 lembar daun salam"
- "1 batang serai digeprek"
- "Secukupnya garam dan royco ayam"
- "Secukupnya minyak goreng"
- " Bumbu Halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "3 buah kemiri"
- "1 ruas kunyit"
- "1/2 sdm ketumbar"
- " Bahan Kremes"
- "300 ml air rebusan ayam"
- "125 gr tepung tapioka boleh pakai tepung sagu tani"
- "40 gr tepung beras"
- "1 butir telur"
- "1/2 sdt baking powder"
recipeinstructions:
- "Siapkan bahan yang akan digunakan"
- "Tuangkan semua air ke kelapa parut, lalu remas-remas agar santan kelapa keluar, lalu saring dan peras. Hasil santan yang diperoleh kurang lebih 450 ml. Kemudian haluskan bumbu menggunakan blender dengan menambahkan sedikit air."
- "Siapkan wajan, masukkan bumbu halus, daun salam, serai dan santan. Lalu tambahkan secukupnya garam dan royco, masak hingga mendidih sambil terus diaduk agar santan tidak pecah. Koreksi rasa."
- "Masukkan ayam, masak hingga ayam matang dan bumbu meresap dengan api kecil. Sisakan air rebusan ayam kira-kira 300 ml. Sesekali diaduk-aduk dalam proses memasaknya"
- "Angkat/keluarkan ayam, lalu saring air sisa rebusan ayam tadi."
- "Siapkan bahan yang akan dilakukan untuk membuat kremes. Lalu campurkan semua bahan kecuali Baking Powder. Aduk-aduk sebentar lalu saring adonan kremes agar tidak ada lagi tepung yang menggerindil/bulat-bulat kecil"
- "Panaskan secukupnya minyak goreng. Celupkan ayam ke dalam adonan kremes, balurkan hingga mereta. Kemudian goreng ayam hingga berwarna golden brown. Angkat dan tiriskan"
- "Cara membuat kremes: Tambahkan baking powder pada sisa adonan kremes. Aduk hingga tercampur rata. (Note: Baking Powder dimasukkan sesaat sebelum adonan kremes digoreng)"
- "Panaskan minyak goreng (pastikan minyak goreng sudah benar-benar panas). Lalu ambil adonan dengan tangan, kucurkan adonan dengan bantuan jari tangan dengan gerakan berputar di atas wajan. Ketika mulai kokoh balik adonan, terus goreng sampai kecokelatan, angkat dan tiriskan."
- "Sajikan ayam goreng dengan kremesan dan sambal. Enjoy... 😊"
categories:
- Resep
tags:
- ayam
- goreng
- kremes

katakunci: ayam goreng kremes 
nutrition: 180 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Goreng Kremes](https://img-global.cpcdn.com/recipes/4fb81f11ba22ac2d/680x482cq70/ayam-goreng-kremes-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan santapan mantab bagi famili merupakan suatu hal yang menyenangkan bagi kamu sendiri. Tanggung jawab seorang istri Tidak sekedar mengurus rumah saja, tapi anda juga wajib menyediakan keperluan nutrisi tercukupi dan olahan yang dimakan keluarga tercinta mesti lezat.

Di era  saat ini, kamu sebenarnya mampu mengorder hidangan siap saji walaupun tanpa harus susah memasaknya lebih dulu. Namun banyak juga lho orang yang selalu mau menghidangkan yang terlezat bagi orang yang dicintainya. Karena, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan selera keluarga. 



Mungkinkah anda merupakan seorang penikmat ayam goreng kremes?. Tahukah kamu, ayam goreng kremes merupakan hidangan khas di Nusantara yang saat ini digemari oleh orang-orang dari hampir setiap wilayah di Nusantara. Anda bisa menyajikan ayam goreng kremes kreasi sendiri di rumah dan dapat dijadikan makanan kegemaranmu di akhir pekanmu.

Kita tidak perlu bingung jika kamu ingin mendapatkan ayam goreng kremes, karena ayam goreng kremes tidak sukar untuk dicari dan kamu pun dapat mengolahnya sendiri di tempatmu. ayam goreng kremes boleh dimasak lewat beragam cara. Sekarang sudah banyak banget cara modern yang membuat ayam goreng kremes semakin mantap.

Resep ayam goreng kremes pun mudah sekali untuk dibuat, lho. Kalian tidak usah capek-capek untuk membeli ayam goreng kremes, lantaran Anda mampu menghidangkan sendiri di rumah. Untuk Kita yang mau membuatnya, inilah cara membuat ayam goreng kremes yang enak yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Goreng Kremes:

1. Gunakan 500 gr ayam bagian paha, potong jadi beberapa bagian, marinasi dengan air jeruk nipis dan secukupnya garam. Diamkan 15 menit. Bilas kembali
1. Ambil 250 gr kelapa parut yang tua
1. Sediakan 350 ml air
1. Sediakan 2 lembar daun salam
1. Gunakan 1 batang serai, digeprek
1. Ambil Secukupnya garam dan royco ayam
1. Ambil Secukupnya minyak goreng
1. Gunakan  Bumbu Halus:
1. Gunakan 6 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Sediakan 3 buah kemiri
1. Gunakan 1 ruas kunyit
1. Gunakan 1/2 sdm ketumbar
1. Ambil  Bahan Kremes:
1. Siapkan 300 ml air rebusan ayam
1. Siapkan 125 gr tepung tapioka (boleh pakai tepung sagu tani)
1. Siapkan 40 gr tepung beras
1. Ambil 1 butir telur
1. Sediakan 1/2 sdt baking powder




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Kremes:

1. Siapkan bahan yang akan digunakan
1. Tuangkan semua air ke kelapa parut, lalu remas-remas agar santan kelapa keluar, lalu saring dan peras. Hasil santan yang diperoleh kurang lebih 450 ml. Kemudian haluskan bumbu menggunakan blender dengan menambahkan sedikit air.
1. Siapkan wajan, masukkan bumbu halus, daun salam, serai dan santan. Lalu tambahkan secukupnya garam dan royco, masak hingga mendidih sambil terus diaduk agar santan tidak pecah. Koreksi rasa.
1. Masukkan ayam, masak hingga ayam matang dan bumbu meresap dengan api kecil. Sisakan air rebusan ayam kira-kira 300 ml. Sesekali diaduk-aduk dalam proses memasaknya
1. Angkat/keluarkan ayam, lalu saring air sisa rebusan ayam tadi.
1. Siapkan bahan yang akan dilakukan untuk membuat kremes. Lalu campurkan semua bahan kecuali Baking Powder. Aduk-aduk sebentar lalu saring adonan kremes agar tidak ada lagi tepung yang menggerindil/bulat-bulat kecil
1. Panaskan secukupnya minyak goreng. Celupkan ayam ke dalam adonan kremes, balurkan hingga mereta. Kemudian goreng ayam hingga berwarna golden brown. Angkat dan tiriskan
1. Cara membuat kremes: - Tambahkan baking powder pada sisa adonan kremes. Aduk hingga tercampur rata. (Note: Baking Powder dimasukkan sesaat sebelum adonan kremes digoreng)
1. Panaskan minyak goreng (pastikan minyak goreng sudah benar-benar panas). Lalu ambil adonan dengan tangan, kucurkan adonan dengan bantuan jari tangan dengan gerakan berputar di atas wajan. Ketika mulai kokoh balik adonan, terus goreng sampai kecokelatan, angkat dan tiriskan.
1. Sajikan ayam goreng dengan kremesan dan sambal. Enjoy... 😊




Ternyata cara buat ayam goreng kremes yang lezat tidak rumit ini gampang banget ya! Anda Semua bisa memasaknya. Resep ayam goreng kremes Sangat cocok banget untuk anda yang sedang belajar memasak maupun untuk kalian yang telah lihai memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam goreng kremes lezat tidak ribet ini? Kalau kamu tertarik, ayo kalian segera buruan siapin alat-alat dan bahannya, kemudian bikin deh Resep ayam goreng kremes yang nikmat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Jadi, daripada kalian diam saja, hayo kita langsung bikin resep ayam goreng kremes ini. Pasti kalian tiidak akan nyesel membuat resep ayam goreng kremes enak simple ini! Selamat mencoba dengan resep ayam goreng kremes lezat simple ini di tempat tinggal sendiri,oke!.

