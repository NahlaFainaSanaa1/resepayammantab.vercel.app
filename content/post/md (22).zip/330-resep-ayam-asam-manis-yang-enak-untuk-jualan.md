---
description: "Resep Ayam Asam Manis yang enak Untuk Jualan"
title: "Resep Ayam Asam Manis yang enak Untuk Jualan"
slug: 330-resep-ayam-asam-manis-yang-enak-untuk-jualan
date: 2021-01-16T11:54:47.202Z
image: https://img-global.cpcdn.com/recipes/80e6ad2114afe65c/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/80e6ad2114afe65c/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/80e6ad2114afe65c/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Danny Huff
ratingvalue: 3.9
reviewcount: 4
recipeingredient:
- "1 Kg Ayam potong 10 bagian"
- "1 Buah Bawang Bombay iris tipis"
- "4 Siung Bawang Putih cincang kasar"
- "6 Buah Tomat Kecil belah 2"
- "2 Ruas Jahe geprek"
- "135 Ml Saus Tomat"
- "2 Sdm Kecap Manis"
- "1 Sdm Saus Tiram"
- "1 Sdt Kaldu Ayam Bubuk"
- "1/2 Sdt Garam"
- "1 Sdt Gula Pasir"
- "secukupnya Minyak goreng"
recipeinstructions:
- "Goreng ayam hingga kecoklatan, lalu angkat dan tiriskan."
- "Tumis bawang putih dan jahe hingga harum lalu masukkan bawang bombay masak hingga layu. Lalu, masukkan ayam yang sudah digoreng dan tambahkan air. Masak sampai ayam matang sempurna dan kuah agak menyusut."
- "Lalu masukkan saus tomat, saus tiram, kecap, kaldu ayam, potongan tomat, garam dan gula pasir. Masak hingga mengental. Cek rasa."
- "Jika dirasa sudah pas, tata dalam piring saji. Selamat mencoba."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 236 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/80e6ad2114afe65c/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Andai kita seorang orang tua, menyajikan masakan lezat pada keluarga tercinta adalah suatu hal yang sangat menyenangkan bagi anda sendiri. Kewajiban seorang ibu Tidak cuma mengerjakan pekerjaan rumah saja, tetapi anda juga harus memastikan keperluan nutrisi terpenuhi dan juga hidangan yang disantap keluarga tercinta wajib lezat.

Di zaman  saat ini, kamu sebenarnya dapat memesan panganan siap saji meski tidak harus susah memasaknya terlebih dahulu. Namun ada juga lho orang yang memang mau memberikan makanan yang terenak untuk orang yang dicintainya. Lantaran, memasak sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan famili. 



Apakah kamu seorang penikmat ayam asam manis?. Tahukah kamu, ayam asam manis adalah makanan khas di Indonesia yang saat ini disukai oleh banyak orang dari hampir setiap daerah di Indonesia. Kita dapat menghidangkan ayam asam manis sendiri di rumah dan pasti jadi santapan kesukaanmu di hari libur.

Kalian tidak perlu bingung untuk memakan ayam asam manis, sebab ayam asam manis gampang untuk didapatkan dan kita pun bisa memasaknya sendiri di tempatmu. ayam asam manis dapat dimasak dengan beragam cara. Kini telah banyak sekali cara modern yang membuat ayam asam manis semakin lebih mantap.

Resep ayam asam manis pun gampang sekali untuk dibikin, lho. Kalian tidak usah repot-repot untuk membeli ayam asam manis, lantaran Kamu bisa membuatnya di rumahmu. Untuk Anda yang hendak membuatnya, berikut cara untuk membuat ayam asam manis yang enak yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Asam Manis:

1. Gunakan 1 Kg Ayam, potong 10 bagian
1. Ambil 1 Buah Bawang Bombay, iris tipis
1. Gunakan 4 Siung Bawang Putih, cincang kasar
1. Ambil 6 Buah Tomat Kecil, belah 2
1. Ambil 2 Ruas Jahe, geprek
1. Ambil 135 Ml Saus Tomat
1. Siapkan 2 Sdm Kecap Manis
1. Siapkan 1 Sdm Saus Tiram
1. Siapkan 1 Sdt Kaldu Ayam Bubuk
1. Ambil 1/2 Sdt Garam
1. Gunakan 1 Sdt Gula Pasir
1. Gunakan secukupnya Minyak goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Asam Manis:

1. Goreng ayam hingga kecoklatan, lalu angkat dan tiriskan.
1. Tumis bawang putih dan jahe hingga harum lalu masukkan bawang bombay masak hingga layu. Lalu, masukkan ayam yang sudah digoreng dan tambahkan air. Masak sampai ayam matang sempurna dan kuah agak menyusut.
1. Lalu masukkan saus tomat, saus tiram, kecap, kaldu ayam, potongan tomat, garam dan gula pasir. Masak hingga mengental. Cek rasa.
1. Jika dirasa sudah pas, tata dalam piring saji. Selamat mencoba.




Wah ternyata resep ayam asam manis yang nikamt simple ini enteng sekali ya! Kalian semua dapat memasaknya. Cara Membuat ayam asam manis Sesuai banget buat kalian yang baru belajar memasak maupun bagi kamu yang sudah pandai memasak.

Apakah kamu tertarik mencoba buat resep ayam asam manis mantab simple ini? Kalau kalian ingin, yuk kita segera buruan siapkan alat-alat dan bahannya, lantas bikin deh Resep ayam asam manis yang lezat dan simple ini. Sangat mudah kan. 

Oleh karena itu, ketimbang kita berlama-lama, maka kita langsung hidangkan resep ayam asam manis ini. Dijamin anda tiidak akan menyesal sudah buat resep ayam asam manis nikmat tidak ribet ini! Selamat berkreasi dengan resep ayam asam manis nikmat simple ini di rumah masing-masing,ya!.

