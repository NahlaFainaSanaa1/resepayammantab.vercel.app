---
description: "Cara membuat Ayam Asam Manis yang nikmat Untuk Jualan"
title: "Cara membuat Ayam Asam Manis yang nikmat Untuk Jualan"
slug: 329-cara-membuat-ayam-asam-manis-yang-nikmat-untuk-jualan
date: 2021-01-10T13:03:17.448Z
image: https://img-global.cpcdn.com/recipes/028ad0e965599664/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/028ad0e965599664/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/028ad0e965599664/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Emma Reid
ratingvalue: 3.9
reviewcount: 15
recipeingredient:
- " Ayam crispy "
- "1 kg ayam fillet"
- "10 sdm penuh tepung serbaguna"
- "6 sdm tepung terigu"
- "4 butir telur"
- " Saos asam manis "
- "2 sdm mentega"
- "1/2 buah nanas iris tipis"
- "2 siung bawang putih iris tipis"
- "2 siung bawang merah iris tipis"
- "1 bawang bombay iris tipis"
- "2 batang daun bawang iris bawang"
- "1 sdt kecap manis"
- "4 sdm saos extra pedas"
- "1 sdm tepung maizena"
- "Secukupnya kaldu bubuk"
- "Secukupnya garam  gula pasir"
recipeinstructions:
- "Siapkan 3 wadah untuk  1) telur kocok 2) 5 sdm tepung serbaguna campur 3 sdm tepung terigu 3) sama seperti no.2 untuk baluran setelah ayam dimasukkan ke telur"
- "Baluri ayam fillet pada adonan tepung wadah ke 2 kemudian masukkan ke telur terakhir balurkan lagi ke tepung pada wadah ke 3."
- "Goreng ayam tepung pada minyak panas pada api kecil sampai kekuningan kemudian tiriskan."
- "Siapkan wajan bersih, panaskan mentega hingga cair kemudian masukkan irisan bawang putih, bawang merah, bawang bombay dan nanas hingga harum."
- "Kemudian masukkan tepung maizena yang sudah diaduk bersama air di gelas secukupnya."
- "Masukkan kecap manis, sambal extra pedas, garam, gula pasir, dan kaldu bubuk secukupnya."
- "Aduk dan icip rasa kemudian masukkan ayam krispy dan daun bawang."
- "Aduk sebentar dan sajikan."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 214 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/028ad0e965599664/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Selaku seorang wanita, menyajikan olahan nikmat bagi famili adalah hal yang menyenangkan untuk anda sendiri. Tugas seorang istri bukan sekadar menangani rumah saja, tapi kamu pun harus memastikan keperluan gizi terpenuhi dan santapan yang dimakan orang tercinta wajib lezat.

Di waktu  saat ini, kita memang dapat memesan masakan praktis meski tidak harus susah memasaknya lebih dulu. Tetapi banyak juga lho mereka yang memang mau memberikan makanan yang terenak untuk orang tercintanya. Sebab, memasak yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan famili. 



Apakah anda adalah seorang penggemar ayam asam manis?. Tahukah kamu, ayam asam manis merupakan sajian khas di Indonesia yang saat ini digemari oleh setiap orang di hampir setiap tempat di Indonesia. Kamu dapat memasak ayam asam manis sendiri di rumahmu dan dapat dijadikan hidangan favorit di hari liburmu.

Kita tidak perlu bingung jika kamu ingin mendapatkan ayam asam manis, lantaran ayam asam manis mudah untuk dicari dan kalian pun bisa menghidangkannya sendiri di tempatmu. ayam asam manis bisa diolah lewat berbagai cara. Kini pun ada banyak sekali resep modern yang membuat ayam asam manis semakin lezat.

Resep ayam asam manis juga mudah sekali dibuat, lho. Kalian tidak perlu capek-capek untuk membeli ayam asam manis, sebab Anda bisa menghidangkan di rumah sendiri. Untuk Kita yang mau mencobanya, dibawah ini merupakan resep menyajikan ayam asam manis yang enak yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Asam Manis:

1. Ambil  Ayam crispy :
1. Siapkan 1 kg ayam fillet
1. Gunakan 10 sdm penuh tepung serbaguna
1. Gunakan 6 sdm tepung terigu
1. Sediakan 4 butir telur
1. Gunakan  Saos asam manis :
1. Sediakan 2 sdm mentega
1. Sediakan 1/2 buah nanas iris tipis
1. Sediakan 2 siung bawang putih iris tipis
1. Gunakan 2 siung bawang merah iris tipis
1. Sediakan 1 bawang bombay iris tipis
1. Siapkan 2 batang daun bawang iris bawang
1. Siapkan 1 sdt kecap manis
1. Gunakan 4 sdm saos extra pedas
1. Siapkan 1 sdm tepung maizena
1. Gunakan Secukupnya kaldu bubuk
1. Ambil Secukupnya garam + gula pasir




<!--inarticleads2-->

##### Cara membuat Ayam Asam Manis:

1. Siapkan 3 wadah untuk  - 1) telur kocok - 2) 5 sdm tepung serbaguna campur 3 sdm tepung terigu - 3) sama seperti no.2 untuk baluran setelah ayam dimasukkan ke telur
1. Baluri ayam fillet pada adonan tepung wadah ke 2 kemudian masukkan ke telur terakhir balurkan lagi ke tepung pada wadah ke 3.
1. Goreng ayam tepung pada minyak panas pada api kecil sampai kekuningan kemudian tiriskan.
1. Siapkan wajan bersih, panaskan mentega hingga cair kemudian masukkan irisan bawang putih, bawang merah, bawang bombay dan nanas hingga harum.
1. Kemudian masukkan tepung maizena yang sudah diaduk bersama air di gelas secukupnya.
1. Masukkan kecap manis, sambal extra pedas, garam, gula pasir, dan kaldu bubuk secukupnya.
1. Aduk dan icip rasa kemudian masukkan ayam krispy dan daun bawang.
1. Aduk sebentar dan sajikan.




Wah ternyata cara membuat ayam asam manis yang mantab tidak ribet ini mudah sekali ya! Anda Semua bisa menghidangkannya. Cara buat ayam asam manis Cocok banget buat anda yang baru belajar memasak maupun untuk kalian yang telah jago dalam memasak.

Tertarik untuk mencoba bikin resep ayam asam manis nikmat tidak rumit ini? Kalau kamu ingin, mending kamu segera siapkan alat dan bahan-bahannya, lantas bikin deh Resep ayam asam manis yang mantab dan tidak rumit ini. Sungguh gampang kan. 

Jadi, daripada anda berfikir lama-lama, yuk kita langsung sajikan resep ayam asam manis ini. Pasti kamu tak akan menyesal sudah membuat resep ayam asam manis enak simple ini! Selamat mencoba dengan resep ayam asam manis lezat tidak rumit ini di tempat tinggal sendiri,oke!.

