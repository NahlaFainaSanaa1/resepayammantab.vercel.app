---
description: "Cara buat Soto Ayam Santan yang enak dan Mudah Dibuat"
title: "Cara buat Soto Ayam Santan yang enak dan Mudah Dibuat"
slug: 393-cara-buat-soto-ayam-santan-yang-enak-dan-mudah-dibuat
date: 2021-05-17T22:36:22.574Z
image: https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Luke Manning
ratingvalue: 3.5
reviewcount: 13
recipeingredient:
- "500 gr dada ayam"
- "1500 ml santan"
- "3 lbr daun salam"
- "3 lbr daub jeruk"
- "2 batang seraimemarkan"
- "2 ruas jari lengkuasmemarkan"
- "2 batang daun bawang potong 2 cm bagian putih kuskip"
- "Sesuai selera gulagaram dan kaldu bubuk"
- " Bumbu halus"
- "6 buah bawang merah"
- "3 siung bawang putih"
- "3 btr kemiri sangarai"
- "1 ruas jari jahe"
- "1/2 sdt ketumba"
- "1/2 sdt merica butir"
- " Pelengkap"
- "1 buah tomat besarpotong kotak kecil"
- "Sesuai selera irisan daun bawang kuskip seledri"
- "200 gr kol iris"
- "1 buah jeruk nipis"
- "Sesuai selera pelngkap lainya sambalbawang goreng dan emping"
recipeinstructions:
- "Potong dada ayam,cuci bersih lumuri dengan air jeruk nipis.Diamkan beberapa saat dan bilas.Goreng hingga agak kecoklatan saja.Kemudian suir suir."
- ""
- "Haluskan bahan bumbu halus.Tumis bumbu halus,daun salam,daun jeruk,serai dan lengkuas.Tumis hingga bumbu matang,beri sedikit air.Matikan api."
- "Masak santan hingga mendidih.Masukkan tumisan bumbu.Aduk selalu agar santan tidak pecah."
- "Masukkan ayam suir,beri bumbu gula,garam dan kaldu bubuk sesuai selera.Masak hingga bumbu pas dilidah."
- "Seduh irisan kol dengan air panas,tiriskan.Tata kol dimangkuk siram dengan kuah soto dan ayam.Beri pelengkap sesuai selera."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 210 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Dinner

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Jika kalian seorang yang hobi masak, menyajikan hidangan menggugah selera kepada orang tercinta merupakan suatu hal yang menyenangkan bagi anda sendiri. Kewajiban seorang  wanita bukan hanya mengerjakan pekerjaan rumah saja, tetapi kamu pun harus menyediakan keperluan nutrisi tercukupi dan panganan yang dikonsumsi keluarga tercinta mesti mantab.

Di waktu  sekarang, kalian sebenarnya bisa memesan hidangan jadi meski tidak harus repot membuatnya terlebih dahulu. Tetapi banyak juga mereka yang selalu mau menghidangkan yang terlezat bagi keluarganya. Sebab, memasak yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan orang tercinta. 



Apakah anda merupakan seorang penyuka soto ayam santan?. Tahukah kamu, soto ayam santan merupakan makanan khas di Indonesia yang saat ini disukai oleh setiap orang dari berbagai daerah di Nusantara. Kamu bisa memasak soto ayam santan sendiri di rumah dan dapat dijadikan camilan favorit di akhir pekanmu.

Kalian tidak usah bingung untuk memakan soto ayam santan, sebab soto ayam santan tidak sukar untuk ditemukan dan kita pun dapat menghidangkannya sendiri di rumah. soto ayam santan boleh dimasak lewat beraneka cara. Kini pun ada banyak sekali cara kekinian yang membuat soto ayam santan semakin mantap.

Resep soto ayam santan juga sangat mudah untuk dibuat, lho. Anda tidak usah repot-repot untuk membeli soto ayam santan, lantaran Anda mampu menyajikan sendiri di rumah. Untuk Kalian yang ingin menyajikannya, berikut cara untuk membuat soto ayam santan yang mantab yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Santan:

1. Sediakan 500 gr dada ayam
1. Ambil 1500 ml santan
1. Siapkan 3 lbr daun salam
1. Siapkan 3 lbr daub jeruk
1. Siapkan 2 batang serai,memarkan
1. Sediakan 2 ruas jari lengkuas,memarkan
1. Siapkan 2 batang daun bawang potong 2 cm bagian putih (kuskip)
1. Gunakan Sesuai selera gula,garam dan kaldu bubuk
1. Sediakan  Bumbu halus
1. Gunakan 6 buah bawang merah
1. Siapkan 3 siung bawang putih
1. Ambil 3 btr kemiri sangarai
1. Sediakan 1 ruas jari jahe
1. Siapkan 1/2 sdt ketumba
1. Siapkan 1/2 sdt merica butir
1. Ambil  Pelengkap
1. Sediakan 1 buah tomat besar,potong kotak kecil
1. Gunakan Sesuai selera irisan daun bawang (kuskip) seledri
1. Sediakan 200 gr kol iris
1. Siapkan 1 buah jeruk nipis
1. Ambil Sesuai selera pelngkap lainya sambal,bawang goreng dan emping




<!--inarticleads2-->

##### Cara membuat Soto Ayam Santan:

1. Potong dada ayam,cuci bersih lumuri dengan air jeruk nipis.Diamkan beberapa saat dan bilas.Goreng hingga agak kecoklatan saja.Kemudian suir suir.
1. 
1. Haluskan bahan bumbu halus.Tumis bumbu halus,daun salam,daun jeruk,serai dan lengkuas.Tumis hingga bumbu matang,beri sedikit air.Matikan api.
1. Masak santan hingga mendidih.Masukkan tumisan bumbu.Aduk selalu agar santan tidak pecah.
1. Masukkan ayam suir,beri bumbu gula,garam dan kaldu bubuk sesuai selera.Masak hingga bumbu pas dilidah.
1. Seduh irisan kol dengan air panas,tiriskan.Tata kol dimangkuk siram dengan kuah soto dan ayam.Beri pelengkap sesuai selera.




Ternyata cara buat soto ayam santan yang mantab tidak ribet ini gampang sekali ya! Anda Semua dapat memasaknya. Resep soto ayam santan Sesuai sekali untuk anda yang baru belajar memasak ataupun juga untuk kalian yang telah lihai dalam memasak.

Apakah kamu ingin mulai mencoba membuat resep soto ayam santan nikmat sederhana ini? Kalau ingin, yuk kita segera buruan siapkan alat dan bahannya, lantas bikin deh Resep soto ayam santan yang nikmat dan tidak ribet ini. Betul-betul mudah kan. 

Jadi, daripada kalian berlama-lama, ayo kita langsung saja buat resep soto ayam santan ini. Pasti kalian tak akan menyesal bikin resep soto ayam santan lezat simple ini! Selamat berkreasi dengan resep soto ayam santan lezat tidak rumit ini di rumah kalian sendiri,ya!.

