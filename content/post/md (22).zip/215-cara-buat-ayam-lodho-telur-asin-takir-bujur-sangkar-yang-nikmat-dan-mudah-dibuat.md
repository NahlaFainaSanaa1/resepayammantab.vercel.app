---
description: "Cara buat Ayam Lodho Telur Asin / Takir Bujur Sangkar yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam Lodho Telur Asin / Takir Bujur Sangkar yang nikmat dan Mudah Dibuat"
slug: 215-cara-buat-ayam-lodho-telur-asin-takir-bujur-sangkar-yang-nikmat-dan-mudah-dibuat
date: 2021-03-18T13:05:33.275Z
image: https://img-global.cpcdn.com/recipes/37486043bac5c49b/680x482cq70/ayam-lodho-telur-asin-takir-bujur-sangkar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/37486043bac5c49b/680x482cq70/ayam-lodho-telur-asin-takir-bujur-sangkar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/37486043bac5c49b/680x482cq70/ayam-lodho-telur-asin-takir-bujur-sangkar-foto-resep-utama.jpg
author: Cody McGuire
ratingvalue: 4.2
reviewcount: 7
recipeingredient:
- " Bahan Utama "
- "1 ekor ayam 750 gram potong kecil jd 20 potong"
- "4 butir telor asin misal tdk ada bisa diganti telor ayam biasa"
- "1 sachet santan bubuk"
- "1 ikat kemangi boleh lebih banyak lebih sedap"
- "1 lembar daun pandan"
- "8 lembar daun pisang utk membungkus"
- "15 buah cabe rawit utuh"
- " Bumbu yang dihaluskan "
- "10 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas sere"
- "1/2 kelingking kencur"
- "1 jempol jahe"
- "1 jempol lengkuas"
- "1 telunjuk kunyit"
- "5 lembar daun jeruk"
- "1 lembar daun salam"
- "1 sdt ketumbar bubuk"
- "3/4 sdt jinten bubuk"
- "1/2 sdt merica bubuk"
- "1 sdt gula pasir"
- "1 sdt garam"
- "1 sachet kaldu bubuk"
recipeinstructions:
- "Potong kecil² ayam krmuan cuci bersih sisik"
- "Rebus air hingga mendidih, dan masukan ayam dan dau pandan, rebus 15 menit"
- "Siapkan wajan anti lengket, bakar ayam sampai kecoklatan"
- "Siapkan bumbu, haluskan dan tumis hingga matang, masukkan ayam, tambahkan air kaldu rebusan ayam tadi"
- "Tambahkan santan bubuk, masak hingga kaldu hingga menyusut, kemudian matikan api, tunggu hingga ayam dingin"
- "Siapkan daun pisang buat takir seperti ini, atau bila tdk bisa anda bisa membungkusnya seperti bungkus botok atau Tum, kemudian panaskan kukusan"
- "Masuk kan kemangi dan cabe rawit utuh ke dalam adonan ayam"
- "Pisahkan antara putih telor dan kuning telor"
- "Tuang putih telor kedalam adonan ayam, aduk rata dan test rasanya"
- "Ambil beberapa sendok adonan ayam dan putih telur, isi takir sesuai selera, tambahkan kuning telor dan bumbu diatas nya"
- "Kukus kurang lebih, 30 menit"
- "Angkat dan sajikan bersama nasi putih hangat, bila Ayam Lodho Telor Asin ini dikosumsi sendiri, takir daun pisang tdk perlu diganti, namun bila akan dijual atau dibuat hantaran, sebaiknya ganti dengan takir yg daunnya masih segar, agar tampilan nya lebih menarik, selamat mencoba"
categories:
- Resep
tags:
- ayam
- lodho
- telur

katakunci: ayam lodho telur 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Lodho Telur Asin / Takir Bujur Sangkar](https://img-global.cpcdn.com/recipes/37486043bac5c49b/680x482cq70/ayam-lodho-telur-asin-takir-bujur-sangkar-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan santapan nikmat untuk orang tercinta adalah hal yang memuaskan untuk kamu sendiri. Tanggung jawab seorang  wanita Tidak saja mengatur rumah saja, namun kamu pun harus menyediakan kebutuhan gizi terpenuhi dan olahan yang dikonsumsi orang tercinta wajib nikmat.

Di era  saat ini, anda memang mampu membeli hidangan jadi tidak harus repot memasaknya dulu. Tetapi ada juga orang yang memang mau menyajikan yang terlezat bagi orang tercintanya. Karena, memasak yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai makanan kesukaan orang tercinta. 



Apakah anda merupakan salah satu penikmat ayam lodho telur asin / takir bujur sangkar?. Tahukah kamu, ayam lodho telur asin / takir bujur sangkar merupakan hidangan khas di Nusantara yang kini disenangi oleh orang-orang dari hampir setiap tempat di Indonesia. Kalian bisa menghidangkan ayam lodho telur asin / takir bujur sangkar hasil sendiri di rumah dan boleh dijadikan makanan favoritmu di hari liburmu.

Kita jangan bingung jika kamu ingin memakan ayam lodho telur asin / takir bujur sangkar, karena ayam lodho telur asin / takir bujur sangkar sangat mudah untuk didapatkan dan kita pun dapat mengolahnya sendiri di tempatmu. ayam lodho telur asin / takir bujur sangkar dapat dimasak memalui beraneka cara. Kini pun ada banyak sekali resep kekinian yang membuat ayam lodho telur asin / takir bujur sangkar lebih mantap.

Resep ayam lodho telur asin / takir bujur sangkar pun mudah sekali dibikin, lho. Anda jangan ribet-ribet untuk membeli ayam lodho telur asin / takir bujur sangkar, karena Anda bisa menyajikan ditempatmu. Untuk Kita yang akan membuatnya, berikut ini cara menyajikan ayam lodho telur asin / takir bujur sangkar yang enak yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Lodho Telur Asin / Takir Bujur Sangkar:

1. Ambil  Bahan Utama :
1. Sediakan 1 ekor ayam (750 gram) potong kecil² jd 20 potong
1. Sediakan 4 butir telor asin misal tdk ada bisa diganti telor ayam biasa
1. Sediakan 1 sachet santan bubuk
1. Ambil 1 ikat kemangi (boleh lebih banyak lebih sedap)
1. Sediakan 1 lembar daun pandan
1. Sediakan 8 lembar daun pisang utk membungkus
1. Siapkan 15 buah cabe rawit utuh
1. Sediakan  Bumbu yang dihaluskan :
1. Ambil 10 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Ambil 1 ruas sere
1. Siapkan 1/2 kelingking kencur
1. Gunakan 1 jempol jahe
1. Siapkan 1 jempol lengkuas
1. Siapkan 1 telunjuk kunyit
1. Sediakan 5 lembar daun jeruk
1. Sediakan 1 lembar daun salam
1. Siapkan 1 sdt ketumbar bubuk
1. Ambil 3/4 sdt jinten bubuk
1. Sediakan 1/2 sdt merica bubuk
1. Ambil 1 sdt gula pasir
1. Siapkan 1 sdt garam
1. Sediakan 1 sachet kaldu bubuk




<!--inarticleads2-->

##### Cara menyiapkan Ayam Lodho Telur Asin / Takir Bujur Sangkar:

1. Potong kecil² ayam krmuan cuci bersih sisik
1. Rebus air hingga mendidih, dan masukan ayam dan dau pandan, rebus 15 menit
1. Siapkan wajan anti lengket, bakar ayam sampai kecoklatan
1. Siapkan bumbu, haluskan dan tumis hingga matang, masukkan ayam, tambahkan air kaldu rebusan ayam tadi
1. Tambahkan santan bubuk, masak hingga kaldu hingga menyusut, kemudian matikan api, tunggu hingga ayam dingin
1. Siapkan daun pisang buat takir seperti ini, atau bila tdk bisa anda bisa membungkusnya seperti bungkus botok atau Tum, kemudian panaskan kukusan
1. Masuk kan kemangi dan cabe rawit utuh ke dalam adonan ayam
1. Pisahkan antara putih telor dan kuning telor
1. Tuang putih telor kedalam adonan ayam, aduk rata dan test rasanya
1. Ambil beberapa sendok adonan ayam dan putih telur, isi takir sesuai selera, tambahkan kuning telor dan bumbu diatas nya
1. Kukus kurang lebih, 30 menit
1. Angkat dan sajikan bersama nasi putih hangat, bila Ayam Lodho Telor Asin ini dikosumsi sendiri, takir daun pisang tdk perlu diganti, namun bila akan dijual atau dibuat hantaran, sebaiknya ganti dengan takir yg daunnya masih segar, agar tampilan nya lebih menarik, selamat mencoba




Ternyata cara membuat ayam lodho telur asin / takir bujur sangkar yang mantab simple ini enteng sekali ya! Kita semua dapat membuatnya. Resep ayam lodho telur asin / takir bujur sangkar Sangat cocok sekali buat kamu yang baru akan belajar memasak maupun juga untuk kamu yang telah jago memasak.

Apakah kamu ingin mencoba membuat resep ayam lodho telur asin / takir bujur sangkar enak sederhana ini? Kalau kamu tertarik, yuk kita segera menyiapkan alat dan bahannya, lantas buat deh Resep ayam lodho telur asin / takir bujur sangkar yang enak dan sederhana ini. Sungguh gampang kan. 

Maka dari itu, daripada kalian diam saja, yuk kita langsung sajikan resep ayam lodho telur asin / takir bujur sangkar ini. Dijamin kamu gak akan nyesel sudah bikin resep ayam lodho telur asin / takir bujur sangkar mantab tidak rumit ini! Selamat berkreasi dengan resep ayam lodho telur asin / takir bujur sangkar lezat sederhana ini di rumah kalian sendiri,ya!.

