---
description: "Cara membuat Opor Ayam Masak Putih Sederhana dan Mudah Dibuat"
title: "Cara membuat Opor Ayam Masak Putih Sederhana dan Mudah Dibuat"
slug: 68-cara-membuat-opor-ayam-masak-putih-sederhana-dan-mudah-dibuat
date: 2021-04-02T11:06:10.404Z
image: https://img-global.cpcdn.com/recipes/1fd3590f43122e26/680x482cq70/opor-ayam-masak-putih-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1fd3590f43122e26/680x482cq70/opor-ayam-masak-putih-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1fd3590f43122e26/680x482cq70/opor-ayam-masak-putih-foto-resep-utama.jpg
author: Rena Mann
ratingvalue: 3.3
reviewcount: 12
recipeingredient:
- "1 kg ayampotong jadi 10 bagian"
- "300 ml santan kental dari 1 butir kelapa"
- "700 ml santan encer dari sisa perasan kelapa tadi"
- "5 lembar daun jerukbuang tulang daunnya"
- "3 lembar daun salam"
- "2 batang seraimemarkan"
- "3 cm lengkuasmemarkan"
- "2 1/2 sdt garam"
- "1/4 sdt merica bubuk"
- "1/2 sdt gula pasir"
- "2 sdm minyak goreng"
- " Jeruk nipis"
- " Bawang goreng untuk taburan"
- " Bumbu yang dihaluskan "
- "10 siung bawang merah"
- "4 siung bawang putih"
- "2 sdt ketumbarsangrai"
- "1/4 sdt jintensangrai"
- "2 cm jahe"
recipeinstructions:
- "Ayam dicuci bersih,lalu lumuri air perasan jeruk nipis,diamkan sebentar,lalu dicuci lagi sampai bersih,sisihkan."
- "Panaskan minyak,tumis bumbu halus,daun jeruk,daun salam,lengkuas dan serai sampai harum,masukkan ayam,aduk rata sampai berubah warna."
- "Tambahkan garam,merica dan gula pasir,aduk rata,tuang santan encer,masak sampai mendidih dan ayam matang,masukkan santan kental,aduk2 sampai santan mendidih,koreksi rasa."
- "Masak sampai matang dan mengental,angkat dan siap dihidangkan dengan taburan bawang goreng."
categories:
- Resep
tags:
- opor
- ayam
- masak

katakunci: opor ayam masak 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dinner

---


![Opor Ayam Masak Putih](https://img-global.cpcdn.com/recipes/1fd3590f43122e26/680x482cq70/opor-ayam-masak-putih-foto-resep-utama.jpg)

Jika kalian seorang ibu, menyediakan hidangan mantab buat orang tercinta merupakan suatu hal yang mengasyikan bagi kamu sendiri. Tugas seorang ibu bukan sekedar mengatur rumah saja, tapi kamu pun wajib memastikan kebutuhan nutrisi terpenuhi dan juga santapan yang dikonsumsi orang tercinta harus mantab.

Di era  saat ini, kita memang dapat memesan hidangan instan walaupun tidak harus ribet membuatnya dulu. Tapi banyak juga lho mereka yang memang ingin memberikan makanan yang terenak bagi orang yang dicintainya. Pasalnya, menyajikan masakan sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan famili. 



Apakah anda seorang penyuka opor ayam masak putih?. Tahukah kamu, opor ayam masak putih adalah sajian khas di Indonesia yang kini disukai oleh orang-orang di berbagai wilayah di Indonesia. Anda dapat memasak opor ayam masak putih kreasi sendiri di rumahmu dan boleh jadi santapan kesenanganmu di akhir pekan.

Anda tak perlu bingung jika kamu ingin mendapatkan opor ayam masak putih, sebab opor ayam masak putih tidak sulit untuk didapatkan dan juga kita pun dapat menghidangkannya sendiri di rumah. opor ayam masak putih dapat dibuat dengan berbagai cara. Sekarang ada banyak resep kekinian yang membuat opor ayam masak putih lebih lezat.

Resep opor ayam masak putih juga mudah sekali dihidangkan, lho. Anda jangan repot-repot untuk memesan opor ayam masak putih, sebab Kalian bisa menyiapkan di rumahmu. Untuk Kamu yang mau mencobanya, di bawah ini adalah cara membuat opor ayam masak putih yang enak yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Opor Ayam Masak Putih:

1. Gunakan 1 kg ayam,potong jadi 10 bagian
1. Siapkan 300 ml santan kental dari 1 butir kelapa
1. Gunakan 700 ml santan encer dari sisa perasan kelapa tadi
1. Siapkan 5 lembar daun jeruk,buang tulang daunnya
1. Ambil 3 lembar daun salam
1. Siapkan 2 batang serai,memarkan
1. Ambil 3 cm lengkuas,memarkan
1. Gunakan 2 1/2 sdt garam
1. Ambil 1/4 sdt merica bubuk
1. Ambil 1/2 sdt gula pasir
1. Siapkan 2 sdm minyak goreng
1. Gunakan  Jeruk nipis
1. Siapkan  Bawang goreng untuk taburan
1. Ambil  Bumbu yang dihaluskan :
1. Siapkan 10 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Sediakan 2 sdt ketumbar,sangrai
1. Siapkan 1/4 sdt jinten,sangrai
1. Sediakan 2 cm jahe




<!--inarticleads2-->

##### Langkah-langkah membuat Opor Ayam Masak Putih:

1. Ayam dicuci bersih,lalu lumuri air perasan jeruk nipis,diamkan sebentar,lalu dicuci lagi sampai bersih,sisihkan.
1. Panaskan minyak,tumis bumbu halus,daun jeruk,daun salam,lengkuas dan serai sampai harum,masukkan ayam,aduk rata sampai berubah warna.
1. Tambahkan garam,merica dan gula pasir,aduk rata,tuang santan encer,masak sampai mendidih dan ayam matang,masukkan santan kental,aduk2 sampai santan mendidih,koreksi rasa.
1. Masak sampai matang dan mengental,angkat dan siap dihidangkan dengan taburan bawang goreng.




Wah ternyata resep opor ayam masak putih yang enak simple ini enteng sekali ya! Kalian semua mampu mencobanya. Cara buat opor ayam masak putih Sesuai banget buat anda yang sedang belajar memasak ataupun untuk kalian yang telah jago dalam memasak.

Apakah kamu tertarik mencoba bikin resep opor ayam masak putih nikmat simple ini? Kalau kalian ingin, mending kamu segera buruan siapkan alat dan bahan-bahannya, kemudian buat deh Resep opor ayam masak putih yang enak dan simple ini. Betul-betul mudah kan. 

Oleh karena itu, ketimbang kalian diam saja, maka langsung aja hidangkan resep opor ayam masak putih ini. Dijamin kamu tak akan menyesal membuat resep opor ayam masak putih nikmat tidak ribet ini! Selamat mencoba dengan resep opor ayam masak putih mantab tidak ribet ini di tempat tinggal masing-masing,oke!.

