---
description: "Bahan-bahan Ayam Panggang Bumbu Santan Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Ayam Panggang Bumbu Santan Sederhana dan Mudah Dibuat"
slug: 320-bahan-bahan-ayam-panggang-bumbu-santan-sederhana-dan-mudah-dibuat
date: 2021-07-06T19:32:14.210Z
image: https://img-global.cpcdn.com/recipes/51461bafa3306089/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/51461bafa3306089/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/51461bafa3306089/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
author: Jeffery Rhodes
ratingvalue: 3.7
reviewcount: 13
recipeingredient:
- "1/2 ekor ayam bagian paha"
- "1 buah jeruk nipis"
- " Bumbu halus "
- "4 butir bawang merah"
- "3 siung bawang putih"
- "5 cm kunyit"
- "1 ruas lengkuas"
- "1 sdt ketumbar"
- " Bumbu aromatik "
- "2 lembar daun jeruk purut"
- "1 batang serai geprek"
- " Bumbu lainnya "
- "2 sachet santan instan 65 ml"
- "400 ml air"
- "3/4 sdm garam"
- "1/4 sdt gula"
recipeinstructions:
- "Potong ayam menjadi dua bagian, kemudian bersihkan dan kucuri air perasan jeruk nipis. Marinasi selama 15 menit. Bilas."
- "Kemudian haluskan bumbu halus hingga benar-benar halus."
- "Dalam wajan masukkan bumbu halus, bumbu lainnya dan bumbu aromatik. Aduk rata. Masukkan potongan ayam."
- "Masak ayam dengan cara diungkep (dengan menggunakan api kecil hingga bumbu meresap dan kuah menyusut)."
- "Angkat potongan ayam, sisihkan bumbu santannya, kemudian panggang hingga permukaannya kering."
- "Angkat ayam yang sudah dipanggang ke atas piring, kemudian baluri dengan bumbu santan. Sajikan."
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 189 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Panggang Bumbu Santan](https://img-global.cpcdn.com/recipes/51461bafa3306089/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan panganan nikmat kepada orang tercinta adalah hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang istri bukan sekedar mengerjakan pekerjaan rumah saja, tetapi anda pun wajib memastikan kebutuhan gizi terpenuhi dan masakan yang dikonsumsi orang tercinta mesti menggugah selera.

Di waktu  sekarang, kamu sebenarnya bisa membeli olahan instan meski tidak harus repot mengolahnya terlebih dahulu. Tetapi banyak juga lho mereka yang selalu ingin memberikan yang terbaik bagi orang yang dicintainya. Karena, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan keluarga. 



Apakah anda merupakan salah satu penikmat ayam panggang bumbu santan?. Asal kamu tahu, ayam panggang bumbu santan adalah sajian khas di Nusantara yang sekarang disukai oleh setiap orang di berbagai wilayah di Nusantara. Kalian bisa memasak ayam panggang bumbu santan sendiri di rumah dan pasti jadi makanan favoritmu di akhir pekanmu.

Kalian tidak usah bingung untuk menyantap ayam panggang bumbu santan, sebab ayam panggang bumbu santan sangat mudah untuk didapatkan dan kita pun boleh memasaknya sendiri di rumah. ayam panggang bumbu santan bisa dibuat memalui bermacam cara. Kini pun ada banyak cara modern yang membuat ayam panggang bumbu santan semakin enak.

Resep ayam panggang bumbu santan pun sangat mudah dibuat, lho. Kita tidak usah repot-repot untuk memesan ayam panggang bumbu santan, sebab Anda bisa menyajikan ditempatmu. Bagi Anda yang hendak mencobanya, berikut ini resep untuk menyajikan ayam panggang bumbu santan yang mantab yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Panggang Bumbu Santan:

1. Ambil 1/2 ekor ayam bagian paha
1. Gunakan 1 buah jeruk nipis
1. Siapkan  Bumbu halus :
1. Ambil 4 butir bawang merah
1. Ambil 3 siung bawang putih
1. Ambil 5 cm kunyit
1. Gunakan 1 ruas lengkuas
1. Sediakan 1 sdt ketumbar
1. Gunakan  Bumbu aromatik :
1. Sediakan 2 lembar daun jeruk purut
1. Sediakan 1 batang serai, geprek
1. Siapkan  Bumbu lainnya :
1. Gunakan 2 sachet santan instan 65 ml
1. Sediakan 400 ml air
1. Siapkan 3/4 sdm garam
1. Siapkan 1/4 sdt gula




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Panggang Bumbu Santan:

1. Potong ayam menjadi dua bagian, kemudian bersihkan dan kucuri air perasan jeruk nipis. Marinasi selama 15 menit. Bilas.
1. Kemudian haluskan bumbu halus hingga benar-benar halus.
1. Dalam wajan masukkan bumbu halus, bumbu lainnya dan bumbu aromatik. Aduk rata. Masukkan potongan ayam.
1. Masak ayam dengan cara diungkep (dengan menggunakan api kecil hingga bumbu meresap dan kuah menyusut).
1. Angkat potongan ayam, sisihkan bumbu santannya, kemudian panggang hingga permukaannya kering.
1. Angkat ayam yang sudah dipanggang ke atas piring, kemudian baluri dengan bumbu santan. Sajikan.




Ternyata cara membuat ayam panggang bumbu santan yang mantab simple ini enteng sekali ya! Kamu semua mampu memasaknya. Resep ayam panggang bumbu santan Sangat cocok banget untuk kita yang baru mau belajar memasak maupun untuk kalian yang sudah hebat memasak.

Apakah kamu mau mulai mencoba buat resep ayam panggang bumbu santan lezat tidak ribet ini? Kalau kalian mau, ayo kamu segera buruan siapkan alat-alat dan bahannya, kemudian bikin deh Resep ayam panggang bumbu santan yang enak dan tidak rumit ini. Sangat mudah kan. 

Maka, daripada kita diam saja, maka kita langsung saja buat resep ayam panggang bumbu santan ini. Pasti kamu tak akan nyesel bikin resep ayam panggang bumbu santan mantab tidak ribet ini! Selamat berkreasi dengan resep ayam panggang bumbu santan nikmat sederhana ini di rumah masing-masing,oke!.

