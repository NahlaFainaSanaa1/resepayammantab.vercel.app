---
description: "Cara membuat Soto ayam santan yang lezat Untuk Jualan"
title: "Cara membuat Soto ayam santan yang lezat Untuk Jualan"
slug: 388-cara-membuat-soto-ayam-santan-yang-lezat-untuk-jualan
date: 2021-03-26T10:46:32.503Z
image: https://img-global.cpcdn.com/recipes/8f0a87d0e1892409/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8f0a87d0e1892409/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8f0a87d0e1892409/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Daisy Jefferson
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "1 dada ayam"
- "2 sendok sayur tetelan yg sudah direbus"
- "2 sacet Sasa santan 65ml"
- "2 liter air"
- "4 lembar salam"
- "1 batang sereh"
- "4 lembar daun jeruk"
- "Secukupnya Minyak untuk menumis"
- "Secukupnya Garamgula dan kaldu bubuk"
- " Bumbu halus "
- "10 bawang merah"
- "5 bawang putih"
- "2 kemiri"
- "1 telunjuk kunyit"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1/2 sdt lada"
- "1/4 sdt ketumbar"
- " Pelengkap"
- " Kentang goreng"
- " Tomat"
- " Daun bawang dan seledri"
- " Emping"
- " Jeruk nipis"
- " Kecap"
- " Sambal"
- " Bawang goreng"
recipeinstructions:
- "Siapkan bahan,Ayam potong dadu lalu cuci bersih"
- "Tumis bumbu halus sampai matang setelah matang masukan salam,sereh,daun jeruk"
- "Lalu masukan air setelah air mendidih masukan ayam nya masak sampai empuk"
- "Tambahkan garam gula dan kaldu bubuk tes rasa yaa"
- "Setelah ayam matang masukan tetelan dan santan masak sampai matang"
- "Cara penyajian masukan ke mangkok kentang goreng,tomat,daun bawang emping,kecap,bawang goreng,jeruk nipis lalu tuang sm kuahnya dan ayamnya"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto ayam santan](https://img-global.cpcdn.com/recipes/8f0a87d0e1892409/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyediakan masakan lezat kepada orang tercinta adalah hal yang membahagiakan bagi kita sendiri. Peran seorang istri bukan hanya mengurus rumah saja, tetapi kamu pun wajib menyediakan kebutuhan gizi tercukupi dan hidangan yang dikonsumsi orang tercinta wajib menggugah selera.

Di masa  sekarang, kalian memang dapat membeli olahan praktis tidak harus ribet membuatnya lebih dulu. Namun ada juga lho orang yang memang ingin memberikan hidangan yang terlezat bagi orang tercintanya. Karena, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai kesukaan orang tercinta. 



Apakah anda seorang penggemar soto ayam santan?. Asal kamu tahu, soto ayam santan adalah hidangan khas di Indonesia yang sekarang digemari oleh orang-orang di hampir setiap daerah di Indonesia. Kita dapat menyajikan soto ayam santan kreasi sendiri di rumahmu dan pasti jadi camilan favoritmu di hari liburmu.

Kalian tidak perlu bingung untuk memakan soto ayam santan, karena soto ayam santan gampang untuk ditemukan dan kita pun bisa menghidangkannya sendiri di rumah. soto ayam santan boleh dibuat dengan beragam cara. Saat ini telah banyak sekali cara kekinian yang membuat soto ayam santan semakin mantap.

Resep soto ayam santan juga sangat mudah untuk dibuat, lho. Kita tidak usah ribet-ribet untuk membeli soto ayam santan, tetapi Kamu bisa menghidangkan di rumah sendiri. Untuk Kita yang mau menghidangkannya, berikut ini cara untuk menyajikan soto ayam santan yang mantab yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Soto ayam santan:

1. Ambil 1 dada ayam
1. Gunakan 2 sendok sayur tetelan yg sudah direbus
1. Ambil 2 sacet Sasa santan 65ml
1. Siapkan 2 liter air
1. Ambil 4 lembar salam
1. Ambil 1 batang sereh
1. Ambil 4 lembar daun jeruk
1. Siapkan Secukupnya Minyak untuk menumis
1. Gunakan Secukupnya Garam,gula dan kaldu bubuk
1. Sediakan  Bumbu halus :
1. Siapkan 10 bawang merah
1. Sediakan 5 bawang putih
1. Siapkan 2 kemiri
1. Gunakan 1 telunjuk kunyit
1. Gunakan 1 ruas jahe
1. Sediakan 1 ruas lengkuas
1. Siapkan 1/2 sdt lada
1. Ambil 1/4 sdt ketumbar
1. Gunakan  Pelengkap
1. Gunakan  Kentang goreng
1. Gunakan  Tomat
1. Siapkan  Daun bawang dan seledri
1. Sediakan  Emping
1. Gunakan  Jeruk nipis
1. Ambil  Kecap
1. Sediakan  Sambal
1. Ambil  Bawang goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Soto ayam santan:

1. Siapkan bahan,Ayam potong dadu lalu cuci bersih
1. Tumis bumbu halus sampai matang setelah matang masukan salam,sereh,daun jeruk
1. Lalu masukan air setelah air mendidih masukan ayam nya masak sampai empuk
1. Tambahkan garam gula dan kaldu bubuk tes rasa yaa
1. Setelah ayam matang masukan tetelan dan santan masak sampai matang
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Soto ayam santan">1. Cara penyajian masukan ke mangkok kentang goreng,tomat,daun bawang emping,kecap,bawang goreng,jeruk nipis lalu tuang sm kuahnya dan ayamnya




Wah ternyata resep soto ayam santan yang nikamt tidak ribet ini gampang banget ya! Kamu semua mampu menghidangkannya. Resep soto ayam santan Sesuai sekali buat kalian yang sedang belajar memasak maupun juga bagi anda yang sudah lihai memasak.

Tertarik untuk mulai mencoba membikin resep soto ayam santan enak simple ini? Kalau anda mau, yuk kita segera buruan siapkan alat-alat dan bahannya, kemudian buat deh Resep soto ayam santan yang lezat dan tidak rumit ini. Sungguh gampang kan. 

Maka, daripada anda berlama-lama, hayo langsung aja hidangkan resep soto ayam santan ini. Dijamin kalian tak akan menyesal sudah bikin resep soto ayam santan lezat simple ini! Selamat mencoba dengan resep soto ayam santan enak sederhana ini di tempat tinggal masing-masing,ya!.

