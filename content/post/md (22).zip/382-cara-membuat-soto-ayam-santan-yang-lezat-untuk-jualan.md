---
description: "Cara membuat Soto Ayam Santan yang lezat Untuk Jualan"
title: "Cara membuat Soto Ayam Santan yang lezat Untuk Jualan"
slug: 382-cara-membuat-soto-ayam-santan-yang-lezat-untuk-jualan
date: 2021-01-31T02:10:09.774Z
image: https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Rena McCoy
ratingvalue: 4
reviewcount: 13
recipeingredient:
- "1 kg dada ayam bagusnya yg fillet"
- "250 ml Santan kara ukuran"
- " Garam kaldu jamur"
- " Air untuk merebus"
- " Pelengkap"
- " Kentang potong dadu goreng"
- " Toge rebus"
- " Kol optional"
- "iris Daun bawang dan seledri"
- " Telur rebus"
- " Bawang goreng untuk taburan"
- "potong dadu Tomat"
- " Bumbu halus"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "8 buah kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdm ketumbar"
- "Secukupnya lada"
- " Bumbu cemplung"
- "5 lembar daun salam"
- "5 lembar daun jeruk"
- "2 buah serai"
- "1 ruas Laos geprek"
recipeinstructions:
- "Bersihkan ayam. Sisihkan"
- "Didihkan air, beserta daun salam dan serai. Masukan ayam."
- "Sambil merebus ayam. Tumis bumbu halus sampai wangi, tambahkan daun jeruk. Setelah bumbu matang, masukan bumbu kedalam rebusan air yang berisi ayam. Biarkan bumbu meresap dan ayam empuk"
- "Angkat ayam, goreng sebentar lalu suwir kasar (optional..kalo ga mau di goreng bisa langsung di suwir)"
- "Dalam air rebusan ayam tadi, masukan santan kara. Biarkan mendidih. Masukan garam dan kaldu jamur. Test rasa"
- "Sajikan soto bersama pelengkapnya."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 265 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan panganan enak buat keluarga merupakan hal yang menyenangkan untuk kamu sendiri. Tanggung jawab seorang istri bukan saja mengurus rumah saja, tapi anda pun harus menyediakan keperluan gizi terpenuhi dan panganan yang dimakan keluarga tercinta mesti mantab.

Di era  sekarang, kamu sebenarnya dapat mengorder hidangan siap saji tidak harus repot memasaknya dahulu. Tetapi banyak juga lho orang yang selalu mau memberikan makanan yang terbaik untuk orang yang dicintainya. Sebab, memasak sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan keluarga. 



Mungkinkah anda adalah salah satu penyuka soto ayam santan?. Tahukah kamu, soto ayam santan adalah sajian khas di Nusantara yang sekarang disukai oleh banyak orang di berbagai wilayah di Indonesia. Kalian dapat menghidangkan soto ayam santan hasil sendiri di rumah dan pasti jadi makanan favoritmu di akhir pekan.

Kita jangan bingung jika kamu ingin mendapatkan soto ayam santan, lantaran soto ayam santan mudah untuk ditemukan dan juga kamu pun boleh memasaknya sendiri di tempatmu. soto ayam santan bisa dimasak lewat beragam cara. Kini pun ada banyak sekali resep modern yang membuat soto ayam santan lebih mantap.

Resep soto ayam santan juga gampang untuk dibikin, lho. Anda jangan ribet-ribet untuk membeli soto ayam santan, lantaran Kita mampu menghidangkan ditempatmu. Untuk Anda yang mau mencobanya, inilah cara untuk membuat soto ayam santan yang nikamat yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto Ayam Santan:

1. Ambil 1 kg dada ayam (bagusnya yg fillet)
1. Siapkan 250 ml Santan kara ukuran
1. Sediakan  Garam, kaldu jamur
1. Sediakan  Air untuk merebus
1. Sediakan  Pelengkap
1. Gunakan  Kentang potong dadu, goreng
1. Gunakan  Toge rebus
1. Siapkan  Kol (optional)
1. Gunakan iris Daun bawang dan seledri
1. Gunakan  Telur rebus
1. Sediakan  Bawang goreng untuk taburan
1. Ambil potong dadu Tomat
1. Ambil  Bumbu halus
1. Siapkan 4 siung bawang putih
1. Gunakan 7 siung bawang merah
1. Gunakan 8 buah kemiri
1. Siapkan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Gunakan 1 sdm ketumbar
1. Ambil Secukupnya lada
1. Gunakan  Bumbu cemplung
1. Gunakan 5 lembar daun salam
1. Sediakan 5 lembar daun jeruk
1. Gunakan 2 buah serai
1. Gunakan 1 ruas Laos geprek




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Santan:

1. Bersihkan ayam. Sisihkan
1. Didihkan air, beserta daun salam dan serai. Masukan ayam.
1. Sambil merebus ayam. Tumis bumbu halus sampai wangi, tambahkan daun jeruk. Setelah bumbu matang, masukan bumbu kedalam rebusan air yang berisi ayam. Biarkan bumbu meresap dan ayam empuk
1. Angkat ayam, goreng sebentar lalu suwir kasar (optional..kalo ga mau di goreng bisa langsung di suwir)
1. Dalam air rebusan ayam tadi, masukan santan kara. Biarkan mendidih. Masukan garam dan kaldu jamur. Test rasa
1. Sajikan soto bersama pelengkapnya.




Wah ternyata resep soto ayam santan yang enak sederhana ini enteng banget ya! Anda Semua mampu mencobanya. Cara buat soto ayam santan Sangat sesuai banget untuk anda yang baru belajar memasak maupun untuk kamu yang telah hebat dalam memasak.

Apakah kamu tertarik mulai mencoba buat resep soto ayam santan mantab tidak ribet ini? Kalau kamu mau, mending kamu segera siapkan alat dan bahannya, setelah itu buat deh Resep soto ayam santan yang lezat dan tidak ribet ini. Sangat mudah kan. 

Jadi, ketimbang kamu diam saja, yuk kita langsung saja bikin resep soto ayam santan ini. Dijamin kamu gak akan nyesel membuat resep soto ayam santan mantab tidak rumit ini! Selamat mencoba dengan resep soto ayam santan mantab sederhana ini di tempat tinggal sendiri,ya!.

