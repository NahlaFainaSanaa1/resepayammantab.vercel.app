---
description: "Cara buat Ayam goreng ala KFC yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam goreng ala KFC yang lezat dan Mudah Dibuat"
slug: 50-cara-buat-ayam-goreng-ala-kfc-yang-lezat-dan-mudah-dibuat
date: 2021-07-01T08:47:38.939Z
image: https://img-global.cpcdn.com/recipes/3fbcf886e6f9d676/680x482cq70/ayam-goreng-ala-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3fbcf886e6f9d676/680x482cq70/ayam-goreng-ala-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3fbcf886e6f9d676/680x482cq70/ayam-goreng-ala-kfc-foto-resep-utama.jpg
author: Pauline Brady
ratingvalue: 5
reviewcount: 8
recipeingredient:
- "1/2 kg Ayam"
- " Bumbu Marinasi"
- "1 sdt oregano tumbuk halus"
- "1 sdt rosmary tumbuk halus"
- "1,5 sdt bubuk paprika bisa di ganti bubuk cabe"
- "1 sdt bawang putih bubuk"
- "1 sdt lada bubuk"
- "1 sdt jahe bubuk"
- "1 sdt ketumbar bubuk"
- "1 sdt kaldu Bubuk"
- "1/2 sdt garam"
- "secukupnya Susu uht"
- " Bahan tepung kering"
- "1/2 kg tepung terigu Cakra"
- "1 sdt paprika bubuk"
- "2 sdt bawang putih bubuk"
- "1 sdt lada bubuk"
- "1 sdt jahe bubuk"
- "1 sdt ketumbar bubuk"
- "1 sacset kaldu bubuk"
- "1/2 sdt garam"
- "1/4 Sdm baking powder"
- "1/4 Sdm baking soda"
recipeinstructions:
- "Potong2 ayam sesuai selera lalu campur smua bumbu2 nya kasih susu uht aduk2 rata."
- "Lalu marinasi terlebih dahulu,masukkan ke Tupperware / tmpt lainnya Dan masukkan ke dalam kulkas selama 8 jam"
- "Untuk tepung bumbunya, campur kan smua bumbu halusnya menjadi satu bersama tepung terigu, kocok2 biar tercampur rata,dan sisihkan"
- "Siapkan air/ susu uht utk pencelupan kasih garam sedikit aduk2 rata,lalu ambil ayam masukkan ke tepung lalu masukkan ke air/ susu lakukan 2x,aduk2 memutar lalu ketok2 biar tepung yg TDK menempel bisa jatuh,dan hasilnya akan terlihat bagus"
- "Dan siapkan minyak yg banyak dgn api 🔥 yg sedang,lalu masukkan ayam yg Sdh di tepung,jgn sering di aduk2 biar tepung TDK rontok"
- "Dan ayam kentaky KFC siap di hidangkan,bersama nasi hangat dan saos sambel 🤗"
categories:
- Resep
tags:
- ayam
- goreng
- ala

katakunci: ayam goreng ala 
nutrition: 226 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam goreng ala KFC](https://img-global.cpcdn.com/recipes/3fbcf886e6f9d676/680x482cq70/ayam-goreng-ala-kfc-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan masakan lezat untuk orang tercinta merupakan suatu hal yang membahagiakan bagi anda sendiri. Tugas seorang  wanita bukan hanya mengurus rumah saja, namun anda juga harus memastikan keperluan nutrisi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta mesti nikmat.

Di waktu  sekarang, kalian sebenarnya dapat memesan hidangan praktis meski tidak harus ribet membuatnya lebih dulu. Tapi banyak juga mereka yang memang ingin memberikan hidangan yang terlezat bagi orang yang dicintainya. Sebab, menghidangkan masakan sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan famili. 

Terlupa nak letak pada video dan malas. Hai, hari nie saya share cara buat ayam goreng ala kfc mudah dan senang tak perlu banyak bahan hanya menggunakan tepung sahaja. Kenikmatan ayam goreng Kentucky memang tiada duanya, rasanya yang gurih dan lezat menjadi salah satu alasannya.

Mungkinkah anda salah satu penikmat ayam goreng ala kfc?. Tahukah kamu, ayam goreng ala kfc merupakan sajian khas di Indonesia yang saat ini digemari oleh setiap orang di hampir setiap tempat di Indonesia. Kita dapat menghidangkan ayam goreng ala kfc sendiri di rumahmu dan dapat dijadikan santapan favoritmu di hari liburmu.

Kalian jangan bingung untuk menyantap ayam goreng ala kfc, sebab ayam goreng ala kfc tidak sulit untuk ditemukan dan juga kamu pun boleh membuatnya sendiri di tempatmu. ayam goreng ala kfc bisa dibuat dengan beraneka cara. Kini pun telah banyak cara modern yang membuat ayam goreng ala kfc semakin nikmat.

Resep ayam goreng ala kfc juga gampang dibikin, lho. Kalian tidak usah ribet-ribet untuk memesan ayam goreng ala kfc, karena Kamu mampu menghidangkan di rumahmu. Untuk Kalian yang ingin mencobanya, dibawah ini merupakan resep menyajikan ayam goreng ala kfc yang lezat yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam goreng ala KFC:

1. Sediakan 1/2 kg Ayam
1. Sediakan  Bumbu Marinasi
1. Gunakan 1 sdt oregano tumbuk halus
1. Sediakan 1 sdt rosmary tumbuk halus
1. Siapkan 1,5 sdt bubuk paprika (bisa di ganti bubuk cabe)
1. Sediakan 1 sdt bawang putih bubuk
1. Gunakan 1 sdt lada bubuk
1. Ambil 1 sdt jahe bubuk
1. Gunakan 1 sdt ketumbar bubuk
1. Sediakan 1 sdt kaldu Bubuk
1. Gunakan 1/2 sdt garam
1. Gunakan secukupnya Susu uht
1. Sediakan  Bahan tepung kering:
1. Gunakan 1/2 kg tepung terigu Cakra
1. Gunakan 1 sdt paprika bubuk
1. Siapkan 2 sdt bawang putih bubuk
1. Siapkan 1 sdt lada bubuk
1. Sediakan 1 sdt jahe bubuk
1. Siapkan 1 sdt ketumbar bubuk
1. Gunakan 1 sacset kaldu bubuk
1. Ambil 1/2 sdt garam
1. Ambil 1/4 Sdm baking powder
1. Sediakan 1/4 Sdm baking soda


Olahan ayam goreng tepung yang begitu diminati masyarakat yakni dari KFC. Mesti ramai yang suka makan ayam goreng KFC, lebih-lebih lagi yang &#39;spicy&#39;. Biasalah, orang Malaysia memang minat yang pedas-pedas ini. Lunch hari ni ayam goreng ala KFC. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam goreng ala KFC:

1. Potong2 ayam sesuai selera lalu campur smua bumbu2 nya kasih susu uht aduk2 rata.
1. Lalu marinasi terlebih dahulu,masukkan ke Tupperware / tmpt lainnya Dan masukkan ke dalam kulkas selama 8 jam
1. Untuk tepung bumbunya, campur kan smua bumbu halusnya menjadi satu bersama tepung terigu, kocok2 biar tercampur rata,dan sisihkan
1. Siapkan air/ susu uht utk pencelupan kasih garam sedikit aduk2 rata,lalu ambil ayam masukkan ke tepung lalu masukkan ke air/ susu lakukan 2x,aduk2 memutar lalu ketok2 biar tepung yg TDK menempel bisa jatuh,dan hasilnya akan terlihat bagus
1. Dan siapkan minyak yg banyak dgn api 🔥 yg sedang,lalu masukkan ayam yg Sdh di tepung,jgn sering di aduk2 biar tepung TDK rontok
1. Dan ayam kentaky KFC siap di hidangkan,bersama nasi hangat dan saos sambel 🤗


Kalau ada sesiapa yang anak asyik ajak makan KFC tu boleh try resepi ni. Ala-ala KFC jugak ada ayam original dan spicy. Yang suka pedas tu boleh tambah kepedasan ayam ikut citarasa sendiri. Lumuri ayam yang sudah dipotong dengan perasan jeruk nipis. Adonan kering: Campur tepung terigu dan tepung. 

Ternyata cara buat ayam goreng ala kfc yang lezat tidak ribet ini enteng sekali ya! Kita semua bisa menghidangkannya. Cara buat ayam goreng ala kfc Sangat cocok banget buat kamu yang baru akan belajar memasak ataupun bagi kalian yang sudah pandai dalam memasak.

Tertarik untuk mulai mencoba membuat resep ayam goreng ala kfc enak tidak ribet ini? Kalau kamu mau, yuk kita segera siapkan alat dan bahan-bahannya, lantas buat deh Resep ayam goreng ala kfc yang mantab dan sederhana ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kita berlama-lama, yuk kita langsung buat resep ayam goreng ala kfc ini. Dijamin kalian gak akan menyesal sudah bikin resep ayam goreng ala kfc lezat sederhana ini! Selamat mencoba dengan resep ayam goreng ala kfc lezat sederhana ini di rumah kalian sendiri,ya!.

