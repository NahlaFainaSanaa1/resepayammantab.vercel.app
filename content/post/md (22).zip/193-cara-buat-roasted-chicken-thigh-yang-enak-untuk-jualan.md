---
description: "Cara buat Roasted Chicken Thigh yang enak Untuk Jualan"
title: "Cara buat Roasted Chicken Thigh yang enak Untuk Jualan"
slug: 193-cara-buat-roasted-chicken-thigh-yang-enak-untuk-jualan
date: 2021-03-19T13:59:35.882Z
image: https://img-global.cpcdn.com/recipes/d633c3773b199e4c/680x482cq70/roasted-chicken-thigh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d633c3773b199e4c/680x482cq70/roasted-chicken-thigh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d633c3773b199e4c/680x482cq70/roasted-chicken-thigh-foto-resep-utama.jpg
author: Jose Spencer
ratingvalue: 4.6
reviewcount: 11
recipeingredient:
- "5 potong paha atas ayam cuci bersih lalu lap pakai tisu atau lap bersih agar air terserap"
- "5 sdm bawang putih bubuk"
- "Secukupnya rosemary"
- "Secukupnya merica bubuk saya pake black pepper"
- "1 sdm garam"
recipeinstructions:
- "Tabur ayam dengan garam dan merica di kedua sisi."
- "Lalu tabur bawang putih bubuk hingga rata di kedua sisi(bisa di tambah atau di kurangi ya sesuai selera, kalo saya rasa udah cukup garlicky banget dengan 5 sdm)"
- "Tabur dengan rosemary di kedua sisi juga."
- "Siapkan loyang. Alasi dengan kertas minyak. Tata ayam diatasnya."
- "Nyalakan oven dengan suhu 350°f (sekitar 176°c - 180°c). Panggang selama 1 jam (maafkan salmonnya ikut terfoto 😅)."
- "Angkat dan sajikan."
categories:
- Resep
tags:
- roasted
- chicken
- thigh

katakunci: roasted chicken thigh 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dinner

---


![Roasted Chicken Thigh](https://img-global.cpcdn.com/recipes/d633c3773b199e4c/680x482cq70/roasted-chicken-thigh-foto-resep-utama.jpg)

Sebagai seorang istri, menyuguhkan olahan mantab untuk famili merupakan suatu hal yang memuaskan bagi kamu sendiri. Tanggung jawab seorang ibu Tidak sekadar mengurus rumah saja, namun kamu pun harus memastikan keperluan nutrisi terpenuhi dan juga hidangan yang dikonsumsi anak-anak mesti mantab.

Di waktu  saat ini, kalian memang dapat membeli panganan praktis meski tidak harus capek membuatnya dahulu. Tapi banyak juga orang yang selalu ingin memberikan hidangan yang terlezat bagi keluarganya. Sebab, memasak yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Mungkinkah kamu salah satu penyuka roasted chicken thigh?. Asal kamu tahu, roasted chicken thigh adalah sajian khas di Nusantara yang sekarang disukai oleh kebanyakan orang di hampir setiap wilayah di Indonesia. Kita dapat memasak roasted chicken thigh olahan sendiri di rumahmu dan dapat dijadikan santapan kesukaanmu di akhir pekanmu.

Kamu jangan bingung untuk mendapatkan roasted chicken thigh, sebab roasted chicken thigh gampang untuk ditemukan dan juga kalian pun dapat menghidangkannya sendiri di rumah. roasted chicken thigh bisa diolah dengan bermacam cara. Sekarang ada banyak sekali cara kekinian yang menjadikan roasted chicken thigh semakin nikmat.

Resep roasted chicken thigh pun mudah sekali dibuat, lho. Kita jangan capek-capek untuk memesan roasted chicken thigh, sebab Kita bisa membuatnya sendiri di rumah. Untuk Kita yang hendak membuatnya, berikut cara menyajikan roasted chicken thigh yang lezat yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Roasted Chicken Thigh:

1. Siapkan 5 potong paha atas ayam (cuci bersih lalu lap pakai tisu atau lap bersih agar air terserap)
1. Siapkan 5 sdm bawang putih bubuk
1. Ambil Secukupnya rosemary
1. Sediakan Secukupnya merica bubuk (saya pake black pepper)
1. Ambil 1 sdm garam




<!--inarticleads2-->

##### Langkah-langkah membuat Roasted Chicken Thigh:

1. Tabur ayam dengan garam dan merica di kedua sisi.
<img src="https://img-global.cpcdn.com/steps/27e8993c678c9280/160x128cq70/roasted-chicken-thigh-langkah-memasak-1-foto.jpg" alt="Roasted Chicken Thigh">1. Lalu tabur bawang putih bubuk hingga rata di kedua sisi(bisa di tambah atau di kurangi ya sesuai selera, kalo saya rasa udah cukup garlicky banget dengan 5 sdm)
<img src="https://img-global.cpcdn.com/steps/501c47131d6a6f45/160x128cq70/roasted-chicken-thigh-langkah-memasak-2-foto.jpg" alt="Roasted Chicken Thigh">1. Tabur dengan rosemary di kedua sisi juga.
<img src="https://img-global.cpcdn.com/steps/759bf4eaf874bcbe/160x128cq70/roasted-chicken-thigh-langkah-memasak-3-foto.jpg" alt="Roasted Chicken Thigh">1. Siapkan loyang. Alasi dengan kertas minyak. Tata ayam diatasnya.
1. Nyalakan oven dengan suhu 350°f (sekitar 176°c - 180°c). Panggang selama 1 jam (maafkan salmonnya ikut terfoto 😅).
1. Angkat dan sajikan.




Wah ternyata cara membuat roasted chicken thigh yang enak tidak rumit ini mudah sekali ya! Kalian semua dapat menghidangkannya. Resep roasted chicken thigh Sesuai banget buat kita yang baru mau belajar memasak ataupun bagi kamu yang telah jago memasak.

Apakah kamu tertarik mulai mencoba membikin resep roasted chicken thigh nikmat tidak rumit ini? Kalau kalian ingin, mending kamu segera buruan siapkan peralatan dan bahan-bahannya, maka bikin deh Resep roasted chicken thigh yang mantab dan tidak rumit ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kamu berlama-lama, yuk kita langsung saja bikin resep roasted chicken thigh ini. Dijamin kalian tiidak akan nyesel sudah buat resep roasted chicken thigh lezat sederhana ini! Selamat mencoba dengan resep roasted chicken thigh nikmat sederhana ini di rumah kalian masing-masing,oke!.

