---
description: "Resep Pepes Ayam yang lezat dan Mudah Dibuat"
title: "Resep Pepes Ayam yang lezat dan Mudah Dibuat"
slug: 425-resep-pepes-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-03-11T05:05:24.511Z
image: https://img-global.cpcdn.com/recipes/07a6052732988e1d/680x482cq70/pepes-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/07a6052732988e1d/680x482cq70/pepes-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/07a6052732988e1d/680x482cq70/pepes-ayam-foto-resep-utama.jpg
author: Julian Thompson
ratingvalue: 4.4
reviewcount: 3
recipeingredient:
- "1 kg daging ayam"
- "9 daun salam"
- "3 batang sereh"
- "6 cm lengkuas"
- "1 buah tomat merah  3 buah asam jawa"
- "9 cabai rawit jika suka pedas cabenya dapat diiris"
- "3 ikat daun kemangi"
- "2 sendok makan garam"
- "1 sdt penyedap"
- "1 sdt gula putih"
- "1 gandu gula merah"
- " Bumbu halus"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "6 kemiri"
- "4 ruas kunyit"
recipeinstructions:
- "Bersihkan semua bahan, keringkan ayam dengan tisu sehingga nanti saat di kukus tdk mengeluarkan air banyak. kemudian haluskan semua bumbu denhan ulekan bisa juga di blender. Iris sereh, lengkuas, dan tomat"
- "Panaskan wajan anti lengket, tumis bumbu halus dengan lengkuas dan daun salam hingga wangi. Setelah wangi masukkan bumbu kedalam ayam aduk merata"
- "Kemudian masukkan penyedap, gula, garam dan irisan gula merah aduk merata cicipi dahulunya disini."
- "Setelah bumbu sudah pas masukkan kemangi, sereh, cabai, dan tomat. Kemudian susun ayam kedalam daun pisang yg sudah di lakuyukan terlebih dahulu"
- "Kukus kurleb 45menit tergantung seberapa banyak yg di kukus, setelah daun pisangnya melayu berarti sudah matang. Angkat tiriskan, sediakan nasi putih siap di hidangkan 😋"
categories:
- Resep
tags:
- pepes
- ayam

katakunci: pepes ayam 
nutrition: 156 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Pepes Ayam](https://img-global.cpcdn.com/recipes/07a6052732988e1d/680x482cq70/pepes-ayam-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan hidangan mantab pada orang tercinta adalah suatu hal yang sangat menyenangkan untuk kamu sendiri. Peran seorang ibu Tidak cuma menjaga rumah saja, tetapi kamu juga wajib menyediakan kebutuhan gizi terpenuhi dan santapan yang dikonsumsi anak-anak mesti lezat.

Di zaman  sekarang, anda memang dapat memesan santapan siap saji tidak harus susah membuatnya dulu. Tapi ada juga orang yang memang mau memberikan hidangan yang terbaik bagi orang tercintanya. Karena, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai kesukaan keluarga tercinta. 



Apakah anda salah satu penyuka pepes ayam?. Asal kamu tahu, pepes ayam adalah hidangan khas di Nusantara yang sekarang digemari oleh banyak orang di berbagai tempat di Indonesia. Kita bisa memasak pepes ayam sendiri di rumah dan pasti jadi hidangan favoritmu di akhir pekanmu.

Kalian tidak perlu bingung untuk menyantap pepes ayam, lantaran pepes ayam tidak sukar untuk didapatkan dan kita pun dapat memasaknya sendiri di tempatmu. pepes ayam dapat dibuat dengan beraneka cara. Sekarang ada banyak resep kekinian yang menjadikan pepes ayam semakin lezat.

Resep pepes ayam juga mudah sekali dibuat, lho. Anda tidak usah capek-capek untuk memesan pepes ayam, lantaran Kita dapat menyajikan ditempatmu. Bagi Kamu yang akan mencobanya, berikut ini cara membuat pepes ayam yang lezat yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Pepes Ayam:

1. Gunakan 1 kg daging ayam
1. Sediakan 9 daun salam
1. Gunakan 3 batang sereh
1. Gunakan 6 cm lengkuas
1. Siapkan 1 buah tomat merah / 3 buah asam jawa
1. Ambil 9 cabai rawit (jika suka pedas cabenya dapat diiris)
1. Siapkan 3 ikat daun kemangi
1. Siapkan 2 sendok makan garam
1. Sediakan 1 sdt penyedap
1. Ambil 1 sdt gula putih
1. Siapkan 1 gandu gula merah
1. Ambil  Bumbu halus
1. Ambil 8 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Siapkan 6 kemiri
1. Ambil 4 ruas kunyit




<!--inarticleads2-->

##### Langkah-langkah membuat Pepes Ayam:

1. Bersihkan semua bahan, keringkan ayam dengan tisu sehingga nanti saat di kukus tdk mengeluarkan air banyak. kemudian haluskan semua bumbu denhan ulekan bisa juga di blender. Iris sereh, lengkuas, dan tomat
1. Panaskan wajan anti lengket, tumis bumbu halus dengan lengkuas dan daun salam hingga wangi. Setelah wangi masukkan bumbu kedalam ayam aduk merata
1. Kemudian masukkan penyedap, gula, garam dan irisan gula merah aduk merata cicipi dahulunya disini.
1. Setelah bumbu sudah pas masukkan kemangi, sereh, cabai, dan tomat. Kemudian susun ayam kedalam daun pisang yg sudah di lakuyukan terlebih dahulu
1. Kukus kurleb 45menit tergantung seberapa banyak yg di kukus, setelah daun pisangnya melayu berarti sudah matang. Angkat tiriskan, sediakan nasi putih siap di hidangkan 😋




Wah ternyata cara membuat pepes ayam yang lezat tidak rumit ini gampang banget ya! Semua orang bisa membuatnya. Cara Membuat pepes ayam Sangat cocok banget untuk kita yang baru belajar memasak atau juga untuk kalian yang telah pandai memasak.

Tertarik untuk mulai mencoba membikin resep pepes ayam mantab tidak ribet ini? Kalau anda mau, ayo kamu segera menyiapkan alat-alat dan bahannya, kemudian buat deh Resep pepes ayam yang mantab dan tidak rumit ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang kalian diam saja, maka kita langsung saja buat resep pepes ayam ini. Dijamin kamu gak akan nyesel sudah buat resep pepes ayam lezat tidak rumit ini! Selamat mencoba dengan resep pepes ayam mantab sederhana ini di tempat tinggal kalian masing-masing,oke!.

