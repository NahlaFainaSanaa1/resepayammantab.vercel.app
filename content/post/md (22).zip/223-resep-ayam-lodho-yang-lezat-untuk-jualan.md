---
description: "Resep Ayam Lodho yang lezat Untuk Jualan"
title: "Resep Ayam Lodho yang lezat Untuk Jualan"
slug: 223-resep-ayam-lodho-yang-lezat-untuk-jualan
date: 2021-04-09T20:23:17.940Z
image: https://img-global.cpcdn.com/recipes/46fae7764f4fb241/680x482cq70/ayam-lodho-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/46fae7764f4fb241/680x482cq70/ayam-lodho-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/46fae7764f4fb241/680x482cq70/ayam-lodho-foto-resep-utama.jpg
author: Jon Mitchell
ratingvalue: 4.9
reviewcount: 5
recipeingredient:
- "1 dada ayam kampung utuhbelah tanpa putus"
- "65 ml santan kental"
- " Bumbu halus "
- "7 buah bawang merah"
- "2 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1/2 kelingking kencur"
- "7 buah cabe rawit"
- "1/2 sdm ketumbar"
- "1/2 sdt jinten"
- "1 sdt lada bubuk"
- "1 sdt garam"
- "1 sdt gula jawa"
- "1 sdt kaldu bubuk"
- " Bumbu utuh "
- "5 lembar daun jeruk"
- "2 batang seraigeprek"
- "2 lembar daun salam"
- "1 ruas lengkuasgeprek"
- " Tambahan dan pelengkap "
- " Bawang merah gorenguntuk taburan"
- "1 genggam cabe rawit utuhsesuai selera"
recipeinstructions:
- "Cuci bersih dada ayam.lalu panggang dalam pan dada ayam hingga setengah matang,sisihkan.uleg jinten dan ketumbar utuh.lalu haluskan bumbu halus beserta ketumbar dan jinten tadi hingga benar²halus(bisa diblender atau dichooper)"
- "Tumis bumbu halus dan bumbu utuh hingga harum dan tanak.masukkan dada ayam yang sudah dibakar tadi,beri air secukupnya rebus hingga ayam lunak.bumbui gula jawa,garam dan kaldu bubuk.tes rasa,masak hingga bumbu meresap kedalam dada ayam."
- "Pindahkan dada ayam dalam panci rebus hingga empuk.masukkan cabe rawit utuh dan tambahkan santan kental aduk rata.lalu masak kembali hingga kuah menyusut dan dada ayam empuk matang sempurna.sajikan dengan pendamping nasi putih hangat dan taburan bawang merah goreng.selamat mencoba🙏😋"
categories:
- Resep
tags:
- ayam
- lodho

katakunci: ayam lodho 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Lodho](https://img-global.cpcdn.com/recipes/46fae7764f4fb241/680x482cq70/ayam-lodho-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyajikan santapan nikmat buat keluarga tercinta merupakan suatu hal yang memuaskan bagi anda sendiri. Tugas seorang istri Tidak saja menangani rumah saja, namun anda juga harus memastikan kebutuhan gizi tercukupi dan olahan yang dikonsumsi orang tercinta harus sedap.

Di era  saat ini, kalian memang dapat memesan masakan yang sudah jadi meski tidak harus susah memasaknya dulu. Tetapi ada juga mereka yang memang ingin menghidangkan yang terbaik bagi orang tercintanya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan makanan kesukaan famili. 



Mungkinkah anda adalah seorang penyuka ayam lodho?. Asal kamu tahu, ayam lodho merupakan makanan khas di Nusantara yang saat ini disukai oleh banyak orang di hampir setiap wilayah di Nusantara. Anda dapat memasak ayam lodho sendiri di rumahmu dan boleh dijadikan santapan kesukaanmu di akhir pekanmu.

Kalian tak perlu bingung untuk menyantap ayam lodho, karena ayam lodho mudah untuk didapatkan dan juga kamu pun boleh mengolahnya sendiri di tempatmu. ayam lodho boleh dimasak dengan bermacam cara. Kini telah banyak banget cara modern yang membuat ayam lodho lebih enak.

Resep ayam lodho juga sangat gampang dibikin, lho. Kamu tidak perlu ribet-ribet untuk memesan ayam lodho, sebab Kita bisa membuatnya di rumahmu. Bagi Kita yang akan mencobanya, berikut resep membuat ayam lodho yang lezat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Lodho:

1. Ambil 1 dada ayam kampung utuh,belah tanpa putus
1. Siapkan 65 ml santan kental
1. Sediakan  Bumbu halus :
1. Sediakan 7 buah bawang merah
1. Ambil 2 siung bawang putih
1. Siapkan 1 ruas jahe
1. Gunakan 1 ruas kunyit
1. Siapkan 1/2 kelingking kencur
1. Sediakan 7 buah cabe rawit
1. Ambil 1/2 sdm ketumbar
1. Ambil 1/2 sdt jinten
1. Ambil 1 sdt lada bubuk
1. Gunakan 1 sdt garam
1. Ambil 1 sdt gula jawa
1. Ambil 1 sdt kaldu bubuk
1. Ambil  Bumbu utuh :
1. Ambil 5 lembar daun jeruk
1. Ambil 2 batang serai,geprek
1. Sediakan 2 lembar daun salam
1. Sediakan 1 ruas lengkuas,geprek
1. Gunakan  Tambahan dan pelengkap :
1. Siapkan  Bawang merah goreng,untuk taburan
1. Ambil 1 genggam cabe rawit utuh(sesuai selera)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Lodho:

1. Cuci bersih dada ayam.lalu panggang dalam pan dada ayam hingga setengah matang,sisihkan.uleg jinten dan ketumbar utuh.lalu haluskan bumbu halus beserta ketumbar dan jinten tadi hingga benar²halus(bisa diblender atau dichooper)
1. Tumis bumbu halus dan bumbu utuh hingga harum dan tanak.masukkan dada ayam yang sudah dibakar tadi,beri air secukupnya rebus hingga ayam lunak.bumbui gula jawa,garam dan kaldu bubuk.tes rasa,masak hingga bumbu meresap kedalam dada ayam.
1. Pindahkan dada ayam dalam panci rebus hingga empuk.masukkan cabe rawit utuh dan tambahkan santan kental aduk rata.lalu masak kembali hingga kuah menyusut dan dada ayam empuk matang sempurna.sajikan dengan pendamping nasi putih hangat dan taburan bawang merah goreng.selamat mencoba🙏😋




Wah ternyata cara buat ayam lodho yang enak tidak ribet ini gampang banget ya! Anda Semua bisa memasaknya. Cara buat ayam lodho Sangat sesuai banget buat kita yang baru mau belajar memasak ataupun juga bagi kalian yang sudah hebat dalam memasak.

Apakah kamu ingin mulai mencoba membuat resep ayam lodho mantab sederhana ini? Kalau kamu ingin, mending kamu segera siapin alat dan bahannya, lalu buat deh Resep ayam lodho yang lezat dan simple ini. Benar-benar taidak sulit kan. 

Jadi, daripada kamu diam saja, yuk kita langsung saja hidangkan resep ayam lodho ini. Pasti kalian gak akan menyesal sudah buat resep ayam lodho lezat tidak ribet ini! Selamat berkreasi dengan resep ayam lodho nikmat sederhana ini di rumah masing-masing,ya!.

