---
description: "Resep Ayam Lodho yang nikmat Untuk Jualan"
title: "Resep Ayam Lodho yang nikmat Untuk Jualan"
slug: 210-resep-ayam-lodho-yang-nikmat-untuk-jualan
date: 2021-04-10T13:15:29.502Z
image: https://img-global.cpcdn.com/recipes/f3919801146d6f71/680x482cq70/ayam-lodho-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f3919801146d6f71/680x482cq70/ayam-lodho-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f3919801146d6f71/680x482cq70/ayam-lodho-foto-resep-utama.jpg
author: Bryan Wilson
ratingvalue: 3.3
reviewcount: 13
recipeingredient:
- "1 ekor ayam kampung"
- "2 bks santan instan"
- "Secukupnya air"
- " Bumbu halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1/2 ruas kencur"
- "1 sdm ketumbar"
- "1 sdt merica"
- "1/2 sdt jintan"
- "6 cabe rawit"
- " Bumbu Cemplung"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "2 batang serai"
- "1 ruas lengkuas geprek"
- "15 cabe rawit"
recipeinstructions:
- "Potong ayam kemudian cuci bersih kemudian rebus ayam sampai mendidih atau setengah matang lalu angkat dan tiriskan (jgn buah air kaldu rebusan nya)"
- "Setelah ayam ditiskan, panaskan telfon anti lengket kemudian panggan ayam hingga sedikit berubah warna kecoklatan kemudian angkat dan sisihkan"
- "Siapkan bahan bumbu halus, kemudian tumis dengan sedikit minyak tambahkan daun salam, daun jeruk, serai dan juga lengkuas. Masak hingga bumbu harum dan matang"
- "Masukkan ayam yg sudah dipanggang tadi kedalam panci kaldu ayam, masukkan bumbu yg sudah ditumis tadi kemudian masak hingga air surut dan ayam empuk (jika air surut ayam belum empuk boleh ditambahkan air lagi)"
- "Setelah ayam empuk dan air surut masukkan santan, gula, garam, dan juga kaldu jamur aduk rata kemudian koreksi rasa. Terakhir masukkan cabe rawit danasak hinggae mendidih (aku masak hingga kuahnya tinggal dikit)"
- "Ayam lodho siap dinikmati 😉 untuk yg suka pedas cabe boleh ditambah ya 🤭"
categories:
- Resep
tags:
- ayam
- lodho

katakunci: ayam lodho 
nutrition: 199 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Lodho](https://img-global.cpcdn.com/recipes/f3919801146d6f71/680x482cq70/ayam-lodho-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan hidangan enak untuk keluarga merupakan hal yang sangat menyenangkan bagi kita sendiri. Tanggung jawab seorang  wanita bukan cuma mengurus rumah saja, namun kamu pun wajib memastikan keperluan nutrisi terpenuhi dan juga masakan yang dikonsumsi orang tercinta harus nikmat.

Di era  saat ini, kamu memang bisa mengorder hidangan jadi walaupun tidak harus repot membuatnya dahulu. Tapi banyak juga mereka yang selalu mau menyajikan yang terenak untuk keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut berdasarkan kesukaan orang tercinta. 



Mungkinkah anda salah satu penggemar ayam lodho?. Tahukah kamu, ayam lodho adalah makanan khas di Indonesia yang kini disukai oleh banyak orang di berbagai daerah di Indonesia. Anda dapat menghidangkan ayam lodho sendiri di rumah dan dapat dijadikan camilan kesenanganmu di akhir pekan.

Anda jangan bingung untuk menyantap ayam lodho, sebab ayam lodho mudah untuk didapatkan dan kamu pun dapat menghidangkannya sendiri di rumah. ayam lodho boleh dibuat memalui beraneka cara. Kini pun sudah banyak banget cara modern yang menjadikan ayam lodho lebih enak.

Resep ayam lodho juga sangat gampang dibuat, lho. Kamu jangan capek-capek untuk memesan ayam lodho, lantaran Anda dapat menyiapkan di rumah sendiri. Bagi Anda yang ingin menyajikannya, berikut ini cara untuk membuat ayam lodho yang enak yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Lodho:

1. Sediakan 1 ekor ayam kampung
1. Ambil 2 bks santan instan
1. Gunakan Secukupnya air
1. Ambil  Bumbu halus
1. Gunakan 10 siung bawang merah
1. Ambil 5 siung bawang putih
1. Gunakan 1 ruas kunyit
1. Sediakan 1 ruas jahe
1. Ambil 1/2 ruas kencur
1. Gunakan 1 sdm ketumbar
1. Sediakan 1 sdt merica
1. Gunakan 1/2 sdt jintan
1. Gunakan 6 cabe rawit
1. Ambil  Bumbu Cemplung
1. Siapkan 3 lembar daun salam
1. Gunakan 3 lembar daun jeruk
1. Siapkan 2 batang serai
1. Sediakan 1 ruas lengkuas geprek
1. Sediakan 15 cabe rawit




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Lodho:

1. Potong ayam kemudian cuci bersih kemudian rebus ayam sampai mendidih atau setengah matang lalu angkat dan tiriskan (jgn buah air kaldu rebusan nya)
1. Setelah ayam ditiskan, panaskan telfon anti lengket kemudian panggan ayam hingga sedikit berubah warna kecoklatan kemudian angkat dan sisihkan
1. Siapkan bahan bumbu halus, kemudian tumis dengan sedikit minyak tambahkan daun salam, daun jeruk, serai dan juga lengkuas. Masak hingga bumbu harum dan matang
1. Masukkan ayam yg sudah dipanggang tadi kedalam panci kaldu ayam, masukkan bumbu yg sudah ditumis tadi kemudian masak hingga air surut dan ayam empuk (jika air surut ayam belum empuk boleh ditambahkan air lagi)
1. Setelah ayam empuk dan air surut masukkan santan, gula, garam, dan juga kaldu jamur aduk rata kemudian koreksi rasa. Terakhir masukkan cabe rawit danasak hinggae mendidih (aku masak hingga kuahnya tinggal dikit)
1. Ayam lodho siap dinikmati 😉 untuk yg suka pedas cabe boleh ditambah ya 🤭
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Lodho">



Ternyata cara membuat ayam lodho yang mantab sederhana ini enteng sekali ya! Anda Semua dapat mencobanya. Cara Membuat ayam lodho Cocok sekali buat kalian yang baru belajar memasak maupun juga untuk anda yang telah lihai memasak.

Tertarik untuk mulai mencoba membuat resep ayam lodho nikmat sederhana ini? Kalau kamu ingin, ayo kalian segera siapin peralatan dan bahannya, maka buat deh Resep ayam lodho yang nikmat dan simple ini. Sangat gampang kan. 

Jadi, ketimbang kita berlama-lama, ayo kita langsung hidangkan resep ayam lodho ini. Pasti kamu tiidak akan menyesal bikin resep ayam lodho mantab simple ini! Selamat mencoba dengan resep ayam lodho nikmat tidak ribet ini di tempat tinggal sendiri,ya!.

