---
description: "Cara buat Ayam Asam Manis yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Asam Manis yang enak dan Mudah Dibuat"
slug: 325-cara-buat-ayam-asam-manis-yang-enak-dan-mudah-dibuat
date: 2021-02-13T21:08:37.899Z
image: https://img-global.cpcdn.com/recipes/c92e66cb9c65e854/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c92e66cb9c65e854/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c92e66cb9c65e854/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Amanda Estrada
ratingvalue: 4.7
reviewcount: 6
recipeingredient:
- "1/2 dada ayam fillet"
- "2 buah wortel"
- "1 buah kembang kol"
- "500 gr tepung kobe me"
- " Bahan untuk saos "
- "1 sdm teriyaki"
- "3 siung bawang putih"
- "1 sdt garam"
- "5 sdt gula"
- "1 sdm penyedap rasa larutkan dengan air 250ml"
- "1/2 sdt merica"
- "1/2 sdt maizena"
- "1/2 buah bombay"
- "Secukupnya saos tomat"
- "3 sdm margarin"
recipeinstructions:
- "Potong dan cuci dada ayam menjadi dadu, kemudian marinasi dengan garam terlebih dulu +/- 10 menit"
- "Potong dan cuci semua sayuran"
- "Baluri ayam dengan tepung hingga berselimut"
- "Panaskan minyak dan goreng ayam tepung hingga matang golden brown (deep fry)"
- "Jika ayam sudah matang sisihkan terlebih dulu"
- "Untuk saosnya : geprek dan cincang bawang putih dan potong tipis bawang bombay lalu tumis dengan margarin sampai harum"
- "Masukkan larutan penyedap rasa, aduk dan tunggu hingga mendidih"
- "Masukkan : teriyaki, garam, gula, dan merica"
- "Tambahkan sayuran, masak hingga matang"
- "Masukkan saos tomat sesuai selera, cek rasa"
- "Masukkan ayam tepung lalu aduk merata"
- "Tuang dan aduk larutan maizena"
- "Ready to serve✨"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 229 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/c92e66cb9c65e854/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan hidangan mantab buat keluarga merupakan suatu hal yang sangat menyenangkan bagi anda sendiri. Tugas seorang ibu bukan sekadar mengerjakan pekerjaan rumah saja, tetapi kamu juga harus memastikan kebutuhan gizi terpenuhi dan juga panganan yang dikonsumsi keluarga tercinta harus sedap.

Di era  sekarang, anda sebenarnya mampu membeli santapan instan meski tidak harus repot membuatnya dulu. Tapi ada juga lho mereka yang selalu ingin memberikan hidangan yang terbaik bagi keluarganya. Karena, menyajikan masakan sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga. 



Mungkinkah anda seorang penyuka ayam asam manis?. Tahukah kamu, ayam asam manis adalah makanan khas di Nusantara yang sekarang digemari oleh kebanyakan orang di berbagai wilayah di Indonesia. Kamu dapat membuat ayam asam manis sendiri di rumahmu dan dapat dijadikan camilan favoritmu di hari libur.

Kalian jangan bingung jika kamu ingin mendapatkan ayam asam manis, lantaran ayam asam manis tidak sukar untuk dicari dan juga kalian pun bisa memasaknya sendiri di rumah. ayam asam manis bisa diolah lewat beraneka cara. Saat ini telah banyak resep modern yang membuat ayam asam manis lebih nikmat.

Resep ayam asam manis pun sangat mudah dihidangkan, lho. Kamu tidak perlu ribet-ribet untuk membeli ayam asam manis, karena Anda dapat menghidangkan ditempatmu. Untuk Kamu yang mau menyajikannya, di bawah ini adalah cara untuk menyajikan ayam asam manis yang nikamat yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Asam Manis:

1. Ambil 1/2 dada ayam fillet
1. Ambil 2 buah wortel
1. Ambil 1 buah kembang kol
1. Sediakan 500 gr tepung kobe (me)
1. Sediakan  Bahan untuk saos :
1. Ambil 1 sdm teriyaki
1. Ambil 3 siung bawang putih
1. Ambil 1 sdt garam
1. Siapkan 5 sdt gula
1. Ambil 1 sdm penyedap rasa (larutkan dengan air 250ml)
1. Sediakan 1/2 sdt merica
1. Sediakan 1/2 sdt maizena
1. Sediakan 1/2 buah bombay
1. Gunakan Secukupnya saos tomat
1. Gunakan 3 sdm margarin




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Asam Manis:

1. Potong dan cuci dada ayam menjadi dadu, kemudian marinasi dengan garam terlebih dulu +/- 10 menit
1. Potong dan cuci semua sayuran
1. Baluri ayam dengan tepung hingga berselimut
1. Panaskan minyak dan goreng ayam tepung hingga matang golden brown (deep fry)
1. Jika ayam sudah matang sisihkan terlebih dulu
1. Untuk saosnya : geprek dan cincang bawang putih dan potong tipis bawang bombay lalu tumis dengan margarin sampai harum
1. Masukkan larutan penyedap rasa, aduk dan tunggu hingga mendidih
1. Masukkan : teriyaki, garam, gula, dan merica
1. Tambahkan sayuran, masak hingga matang
1. Masukkan saos tomat sesuai selera, cek rasa
1. Masukkan ayam tepung lalu aduk merata
1. Tuang dan aduk larutan maizena
1. Ready to serve✨




Ternyata resep ayam asam manis yang enak tidak rumit ini gampang banget ya! Anda Semua dapat menghidangkannya. Resep ayam asam manis Sangat sesuai banget buat anda yang baru mau belajar memasak maupun untuk kalian yang telah ahli dalam memasak.

Apakah kamu ingin mulai mencoba buat resep ayam asam manis nikmat tidak ribet ini? Kalau kalian mau, ayo kamu segera siapkan alat dan bahannya, lalu buat deh Resep ayam asam manis yang enak dan simple ini. Betul-betul taidak sulit kan. 

Jadi, ketimbang kamu diam saja, maka kita langsung saja sajikan resep ayam asam manis ini. Dijamin kalian tiidak akan menyesal membuat resep ayam asam manis enak simple ini! Selamat berkreasi dengan resep ayam asam manis nikmat simple ini di rumah sendiri,oke!.

