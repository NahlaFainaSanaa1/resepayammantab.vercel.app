---
description: "Cara buat Ayam Asam Manis yang enak Untuk Jualan"
title: "Cara buat Ayam Asam Manis yang enak Untuk Jualan"
slug: 331-cara-buat-ayam-asam-manis-yang-enak-untuk-jualan
date: 2021-06-01T22:17:39.734Z
image: https://img-global.cpcdn.com/recipes/9c7e0871fe15cb29/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9c7e0871fe15cb29/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9c7e0871fe15cb29/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Loretta Garner
ratingvalue: 3.8
reviewcount: 15
recipeingredient:
- "500 gr paha ayam fillet potong dadu"
- "1/2 sdm bawang putih bubuk"
- "1 sdm kecap asin"
- "4 sdm maizena"
- "1 bh wortel ukuran kecil iris korek api"
- "1/2 bh ketimun buang biji iris memanjang"
- "1/4 bh nenas iris kecil2"
- "1/4 bh paprika merah iris memanjang"
- "200 ml air"
- " Minyak goreng secukupnya untuk menggoreng dan menumis"
- " Bumbu Tumis "
- "3 sg bawang putih cincang"
- "1/2 bh bawang bombay iris2"
- " Bahan Saus "
- "5 ssm saus tomat"
- "2 sdm saus cabe"
- "1 sdm cuka apel"
- "1/2 sdt merica bubuk"
- " Bahan Pengental  larutkan"
- "2 sdt maizena"
- "20 ml air"
recipeinstructions:
- "Lumuri ayam dengan bawang putih bubuk, kecap asin dan maizena"
- "Panaskan minyak agak banyak. Goreng ayam sampai matang dan berwarna kekuningan. Angkat. Sisihkan"
- "Panaskan 3 sdm minyak goreng. Masukkan bumbu tumis. Aduk sampai harum."
- "Maaukkan wortel. Aduk sebentar. Masukkan paprika dan ketimun. Aduk kembali. Lalu maaukkan nenas."
- "Tuang bahan saus dan air. Masak sampai bahan agak layu. Berikan garam, gula pasir, kaldu bubuk."
- "Maaukkan bahan pengental. Aduk rata. Masukkan ayam. Aduk kembali sampai rata. Angkat"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 274 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/9c7e0871fe15cb29/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyuguhkan masakan enak pada keluarga tercinta adalah suatu hal yang sangat menyenangkan bagi anda sendiri. Tugas seorang  wanita Tidak cuman mengatur rumah saja, tetapi kamu pun harus menyediakan kebutuhan gizi tercukupi dan panganan yang dimakan keluarga tercinta harus menggugah selera.

Di zaman  sekarang, kamu memang dapat mengorder panganan praktis meski tidak harus susah memasaknya dahulu. Tetapi banyak juga lho orang yang selalu mau memberikan hidangan yang terenak bagi orang tercintanya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga. 



Apakah kamu seorang penggemar ayam asam manis?. Tahukah kamu, ayam asam manis adalah makanan khas di Indonesia yang saat ini disenangi oleh orang-orang dari berbagai tempat di Nusantara. Kamu dapat menghidangkan ayam asam manis sendiri di rumah dan pasti jadi camilan kesenanganmu di hari liburmu.

Kita tak perlu bingung untuk mendapatkan ayam asam manis, lantaran ayam asam manis mudah untuk didapatkan dan juga kamu pun boleh membuatnya sendiri di rumah. ayam asam manis dapat dimasak dengan bermacam cara. Kini pun telah banyak sekali cara kekinian yang membuat ayam asam manis semakin lebih lezat.

Resep ayam asam manis juga sangat gampang dibikin, lho. Kita jangan ribet-ribet untuk membeli ayam asam manis, lantaran Kamu dapat menyiapkan di rumahmu. Untuk Kita yang akan menghidangkannya, di bawah ini adalah cara untuk menyajikan ayam asam manis yang enak yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Asam Manis:

1. Ambil 500 gr paha ayam fillet, potong dadu
1. Siapkan 1/2 sdm bawang putih bubuk
1. Gunakan 1 sdm kecap asin
1. Sediakan 4 sdm maizena
1. Ambil 1 bh wortel ukuran kecil, iris korek api
1. Sediakan 1/2 bh ketimun, buang biji, iris memanjang
1. Gunakan 1/4 bh nenas, iris kecil2
1. Sediakan 1/4 bh paprika merah, iris memanjang
1. Siapkan 200 ml air
1. Ambil  Minyak goreng secukupnya untuk menggoreng dan menumis
1. Siapkan  Bumbu Tumis :
1. Gunakan 3 sg bawang putih, cincang
1. Sediakan 1/2 bh bawang bombay, iris2
1. Ambil  Bahan Saus :
1. Ambil 5 ssm saus tomat
1. Gunakan 2 sdm saus cabe
1. Ambil 1 sdm cuka apel
1. Ambil 1/2 sdt merica bubuk
1. Gunakan  Bahan Pengental : (larutkan)
1. Sediakan 2 sdt maizena
1. Ambil 20 ml air




<!--inarticleads2-->

##### Cara membuat Ayam Asam Manis:

1. Lumuri ayam dengan bawang putih bubuk, kecap asin dan maizena
1. Panaskan minyak agak banyak. Goreng ayam sampai matang dan berwarna kekuningan. Angkat. Sisihkan
1. Panaskan 3 sdm minyak goreng. Masukkan bumbu tumis. Aduk sampai harum.
1. Maaukkan wortel. Aduk sebentar. Masukkan paprika dan ketimun. Aduk kembali. Lalu maaukkan nenas.
1. Tuang bahan saus dan air. Masak sampai bahan agak layu. Berikan garam, gula pasir, kaldu bubuk.
1. Maaukkan bahan pengental. Aduk rata. Masukkan ayam. Aduk kembali sampai rata. Angkat




Wah ternyata cara buat ayam asam manis yang nikamt sederhana ini enteng banget ya! Semua orang dapat memasaknya. Cara Membuat ayam asam manis Sangat cocok sekali buat anda yang baru belajar memasak atau juga untuk anda yang telah ahli dalam memasak.

Tertarik untuk mencoba bikin resep ayam asam manis lezat tidak ribet ini? Kalau kalian ingin, ayo kamu segera siapin alat-alat dan bahannya, kemudian bikin deh Resep ayam asam manis yang lezat dan tidak rumit ini. Benar-benar mudah kan. 

Maka dari itu, ketimbang kamu berfikir lama-lama, maka langsung aja hidangkan resep ayam asam manis ini. Pasti kamu tiidak akan nyesel bikin resep ayam asam manis lezat tidak ribet ini! Selamat mencoba dengan resep ayam asam manis lezat tidak ribet ini di rumah sendiri,oke!.

