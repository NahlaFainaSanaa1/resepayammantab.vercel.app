---
description: "Bahan-bahan Ayam Asam Manis Khas Banjar Sederhana Untuk Jualan"
title: "Bahan-bahan Ayam Asam Manis Khas Banjar Sederhana Untuk Jualan"
slug: 334-bahan-bahan-ayam-asam-manis-khas-banjar-sederhana-untuk-jualan
date: 2021-06-21T10:41:56.763Z
image: https://img-global.cpcdn.com/recipes/cf47e801e99db32b/680x482cq70/ayam-asam-manis-khas-banjar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cf47e801e99db32b/680x482cq70/ayam-asam-manis-khas-banjar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cf47e801e99db32b/680x482cq70/ayam-asam-manis-khas-banjar-foto-resep-utama.jpg
author: Grace Banks
ratingvalue: 4.3
reviewcount: 10
recipeingredient:
- "500 gr ayam bagian paha potongpotong jadi beberapa bagian"
- "1/2 buah jeruk nipis ambil airnya saja"
- "3 buah cabe merah besar iris serong"
- "3 buah cabe hijau besar iris serong"
- "2 sdm kecap manis"
- "2 sdm saos tomat"
- "2 sdm air asam Jawa pekat"
- "150 ml air"
- "Secukupnya garam dan kaldu bubuk me Royco"
- "Secukupnya minyak goreng untuk menumis"
- " Bumbu Marinasi Ayam"
- "1 sdt garam"
- "2 sdm saos tomat"
- " Bumbu Tumis"
- "6 siung bawang merah iris tipis"
- "5 siung bawang putih iris tipis"
- "1/2 buah bawang bombai irisiris"
- " Bumbu Halus"
- "4 buah tomat"
- "125 gr gula merah"
recipeinstructions:
- "Siapkan bahan yang akan digunakan"
- "Cuci baju ayam, berikan perasan air jeruk nipis, diamkan 10-15 menit agar tidak bau amis, lalu bilas kembali."
- "Tambahkan bumbu marinasi (garam dan saos tomat), aduk rata, diamkan selama 15 menit."
- "Sambil menunggu ayamnya di marinasi, rajang/iris-iris bumbu yang akan digunakan, dan blender bumbu halus, sisihkan"
- "Setelah 15 menit kemudian, goreng ayam setengah matang, angkat dan tiriskan, sisihkan"
- "Panaskan secukupnya minyak goreng, tumis bawang merah, bawang putih, bawang bombai hingga wangi"
- "Kemudian masukkan bumbu halus, aduk rata. Tambahkan air, saos tomat, kecap, secukupnya garam dan kaldu bubuk (me. royco ayam), aduk rata. Koreksi rasa. (Note. Garam dan kaldu bubuk dimasukkan dikit aja dulu ya, nanti bisa ditambahkan lagi sebelum diangkat, agar tidak asin)"
- "Lalu masukkan ayam yang telah di goreng setengah matang, irisan cabe merah dan cabe hijau. Aduk rata. Masak hingga ayam matang, bumbunya meresap dan kuahnya menyusut tinggal sedikit dan agak kental. Sesekali diaduk-aduk dalam proses memasaknya. Sebelum diangkat, koreksi rasa terlebih dahulu. (Jika masih ada yang kuran boleh ditambahkan lagi secukupnya garam dan kaldu bubuk), jika sudah rasanya pas, angkat dan sajikan"
- "Ayam Asam Manis Khas Banjar siap disajikan 😊"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 206 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Asam Manis Khas Banjar](https://img-global.cpcdn.com/recipes/cf47e801e99db32b/680x482cq70/ayam-asam-manis-khas-banjar-foto-resep-utama.jpg)

Sebagai seorang wanita, menyuguhkan masakan sedap bagi orang tercinta adalah hal yang mengasyikan bagi kita sendiri. Tugas seorang istri bukan cuman mengatur rumah saja, tetapi kamu pun wajib menyediakan keperluan gizi tercukupi dan juga masakan yang dikonsumsi keluarga tercinta harus nikmat.

Di era  saat ini, kalian sebenarnya mampu mengorder hidangan jadi meski tanpa harus capek membuatnya terlebih dahulu. Tapi banyak juga lho mereka yang memang mau memberikan hidangan yang terenak untuk orang tercintanya. Pasalnya, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan selera famili. 



Apakah kamu salah satu penikmat ayam asam manis khas banjar?. Asal kamu tahu, ayam asam manis khas banjar merupakan hidangan khas di Indonesia yang saat ini disenangi oleh orang-orang dari hampir setiap daerah di Nusantara. Anda dapat menyajikan ayam asam manis khas banjar sendiri di rumahmu dan boleh jadi santapan kesenanganmu di hari libur.

Kita tidak usah bingung jika kamu ingin menyantap ayam asam manis khas banjar, lantaran ayam asam manis khas banjar sangat mudah untuk dicari dan kalian pun boleh memasaknya sendiri di tempatmu. ayam asam manis khas banjar dapat dibuat lewat beraneka cara. Sekarang telah banyak banget cara modern yang menjadikan ayam asam manis khas banjar semakin lebih nikmat.

Resep ayam asam manis khas banjar pun mudah sekali untuk dibuat, lho. Anda tidak usah ribet-ribet untuk membeli ayam asam manis khas banjar, karena Anda bisa menghidangkan sendiri di rumah. Bagi Kamu yang mau membuatnya, berikut ini cara membuat ayam asam manis khas banjar yang nikamat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Asam Manis Khas Banjar:

1. Gunakan 500 gr ayam bagian paha, potong-potong jadi beberapa bagian
1. Gunakan 1/2 buah jeruk nipis, ambil airnya saja
1. Gunakan 3 buah cabe merah besar, iris serong
1. Siapkan 3 buah cabe hijau besar, iris serong
1. Ambil 2 sdm kecap manis
1. Siapkan 2 sdm saos tomat
1. Sediakan 2 sdm air asam Jawa pekat
1. Gunakan 150 ml air
1. Gunakan Secukupnya garam dan kaldu bubuk (me. Royco)
1. Siapkan Secukupnya minyak goreng untuk menumis
1. Siapkan  Bumbu Marinasi Ayam:
1. Siapkan 1 sdt garam
1. Ambil 2 sdm saos tomat
1. Sediakan  Bumbu Tumis:
1. Gunakan 6 siung bawang merah, iris tipis
1. Gunakan 5 siung bawang putih, iris tipis
1. Siapkan 1/2 buah bawang bombai, iris-iris
1. Gunakan  Bumbu Halus:
1. Gunakan 4 buah tomat
1. Ambil 125 gr gula merah




<!--inarticleads2-->

##### Cara membuat Ayam Asam Manis Khas Banjar:

1. Siapkan bahan yang akan digunakan
1. Cuci baju ayam, berikan perasan air jeruk nipis, diamkan 10-15 menit agar tidak bau amis, lalu bilas kembali.
1. Tambahkan bumbu marinasi (garam dan saos tomat), aduk rata, diamkan selama 15 menit.
1. Sambil menunggu ayamnya di marinasi, rajang/iris-iris bumbu yang akan digunakan, dan blender bumbu halus, sisihkan
1. Setelah 15 menit kemudian, goreng ayam setengah matang, angkat dan tiriskan, sisihkan
1. Panaskan secukupnya minyak goreng, tumis bawang merah, bawang putih, bawang bombai hingga wangi
1. Kemudian masukkan bumbu halus, aduk rata. Tambahkan air, saos tomat, kecap, secukupnya garam dan kaldu bubuk (me. royco ayam), aduk rata. Koreksi rasa. (Note. Garam dan kaldu bubuk dimasukkan dikit aja dulu ya, nanti bisa ditambahkan lagi sebelum diangkat, agar tidak asin)
1. Lalu masukkan ayam yang telah di goreng setengah matang, irisan cabe merah dan cabe hijau. Aduk rata. Masak hingga ayam matang, bumbunya meresap dan kuahnya menyusut tinggal sedikit dan agak kental. Sesekali diaduk-aduk dalam proses memasaknya. Sebelum diangkat, koreksi rasa terlebih dahulu. (Jika masih ada yang kuran boleh ditambahkan lagi secukupnya garam dan kaldu bubuk), jika sudah rasanya pas, angkat dan sajikan
1. Ayam Asam Manis Khas Banjar siap disajikan 😊




Ternyata cara buat ayam asam manis khas banjar yang enak sederhana ini mudah sekali ya! Kamu semua bisa mencobanya. Cara buat ayam asam manis khas banjar Sangat sesuai banget untuk anda yang baru mau belajar memasak maupun juga untuk kamu yang telah pandai memasak.

Apakah kamu mau mencoba bikin resep ayam asam manis khas banjar mantab simple ini? Kalau tertarik, ayo kamu segera buruan menyiapkan alat-alat dan bahannya, maka buat deh Resep ayam asam manis khas banjar yang lezat dan tidak ribet ini. Sungguh mudah kan. 

Oleh karena itu, daripada kalian berlama-lama, yuk kita langsung saja buat resep ayam asam manis khas banjar ini. Dijamin kalian gak akan menyesal membuat resep ayam asam manis khas banjar lezat sederhana ini! Selamat mencoba dengan resep ayam asam manis khas banjar enak tidak rumit ini di tempat tinggal kalian sendiri,ya!.

