---
description: "Resep Ayam Asam Manis Nanas yang enak Untuk Jualan"
title: "Resep Ayam Asam Manis Nanas yang enak Untuk Jualan"
slug: 327-resep-ayam-asam-manis-nanas-yang-enak-untuk-jualan
date: 2021-04-05T06:03:38.347Z
image: https://img-global.cpcdn.com/recipes/d8d9b6a948afa933/680x482cq70/ayam-asam-manis-nanas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d8d9b6a948afa933/680x482cq70/ayam-asam-manis-nanas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d8d9b6a948afa933/680x482cq70/ayam-asam-manis-nanas-foto-resep-utama.jpg
author: Eddie Guerrero
ratingvalue: 4
reviewcount: 14
recipeingredient:
- "300 gr dada ayam fillet potong dadu"
- "5 sdm tepung serbaguna"
- "4 sdm tepung maizena"
- "2 sdm tepung serbaguna dilarutkan dalam 150200 ml air"
- "1 bh wortel potong korek api"
- "1 bh bawang bombay ukuran kecil potong"
- "2 siung bawang putih cincang"
- "potong Nanas kupas secukupnya"
- " Bahan saus "
- "3 sdm saus tomat"
- "1 sdm saus sambal"
- "1 sdm kecap asin"
- "1 sdm kecap manis"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- "1 sdt kaldu ayam bubukkaldu jamur"
- "300 ml air"
- "1/2 sdm tepung maizena dilarutkan dlm 2 sdm air"
recipeinstructions:
- "Campur tepung serbaguna dan maizena, sisihkan. Masukkan potongan daging ayam dalam adonan tepung, biarkan 5-10 menit. Panaskan minyak, celupkan ayam dari adonan basah ke adonan tepung kering, lalu goreng hingga matang/kuning kecoklatan, dengan api sedang cenderung kecil."
- "Tumis bawang bombay hingga layu, masukkan bawang putih, tumis hingga harum. Masukkan wortel, nanas, saus dan bumbu lainnya, tambahkan air, koreksi rasanya."
- "Masukkan ayam, aduk rata, masukkan larutan maizena, lalu aduk rata kembali. Siap disajikan."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 243 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Asam Manis Nanas](https://img-global.cpcdn.com/recipes/d8d9b6a948afa933/680x482cq70/ayam-asam-manis-nanas-foto-resep-utama.jpg)

Andai anda seorang wanita, menyuguhkan santapan enak bagi famili adalah suatu hal yang membahagiakan bagi kamu sendiri. Tugas seorang istri bukan cuman mengerjakan pekerjaan rumah saja, namun kamu juga wajib memastikan keperluan gizi tercukupi dan juga masakan yang disantap orang tercinta mesti menggugah selera.

Di zaman  sekarang, anda sebenarnya mampu memesan masakan instan meski tidak harus repot memasaknya dahulu. Tetapi banyak juga orang yang selalu ingin memberikan makanan yang terbaik untuk keluarganya. Pasalnya, menyajikan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai selera famili. 



Apakah anda merupakan seorang penikmat ayam asam manis nanas?. Tahukah kamu, ayam asam manis nanas merupakan hidangan khas di Indonesia yang kini disukai oleh setiap orang dari hampir setiap wilayah di Indonesia. Anda dapat menghidangkan ayam asam manis nanas sendiri di rumahmu dan pasti jadi makanan kesukaanmu di akhir pekanmu.

Anda tidak perlu bingung jika kamu ingin mendapatkan ayam asam manis nanas, sebab ayam asam manis nanas tidak sulit untuk didapatkan dan kalian pun boleh memasaknya sendiri di rumah. ayam asam manis nanas dapat diolah memalui bermacam cara. Sekarang sudah banyak banget cara modern yang menjadikan ayam asam manis nanas semakin lebih nikmat.

Resep ayam asam manis nanas pun sangat gampang dihidangkan, lho. Anda tidak perlu repot-repot untuk membeli ayam asam manis nanas, karena Kita bisa menghidangkan ditempatmu. Bagi Kalian yang mau menyajikannya, berikut ini cara untuk membuat ayam asam manis nanas yang lezat yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Asam Manis Nanas:

1. Sediakan 300 gr dada ayam fillet, potong dadu
1. Sediakan 5 sdm tepung serbaguna
1. Siapkan 4 sdm tepung maizena
1. Ambil 2 sdm tepung serbaguna, dilarutkan dalam 150-200 ml air
1. Gunakan 1 bh wortel, potong korek api
1. Siapkan 1 bh bawang bombay ukuran kecil, potong
1. Siapkan 2 siung bawang putih, cincang
1. Sediakan potong Nanas kupas secukupnya,
1. Ambil  Bahan saus :
1. Gunakan 3 sdm saus tomat
1. Siapkan 1 sdm saus sambal
1. Gunakan 1 sdm kecap asin
1. Ambil 1 sdm kecap manis
1. Gunakan 1/2 sdt lada bubuk
1. Gunakan 1/2 sdt garam
1. Ambil 1 sdt kaldu ayam bubuk/kaldu jamur
1. Gunakan 300 ml air
1. Sediakan 1/2 sdm tepung maizena, dilarutkan dlm 2 sdm air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Asam Manis Nanas:

1. Campur tepung serbaguna dan maizena, sisihkan. Masukkan potongan daging ayam dalam adonan tepung, biarkan 5-10 menit. Panaskan minyak, celupkan ayam dari adonan basah ke adonan tepung kering, lalu goreng hingga matang/kuning kecoklatan, dengan api sedang cenderung kecil.
1. Tumis bawang bombay hingga layu, masukkan bawang putih, tumis hingga harum. Masukkan wortel, nanas, saus dan bumbu lainnya, tambahkan air, koreksi rasanya.
1. Masukkan ayam, aduk rata, masukkan larutan maizena, lalu aduk rata kembali. Siap disajikan.




Wah ternyata cara buat ayam asam manis nanas yang mantab simple ini enteng banget ya! Semua orang mampu menghidangkannya. Cara Membuat ayam asam manis nanas Sangat sesuai banget untuk kalian yang sedang belajar memasak maupun bagi anda yang telah jago memasak.

Apakah kamu ingin mulai mencoba bikin resep ayam asam manis nanas enak tidak ribet ini? Kalau kalian tertarik, ayo kalian segera buruan siapkan alat dan bahan-bahannya, setelah itu buat deh Resep ayam asam manis nanas yang lezat dan tidak rumit ini. Betul-betul gampang kan. 

Maka dari itu, daripada kalian diam saja, yuk kita langsung saja hidangkan resep ayam asam manis nanas ini. Pasti anda gak akan nyesel sudah bikin resep ayam asam manis nanas mantab sederhana ini! Selamat berkreasi dengan resep ayam asam manis nanas lezat tidak ribet ini di tempat tinggal masing-masing,ya!.

