---
description: "Cara buat Ayam Kentucky yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam Kentucky yang nikmat dan Mudah Dibuat"
slug: 42-cara-buat-ayam-kentucky-yang-nikmat-dan-mudah-dibuat
date: 2021-01-16T16:51:48.940Z
image: https://img-global.cpcdn.com/recipes/75b2f79782012857/680x482cq70/ayam-kentucky-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/75b2f79782012857/680x482cq70/ayam-kentucky-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/75b2f79782012857/680x482cq70/ayam-kentucky-foto-resep-utama.jpg
author: Lucinda Olson
ratingvalue: 3.5
reviewcount: 11
recipeingredient:
- " Marinasi"
- "1 Ekor Ayam"
- "1 Biji Jeruk Nipis"
- "1/2 Sachet Ketumbar Bubuk Saya pakai Desaku"
- "1/2 Sachet Kunyit Bubuk Saya pakai Desaku"
- "1/2 Sachet Merica Bubuk Saya pakai Ladaku"
- "1 1/2 Sachet Penyedap Rasa Saya pakai Masako"
- " Bahan Kering"
- "1 kg Tepung Terigu Cakra"
- "1 Bungkus Tepung Serba Guna Saya pakai Sajiku"
- "1 Sachet Penyedap Rasa"
- "1/2 Sachet Ketumbar Bubuk"
- "1/2 Sachet Merica Bubuk"
- " Bahan Basah"
- "Secukupnya Air"
- "Secukupnya Minyak Goreng"
recipeinstructions:
- "Campur perasan jeruk nipis ke Ayam yang sudah di potong²"
- "Diamkan 1/2 jam lalu cuci kembali ayam"
- "Campur semua bahan marinasi, diamkan di kulkas selama 1 jam."
- "Campur semua bahan kering."
- "Kemudian masukan ayam yang sudah di marinasi ke dalam bahan kering aduk pelan"
- "Lalu masukan ke dalam bahan Basah sebentar saja asal basah"
- "Kemudian masukan lagi ke bahan kering, aduk² hingga keriting ayamnya"
- "Goreng di minyak panas dan menggunakan api sedang"
- "Gunakan minyak banyak dan panas agar keritingnya membentuk."
- "Goreng hingga kecoklatan. Angkat. Dan Sajikan."
categories:
- Resep
tags:
- ayam
- kentucky

katakunci: ayam kentucky 
nutrition: 292 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Kentucky](https://img-global.cpcdn.com/recipes/75b2f79782012857/680x482cq70/ayam-kentucky-foto-resep-utama.jpg)

Jika anda seorang yang hobi memasak, menyajikan olahan sedap pada orang tercinta merupakan hal yang memuaskan bagi kamu sendiri. Peran seorang istri Tidak sekadar mengurus rumah saja, tetapi anda pun wajib menyediakan keperluan nutrisi tercukupi dan santapan yang disantap orang tercinta wajib menggugah selera.

Di masa  saat ini, anda sebenarnya dapat memesan santapan siap saji meski tidak harus ribet mengolahnya dulu. Tetapi banyak juga orang yang memang ingin menghidangkan yang terenak untuk keluarganya. Lantaran, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai kesukaan orang tercinta. 



Mungkinkah kamu seorang penikmat ayam kentucky?. Asal kamu tahu, ayam kentucky adalah hidangan khas di Nusantara yang sekarang digemari oleh kebanyakan orang di berbagai tempat di Indonesia. Anda dapat memasak ayam kentucky buatan sendiri di rumahmu dan pasti jadi camilan kesenanganmu di akhir pekanmu.

Kamu jangan bingung untuk menyantap ayam kentucky, sebab ayam kentucky tidak sukar untuk ditemukan dan juga kalian pun bisa menghidangkannya sendiri di rumah. ayam kentucky bisa dibuat lewat beraneka cara. Kini pun sudah banyak cara kekinian yang membuat ayam kentucky semakin lebih lezat.

Resep ayam kentucky juga mudah untuk dibikin, lho. Kamu tidak usah ribet-ribet untuk memesan ayam kentucky, sebab Kalian mampu menghidangkan sendiri di rumah. Untuk Anda yang hendak menyajikannya, berikut ini cara membuat ayam kentucky yang enak yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Kentucky:

1. Siapkan  Marinasi
1. Ambil 1 Ekor Ayam
1. Sediakan 1 Biji Jeruk Nipis
1. Ambil 1/2 Sachet Ketumbar Bubuk (Saya pakai Desaku)
1. Gunakan 1/2 Sachet Kunyit Bubuk (Saya pakai Desaku)
1. Gunakan 1/2 Sachet Merica Bubuk (Saya pakai Ladaku)
1. Siapkan 1 1/2 Sachet Penyedap Rasa (Saya pakai Masako)
1. Ambil  Bahan Kering
1. Ambil 1 kg Tepung Terigu Cakra
1. Siapkan 1 Bungkus Tepung Serba Guna (Saya pakai Sajiku)
1. Sediakan 1 Sachet Penyedap Rasa
1. Gunakan 1/2 Sachet Ketumbar Bubuk
1. Sediakan 1/2 Sachet Merica Bubuk
1. Ambil  Bahan Basah
1. Sediakan Secukupnya Air
1. Gunakan Secukupnya Minyak Goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Kentucky:

1. Campur perasan jeruk nipis ke Ayam yang sudah di potong²
1. Diamkan 1/2 jam lalu cuci kembali ayam
1. Campur semua bahan marinasi, diamkan di kulkas selama 1 jam.
1. Campur semua bahan kering.
1. Kemudian masukan ayam yang sudah di marinasi ke dalam bahan kering aduk pelan
1. Lalu masukan ke dalam bahan Basah sebentar saja asal basah
1. Kemudian masukan lagi ke bahan kering, aduk² hingga keriting ayamnya
1. Goreng di minyak panas dan menggunakan api sedang
1. Gunakan minyak banyak dan panas agar keritingnya membentuk.
1. Goreng hingga kecoklatan. Angkat. Dan Sajikan.




Ternyata cara membuat ayam kentucky yang mantab tidak rumit ini gampang sekali ya! Semua orang mampu mencobanya. Cara Membuat ayam kentucky Sesuai banget untuk kamu yang sedang belajar memasak maupun bagi kalian yang sudah hebat dalam memasak.

Tertarik untuk mencoba membuat resep ayam kentucky enak simple ini? Kalau anda ingin, yuk kita segera siapin peralatan dan bahannya, maka buat deh Resep ayam kentucky yang mantab dan simple ini. Sangat taidak sulit kan. 

Maka, daripada anda berlama-lama, yuk kita langsung bikin resep ayam kentucky ini. Dijamin kamu tiidak akan nyesel sudah buat resep ayam kentucky lezat tidak ribet ini! Selamat mencoba dengan resep ayam kentucky mantab tidak rumit ini di rumah kalian sendiri,ya!.

