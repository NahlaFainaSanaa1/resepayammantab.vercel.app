---
description: "Resep Soto Ayam yang nikmat Untuk Jualan"
title: "Resep Soto Ayam yang nikmat Untuk Jualan"
slug: 175-resep-soto-ayam-yang-nikmat-untuk-jualan
date: 2021-06-14T08:49:33.910Z
image: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Louise McLaughlin
ratingvalue: 4.5
reviewcount: 3
recipeingredient:
- "1 ekor ayam potong 8 bagian"
- "1 sdt ketumbar"
- "2 cm jahe"
- "2 cm lengkuas"
- "2 cm kunyit"
- "15 bawang merah"
- "10 bawang putih"
- "1 sdt merica"
- "5 butir kemiri"
- "100 gr toge"
- "2 bungkus kecil soun"
- "2 batang daun bawang"
- "5 batang seledri"
- "3 daun jeruk 3 daun salam 3 batang sereh"
- " Sambal  15 cabe rawit  2 bawang putih"
- "2 lt air 5 sdm minyak untuk menumis"
- " Garam dan penyedap rasa opsional"
- " Jeruk nipis dipotong kecil2"
recipeinstructions:
- "Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri."
- "Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  Kemudian tambahkan air 1lt.  Tutup panci"
- "Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit."
- "Setelah bumbu meresap, keluarkan ayam dari panci.  Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2."
- "Goreng ayam di minyak panas, tiriskan.  Lalu potong kecil2 / suwir.  Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa."
- "Bahan pelengkap : Potong/iris tipis kol.  Cuci kol dan toge. Lalu di panci lain, rebus air hingga mendidih.  Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. Siapkan di mangkok."
- "Bahan tabur : Potong/iris daun bawang, seledri. Siapkan di piring kecil"
- "Sambal soto : Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal."
- "Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. Silahkan mencoba"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 211 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan olahan sedap bagi famili adalah hal yang membahagiakan untuk kita sendiri. Tugas seorang ibu Tidak hanya mengatur rumah saja, tetapi anda juga wajib menyediakan kebutuhan gizi tercukupi dan juga santapan yang dikonsumsi anak-anak wajib enak.

Di era  saat ini, kita memang dapat mengorder panganan instan walaupun tidak harus ribet mengolahnya terlebih dahulu. Tapi ada juga mereka yang selalu mau memberikan makanan yang terlezat untuk orang tercintanya. Karena, menyajikan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penikmat soto ayam?. Tahukah kamu, soto ayam merupakan hidangan khas di Nusantara yang sekarang digemari oleh orang-orang dari berbagai tempat di Nusantara. Anda dapat menyajikan soto ayam sendiri di rumah dan pasti jadi santapan favoritmu di akhir pekanmu.

Kamu jangan bingung untuk mendapatkan soto ayam, sebab soto ayam tidak sukar untuk ditemukan dan kamu pun bisa membuatnya sendiri di rumah. soto ayam dapat dibuat dengan berbagai cara. Saat ini ada banyak sekali resep modern yang menjadikan soto ayam semakin mantap.

Resep soto ayam juga mudah dibikin, lho. Kalian tidak perlu repot-repot untuk membeli soto ayam, sebab Kita bisa menyajikan di rumah sendiri. Bagi Anda yang hendak membuatnya, inilah resep membuat soto ayam yang nikamat yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto Ayam:

1. Sediakan 1 ekor ayam potong 8 bagian
1. Ambil 1 sdt ketumbar
1. Gunakan 2 cm jahe
1. Ambil 2 cm lengkuas
1. Gunakan 2 cm kunyit
1. Gunakan 15 bawang merah
1. Siapkan 10 bawang putih
1. Siapkan 1 sdt merica
1. Ambil 5 butir kemiri
1. Ambil 100 gr toge
1. Sediakan 2 bungkus kecil soun
1. Sediakan 2 batang daun bawang
1. Gunakan 5 batang seledri
1. Gunakan 3 daun jeruk, 3 daun salam, 3 batang sereh
1. Siapkan  Sambal : 15 cabe rawit + 2 bawang putih
1. Siapkan 2 lt air, 5 sdm minyak untuk menumis
1. Sediakan  Garam dan penyedap rasa (opsional)
1. Sediakan  Jeruk nipis dipotong kecil2




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam:

1. Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri.
1. Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  - Kemudian tambahkan air 1lt.  - Tutup panci
1. Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit.
1. Setelah bumbu meresap, keluarkan ayam dari panci.  - Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2.
1. Goreng ayam di minyak panas, tiriskan.  - Lalu potong kecil2 / suwir.  - Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  - Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa.
1. Bahan pelengkap : - Potong/iris tipis kol.  - Cuci kol dan toge. - Lalu di panci lain, rebus air hingga mendidih.  - Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. - Siapkan di mangkok.
1. Bahan tabur : - Potong/iris daun bawang, seledri. Siapkan di piring kecil
1. Sambal soto : - Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  - Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal.
1. Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. - Silahkan mencoba




Ternyata resep soto ayam yang lezat sederhana ini enteng banget ya! Semua orang bisa mencobanya. Cara Membuat soto ayam Cocok sekali untuk anda yang baru mau belajar memasak atau juga untuk kamu yang telah pandai memasak.

Apakah kamu ingin mencoba membikin resep soto ayam mantab tidak rumit ini? Kalau kalian tertarik, yuk kita segera buruan menyiapkan peralatan dan bahan-bahannya, lalu buat deh Resep soto ayam yang mantab dan simple ini. Sungguh taidak sulit kan. 

Maka dari itu, ketimbang kamu diam saja, yuk langsung aja buat resep soto ayam ini. Pasti anda gak akan nyesel bikin resep soto ayam nikmat sederhana ini! Selamat berkreasi dengan resep soto ayam mantab sederhana ini di tempat tinggal sendiri,oke!.

