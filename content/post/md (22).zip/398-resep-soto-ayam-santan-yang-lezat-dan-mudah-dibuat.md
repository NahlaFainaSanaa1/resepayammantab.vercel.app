---
description: "Resep Soto ayam Santan yang lezat dan Mudah Dibuat"
title: "Resep Soto ayam Santan yang lezat dan Mudah Dibuat"
slug: 398-resep-soto-ayam-santan-yang-lezat-dan-mudah-dibuat
date: 2021-04-23T05:52:08.738Z
image: https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Claudia Aguilar
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- "2 potong ayam"
- "500 ml air"
- "50 gr tauge siangi"
- "1/2 buah kol iris"
- "1 batang daun bawang iris"
- "4 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "500 ml santan"
- "1 buah telur rebus potong 4bagian"
- "2 sdm bawang goreng"
- "1 buah kentang ukuran besarsedang goreng"
- " Bumbu halus "
- "5 siung bawang merah"
- "4 siung bawang putih"
- "2 buah kemiri"
- "2 cm jahe"
- "2 cm kunyit"
- "Secukupnya lada dan merica bubuk"
- "Secukupnya gula"
- "Secukupnya garam"
- "Secukupnya minyak goreng"
recipeinstructions:
- "Siapkan panci dan didihkan air bersama ayam atau tulang ayam untuk membuat kuah kaldu. Tunggu ayam hingga empuk dan kaldu mendidih. Sementara menunggu ayam matang, haluskan bumbu halus kemudian tumis hingga harum dan matang."
- "Angkat ayam dari dalam rebusan jika sudah matang, lalu sisihkan. Kemudian, masukkan bumbu yang sudah di tumis kedalam kaldu aduk-aduk hingga tercampur rata. Masukkan juga gula, garam, lada, serai, daun salam, daun jeruk, dan daun bawang."
- "Aduk lagi hingga tercampur rata, dan terakhir masukkan santan dan aduk-aduk agar santan tidak pecah selama di masak. Kemudian cek rasa. Jika di rasa sudah pas, sisihkan dahulu."
- "Goreng ayam(suwir2) dan kentang bergantian hingga benar-benar matang dan kecoklatan. Terakhir, sajikan soto bersama tauge, kol, kentang goreng, lalu tuangkan kuah soto dan tambahkan telur rebus serta bawang goreng."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 176 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Lunch

---


![Soto ayam Santan](https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Andai kita seorang istri, mempersiapkan panganan menggugah selera untuk keluarga tercinta merupakan hal yang sangat menyenangkan bagi kamu sendiri. Tugas seorang istri bukan saja mengurus rumah saja, tetapi anda pun harus menyediakan kebutuhan nutrisi terpenuhi dan juga hidangan yang dimakan keluarga tercinta wajib mantab.

Di waktu  sekarang, anda memang bisa membeli masakan siap saji tidak harus repot mengolahnya lebih dulu. Tetapi ada juga lho mereka yang selalu ingin memberikan yang terenak untuk orang tercintanya. Karena, menyajikan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan keluarga. 

Resep Soto Ayam Santan Gurih Pedas Sederhana Spesial Asli Enak. Soto ayam berkuah santan dengan warna kuning dikenal di daerah Bogor dan Medan. Soto ini memakai bumbu kuning dan santan sehingga rasanya gurih berempah.

Apakah kamu seorang penggemar soto ayam santan?. Asal kamu tahu, soto ayam santan adalah hidangan khas di Nusantara yang saat ini digemari oleh kebanyakan orang dari berbagai tempat di Indonesia. Kita bisa membuat soto ayam santan hasil sendiri di rumah dan boleh dijadikan camilan kesenanganmu di akhir pekanmu.

Kamu tidak perlu bingung untuk mendapatkan soto ayam santan, lantaran soto ayam santan gampang untuk dicari dan anda pun bisa memasaknya sendiri di tempatmu. soto ayam santan dapat diolah memalui bermacam cara. Saat ini ada banyak banget cara modern yang menjadikan soto ayam santan semakin enak.

Resep soto ayam santan pun sangat mudah untuk dibikin, lho. Kalian tidak usah ribet-ribet untuk membeli soto ayam santan, sebab Anda mampu menyiapkan di rumah sendiri. Untuk Kalian yang hendak menyajikannya, inilah resep untuk membuat soto ayam santan yang lezat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Soto ayam Santan:

1. Ambil 2 potong ayam
1. Gunakan 500 ml air
1. Ambil 50 gr tauge, siangi
1. Ambil 1/2 buah kol, iris
1. Ambil 1 batang daun bawang, iris
1. Siapkan 4 lembar daun salam
1. Gunakan 3 lembar daun jeruk
1. Gunakan 1 batang serai, geprek
1. Gunakan 500 ml santan
1. Gunakan 1 buah telur rebus, potong 4bagian
1. Gunakan 2 sdm bawang goreng
1. Gunakan 1 buah kentang ukuran besar/sedang, goreng
1. Gunakan  Bumbu halus :
1. Ambil 5 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 2 buah kemiri
1. Siapkan 2 cm jahe
1. Sediakan 2 cm kunyit
1. Ambil Secukupnya lada dan merica bubuk
1. Gunakan Secukupnya gula
1. Ambil Secukupnya garam
1. Gunakan Secukupnya minyak goreng


Rasanya tidak kalah sedap dan segar, lho! Resep soto ayam santan, variasi soto ayam. Soto ayam cocok disantap untuk sarapan maupun makan siang. Soto ayam santan ala resto. foto: Instagram/@hennysgalley. 

<!--inarticleads2-->

##### Cara membuat Soto ayam Santan:

1. Siapkan panci dan didihkan air bersama ayam atau tulang ayam untuk membuat kuah kaldu. Tunggu ayam hingga empuk dan kaldu mendidih. Sementara menunggu ayam matang, haluskan bumbu halus kemudian tumis hingga harum dan matang.
1. Angkat ayam dari dalam rebusan jika sudah matang, lalu sisihkan. Kemudian, masukkan bumbu yang sudah di tumis kedalam kaldu aduk-aduk hingga tercampur rata. Masukkan juga gula, garam, lada, serai, daun salam, daun jeruk, dan daun bawang.
1. Aduk lagi hingga tercampur rata, dan terakhir masukkan santan dan aduk-aduk agar santan tidak pecah selama di masak. Kemudian cek rasa. Jika di rasa sudah pas, sisihkan dahulu.
1. Goreng ayam(suwir2) dan kentang bergantian hingga benar-benar matang dan kecoklatan. Terakhir, sajikan soto bersama tauge, kol, kentang goreng, lalu tuangkan kuah soto dan tambahkan telur rebus serta bawang goreng.


Soto Ayam Bening, Lamongan, Madura, Santan, Kuning. Resep Soto Ayam - Soto ayam merupakan salah satu dari ratusan ribu kuliner yang ada di Indonesia. Resep soto ayam santan merupakan salah satu dari sekian banyak resep soto yang ada di Nusantara. Soto ayam yang dipadu dengan kuah santan yang segar ini semakin menambah gurih. Seperti soto yang terdapat di Jawa, soto Medan juga menggunakan daging ayam sebagai bahan Bedanya, soto Medan menggunakan santan sehingga tekstur kuahnya lebih kental dan berwarna. 

Ternyata cara buat soto ayam santan yang enak tidak rumit ini mudah sekali ya! Kalian semua bisa memasaknya. Cara Membuat soto ayam santan Sangat cocok sekali untuk kamu yang sedang belajar memasak atau juga bagi kamu yang sudah jago dalam memasak.

Tertarik untuk mencoba bikin resep soto ayam santan nikmat sederhana ini? Kalau kamu tertarik, ayo kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, lalu bikin deh Resep soto ayam santan yang lezat dan sederhana ini. Sangat taidak sulit kan. 

Jadi, ketimbang kita berlama-lama, hayo langsung aja sajikan resep soto ayam santan ini. Pasti kalian gak akan nyesel sudah membuat resep soto ayam santan nikmat simple ini! Selamat mencoba dengan resep soto ayam santan enak tidak ribet ini di tempat tinggal masing-masing,oke!.

