---
description: "Resep Ayam Ungkep Versi Bumbu Dasar yang lezat Untuk Jualan"
title: "Resep Ayam Ungkep Versi Bumbu Dasar yang lezat Untuk Jualan"
slug: 168-resep-ayam-ungkep-versi-bumbu-dasar-yang-lezat-untuk-jualan
date: 2021-05-08T16:40:45.350Z
image: https://img-global.cpcdn.com/recipes/b8152492e31346b6/680x482cq70/ayam-ungkep-versi-bumbu-dasar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b8152492e31346b6/680x482cq70/ayam-ungkep-versi-bumbu-dasar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b8152492e31346b6/680x482cq70/ayam-ungkep-versi-bumbu-dasar-foto-resep-utama.jpg
author: Charles Quinn
ratingvalue: 4.6
reviewcount: 7
recipeingredient:
- "600 g ayam 7 potong ayam"
- "1/2 buah jeruk nipis utk marinasi ayam"
- " Bumbu ayam ungkep "
- "2 sdm bumbu dasar kuning kurleb 50 g           lihat resep"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 tangkai serai geprek simpul"
- "1 ruas lengkuas geprek"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "300 ml air"
recipeinstructions:
- "Cuci bersih ayam, dan marinasi dg air perasan jeruk nipis selama 10 menit. Setelah luruh lendir2nya, cuci dan tiriskan kembali ayam."
- "Masukkan bumbu dasar kuning dan rempah2/bumbu tambahan lainnya. Tambahkan air. Adukrata dulu."
- "Masukkan ayam, tutup wajan. Ungkep ayam dg api sedang cenderung kecil, selama 30 menit. Di pertengahan memasak, dibolak- balik ayam. Masak hingga bumbu meresap dan ayam empuk. Matikan kompor"
- "Biarkan ayam dingin dulu. Tiriskan dan kemas dlm wadah kedap udara. Simpan dlm kulkas. Sewaktu2 tinggal kita goreng sesuai kebutuhan. Bisa digoreng lalu dibumbu balado merah pake bumbu dasar juga.           (lihat resep)"
categories:
- Resep
tags:
- ayam
- ungkep
- versi

katakunci: ayam ungkep versi 
nutrition: 104 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Ungkep Versi Bumbu Dasar](https://img-global.cpcdn.com/recipes/b8152492e31346b6/680x482cq70/ayam-ungkep-versi-bumbu-dasar-foto-resep-utama.jpg)

Jika kita seorang wanita, menyediakan hidangan sedap kepada keluarga tercinta merupakan hal yang membahagiakan bagi kita sendiri. Peran seorang  wanita bukan sekadar menjaga rumah saja, tapi anda juga harus menyediakan keperluan gizi terpenuhi dan hidangan yang dikonsumsi orang tercinta harus enak.

Di zaman  saat ini, anda memang bisa membeli masakan jadi walaupun tanpa harus repot membuatnya dulu. Tetapi ada juga lho mereka yang selalu mau menyajikan yang terenak bagi orang yang dicintainya. Sebab, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan masakan kesukaan orang tercinta. 



Mungkinkah anda salah satu penggemar ayam ungkep versi bumbu dasar?. Tahukah kamu, ayam ungkep versi bumbu dasar merupakan sajian khas di Indonesia yang kini digemari oleh setiap orang dari hampir setiap daerah di Indonesia. Anda dapat menyajikan ayam ungkep versi bumbu dasar kreasi sendiri di rumah dan pasti jadi camilan kegemaranmu di hari libur.

Kalian tidak perlu bingung untuk menyantap ayam ungkep versi bumbu dasar, sebab ayam ungkep versi bumbu dasar gampang untuk ditemukan dan juga anda pun boleh membuatnya sendiri di tempatmu. ayam ungkep versi bumbu dasar boleh dimasak dengan beraneka cara. Kini pun sudah banyak sekali cara modern yang membuat ayam ungkep versi bumbu dasar semakin enak.

Resep ayam ungkep versi bumbu dasar juga mudah untuk dibikin, lho. Kalian tidak perlu capek-capek untuk membeli ayam ungkep versi bumbu dasar, sebab Kalian mampu menyajikan ditempatmu. Bagi Anda yang hendak mencobanya, berikut resep menyajikan ayam ungkep versi bumbu dasar yang enak yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Ungkep Versi Bumbu Dasar:

1. Siapkan 600 g ayam (7 potong ayam)
1. Siapkan 1/2 buah jeruk nipis utk marinasi ayam
1. Sediakan  ⏩Bumbu ayam ungkep :
1. Ambil 2 sdm bumbu dasar kuning (=kurleb 50 g)           (lihat resep)
1. Sediakan 2 lembar daun jeruk
1. Sediakan 2 lembar daun salam
1. Gunakan 1 tangkai serai (geprek, simpul)
1. Sediakan 1 ruas lengkuas, geprek
1. Sediakan 1 sdt garam
1. Siapkan 1 sdt kaldu bubuk
1. Gunakan 300 ml air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Ungkep Versi Bumbu Dasar:

1. Cuci bersih ayam, dan marinasi dg air perasan jeruk nipis selama 10 menit. Setelah luruh lendir2nya, cuci dan tiriskan kembali ayam.
1. Masukkan bumbu dasar kuning dan rempah2/bumbu tambahan lainnya. Tambahkan air. Adukrata dulu.
1. Masukkan ayam, tutup wajan. Ungkep ayam dg api sedang cenderung kecil, selama 30 menit. Di pertengahan memasak, dibolak- balik ayam. Masak hingga bumbu meresap dan ayam empuk. Matikan kompor
1. Biarkan ayam dingin dulu. Tiriskan dan kemas dlm wadah kedap udara. Simpan dlm kulkas. Sewaktu2 tinggal kita goreng sesuai kebutuhan. Bisa digoreng lalu dibumbu balado merah pake bumbu dasar juga. -           (lihat resep)




Ternyata resep ayam ungkep versi bumbu dasar yang lezat tidak ribet ini gampang sekali ya! Kalian semua dapat membuatnya. Cara Membuat ayam ungkep versi bumbu dasar Sangat sesuai banget untuk anda yang sedang belajar memasak maupun untuk anda yang telah lihai memasak.

Apakah kamu mau mulai mencoba buat resep ayam ungkep versi bumbu dasar enak sederhana ini? Kalau anda ingin, yuk kita segera menyiapkan peralatan dan bahan-bahannya, setelah itu buat deh Resep ayam ungkep versi bumbu dasar yang enak dan simple ini. Sungguh mudah kan. 

Oleh karena itu, daripada anda berfikir lama-lama, hayo langsung aja buat resep ayam ungkep versi bumbu dasar ini. Pasti kamu tak akan menyesal sudah membuat resep ayam ungkep versi bumbu dasar nikmat simple ini! Selamat berkreasi dengan resep ayam ungkep versi bumbu dasar mantab sederhana ini di rumah kalian masing-masing,ya!.

