---
description: "Resep Soto Ayam Betawi (Santan) Sederhana Untuk Jualan"
title: "Resep Soto Ayam Betawi (Santan) Sederhana Untuk Jualan"
slug: 391-resep-soto-ayam-betawi-santan-sederhana-untuk-jualan
date: 2021-03-03T03:46:14.155Z
image: https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg
author: Manuel Sutton
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "500 gram dada ayam potong"
- "3 buah kentang potong dadu"
- "3 buah tomat merah potong sedang"
- "3-4 jeruk limau"
- " Bawang goreng optional"
- " Emping optional"
- "secukupnya Kecap manis"
- "secukupnya Bihun"
- " Bumbu Halus"
- "9 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas kunyit"
- "1/2 sdt pala"
- "1 sdt ketumbar"
- "1 sdt lada"
- "1 ruas jahe"
- "5 butir kemiri"
- " Bumbu tambahan"
- "1 kotak santan instan"
- "1 batang sereh digeprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 ruas lengkuas digeprek"
- "secukupnya Garam"
- "secukupnya Penyedap rasa"
- " Air"
- "2 batang daun bawang iris"
- " Minyak secukupnya untuk tumis bumbu"
recipeinstructions:
- "Potong ayam dan cuci bersih lalu sisihkan."
- "3 buah kentang potong dadu, cuci bersih lalu sisihkan."
- "Potong bahan lainnya seperti tomat dan daun bawang. Geprek sereh dan lengkuas, sisihkan."
- "Goreng ayam hingga kecoklatan. Jika sudah matang tiriskan, lalu suwir."
- "Goreng kentang hingga matang. Sisihkan."
- "(Disarankan langsung di panci) Ulek bumbu halus. Lalu tumis bumbu dengan minyak secukupnya hingga harum. Masukkan sereh, lengkuas, daun salam, daun jeruk, daun bawang. Jika sudah harum, masukkan air aduk sampai mendidih. Lalu masukkan santan, garam dan penyedap, aduk rata, cek rasa. Jika sudah matang, matikan kompor dan sisihkan."
- "Rebus bihun. Siapkan mangkuk, sajikan ayam yg telah di suwir, bihun, kentang goreng, tomat, bawang goreng, dan emping ke dalam mangkuk. Siram dengan kuah soto lalu tambahkan perasan jeruk limau, dan beri sedikit kecap manis. Selamat menikmati!"
categories:
- Resep
tags:
- soto
- ayam
- betawi

katakunci: soto ayam betawi 
nutrition: 219 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto Ayam Betawi (Santan)](https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan santapan sedap buat famili adalah hal yang membahagiakan untuk kamu sendiri. Tugas seorang ibu Tidak cuman menangani rumah saja, namun anda juga wajib menyediakan kebutuhan gizi terpenuhi dan juga panganan yang disantap keluarga tercinta wajib sedap.

Di zaman  sekarang, kita sebenarnya dapat mengorder santapan siap saji tidak harus susah memasaknya lebih dulu. Tetapi banyak juga mereka yang memang ingin menyajikan yang terlezat bagi keluarganya. Pasalnya, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan selera famili. 



Mungkinkah anda seorang penikmat soto ayam betawi (santan)?. Tahukah kamu, soto ayam betawi (santan) merupakan sajian khas di Indonesia yang saat ini disukai oleh orang-orang di hampir setiap wilayah di Nusantara. Kita dapat membuat soto ayam betawi (santan) hasil sendiri di rumah dan dapat dijadikan hidangan favoritmu di hari libur.

Kita jangan bingung jika kamu ingin mendapatkan soto ayam betawi (santan), lantaran soto ayam betawi (santan) tidak sulit untuk didapatkan dan juga kita pun dapat memasaknya sendiri di tempatmu. soto ayam betawi (santan) bisa diolah memalui beragam cara. Sekarang ada banyak sekali resep modern yang menjadikan soto ayam betawi (santan) semakin lezat.

Resep soto ayam betawi (santan) juga sangat mudah dibikin, lho. Kita tidak usah ribet-ribet untuk memesan soto ayam betawi (santan), lantaran Kalian dapat menyiapkan sendiri di rumah. Untuk Kamu yang akan menghidangkannya, inilah resep membuat soto ayam betawi (santan) yang enak yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Soto Ayam Betawi (Santan):

1. Sediakan 500 gram dada ayam, potong
1. Sediakan 3 buah kentang, potong dadu
1. Ambil 3 buah tomat merah, potong sedang
1. Siapkan 3-4 jeruk limau
1. Siapkan  Bawang goreng (optional)
1. Ambil  Emping (optional)
1. Sediakan secukupnya Kecap manis,
1. Sediakan secukupnya Bihun
1. Gunakan  Bumbu Halus
1. Ambil 9 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Siapkan 1 ruas kunyit
1. Siapkan 1/2 sdt pala
1. Ambil 1 sdt ketumbar
1. Sediakan 1 sdt lada
1. Siapkan 1 ruas jahe
1. Ambil 5 butir kemiri
1. Gunakan  Bumbu tambahan
1. Ambil 1 kotak santan instan
1. Sediakan 1 batang sereh (digeprek)
1. Sediakan 2 lembar daun salam
1. Gunakan 3 lembar daun jeruk
1. Sediakan 1 ruas lengkuas (digeprek)
1. Siapkan secukupnya Garam
1. Sediakan secukupnya Penyedap rasa
1. Sediakan  Air
1. Ambil 2 batang daun bawang, iris
1. Siapkan  Minyak secukupnya (untuk tumis bumbu)




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Betawi (Santan):

1. Potong ayam dan cuci bersih lalu sisihkan.
1. 3 buah kentang potong dadu, cuci bersih lalu sisihkan.
1. Potong bahan lainnya seperti tomat dan daun bawang. Geprek sereh dan lengkuas, sisihkan.
1. Goreng ayam hingga kecoklatan. Jika sudah matang tiriskan, lalu suwir.
1. Goreng kentang hingga matang. Sisihkan.
1. (Disarankan langsung di panci) Ulek bumbu halus. Lalu tumis bumbu dengan minyak secukupnya hingga harum. Masukkan sereh, lengkuas, daun salam, daun jeruk, daun bawang. Jika sudah harum, masukkan air aduk sampai mendidih. Lalu masukkan santan, garam dan penyedap, aduk rata, cek rasa. Jika sudah matang, matikan kompor dan sisihkan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Soto Ayam Betawi (Santan)">1. Rebus bihun. Siapkan mangkuk, sajikan ayam yg telah di suwir, bihun, kentang goreng, tomat, bawang goreng, dan emping ke dalam mangkuk. Siram dengan kuah soto lalu tambahkan perasan jeruk limau, dan beri sedikit kecap manis. Selamat menikmati!




Wah ternyata cara buat soto ayam betawi (santan) yang nikamt tidak ribet ini enteng banget ya! Kita semua dapat menghidangkannya. Resep soto ayam betawi (santan) Sangat cocok banget untuk kalian yang baru belajar memasak maupun untuk kamu yang telah lihai dalam memasak.

Tertarik untuk mencoba bikin resep soto ayam betawi (santan) lezat simple ini? Kalau kalian tertarik, ayo kalian segera buruan menyiapkan peralatan dan bahannya, lantas bikin deh Resep soto ayam betawi (santan) yang nikmat dan simple ini. Betul-betul mudah kan. 

Maka, ketimbang kamu berlama-lama, ayo langsung aja buat resep soto ayam betawi (santan) ini. Pasti kalian tak akan menyesal sudah membuat resep soto ayam betawi (santan) lezat tidak ribet ini! Selamat mencoba dengan resep soto ayam betawi (santan) lezat simple ini di tempat tinggal kalian masing-masing,oke!.

