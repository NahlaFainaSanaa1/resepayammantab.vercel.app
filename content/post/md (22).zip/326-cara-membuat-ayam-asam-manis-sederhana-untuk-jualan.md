---
description: "Cara membuat Ayam Asam Manis Sederhana Untuk Jualan"
title: "Cara membuat Ayam Asam Manis Sederhana Untuk Jualan"
slug: 326-cara-membuat-ayam-asam-manis-sederhana-untuk-jualan
date: 2021-01-26T06:17:44.323Z
image: https://img-global.cpcdn.com/recipes/9925cdc48f64aca3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9925cdc48f64aca3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9925cdc48f64aca3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Anthony Miles
ratingvalue: 4.5
reviewcount: 10
recipeingredient:
- "400 gr Dada Ayam tanpa tulang"
- "1 butir telur"
- " Tepung Bumbu Serbaguna"
- "1/2 Bawang Bombay"
- "2 siung Bawang Putih"
- "1 siung Bawang Merah"
- "1 Sdm Saus Tiram"
- "3 Sdm Saus Tomat"
- "1/2 sdm kecap manis"
- " Gula"
- " Garam"
- " Penyedap Rasa"
- " Lada bubuk"
- "1 Gelas Air"
- " Daun Bawang"
recipeinstructions:
- "Cuci bersih dada ayam, lalu potong-potong sesuai selera"
- "Marinasi Dada Ayam dengan garam, lada bubuk dan telur. Diamkan sekitar 15 menit"
- "Balurkan dada ayam dengan tepung bumbu serbaguna, lalu goreng hingga matang. Sisihkan."
- "Tumis bawang putih, bawang merah dan bawang bombay hingga harum"
- "Masukkan saus tiram, saus tomat, kecap manis dan air. Tambahkan gula, garam, penyedap rasa dan lada bubuk."
- "Masak hingga agak mengental. Matikan api, masukan dada ayam yang sudah di goreng. Aduk rata dan taburi dengan daun bawang."
- "Siap disajikan dengan nasi hangat"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 101 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/9925cdc48f64aca3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan santapan enak buat famili adalah suatu hal yang memuaskan untuk anda sendiri. Tanggung jawab seorang ibu bukan cuma menangani rumah saja, tapi anda pun harus memastikan keperluan gizi tercukupi dan juga masakan yang disantap anak-anak wajib enak.

Di era  saat ini, kita sebenarnya bisa memesan santapan praktis walaupun tanpa harus susah mengolahnya terlebih dahulu. Tetapi banyak juga mereka yang memang mau menghidangkan yang terbaik bagi orang tercintanya. Karena, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan berdasarkan selera orang tercinta. 



Apakah kamu seorang penikmat ayam asam manis?. Tahukah kamu, ayam asam manis adalah sajian khas di Nusantara yang kini disenangi oleh banyak orang dari berbagai tempat di Indonesia. Kamu bisa menghidangkan ayam asam manis sendiri di rumah dan boleh jadi santapan kesenanganmu di akhir pekanmu.

Anda jangan bingung jika kamu ingin menyantap ayam asam manis, sebab ayam asam manis tidak sukar untuk ditemukan dan kalian pun boleh menghidangkannya sendiri di tempatmu. ayam asam manis bisa dimasak lewat berbagai cara. Saat ini sudah banyak resep kekinian yang menjadikan ayam asam manis semakin lezat.

Resep ayam asam manis juga sangat gampang untuk dibuat, lho. Kamu jangan ribet-ribet untuk membeli ayam asam manis, sebab Kita dapat menghidangkan sendiri di rumah. Bagi Kalian yang mau menyajikannya, berikut cara membuat ayam asam manis yang mantab yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Asam Manis:

1. Ambil 400 gr Dada Ayam tanpa tulang
1. Sediakan 1 butir telur
1. Ambil  Tepung Bumbu Serbaguna
1. Ambil 1/2 Bawang Bombay
1. Sediakan 2 siung Bawang Putih
1. Siapkan 1 siung Bawang Merah
1. Ambil 1 Sdm Saus Tiram
1. Ambil 3 Sdm Saus Tomat
1. Sediakan 1/2 sdm kecap manis
1. Siapkan  Gula
1. Ambil  Garam
1. Ambil  Penyedap Rasa
1. Sediakan  Lada bubuk
1. Sediakan 1 Gelas Air
1. Siapkan  Daun Bawang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Asam Manis:

1. Cuci bersih dada ayam, lalu potong-potong sesuai selera
1. Marinasi Dada Ayam dengan garam, lada bubuk dan telur. Diamkan sekitar 15 menit
1. Balurkan dada ayam dengan tepung bumbu serbaguna, lalu goreng hingga matang. Sisihkan.
1. Tumis bawang putih, bawang merah dan bawang bombay hingga harum
1. Masukkan saus tiram, saus tomat, kecap manis dan air. Tambahkan gula, garam, penyedap rasa dan lada bubuk.
1. Masak hingga agak mengental. Matikan api, masukan dada ayam yang sudah di goreng. Aduk rata dan taburi dengan daun bawang.
1. Siap disajikan dengan nasi hangat




Wah ternyata cara buat ayam asam manis yang mantab sederhana ini mudah banget ya! Anda Semua bisa menghidangkannya. Cara buat ayam asam manis Cocok sekali buat kamu yang baru belajar memasak ataupun untuk anda yang telah lihai memasak.

Tertarik untuk mulai mencoba buat resep ayam asam manis nikmat simple ini? Kalau mau, mending kamu segera siapkan alat-alat dan bahannya, lantas buat deh Resep ayam asam manis yang lezat dan sederhana ini. Sangat mudah kan. 

Maka, daripada kita diam saja, maka langsung aja sajikan resep ayam asam manis ini. Dijamin kamu tak akan nyesel sudah bikin resep ayam asam manis lezat tidak ribet ini! Selamat berkreasi dengan resep ayam asam manis lezat tidak rumit ini di rumah sendiri,oke!.

