---
description: "Cara membuat Opor Ayam yang nikmat Untuk Jualan"
title: "Cara membuat Opor Ayam yang nikmat Untuk Jualan"
slug: 75-cara-membuat-opor-ayam-yang-nikmat-untuk-jualan
date: 2021-04-19T02:24:30.862Z
image: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Peter Parker
ratingvalue: 3.2
reviewcount: 15
recipeingredient:
- "1 ekor ayam sedang potong2 cuci bersih"
- "50 ml santan kara campur air hingga 100ml"
- "3 bh cabe keriting iris serong"
- "1 btg serai geprek"
- "3 daun salam"
- "3 daun jeruk buang tulang"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1/8 bj pala"
- "1/4 sdt jintan"
- "1/2 sdt ketumbar bubuk"
- "600 ml air minum"
- " Minyak unt menumis"
- "1 sdt garam batu himalayan"
- "secukupnya Lada"
- " Bawang goreng  telur rebus sbg pelengkap"
- " Bahan halus "
- "12 siung bawang merah"
- "6 siung bawang putih"
- "5 bh kemiri"
- "1 ruas kunyit"
recipeinstructions:
- "Tumis semua bahan kecuali santan."
- "Masukkan ayam, aduk rata. Tutup sbntr wajan. Biarkan bumbu meresap."
- "Beri air, didihkan dan masak hingga ayam empuk."
- "Beri garam. Koreksi rasa, matikan api. Masukkan santan &amp; aduk rata."
- "Angkat ayam, saring kuah agar ampas bumbu tdk ikt. Sajikan dgn bawang goreng &amp; telur rebus."
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 223 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dessert

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan panganan lezat untuk orang tercinta adalah hal yang menyenangkan untuk anda sendiri. Tugas seorang  wanita bukan saja mengurus rumah saja, tapi anda pun wajib memastikan kebutuhan gizi tercukupi dan hidangan yang disantap keluarga tercinta wajib sedap.

Di zaman  saat ini, kita sebenarnya mampu membeli panganan praktis walaupun tanpa harus susah membuatnya dulu. Namun ada juga orang yang selalu ingin memberikan yang terenak bagi orang tercintanya. Pasalnya, menyajikan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai selera keluarga. 



Apakah anda merupakan salah satu penikmat opor ayam?. Tahukah kamu, opor ayam adalah makanan khas di Indonesia yang sekarang disenangi oleh banyak orang dari hampir setiap wilayah di Nusantara. Kamu bisa memasak opor ayam sendiri di rumah dan boleh jadi camilan favoritmu di hari liburmu.

Anda tidak perlu bingung jika kamu ingin mendapatkan opor ayam, lantaran opor ayam sangat mudah untuk didapatkan dan juga kalian pun dapat mengolahnya sendiri di tempatmu. opor ayam dapat dibuat memalui beragam cara. Sekarang telah banyak resep modern yang membuat opor ayam semakin lebih enak.

Resep opor ayam juga gampang dihidangkan, lho. Kalian tidak usah ribet-ribet untuk membeli opor ayam, tetapi Kamu dapat membuatnya di rumah sendiri. Untuk Kamu yang mau mencobanya, dibawah ini merupakan resep menyajikan opor ayam yang mantab yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Opor Ayam:

1. Sediakan 1 ekor ayam sedang, potong2, cuci bersih
1. Siapkan 50 ml santan kara, campur air hingga 100ml
1. Ambil 3 bh cabe keriting, iris serong
1. Sediakan 1 btg serai, geprek
1. Sediakan 3 daun salam
1. Ambil 3 daun jeruk, buang tulang
1. Siapkan 1 ruas jahe
1. Ambil 1 ruas lengkuas
1. Ambil 1/8 bj pala
1. Sediakan 1/4 sdt jintan
1. Ambil 1/2 sdt ketumbar bubuk
1. Ambil 600 ml air minum
1. Sediakan  Minyak unt menumis
1. Ambil 1 sdt garam batu himalayan
1. Sediakan secukupnya Lada
1. Gunakan  Bawang goreng &amp; telur rebus sbg pelengkap
1. Sediakan  Bahan halus :
1. Ambil 12 siung bawang merah
1. Siapkan 6 siung bawang putih
1. Siapkan 5 bh kemiri
1. Sediakan 1 ruas kunyit




<!--inarticleads2-->

##### Cara membuat Opor Ayam:

1. Tumis semua bahan kecuali santan.
1. Masukkan ayam, aduk rata. Tutup sbntr wajan. Biarkan bumbu meresap.
1. Beri air, didihkan dan masak hingga ayam empuk.
1. Beri garam. Koreksi rasa, matikan api. Masukkan santan &amp; aduk rata.
1. Angkat ayam, saring kuah agar ampas bumbu tdk ikt. Sajikan dgn bawang goreng &amp; telur rebus.




Wah ternyata cara buat opor ayam yang lezat sederhana ini gampang banget ya! Kamu semua bisa menghidangkannya. Cara buat opor ayam Cocok sekali untuk kita yang baru mau belajar memasak ataupun juga untuk anda yang sudah jago dalam memasak.

Apakah kamu mau mencoba buat resep opor ayam nikmat sederhana ini? Kalau anda tertarik, mending kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep opor ayam yang enak dan simple ini. Sangat gampang kan. 

Maka dari itu, daripada anda diam saja, hayo langsung aja buat resep opor ayam ini. Dijamin kalian tiidak akan menyesal membuat resep opor ayam nikmat tidak ribet ini! Selamat mencoba dengan resep opor ayam mantab sederhana ini di rumah sendiri,ya!.

