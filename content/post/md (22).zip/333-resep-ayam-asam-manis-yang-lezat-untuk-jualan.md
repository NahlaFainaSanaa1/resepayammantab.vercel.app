---
description: "Resep Ayam asam manis yang lezat Untuk Jualan"
title: "Resep Ayam asam manis yang lezat Untuk Jualan"
slug: 333-resep-ayam-asam-manis-yang-lezat-untuk-jualan
date: 2021-01-30T08:33:58.838Z
image: https://img-global.cpcdn.com/recipes/eb47500c82b48de5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eb47500c82b48de5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eb47500c82b48de5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Harvey Pope
ratingvalue: 4.5
reviewcount: 5
recipeingredient:
- "300 gr ayam fillet potong dadu"
- "100 gr tepung meizena"
- "Buah Nanas secukupnya"
- "secukupnya Cabe merah"
- "1 buah telur"
- " Paprika"
- "1 buah bawang bombay"
- "4 siung bawang putih cincang halus"
- " Gula"
- " Garam"
- " Bahan untuk marinasi "
- "1 sdm Minyak wijen"
- "1 sdm Gula"
- "2 sdm Kecap asin"
- " Bahan untuk membuat saos "
- "3 sdm Saos tomat sesuai selera"
- "1 sdm Cuka"
- "1 sdm Kecap manis"
- "secukupnya Gula pasir"
- "100 ml Air"
- "secukupnya Gula dan garam"
recipeinstructions:
- "Siapkan semua bahan kemudian, Ayam yang sudah di potong dadu masukkan ke dalam bumbu marinasi, kemudian diamkan selama 30 menit di dlm kulkas agar bumbu meresap."
- "Kemudian setelah 30 menit, tambahkan 1 butir telur kedalam ayam yg sdh di marinasi aduk rata, beri sedikit demi sedikit tepung maizena dan aduk rata"
- "Kemudian goreng ayam di minyak panas dengan api kecil, goreng hingga kecoklatan"
- "Buat saos : Tumis bawang putih dan bawang bombay, kemudian masukkan saos tomat, cabe, cuka, garam, gula, kecap manis, air secukupnya, paprika dan nanas"
- "Campurkan ayam dengan saos"
- "Siap disajikan"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 265 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam asam manis](https://img-global.cpcdn.com/recipes/eb47500c82b48de5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan hidangan mantab buat famili merupakan suatu hal yang menyenangkan bagi kamu sendiri. Kewajiban seorang ibu bukan saja menjaga rumah saja, namun anda juga harus memastikan kebutuhan gizi terpenuhi dan juga masakan yang disantap anak-anak mesti sedap.

Di masa  sekarang, kamu memang mampu membeli olahan yang sudah jadi tanpa harus ribet memasaknya terlebih dahulu. Tetapi ada juga orang yang memang ingin memberikan yang terbaik bagi orang tercintanya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai kesukaan keluarga tercinta. 



Apakah anda adalah seorang penggemar ayam asam manis?. Asal kamu tahu, ayam asam manis merupakan hidangan khas di Indonesia yang sekarang digemari oleh setiap orang di berbagai daerah di Indonesia. Kita dapat menyajikan ayam asam manis hasil sendiri di rumah dan pasti jadi makanan favorit di akhir pekan.

Kita tak perlu bingung jika kamu ingin menyantap ayam asam manis, lantaran ayam asam manis tidak sulit untuk didapatkan dan juga anda pun boleh memasaknya sendiri di tempatmu. ayam asam manis boleh dimasak dengan beragam cara. Kini telah banyak cara modern yang membuat ayam asam manis semakin lebih lezat.

Resep ayam asam manis pun mudah untuk dibuat, lho. Kamu jangan capek-capek untuk membeli ayam asam manis, tetapi Kalian dapat menghidangkan ditempatmu. Bagi Kita yang mau menyajikannya, berikut cara untuk membuat ayam asam manis yang mantab yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam asam manis:

1. Sediakan 300 gr ayam fillet potong dadu
1. Ambil 100 gr tepung meizena
1. Sediakan Buah Nanas secukupnya
1. Sediakan secukupnya Cabe merah
1. Ambil 1 buah telur
1. Sediakan  Paprika
1. Siapkan 1 buah bawang bombay
1. Sediakan 4 siung bawang putih cincang halus
1. Gunakan  Gula
1. Siapkan  Garam
1. Siapkan  Bahan untuk marinasi :
1. Siapkan 1 sdm Minyak wijen
1. Gunakan 1 sdm Gula
1. Sediakan 2 sdm Kecap asin
1. Gunakan  Bahan untuk membuat saos :
1. Ambil 3 sdm Saos tomat sesuai selera
1. Gunakan 1 sdm Cuka
1. Siapkan 1 sdm Kecap manis
1. Sediakan secukupnya Gula pasir
1. Sediakan 100 ml Air
1. Siapkan secukupnya Gula dan garam




<!--inarticleads2-->

##### Cara menyiapkan Ayam asam manis:

1. Siapkan semua bahan kemudian, Ayam yang sudah di potong dadu masukkan ke dalam bumbu marinasi, kemudian diamkan selama 30 menit di dlm kulkas agar bumbu meresap.
1. Kemudian setelah 30 menit, tambahkan 1 butir telur kedalam ayam yg sdh di marinasi aduk rata, beri sedikit demi sedikit tepung maizena dan aduk rata
1. Kemudian goreng ayam di minyak panas dengan api kecil, goreng hingga kecoklatan
1. Buat saos : - Tumis bawang putih dan bawang bombay, kemudian masukkan saos tomat, cabe, cuka, garam, gula, kecap manis, air secukupnya, paprika dan nanas
1. Campurkan ayam dengan saos
1. Siap disajikan




Wah ternyata resep ayam asam manis yang nikamt sederhana ini gampang sekali ya! Kamu semua mampu membuatnya. Resep ayam asam manis Sangat sesuai banget buat kita yang baru mau belajar memasak atau juga bagi kamu yang telah pandai memasak.

Tertarik untuk mulai mencoba membikin resep ayam asam manis nikmat simple ini? Kalau kamu tertarik, ayo kamu segera buruan menyiapkan alat-alat dan bahannya, lalu buat deh Resep ayam asam manis yang lezat dan simple ini. Betul-betul gampang kan. 

Oleh karena itu, ketimbang kamu diam saja, hayo langsung aja buat resep ayam asam manis ini. Dijamin kamu tiidak akan nyesel bikin resep ayam asam manis mantab simple ini! Selamat mencoba dengan resep ayam asam manis mantab tidak rumit ini di tempat tinggal sendiri,oke!.

