---
description: "Bahan-bahan Opor ayam tahu yang nikmat Untuk Jualan"
title: "Bahan-bahan Opor ayam tahu yang nikmat Untuk Jualan"
slug: 78-bahan-bahan-opor-ayam-tahu-yang-nikmat-untuk-jualan
date: 2021-02-25T21:29:54.185Z
image: https://img-global.cpcdn.com/recipes/800ca4a59bcba6eb/680x482cq70/opor-ayam-tahu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/800ca4a59bcba6eb/680x482cq70/opor-ayam-tahu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/800ca4a59bcba6eb/680x482cq70/opor-ayam-tahu-foto-resep-utama.jpg
author: Sarah Stewart
ratingvalue: 3.9
reviewcount: 9
recipeingredient:
- "1/2 kg ayam potong kecil2 17k"
- "1 plastik tahu putih 3k"
- " Kelapa parut 2k"
- " Gula merah kira2 seruas jari"
- " Garam dan kaldu bubuk"
- "1 ruas jahe 1 batang serai 2 lb daun jeruk dan 2 lb daun salam"
- " Bumbu halus"
- "7 bawang merah"
- "3 siung bawang putih"
- "2 butir Kemiri"
- "1 ruas kunyit"
- "1/2 sendok makan ketumbar"
- "1/2 sendok teh merica"
- "1 ruas jahe"
recipeinstructions:
- "Siapkan bumbu halus.  Bersihkan ayam (kl aq tdk perlu diberi perasan jeruk krn nanti ayam direbus dg bumbu halus. Jd ga amis).  Juga Potong2 tahu sesuai selera"
- "Siapkan santan dr kelapa parut yg sudah dibeli. Awalnya santan diberi cukup air kemudian diremas2 supaya sarinya keluar. Kl udah baru sedikit demi sedikit ditambah air sambil diremas2 juga sampai ukuran bisa buat kuah banyak. Jd nanti santannya intensitas tidak terlalu kental juga tdk terlalu cair"
- "Siapkan penggorengan dan beri minyak. Kemudian tumis bumbu halus hingga harum, masukkan daun salam, daun jeruk, sereh, gula merah, secukupnya garam dan kaldu bubuk. (Aq pakai kaldu bubuk merk royco stgh sachet yg 500an)."
- "Kemudian masukkan ayam dan aduk hingga rata. Masak hingga mendidih atau bumbu mulai asat. dg sesekali diaduk. Api sedang saja supaya ayam empuk dan bumbu meresap."
- "Setelah kiranya bumbu sudah sedikit asat dan ayam sudah berubah warna kuning, masukkan santan dan tahu. Kemudian diaduk supaya rata. Agar santan tidak pecah, selama masak lerlu diaduk sampai kuah mendidih (cukup buat gerakan gelombang dr spatula yg dimasukan di bawah masakan). Kl kuah sudah mendidih, boleh berhenti diaduk sambil nunggu tanak betul masakannya."
- "Monggo dites rasa, kl ada yg kurang bisa ditambah2 sambil menunggu matang sempurna. Kl sudah, siap disajikan"
categories:
- Resep
tags:
- opor
- ayam
- tahu

katakunci: opor ayam tahu 
nutrition: 253 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Opor ayam tahu](https://img-global.cpcdn.com/recipes/800ca4a59bcba6eb/680x482cq70/opor-ayam-tahu-foto-resep-utama.jpg)

Apabila kamu seorang istri, menyediakan masakan menggugah selera kepada orang tercinta merupakan suatu hal yang memuaskan untuk kita sendiri. Kewajiban seorang istri bukan hanya mengatur rumah saja, tapi kamu juga wajib memastikan kebutuhan gizi tercukupi dan juga masakan yang dikonsumsi keluarga tercinta harus sedap.

Di zaman  saat ini, kalian memang bisa mengorder olahan praktis tidak harus ribet membuatnya dahulu. Namun banyak juga mereka yang selalu ingin menghidangkan yang terlezat untuk keluarganya. Pasalnya, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan kesukaan keluarga tercinta. 



Apakah kamu salah satu penyuka opor ayam tahu?. Tahukah kamu, opor ayam tahu merupakan makanan khas di Indonesia yang kini disukai oleh banyak orang di berbagai wilayah di Indonesia. Kalian bisa membuat opor ayam tahu buatan sendiri di rumah dan boleh dijadikan santapan favorit di akhir pekan.

Kamu jangan bingung jika kamu ingin memakan opor ayam tahu, karena opor ayam tahu tidak sulit untuk didapatkan dan juga kamu pun dapat menghidangkannya sendiri di rumah. opor ayam tahu dapat diolah lewat beraneka cara. Kini sudah banyak sekali resep modern yang membuat opor ayam tahu semakin lebih nikmat.

Resep opor ayam tahu pun mudah sekali dihidangkan, lho. Kalian jangan ribet-ribet untuk memesan opor ayam tahu, sebab Kalian bisa menyiapkan di rumahmu. Bagi Kalian yang ingin mencobanya, di bawah ini adalah resep membuat opor ayam tahu yang lezat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Opor ayam tahu:

1. Siapkan 1/2 kg ayam potong kecil2 17k
1. Sediakan 1 plastik tahu putih 3k
1. Sediakan  Kelapa parut 2k
1. Sediakan  Gula merah kira2 seruas jari
1. Siapkan  Garam dan kaldu bubuk
1. Sediakan 1 ruas jahe, 1 batang serai, 2 lb daun jeruk dan 2 lb daun salam
1. Siapkan  Bumbu halus
1. Sediakan 7 bawang merah
1. Gunakan 3 siung bawang putih
1. Ambil 2 butir Kemiri
1. Siapkan 1 ruas kunyit
1. Gunakan 1/2 sendok makan ketumbar
1. Sediakan 1/2 sendok teh merica
1. Siapkan 1 ruas jahe




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor ayam tahu:

1. Siapkan bumbu halus.  - Bersihkan ayam (kl aq tdk perlu diberi perasan jeruk krn nanti ayam direbus dg bumbu halus. Jd ga amis).  - Juga Potong2 tahu sesuai selera
1. Siapkan santan dr kelapa parut yg sudah dibeli. Awalnya santan diberi cukup air kemudian diremas2 supaya sarinya keluar. Kl udah baru sedikit demi sedikit ditambah air sambil diremas2 juga sampai ukuran bisa buat kuah banyak. Jd nanti santannya intensitas tidak terlalu kental juga tdk terlalu cair
1. Siapkan penggorengan dan beri minyak. Kemudian tumis bumbu halus hingga harum, masukkan daun salam, daun jeruk, sereh, gula merah, secukupnya garam dan kaldu bubuk. (Aq pakai kaldu bubuk merk royco stgh sachet yg 500an).
1. Kemudian masukkan ayam dan aduk hingga rata. Masak hingga mendidih atau bumbu mulai asat. dg sesekali diaduk. Api sedang saja supaya ayam empuk dan bumbu meresap.
1. Setelah kiranya bumbu sudah sedikit asat dan ayam sudah berubah warna kuning, masukkan santan dan tahu. Kemudian diaduk supaya rata. Agar santan tidak pecah, selama masak lerlu diaduk sampai kuah mendidih (cukup buat gerakan gelombang dr spatula yg dimasukan di bawah masakan). Kl kuah sudah mendidih, boleh berhenti diaduk sambil nunggu tanak betul masakannya.
1. Monggo dites rasa, kl ada yg kurang bisa ditambah2 sambil menunggu matang sempurna. Kl sudah, siap disajikan




Wah ternyata cara membuat opor ayam tahu yang lezat sederhana ini enteng banget ya! Kamu semua mampu membuatnya. Cara buat opor ayam tahu Sesuai sekali buat kamu yang baru belajar memasak ataupun bagi kalian yang sudah pandai dalam memasak.

Apakah kamu ingin mulai mencoba buat resep opor ayam tahu mantab tidak rumit ini? Kalau kamu tertarik, mending kamu segera buruan menyiapkan peralatan dan bahan-bahannya, lalu bikin deh Resep opor ayam tahu yang enak dan simple ini. Sungguh gampang kan. 

Maka dari itu, ketimbang kalian berfikir lama-lama, ayo kita langsung saja bikin resep opor ayam tahu ini. Pasti kalian tak akan menyesal sudah bikin resep opor ayam tahu nikmat sederhana ini! Selamat mencoba dengan resep opor ayam tahu mantab sederhana ini di rumah masing-masing,ya!.

