---
description: "Cara membuat Ayam asam manis Sederhana Untuk Jualan"
title: "Cara membuat Ayam asam manis Sederhana Untuk Jualan"
slug: 340-cara-membuat-ayam-asam-manis-sederhana-untuk-jualan
date: 2021-01-23T06:18:54.784Z
image: https://img-global.cpcdn.com/recipes/063fe4d71b111a91/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/063fe4d71b111a91/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/063fe4d71b111a91/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Richard Benson
ratingvalue: 4.8
reviewcount: 6
recipeingredient:
- "1/2 kg dada ayam fillet"
- "1 sct tepung bumbu serbaguna akoh pake merk Sasa uk225gr"
- "secukupnya Air es"
- " Minyak untuk menggoreng"
- " Saos asam manis"
- "2 Sdm Margarin"
- "1/4 buah bawang bombai"
- "3 Sdm saos tomat"
- "4 Sdm gula pasir"
- "500 ml air"
- "secukupnya Garam lada bubuk"
- "1 buah tomat"
- "1 sdm maizena"
recipeinstructions:
- "Potong kecil ayam,"
- "Siakan tepung bumbu Sasa. Ambil 4 Sdm lalu tambahkan air es sedikit. (Adonan kental). Lalu masukkan ayam. Aduk rata. Diamkan 15 menit"
- "Sambil menunggu marinasi ayam. Buat saos asam manisnya."
- "Panaskan teflon, masukkan margarin. Lalu tumis bawang bombai hingga harum"
- "Tambahkan saos tomat aduk rata. Lalu tambahkan air. Biarkan mendidih"
- "Tambahkan garam,gula, lada. Aduk rata."
- "Larutkan maizena dengan sedikit air. Tuang kedalam saos"
- "Terakhir tambahkan irisan tomat. Aduk, tes rasa dan Sisihkan"
- "Panaskan minyak untuk menggoreng"
- "Siapkan wadah, tuang tepung Sasa kering"
- "Ambil ayam, balurkan dengan tepung kering."
- "Cubit ayam. Lalu goreng dengan api kecil hingga kuning keemasan. (Minyak harus merendam ayam)"
- "Ayam goreng siap disajikan dengan saos asam manis. Klo akoh lebih suka saosnya dipisah aja kaya gini. Nanti kalo mau makan baru di ruang saos. Biar tetep ada sensasi kriuk dr ayam nya,. Selamat mencoba..."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 248 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam asam manis](https://img-global.cpcdn.com/recipes/063fe4d71b111a91/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Apabila kamu seorang istri, menyuguhkan olahan nikmat kepada famili adalah hal yang sangat menyenangkan untuk anda sendiri. Peran seorang ibu Tidak sekedar mengerjakan pekerjaan rumah saja, tetapi anda juga harus menyediakan keperluan gizi terpenuhi dan juga panganan yang dimakan orang tercinta mesti enak.

Di waktu  saat ini, kalian sebenarnya bisa membeli panganan yang sudah jadi tidak harus susah membuatnya terlebih dahulu. Namun ada juga lho orang yang selalu ingin memberikan hidangan yang terbaik bagi keluarganya. Lantaran, menyajikan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai kesukaan orang tercinta. 



Apakah anda merupakan seorang penggemar ayam asam manis?. Asal kamu tahu, ayam asam manis adalah hidangan khas di Nusantara yang sekarang disukai oleh kebanyakan orang di hampir setiap wilayah di Indonesia. Kamu dapat membuat ayam asam manis sendiri di rumahmu dan pasti jadi camilan favorit di akhir pekanmu.

Kamu tidak perlu bingung untuk memakan ayam asam manis, sebab ayam asam manis tidak sukar untuk ditemukan dan juga anda pun dapat mengolahnya sendiri di tempatmu. ayam asam manis dapat dimasak dengan beraneka cara. Kini ada banyak banget cara kekinian yang menjadikan ayam asam manis semakin enak.

Resep ayam asam manis pun mudah dibuat, lho. Kamu tidak perlu capek-capek untuk memesan ayam asam manis, lantaran Kita bisa menyiapkan ditempatmu. Bagi Kamu yang mau mencobanya, dibawah ini merupakan cara menyajikan ayam asam manis yang lezat yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam asam manis:

1. Siapkan 1/2 kg dada ayam fillet
1. Gunakan 1 sct tepung bumbu serbaguna (akoh pake merk Sasa uk.225gr)
1. Siapkan secukupnya Air es
1. Siapkan  Minyak untuk menggoreng
1. Gunakan  Saos asam manis
1. Sediakan 2 Sdm Margarin
1. Siapkan 1/4 buah bawang bombai
1. Sediakan 3 Sdm saos tomat
1. Ambil 4 Sdm gula pasir
1. Siapkan 500 ml air
1. Siapkan secukupnya Garam, lada bubuk
1. Ambil 1 buah tomat
1. Gunakan 1 sdm maizena




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam asam manis:

1. Potong kecil ayam,
1. Siakan tepung bumbu Sasa. Ambil 4 Sdm lalu tambahkan air es sedikit. (Adonan kental). Lalu masukkan ayam. Aduk rata. Diamkan 15 menit
1. Sambil menunggu marinasi ayam. Buat saos asam manisnya.
1. Panaskan teflon, masukkan margarin. Lalu tumis bawang bombai hingga harum
1. Tambahkan saos tomat aduk rata. Lalu tambahkan air. Biarkan mendidih
1. Tambahkan garam,gula, lada. Aduk rata.
1. Larutkan maizena dengan sedikit air. Tuang kedalam saos
1. Terakhir tambahkan irisan tomat. Aduk, tes rasa dan Sisihkan
1. Panaskan minyak untuk menggoreng
1. Siapkan wadah, tuang tepung Sasa kering
1. Ambil ayam, balurkan dengan tepung kering.
1. Cubit ayam. Lalu goreng dengan api kecil hingga kuning keemasan. (Minyak harus merendam ayam)
1. Ayam goreng siap disajikan dengan saos asam manis. Klo akoh lebih suka saosnya dipisah aja kaya gini. Nanti kalo mau makan baru di ruang saos. Biar tetep ada sensasi kriuk dr ayam nya,. Selamat mencoba...




Ternyata cara buat ayam asam manis yang lezat tidak rumit ini mudah sekali ya! Kamu semua dapat menghidangkannya. Cara buat ayam asam manis Sangat cocok banget untuk kalian yang baru akan belajar memasak ataupun juga untuk kalian yang telah jago dalam memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam asam manis mantab tidak rumit ini? Kalau kamu tertarik, ayo kamu segera buruan siapkan alat dan bahannya, maka bikin deh Resep ayam asam manis yang nikmat dan simple ini. Betul-betul gampang kan. 

Maka, daripada kita diam saja, ayo kita langsung saja sajikan resep ayam asam manis ini. Dijamin kamu tiidak akan menyesal sudah buat resep ayam asam manis nikmat tidak rumit ini! Selamat mencoba dengan resep ayam asam manis lezat tidak rumit ini di rumah sendiri,oke!.

