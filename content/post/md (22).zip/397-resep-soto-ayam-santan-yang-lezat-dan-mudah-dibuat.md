---
description: "Resep Soto Ayam Santan yang lezat dan Mudah Dibuat"
title: "Resep Soto Ayam Santan yang lezat dan Mudah Dibuat"
slug: 397-resep-soto-ayam-santan-yang-lezat-dan-mudah-dibuat
date: 2021-01-19T07:33:25.575Z
image: https://img-global.cpcdn.com/recipes/75582be4ef1c543d/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/75582be4ef1c543d/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/75582be4ef1c543d/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Amy Ellis
ratingvalue: 4
reviewcount: 11
recipeingredient:
- "1/2 kg ayam fillet"
- "2 bh kentang"
- "1 bks santan instant 65ml"
- "1 bh belimbing dewa manis me skip  ganti gula pasir 1 sdm"
- "1/2 sdt garam utk marinasi ayam"
- "1 sdt garam utk kuah soto"
- "1 sdt penyedap rasa"
- "4 gelas belimbing air matang lebih enak pakai air kaldu ayam"
- " Minyak utk menumis bumbu"
- "  Bumbu Halus"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "1 sdt ketumbar bubuk"
- "1/2 sdt jinten"
- "1 ruas jari kencur"
- "  Bumbu Cemplung"
- "2 lbr daun salam"
- "2 batang sereh geprek"
- "5 lbr daun jeruk"
- "2 batang daun bawang potong pendek tambahan saya"
- "  Bahan Pelengkap"
- " Daun seledri"
- " Tomat"
- " Cabai rawit"
- " Jeruk nipis"
- " Kecap"
recipeinstructions:
- "Siapkan bahan. Cuci bersih ayam fillet. Potong dadu. Marinasi ayam dengan garam sisihkan. Kentang, kupas lalu cuci bersih dan goreng setengah kering. Sisishkan."
- "Panaskan sedikit minyak. Tumis bumbu halus bersama daun salam dan sereh. Masak hingga harum dan kecoklatan."
- "Didihkan air lalu masukkan bumbu halus, daun jeruk, daun bawang, kentang dan ayam. Masak hingga air mendidih kembali dan ayam matang."
- "Terakhir tambahkan garam, gula, penyedap rasa dan santan. Aduk rata lalu koreksi rasa."
- "Sajikan hangat bersama bahan pelengkap."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 232 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/75582be4ef1c543d/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang wanita, menyuguhkan hidangan enak buat orang tercinta adalah hal yang memuaskan untuk kamu sendiri. Kewajiban seorang istri bukan sekadar mengerjakan pekerjaan rumah saja, tetapi anda juga wajib memastikan keperluan gizi terpenuhi dan juga olahan yang dimakan anak-anak mesti lezat.

Di masa  sekarang, kalian sebenarnya bisa mengorder hidangan praktis tidak harus repot membuatnya lebih dulu. Tapi banyak juga lho orang yang selalu mau memberikan makanan yang terbaik bagi keluarganya. Lantaran, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan famili. 



Mungkinkah anda merupakan seorang penyuka soto ayam santan?. Tahukah kamu, soto ayam santan adalah hidangan khas di Indonesia yang kini disukai oleh kebanyakan orang di berbagai tempat di Indonesia. Kita dapat menghidangkan soto ayam santan sendiri di rumah dan pasti jadi santapan kesukaanmu di akhir pekanmu.

Kalian tak perlu bingung jika kamu ingin mendapatkan soto ayam santan, lantaran soto ayam santan gampang untuk didapatkan dan juga kalian pun boleh membuatnya sendiri di tempatmu. soto ayam santan dapat dimasak dengan beragam cara. Kini sudah banyak resep modern yang menjadikan soto ayam santan semakin lebih lezat.

Resep soto ayam santan pun mudah untuk dibikin, lho. Kamu tidak usah ribet-ribet untuk membeli soto ayam santan, sebab Kalian mampu membuatnya di rumahmu. Bagi Kita yang mau mencobanya, berikut ini cara membuat soto ayam santan yang lezat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Soto Ayam Santan:

1. Siapkan 1/2 kg ayam fillet
1. Ambil 2 bh kentang
1. Ambil 1 bks santan instant 65ml
1. Gunakan 1 bh belimbing dewa manis (me: skip 😁 ganti gula pasir 1 sdm)
1. Ambil 1/2 sdt garam utk marinasi ayam
1. Siapkan 1 sdt garam utk kuah soto
1. Sediakan 1 sdt penyedap rasa
1. Sediakan 4 gelas belimbing air matang (lebih enak pakai air kaldu ayam)
1. Sediakan  Minyak utk menumis bumbu
1. Siapkan  ◾ Bumbu Halus
1. Ambil 7 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Siapkan 1 sdt ketumbar bubuk
1. Sediakan 1/2 sdt jinten
1. Ambil 1 ruas jari kencur
1. Siapkan  ◾ Bumbu Cemplung
1. Gunakan 2 lbr daun salam
1. Sediakan 2 batang sereh geprek
1. Siapkan 5 lbr daun jeruk
1. Ambil 2 batang daun bawang potong pendek (tambahan saya)
1. Sediakan  ◾ Bahan Pelengkap
1. Ambil  Daun seledri
1. Sediakan  Tomat
1. Ambil  Cabai rawit
1. Sediakan  Jeruk nipis
1. Gunakan  Kecap




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Santan:

1. Siapkan bahan. Cuci bersih ayam fillet. Potong dadu. Marinasi ayam dengan garam sisihkan. Kentang, kupas lalu cuci bersih dan goreng setengah kering. Sisishkan.
1. Panaskan sedikit minyak. Tumis bumbu halus bersama daun salam dan sereh. Masak hingga harum dan kecoklatan.
1. Didihkan air lalu masukkan bumbu halus, daun jeruk, daun bawang, kentang dan ayam. Masak hingga air mendidih kembali dan ayam matang.
1. Terakhir tambahkan garam, gula, penyedap rasa dan santan. Aduk rata lalu koreksi rasa.
1. Sajikan hangat bersama bahan pelengkap.




Ternyata cara membuat soto ayam santan yang lezat tidak rumit ini gampang banget ya! Kamu semua dapat menghidangkannya. Resep soto ayam santan Sangat cocok banget buat kamu yang sedang belajar memasak atau juga bagi anda yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba membuat resep soto ayam santan nikmat sederhana ini? Kalau kamu mau, yuk kita segera buruan menyiapkan peralatan dan bahannya, kemudian bikin deh Resep soto ayam santan yang mantab dan tidak rumit ini. Sangat gampang kan. 

Oleh karena itu, daripada kamu berlama-lama, maka kita langsung saja bikin resep soto ayam santan ini. Dijamin anda tak akan nyesel sudah membuat resep soto ayam santan nikmat tidak ribet ini! Selamat mencoba dengan resep soto ayam santan lezat tidak rumit ini di rumah kalian masing-masing,ya!.

