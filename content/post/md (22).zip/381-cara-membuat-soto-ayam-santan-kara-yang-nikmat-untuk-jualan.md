---
description: "Cara membuat Soto Ayam Santan Kara yang nikmat Untuk Jualan"
title: "Cara membuat Soto Ayam Santan Kara yang nikmat Untuk Jualan"
slug: 381-cara-membuat-soto-ayam-santan-kara-yang-nikmat-untuk-jualan
date: 2021-01-24T08:57:47.736Z
image: https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg
author: Violet Davis
ratingvalue: 4.9
reviewcount: 12
recipeingredient:
- "1/2 ekor ayam"
- " Isian soto kol tauge tomat kentang jeruk nipis emping"
- " Bumbu halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "3 buah kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 sdt ketumbar"
- "1 sdt lada"
- "1 sdt jinten"
- "1 gelas kecil air"
- " Bumbu Cemplung"
- "1 liter air"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 serai digeprek"
- "1 ruas lengkuas digeprek"
- "1/4 bulatan biji pala"
- "3 buah bunga"
- "secukupnya Daun bawang"
- "1 sachet santan kara kecil"
- "secukupnya Gula msg Royco"
recipeinstructions:
- "Blender semua bumbu halus, kemudian tumis sampai air menyusut dan bumbu keluar minyak dan benar2 matang"
- "Cuci bersih ayam, potong2. Panaskan panci masukkan semua bumbu Cemplung (kecuali santan dan daun bawang) beserta ayam, dan masukkan bumbu halus yg sudah ditumis tadi. Bila ayam sudah setengah matang angkat lalu goreng ayam. Sisihkan suwir2"
- "Masukkan santan ke dalam panci tunggu sampai mendidih sambil diaduk2. Koreksi rasa, masukkan daun bawang dan jadi deh."
- "Potong2 isian soto, rebus tauge, dan goreng kentang (empingnya lupa di foto)"
- "Cara buat sambal: 31 cabe rawit direbus, ulek dengan msg kasih beberapa tetes jeruk nipis. (Ga perlu dikasih garam)"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 182 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto Ayam Santan Kara](https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan panganan mantab pada keluarga merupakan suatu hal yang memuaskan bagi anda sendiri. Tanggung jawab seorang istri bukan cuma menjaga rumah saja, tapi anda juga wajib menyediakan keperluan gizi tercukupi dan olahan yang dimakan orang tercinta harus nikmat.

Di waktu  saat ini, kita memang dapat mengorder olahan praktis walaupun tidak harus capek membuatnya terlebih dahulu. Tetapi banyak juga lho orang yang selalu mau menghidangkan yang terenak bagi keluarganya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan selera keluarga tercinta. 



Apakah anda salah satu penyuka soto ayam santan kara?. Asal kamu tahu, soto ayam santan kara adalah makanan khas di Nusantara yang sekarang disukai oleh orang-orang dari hampir setiap daerah di Indonesia. Kamu bisa memasak soto ayam santan kara hasil sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di akhir pekan.

Kamu jangan bingung untuk mendapatkan soto ayam santan kara, lantaran soto ayam santan kara tidak sukar untuk dicari dan juga kamu pun dapat memasaknya sendiri di tempatmu. soto ayam santan kara dapat dibuat lewat beraneka cara. Saat ini telah banyak sekali cara modern yang membuat soto ayam santan kara lebih enak.

Resep soto ayam santan kara juga sangat gampang untuk dibuat, lho. Anda jangan capek-capek untuk membeli soto ayam santan kara, sebab Kita dapat menyiapkan di rumahmu. Bagi Kalian yang hendak membuatnya, di bawah ini adalah cara untuk membuat soto ayam santan kara yang nikamat yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto Ayam Santan Kara:

1. Siapkan 1/2 ekor ayam
1. Gunakan  Isian soto: kol, tauge, tomat, kentang, jeruk nipis, emping
1. Siapkan  Bumbu halus:
1. Gunakan 10 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Gunakan 3 buah kemiri
1. Sediakan 1 ruas kunyit
1. Sediakan 1 ruas jahe
1. Siapkan 1 sdt ketumbar
1. Siapkan 1 sdt lada
1. Ambil 1 sdt jinten
1. Siapkan 1 gelas kecil air
1. Gunakan  Bumbu Cemplung:
1. Gunakan 1 liter air
1. Siapkan 2 lembar daun salam
1. Gunakan 3 lembar daun jeruk
1. Gunakan 1 serai digeprek
1. Ambil 1 ruas lengkuas digeprek
1. Ambil 1/4 bulatan biji pala
1. Gunakan 3 buah bunga
1. Siapkan secukupnya Daun bawang
1. Siapkan 1 sachet santan kara kecil
1. Sediakan secukupnya Gula, msg, Royco




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Santan Kara:

1. Blender semua bumbu halus, kemudian tumis sampai air menyusut dan bumbu keluar minyak dan benar2 matang
1. Cuci bersih ayam, potong2. Panaskan panci masukkan semua bumbu Cemplung (kecuali santan dan daun bawang) beserta ayam, dan masukkan bumbu halus yg sudah ditumis tadi. Bila ayam sudah setengah matang angkat lalu goreng ayam. Sisihkan suwir2
1. Masukkan santan ke dalam panci tunggu sampai mendidih sambil diaduk2. Koreksi rasa, masukkan daun bawang dan jadi deh.
1. Potong2 isian soto, rebus tauge, dan goreng kentang (empingnya lupa di foto)
1. Cara buat sambal: 31 cabe rawit direbus, ulek dengan msg kasih beberapa tetes jeruk nipis. (Ga perlu dikasih garam)




Ternyata cara buat soto ayam santan kara yang mantab tidak rumit ini gampang sekali ya! Kalian semua dapat membuatnya. Cara buat soto ayam santan kara Sangat sesuai banget untuk kita yang baru belajar memasak maupun juga untuk anda yang telah lihai memasak.

Tertarik untuk mulai mencoba membuat resep soto ayam santan kara enak simple ini? Kalau kamu mau, mending kamu segera buruan siapin peralatan dan bahannya, setelah itu buat deh Resep soto ayam santan kara yang nikmat dan tidak rumit ini. Betul-betul mudah kan. 

Oleh karena itu, daripada kalian diam saja, hayo langsung aja hidangkan resep soto ayam santan kara ini. Pasti kamu gak akan menyesal sudah bikin resep soto ayam santan kara lezat simple ini! Selamat mencoba dengan resep soto ayam santan kara enak sederhana ini di rumah kalian masing-masing,ya!.

