---
description: "Cara membuat Soto Ayam Kuah Santan yang lezat dan Mudah Dibuat"
title: "Cara membuat Soto Ayam Kuah Santan yang lezat dan Mudah Dibuat"
slug: 400-cara-membuat-soto-ayam-kuah-santan-yang-lezat-dan-mudah-dibuat
date: 2021-03-04T18:03:43.981Z
image: https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg
author: Edna Long
ratingvalue: 4.7
reviewcount: 11
recipeingredient:
- "1/2 kg ayam"
- "1 bks kara santan"
- "1,5 liter air"
- "1 batang sereh"
- "1 ruas lengkuas"
- "2 lembar daun salam"
- "5 lembar daun jeruk"
- "1 tomat"
- "2 daun bawang"
- "Secukupnya bawang goreng"
- "2 jeruk limau"
- "1/2 sdt garam"
- "1 sdm gula"
- " Bumbu halus "
- "5 bawang putih"
- "10 bawang merah"
- "2 ruas kunyit"
- "3 kemiri"
- "1/2 sdt lada"
recipeinstructions:
- "Tumis bumbu halus hingga harum, tambahkan sereh, lengkuas, daun salam, daun jeruk."
- "Masukkan ayam yang telah dicuci bersih dan dipotong*.Tambahkan air, biarkan meresap dan ayam lunak."
- "Masukkan santan, garam, kaldu, gula. Aduk rata, jangan lupa koreksi rasa."
- "Jika sudah, siapkan mangkuk, masukkan kuah, beri potongan tomat, daun bawang, bawang goreng, perasan jeruk limau dan sajikan."
categories:
- Resep
tags:
- soto
- ayam
- kuah

katakunci: soto ayam kuah 
nutrition: 262 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam Kuah Santan](https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan olahan menggugah selera pada keluarga tercinta adalah suatu hal yang menggembirakan bagi anda sendiri. Tanggung jawab seorang ibu bukan cuma menjaga rumah saja, tetapi kamu pun harus memastikan keperluan nutrisi tercukupi dan olahan yang dimakan orang tercinta harus mantab.

Di waktu  saat ini, kamu sebenarnya bisa memesan olahan instan walaupun tidak harus susah membuatnya dahulu. Tapi banyak juga orang yang selalu ingin memberikan hidangan yang terenak bagi keluarganya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai masakan kesukaan famili. 



Apakah kamu salah satu penikmat soto ayam kuah santan?. Asal kamu tahu, soto ayam kuah santan adalah sajian khas di Indonesia yang kini disenangi oleh banyak orang di hampir setiap tempat di Nusantara. Kalian bisa menghidangkan soto ayam kuah santan sendiri di rumah dan dapat dijadikan makanan favorit di hari libur.

Anda tak perlu bingung jika kamu ingin menyantap soto ayam kuah santan, lantaran soto ayam kuah santan tidak sukar untuk ditemukan dan juga anda pun boleh menghidangkannya sendiri di tempatmu. soto ayam kuah santan dapat dimasak memalui beragam cara. Saat ini telah banyak cara modern yang membuat soto ayam kuah santan semakin lebih lezat.

Resep soto ayam kuah santan juga sangat mudah untuk dibuat, lho. Kalian tidak perlu capek-capek untuk membeli soto ayam kuah santan, lantaran Kita bisa menyiapkan di rumahmu. Bagi Anda yang mau mencobanya, dibawah ini merupakan cara untuk membuat soto ayam kuah santan yang enak yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Soto Ayam Kuah Santan:

1. Gunakan 1/2 kg ayam
1. Siapkan 1 bks kara santan
1. Gunakan 1,5 liter air
1. Sediakan 1 batang sereh
1. Ambil 1 ruas lengkuas
1. Gunakan 2 lembar daun salam
1. Sediakan 5 lembar daun jeruk
1. Gunakan 1 tomat
1. Ambil 2 daun bawang
1. Gunakan Secukupnya bawang goreng
1. Siapkan 2 jeruk limau
1. Ambil 1/2 sdt garam
1. Ambil 1 sdm gula
1. Sediakan  Bumbu halus :
1. Sediakan 5 bawang putih
1. Ambil 10 bawang merah
1. Sediakan 2 ruas kunyit
1. Gunakan 3 kemiri
1. Gunakan 1/2 sdt lada




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Kuah Santan:

1. Tumis bumbu halus hingga harum, tambahkan sereh, lengkuas, daun salam, daun jeruk.
1. Masukkan ayam yang telah dicuci bersih dan dipotong*.Tambahkan air, biarkan meresap dan ayam lunak.
1. Masukkan santan, garam, kaldu, gula. Aduk rata, jangan lupa koreksi rasa.
1. Jika sudah, siapkan mangkuk, masukkan kuah, beri potongan tomat, daun bawang, bawang goreng, perasan jeruk limau dan sajikan.




Wah ternyata cara buat soto ayam kuah santan yang mantab tidak ribet ini enteng sekali ya! Semua orang dapat membuatnya. Resep soto ayam kuah santan Cocok banget untuk kita yang baru akan belajar memasak atau juga bagi kamu yang telah jago memasak.

Apakah kamu mau mencoba buat resep soto ayam kuah santan mantab sederhana ini? Kalau kamu mau, ayo kamu segera buruan siapkan alat-alat dan bahannya, kemudian buat deh Resep soto ayam kuah santan yang nikmat dan sederhana ini. Sangat gampang kan. 

Maka dari itu, ketimbang kita berlama-lama, yuk kita langsung saja sajikan resep soto ayam kuah santan ini. Pasti kalian tiidak akan menyesal sudah membuat resep soto ayam kuah santan nikmat simple ini! Selamat mencoba dengan resep soto ayam kuah santan mantab simple ini di tempat tinggal masing-masing,ya!.

