---
description: "Cara buat Ayam bakar bumbu kecap yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam bakar bumbu kecap yang nikmat dan Mudah Dibuat"
slug: 418-cara-buat-ayam-bakar-bumbu-kecap-yang-nikmat-dan-mudah-dibuat
date: 2021-04-06T23:37:24.651Z
image: https://img-global.cpcdn.com/recipes/b65e32e9934c9cd3/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b65e32e9934c9cd3/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b65e32e9934c9cd3/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg
author: Henrietta Obrien
ratingvalue: 3.9
reviewcount: 13
recipeingredient:
- "1/2 kg sayap ayam"
- "1 buah jeruk nipis"
- "1 sdm gula merah sisir"
- "2 sdm kecap manis"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang sereh"
- "300 ml air matang"
- " bumbu halus "
- "8 siung bawang merah"
- "4 siung bawang putih"
- "4 buah cabe rawit merah"
- "2 cm jahe"
- "3 cm lengkuas"
- "2 butir kemiri"
- "2 buah asam kandis"
- " Garam merica dan gula"
recipeinstructions:
- "Cuci bersih ayam. Kemudian marinasi dgn jeruk nipis dan garam. Diamkan 15 menit, kemudian cuci bersih kembali"
- "Tumis bumbu halus + duo daun dan sereh. Masukkan ayam dan tambahkan air. Koreksi rasa. Masak hingga air menyusut"
- "Panggang di happy call/ teflon dgn sisa bumbu sambil dibolak balik."
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 191 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam bakar bumbu kecap](https://img-global.cpcdn.com/recipes/b65e32e9934c9cd3/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg)

Andai kamu seorang wanita, menyediakan olahan nikmat pada orang tercinta merupakan hal yang membahagiakan bagi anda sendiri. Tanggung jawab seorang ibu bukan sekedar menangani rumah saja, tapi kamu juga wajib memastikan keperluan nutrisi terpenuhi dan juga masakan yang disantap orang tercinta mesti sedap.

Di waktu  saat ini, kamu memang dapat memesan santapan yang sudah jadi meski tidak harus repot membuatnya lebih dulu. Tapi banyak juga mereka yang selalu mau memberikan yang terenak untuk orang yang dicintainya. Lantaran, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai dengan makanan kesukaan famili. 



Mungkinkah anda merupakan seorang penggemar ayam bakar bumbu kecap?. Tahukah kamu, ayam bakar bumbu kecap adalah sajian khas di Indonesia yang kini disenangi oleh banyak orang dari berbagai daerah di Indonesia. Kita bisa menghidangkan ayam bakar bumbu kecap buatan sendiri di rumahmu dan boleh dijadikan hidangan favoritmu di hari liburmu.

Anda jangan bingung jika kamu ingin menyantap ayam bakar bumbu kecap, sebab ayam bakar bumbu kecap gampang untuk didapatkan dan juga kamu pun boleh membuatnya sendiri di rumah. ayam bakar bumbu kecap boleh dimasak memalui berbagai cara. Sekarang sudah banyak resep modern yang menjadikan ayam bakar bumbu kecap semakin lebih lezat.

Resep ayam bakar bumbu kecap pun gampang sekali dihidangkan, lho. Kamu tidak usah ribet-ribet untuk membeli ayam bakar bumbu kecap, sebab Kamu bisa menghidangkan sendiri di rumah. Bagi Anda yang hendak menghidangkannya, dibawah ini merupakan cara untuk membuat ayam bakar bumbu kecap yang mantab yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam bakar bumbu kecap:

1. Sediakan 1/2 kg sayap ayam
1. Siapkan 1 buah jeruk nipis
1. Ambil 1 sdm gula merah (sisir)
1. Sediakan 2 sdm kecap manis
1. Gunakan 4 lembar daun jeruk
1. Ambil 2 lembar daun salam
1. Ambil 1 batang sereh
1. Sediakan 300 ml air matang
1. Gunakan  🌻bumbu halus :
1. Sediakan 8 siung bawang merah
1. Ambil 4 siung bawang putih
1. Sediakan 4 buah cabe rawit merah
1. Siapkan 2 cm jahe
1. Ambil 3 cm lengkuas
1. Gunakan 2 butir kemiri
1. Ambil 2 buah asam kandis
1. Gunakan  Garam, merica dan gula




<!--inarticleads2-->

##### Cara membuat Ayam bakar bumbu kecap:

1. Cuci bersih ayam. Kemudian marinasi dgn jeruk nipis dan garam. Diamkan 15 menit, kemudian cuci bersih kembali
1. Tumis bumbu halus + duo daun dan sereh. Masukkan ayam dan tambahkan air. Koreksi rasa. Masak hingga air menyusut
1. Panggang di happy call/ teflon dgn sisa bumbu sambil dibolak balik.




Wah ternyata cara buat ayam bakar bumbu kecap yang mantab tidak ribet ini mudah banget ya! Kamu semua mampu mencobanya. Resep ayam bakar bumbu kecap Cocok banget buat kamu yang baru belajar memasak maupun juga untuk kalian yang telah hebat memasak.

Apakah kamu tertarik mulai mencoba membikin resep ayam bakar bumbu kecap lezat tidak rumit ini? Kalau kamu mau, ayo kalian segera siapkan peralatan dan bahannya, setelah itu bikin deh Resep ayam bakar bumbu kecap yang lezat dan simple ini. Sangat gampang kan. 

Jadi, daripada anda berfikir lama-lama, maka langsung aja bikin resep ayam bakar bumbu kecap ini. Dijamin anda gak akan menyesal membuat resep ayam bakar bumbu kecap lezat simple ini! Selamat berkreasi dengan resep ayam bakar bumbu kecap lezat sederhana ini di tempat tinggal masing-masing,ya!.

