---
description: "Bahan-bahan Ayam Kentucky ala KFC Sederhana Untuk Jualan"
title: "Bahan-bahan Ayam Kentucky ala KFC Sederhana Untuk Jualan"
slug: 41-bahan-bahan-ayam-kentucky-ala-kfc-sederhana-untuk-jualan
date: 2021-05-21T07:01:42.588Z
image: https://img-global.cpcdn.com/recipes/c984b5f6ef443d1e/680x482cq70/ayam-kentucky-ala-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c984b5f6ef443d1e/680x482cq70/ayam-kentucky-ala-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c984b5f6ef443d1e/680x482cq70/ayam-kentucky-ala-kfc-foto-resep-utama.jpg
author: Madge Franklin
ratingvalue: 4.2
reviewcount: 11
recipeingredient:
- "4 ekor ayam"
- " Bumbu marinasi"
- "1 sdt bawang putih bubuk sy 2 siung cincang halus"
- "1/2 sdt lada bubuk"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt kunyit bubuk"
- "1 sdt kaldu ayam"
- "1/2 sdt garam"
- " Bahan pelapis "
- "300 gr tepung terigu cakra"
- "2 sdt bawang putih bubuk sy skip krn kosong"
- "1/2 sdt baking powder"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- "1 sdt kaldu ayam"
- " Bahan pencelup "
- "3 sdm tepung diambil dr bahan pelapis"
- "400 ml air dingines"
recipeinstructions:
- "Cuci bersih ayam, beri bumbu marinasi aduk rata diamkan di kulkas selama 1 jam"
- "Campurkan semua bahan pelapis lalu ambil 3 adonan (utk adonan basah) beri air es perlahan aduk rata jgn sampai bergelindir adonan jgn terlalu encer"
- "Masukan ayam yg sudah dimarinasi kedalam adonan tepung kering lalu masukan keadonan basah lalu gulir lagi keadonan kering sambil di cubit2 dikit"
- "Panaskan dg minyak yg banyak goreng ayam hingga kecoklatan dan gurih angkat lalu tiriskan. Siap deh disajikan kfc ala ala nya. Ini favorite anak ku banget 😍😍"
categories:
- Resep
tags:
- ayam
- kentucky
- ala

katakunci: ayam kentucky ala 
nutrition: 134 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Kentucky ala KFC](https://img-global.cpcdn.com/recipes/c984b5f6ef443d1e/680x482cq70/ayam-kentucky-ala-kfc-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan panganan menggugah selera bagi keluarga adalah hal yang menyenangkan bagi kamu sendiri. Kewajiban seorang ibu bukan hanya mengerjakan pekerjaan rumah saja, namun kamu juga harus menyediakan keperluan nutrisi terpenuhi dan juga olahan yang dikonsumsi anak-anak harus enak.

Di waktu  saat ini, kalian memang bisa memesan panganan yang sudah jadi walaupun tidak harus repot membuatnya dahulu. Tetapi ada juga lho orang yang memang mau memberikan hidangan yang terenak bagi orang yang dicintainya. Karena, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan famili. 



Mungkinkah kamu salah satu penggemar ayam kentucky ala kfc?. Tahukah kamu, ayam kentucky ala kfc merupakan makanan khas di Nusantara yang sekarang digemari oleh setiap orang di hampir setiap tempat di Nusantara. Anda bisa memasak ayam kentucky ala kfc olahan sendiri di rumah dan pasti jadi camilan kegemaranmu di hari libur.

Kita jangan bingung untuk mendapatkan ayam kentucky ala kfc, karena ayam kentucky ala kfc mudah untuk ditemukan dan kalian pun bisa membuatnya sendiri di rumah. ayam kentucky ala kfc boleh dibuat dengan bermacam cara. Kini telah banyak resep modern yang membuat ayam kentucky ala kfc lebih lezat.

Resep ayam kentucky ala kfc pun mudah sekali dihidangkan, lho. Kita tidak usah repot-repot untuk memesan ayam kentucky ala kfc, sebab Kita bisa menyiapkan di rumah sendiri. Bagi Kalian yang mau mencobanya, inilah cara menyajikan ayam kentucky ala kfc yang nikamat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Kentucky ala KFC:

1. Ambil 4 ekor ayam
1. Siapkan  Bumbu marinasi
1. Gunakan 1 sdt bawang putih bubuk (sy 2 siung cincang halus)
1. Ambil 1/2 sdt lada bubuk
1. Gunakan 1/2 sdt ketumbar bubuk
1. Gunakan 1/2 sdt kunyit bubuk
1. Siapkan 1 sdt kaldu ayam
1. Gunakan 1/2 sdt garam
1. Siapkan  Bahan pelapis :
1. Ambil 300 gr tepung terigu cakra
1. Siapkan 2 sdt bawang putih bubuk (sy skip krn kosong)
1. Gunakan 1/2 sdt baking powder
1. Siapkan 1/2 sdt lada bubuk
1. Gunakan 1/2 sdt garam
1. Sediakan 1 sdt kaldu ayam
1. Ambil  Bahan pencelup :
1. Sediakan 3 sdm tepung (diambil dr bahan pelapis)
1. Ambil 400 ml air dingin/es




<!--inarticleads2-->

##### Cara menyiapkan Ayam Kentucky ala KFC:

1. Cuci bersih ayam, beri bumbu marinasi aduk rata diamkan di kulkas selama 1 jam
1. Campurkan semua bahan pelapis lalu ambil 3 adonan (utk adonan basah) beri air es perlahan aduk rata jgn sampai bergelindir adonan jgn terlalu encer
1. Masukan ayam yg sudah dimarinasi kedalam adonan tepung kering lalu masukan keadonan basah lalu gulir lagi keadonan kering sambil di cubit2 dikit
1. Panaskan dg minyak yg banyak goreng ayam hingga kecoklatan dan gurih angkat lalu tiriskan. Siap deh disajikan kfc ala ala nya. Ini favorite anak ku banget 😍😍




Wah ternyata resep ayam kentucky ala kfc yang enak sederhana ini mudah sekali ya! Kamu semua dapat membuatnya. Cara buat ayam kentucky ala kfc Sangat cocok banget untuk anda yang baru mau belajar memasak maupun juga untuk anda yang telah lihai dalam memasak.

Apakah kamu mau mulai mencoba membuat resep ayam kentucky ala kfc nikmat sederhana ini? Kalau kamu ingin, mending kamu segera menyiapkan peralatan dan bahannya, lalu bikin deh Resep ayam kentucky ala kfc yang nikmat dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka, ketimbang kita berlama-lama, yuk kita langsung saja hidangkan resep ayam kentucky ala kfc ini. Pasti kamu gak akan nyesel sudah membuat resep ayam kentucky ala kfc nikmat tidak rumit ini! Selamat berkreasi dengan resep ayam kentucky ala kfc mantab simple ini di tempat tinggal kalian masing-masing,oke!.

