---
description: "Resep Ayam Goreng Saus Asam Pedas Manis yang nikmat dan Mudah Dibuat"
title: "Resep Ayam Goreng Saus Asam Pedas Manis yang nikmat dan Mudah Dibuat"
slug: 128-resep-ayam-goreng-saus-asam-pedas-manis-yang-nikmat-dan-mudah-dibuat
date: 2021-04-28T18:40:57.035Z
image: https://img-global.cpcdn.com/recipes/8bd57cc2d6b25f39/680x482cq70/ayam-goreng-saus-asam-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8bd57cc2d6b25f39/680x482cq70/ayam-goreng-saus-asam-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8bd57cc2d6b25f39/680x482cq70/ayam-goreng-saus-asam-pedas-manis-foto-resep-utama.jpg
author: Roy Turner
ratingvalue: 4.2
reviewcount: 12
recipeingredient:
- " Bahanbahan utama"
- "1 bungkus ayam paha atau dada fillet 10 potong"
- " BahanBahan Bumbu Ayam"
- "1 butir telurputih  kuning"
- "1/1/4 sendok tepung terigu"
- "2 sendok makan tepung maizena"
- "1/1/2 sendok teh garam"
- " BahanBahan Bumbu Ayam"
- "2 sendok makan Thai Tom Yam Paste lihat gambar di bagian step"
- "3 siung bawang putih cincang kecilkecil"
- "3 sendok makan saus tiram"
- "2 sendok makan cuka putih"
- "3 sendok makan cabe murah bubuk"
- "1 sendok makan fish sauce kecap ikan"
- "1 gelas kecil teh air"
- " BahanBahan Pelengkap Bumbu"
- "4 helai daun jeruk purut cincang kecilkecil"
- "1 buah jeruk lemon hijau lime ambil jusnya"
- "1/2 kulit jeruk lemon hijau kupas kulitnya"
- "3/4 gelas tepung terigu"
- "1/4 gelas tepung maizena"
recipeinstructions:
- "Cuci ayam hingga bersih lalu lumuri dua permukaan ayam dengan bahan-bahan sebagai berikiut lalu kocok dan diamkan selama 15 menit : tepung maizena, garam dan 1 butir telur kocok (putih dan kuning telur)."
- "Inilah gambar &#34;Thai Tom Yam Paste&#34; yang saya buat setahun yang lalu."
- "Masukan lalu campurkan bahan-bahan untuk bumbu ayam goreng ini ke dalam panci lalu rebus hingga mendidih dan sausnya mengental : Tom Yam Paste, bawang putih cincang, garam, gula pasir putih, cuka putih, saus tiram dan air. Matikan kompor api setelah saus sudah mengental dan biarkan sejenak; tambahkan jus jeruk lemon hijau lalu aduk hingga rata."
- "Selimuti dan tenggelamkan potongan-potongan ayam ke dalam tepung maizena dan tepung terigu. Panaskan minyak dalam wajan hingga mendidih lalu goreng ayam selama 3 menit atau hingga ayam berawarna memesan."
- "Tuang saus bumbu ayam ke dalam mangkok lalu selimuti ayam dengan saus tersebut; tambahkan potongan-potongandaun jeruk purut."
categories:
- Resep
tags:
- ayam
- goreng
- saus

katakunci: ayam goreng saus 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Saus Asam Pedas Manis](https://img-global.cpcdn.com/recipes/8bd57cc2d6b25f39/680x482cq70/ayam-goreng-saus-asam-pedas-manis-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan olahan mantab kepada keluarga adalah hal yang membahagiakan untuk kita sendiri. Tanggung jawab seorang istri Tidak saja mengurus rumah saja, namun anda juga harus memastikan kebutuhan nutrisi terpenuhi dan olahan yang dimakan anak-anak wajib menggugah selera.

Di era  saat ini, kita memang dapat membeli santapan yang sudah jadi walaupun tidak harus capek memasaknya terlebih dahulu. Tetapi banyak juga lho mereka yang selalu mau memberikan yang terenak bagi orang yang dicintainya. Karena, menghidangkan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 

Taburkan tepung terigu, tepung sagu, air, merica bubuk &amp; bumbu penyedap kedalam wadah yang berisi ayam tadi. Lihat juga resep Yangnyeom Tongdak (Ayam Goreng Asam Manis Pedas Korea) enak lainnya. Jika ayam goreng tepung terasa terlalu biasa untuk terus menerus disajikan di rumah bersama keluarga, resep ayam saus asam manis ini mungkin bisa menambah variasi makan Anda.

Mungkinkah anda adalah seorang penikmat ayam goreng saus asam pedas manis?. Asal kamu tahu, ayam goreng saus asam pedas manis merupakan makanan khas di Indonesia yang saat ini disenangi oleh banyak orang dari berbagai tempat di Nusantara. Anda bisa memasak ayam goreng saus asam pedas manis hasil sendiri di rumah dan pasti jadi hidangan favorit di hari libur.

Kalian tidak perlu bingung untuk mendapatkan ayam goreng saus asam pedas manis, lantaran ayam goreng saus asam pedas manis tidak sulit untuk didapatkan dan juga kalian pun dapat menghidangkannya sendiri di rumah. ayam goreng saus asam pedas manis bisa diolah dengan beragam cara. Saat ini telah banyak cara kekinian yang menjadikan ayam goreng saus asam pedas manis lebih mantap.

Resep ayam goreng saus asam pedas manis juga sangat gampang dibuat, lho. Kamu tidak usah ribet-ribet untuk memesan ayam goreng saus asam pedas manis, sebab Kita dapat menghidangkan sendiri di rumah. Bagi Kalian yang akan mencobanya, inilah cara untuk menyajikan ayam goreng saus asam pedas manis yang lezat yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Goreng Saus Asam Pedas Manis:

1. Gunakan  Bahan-bahan utama:
1. Gunakan 1 bungkus ayam paha atau dada fillet (10 potong)
1. Ambil  Bahan-Bahan Bumbu Ayam:
1. Ambil 1 butir telur(putih &amp; kuning)
1. Siapkan 1/1/4 sendok tepung terigu
1. Ambil 2 sendok makan tepung maizena
1. Gunakan 1/1/2 sendok teh garam
1. Ambil  Bahan-Bahan Bumbu Ayam:
1. Ambil 2 sendok makan &#34;Thai Tom Yam Paste&#34; (lihat gambar di bagian step)
1. Siapkan 3 siung bawang putih (cincang kecil-kecil)
1. Sediakan 3 sendok makan saus tiram
1. Sediakan 2 sendok makan cuka putih
1. Gunakan 3 sendok makan cabe murah bubuk
1. Sediakan 1 sendok makan fish sauce (kecap ikan)
1. Siapkan 1 gelas kecil teh air
1. Siapkan  Bahan-Bahan Pelengkap Bumbu:
1. Siapkan 4 helai daun jeruk purut (cincang kecil-kecil)
1. Ambil 1 buah jeruk lemon hijau (lime) ambil jusnya
1. Gunakan 1/2 kulit jeruk lemon hijau (kupas kulitnya)
1. Ambil 3/4 gelas tepung terigu
1. Sediakan 1/4 gelas tepung maizena


Pada mulanya, saus tersebut bukanlah disajikan dengan ayam goreng, tetapi digunakan dalam masakan Tiongkok sebagai saus daging babi yang biasa disebut gulouyuk dalam bahasa Kantonis. Ayam Bumbu Pedas Manis Foto: Dok. Daging ayam untuk ayam bumbu pedas manis ini bisa pakai ayam kampung atau ayam jantan yang dipotong-potong. Baik menu seafood, ayam maupun daging akan terasa sangat enak bila dimasak dengan saus asam manis. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Saus Asam Pedas Manis:

1. Cuci ayam hingga bersih lalu lumuri dua permukaan ayam dengan bahan-bahan sebagai berikiut lalu kocok dan diamkan selama 15 menit : tepung maizena, garam dan 1 butir telur kocok (putih dan kuning telur).
1. Inilah gambar &#34;Thai Tom Yam Paste&#34; yang saya buat setahun yang lalu.
1. Masukan lalu campurkan bahan-bahan untuk bumbu ayam goreng ini ke dalam panci lalu rebus hingga mendidih dan sausnya mengental : Tom Yam Paste, bawang putih cincang, garam, gula pasir putih, cuka putih, saus tiram dan air. Matikan kompor api setelah saus sudah mengental dan biarkan sejenak; tambahkan jus jeruk lemon hijau lalu aduk hingga rata.
1. Selimuti dan tenggelamkan potongan-potongan ayam ke dalam tepung maizena dan tepung terigu. Panaskan minyak dalam wajan hingga mendidih lalu goreng ayam selama 3 menit atau hingga ayam berawarna memesan.
1. Tuang saus bumbu ayam ke dalam mangkok lalu selimuti ayam dengan saus tersebut; tambahkan potongan-potongandaun jeruk purut.


Terlebih bagi kamu yang tidak begitu menyukai masakan pedas dengan rasa menyengat. Saus asam manis memang mudah ditemukan di pasar, supermarket bahkan toko kelontongan sekalipun dalam bentuk kemasan praktis. Mau hidangan ayam goreng saus pedas manis ala restoran nongkrong di meja makannya bunda,,, bunda gak perlu harus pergi ke restoran kok. karena ternyata ayam goreng pakai saus pedas manis sangat mudah di masak di dapur bunda sendiri. Ayam menjadi makanan favorit semua orang. Ragam masakan nikmat olahan ayam bisa Anda temukan di berbagai restoran. 

Wah ternyata cara membuat ayam goreng saus asam pedas manis yang nikamt sederhana ini enteng banget ya! Kalian semua bisa menghidangkannya. Cara Membuat ayam goreng saus asam pedas manis Sangat sesuai banget buat kamu yang baru belajar memasak ataupun untuk kalian yang sudah pandai memasak.

Tertarik untuk mulai mencoba bikin resep ayam goreng saus asam pedas manis mantab simple ini? Kalau kalian tertarik, ayo kamu segera siapkan alat dan bahannya, setelah itu bikin deh Resep ayam goreng saus asam pedas manis yang mantab dan tidak rumit ini. Sangat taidak sulit kan. 

Maka dari itu, daripada anda berfikir lama-lama, maka kita langsung saja buat resep ayam goreng saus asam pedas manis ini. Dijamin kamu tiidak akan menyesal sudah buat resep ayam goreng saus asam pedas manis mantab tidak rumit ini! Selamat berkreasi dengan resep ayam goreng saus asam pedas manis lezat simple ini di rumah kalian sendiri,ya!.

