---
description: "Bahan-bahan Ayam Asam Manis Sederhana Untuk Jualan"
title: "Bahan-bahan Ayam Asam Manis Sederhana Untuk Jualan"
slug: 323-bahan-bahan-ayam-asam-manis-sederhana-untuk-jualan
date: 2021-06-07T21:38:58.348Z
image: https://img-global.cpcdn.com/recipes/8b4f16e3acfdb660/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b4f16e3acfdb660/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b4f16e3acfdb660/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Max Rodgers
ratingvalue: 3
reviewcount: 11
recipeingredient:
- "1/2 kg ayam fillet"
- " Tepung bumbu ayam krispy kentucky"
- "1/2 bawang bombay di iris"
- "4 siung bawang putih di cincang halus"
- "6 sdm saus tomat"
- "3 sdm saus sambal"
- "2 sdm kecap manis"
- "1 sdm saus tiram"
- "Secukupnya minyak untuk menumis"
- "Secukup nya garam dan kaldu bubuk"
- "Secukupnya air"
recipeinstructions:
- "Potong fillet ayam jadi potongan dadu (ukuran sedang)"
- "Siap kan tepung kentucky lalu campur air (adonan jangan terlalu encer dan jangan terlalu kental)"
- "Masukan ayam fillet ke adonan kentucky dan diamkan selama 10 menit"
- "Goreng ayam sampai kecoklatan lalu angkat"
- "Untuk saus asam manis, panaskan secukupnya minyak lalu tumis bawang putih yang sudah di cincang halus"
- "Masukan bawang bombay yang sudah di iris lalu aduk aduk sampai setengah matang"
- "Jika sudah tercium harum masukan saus tomat, saus sambal, kecap dan saus tiram. Aduk aduk hingga semua merata"
- "Jika sudah merata, tambahkan air secukupnya lalu tambahkan garam dan kaldu bubuk"
- "Koreksi rasa, jika sudah pas masukkan ayam ke dalam saus asam manis. Lalu di aduk sampai bumbu agak menyusut"
- "Selesaaaai~"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 184 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/8b4f16e3acfdb660/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, mempersiapkan santapan lezat bagi keluarga adalah suatu hal yang memuaskan bagi kita sendiri. Tugas seorang istri bukan sekedar menjaga rumah saja, tetapi anda pun wajib memastikan keperluan gizi terpenuhi dan juga masakan yang disantap anak-anak wajib sedap.

Di zaman  sekarang, kalian memang mampu membeli hidangan instan tidak harus repot mengolahnya dahulu. Namun ada juga lho mereka yang memang ingin memberikan hidangan yang terbaik untuk keluarganya. Karena, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan selera keluarga tercinta. 



Apakah anda salah satu penyuka ayam asam manis?. Asal kamu tahu, ayam asam manis adalah makanan khas di Indonesia yang saat ini digemari oleh setiap orang dari hampir setiap daerah di Indonesia. Kamu dapat membuat ayam asam manis sendiri di rumahmu dan pasti jadi camilan favoritmu di hari liburmu.

Anda tidak perlu bingung jika kamu ingin mendapatkan ayam asam manis, lantaran ayam asam manis mudah untuk didapatkan dan kalian pun dapat mengolahnya sendiri di rumah. ayam asam manis dapat dimasak memalui beraneka cara. Saat ini telah banyak sekali resep kekinian yang menjadikan ayam asam manis lebih enak.

Resep ayam asam manis juga sangat mudah dibikin, lho. Kalian tidak usah capek-capek untuk membeli ayam asam manis, karena Kalian mampu menyajikan di rumah sendiri. Bagi Kita yang mau mencobanya, di bawah ini adalah cara untuk membuat ayam asam manis yang mantab yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Asam Manis:

1. Gunakan 1/2 kg ayam fillet
1. Siapkan  Tepung bumbu ayam krispy kentucky
1. Ambil 1/2 bawang bombay (di iris)
1. Gunakan 4 siung bawang putih (di cincang halus)
1. Gunakan 6 sdm saus tomat
1. Siapkan 3 sdm saus sambal
1. Sediakan 2 sdm kecap manis
1. Siapkan 1 sdm saus tiram
1. Sediakan Secukupnya minyak untuk menumis
1. Sediakan Secukup nya garam dan kaldu bubuk
1. Ambil Secukupnya air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Asam Manis:

1. Potong fillet ayam jadi potongan dadu (ukuran sedang)
1. Siap kan tepung kentucky lalu campur air (adonan jangan terlalu encer dan jangan terlalu kental)
1. Masukan ayam fillet ke adonan kentucky dan diamkan selama 10 menit
1. Goreng ayam sampai kecoklatan lalu angkat
1. Untuk saus asam manis, panaskan secukupnya minyak lalu tumis bawang putih yang sudah di cincang halus
1. Masukan bawang bombay yang sudah di iris lalu aduk aduk sampai setengah matang
1. Jika sudah tercium harum masukan saus tomat, saus sambal, kecap dan saus tiram. Aduk aduk hingga semua merata
1. Jika sudah merata, tambahkan air secukupnya lalu tambahkan garam dan kaldu bubuk
1. Koreksi rasa, jika sudah pas masukkan ayam ke dalam saus asam manis. Lalu di aduk sampai bumbu agak menyusut
1. Selesaaaai~




Wah ternyata cara membuat ayam asam manis yang mantab sederhana ini mudah banget ya! Kita semua mampu menghidangkannya. Resep ayam asam manis Sesuai sekali buat kita yang baru belajar memasak ataupun bagi kalian yang telah ahli dalam memasak.

Tertarik untuk mencoba membuat resep ayam asam manis enak tidak rumit ini? Kalau anda tertarik, yuk kita segera siapkan alat-alat dan bahannya, lantas bikin deh Resep ayam asam manis yang mantab dan sederhana ini. Sungguh taidak sulit kan. 

Maka, daripada anda berfikir lama-lama, hayo langsung aja hidangkan resep ayam asam manis ini. Pasti kalian tak akan nyesel sudah membuat resep ayam asam manis lezat sederhana ini! Selamat mencoba dengan resep ayam asam manis nikmat tidak rumit ini di tempat tinggal masing-masing,ya!.

