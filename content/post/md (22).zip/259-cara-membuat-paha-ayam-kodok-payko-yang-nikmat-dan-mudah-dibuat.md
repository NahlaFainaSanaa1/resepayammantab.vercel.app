---
description: "Cara membuat Paha Ayam Kodok (Payko) yang nikmat dan Mudah Dibuat"
title: "Cara membuat Paha Ayam Kodok (Payko) yang nikmat dan Mudah Dibuat"
slug: 259-cara-membuat-paha-ayam-kodok-payko-yang-nikmat-dan-mudah-dibuat
date: 2021-02-09T23:03:40.925Z
image: https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg
author: Melvin Bennett
ratingvalue: 4.5
reviewcount: 9
recipeingredient:
- "6 pcs paha ayam bag bawah"
- "200 gr daging giling"
- "6 btr telur puyuh rebus kupas"
- "1/4 bawang bombay cincang"
- "2 siung bawang putih"
- "3 sdm tepung rotipanir"
- "1 butir telur ayam"
- "50 ml susu cair"
- "1 sdt garam"
- "1 sdm gula pasir"
- "1/2-1 sdt lada bubuk"
- "1/4 sdt pala bubuk"
- " Saus "
- "1/2 bawang bombay cincang"
- "200 ml air kaldu ayam"
- "1 sdm saus inggris"
- "2 sdm kecap manis"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- "2 sdm mentega utk menumis"
- "1 1/2 sdm maizena cairkan dengan sedikit air"
- " Bumbu Oles Panggang "
- "1 sdm margarin"
- "1 sdm kecap"
- "1 sdt madu"
- " Pelengkap "
- " Kentang gorengwedgesfrench fries"
- " Mixed vegetable yang ditumis dengan sedikit mentega  bawput"
recipeinstructions:
- "Kuliti paha, ambil daging dan tulangnya, sisakan di ujung untuk pegangan. Cincang lembut daging ayam/bisa dihaluskan di FP. Sisihkan. Sementara rebus tulang ayam dengan 300 ml air dengam api kecil hingga kuah bening, saring dan sisihkan. (Nanti yg dipakai hanya 200ml)"
- "Tumis bawang bombay dgn mentega hingga harum. Sisihkan. Campur semua bahan : ayam, daging, bumbu dsb. Uleni hingga rata. Jangan lupa tes icip dengan sedikit memggoreng adonan. Jika rasa sudahbpas, masukkan ke dalam plastik segitiga untuk memudahkan pengisian ke dalam kulit paha. Isikan sebagian, masukkan 1 telur puyuh dan iso lagi dengan adonan hingga penuh sambil dipadatkan. Kukus selama 30 menit atau hingga matang. Di menit 10 tusuki permukaan kulitnya dengan tusuk gigi agar air keluar."
- "Panaskan pan..dan panggang paha sambil dioles bahan olesan yang sudah diaduk rata. Panggang hingga kecoklatan. Angkat. Utk saus : tumis bombay hingga harum, tuang air kaldu dan didihkan. Bumbui. Tes icip. Dan kentalkan dengan memasukkan larutan maizena. Angkat.Sajikan Payko dengan kentang goreng, tumisan mix vegetable.dan disiram saus."
- "Note untuk yang dibikin Rolade : siapkan selembar alumunium foil, taruh adonan daging, tata telur/telur puyuh rebus di atasnya. Tutup lagi dengan adinan daging. Gulung dan padatkan dengan alumunium foul. Tusuk2 dengan tusuk gigi permukaan rol. Kukus selama 30-45 menit. Angkat di bisa disimpan jika sudah dingin"
categories:
- Resep
tags:
- paha
- ayam
- kodok

katakunci: paha ayam kodok 
nutrition: 292 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dinner

---


![Paha Ayam Kodok (Payko)](https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg)

Jika anda seorang istri, menyediakan hidangan sedap bagi keluarga merupakan hal yang membahagiakan untuk kita sendiri. Kewajiban seorang ibu bukan hanya mengatur rumah saja, tapi anda pun wajib menyediakan kebutuhan gizi terpenuhi dan juga masakan yang dikonsumsi anak-anak harus lezat.

Di waktu  sekarang, kita sebenarnya mampu membeli masakan jadi meski tidak harus susah memasaknya lebih dulu. Namun ada juga orang yang memang mau memberikan hidangan yang terbaik untuk keluarganya. Sebab, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai kesukaan keluarga. 



Apakah kamu salah satu penyuka paha ayam kodok (payko)?. Asal kamu tahu, paha ayam kodok (payko) merupakan makanan khas di Indonesia yang sekarang disenangi oleh orang-orang di berbagai tempat di Indonesia. Kita bisa membuat paha ayam kodok (payko) hasil sendiri di rumahmu dan boleh dijadikan santapan favoritmu di akhir pekanmu.

Kalian tidak usah bingung jika kamu ingin menyantap paha ayam kodok (payko), sebab paha ayam kodok (payko) tidak sukar untuk didapatkan dan juga anda pun boleh mengolahnya sendiri di rumah. paha ayam kodok (payko) bisa dimasak memalui berbagai cara. Kini pun telah banyak sekali cara modern yang menjadikan paha ayam kodok (payko) semakin mantap.

Resep paha ayam kodok (payko) juga sangat mudah dibikin, lho. Kalian jangan ribet-ribet untuk membeli paha ayam kodok (payko), lantaran Kita dapat membuatnya di rumahmu. Untuk Kita yang hendak menyajikannya, berikut ini resep untuk membuat paha ayam kodok (payko) yang mantab yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Paha Ayam Kodok (Payko):

1. Siapkan 6 pcs paha ayam bag. bawah
1. Sediakan 200 gr daging giling
1. Gunakan 6 btr telur puyuh rebus, kupas
1. Sediakan 1/4 bawang bombay cincang
1. Siapkan 2 siung bawang putih
1. Sediakan 3 sdm tepung roti/panir
1. Gunakan 1 butir telur ayam
1. Siapkan 50 ml susu cair
1. Sediakan 1 sdt garam
1. Siapkan 1 sdm gula pasir
1. Sediakan 1/2-1 sdt lada bubuk
1. Siapkan 1/4 sdt pala bubuk
1. Sediakan  Saus :
1. Sediakan 1/2 bawang bombay cincang
1. Sediakan 200 ml air kaldu ayam
1. Siapkan 1 sdm saus inggris
1. Gunakan 2 sdm kecap manis
1. Ambil 1/2 sdt lada bubuk
1. Siapkan 1/2 sdt garam
1. Ambil 2 sdm mentega utk menumis
1. Ambil 1 1/2 sdm maizena cairkan dengan sedikit air
1. Siapkan  Bumbu Oles Panggang :
1. Ambil 1 sdm margarin
1. Ambil 1 sdm kecap
1. Ambil 1 sdt madu
1. Sediakan  Pelengkap :
1. Gunakan  Kentang goreng/wedges/french fries
1. Sediakan  Mixed vegetable yang ditumis dengan sedikit mentega + bawput




<!--inarticleads2-->

##### Langkah-langkah membuat Paha Ayam Kodok (Payko):

1. Kuliti paha, ambil daging dan tulangnya, sisakan di ujung untuk pegangan. Cincang lembut daging ayam/bisa dihaluskan di FP. Sisihkan. Sementara rebus tulang ayam dengan 300 ml air dengam api kecil hingga kuah bening, saring dan sisihkan. (Nanti yg dipakai hanya 200ml)
1. Tumis bawang bombay dgn mentega hingga harum. Sisihkan. Campur semua bahan : ayam, daging, bumbu dsb. Uleni hingga rata. Jangan lupa tes icip dengan sedikit memggoreng adonan. Jika rasa sudahbpas, masukkan ke dalam plastik segitiga untuk memudahkan pengisian ke dalam kulit paha. Isikan sebagian, masukkan 1 telur puyuh dan iso lagi dengan adonan hingga penuh sambil dipadatkan. Kukus selama 30 menit atau hingga matang. Di menit 10 tusuki permukaan kulitnya dengan tusuk gigi agar air keluar.
1. Panaskan pan..dan panggang paha sambil dioles bahan olesan yang sudah diaduk rata. Panggang hingga kecoklatan. Angkat. Utk saus : tumis bombay hingga harum, tuang air kaldu dan didihkan. Bumbui. Tes icip. Dan kentalkan dengan memasukkan larutan maizena. Angkat.Sajikan Payko dengan kentang goreng, tumisan mix vegetable.dan disiram saus.
1. Note untuk yang dibikin Rolade : siapkan selembar alumunium foil, taruh adonan daging, tata telur/telur puyuh rebus di atasnya. Tutup lagi dengan adinan daging. Gulung dan padatkan dengan alumunium foul. Tusuk2 dengan tusuk gigi permukaan rol. Kukus selama 30-45 menit. Angkat di bisa disimpan jika sudah dingin




Ternyata cara membuat paha ayam kodok (payko) yang mantab tidak rumit ini mudah banget ya! Kamu semua bisa mencobanya. Resep paha ayam kodok (payko) Sangat cocok sekali untuk kamu yang baru akan belajar memasak ataupun bagi kamu yang sudah lihai memasak.

Tertarik untuk mencoba buat resep paha ayam kodok (payko) enak tidak rumit ini? Kalau kamu ingin, ayo kalian segera buruan siapkan alat-alat dan bahan-bahannya, lalu bikin deh Resep paha ayam kodok (payko) yang lezat dan tidak rumit ini. Betul-betul mudah kan. 

Jadi, ketimbang kita berlama-lama, maka kita langsung hidangkan resep paha ayam kodok (payko) ini. Dijamin anda tak akan menyesal membuat resep paha ayam kodok (payko) enak tidak ribet ini! Selamat mencoba dengan resep paha ayam kodok (payko) nikmat tidak ribet ini di rumah kalian masing-masing,oke!.

