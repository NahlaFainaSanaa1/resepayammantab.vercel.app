---
description: "Cara buat Ayam Asam Manis Kering yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam Asam Manis Kering yang lezat dan Mudah Dibuat"
slug: 337-cara-buat-ayam-asam-manis-kering-yang-lezat-dan-mudah-dibuat
date: 2021-05-14T05:11:14.642Z
image: https://img-global.cpcdn.com/recipes/cd9a4d8e461925b5/680x482cq70/ayam-asam-manis-kering-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cd9a4d8e461925b5/680x482cq70/ayam-asam-manis-kering-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cd9a4d8e461925b5/680x482cq70/ayam-asam-manis-kering-foto-resep-utama.jpg
author: Hulda Richards
ratingvalue: 3.1
reviewcount: 4
recipeingredient:
- "1/4 ekor ayam potong2 agak kecil"
- "1/2 buah jeruk nipis"
- "Secukupnya garam dan merica bubuk"
- "4 sdm tapioka  14 sdt baking soda aduk rata"
- " Saus asam manis aduk rata"
- "5 sdm saus tomat Surabaya saya wajib pake ini"
- "2 sdm munjung gula pasir"
- "1/4 sdm kecap radja rasa"
- "1 sdt minyak wijen"
- "1/4 sdt merica"
recipeinstructions:
- "Cuci bersih ayam yang sudah dipotong2, kucuri jeruk nipis, tambahkan garam dan merica aduk rata"
- "Baluri ayam dengan campuran tapioka dan baking soda, goreng hingga matang, tiriskan"
- "Panaskan wajan, masak saus hingga gula larut dan mengental"
- "Masukkan ayam yang sudah digoreng, aduk rata (gunakan api kecil saja)"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 216 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Asam Manis Kering](https://img-global.cpcdn.com/recipes/cd9a4d8e461925b5/680x482cq70/ayam-asam-manis-kering-foto-resep-utama.jpg)

Apabila kita seorang ibu, menyuguhkan santapan sedap untuk orang tercinta adalah hal yang membahagiakan untuk kamu sendiri. Tugas seorang  wanita bukan saja mengurus rumah saja, tapi anda juga wajib memastikan keperluan nutrisi tercukupi dan juga hidangan yang dikonsumsi anak-anak harus menggugah selera.

Di masa  sekarang, kita memang dapat membeli santapan siap saji meski tidak harus capek membuatnya terlebih dahulu. Tapi banyak juga mereka yang selalu ingin memberikan hidangan yang terbaik untuk orang tercintanya. Lantaran, menyajikan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera orang tercinta. 



Apakah anda seorang penggemar ayam asam manis kering?. Asal kamu tahu, ayam asam manis kering adalah hidangan khas di Nusantara yang saat ini digemari oleh kebanyakan orang dari berbagai tempat di Indonesia. Kalian bisa menyajikan ayam asam manis kering kreasi sendiri di rumahmu dan boleh dijadikan camilan favorit di akhir pekanmu.

Kalian tak perlu bingung jika kamu ingin menyantap ayam asam manis kering, lantaran ayam asam manis kering tidak sukar untuk ditemukan dan juga kamu pun boleh membuatnya sendiri di rumah. ayam asam manis kering bisa dibuat dengan bermacam cara. Kini ada banyak resep kekinian yang menjadikan ayam asam manis kering semakin lezat.

Resep ayam asam manis kering juga sangat gampang dihidangkan, lho. Kita tidak usah repot-repot untuk membeli ayam asam manis kering, sebab Kalian bisa menghidangkan sendiri di rumah. Untuk Kita yang hendak mencobanya, inilah resep untuk menyajikan ayam asam manis kering yang mantab yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Asam Manis Kering:

1. Gunakan 1/4 ekor ayam, potong2 agak kecil
1. Siapkan 1/2 buah jeruk nipis
1. Gunakan Secukupnya garam dan merica bubuk
1. Gunakan 4 sdm tapioka + 1/4 sdt baking soda (aduk rata)
1. Siapkan  Saus asam manis (aduk rata):
1. Siapkan 5 sdm saus tomat Surabaya (saya wajib pake ini)
1. Ambil 2 sdm munjung gula pasir
1. Gunakan 1/4 sdm kecap radja rasa
1. Siapkan 1 sdt minyak wijen
1. Siapkan 1/4 sdt merica




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Asam Manis Kering:

1. Cuci bersih ayam yang sudah dipotong2, kucuri jeruk nipis, tambahkan garam dan merica aduk rata
<img src="https://img-global.cpcdn.com/steps/488422ce5542acd9/160x128cq70/ayam-asam-manis-kering-langkah-memasak-1-foto.jpg" alt="Ayam Asam Manis Kering">1. Baluri ayam dengan campuran tapioka dan baking soda, goreng hingga matang, tiriskan
1. Panaskan wajan, masak saus hingga gula larut dan mengental
1. Masukkan ayam yang sudah digoreng, aduk rata (gunakan api kecil saja)




Ternyata cara membuat ayam asam manis kering yang enak simple ini mudah sekali ya! Kamu semua dapat mencobanya. Cara buat ayam asam manis kering Sangat sesuai banget untuk kita yang baru akan belajar memasak ataupun juga bagi anda yang sudah ahli dalam memasak.

Apakah kamu ingin mencoba bikin resep ayam asam manis kering lezat tidak ribet ini? Kalau kamu tertarik, ayo kalian segera menyiapkan alat-alat dan bahan-bahannya, kemudian bikin deh Resep ayam asam manis kering yang nikmat dan simple ini. Sangat mudah kan. 

Jadi, daripada kalian berlama-lama, maka kita langsung saja bikin resep ayam asam manis kering ini. Pasti kamu gak akan nyesel sudah buat resep ayam asam manis kering mantab tidak ribet ini! Selamat berkreasi dengan resep ayam asam manis kering nikmat tidak ribet ini di rumah kalian sendiri,ya!.

