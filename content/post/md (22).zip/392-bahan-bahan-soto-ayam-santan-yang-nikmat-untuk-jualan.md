---
description: "Bahan-bahan Soto Ayam Santan yang nikmat Untuk Jualan"
title: "Bahan-bahan Soto Ayam Santan yang nikmat Untuk Jualan"
slug: 392-bahan-bahan-soto-ayam-santan-yang-nikmat-untuk-jualan
date: 2021-05-03T22:27:40.916Z
image: https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Gordon Burgess
ratingvalue: 3.2
reviewcount: 7
recipeingredient:
- "1/2 ekor ayam bagian dada cuci bersih sy pakai bagian paha"
- "250 ml santan dr 12 buah kelapa"
- "1 liter air"
- "4 lembar daun jeruk sobek2"
- "2 lembar daun salam"
- "2 batang sereh geprek"
- "1 ruas jari lengkuas geprek"
- "Secukupnya gulagaram"
- "Secukupnya kaldu ayam bubuk"
- " Bumbu halus "
- "6 siung bawang merah"
- "3 Siung bawang putih"
- "3 butir kemiri"
- "1/2 sdt ketumbar"
- "Secukupnya lada"
- " Pelengkap "
- " Sambal"
- " Daun bawang"
- " Jeruk nipis"
- " Bawang goreng"
- " Kentang goreng"
- " Tomat"
recipeinstructions:
- "Didihkan 1 liter air di panci lalu masukan ayam,rebus ayam dgn api kecil"
- "Tumis bumbu halus,daun jeruk,daun salam,lengkuas,sereh sampai harum,masukan tumisan bumbu ke dlm rebusan ayam,masukan royco,garam dan gula,masak hingga ayam empuk dan bumbu meresap. Masukan santan aduk2 agar tdk pecah,klu kira2 krg kental kuahnya bs di tambah santan instan,aduk hingga mendidih"
- "Setelah mendidih lalu angkat ayam dan tiriskan"
- "Tes rasa lalu matikan"
- "Pansakan minyak goreng lalu goreng ayam,tdk ush terlalu kering,lalu siapkan mangkuk saji,suir2 ayam"
- "Siapkan mangkuk dan tata di magkuk saji dgn pelengkapnya .. Yuumyyy"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 246 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan hidangan menggugah selera pada famili adalah hal yang menyenangkan untuk kita sendiri. Tanggung jawab seorang ibu bukan sekadar menjaga rumah saja, tapi anda juga wajib memastikan keperluan gizi terpenuhi dan masakan yang disantap orang tercinta wajib sedap.

Di zaman  saat ini, kalian memang mampu membeli hidangan praktis walaupun tidak harus repot membuatnya terlebih dahulu. Tetapi banyak juga mereka yang selalu ingin memberikan hidangan yang terlezat untuk keluarganya. Sebab, memasak yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai makanan kesukaan orang tercinta. 



Mungkinkah anda adalah seorang penyuka soto ayam santan?. Tahukah kamu, soto ayam santan adalah sajian khas di Nusantara yang saat ini disukai oleh setiap orang dari hampir setiap tempat di Indonesia. Kamu dapat memasak soto ayam santan buatan sendiri di rumahmu dan pasti jadi santapan favoritmu di hari liburmu.

Kita tak perlu bingung untuk menyantap soto ayam santan, lantaran soto ayam santan mudah untuk ditemukan dan kalian pun dapat memasaknya sendiri di rumah. soto ayam santan boleh dibuat memalui beragam cara. Kini pun sudah banyak sekali resep modern yang menjadikan soto ayam santan lebih enak.

Resep soto ayam santan juga mudah sekali dibikin, lho. Kamu tidak perlu capek-capek untuk memesan soto ayam santan, karena Kita dapat menghidangkan di rumah sendiri. Bagi Kalian yang ingin menghidangkannya, berikut ini resep membuat soto ayam santan yang enak yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Santan:

1. Ambil 1/2 ekor ayam bagian dada cuci bersih, sy pakai bagian paha
1. Gunakan 250 ml santan dr 1/2 buah kelapa
1. Sediakan 1 liter air
1. Ambil 4 lembar daun jeruk sobek2
1. Ambil 2 lembar daun salam
1. Gunakan 2 batang sereh geprek
1. Gunakan 1 ruas jari lengkuas geprek
1. Siapkan Secukupnya gula,garam
1. Sediakan Secukupnya kaldu ayam bubuk
1. Sediakan  Bumbu halus :
1. Ambil 6 siung bawang merah
1. Gunakan 3 Siung bawang putih
1. Ambil 3 butir kemiri
1. Ambil 1/2 sdt ketumbar
1. Sediakan Secukupnya lada
1. Ambil  Pelengkap :
1. Sediakan  Sambal
1. Sediakan  Daun bawang
1. Sediakan  Jeruk nipis
1. Sediakan  Bawang goreng
1. Ambil  Kentang goreng
1. Sediakan  Tomat




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Santan:

1. Didihkan 1 liter air di panci lalu masukan ayam,rebus ayam dgn api kecil
1. Tumis bumbu halus,daun jeruk,daun salam,lengkuas,sereh sampai harum,masukan tumisan bumbu ke dlm rebusan ayam,masukan royco,garam dan gula,masak hingga ayam empuk dan bumbu meresap. Masukan santan aduk2 agar tdk pecah,klu kira2 krg kental kuahnya bs di tambah santan instan,aduk hingga mendidih
1. Setelah mendidih lalu angkat ayam dan tiriskan
1. Tes rasa lalu matikan
1. Pansakan minyak goreng lalu goreng ayam,tdk ush terlalu kering,lalu siapkan mangkuk saji,suir2 ayam
1. Siapkan mangkuk dan tata di magkuk saji dgn pelengkapnya .. Yuumyyy




Ternyata cara membuat soto ayam santan yang nikamt tidak ribet ini enteng sekali ya! Anda Semua mampu memasaknya. Cara Membuat soto ayam santan Cocok banget untuk kita yang baru akan belajar memasak maupun juga untuk anda yang sudah jago dalam memasak.

Tertarik untuk mencoba membikin resep soto ayam santan mantab tidak rumit ini? Kalau kalian tertarik, mending kamu segera siapin alat-alat dan bahannya, setelah itu bikin deh Resep soto ayam santan yang lezat dan sederhana ini. Benar-benar taidak sulit kan. 

Maka, ketimbang kamu berlama-lama, yuk kita langsung buat resep soto ayam santan ini. Pasti kalian gak akan menyesal sudah bikin resep soto ayam santan mantab tidak rumit ini! Selamat mencoba dengan resep soto ayam santan lezat simple ini di tempat tinggal kalian sendiri,ya!.

