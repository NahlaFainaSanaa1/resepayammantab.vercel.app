---
description: "Cara buat Ayam Lodho khas Tulungagung yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam Lodho khas Tulungagung yang nikmat dan Mudah Dibuat"
slug: 220-cara-buat-ayam-lodho-khas-tulungagung-yang-nikmat-dan-mudah-dibuat
date: 2021-04-15T21:27:18.410Z
image: https://img-global.cpcdn.com/recipes/9828fef0f34576fb/680x482cq70/ayam-lodho-khas-tulungagung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9828fef0f34576fb/680x482cq70/ayam-lodho-khas-tulungagung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9828fef0f34576fb/680x482cq70/ayam-lodho-khas-tulungagung-foto-resep-utama.jpg
author: Lee Morris
ratingvalue: 4.1
reviewcount: 5
recipeingredient:
- "1 ekor bakaran ayam potongayam kampung skitar berat 15kg"
- "7 lembar daun jeruk"
- "10 lembar daun salam"
- "4 cm lengkuas di geprek"
- "400 mL santan kanilkental dri 6plastik kelapa parut"
- "800 mL santan cair sisan perasan santan kanil"
- " Bumbu Halus"
- "25 bawang merah pakai bnyak biar enak"
- "10 bawah putih"
- "1 sdt merica"
- "1 sdm ketumbar"
- "2 sdm garam bsa lebih"
- "1 sdm gula bsa lebih"
- "2 ruas jahe skitar 23 cm"
- "4 ruas kunyit skitar 45cm"
- "15 cabe rawit bsa lebih"
recipeinstructions:
- "Potong ayam bakaran menjadi beberapa bagian lalu cuci bersih dan sisihkan. Jika tidak ada ayam bakaran maka bsa bakar sndiri sbelum dimasak. Karena yg bkin beda adalah ayam yg sudah dibakar asap ini"
- "Siapkan bumbu halus (selain garam, gula, merica, ketumbar) lalu goreng hingga matang. Kemudian haluskan dgn uleg/bsa blender bersama dgn garam, gula, merica dan ketumbar. Sisihkan"
- "Peras parutan kelapa dgn membedakan santan kanil dan santan encer, aku pakai 5 plastik kelapa jdi gak perlu marut sndiri atau setara 1 buah kelapa klo pngen marut sndiri."
- "Masukkan ayam dalam kompor. Lalu masukkan santan cair, daun jeruk dan salam. Masak hingga mendidih dlu. Kmudian msukkan bumbu halus dan aduk2. Masak hingga mendidih lgi smbil sesekali diaduk, sampai ayam mulai empuk dan bumbu meresap (skitar 30menitan)."
- "Lalu masukkan santan kanil sedikit, aduk2 dan tunggu mendidih, masukkan santan kanil sedikit lgi, aduk lagi dan terus ulangi smpai smua santan kanil masuk smua. Tujuannya supaya bumbu meresap sempurna."
- "Tutup wajan dan masak sambil diaduk2 sesekali hingga santan kanil dan bumbu menyatu, jangan lupa koreksi rasa jika kurang bsa tambahkan gula dan garam ya."
- "Jika bumbu sudah meresap ke ayam, matikan dan siap disajikaann dgn nasi hangat atau nasi guriihhh😍❤ wuenaakk tenannn"
- "Ket: Bisa jga pakai santan kara tpi kalo pakai santan kara brarti ayam bakarannya direbus pakai air, daun salam dan daun jeruk, lalu masukkan bumbu lalu, aduk rata, baru 4 plastik santan karanya dimasukkan."
categories:
- Resep
tags:
- ayam
- lodho
- khas

katakunci: ayam lodho khas 
nutrition: 268 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Lodho khas Tulungagung](https://img-global.cpcdn.com/recipes/9828fef0f34576fb/680x482cq70/ayam-lodho-khas-tulungagung-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyajikan panganan enak buat keluarga tercinta merupakan hal yang mengasyikan bagi kita sendiri. Peran seorang  wanita bukan sekadar mengurus rumah saja, namun kamu pun harus memastikan kebutuhan nutrisi tercukupi dan hidangan yang dimakan keluarga tercinta wajib mantab.

Di era  saat ini, kamu sebenarnya mampu membeli olahan praktis tanpa harus repot mengolahnya terlebih dahulu. Tetapi ada juga lho mereka yang selalu mau memberikan hidangan yang terlezat untuk orang yang dicintainya. Pasalnya, memasak sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penikmat ayam lodho khas tulungagung?. Tahukah kamu, ayam lodho khas tulungagung adalah hidangan khas di Indonesia yang kini disenangi oleh banyak orang dari berbagai tempat di Indonesia. Kita bisa memasak ayam lodho khas tulungagung hasil sendiri di rumah dan dapat dijadikan makanan favoritmu di akhir pekanmu.

Anda tak perlu bingung jika kamu ingin memakan ayam lodho khas tulungagung, lantaran ayam lodho khas tulungagung gampang untuk didapatkan dan juga kalian pun bisa memasaknya sendiri di tempatmu. ayam lodho khas tulungagung dapat dimasak lewat berbagai cara. Sekarang sudah banyak cara kekinian yang menjadikan ayam lodho khas tulungagung semakin enak.

Resep ayam lodho khas tulungagung juga sangat gampang untuk dibikin, lho. Kita tidak usah ribet-ribet untuk membeli ayam lodho khas tulungagung, lantaran Kita dapat menyajikan di rumahmu. Bagi Kamu yang hendak mencobanya, di bawah ini adalah cara untuk membuat ayam lodho khas tulungagung yang lezat yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Lodho khas Tulungagung:

1. Ambil 1 ekor bakaran ayam potong/ayam kampung (skitar berat 1,5kg)
1. Sediakan 7 lembar daun jeruk
1. Siapkan 10 lembar daun salam
1. Siapkan 4 cm lengkuas di geprek
1. Sediakan 400 mL santan kanil/kental (dri 6plastik kelapa parut)
1. Ambil 800 mL santan cair (sisan perasan santan kanil)
1. Gunakan  Bumbu Halus:
1. Sediakan 25 bawang merah (pakai bnyak biar enak)
1. Sediakan 10 bawah putih
1. Gunakan 1 sdt merica
1. Sediakan 1 sdm ketumbar
1. Gunakan 2 sdm garam bsa lebih
1. Sediakan 1 sdm gula bsa lebih
1. Sediakan 2 ruas jahe (skitar 2-3 cm)
1. Ambil 4 ruas kunyit (skitar 4-5cm)
1. Ambil 15 cabe rawit bsa lebih




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Lodho khas Tulungagung:

1. Potong ayam bakaran menjadi beberapa bagian lalu cuci bersih dan sisihkan. Jika tidak ada ayam bakaran maka bsa bakar sndiri sbelum dimasak. Karena yg bkin beda adalah ayam yg sudah dibakar asap ini
1. Siapkan bumbu halus (selain garam, gula, merica, ketumbar) lalu goreng hingga matang. Kemudian haluskan dgn uleg/bsa blender bersama dgn garam, gula, merica dan ketumbar. Sisihkan
1. Peras parutan kelapa dgn membedakan santan kanil dan santan encer, aku pakai 5 plastik kelapa jdi gak perlu marut sndiri atau setara 1 buah kelapa klo pngen marut sndiri.
1. Masukkan ayam dalam kompor. Lalu masukkan santan cair, daun jeruk dan salam. Masak hingga mendidih dlu. Kmudian msukkan bumbu halus dan aduk2. Masak hingga mendidih lgi smbil sesekali diaduk, sampai ayam mulai empuk dan bumbu meresap (skitar 30menitan).
1. Lalu masukkan santan kanil sedikit, aduk2 dan tunggu mendidih, masukkan santan kanil sedikit lgi, aduk lagi dan terus ulangi smpai smua santan kanil masuk smua. Tujuannya supaya bumbu meresap sempurna.
1. Tutup wajan dan masak sambil diaduk2 sesekali hingga santan kanil dan bumbu menyatu, jangan lupa koreksi rasa jika kurang bsa tambahkan gula dan garam ya.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Lodho khas Tulungagung">1. Jika bumbu sudah meresap ke ayam, matikan dan siap disajikaann dgn nasi hangat atau nasi guriihhh😍❤ wuenaakk tenannn
1. Ket: Bisa jga pakai santan kara tpi kalo pakai santan kara brarti ayam bakarannya direbus pakai air, daun salam dan daun jeruk, lalu masukkan bumbu lalu, aduk rata, baru 4 plastik santan karanya dimasukkan.




Wah ternyata cara buat ayam lodho khas tulungagung yang mantab sederhana ini mudah banget ya! Kita semua dapat mencobanya. Cara Membuat ayam lodho khas tulungagung Sangat cocok sekali buat kita yang baru belajar memasak maupun juga untuk kalian yang sudah hebat memasak.

Apakah kamu mau mencoba membikin resep ayam lodho khas tulungagung nikmat simple ini? Kalau kalian mau, ayo kamu segera siapkan peralatan dan bahannya, kemudian bikin deh Resep ayam lodho khas tulungagung yang mantab dan simple ini. Sungguh taidak sulit kan. 

Jadi, daripada anda diam saja, maka kita langsung saja hidangkan resep ayam lodho khas tulungagung ini. Dijamin anda tiidak akan menyesal sudah buat resep ayam lodho khas tulungagung mantab tidak ribet ini! Selamat berkreasi dengan resep ayam lodho khas tulungagung mantab sederhana ini di rumah kalian sendiri,ya!.

