---
description: "Cara buat Ayam Asam Manis yang lezat Untuk Jualan"
title: "Cara buat Ayam Asam Manis yang lezat Untuk Jualan"
slug: 341-cara-buat-ayam-asam-manis-yang-lezat-untuk-jualan
date: 2021-04-19T08:27:06.779Z
image: https://img-global.cpcdn.com/recipes/24e3aedb6a6d4701/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24e3aedb6a6d4701/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24e3aedb6a6d4701/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Herman Rodriquez
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- " Ayam Goreng"
- "400-600 gr dada ayam"
- "Secukupnya garam"
- "Secukupnya lada"
- "60-100 gr maizena cornstarch"
- "2 buah telur"
- "Secukupnya minyak untuk menggoreng"
- " Saus Asam Manis"
- "1 sdm minyak"
- "1/2 sdm bawang putih cincang"
- "1 buah paprika potong dadu"
- "180 ml cuka apel aku pakai 23sdm lemon karena ga punya cuka apel"
- "1 sdm soy sauce"
- "55 gr saus aku pakai tomato paste karena ga punya saos di rumah"
- "100 gr gula"
- "Secukupnya chili flakes optional ku tambah biar ada rasa pedas sedikit"
- "Secukupnya nanas potong dadu optional kalau mau ada rasa manis asam yang segar bisa ditambah nanas"
recipeinstructions:
- "Panaskan minyak goreng. Pastikan minyak untuk menggoreng bisa menutupi seluruh ayam ya"
- "Potong2 ayam (aku pakai paha atas disini yang masih ada kulitnya) bumbui dengan garam dan lada lalu masukkan maizena. Aduk yang rata"
- "Kocok telur lalu celupkan ayam yang sudah dibumbui ke adukan telur. Masukkan ayam ke minyak untuk digoreng"
- "Sisihkan ayam yang sudah digoreng ke wadah terpisah"
- "Masukkan semua bahan untuk membuat saus. Aduk hingga saus agak mengental. Ketika sudah mengental masukkan ayam yang sudah digoreng dan aduk hingga rata"
- "Sajikan masakan dan selamat menikmati! :D"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/24e3aedb6a6d4701/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan panganan enak buat keluarga tercinta adalah suatu hal yang menggembirakan untuk kita sendiri. Tanggung jawab seorang istri bukan cuman menjaga rumah saja, tetapi kamu juga wajib memastikan kebutuhan gizi terpenuhi dan juga hidangan yang dikonsumsi orang tercinta wajib nikmat.

Di waktu  saat ini, kalian memang bisa mengorder olahan jadi walaupun tidak harus susah membuatnya dulu. Tetapi banyak juga mereka yang selalu ingin memberikan hidangan yang terlezat untuk orang yang dicintainya. Karena, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penikmat ayam asam manis?. Asal kamu tahu, ayam asam manis adalah sajian khas di Nusantara yang sekarang disukai oleh kebanyakan orang di berbagai tempat di Nusantara. Kita dapat membuat ayam asam manis buatan sendiri di rumahmu dan boleh jadi hidangan kesenanganmu di akhir pekan.

Kita tidak usah bingung jika kamu ingin menyantap ayam asam manis, sebab ayam asam manis gampang untuk dicari dan juga anda pun boleh mengolahnya sendiri di rumah. ayam asam manis bisa dibuat dengan beragam cara. Kini pun ada banyak sekali cara kekinian yang membuat ayam asam manis lebih lezat.

Resep ayam asam manis juga mudah untuk dibuat, lho. Kamu tidak usah repot-repot untuk membeli ayam asam manis, lantaran Kamu dapat menyiapkan ditempatmu. Untuk Kalian yang mau membuatnya, berikut resep membuat ayam asam manis yang nikamat yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Asam Manis:

1. Gunakan  Ayam Goreng
1. Sediakan 400-600 gr dada ayam
1. Gunakan Secukupnya garam
1. Ambil Secukupnya lada
1. Siapkan 60-100 gr maizena (cornstarch)
1. Ambil 2 buah telur
1. Sediakan Secukupnya minyak untuk menggoreng
1. Gunakan  Saus Asam Manis
1. Ambil 1 sdm minyak
1. Sediakan 1/2 sdm bawang putih cincang
1. Gunakan 1 buah paprika potong dadu
1. Ambil 180 ml cuka apel (aku pakai 2-3sdm lemon karena ga punya cuka apel)
1. Gunakan 1 sdm soy sauce
1. Ambil 55 gr saus (aku pakai tomato paste karena ga punya saos di rumah)
1. Siapkan 100 gr gula
1. Siapkan Secukupnya chili flakes (optional; ku tambah biar ada rasa pedas sedikit)
1. Ambil Secukupnya nanas potong dadu (optional; kalau mau ada rasa manis asam yang segar bisa ditambah nanas)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Asam Manis:

1. Panaskan minyak goreng. Pastikan minyak untuk menggoreng bisa menutupi seluruh ayam ya
1. Potong2 ayam (aku pakai paha atas disini yang masih ada kulitnya) bumbui dengan garam dan lada lalu masukkan maizena. Aduk yang rata
1. Kocok telur lalu celupkan ayam yang sudah dibumbui ke adukan telur. Masukkan ayam ke minyak untuk digoreng
1. Sisihkan ayam yang sudah digoreng ke wadah terpisah
1. Masukkan semua bahan untuk membuat saus. Aduk hingga saus agak mengental. Ketika sudah mengental masukkan ayam yang sudah digoreng dan aduk hingga rata
1. Sajikan masakan dan selamat menikmati! :D




Ternyata resep ayam asam manis yang nikamt sederhana ini mudah sekali ya! Anda Semua mampu membuatnya. Resep ayam asam manis Sangat cocok sekali untuk kamu yang baru mau belajar memasak ataupun juga untuk kalian yang sudah hebat dalam memasak.

Apakah kamu mau mencoba membuat resep ayam asam manis lezat tidak ribet ini? Kalau anda mau, ayo kamu segera menyiapkan peralatan dan bahannya, maka bikin deh Resep ayam asam manis yang nikmat dan tidak ribet ini. Betul-betul taidak sulit kan. 

Maka dari itu, daripada kalian diam saja, hayo langsung aja buat resep ayam asam manis ini. Dijamin kamu gak akan menyesal sudah bikin resep ayam asam manis mantab simple ini! Selamat berkreasi dengan resep ayam asam manis mantab tidak rumit ini di rumah sendiri,oke!.

