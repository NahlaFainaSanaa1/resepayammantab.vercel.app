---
description: "Resep Ceker Mercon / Ceker Setan Sederhana Untuk Jualan"
title: "Resep Ceker Mercon / Ceker Setan Sederhana Untuk Jualan"
slug: 243-resep-ceker-mercon-ceker-setan-sederhana-untuk-jualan
date: 2021-01-20T09:09:48.871Z
image: https://img-global.cpcdn.com/recipes/04b8639c083549ed/680x482cq70/ceker-mercon-ceker-setan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/04b8639c083549ed/680x482cq70/ceker-mercon-ceker-setan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/04b8639c083549ed/680x482cq70/ceker-mercon-ceker-setan-foto-resep-utama.jpg
author: Delia Strickland
ratingvalue: 4.5
reviewcount: 4
recipeingredient:
- "1/2 kg ceker ayam"
- "1 batang sereh geprek"
- "1 ruas lengkuas geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk purut"
- "1 sdm kecap manis"
- "1 buah tomat potong 4 bagian"
- "1/2 batang bawang prei"
- "Secukupnya gula pasir"
- "Secukupnya garam"
- "Secukupnya kaldu jamur bubuk"
- "Secukupnya lada putih bubuk"
- " Bahan Bumbu Halus "
- "20 buah cabe rawit"
- "5 buah cabe merah besar"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "1 ruas jahe"
recipeinstructions:
- "Cuci bersih ceker ayam lalu rebus di air mendidih sebanyak 2x. Di rebusan kedua, airnya jangan dibuang (jadikan sebagai air kaldu di step terakhir nanti). Tiris dan sisihkan."
- "Tumis bumbu halus, lalu masukkan sereh, lengkuas, daun salam dan daun jeruk purut. Tunggu hingga harum."
- "Kemudian, masukkan ceker ayam dan tuang sisa air rebusan tadi secukupnya saja. Lalu, beri garam, gula pasir, lada putih bubuk, kaldu jamur bubuk, kecap manis, tomat dan bawang prei. Aduk rata, koreksi rasa dan tunggu hingga air kaldunya menyusut."
- "Masakan siap dihidangkan ❤️"
categories:
- Resep
tags:
- ceker
- mercon
- 

katakunci: ceker mercon  
nutrition: 261 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Ceker Mercon / Ceker Setan](https://img-global.cpcdn.com/recipes/04b8639c083549ed/680x482cq70/ceker-mercon-ceker-setan-foto-resep-utama.jpg)

Sebagai seorang istri, menyuguhkan olahan lezat untuk keluarga tercinta adalah hal yang menyenangkan bagi kita sendiri. Peran seorang ibu Tidak saja mengurus rumah saja, namun anda juga harus menyediakan kebutuhan nutrisi terpenuhi dan hidangan yang dikonsumsi anak-anak wajib menggugah selera.

Di zaman  saat ini, kamu memang dapat memesan santapan instan tanpa harus susah mengolahnya dulu. Namun ada juga lho mereka yang memang mau menghidangkan yang terlezat untuk orang yang dicintainya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan sesuai makanan kesukaan orang tercinta. 



Apakah anda adalah salah satu penggemar ceker mercon / ceker setan?. Tahukah kamu, ceker mercon / ceker setan adalah hidangan khas di Indonesia yang kini disenangi oleh kebanyakan orang di berbagai daerah di Indonesia. Kita dapat menghidangkan ceker mercon / ceker setan olahan sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di hari libur.

Kamu tak perlu bingung jika kamu ingin memakan ceker mercon / ceker setan, lantaran ceker mercon / ceker setan gampang untuk ditemukan dan juga anda pun bisa mengolahnya sendiri di rumah. ceker mercon / ceker setan dapat diolah lewat berbagai cara. Saat ini telah banyak sekali cara modern yang membuat ceker mercon / ceker setan lebih nikmat.

Resep ceker mercon / ceker setan pun mudah sekali dibuat, lho. Kita jangan repot-repot untuk membeli ceker mercon / ceker setan, lantaran Kalian mampu menyiapkan ditempatmu. Bagi Kamu yang ingin membuatnya, dibawah ini merupakan resep membuat ceker mercon / ceker setan yang nikamat yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ceker Mercon / Ceker Setan:

1. Sediakan 1/2 kg ceker ayam
1. Siapkan 1 batang sereh, geprek
1. Sediakan 1 ruas lengkuas, geprek
1. Sediakan 2 lembar daun salam
1. Ambil 2 lembar daun jeruk purut
1. Sediakan 1 sdm kecap manis
1. Sediakan 1 buah tomat, potong 4 bagian
1. Ambil 1/2 batang bawang prei
1. Siapkan Secukupnya gula pasir
1. Ambil Secukupnya garam
1. Gunakan Secukupnya kaldu jamur bubuk
1. Sediakan Secukupnya lada putih bubuk
1. Gunakan  Bahan Bumbu Halus :
1. Ambil 20 buah cabe rawit
1. Gunakan 5 buah cabe merah besar
1. Ambil 3 siung bawang putih
1. Siapkan 5 siung bawang merah
1. Siapkan 1 ruas jahe




<!--inarticleads2-->

##### Cara menyiapkan Ceker Mercon / Ceker Setan:

1. Cuci bersih ceker ayam lalu rebus di air mendidih sebanyak 2x. Di rebusan kedua, airnya jangan dibuang (jadikan sebagai air kaldu di step terakhir nanti). Tiris dan sisihkan.
1. Tumis bumbu halus, lalu masukkan sereh, lengkuas, daun salam dan daun jeruk purut. Tunggu hingga harum.
1. Kemudian, masukkan ceker ayam dan tuang sisa air rebusan tadi secukupnya saja. Lalu, beri garam, gula pasir, lada putih bubuk, kaldu jamur bubuk, kecap manis, tomat dan bawang prei. Aduk rata, koreksi rasa dan tunggu hingga air kaldunya menyusut.
1. Masakan siap dihidangkan ❤️




Ternyata resep ceker mercon / ceker setan yang mantab simple ini mudah sekali ya! Semua orang bisa mencobanya. Cara Membuat ceker mercon / ceker setan Sangat sesuai banget untuk kalian yang sedang belajar memasak atau juga bagi anda yang telah lihai memasak.

Apakah kamu ingin mencoba membuat resep ceker mercon / ceker setan lezat simple ini? Kalau kamu ingin, mending kamu segera menyiapkan alat dan bahan-bahannya, maka bikin deh Resep ceker mercon / ceker setan yang nikmat dan sederhana ini. Sungguh mudah kan. 

Jadi, ketimbang kalian berlama-lama, maka kita langsung saja sajikan resep ceker mercon / ceker setan ini. Dijamin anda tak akan nyesel sudah membuat resep ceker mercon / ceker setan nikmat tidak rumit ini! Selamat mencoba dengan resep ceker mercon / ceker setan mantab simple ini di rumah kalian masing-masing,ya!.

