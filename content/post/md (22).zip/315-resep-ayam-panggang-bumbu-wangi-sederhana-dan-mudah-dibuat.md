---
description: "Resep Ayam panggang bumbu wangi Sederhana dan Mudah Dibuat"
title: "Resep Ayam panggang bumbu wangi Sederhana dan Mudah Dibuat"
slug: 315-resep-ayam-panggang-bumbu-wangi-sederhana-dan-mudah-dibuat
date: 2021-02-06T03:34:36.094Z
image: https://img-global.cpcdn.com/recipes/f1b9b457ca48dd24/680x482cq70/ayam-panggang-bumbu-wangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f1b9b457ca48dd24/680x482cq70/ayam-panggang-bumbu-wangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f1b9b457ca48dd24/680x482cq70/ayam-panggang-bumbu-wangi-foto-resep-utama.jpg
author: Larry Townsend
ratingvalue: 4.2
reviewcount: 10
recipeingredient:
- "500 gr paha ayam tanpa tulang dengan kulit"
- "3 siung bawang putih"
- "2 batang seledri potongpotong"
- "2 batang rosemary"
- "2 batang thyme"
- "4 lembar daun oregano"
- "secukupnya Garam dan lada bubuk"
- "1 sdt minyak zaitun"
- " Daun bawang secukupnya irisiris"
recipeinstructions:
- "Ulek bawang putih dan seledri sampai setengah hancur, lalu masukkan rosemary, thyme, dan oregano, ulek sampai halus lalu campurkan minyak zaitun dan aduk sampai tercampur rata."
- "Panaskan oven."
- "Cuci ayam, tiriskan. Lalu lumuri bumbu ke ayam secara merata, dipastikan juga bumbu dilumuri ke lapisan dalam kulit."
- "Setelah dilumuri dengan rata, lumuri dengan garam dan lada bubuk secukupnya."
- "Taburkan irisan daun bawang ke atas ayam di atas loyang"
- "Masukkan ayam ke dalam oven, dan panggan selama kurang lebih 30 menit atau sampai matang. Angkat dan sajikan."
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 234 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam panggang bumbu wangi](https://img-global.cpcdn.com/recipes/f1b9b457ca48dd24/680x482cq70/ayam-panggang-bumbu-wangi-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyediakan panganan nikmat buat famili adalah suatu hal yang menggembirakan untuk kamu sendiri. Tugas seorang  wanita bukan cuma menjaga rumah saja, tetapi kamu pun harus memastikan kebutuhan gizi terpenuhi dan juga santapan yang dimakan orang tercinta harus mantab.

Di zaman  sekarang, anda sebenarnya mampu membeli masakan praktis meski tanpa harus repot mengolahnya lebih dulu. Tapi banyak juga orang yang memang mau menyajikan yang terlezat untuk orang tercintanya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan orang tercinta. 

Hal ini dimaksudkan agar bumbu bisa meresap pada ayam secara merata. Panggang daging ayam sambil sesekali diolesi kecap dan bumbu sisa ungkep. Pastikan ayam matang sesuai tingkat kematangan yang diinginkan.

Apakah anda seorang penikmat ayam panggang bumbu wangi?. Asal kamu tahu, ayam panggang bumbu wangi adalah makanan khas di Indonesia yang sekarang disukai oleh setiap orang di berbagai wilayah di Nusantara. Kamu dapat menghidangkan ayam panggang bumbu wangi hasil sendiri di rumah dan dapat dijadikan hidangan favoritmu di akhir pekanmu.

Kamu jangan bingung untuk memakan ayam panggang bumbu wangi, karena ayam panggang bumbu wangi gampang untuk ditemukan dan kalian pun boleh menghidangkannya sendiri di rumah. ayam panggang bumbu wangi boleh diolah lewat bermacam cara. Saat ini ada banyak sekali cara kekinian yang membuat ayam panggang bumbu wangi semakin lebih lezat.

Resep ayam panggang bumbu wangi pun gampang sekali dibikin, lho. Anda jangan ribet-ribet untuk memesan ayam panggang bumbu wangi, sebab Kita bisa menghidangkan di rumahmu. Bagi Anda yang ingin menghidangkannya, dibawah ini merupakan cara membuat ayam panggang bumbu wangi yang mantab yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam panggang bumbu wangi:

1. Sediakan 500 gr paha ayam tanpa tulang (dengan kulit)
1. Ambil 3 siung bawang putih
1. Ambil 2 batang seledri, potong-potong
1. Ambil 2 batang rosemary
1. Sediakan 2 batang thyme
1. Ambil 4 lembar daun oregano
1. Gunakan secukupnya Garam dan lada bubuk
1. Gunakan 1 sdt minyak zaitun
1. Siapkan  Daun bawang secukupnya, iris-iris


Aduk merata, masak hingga matang dan bumbu meresap. Bakar ayam sambil dibolak balik dan sesekali diolesi bumbu hingga terasa harum. Cara membuat ayam panggang: Cuci bersih bahan untuk bumbu ungkepnya lalu iris-iris. Siapkan air di wajan lalu masukkan ayamnya dan bumbu ungkep tadi. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam panggang bumbu wangi:

1. Ulek bawang putih dan seledri sampai setengah hancur, lalu masukkan rosemary, thyme, dan oregano, ulek sampai halus lalu campurkan minyak zaitun dan aduk sampai tercampur rata.
1. Panaskan oven.
1. Cuci ayam, tiriskan. Lalu lumuri bumbu ke ayam secara merata, dipastikan juga bumbu dilumuri ke lapisan dalam kulit.
1. Setelah dilumuri dengan rata, lumuri dengan garam dan lada bubuk secukupnya.
1. Taburkan irisan daun bawang ke atas ayam di atas loyang
1. Masukkan ayam ke dalam oven, dan panggan selama kurang lebih 30 menit atau sampai matang. Angkat dan sajikan.


Masak sampai ayam berwarna kuning dan air tinggal sedikit. Selagi menunggu ayam di ungkep,buat sambal tomat untuk marinasi. Membuat ayam panggang yang utuh sebenarnya susah-susah gampang. Tumis bumbu halus hingga wangi, tambahkan serai, daun salam, jahe, dan lengkuas. Resep ayam bumbu rujak - Ayam adalah salah satu menu favorit semua orang, dan sekarang sudah ada berbagai macam masakan variasi dari ayam. 

Ternyata cara membuat ayam panggang bumbu wangi yang mantab tidak ribet ini enteng banget ya! Semua orang mampu memasaknya. Resep ayam panggang bumbu wangi Sangat sesuai sekali untuk kita yang baru akan belajar memasak maupun juga untuk kalian yang sudah hebat dalam memasak.

Tertarik untuk mencoba buat resep ayam panggang bumbu wangi mantab sederhana ini? Kalau kamu tertarik, ayo kalian segera siapin alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam panggang bumbu wangi yang mantab dan simple ini. Benar-benar taidak sulit kan. 

Jadi, daripada anda berfikir lama-lama, yuk kita langsung saja sajikan resep ayam panggang bumbu wangi ini. Dijamin kalian tiidak akan nyesel sudah bikin resep ayam panggang bumbu wangi nikmat sederhana ini! Selamat berkreasi dengan resep ayam panggang bumbu wangi lezat tidak ribet ini di rumah kalian masing-masing,oke!.

