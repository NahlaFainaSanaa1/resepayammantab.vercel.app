---
description: "Resep Soto ayam yang lezat dan Mudah Dibuat"
title: "Resep Soto ayam yang lezat dan Mudah Dibuat"
slug: 171-resep-soto-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-04-08T06:52:58.509Z
image: https://img-global.cpcdn.com/recipes/9c3a233970259c59/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9c3a233970259c59/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9c3a233970259c59/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Hulda Cummings
ratingvalue: 4.2
reviewcount: 9
recipeingredient:
- "1/2 kg ayam saya pilih bagian dada yah moms"
- "250 gr Kolkobis"
- " Soon 2bungkus sya pakai kemasan kecil yah moms"
- "100 gr Kecambah"
- " Daun bawang dan seledri"
- "2 buah Tomat"
- "1 buah Tomat"
- " Bumbu"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas jari Kunyit"
- "2 lembar daun salam"
- "2 potong laos digeprek"
- "2 batang sereh digeprek"
- "3 lembar daun jeruk"
- "1 sdt garam sesuaikan dengan selera"
- "1/2 sdt Kaldu jamur"
- "1/2 sdt gula pasir"
- "1/2 sdt merica"
- "Sejumput jinten"
- "1 ruas jari kayu manis"
- "500 ml Air"
recipeinstructions:
- "Uleg bawang merah, bawang putih, merica, kunyit hingga halus. Kemudian tumis hingga harum san masukkan daun salam, daun jeruk, sereh, laos. Setelah daun salam layu masukan 500ml air"
- "Setelah air mendidih masukkan kayu manis, jinten, tambahkan garam, gula, dan kaldu jamur. Tambahkan sedikit daun bawang untuk menambah aroma yah moms.... Setelah mendidih masukkan ayam rebus hingga ayam empuk kemudian angkat ayam dan sisihkan."
- "Goreng ayam sebentar kurang lebih 4-5 menit, sisihkan dan suwir2 ketika sdh dingin"
- "Iris halus kol/kobis, daun seledry, daun bawang, tomat, kemudian rebus sebentar kecambah, wortel, dan juga soon. Kemudian sisihkan"
- "Siapkan mangkok saji, masukkan isian sesuai selera kemudian siram dengan kuah soto, jangan lupa beri taburan bawang merah goreng yah moms... (bisa beli nawang merah goreng siap pakai moms kalau g mau ribet buat nge gorengnya)"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 135 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Soto ayam](https://img-global.cpcdn.com/recipes/9c3a233970259c59/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyediakan santapan enak untuk famili adalah suatu hal yang menggembirakan untuk anda sendiri. Peran seorang  wanita Tidak saja menjaga rumah saja, namun anda pun wajib memastikan keperluan gizi tercukupi dan panganan yang disantap keluarga tercinta harus sedap.

Di zaman  sekarang, kamu sebenarnya bisa membeli olahan siap saji tidak harus capek mengolahnya lebih dulu. Namun banyak juga lho orang yang selalu mau memberikan makanan yang terlezat untuk keluarganya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Mungkinkah anda adalah salah satu penikmat soto ayam?. Tahukah kamu, soto ayam adalah makanan khas di Indonesia yang saat ini disukai oleh setiap orang dari berbagai wilayah di Indonesia. Kita dapat menyajikan soto ayam buatan sendiri di rumahmu dan boleh jadi hidangan kegemaranmu di akhir pekanmu.

Kita jangan bingung untuk mendapatkan soto ayam, karena soto ayam sangat mudah untuk dicari dan kita pun boleh menghidangkannya sendiri di tempatmu. soto ayam boleh dibuat memalui beraneka cara. Kini telah banyak sekali cara modern yang membuat soto ayam lebih enak.

Resep soto ayam pun mudah dihidangkan, lho. Anda tidak usah capek-capek untuk membeli soto ayam, tetapi Kamu dapat menghidangkan sendiri di rumah. Bagi Kamu yang hendak membuatnya, berikut ini resep untuk menyajikan soto ayam yang nikamat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Soto ayam:

1. Sediakan 1/2 kg ayam (saya pilih bagian dada yah moms)
1. Gunakan 250 gr Kol/kobis
1. Gunakan  Soon 2bungkus (sya pakai kemasan kecil yah moms)
1. Ambil 100 gr Kecambah
1. Ambil  Daun bawang dan seledri
1. Siapkan 2 buah Tomat
1. Siapkan 1 buah Tomat
1. Ambil  Bumbu
1. Gunakan 5 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Sediakan 1 ruas jari Kunyit
1. Sediakan 2 lembar daun salam
1. Sediakan 2 potong laos digeprek
1. Ambil 2 batang sereh digeprek
1. Ambil 3 lembar daun jeruk
1. Siapkan 1 sdt garam (sesuaikan dengan selera)
1. Ambil 1/2 sdt Kaldu jamur
1. Ambil 1/2 sdt gula pasir
1. Siapkan 1/2 sdt merica
1. Siapkan Sejumput jinten
1. Gunakan 1 ruas jari kayu manis
1. Siapkan 500 ml Air




<!--inarticleads2-->

##### Cara menyiapkan Soto ayam:

1. Uleg bawang merah, bawang putih, merica, kunyit hingga halus. Kemudian tumis hingga harum san masukkan daun salam, daun jeruk, sereh, laos. Setelah daun salam layu masukan 500ml air
1. Setelah air mendidih masukkan kayu manis, jinten, tambahkan garam, gula, dan kaldu jamur. Tambahkan sedikit daun bawang untuk menambah aroma yah moms.... Setelah mendidih masukkan ayam rebus hingga ayam empuk kemudian angkat ayam dan sisihkan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Soto ayam">1. Goreng ayam sebentar kurang lebih 4-5 menit, sisihkan dan suwir2 ketika sdh dingin
1. Iris halus kol/kobis, daun seledry, daun bawang, tomat, kemudian rebus sebentar kecambah, wortel, dan juga soon. Kemudian sisihkan
1. Siapkan mangkok saji, masukkan isian sesuai selera kemudian siram dengan kuah soto, jangan lupa beri taburan bawang merah goreng yah moms... (bisa beli nawang merah goreng siap pakai moms kalau g mau ribet buat nge gorengnya)




Wah ternyata resep soto ayam yang enak tidak ribet ini gampang sekali ya! Kamu semua dapat membuatnya. Cara Membuat soto ayam Sangat sesuai sekali buat anda yang baru mau belajar memasak maupun juga untuk kamu yang sudah hebat memasak.

Apakah kamu ingin mulai mencoba bikin resep soto ayam lezat sederhana ini? Kalau kamu ingin, ayo kalian segera buruan siapin alat dan bahannya, lalu bikin deh Resep soto ayam yang nikmat dan tidak ribet ini. Betul-betul taidak sulit kan. 

Jadi, ketimbang anda berlama-lama, maka kita langsung buat resep soto ayam ini. Dijamin anda gak akan nyesel membuat resep soto ayam enak sederhana ini! Selamat berkreasi dengan resep soto ayam lezat tidak rumit ini di tempat tinggal masing-masing,oke!.

