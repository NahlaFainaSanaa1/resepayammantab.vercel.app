---
description: "Cara membuat Ayam bakar ungkep bumbu kecap Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam bakar ungkep bumbu kecap Sederhana dan Mudah Dibuat"
slug: 459-cara-membuat-ayam-bakar-ungkep-bumbu-kecap-sederhana-dan-mudah-dibuat
date: 2021-01-11T10:49:50.778Z
image: https://img-global.cpcdn.com/recipes/79c14e55fb99134c/680x482cq70/ayam-bakar-ungkep-bumbu-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/79c14e55fb99134c/680x482cq70/ayam-bakar-ungkep-bumbu-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/79c14e55fb99134c/680x482cq70/ayam-bakar-ungkep-bumbu-kecap-foto-resep-utama.jpg
author: Addie Ballard
ratingvalue: 4.2
reviewcount: 6
recipeingredient:
- " Bahan utama"
- "1/2 kg ayam"
- " Bumbu halus"
- "5 siung bawang putih"
- "3 siung bawang merah"
- "2 cm jahe"
- "2 cm kunyit"
- " Bumbu lain"
- "2 batang sereh"
- "1 ruas lengkuas digeprek"
- "3 sdm gula merah"
- "3 lembar daun salam"
- "2 lembar daun jeruk"
- "1 sdm kaldu bubuk"
- "5 sdm kecap manis"
- "2 sdm air asam jawa"
- "500 ml air"
- "2 sdm minyak untuk menumis"
recipeinstructions:
- "Haluskan bawang putih, bawang merah, jahe dan kunyit, lalu panaskan minyak dan tumis bumbu halus sampai harum."
- "Setelah harum masukkan lengkuas, sereh, daun jeruk, gula merah, kecap manis dan air asam jawa lalu masukkan ayam dan aduk sampai rata."
- "Masukkan air lalu didihkan sampai menyusut dan mengental."
- "Panaskan teflon beri sedikit minyak ambil ayam dan bakar di atas teflon sebentar saja untuk memperoleh aroma bakarannya. Angkat dan sajikan. Ayam ungkep bumbu kecap siap dihidangkan dengan sambel kecap juga lebih yummi."
categories:
- Resep
tags:
- ayam
- bakar
- ungkep

katakunci: ayam bakar ungkep 
nutrition: 204 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam bakar ungkep bumbu kecap](https://img-global.cpcdn.com/recipes/79c14e55fb99134c/680x482cq70/ayam-bakar-ungkep-bumbu-kecap-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyajikan masakan nikmat bagi keluarga tercinta merupakan hal yang mengasyikan untuk anda sendiri. Tanggung jawab seorang istri Tidak cuman menangani rumah saja, tapi kamu juga harus memastikan keperluan nutrisi terpenuhi dan juga santapan yang dikonsumsi anak-anak wajib mantab.

Di era  saat ini, kita sebenarnya dapat mengorder olahan praktis walaupun tanpa harus susah memasaknya terlebih dahulu. Namun ada juga lho mereka yang memang ingin memberikan yang terlezat untuk orang yang dicintainya. Pasalnya, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penggemar ayam bakar ungkep bumbu kecap?. Tahukah kamu, ayam bakar ungkep bumbu kecap merupakan sajian khas di Indonesia yang saat ini disukai oleh orang-orang dari berbagai tempat di Nusantara. Kamu dapat membuat ayam bakar ungkep bumbu kecap sendiri di rumah dan dapat dijadikan makanan favoritmu di akhir pekan.

Kita tak perlu bingung untuk memakan ayam bakar ungkep bumbu kecap, lantaran ayam bakar ungkep bumbu kecap tidak sulit untuk ditemukan dan kita pun dapat menghidangkannya sendiri di rumah. ayam bakar ungkep bumbu kecap bisa dibuat memalui beraneka cara. Sekarang telah banyak cara kekinian yang menjadikan ayam bakar ungkep bumbu kecap lebih enak.

Resep ayam bakar ungkep bumbu kecap pun gampang sekali dihidangkan, lho. Anda tidak usah ribet-ribet untuk membeli ayam bakar ungkep bumbu kecap, karena Kita dapat menyiapkan di rumah sendiri. Bagi Kamu yang akan menghidangkannya, berikut resep menyajikan ayam bakar ungkep bumbu kecap yang nikamat yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam bakar ungkep bumbu kecap:

1. Gunakan  Bahan utama
1. Gunakan 1/2 kg ayam
1. Gunakan  Bumbu halus
1. Sediakan 5 siung bawang putih
1. Gunakan 3 siung bawang merah
1. Sediakan 2 cm jahe
1. Ambil 2 cm kunyit
1. Sediakan  Bumbu lain
1. Sediakan 2 batang sereh
1. Siapkan 1 ruas lengkuas (digeprek)
1. Ambil 3 sdm gula merah
1. Gunakan 3 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Ambil 1 sdm kaldu bubuk
1. Ambil 5 sdm kecap manis
1. Sediakan 2 sdm air asam jawa
1. Gunakan 500 ml air
1. Gunakan 2 sdm minyak untuk menumis




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam bakar ungkep bumbu kecap:

1. Haluskan bawang putih, bawang merah, jahe dan kunyit, lalu panaskan minyak dan tumis bumbu halus sampai harum.
1. Setelah harum masukkan lengkuas, sereh, daun jeruk, gula merah, kecap manis dan air asam jawa lalu masukkan ayam dan aduk sampai rata.
1. Masukkan air lalu didihkan sampai menyusut dan mengental.
1. Panaskan teflon beri sedikit minyak ambil ayam dan bakar di atas teflon sebentar saja untuk memperoleh aroma bakarannya. Angkat dan sajikan. Ayam ungkep bumbu kecap siap dihidangkan dengan sambel kecap juga lebih yummi.




Wah ternyata cara membuat ayam bakar ungkep bumbu kecap yang enak sederhana ini enteng banget ya! Kalian semua bisa membuatnya. Cara buat ayam bakar ungkep bumbu kecap Sangat sesuai banget untuk kalian yang sedang belajar memasak maupun juga bagi kalian yang telah pandai dalam memasak.

Apakah kamu ingin mencoba membuat resep ayam bakar ungkep bumbu kecap nikmat sederhana ini? Kalau anda mau, mending kamu segera buruan siapin alat-alat dan bahannya, lalu buat deh Resep ayam bakar ungkep bumbu kecap yang enak dan simple ini. Sungguh mudah kan. 

Maka, daripada anda berfikir lama-lama, hayo kita langsung saja buat resep ayam bakar ungkep bumbu kecap ini. Pasti kalian tiidak akan menyesal bikin resep ayam bakar ungkep bumbu kecap nikmat simple ini! Selamat berkreasi dengan resep ayam bakar ungkep bumbu kecap lezat simple ini di rumah sendiri,oke!.

