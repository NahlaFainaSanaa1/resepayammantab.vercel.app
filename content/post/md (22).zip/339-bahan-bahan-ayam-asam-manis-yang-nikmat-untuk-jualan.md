---
description: "Bahan-bahan Ayam Asam Manis yang nikmat Untuk Jualan"
title: "Bahan-bahan Ayam Asam Manis yang nikmat Untuk Jualan"
slug: 339-bahan-bahan-ayam-asam-manis-yang-nikmat-untuk-jualan
date: 2021-03-25T07:15:05.703Z
image: https://img-global.cpcdn.com/recipes/504d29795bc2cfd1/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/504d29795bc2cfd1/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/504d29795bc2cfd1/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Ronnie Payne
ratingvalue: 4
reviewcount: 7
recipeingredient:
- " Dada ayam fillet bisa dipotong dadu atau sedikit memanjang"
- " Bahan marinasi ayam"
- "1 sdm saos tiram"
- "1/2 sdt lada bulat yg sudah diulek"
- "1 sdt kecap asin"
- "1/2 potong jeruk nipis"
- " Bahan tepung krispi ayam"
- "1 sdm tepung kobe krispi"
- "3 sdm terigu"
- "1/2 sdt baking powder"
- " Bahan saus asam manis"
- "1 buah paprika merah bisa dipakai semua atau setengahnya"
- "1 buah paprika hijau"
- "1 buah bawang bombay bisa dipakai separuh balik ke selera"
- "1 siung bawang putih cincang"
- "4 cm jahe bisa cincang atau geprek atau parut"
- "1 sdm kecap inggris"
- "4 sdm saus tomat"
- "1 sdm saus cabe botolan"
- "100 ml air"
- "1 sdm maizena larutkan dengan air"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya minyak"
recipeinstructions:
- "Siapkan semua bahan dan peralatan."
- "Saya selalu marinasi ayam kalau mau ditepungin. Beri waktu sekitar 20menitan untuk marinasinya."
- "Siapkan tepung krispinya. Bisa dibuat 1 adonan basah agak kental. Atau 2 adonan yaitu basah dan kering. Kalau saya pakai 2 adonan."
- "Panaskan minyak yg cukup utk goreng ayam. Masukkan potongan ayam ke adonan kering - basah - kering lalu goreng sampai semua potongan habis."
- "Pastikan ayam mateng luar dalam ya hingga warna golden brown. Lalu angkat dan tiriskan"
- "Mari membuat saus. Beri sedikit minyak panas. Tumis bawangputih terlebih dahulu. Lalu masukkan jahe. Aduk"
- "Api jangan besar supaya tidak gosong. Kemudian masukkan bombay dan semua paprika."
- "Setelah agak layu, masukkan saus tomat dan sambal. Lanjut dengan kecap inggris dan air."
- "Setelah itu masukkan maizena yg sudah dilarutkan tadi. Aduk"
- "Tambahkan garam dan gula secukupnya. Tes rasa. Jika sudah pas bisa disajikan langsung disiram ke ayam atau terpisah sebagai cocolan."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 114 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/504d29795bc2cfd1/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Andai kamu seorang istri, mempersiapkan hidangan nikmat bagi orang tercinta adalah suatu hal yang menyenangkan bagi anda sendiri. Tugas seorang ibu Tidak hanya mengerjakan pekerjaan rumah saja, namun kamu juga harus memastikan kebutuhan nutrisi tercukupi dan panganan yang dimakan orang tercinta harus lezat.

Di masa  sekarang, anda sebenarnya dapat memesan masakan yang sudah jadi walaupun tanpa harus capek membuatnya dahulu. Namun ada juga lho orang yang memang ingin memberikan makanan yang terbaik untuk keluarganya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai makanan kesukaan famili. 



Apakah anda merupakan salah satu penggemar ayam asam manis?. Asal kamu tahu, ayam asam manis adalah hidangan khas di Nusantara yang kini disukai oleh orang-orang dari berbagai daerah di Nusantara. Kamu bisa menyajikan ayam asam manis olahan sendiri di rumah dan dapat dijadikan camilan kesukaanmu di hari libur.

Kita jangan bingung untuk menyantap ayam asam manis, sebab ayam asam manis tidak sukar untuk ditemukan dan juga kamu pun boleh membuatnya sendiri di tempatmu. ayam asam manis bisa diolah memalui beragam cara. Kini ada banyak resep kekinian yang menjadikan ayam asam manis lebih enak.

Resep ayam asam manis pun sangat gampang untuk dibuat, lho. Kita tidak usah capek-capek untuk memesan ayam asam manis, tetapi Anda dapat menghidangkan sendiri di rumah. Untuk Kamu yang hendak menghidangkannya, berikut resep untuk membuat ayam asam manis yang nikamat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Asam Manis:

1. Ambil  Dada ayam fillet, (bisa dipotong dadu atau sedikit memanjang)
1. Ambil  Bahan marinasi ayam:
1. Gunakan 1 sdm saos tiram
1. Gunakan 1/2 sdt lada bulat yg sudah diulek
1. Ambil 1 sdt kecap asin
1. Siapkan 1/2 potong jeruk nipis
1. Sediakan  Bahan tepung krispi ayam:
1. Sediakan 1 sdm tepung kobe krispi
1. Gunakan 3 sdm terigu
1. Gunakan 1/2 sdt baking powder
1. Gunakan  Bahan saus asam manis:
1. Sediakan 1 buah paprika merah, bisa dipakai semua atau setengahnya
1. Sediakan 1 buah paprika hijau
1. Ambil 1 buah bawang bombay, bisa dipakai separuh balik ke selera
1. Ambil 1 siung bawang putih, cincang
1. Sediakan 4 cm jahe, bisa cincang atau geprek atau parut
1. Ambil 1 sdm kecap inggris
1. Ambil 4 sdm saus tomat
1. Gunakan 1 sdm saus cabe botolan
1. Ambil 100 ml air
1. Sediakan 1 sdm maizena, larutkan dengan air
1. Siapkan Secukupnya garam
1. Ambil Secukupnya gula
1. Gunakan Secukupnya minyak




<!--inarticleads2-->

##### Cara menyiapkan Ayam Asam Manis:

1. Siapkan semua bahan dan peralatan.
1. Saya selalu marinasi ayam kalau mau ditepungin. Beri waktu sekitar 20menitan untuk marinasinya.
1. Siapkan tepung krispinya. Bisa dibuat 1 adonan basah agak kental. Atau 2 adonan yaitu basah dan kering. Kalau saya pakai 2 adonan.
1. Panaskan minyak yg cukup utk goreng ayam. Masukkan potongan ayam ke adonan kering - basah - kering lalu goreng sampai semua potongan habis.
1. Pastikan ayam mateng luar dalam ya hingga warna golden brown. Lalu angkat dan tiriskan
1. Mari membuat saus. Beri sedikit minyak panas. Tumis bawangputih terlebih dahulu. Lalu masukkan jahe. Aduk
1. Api jangan besar supaya tidak gosong. Kemudian masukkan bombay dan semua paprika.
1. Setelah agak layu, masukkan saus tomat dan sambal. Lanjut dengan kecap inggris dan air.
1. Setelah itu masukkan maizena yg sudah dilarutkan tadi. Aduk
1. Tambahkan garam dan gula secukupnya. Tes rasa. Jika sudah pas bisa disajikan langsung disiram ke ayam atau terpisah sebagai cocolan.




Wah ternyata resep ayam asam manis yang mantab simple ini gampang sekali ya! Kita semua bisa menghidangkannya. Cara Membuat ayam asam manis Sesuai banget buat anda yang baru belajar memasak maupun juga bagi anda yang sudah pandai memasak.

Tertarik untuk mulai mencoba buat resep ayam asam manis enak tidak ribet ini? Kalau kamu mau, yuk kita segera buruan siapin peralatan dan bahannya, setelah itu bikin deh Resep ayam asam manis yang nikmat dan tidak rumit ini. Sangat gampang kan. 

Jadi, ketimbang anda berfikir lama-lama, maka kita langsung buat resep ayam asam manis ini. Dijamin kamu tak akan nyesel bikin resep ayam asam manis mantab sederhana ini! Selamat mencoba dengan resep ayam asam manis nikmat tidak rumit ini di rumah kalian sendiri,ya!.

