---
description: "Cara membuat Soto Ayam yang lezat dan Mudah Dibuat"
title: "Cara membuat Soto Ayam yang lezat dan Mudah Dibuat"
slug: 186-cara-membuat-soto-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-05-20T03:03:44.762Z
image: https://img-global.cpcdn.com/recipes/627c9f6674b50aad/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/627c9f6674b50aad/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/627c9f6674b50aad/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Clayton Houston
ratingvalue: 4.6
reviewcount: 4
recipeingredient:
- "5 siung bawang putih"
- "4 siung bawang merah"
- "6 buah kemiri"
- " lengkuas"
- " kunyit"
- " sereh"
- " ketumbar bubuk"
- " merica bubuk"
- " penyedap rasa"
- " daun bawang"
- " air"
- " bihun"
- " kol"
- " ayam"
- " daun jeruk"
recipeinstructions:
- "Siapkan bawang putih, bawang merah, ketumbar, merica, kemiri, lengkuas, dan kunyit. Blender semua bahan hingga halus."
- "Siapkan ayam dan cuci sampai bersih."
- "Tumis bumbu dan masukkan daun bawang yang sudah di potong-potong serta sereh dan lengkuas yang sudah di geprek. Tumis bumbu hingga matang dan wangi."
- "Untuk kuah soto nya, masak ayam dan masukkan bumbu yang sudah di tumis tadi. Tambahkan penyedap rasa serta daun jeruk dan aduk hingga merata. Masak hingga ayam matang."
- "Rebus bihun angkat dan tiriskan. Potong-potong kol, kemudian cuci angkat dan tiriskan."
- "Bila ayam sudah matang. Angkat dan suwir-suwir."
- "Sajikan dalam mangkuk bihun, kol, ayam suwielr dan tuangkan kuah serta berikan perasan jeruk nipis. Bila ada bawang goreng sajikan di atas soto. Soto ayam siap disantap."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 149 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/627c9f6674b50aad/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan hidangan lezat buat keluarga adalah hal yang sangat menyenangkan bagi kita sendiri. Tanggung jawab seorang ibu Tidak sekadar menangani rumah saja, namun anda juga harus menyediakan keperluan nutrisi tercukupi dan panganan yang dikonsumsi keluarga tercinta wajib mantab.

Di masa  sekarang, kalian sebenarnya bisa memesan santapan siap saji meski tidak harus susah memasaknya dahulu. Tetapi ada juga mereka yang memang ingin memberikan makanan yang terenak untuk orang yang dicintainya. Lantaran, memasak yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan sesuai dengan kesukaan orang tercinta. 



Apakah anda salah satu penikmat soto ayam?. Asal kamu tahu, soto ayam adalah sajian khas di Nusantara yang sekarang disukai oleh banyak orang dari hampir setiap tempat di Nusantara. Kita bisa membuat soto ayam sendiri di rumah dan dapat dijadikan camilan kegemaranmu di hari liburmu.

Kalian tidak perlu bingung jika kamu ingin menyantap soto ayam, karena soto ayam tidak sulit untuk dicari dan anda pun boleh menghidangkannya sendiri di tempatmu. soto ayam boleh dimasak lewat bermacam cara. Kini ada banyak banget resep modern yang membuat soto ayam semakin lebih lezat.

Resep soto ayam juga mudah sekali untuk dibikin, lho. Kamu tidak perlu repot-repot untuk membeli soto ayam, sebab Kita bisa menghidangkan di rumahmu. Bagi Kita yang mau menghidangkannya, dibawah ini merupakan cara membuat soto ayam yang enak yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Soto Ayam:

1. Siapkan 5 siung bawang putih
1. Sediakan 4 siung bawang merah
1. Ambil 6 buah kemiri
1. Ambil  lengkuas
1. Siapkan  kunyit
1. Gunakan  sereh
1. Ambil  ketumbar bubuk
1. Ambil  merica bubuk
1. Sediakan  penyedap rasa
1. Ambil  daun bawang
1. Ambil  air
1. Ambil  bihun
1. Sediakan  kol
1. Gunakan  ayam
1. Gunakan  daun jeruk




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam:

1. Siapkan bawang putih, bawang merah, ketumbar, merica, kemiri, lengkuas, dan kunyit. Blender semua bahan hingga halus.
1. Siapkan ayam dan cuci sampai bersih.
1. Tumis bumbu dan masukkan daun bawang yang sudah di potong-potong serta sereh dan lengkuas yang sudah di geprek. Tumis bumbu hingga matang dan wangi.
1. Untuk kuah soto nya, masak ayam dan masukkan bumbu yang sudah di tumis tadi. Tambahkan penyedap rasa serta daun jeruk dan aduk hingga merata. Masak hingga ayam matang.
1. Rebus bihun angkat dan tiriskan. Potong-potong kol, kemudian cuci angkat dan tiriskan.
1. Bila ayam sudah matang. Angkat dan suwir-suwir.
1. Sajikan dalam mangkuk bihun, kol, ayam suwielr dan tuangkan kuah serta berikan perasan jeruk nipis. Bila ada bawang goreng sajikan di atas soto. Soto ayam siap disantap.




Wah ternyata cara membuat soto ayam yang nikamt sederhana ini enteng banget ya! Kalian semua mampu mencobanya. Resep soto ayam Sangat cocok banget buat kamu yang baru belajar memasak atau juga bagi anda yang telah jago memasak.

Apakah kamu mau mencoba membikin resep soto ayam nikmat simple ini? Kalau mau, yuk kita segera buruan siapin alat dan bahan-bahannya, lantas bikin deh Resep soto ayam yang nikmat dan tidak ribet ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang kita diam saja, ayo langsung aja bikin resep soto ayam ini. Pasti anda tiidak akan menyesal sudah buat resep soto ayam nikmat tidak rumit ini! Selamat berkreasi dengan resep soto ayam enak tidak rumit ini di tempat tinggal kalian masing-masing,ya!.

