---
description: "Cara membuat Ayam Bakar Kecap Mudah (Grilled Chicken) yang lezat Untuk Jualan"
title: "Cara membuat Ayam Bakar Kecap Mudah (Grilled Chicken) yang lezat Untuk Jualan"
slug: 414-cara-membuat-ayam-bakar-kecap-mudah-grilled-chicken-yang-lezat-untuk-jualan
date: 2021-06-07T03:39:22.175Z
image: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
author: Beulah Harvey
ratingvalue: 4.6
reviewcount: 11
recipeingredient:
- "1/2 ekor Ayam saya suka bagian paha"
- " Bumbu Ungkep"
- "1 batang Serai"
- "2 lembar Daun Salam"
- "1 ruas Lengkuas"
- "Secukupnya Garam Gula Merica Bubuk dan Kecap Manis"
- "2 bongkah kecil Gula Merah Sekitar 23 sendok makan bila di potongpotong"
- " Bumbu Halus BlenderUlek"
- "4 siung Bawang Putih"
- "7 siung Bawang Merah"
- "5 buah Cabai Merah Keriting"
- "2 buah Cabai Merah Besar"
- "2 butir Kemiri"
- "1 ruas Jahe"
- "1 sdm Kunyit Bubuk"
- "1 sdm Ketumbar Bubuk"
recipeinstructions:
- "Masukkan bumbu yang sudah dihaluskan kedalam wajan atau panci, lalu tambahkan ayam, serai, lengkuas, daun salam serta air (tambahkan air hingga semua bagian ayam tenggelam). Jangan lupa tambahkan garam, gula dan merica bubuk. Sisihkan gula merah dan kecap untuk nanti."
- "Ungkep ayam dengan api sedang atau kecil, biarkan hingga matang. Setelah ayam matang dan bumbu meresap tambahkan gula merah dan kecap. Lalu aduk rata dan biarkan hingga air ungkepan hampir kering (sambil dites rasa)."
- "Jika suka ayam bakar yang manis bisa tambahkan gula agak banyak dan kecap. Tapi harus sambil dites rasa, agar rasa gula dan kecap tidak terlalu berlebihan."
- "Setelah itu matikan kompor dan bakar ayam yang sudah diungkep dengan teflon (kalau saya, teflon saya lapisi sedikit minyak goreng, diusapkan merata menggunakan tissue). Bakar dengan api kecil."
- "Setelah matang bisa langsung disantap dengan nasi hangat. Selamat Mencoba 😊"
categories:
- Resep
tags:
- ayam
- bakar
- kecap

katakunci: ayam bakar kecap 
nutrition: 226 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Bakar Kecap Mudah (Grilled Chicken)](https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan hidangan lezat untuk keluarga tercinta adalah suatu hal yang sangat menyenangkan untuk kita sendiri. Kewajiban seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, tetapi anda pun wajib memastikan kebutuhan gizi tercukupi dan juga masakan yang dikonsumsi keluarga tercinta wajib enak.

Di zaman  sekarang, kita memang bisa mengorder olahan yang sudah jadi tidak harus susah memasaknya lebih dulu. Tapi banyak juga lho mereka yang memang ingin menyajikan yang terlezat untuk orang tercintanya. Lantaran, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut berdasarkan selera famili. 



Apakah kamu seorang penyuka ayam bakar kecap mudah (grilled chicken)?. Asal kamu tahu, ayam bakar kecap mudah (grilled chicken) adalah makanan khas di Nusantara yang saat ini disukai oleh orang-orang dari berbagai daerah di Indonesia. Anda bisa menyajikan ayam bakar kecap mudah (grilled chicken) kreasi sendiri di rumah dan boleh dijadikan makanan kesenanganmu di akhir pekan.

Kalian jangan bingung jika kamu ingin memakan ayam bakar kecap mudah (grilled chicken), lantaran ayam bakar kecap mudah (grilled chicken) tidak sulit untuk ditemukan dan juga anda pun boleh mengolahnya sendiri di tempatmu. ayam bakar kecap mudah (grilled chicken) boleh dibuat dengan berbagai cara. Kini pun sudah banyak banget resep kekinian yang menjadikan ayam bakar kecap mudah (grilled chicken) semakin lebih enak.

Resep ayam bakar kecap mudah (grilled chicken) juga sangat mudah dibikin, lho. Kamu jangan capek-capek untuk membeli ayam bakar kecap mudah (grilled chicken), lantaran Kalian dapat membuatnya sendiri di rumah. Bagi Anda yang akan menyajikannya, dibawah ini merupakan cara membuat ayam bakar kecap mudah (grilled chicken) yang enak yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Bakar Kecap Mudah (Grilled Chicken):

1. Siapkan 1/2 ekor Ayam (saya suka bagian paha)
1. Gunakan  Bumbu Ungkep
1. Ambil 1 batang Serai
1. Gunakan 2 lembar Daun Salam
1. Ambil 1 ruas Lengkuas
1. Gunakan Secukupnya Garam, Gula, Merica Bubuk dan Kecap Manis
1. Gunakan 2 bongkah kecil Gula Merah (Sekitar 2-3 sendok makan bila di potong-potong)
1. Gunakan  Bumbu Halus (Blender/Ulek)
1. Siapkan 4 siung Bawang Putih
1. Ambil 7 siung Bawang Merah
1. Gunakan 5 buah Cabai Merah Keriting
1. Gunakan 2 buah Cabai Merah Besar
1. Siapkan 2 butir Kemiri
1. Gunakan 1 ruas Jahe
1. Gunakan 1 sdm Kunyit Bubuk
1. Sediakan 1 sdm Ketumbar Bubuk




<!--inarticleads2-->

##### Cara menyiapkan Ayam Bakar Kecap Mudah (Grilled Chicken):

1. Masukkan bumbu yang sudah dihaluskan kedalam wajan atau panci, lalu tambahkan ayam, serai, lengkuas, daun salam serta air (tambahkan air hingga semua bagian ayam tenggelam). Jangan lupa tambahkan garam, gula dan merica bubuk. Sisihkan gula merah dan kecap untuk nanti.
1. Ungkep ayam dengan api sedang atau kecil, biarkan hingga matang. Setelah ayam matang dan bumbu meresap tambahkan gula merah dan kecap. Lalu aduk rata dan biarkan hingga air ungkepan hampir kering (sambil dites rasa).
1. Jika suka ayam bakar yang manis bisa tambahkan gula agak banyak dan kecap. Tapi harus sambil dites rasa, agar rasa gula dan kecap tidak terlalu berlebihan.
1. Setelah itu matikan kompor dan bakar ayam yang sudah diungkep dengan teflon (kalau saya, teflon saya lapisi sedikit minyak goreng, diusapkan merata menggunakan tissue). Bakar dengan api kecil.
1. Setelah matang bisa langsung disantap dengan nasi hangat. Selamat Mencoba 😊




Wah ternyata cara membuat ayam bakar kecap mudah (grilled chicken) yang mantab sederhana ini enteng sekali ya! Kita semua bisa menghidangkannya. Cara buat ayam bakar kecap mudah (grilled chicken) Sangat cocok banget buat anda yang baru belajar memasak atau juga bagi kamu yang telah lihai dalam memasak.

Tertarik untuk mencoba membikin resep ayam bakar kecap mudah (grilled chicken) enak sederhana ini? Kalau kalian mau, ayo kamu segera siapin peralatan dan bahan-bahannya, setelah itu buat deh Resep ayam bakar kecap mudah (grilled chicken) yang nikmat dan tidak rumit ini. Betul-betul mudah kan. 

Maka, ketimbang anda diam saja, maka langsung aja hidangkan resep ayam bakar kecap mudah (grilled chicken) ini. Dijamin kalian tiidak akan nyesel membuat resep ayam bakar kecap mudah (grilled chicken) mantab tidak ribet ini! Selamat mencoba dengan resep ayam bakar kecap mudah (grilled chicken) nikmat tidak ribet ini di tempat tinggal masing-masing,oke!.

