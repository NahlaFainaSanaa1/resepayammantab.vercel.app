---
description: "Resep Sup Ayam Ala KFC yang lezat Untuk Jualan"
title: "Resep Sup Ayam Ala KFC yang lezat Untuk Jualan"
slug: 51-resep-sup-ayam-ala-kfc-yang-lezat-untuk-jualan
date: 2021-01-11T19:24:04.158Z
image: https://img-global.cpcdn.com/recipes/40b365988ad87ee8/680x482cq70/sup-ayam-ala-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/40b365988ad87ee8/680x482cq70/sup-ayam-ala-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/40b365988ad87ee8/680x482cq70/sup-ayam-ala-kfc-foto-resep-utama.jpg
author: Gavin Gutierrez
ratingvalue: 4.8
reviewcount: 12
recipeingredient:
- "1/2 kg ayam potong kecilkecil"
- "2 buah jagung manis dipipil"
- "3 buah wortel dipotong dadu"
- "Secukupnya buncis potong 2cm"
- "Secukupnya daun seledri"
- "Secukupnya daun bawang"
- "1 sdm margarin"
- "Secukupnya merica bubuk"
- "Secukupnya kaldu ayam boleh diskip"
- "Secukupnya kaldu jamur"
- "Secukupnya garam"
- "1 sdt gula pasir"
recipeinstructions:
- "Seperti biasa, cuci bersih ayam, rebus sampai mendidih saja airnya, tdk perlu lama2. Matikan kompor, buang air rebusan ayam, bilas dgn air bersih, sisihkan. Cuci bersih semua bahan sayurannya setelah dikupas, baru dipotong2."
- "Masukkan ayam yg sdh direbus &amp; dicuci tadi ke dalam panci, beri air &amp; rebus kembali. Kalau pake ayam kampung tdk usah begini ya moms. Langsung rebus saja, tdk perlu dibuang airnya."
- "Setelah ayam mendidih, masukan wortel yg sdh di iris dadu tadi."
- "Setelah wortelnya setengah matang, masukkan potongan buncisnya."
- "Setelah itu masukkan pipilan jagung manisnya."
- "Kemudian masukkan trio penyedapnya, yaitu merica bubuk, kaldu ayam &amp; kaldu jamurnya."
- "Sebelum dimatikan kompornya, masukkan 1 sendok makan margarin, gula pasir &amp; garam. Aduk2 &amp; koreksi rasanya."
- "Terakhir masukkan daun seledri &amp; daun bawangnya. Aduk2 &amp; kemudian matikan kompornya."
- "Sup ayam ala2 kaefsi siap disajikan mom... ❤️"
- "Mudah &amp; cepat moms...solusi praktis kalo lagi ga punya bawang putih atau males ngeprek bawang putih 🤭"
categories:
- Resep
tags:
- sup
- ayam
- ala

katakunci: sup ayam ala 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Sup Ayam Ala KFC](https://img-global.cpcdn.com/recipes/40b365988ad87ee8/680x482cq70/sup-ayam-ala-kfc-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan masakan menggugah selera untuk keluarga tercinta merupakan suatu hal yang menggembirakan untuk kita sendiri. Kewajiban seorang ibu Tidak sekedar menjaga rumah saja, namun anda pun harus memastikan kebutuhan nutrisi terpenuhi dan juga masakan yang dikonsumsi anak-anak mesti enak.

Di waktu  sekarang, kita memang bisa membeli santapan instan tanpa harus susah mengolahnya dulu. Namun ada juga mereka yang memang mau memberikan makanan yang terlezat untuk orang tercintanya. Lantaran, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan keluarga. 

Beli mahal 🤭, buat sendiri lebih puas makannya 😅😅. Recook : @happy_endahsa #GenkPejuangDapur #ArisanRecook_HappyEnd #RememberGenkPeDa_HappyEnd #GenkPeDa_HappyEnd #GenkPeDa_Eksis #MasakItuSaya #BagikanIspirasimu #cookpadcommunity_jakarta #cookpadindonesia. Sup Ayam ala kfc dada ayam fillet,potong dadu • sayap ayam,potong kecil (optional) • wortel,potong kecil dadu • kentang,potong kecil dadu • jagung,pipil (optional) • bawang putih,cincang kasar • daun seledri,iris tipis • garam Anda bisa mengatasi hal ini dengan mencoba sendiri resep sup ala KFC ini di rumah yang pastinya anda bisa mengontrol jumlah daging, jumlah porsi, dan bahan lainnya yang ingin anda tambahkan.

Mungkinkah anda seorang penyuka sup ayam ala kfc?. Tahukah kamu, sup ayam ala kfc adalah sajian khas di Nusantara yang sekarang disenangi oleh setiap orang dari hampir setiap wilayah di Nusantara. Kita bisa menyajikan sup ayam ala kfc sendiri di rumahmu dan dapat dijadikan hidangan favoritmu di hari libur.

Kalian tak perlu bingung jika kamu ingin memakan sup ayam ala kfc, lantaran sup ayam ala kfc sangat mudah untuk didapatkan dan kalian pun dapat membuatnya sendiri di rumah. sup ayam ala kfc bisa dibuat dengan bermacam cara. Kini sudah banyak sekali cara modern yang menjadikan sup ayam ala kfc lebih nikmat.

Resep sup ayam ala kfc pun sangat gampang dibuat, lho. Kita jangan repot-repot untuk membeli sup ayam ala kfc, karena Anda bisa membuatnya ditempatmu. Untuk Kamu yang mau membuatnya, di bawah ini adalah resep untuk membuat sup ayam ala kfc yang mantab yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Sup Ayam Ala KFC:

1. Sediakan 1/2 kg ayam potong kecil-kecil
1. Siapkan 2 buah jagung manis dipipil
1. Gunakan 3 buah wortel dipotong dadu
1. Ambil Secukupnya buncis potong 2cm
1. Ambil Secukupnya daun seledri
1. Ambil Secukupnya daun bawang
1. Siapkan 1 sdm margarin
1. Ambil Secukupnya merica bubuk
1. Gunakan Secukupnya kaldu ayam (boleh diskip)
1. Gunakan Secukupnya kaldu jamur
1. Siapkan Secukupnya garam
1. Sediakan 1 sdt gula pasir


Jika kaldu ayam sudah hampir mendidih, masukkan ayam suwir, potongan wortel, jagung, dan kacang polong. Masukkan bumbu sup dengan lada dan garam. Cream soup ala KFC siap dihidangkan. Cream soup ayam ala KFC bawang Bombay, iris memanjang • bawang putih, geprek, cincang halus • jagung manis, pipil • wortel, potong dadu kecil • kentang, potong dadu kecil • daging ayam, potong dadu kecil • susu cair (saya pakai diamond) • kaldu bubuk Bahkan cara membuat krim sup ala KFC tak sulit loh. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Sup Ayam Ala KFC:

1. Seperti biasa, cuci bersih ayam, rebus sampai mendidih saja airnya, tdk perlu lama2. Matikan kompor, buang air rebusan ayam, bilas dgn air bersih, sisihkan. Cuci bersih semua bahan sayurannya setelah dikupas, baru dipotong2.
1. Masukkan ayam yg sdh direbus &amp; dicuci tadi ke dalam panci, beri air &amp; rebus kembali. Kalau pake ayam kampung tdk usah begini ya moms. Langsung rebus saja, tdk perlu dibuang airnya.
1. Setelah ayam mendidih, masukan wortel yg sdh di iris dadu tadi.
1. Setelah wortelnya setengah matang, masukkan potongan buncisnya.
1. Setelah itu masukkan pipilan jagung manisnya.
1. Kemudian masukkan trio penyedapnya, yaitu merica bubuk, kaldu ayam &amp; kaldu jamurnya.
1. Sebelum dimatikan kompornya, masukkan 1 sendok makan margarin, gula pasir &amp; garam. Aduk2 &amp; koreksi rasanya.
1. Terakhir masukkan daun seledri &amp; daun bawangnya. Aduk2 &amp; kemudian matikan kompornya.
1. Sup ayam ala2 kaefsi siap disajikan mom... ❤️
1. Mudah &amp; cepat moms...solusi praktis kalo lagi ga punya bawang putih atau males ngeprek bawang putih 🤭


Dengan Anda mengetahui bagaimana cara membuat krim sup ala KFC Anda tak perlu lagi jajan di luar. Krim sup memang jadi menu favorit semua orang. Baca Juga: Engga Perlu Beli Mahal-mahal, Begini Cara Membuat Kaldu yang Enak Di Rumah, Dijamin Antigagal! Panaskan minyak, tumis bawang putih, halia, bawang merah, bawang besar, serai dan cili. Tambahkan air dan perasakan dengan kiub ayam, sup bunjut, garam, gula, serbuk perasa dan sedikit sos ikan. 

Ternyata cara buat sup ayam ala kfc yang enak sederhana ini enteng sekali ya! Kamu semua mampu memasaknya. Cara buat sup ayam ala kfc Sangat sesuai banget untuk kalian yang baru akan belajar memasak maupun untuk kamu yang telah ahli memasak.

Apakah kamu tertarik mulai mencoba membikin resep sup ayam ala kfc enak sederhana ini? Kalau anda mau, ayo kamu segera buruan siapkan peralatan dan bahannya, setelah itu bikin deh Resep sup ayam ala kfc yang enak dan sederhana ini. Benar-benar gampang kan. 

Maka, ketimbang kita diam saja, ayo langsung aja buat resep sup ayam ala kfc ini. Dijamin anda tiidak akan nyesel sudah buat resep sup ayam ala kfc nikmat sederhana ini! Selamat berkreasi dengan resep sup ayam ala kfc lezat tidak ribet ini di tempat tinggal masing-masing,ya!.

