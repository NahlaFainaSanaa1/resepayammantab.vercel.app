---
description: "Bahan-bahan Ayam Panggang Bumbu Santan Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Ayam Panggang Bumbu Santan Sederhana dan Mudah Dibuat"
slug: 305-bahan-bahan-ayam-panggang-bumbu-santan-sederhana-dan-mudah-dibuat
date: 2021-03-03T02:46:09.691Z
image: https://img-global.cpcdn.com/recipes/21bee21c6c267815/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/21bee21c6c267815/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/21bee21c6c267815/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
author: Larry Vasquez
ratingvalue: 4.6
reviewcount: 10
recipeingredient:
- "500 gr ayam bagian paha cuci bersih lalu marinasi dengan secukupnya garam dan air jeruk nipis selama 15 menit lalu bilas kembali"
- "130 ml santan instan me 2 pack santan instan isi 65mlpack"
- "2 lembar daun jeruk"
- "1 batang serai digeprek"
- "350 ml air"
- "1/2 sdm garam"
- "1/4 sdt gula pasir"
- " Bumbu Halus"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "5 cm kunyit"
- "1 ruas lengkuas"
- "1 sdt ketumbar"
recipeinstructions:
- "Siapkan bahan yang digunakan"
- "Siapkan wajan, masukkan air, santan, bumbu halus, daun jeruk, serai, gula pasir dan garam. Aduk rata"
- "Kemudian masukkan ayam, lalu masak ayam hingga matang dan bumbunya meresap serta kuahnya menyusut dan terlihat sedikit mengental, sesekali diaduk-aduk dalam proses memasaknya."
- "Setelah ayam matang, pisahkan potongan ayam dari bumbunya. Sisihkan sisa bumbu santan (note: sisa bumbu santan jangan dibuang, karena nanti akan disajikan bersama ayam panggang)"
- "Oles tipis teflon dengan minyak goreng, lalu pangang ayam hingga kulit luarnya kering dan berwarna agak kecoklatan"
- "Tata ayam panggang di piring saji, lalu balurkan secukupnya sisa bumbu santan diatas ayam panggang. Sajikan Ayam Panggang Bumbu Santan bersama lalapan dan sambal sesuai selera 😊"
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 295 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Panggang Bumbu Santan](https://img-global.cpcdn.com/recipes/21bee21c6c267815/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan masakan nikmat untuk keluarga merupakan hal yang menggembirakan bagi kamu sendiri. Peran seorang ibu Tidak cuma menangani rumah saja, namun anda juga wajib menyediakan kebutuhan nutrisi terpenuhi dan olahan yang disantap anak-anak wajib menggugah selera.

Di zaman  saat ini, kamu memang dapat mengorder panganan siap saji walaupun tidak harus ribet memasaknya dahulu. Tetapi ada juga orang yang memang mau memberikan hidangan yang terlezat untuk orang tercintanya. Karena, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera keluarga tercinta. 



Apakah anda merupakan salah satu penggemar ayam panggang bumbu santan?. Tahukah kamu, ayam panggang bumbu santan merupakan sajian khas di Indonesia yang sekarang disenangi oleh setiap orang dari hampir setiap wilayah di Indonesia. Anda dapat menyajikan ayam panggang bumbu santan olahan sendiri di rumah dan pasti jadi makanan kesenanganmu di hari liburmu.

Anda tidak usah bingung untuk menyantap ayam panggang bumbu santan, sebab ayam panggang bumbu santan sangat mudah untuk didapatkan dan kalian pun boleh memasaknya sendiri di rumah. ayam panggang bumbu santan dapat dibuat lewat bermacam cara. Kini ada banyak banget cara kekinian yang menjadikan ayam panggang bumbu santan lebih mantap.

Resep ayam panggang bumbu santan pun gampang dihidangkan, lho. Kalian tidak perlu ribet-ribet untuk memesan ayam panggang bumbu santan, tetapi Kalian mampu menyiapkan di rumahmu. Untuk Kita yang akan membuatnya, dibawah ini merupakan resep menyajikan ayam panggang bumbu santan yang enak yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Panggang Bumbu Santan:

1. Gunakan 500 gr ayam bagian paha, cuci bersih, lalu marinasi dengan secukupnya garam dan air jeruk nipis selama 15 menit, lalu bilas kembali
1. Gunakan 130 ml santan instan (me. 2 pack santan instan isi @65ml/pack)
1. Sediakan 2 lembar daun jeruk
1. Siapkan 1 batang serai, digeprek
1. Ambil 350 ml air
1. Sediakan 1/2 sdm garam
1. Sediakan 1/4 sdt gula pasir
1. Siapkan  Bumbu Halus:
1. Ambil 4 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Siapkan 5 cm kunyit
1. Siapkan 1 ruas lengkuas
1. Ambil 1 sdt ketumbar




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Panggang Bumbu Santan:

1. Siapkan bahan yang digunakan
1. Siapkan wajan, masukkan air, santan, bumbu halus, daun jeruk, serai, gula pasir dan garam. Aduk rata
1. Kemudian masukkan ayam, lalu masak ayam hingga matang dan bumbunya meresap serta kuahnya menyusut dan terlihat sedikit mengental, sesekali diaduk-aduk dalam proses memasaknya.
1. Setelah ayam matang, pisahkan potongan ayam dari bumbunya. Sisihkan sisa bumbu santan (note: sisa bumbu santan jangan dibuang, karena nanti akan disajikan bersama ayam panggang)
1. Oles tipis teflon dengan minyak goreng, lalu pangang ayam hingga kulit luarnya kering dan berwarna agak kecoklatan
1. Tata ayam panggang di piring saji, lalu balurkan secukupnya sisa bumbu santan diatas ayam panggang. Sajikan Ayam Panggang Bumbu Santan bersama lalapan dan sambal sesuai selera 😊




Ternyata cara buat ayam panggang bumbu santan yang enak tidak ribet ini gampang banget ya! Kamu semua mampu menghidangkannya. Cara buat ayam panggang bumbu santan Sangat sesuai banget buat anda yang baru mau belajar memasak ataupun juga bagi anda yang sudah pandai memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam panggang bumbu santan nikmat sederhana ini? Kalau kamu tertarik, ayo kamu segera buruan siapin alat-alat dan bahan-bahannya, lalu bikin deh Resep ayam panggang bumbu santan yang nikmat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Maka, ketimbang anda berfikir lama-lama, yuk kita langsung saja bikin resep ayam panggang bumbu santan ini. Pasti kamu tiidak akan menyesal membuat resep ayam panggang bumbu santan nikmat sederhana ini! Selamat mencoba dengan resep ayam panggang bumbu santan lezat simple ini di tempat tinggal masing-masing,oke!.

