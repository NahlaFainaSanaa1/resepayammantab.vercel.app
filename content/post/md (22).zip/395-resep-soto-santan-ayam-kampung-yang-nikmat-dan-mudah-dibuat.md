---
description: "Resep Soto santan ayam kampung yang nikmat dan Mudah Dibuat"
title: "Resep Soto santan ayam kampung yang nikmat dan Mudah Dibuat"
slug: 395-resep-soto-santan-ayam-kampung-yang-nikmat-dan-mudah-dibuat
date: 2021-06-14T07:17:41.607Z
image: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
author: Jonathan Duncan
ratingvalue: 3.7
reviewcount: 13
recipeingredient:
- "1/2 kg ayam kampung"
- "1 bks santan cair"
- " Bahan tambahan"
- "1/2 ons soun rebus"
- "1 rb toge rebus sbntr"
- "2 rb kol rebus sebentar"
- "4 btr telor ayam rebus 20 menit"
- "1 batang sledri iris kecil"
- "2 buah jeruk limo"
- "1 buah tomat iris kasar"
- "3 batang daun bawangb iris"
- " Bawang goreng untuk taburan"
- " Bumbu halus"
- "7 siung bawang merah"
- "6 siung bawang putih"
- "4 butir kemiri"
- "1 ruas jahe"
- "1/2 ruas kunyit"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt merica biji"
- "1/2 bks ketumbar biji 500 rupiah"
- "1/2 bks jinten 500 rupiah"
- "1/2 sdt pala biji"
- "3 butir cengkeh"
- "2 butir kapulaga"
- " Bumbu cemplung"
- "1 lmbr daun salam"
- "5 lmbr daun jeruk"
- "1 buah bunga lawang"
- "1/2 potong kayu manis"
- "1/2 ruas lengkuas"
- " Sambal nya"
- "10 biji cabe rawit merah"
- " Gulagaram"
- " Dibikin goang aja"
recipeinstructions:
- "Cuci bersih ayam nya potong2 sesuai keinginan"
- "Didihkan air dan klau sdh bersih ayam ny tinggal masukan ke rebusan air tadi geplek diapi sedang slma 20 menit lalu matikan kompor ny"
- "Haluskan bumbunya boleh pkai blender atau manual aja pke coet biar wanginya nampol klo diulek sendiri mah."
- "Kalo sudah halus semua siapkan minyak di ketel tumis2 hingga harum dan klo dah setengah mateng masukan bumbu cemplung nya dan aduk2 sampe mateng dan kalo sudah mateng kasih air sedikit aja segelas misal ny"
- "Lalu hidup kan lg kompor yg ayam tdi lalu masukan si bumbu ke ayam ny bila kurang air nya boleh tambah lg sesuai selera aja dan koreksi rasa ya bun"
- "Kalo sudah siap siapkan mangkok dan masukan soto nya tata semua bahan tambahan nya.maaf aku juga pke suwiran ayam lgi biar enak aj😁"
- "Siap dihidangkan deh bunda2"
categories:
- Resep
tags:
- soto
- santan
- ayam

katakunci: soto santan ayam 
nutrition: 127 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto santan ayam kampung](https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan panganan mantab pada orang tercinta adalah hal yang menyenangkan untuk anda sendiri. Tugas seorang ibu Tidak cuma menangani rumah saja, namun kamu pun harus menyediakan keperluan gizi tercukupi dan hidangan yang dimakan keluarga tercinta harus enak.

Di waktu  sekarang, kita memang bisa membeli masakan jadi meski tanpa harus repot mengolahnya dahulu. Namun ada juga lho orang yang selalu ingin memberikan hidangan yang terlezat untuk keluarganya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan salah satu penyuka soto santan ayam kampung?. Asal kamu tahu, soto santan ayam kampung merupakan makanan khas di Indonesia yang saat ini digemari oleh banyak orang dari berbagai daerah di Indonesia. Kamu bisa menghidangkan soto santan ayam kampung hasil sendiri di rumah dan boleh jadi santapan kesukaanmu di hari liburmu.

Kita tidak perlu bingung jika kamu ingin mendapatkan soto santan ayam kampung, karena soto santan ayam kampung mudah untuk dicari dan juga kamu pun dapat membuatnya sendiri di rumah. soto santan ayam kampung dapat diolah memalui beraneka cara. Sekarang telah banyak banget cara kekinian yang menjadikan soto santan ayam kampung lebih enak.

Resep soto santan ayam kampung juga gampang dibuat, lho. Kamu tidak usah ribet-ribet untuk membeli soto santan ayam kampung, karena Anda bisa menyajikan sendiri di rumah. Bagi Anda yang akan mencobanya, dibawah ini merupakan resep menyajikan soto santan ayam kampung yang lezat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Soto santan ayam kampung:

1. Siapkan 1/2 kg ayam kampung
1. Sediakan 1 bks santan cair
1. Gunakan  Bahan tambahan
1. Sediakan 1/2 ons soun rebus
1. Siapkan 1 rb toge rebus sbntr
1. Siapkan 2 rb kol rebus sebentar
1. Ambil 4 btr telor ayam rebus 20 menit
1. Sediakan 1 batang sledri iris kecil
1. Ambil 2 buah jeruk limo
1. Siapkan 1 buah tomat iris kasar
1. Siapkan 3 batang daun bawangb iris
1. Sediakan  Bawang goreng untuk taburan
1. Sediakan  Bumbu halus
1. Siapkan 7 siung bawang merah
1. Ambil 6 siung bawang putih
1. Gunakan 4 butir kemiri
1. Ambil 1 ruas jahe
1. Sediakan 1/2 ruas kunyit
1. Ambil 1/2 sdt kunyit bubuk
1. Siapkan 1/2 sdt merica biji
1. Sediakan 1/2 bks ketumbar biji 500 rupiah
1. Gunakan 1/2 bks jinten 500 rupiah
1. Ambil 1/2 sdt pala biji
1. Ambil 3 butir cengkeh
1. Ambil 2 butir kapulaga
1. Sediakan  Bumbu cemplung
1. Sediakan 1 lmbr daun salam
1. Gunakan 5 lmbr daun jeruk
1. Siapkan 1 buah bunga lawang
1. Siapkan 1/2 potong kayu manis
1. Ambil 1/2 ruas lengkuas
1. Ambil  Sambal nya
1. Gunakan 10 biji cabe rawit merah
1. Sediakan  Gula+garam
1. Sediakan  Dibikin goang aja👍🏻




<!--inarticleads2-->

##### Cara menyiapkan Soto santan ayam kampung:

1. Cuci bersih ayam nya potong2 sesuai keinginan
1. Didihkan air dan klau sdh bersih ayam ny tinggal masukan ke rebusan air tadi geplek diapi sedang slma 20 menit lalu matikan kompor ny
1. Haluskan bumbunya boleh pkai blender atau manual aja pke coet biar wanginya nampol klo diulek sendiri mah.
1. Kalo sudah halus semua siapkan minyak di ketel tumis2 hingga harum dan klo dah setengah mateng masukan bumbu cemplung nya dan aduk2 sampe mateng dan kalo sudah mateng kasih air sedikit aja segelas misal ny
1. Lalu hidup kan lg kompor yg ayam tdi lalu masukan si bumbu ke ayam ny bila kurang air nya boleh tambah lg sesuai selera aja dan koreksi rasa ya bun
1. Kalo sudah siap siapkan mangkok dan masukan soto nya tata semua bahan tambahan nya.maaf aku juga pke suwiran ayam lgi biar enak aj😁
1. Siap dihidangkan deh bunda2




Wah ternyata resep soto santan ayam kampung yang enak tidak ribet ini enteng sekali ya! Semua orang mampu mencobanya. Resep soto santan ayam kampung Sesuai banget buat kamu yang baru belajar memasak maupun untuk kalian yang sudah pandai dalam memasak.

Tertarik untuk mulai mencoba membikin resep soto santan ayam kampung lezat tidak ribet ini? Kalau mau, ayo kalian segera buruan siapkan alat-alat dan bahan-bahannya, lalu buat deh Resep soto santan ayam kampung yang nikmat dan tidak ribet ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang kalian diam saja, yuk kita langsung hidangkan resep soto santan ayam kampung ini. Pasti kamu gak akan menyesal sudah bikin resep soto santan ayam kampung mantab tidak ribet ini! Selamat mencoba dengan resep soto santan ayam kampung enak sederhana ini di tempat tinggal kalian masing-masing,ya!.

