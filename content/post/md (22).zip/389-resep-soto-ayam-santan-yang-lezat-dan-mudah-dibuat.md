---
description: "Resep Soto Ayam Santan yang lezat dan Mudah Dibuat"
title: "Resep Soto Ayam Santan yang lezat dan Mudah Dibuat"
slug: 389-resep-soto-ayam-santan-yang-lezat-dan-mudah-dibuat
date: 2021-02-03T20:57:05.987Z
image: https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Flora Lee
ratingvalue: 4.4
reviewcount: 9
recipeingredient:
- "1/2 kg ayam"
- "1 buah santan"
- "Secukupnya garam"
- "Secukupnya lada bubuk"
- "Secukupnya kaldu bubukpenyedap"
- " Bumbu Halus"
- "4 siung bawang putih"
- "4 siung bawang merah"
- "2 butir kemiri sangrai"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1/2 ruas lengkuas"
- "1 sdt ketumbar"
- " Bumbu Cemplung"
- "1 batang sereh geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- " Bahan Pelengkap"
- "1 buah tomat"
- " Kentang goreng potong dadu"
- " Bawang goreng optional"
- " Daun bawang iris optional"
- " Emping"
recipeinstructions:
- "Tumis bumbu halus dan bumbu cemplung sampai harum."
- "Tambahkan air secukupnya untuk kuah dan masak hingga mendidih. Masukkan garam, lada dan penyedap."
- "Masukkan ayam ke dalam air kuah mendidih tadi dan masak sampai ayam matang. Kemudian angkat dan tiriskan ayam, lalu goreng sebentar sampai kecoklatan, dan suwir-suwir ayam."
- "Sementara itu masukkan santan ke dalam air kuah dan aduk perlahan. Jangan lupa koreksi rasa."
- "Jangan lupa juga goreng kentang yang sudah dipotong dadu."
- "Tata bahan pelengkap di mangkuk, dan siram dengan kuah soto. Siap disajikan dengan nasi hangat ^^ p.s:Kalo mau pedes bisa bikin sambel simplenya. Caranya rebus cabe rawit merah, kemudian blender atau ulek, tambahkan air dan garam sedikit."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan panganan nikmat buat orang tercinta adalah hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang istri bukan sekadar mengerjakan pekerjaan rumah saja, tetapi kamu pun harus menyediakan kebutuhan gizi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta mesti nikmat.

Di masa  saat ini, anda memang bisa membeli hidangan yang sudah jadi walaupun tanpa harus ribet memasaknya lebih dulu. Namun banyak juga orang yang selalu mau menghidangkan yang terbaik bagi orang tercintanya. Lantaran, memasak yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga tercinta. 



Mungkinkah kamu seorang penikmat soto ayam santan?. Asal kamu tahu, soto ayam santan merupakan sajian khas di Nusantara yang sekarang digemari oleh setiap orang dari hampir setiap daerah di Nusantara. Anda dapat membuat soto ayam santan sendiri di rumahmu dan dapat dijadikan makanan kegemaranmu di akhir pekan.

Kita tak perlu bingung jika kamu ingin mendapatkan soto ayam santan, karena soto ayam santan sangat mudah untuk didapatkan dan anda pun boleh memasaknya sendiri di tempatmu. soto ayam santan dapat diolah dengan beragam cara. Sekarang ada banyak sekali resep kekinian yang menjadikan soto ayam santan semakin enak.

Resep soto ayam santan juga sangat gampang untuk dibikin, lho. Kita tidak usah repot-repot untuk memesan soto ayam santan, karena Kita bisa menyiapkan di rumahmu. Untuk Kita yang akan mencobanya, berikut ini resep menyajikan soto ayam santan yang lezat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Soto Ayam Santan:

1. Gunakan 1/2 kg ayam
1. Sediakan 1 buah santan
1. Siapkan Secukupnya garam
1. Gunakan Secukupnya lada bubuk
1. Sediakan Secukupnya kaldu bubuk/penyedap
1. Sediakan  Bumbu Halus
1. Ambil 4 siung bawang putih
1. Gunakan 4 siung bawang merah
1. Siapkan 2 butir kemiri (sangrai)
1. Gunakan 1 ruas jahe
1. Gunakan 1 ruas kunyit
1. Gunakan 1/2 ruas lengkuas
1. Gunakan 1 sdt ketumbar
1. Siapkan  Bumbu Cemplung
1. Siapkan 1 batang sereh (geprek)
1. Siapkan 2 lembar daun salam
1. Sediakan 2 lembar daun jeruk
1. Siapkan  Bahan Pelengkap
1. Siapkan 1 buah tomat
1. Sediakan  Kentang goreng (potong dadu)
1. Ambil  Bawang goreng (optional)
1. Siapkan  Daun bawang iris (optional)
1. Siapkan  Emping




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Santan:

1. Tumis bumbu halus dan bumbu cemplung sampai harum.
1. Tambahkan air secukupnya untuk kuah dan masak hingga mendidih. Masukkan garam, lada dan penyedap.
1. Masukkan ayam ke dalam air kuah mendidih tadi dan masak sampai ayam matang. Kemudian angkat dan tiriskan ayam, lalu goreng sebentar sampai kecoklatan, dan suwir-suwir ayam.
1. Sementara itu masukkan santan ke dalam air kuah dan aduk perlahan. Jangan lupa koreksi rasa.
1. Jangan lupa juga goreng kentang yang sudah dipotong dadu.
1. Tata bahan pelengkap di mangkuk, dan siram dengan kuah soto. Siap disajikan dengan nasi hangat ^^ p.s:Kalo mau pedes bisa bikin sambel simplenya. Caranya rebus cabe rawit merah, kemudian blender atau ulek, tambahkan air dan garam sedikit.




Ternyata cara membuat soto ayam santan yang lezat sederhana ini mudah sekali ya! Kamu semua dapat mencobanya. Resep soto ayam santan Sesuai banget untuk anda yang baru akan belajar memasak maupun juga bagi kamu yang telah ahli memasak.

Tertarik untuk mulai mencoba membikin resep soto ayam santan mantab sederhana ini? Kalau kamu ingin, ayo kalian segera buruan menyiapkan alat dan bahan-bahannya, lalu bikin deh Resep soto ayam santan yang nikmat dan simple ini. Betul-betul taidak sulit kan. 

Maka, ketimbang kalian diam saja, maka kita langsung saja sajikan resep soto ayam santan ini. Pasti kamu gak akan nyesel sudah bikin resep soto ayam santan lezat tidak ribet ini! Selamat berkreasi dengan resep soto ayam santan nikmat sederhana ini di tempat tinggal sendiri,oke!.

