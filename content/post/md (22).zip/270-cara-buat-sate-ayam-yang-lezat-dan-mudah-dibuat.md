---
description: "Cara buat Sate Ayam yang lezat dan Mudah Dibuat"
title: "Cara buat Sate Ayam yang lezat dan Mudah Dibuat"
slug: 270-cara-buat-sate-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-05-11T06:29:44.324Z
image: https://img-global.cpcdn.com/recipes/588057aaa56ec915/680x482cq70/sate-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/588057aaa56ec915/680x482cq70/sate-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/588057aaa56ec915/680x482cq70/sate-ayam-foto-resep-utama.jpg
author: Fred Cross
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "200 gr paha ayam fillet potong dadu"
- "1/2 sdt bawang merah halus"
- "1/2 sdt bawang putih halus"
- "1/2 sdt gula"
- "1/4 sdt garam"
- "1/2 sdt merica opsional"
- "1/2 sdm santan kental"
- "1/2 sdt kecap manis"
- " Bumbu Kacang  "
- "40 gr kacang tanah kupas"
- "100 ml air"
- "1 siung bawang putih iris"
- "1 siung bawang merah iris"
- "1/2 sdt garam"
- "1 sdm gula merahgula palem"
- "1 sdm nasi"
- "10 ml minyak"
- "1 sdt kecap manis"
recipeinstructions:
- "Campurkan ayam dengan bumbu marinasi lalu diamkan minimal 1-2 jam atau simpan di dalam kulkas semalaman."
- "Tusukkan ayam dengan tusuk sate masing-masing 4-5 potong atau sesuai selera."
- "Panggang sate di atas grill pan sampai kecokelatan dan matang."
- "Bumbu kacang: tumis kacang tanah dengan minyak sampai setengah matang. Masukkan bawang merah dan bawang putih lalu tumis sampai kecokelatan dengan api kecil."
- "Blender tumisan dengan ditambahkan air, garam, gula merah, nasi, dan kecap sampai halus."
- "Masak lagi bumbu sampai mengental"
- "Sate ayam siap disajikan bersama dengan bumbu kacang."
categories:
- Resep
tags:
- sate
- ayam

katakunci: sate ayam 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dinner

---


![Sate Ayam](https://img-global.cpcdn.com/recipes/588057aaa56ec915/680x482cq70/sate-ayam-foto-resep-utama.jpg)

Jika kamu seorang wanita, menyuguhkan santapan lezat untuk orang tercinta merupakan suatu hal yang menggembirakan untuk anda sendiri. Tugas seorang ibu bukan sekadar mengurus rumah saja, namun kamu juga harus memastikan keperluan gizi tercukupi dan santapan yang dimakan anak-anak wajib menggugah selera.

Di era  saat ini, kalian memang dapat mengorder santapan instan tanpa harus repot membuatnya dulu. Namun ada juga lho orang yang selalu ingin menyajikan yang terenak untuk orang tercintanya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan makanan kesukaan orang tercinta. 



Apakah anda merupakan salah satu penikmat sate ayam?. Asal kamu tahu, sate ayam adalah hidangan khas di Nusantara yang kini digemari oleh orang-orang di hampir setiap tempat di Nusantara. Kamu bisa memasak sate ayam sendiri di rumahmu dan pasti jadi makanan kesenanganmu di hari libur.

Anda jangan bingung untuk mendapatkan sate ayam, sebab sate ayam gampang untuk dicari dan kalian pun boleh mengolahnya sendiri di tempatmu. sate ayam boleh dimasak dengan beraneka cara. Sekarang telah banyak sekali resep modern yang membuat sate ayam lebih lezat.

Resep sate ayam juga sangat mudah dibuat, lho. Anda tidak usah repot-repot untuk memesan sate ayam, karena Anda mampu membuatnya sendiri di rumah. Untuk Kalian yang mau menghidangkannya, berikut resep untuk menyajikan sate ayam yang enak yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Sate Ayam:

1. Ambil 200 gr paha ayam fillet, potong dadu
1. Sediakan 1/2 sdt bawang merah halus
1. Ambil 1/2 sdt bawang putih halus
1. Ambil 1/2 sdt gula
1. Gunakan 1/4 sdt garam
1. Ambil 1/2 sdt merica opsional
1. Gunakan 1/2 sdm santan kental
1. Sediakan 1/2 sdt kecap manis
1. Ambil  Bumbu Kacang 🥜 :
1. Gunakan 40 gr kacang tanah kupas
1. Siapkan 100 ml air
1. Siapkan 1 siung bawang putih, iris
1. Siapkan 1 siung bawang merah, iris
1. Ambil 1/2 sdt garam
1. Siapkan 1 sdm gula merah/gula palem
1. Ambil 1 sdm nasi
1. Ambil 10 ml minyak
1. Siapkan 1 sdt kecap manis




<!--inarticleads2-->

##### Langkah-langkah membuat Sate Ayam:

1. Campurkan ayam dengan bumbu marinasi lalu diamkan minimal 1-2 jam atau simpan di dalam kulkas semalaman.
1. Tusukkan ayam dengan tusuk sate masing-masing 4-5 potong atau sesuai - selera.
1. Panggang sate di atas grill pan sampai kecokelatan dan matang.
1. Bumbu kacang: tumis kacang tanah dengan minyak sampai setengah matang. Masukkan bawang merah - dan bawang putih lalu tumis sampai kecokelatan dengan api kecil.
1. Blender tumisan dengan ditambahkan air, garam, gula merah, nasi, dan kecap - sampai halus.
1. Masak lagi bumbu sampai mengental
1. Sate ayam siap disajikan bersama dengan bumbu kacang.




Wah ternyata cara membuat sate ayam yang nikamt sederhana ini enteng sekali ya! Kamu semua mampu membuatnya. Cara Membuat sate ayam Sangat cocok sekali buat kamu yang sedang belajar memasak maupun untuk anda yang telah hebat dalam memasak.

Apakah kamu tertarik mulai mencoba buat resep sate ayam mantab sederhana ini? Kalau anda mau, ayo kamu segera menyiapkan peralatan dan bahan-bahannya, setelah itu bikin deh Resep sate ayam yang nikmat dan simple ini. Sangat mudah kan. 

Maka dari itu, ketimbang anda diam saja, hayo kita langsung saja sajikan resep sate ayam ini. Dijamin anda tak akan nyesel bikin resep sate ayam nikmat tidak rumit ini! Selamat berkreasi dengan resep sate ayam mantab simple ini di rumah kalian masing-masing,ya!.

