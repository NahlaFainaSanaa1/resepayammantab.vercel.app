---
description: "Cara membuat Pepes Ayam Pedas Sederhana dan Mudah Dibuat"
title: "Cara membuat Pepes Ayam Pedas Sederhana dan Mudah Dibuat"
slug: 438-cara-membuat-pepes-ayam-pedas-sederhana-dan-mudah-dibuat
date: 2021-06-26T10:56:08.494Z
image: https://img-global.cpcdn.com/recipes/5aa4696fe1d726dd/680x482cq70/pepes-ayam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5aa4696fe1d726dd/680x482cq70/pepes-ayam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5aa4696fe1d726dd/680x482cq70/pepes-ayam-pedas-foto-resep-utama.jpg
author: Ray Massey
ratingvalue: 4.2
reviewcount: 7
recipeingredient:
- "500 gr ayam"
- "1/2 buah jeruk nipis"
- "3 sdm santan kental"
- "8 lembar daun salam"
- "4 lembar daun jeruk sobek"
- "2 buah tomat potong kecil"
- "20 buah cabe rawit merah utuh"
- " Bumbu Halus"
- "8 siung bawang merah"
- "6 siung bawang putih"
- "10 buah cabe merah keriting"
- "8 buah cabe rawit merah"
- "1 ruas jahe"
- "1 ruas kunyit bakar"
- "6 buah kemiri sangrai"
- "1 batang serai"
recipeinstructions:
- "Potong kecil&#34; ayam lalu lumuri dengan jeruk nipis, diamkan selama 15 menit lalu cuci bersih lagi"
- "Panaskan sedikit minyak lalu tumis bumbu halus hingga harum, setelah itu masukkan ayam, daun salam dan santan, aduk&#34; hingga ayam berubah warna, angkat"
- "Siapkan 2 lembar daun pisang, lalu masukkan 2-3 potong ayam bersama bumbu, daun salam, cabe rawit dan tomat potong, kemudian bungkus dan semat tusuk gigi"
- "Panaskan kukusan, lalu kukus pepes selama 20 menit, kemudian angkat dan panggang hingga daun kering"
categories:
- Resep
tags:
- pepes
- ayam
- pedas

katakunci: pepes ayam pedas 
nutrition: 214 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Pepes Ayam Pedas](https://img-global.cpcdn.com/recipes/5aa4696fe1d726dd/680x482cq70/pepes-ayam-pedas-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, mempersiapkan panganan menggugah selera bagi keluarga tercinta adalah hal yang sangat menyenangkan bagi kamu sendiri. Tanggung jawab seorang  wanita bukan cuma mengatur rumah saja, tapi kamu pun harus menyediakan kebutuhan nutrisi tercukupi dan masakan yang disantap keluarga tercinta harus enak.

Di masa  saat ini, kamu memang dapat memesan hidangan praktis tanpa harus susah membuatnya lebih dulu. Tapi banyak juga lho mereka yang memang ingin menyajikan yang terlezat untuk orang yang dicintainya. Sebab, memasak yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan orang tercinta. 



Apakah anda salah satu penggemar pepes ayam pedas?. Asal kamu tahu, pepes ayam pedas merupakan hidangan khas di Nusantara yang kini disenangi oleh setiap orang di berbagai wilayah di Indonesia. Kalian dapat menyajikan pepes ayam pedas sendiri di rumahmu dan boleh jadi hidangan favorit di hari liburmu.

Kalian tak perlu bingung untuk mendapatkan pepes ayam pedas, lantaran pepes ayam pedas mudah untuk didapatkan dan anda pun dapat menghidangkannya sendiri di tempatmu. pepes ayam pedas boleh dibuat memalui beragam cara. Kini sudah banyak resep modern yang membuat pepes ayam pedas semakin lebih enak.

Resep pepes ayam pedas juga mudah sekali dibikin, lho. Kamu tidak perlu ribet-ribet untuk membeli pepes ayam pedas, sebab Anda mampu menyajikan di rumah sendiri. Untuk Kalian yang akan menyajikannya, inilah resep untuk menyajikan pepes ayam pedas yang mantab yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Pepes Ayam Pedas:

1. Gunakan 500 gr ayam
1. Siapkan 1/2 buah jeruk nipis
1. Siapkan 3 sdm santan kental
1. Gunakan 8 lembar daun salam
1. Siapkan 4 lembar daun jeruk sobek&#34;
1. Ambil 2 buah tomat potong kecil&#34;
1. Sediakan 20 buah cabe rawit merah utuh
1. Ambil  Bumbu Halus
1. Gunakan 8 siung bawang merah
1. Sediakan 6 siung bawang putih
1. Sediakan 10 buah cabe merah keriting
1. Gunakan 8 buah cabe rawit merah
1. Ambil 1 ruas jahe
1. Ambil 1 ruas kunyit bakar
1. Siapkan 6 buah kemiri sangrai
1. Ambil 1 batang serai




<!--inarticleads2-->

##### Cara membuat Pepes Ayam Pedas:

1. Potong kecil&#34; ayam lalu lumuri dengan jeruk nipis, diamkan selama 15 menit lalu cuci bersih lagi
1. Panaskan sedikit minyak lalu tumis bumbu halus hingga harum, setelah itu masukkan ayam, daun salam dan santan, aduk&#34; hingga ayam berubah warna, angkat
1. Siapkan 2 lembar daun pisang, lalu masukkan 2-3 potong ayam bersama bumbu, daun salam, cabe rawit dan tomat potong, kemudian bungkus dan semat tusuk gigi
1. Panaskan kukusan, lalu kukus pepes selama 20 menit, kemudian angkat dan panggang hingga daun kering




Ternyata cara buat pepes ayam pedas yang enak tidak rumit ini gampang banget ya! Kamu semua bisa memasaknya. Resep pepes ayam pedas Sesuai banget untuk kamu yang sedang belajar memasak ataupun untuk anda yang telah ahli memasak.

Tertarik untuk mencoba membuat resep pepes ayam pedas nikmat tidak ribet ini? Kalau kamu mau, ayo kalian segera siapkan alat dan bahan-bahannya, lantas buat deh Resep pepes ayam pedas yang lezat dan tidak ribet ini. Benar-benar gampang kan. 

Oleh karena itu, ketimbang anda diam saja, ayo kita langsung saja hidangkan resep pepes ayam pedas ini. Dijamin kamu tiidak akan nyesel sudah bikin resep pepes ayam pedas nikmat simple ini! Selamat berkreasi dengan resep pepes ayam pedas nikmat sederhana ini di rumah kalian sendiri,ya!.

