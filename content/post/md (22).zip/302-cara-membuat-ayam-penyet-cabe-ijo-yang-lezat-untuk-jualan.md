---
description: "Cara membuat Ayam Penyet Cabe Ijo yang lezat Untuk Jualan"
title: "Cara membuat Ayam Penyet Cabe Ijo yang lezat Untuk Jualan"
slug: 302-cara-membuat-ayam-penyet-cabe-ijo-yang-lezat-untuk-jualan
date: 2021-05-24T12:14:33.864Z
image: https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg
author: Cynthia Mendoza
ratingvalue: 3.5
reviewcount: 7
recipeingredient:
- "1/2 kg daging ayam"
- "1 batang serai"
- "2 lembar daun jeruk"
- " Bumbu ukep ayam"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt ketumbar"
- "Secukupnya garam"
- "Secukupnya kaldu jamur"
- "Secukupnya air untuk merebus ayam"
- " Bahan sambal ijo"
- "5 cabe hijau besar"
- "20 cabe rawit hijau"
- "2 tomat hijau kecil"
- "3 siung bawang putih"
- "4 siung bawang merah"
- "Secukupnya gula dan garam"
- "Secukupnya minyak goreng"
recipeinstructions:
- "Potong ayam kemudian cuci bersih ditiriskan. Rebus air hingga mendidih lalu masukkan ayam"
- "Siapkan bahan bumbu ukep, masukkan bumbu kedalam rebusan ayam tambahkan daun jeruk, serai garam dan kaldu jamur biarkan mendidih lalu koreksi rasa, masak hingga ayam empuk dan bumbu meresap"
- "Jika ayam sudah matang dan bumbu meresap, angkat dan tiriskan ayam lalu goreng dalam minyak panas hingga kecoklatan kemudian sisihkan"
- "Siapkan bahan untuk sambal ijo, goreng bumbu yg sudah dipotong-potong hingga bumbu matang dan layu"
- "Letakan bumbu di atas cobek tambahkan sedikit gula dan garam kemudian ulek dan koreksi rasa."
- "Letakkan ayam yg sudah digoreng tadi di atas cobek lalu penyet, ayam penyet siap disajikan"
- "Sajikan dengan nasi hangat, selamat sarapan 😅😉"
categories:
- Resep
tags:
- ayam
- penyet
- cabe

katakunci: ayam penyet cabe 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Penyet Cabe Ijo](https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan olahan nikmat buat keluarga tercinta merupakan suatu hal yang sangat menyenangkan bagi kamu sendiri. Tugas seorang ibu bukan cuman menjaga rumah saja, tetapi kamu pun harus menyediakan kebutuhan nutrisi tercukupi dan juga hidangan yang dikonsumsi orang tercinta mesti sedap.

Di masa  sekarang, kamu sebenarnya bisa membeli santapan siap saji meski tanpa harus capek membuatnya dulu. Tetapi ada juga lho orang yang memang mau memberikan yang terenak bagi orang tercintanya. Sebab, menyajikan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai masakan kesukaan orang tercinta. 



Mungkinkah anda merupakan salah satu penyuka ayam penyet cabe ijo?. Asal kamu tahu, ayam penyet cabe ijo merupakan hidangan khas di Indonesia yang saat ini disukai oleh orang-orang di hampir setiap wilayah di Nusantara. Kamu bisa menghidangkan ayam penyet cabe ijo sendiri di rumahmu dan dapat dijadikan hidangan kesukaanmu di hari libur.

Kamu tidak perlu bingung untuk menyantap ayam penyet cabe ijo, sebab ayam penyet cabe ijo tidak sulit untuk didapatkan dan juga kalian pun dapat mengolahnya sendiri di tempatmu. ayam penyet cabe ijo boleh dibuat dengan beragam cara. Kini ada banyak sekali cara kekinian yang membuat ayam penyet cabe ijo semakin mantap.

Resep ayam penyet cabe ijo pun mudah untuk dibikin, lho. Kalian tidak usah capek-capek untuk memesan ayam penyet cabe ijo, tetapi Anda mampu menyajikan di rumahmu. Untuk Kita yang akan mencobanya, berikut ini cara untuk membuat ayam penyet cabe ijo yang lezat yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Penyet Cabe Ijo:

1. Sediakan 1/2 kg daging ayam
1. Gunakan 1 batang serai
1. Gunakan 2 lembar daun jeruk
1. Siapkan  Bumbu ukep ayam
1. Gunakan 4 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Gunakan 1 ruas jahe
1. Ambil 1 ruas kunyit
1. Ambil 1 sdt ketumbar
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya kaldu jamur
1. Siapkan Secukupnya air untuk merebus ayam
1. Siapkan  Bahan sambal ijo
1. Sediakan 5 cabe hijau besar
1. Ambil 20 cabe rawit hijau
1. Ambil 2 tomat hijau kecil
1. Ambil 3 siung bawang putih
1. Siapkan 4 siung bawang merah
1. Gunakan Secukupnya gula dan garam
1. Ambil Secukupnya minyak goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Penyet Cabe Ijo:

1. Potong ayam kemudian cuci bersih ditiriskan. Rebus air hingga mendidih lalu masukkan ayam
1. Siapkan bahan bumbu ukep, masukkan bumbu kedalam rebusan ayam tambahkan daun jeruk, serai garam dan kaldu jamur biarkan mendidih lalu koreksi rasa, masak hingga ayam empuk dan bumbu meresap
1. Jika ayam sudah matang dan bumbu meresap, angkat dan tiriskan ayam lalu goreng dalam minyak panas hingga kecoklatan kemudian sisihkan
1. Siapkan bahan untuk sambal ijo, goreng bumbu yg sudah dipotong-potong hingga bumbu matang dan layu
1. Letakan bumbu di atas cobek tambahkan sedikit gula dan garam kemudian ulek dan koreksi rasa.
1. Letakkan ayam yg sudah digoreng tadi di atas cobek lalu penyet, ayam penyet siap disajikan
1. Sajikan dengan nasi hangat, selamat sarapan 😅😉




Wah ternyata cara membuat ayam penyet cabe ijo yang nikamt sederhana ini enteng banget ya! Kalian semua dapat memasaknya. Resep ayam penyet cabe ijo Cocok banget untuk kalian yang baru mau belajar memasak atau juga bagi anda yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba buat resep ayam penyet cabe ijo lezat tidak rumit ini? Kalau tertarik, ayo kamu segera siapkan alat-alat dan bahannya, setelah itu bikin deh Resep ayam penyet cabe ijo yang nikmat dan tidak rumit ini. Sangat gampang kan. 

Jadi, ketimbang anda berfikir lama-lama, maka kita langsung saja buat resep ayam penyet cabe ijo ini. Dijamin kamu gak akan nyesel sudah membuat resep ayam penyet cabe ijo lezat sederhana ini! Selamat mencoba dengan resep ayam penyet cabe ijo lezat tidak rumit ini di tempat tinggal kalian sendiri,oke!.

