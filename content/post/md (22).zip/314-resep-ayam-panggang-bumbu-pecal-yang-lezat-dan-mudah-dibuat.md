---
description: "Resep Ayam Panggang Bumbu Pecal yang lezat dan Mudah Dibuat"
title: "Resep Ayam Panggang Bumbu Pecal yang lezat dan Mudah Dibuat"
slug: 314-resep-ayam-panggang-bumbu-pecal-yang-lezat-dan-mudah-dibuat
date: 2021-06-03T14:29:21.340Z
image: https://img-global.cpcdn.com/recipes/e2c6278d65646a32/680x482cq70/ayam-panggang-bumbu-pecal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e2c6278d65646a32/680x482cq70/ayam-panggang-bumbu-pecal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e2c6278d65646a32/680x482cq70/ayam-panggang-bumbu-pecal-foto-resep-utama.jpg
author: Carl Paul
ratingvalue: 3.1
reviewcount: 5
recipeingredient:
- "1 ekor ayam"
- "150 gram bumbu pecal"
- "1/2 ibu jari jahe cincang"
- "2 siung bawang putih cincang"
- "1/2 sendok teh garam"
- "1/2 sendok teh merica bubuk"
- "1 sendok makan cabai bubuk"
- "1 sendok makan saus tomat"
recipeinstructions:
- "Siapkan ayam potong- potong sesuai selera, cuci bersih dan taruh dalam loyang. Kemudian siapkan bumbu pecal larutkan dengan sedikit air, siapkan juga jahe dan bawang putih cincang."
- "Kemudian taruh bumbu pecal, jahe dan bawang putih cincang kedalam loyang yang berisi ayam, tambahkan garam, merica bubuk, cabai bubuk dan saus tomat. kemudian aduk rata. Dan diamkan 20 menit."
- "Kemudian panggang dalam oven selama 1 jam dengan suhu 150, atau sampai matang. Setelah ayam panggang matang keluarkan dari dalam oven taruh dalam wadah dan sajikan."
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 152 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Panggang Bumbu Pecal](https://img-global.cpcdn.com/recipes/e2c6278d65646a32/680x482cq70/ayam-panggang-bumbu-pecal-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, mempersiapkan hidangan nikmat buat orang tercinta merupakan suatu hal yang memuaskan bagi kamu sendiri. Peran seorang ibu bukan cuman menangani rumah saja, tetapi anda pun harus menyediakan kebutuhan nutrisi tercukupi dan panganan yang dimakan anak-anak harus nikmat.

Di era  sekarang, anda memang mampu mengorder panganan praktis meski tidak harus repot mengolahnya lebih dulu. Tetapi banyak juga lho orang yang memang mau memberikan hidangan yang terbaik untuk keluarganya. Lantaran, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga tercinta. 



Mungkinkah kamu seorang penyuka ayam panggang bumbu pecal?. Asal kamu tahu, ayam panggang bumbu pecal adalah sajian khas di Nusantara yang saat ini digemari oleh banyak orang di berbagai daerah di Nusantara. Anda bisa memasak ayam panggang bumbu pecal olahan sendiri di rumah dan boleh jadi santapan favoritmu di hari libur.

Anda tidak perlu bingung untuk memakan ayam panggang bumbu pecal, lantaran ayam panggang bumbu pecal tidak sulit untuk ditemukan dan juga kalian pun bisa menghidangkannya sendiri di tempatmu. ayam panggang bumbu pecal boleh dimasak dengan berbagai cara. Kini pun telah banyak sekali resep modern yang menjadikan ayam panggang bumbu pecal semakin nikmat.

Resep ayam panggang bumbu pecal juga mudah dihidangkan, lho. Kalian tidak usah ribet-ribet untuk membeli ayam panggang bumbu pecal, sebab Anda dapat membuatnya sendiri di rumah. Bagi Kamu yang akan mencobanya, dibawah ini merupakan resep menyajikan ayam panggang bumbu pecal yang enak yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Panggang Bumbu Pecal:

1. Ambil 1 ekor ayam
1. Sediakan 150 gram bumbu pecal
1. Sediakan 1/2 ibu jari jahe cincang
1. Ambil 2 siung bawang putih cincang
1. Gunakan 1/2 sendok teh garam
1. Ambil 1/2 sendok teh merica bubuk
1. Sediakan 1 sendok makan cabai bubuk
1. Ambil 1 sendok makan saus tomat




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Panggang Bumbu Pecal:

1. Siapkan ayam potong- potong sesuai selera, cuci bersih dan taruh dalam loyang. Kemudian siapkan bumbu pecal larutkan dengan sedikit air, siapkan juga jahe dan bawang putih cincang.
1. Kemudian taruh bumbu pecal, jahe dan bawang putih cincang kedalam loyang yang berisi ayam, tambahkan garam, merica bubuk, cabai bubuk dan saus tomat. kemudian aduk rata. Dan diamkan 20 menit.
1. Kemudian panggang dalam oven selama 1 jam dengan suhu 150, atau sampai matang. Setelah ayam panggang matang keluarkan dari dalam oven taruh dalam wadah dan sajikan.




Wah ternyata resep ayam panggang bumbu pecal yang mantab tidak ribet ini gampang sekali ya! Kita semua dapat membuatnya. Cara Membuat ayam panggang bumbu pecal Cocok banget untuk kita yang sedang belajar memasak ataupun bagi kamu yang telah jago dalam memasak.

Apakah kamu ingin mencoba bikin resep ayam panggang bumbu pecal lezat simple ini? Kalau anda ingin, mending kamu segera buruan menyiapkan alat dan bahannya, maka bikin deh Resep ayam panggang bumbu pecal yang nikmat dan sederhana ini. Sungguh taidak sulit kan. 

Oleh karena itu, daripada kamu berfikir lama-lama, hayo kita langsung sajikan resep ayam panggang bumbu pecal ini. Pasti kalian tiidak akan menyesal sudah bikin resep ayam panggang bumbu pecal nikmat tidak rumit ini! Selamat mencoba dengan resep ayam panggang bumbu pecal mantab simple ini di rumah kalian sendiri,oke!.

