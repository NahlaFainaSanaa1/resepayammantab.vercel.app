---
description: "Bahan-bahan Ayam asam manis Sederhana Untuk Jualan"
title: "Bahan-bahan Ayam asam manis Sederhana Untuk Jualan"
slug: 324-bahan-bahan-ayam-asam-manis-sederhana-untuk-jualan
date: 2021-02-09T06:41:38.410Z
image: https://img-global.cpcdn.com/recipes/0657f961a5bcdaf9/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0657f961a5bcdaf9/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0657f961a5bcdaf9/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Alexander Sanchez
ratingvalue: 3.6
reviewcount: 11
recipeingredient:
- "1/2 kg ayam"
- "1 bungkus tepung sajiku"
- "Secukupnya saos tiram"
- "Secukupnya kecap manis"
- "Secukupnya Saos tomatsaos pedas"
- "secukupnya Minyak goreng"
- "secukupnya Garam"
- "secukupnya Gula pasir"
- "secukupnya Penyedap rasa"
- "1/2 bungkus Ladaku"
- " Bahan diiris"
- "1 buah bawang Bombay"
- "4 siung bawang putih"
- "Secukupnya daun bawang"
recipeinstructions:
- "Bersih kan ayam, lalu potong sesuai selera. Larutkan tepung sajiku dengan 5 sendok air biasa, lalu masukan ayam kedalam larutan tepung tadi, balur hingga rata. Lalu diamkan sebentar."
- "Panaskan minyak, lalu ayam yang sudah dibalur kedalam tepung basah di balurkan ke tepung sajiku yang kering. Goreng ayam dengan api sedang, goreng hingga berubah warna menjadi kecoklatan Angkat sisihkan."
- "Cuci semua bahan irisan, lalu iris bawang Bombay dan daun bawang. Bawang putih di geprek lalu dicincang halus."
- "Masukan sedikit minyak untuk menumis, masukan bawang bombay, lalu bawang putih cincang, tumis hingga layu lalu tambahkan saos tiram, soas pedas, kecap manis. Aduk dan tambahkan sesuai selera air, klo saya sekitar 250 ml air biasa. Aduk hingga mendidih koreksi rasa, tambahkan sedikit garam, ladaku, gula dan penyedap rasa. Kalau sudah sesuai selera masukan daun bawang diamkan sebentar biar daun bawang agak layu lalu angkat dan sajikan."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam asam manis](https://img-global.cpcdn.com/recipes/0657f961a5bcdaf9/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan olahan nikmat bagi keluarga adalah suatu hal yang menggembirakan untuk kamu sendiri. Tanggung jawab seorang  wanita Tidak cuma mengatur rumah saja, namun kamu pun harus memastikan kebutuhan gizi tercukupi dan juga olahan yang dimakan keluarga tercinta mesti mantab.

Di zaman  saat ini, anda memang mampu membeli panganan yang sudah jadi meski tidak harus repot membuatnya dulu. Tetapi ada juga mereka yang selalu mau memberikan hidangan yang terenak bagi orang tercintanya. Sebab, menyajikan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai kesukaan keluarga tercinta. 



Apakah kamu seorang penikmat ayam asam manis?. Asal kamu tahu, ayam asam manis merupakan hidangan khas di Nusantara yang saat ini digemari oleh orang-orang di berbagai tempat di Indonesia. Kamu bisa memasak ayam asam manis buatan sendiri di rumahmu dan boleh dijadikan hidangan favoritmu di hari libur.

Kamu jangan bingung jika kamu ingin menyantap ayam asam manis, sebab ayam asam manis sangat mudah untuk dicari dan juga kalian pun dapat membuatnya sendiri di rumah. ayam asam manis bisa dimasak memalui beraneka cara. Sekarang telah banyak banget cara kekinian yang menjadikan ayam asam manis semakin mantap.

Resep ayam asam manis juga sangat mudah untuk dibuat, lho. Kalian tidak usah repot-repot untuk memesan ayam asam manis, lantaran Kamu bisa menghidangkan ditempatmu. Bagi Anda yang akan mencobanya, di bawah ini adalah cara untuk menyajikan ayam asam manis yang mantab yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam asam manis:

1. Sediakan 1/2 kg ayam
1. Siapkan 1 bungkus tepung sajiku
1. Siapkan Secukupnya saos tiram
1. Siapkan Secukupnya kecap manis
1. Sediakan Secukupnya Saos tomat/saos pedas
1. Siapkan secukupnya Minyak goreng
1. Ambil secukupnya Garam
1. Ambil secukupnya Gula pasir
1. Gunakan secukupnya Penyedap rasa
1. Sediakan 1/2 bungkus Ladaku
1. Siapkan  Bahan diiris
1. Ambil 1 buah bawang Bombay
1. Siapkan 4 siung bawang putih
1. Ambil Secukupnya daun bawang




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam asam manis:

1. Bersih kan ayam, lalu potong sesuai selera. Larutkan tepung sajiku dengan 5 sendok air biasa, lalu masukan ayam kedalam larutan tepung tadi, balur hingga rata. Lalu diamkan sebentar.
1. Panaskan minyak, lalu ayam yang sudah dibalur kedalam tepung basah di balurkan ke tepung sajiku yang kering. Goreng ayam dengan api sedang, goreng hingga berubah warna menjadi kecoklatan Angkat sisihkan.
1. Cuci semua bahan irisan, lalu iris bawang Bombay dan daun bawang. Bawang putih di geprek lalu dicincang halus.
1. Masukan sedikit minyak untuk menumis, masukan bawang bombay, lalu bawang putih cincang, tumis hingga layu lalu tambahkan saos tiram, soas pedas, kecap manis. Aduk dan tambahkan sesuai selera air, klo saya sekitar 250 ml air biasa. Aduk hingga mendidih koreksi rasa, tambahkan sedikit garam, ladaku, gula dan penyedap rasa. Kalau sudah sesuai selera masukan daun bawang diamkan sebentar biar daun bawang agak layu lalu angkat dan sajikan.




Wah ternyata resep ayam asam manis yang lezat sederhana ini gampang sekali ya! Anda Semua bisa mencobanya. Resep ayam asam manis Sangat sesuai sekali buat kita yang baru belajar memasak ataupun untuk anda yang telah jago memasak.

Apakah kamu ingin mencoba membuat resep ayam asam manis lezat sederhana ini? Kalau kalian mau, ayo kalian segera siapkan alat dan bahannya, lantas buat deh Resep ayam asam manis yang mantab dan tidak rumit ini. Benar-benar gampang kan. 

Maka, daripada kalian diam saja, maka kita langsung bikin resep ayam asam manis ini. Pasti kalian tak akan menyesal sudah buat resep ayam asam manis lezat tidak ribet ini! Selamat berkreasi dengan resep ayam asam manis nikmat tidak ribet ini di tempat tinggal masing-masing,oke!.

