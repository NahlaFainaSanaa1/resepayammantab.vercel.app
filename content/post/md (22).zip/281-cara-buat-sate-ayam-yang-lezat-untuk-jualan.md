---
description: "Cara buat Sate Ayam yang lezat Untuk Jualan"
title: "Cara buat Sate Ayam yang lezat Untuk Jualan"
slug: 281-cara-buat-sate-ayam-yang-lezat-untuk-jualan
date: 2021-01-23T04:33:52.386Z
image: https://img-global.cpcdn.com/recipes/768e51f151560b19/680x482cq70/sate-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/768e51f151560b19/680x482cq70/sate-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/768e51f151560b19/680x482cq70/sate-ayam-foto-resep-utama.jpg
author: Chase Nichols
ratingvalue: 4.3
reviewcount: 3
recipeingredient:
- " Sate ayam"
- "1 ekor ayam ambil dagingnya saja dan potong dadu"
- "3 sdm kecap manis"
- "2 sdm mentega"
- "1 batang sereh memarkan lalu iris"
- "4 siung bawang merah iris"
- "1/4 sdt garam halus"
- "1/2 sdt gula pasir"
- "Sedikit lada saya skip"
- " Kuah kacang"
- "200 gr kacang tanah"
- "5 siung bawang putih"
- "5 siung bawang merah"
- "3 lembar daun jeruk"
- "2 butir kemiri"
- "5 buah cabe merah keriting"
- "2 buah limau kasturi"
- "1/2 sdt garam halus"
- "500 ml air"
- " Minyak goreng"
recipeinstructions:
- "Cuci daging ayam, baluri dengan sedikit cuka untuk menghilangkan bau amis, bilas"
- "Campurkan semua bahan kecap, mentega, bawang merah iris, sereh, garam, gula dan lada. Campur rata."
- "Masukkan daging ayam ke dalam bahan kecap, diamkan 30 menit agar bumbu meresap."
- "Tusuk ayam dengan tusukan sate, lalu bakar sampai matang, sisihkan"
- "Goreng kacang, bawang putih, bawang merah, cabe, kemiri sampai matang. Angkat, tunggu dingin, lalu blender sampai kehalusan yang diinginkan. Tambahkan sedikit air agar mudah blendernya."
- "Tumis kacang di atas api kecil. Tambahkan air, daun jeruk, garam, kecap. Masak sampai mengeluarkan minyak dan kental. Beri air perasan limau. Angkat"
- "Sajikan sate dengan kuah kacangnya. Tambahkan ketupat atau lontong sesuai selera. Taburi bawang goreng agar lebih nikmat."
- "Selamat menikmati"
categories:
- Resep
tags:
- sate
- ayam

katakunci: sate ayam 
nutrition: 152 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dinner

---


![Sate Ayam](https://img-global.cpcdn.com/recipes/768e51f151560b19/680x482cq70/sate-ayam-foto-resep-utama.jpg)

Sebagai seorang istri, menyediakan hidangan sedap buat orang tercinta merupakan hal yang sangat menyenangkan untuk anda sendiri. Peran seorang istri bukan sekadar mengerjakan pekerjaan rumah saja, tetapi kamu juga harus memastikan kebutuhan gizi terpenuhi dan santapan yang disantap anak-anak harus lezat.

Di waktu  saat ini, anda memang bisa memesan masakan siap saji tanpa harus repot memasaknya dulu. Namun ada juga lho orang yang selalu mau memberikan hidangan yang terlezat bagi orang yang dicintainya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan seorang penyuka sate ayam?. Asal kamu tahu, sate ayam adalah makanan khas di Indonesia yang saat ini disukai oleh banyak orang di hampir setiap daerah di Indonesia. Anda bisa membuat sate ayam sendiri di rumah dan boleh dijadikan makanan favoritmu di akhir pekanmu.

Kamu tak perlu bingung jika kamu ingin menyantap sate ayam, sebab sate ayam tidak sukar untuk ditemukan dan kamu pun bisa memasaknya sendiri di tempatmu. sate ayam boleh dimasak dengan beraneka cara. Kini pun ada banyak banget resep kekinian yang menjadikan sate ayam lebih mantap.

Resep sate ayam juga mudah dihidangkan, lho. Anda tidak perlu capek-capek untuk memesan sate ayam, lantaran Kamu dapat menyajikan di rumahmu. Untuk Kamu yang akan menyajikannya, berikut ini cara untuk membuat sate ayam yang nikamat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Sate Ayam:

1. Gunakan  Sate ayam
1. Gunakan 1 ekor ayam, ambil dagingnya saja dan potong dadu
1. Sediakan 3 sdm kecap manis
1. Siapkan 2 sdm mentega
1. Ambil 1 batang sereh, memarkan, lalu iris
1. Gunakan 4 siung bawang merah, iris
1. Siapkan 1/4 sdt garam halus
1. Siapkan 1/2 sdt gula pasir
1. Siapkan Sedikit lada (saya skip)
1. Siapkan  Kuah kacang
1. Gunakan 200 gr kacang tanah
1. Sediakan 5 siung bawang putih
1. Gunakan 5 siung bawang merah
1. Ambil 3 lembar daun jeruk
1. Siapkan 2 butir kemiri
1. Siapkan 5 buah cabe merah keriting
1. Sediakan 2 buah limau kasturi
1. Gunakan 1/2 sdt garam halus
1. Ambil 500 ml air
1. Ambil  Minyak goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Sate Ayam:

1. Cuci daging ayam, baluri dengan sedikit cuka untuk menghilangkan bau amis, bilas
1. Campurkan semua bahan kecap, mentega, bawang merah iris, sereh, garam, gula dan lada. Campur rata.
1. Masukkan daging ayam ke dalam bahan kecap, diamkan 30 menit agar bumbu meresap.
1. Tusuk ayam dengan tusukan sate, lalu bakar sampai matang, sisihkan
1. Goreng kacang, bawang putih, bawang merah, cabe, kemiri sampai matang. Angkat, tunggu dingin, lalu blender sampai kehalusan yang diinginkan. Tambahkan sedikit air agar mudah blendernya.
1. Tumis kacang di atas api kecil. Tambahkan air, daun jeruk, garam, kecap. Masak sampai mengeluarkan minyak dan kental. Beri air perasan limau. Angkat
1. Sajikan sate dengan kuah kacangnya. Tambahkan ketupat atau lontong sesuai selera. Taburi bawang goreng agar lebih nikmat.
1. Selamat menikmati




Wah ternyata cara membuat sate ayam yang mantab sederhana ini enteng banget ya! Semua orang mampu membuatnya. Resep sate ayam Cocok banget untuk kalian yang baru belajar memasak maupun bagi anda yang sudah jago dalam memasak.

Tertarik untuk mulai mencoba membuat resep sate ayam lezat simple ini? Kalau kalian tertarik, mending kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, kemudian bikin deh Resep sate ayam yang enak dan tidak rumit ini. Sangat gampang kan. 

Maka, daripada kalian berfikir lama-lama, ayo kita langsung saja bikin resep sate ayam ini. Pasti kamu gak akan menyesal bikin resep sate ayam mantab tidak rumit ini! Selamat berkreasi dengan resep sate ayam mantab tidak rumit ini di rumah kalian sendiri,ya!.

