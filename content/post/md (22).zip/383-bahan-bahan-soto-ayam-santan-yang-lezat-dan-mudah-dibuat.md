---
description: "Bahan-bahan Soto Ayam Santan yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Soto Ayam Santan yang lezat dan Mudah Dibuat"
slug: 383-bahan-bahan-soto-ayam-santan-yang-lezat-dan-mudah-dibuat
date: 2021-05-22T03:48:20.474Z
image: https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Ada Boyd
ratingvalue: 4.1
reviewcount: 13
recipeingredient:
- "1/4 kg Dada Ayam"
- "1500 ml Air"
- "1 btg Serai memarkan"
- "2 cm Lengkuas memarkan"
- "3 lbr Daun Jeruk"
- "1 bks Santan Instan"
- "1/4 sdt Lada bubuk"
- "Secukupnya Bawang Goreng"
- "Secukupnya Garam Gula dan Kaldu Bubuk"
- " Cengkeh Kapulaga Bunga Lawang untuk wewangian bisa di skip"
- " bumbu halus"
- "7 bh Bawang merah"
- "5 bh Bawang Putih"
- "4 btr Kemiri"
- "2 cm Kunyit"
- "2 cm Jahe"
- "Secukupnya Minyak Goreng"
recipeinstructions:
- "Cuci bersih semua bahan"
- "Rebus ayam hingga empuk dan keluar kaldunya"
- "Tumis bumbu halus hingga wangi. Tambahkan serai, lengkuas, daun jeruk dan lada bubuk, aduk hingga rata kemudian sisihkan"
- "Masukkan bumbu yang sudah ditumis kedalam rebusan ayam, kemudian tambahkan garam, gula dan kaldu bubuk. Aduk hingga rata"
- "Koreksi rasa dan masak sekitar 15 menit dengan api kecil hingga bumbu meresap"
- "Angkat daging ayam, kemudian masukkan santan, aduk hingga rata dan tambahkan cengkeh, kapulaga dan bunga lawang (bisa di skip)"
- "Goreng ayam yang sudah di tiriskan, jangan terlalu kering, kemudian di suwir suwir"
- "Taburkan bawang goreng kedalam kuah soto yang telah matang. Soto ayam santan, siap dihidangkan!"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Lunch

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Andai kamu seorang wanita, menyediakan santapan menggugah selera kepada keluarga adalah hal yang sangat menyenangkan bagi kamu sendiri. Tugas seorang ibu Tidak sekedar menangani rumah saja, tapi kamu pun wajib memastikan kebutuhan gizi terpenuhi dan masakan yang dimakan anak-anak mesti enak.

Di zaman  saat ini, kita memang mampu mengorder santapan siap saji meski tanpa harus ribet membuatnya terlebih dahulu. Namun banyak juga mereka yang selalu mau memberikan yang terbaik untuk keluarganya. Sebab, memasak sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penyuka soto ayam santan?. Asal kamu tahu, soto ayam santan merupakan makanan khas di Indonesia yang saat ini disenangi oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Kalian dapat menghidangkan soto ayam santan hasil sendiri di rumah dan boleh dijadikan santapan favorit di hari libur.

Kita tidak usah bingung untuk menyantap soto ayam santan, lantaran soto ayam santan gampang untuk dicari dan kalian pun boleh mengolahnya sendiri di tempatmu. soto ayam santan bisa dibuat dengan bermacam cara. Sekarang sudah banyak sekali cara modern yang membuat soto ayam santan semakin lebih enak.

Resep soto ayam santan juga mudah dibuat, lho. Kita tidak perlu ribet-ribet untuk membeli soto ayam santan, karena Kamu mampu membuatnya di rumah sendiri. Bagi Kita yang akan menyajikannya, dibawah ini merupakan cara menyajikan soto ayam santan yang lezat yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto Ayam Santan:

1. Gunakan 1/4 kg Dada Ayam
1. Siapkan 1500 ml Air
1. Sediakan 1 btg Serai (memarkan)
1. Ambil 2 cm Lengkuas (memarkan)
1. Ambil 3 lbr Daun Jeruk
1. Ambil 1 bks Santan Instan
1. Gunakan 1/4 sdt Lada bubuk
1. Siapkan Secukupnya Bawang Goreng
1. Sediakan Secukupnya Garam, Gula dan Kaldu Bubuk
1. Gunakan  Cengkeh, Kapulaga, Bunga Lawang (untuk wewangian, bisa di skip)
1. Siapkan  bumbu halus
1. Sediakan 7 bh Bawang merah
1. Siapkan 5 bh Bawang Putih
1. Gunakan 4 btr Kemiri
1. Ambil 2 cm Kunyit
1. Siapkan 2 cm Jahe
1. Sediakan Secukupnya Minyak Goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Santan:

1. Cuci bersih semua bahan
1. Rebus ayam hingga empuk dan keluar kaldunya
1. Tumis bumbu halus hingga wangi. Tambahkan serai, lengkuas, daun jeruk dan lada bubuk, aduk hingga rata kemudian sisihkan
1. Masukkan bumbu yang sudah ditumis kedalam rebusan ayam, kemudian tambahkan garam, gula dan kaldu bubuk. Aduk hingga rata
1. Koreksi rasa dan masak sekitar 15 menit dengan api kecil hingga bumbu meresap
1. Angkat daging ayam, kemudian masukkan santan, aduk hingga rata dan tambahkan cengkeh, kapulaga dan bunga lawang (bisa di skip)
1. Goreng ayam yang sudah di tiriskan, jangan terlalu kering, kemudian di suwir suwir
1. Taburkan bawang goreng kedalam kuah soto yang telah matang. - Soto ayam santan, siap dihidangkan!




Wah ternyata cara buat soto ayam santan yang enak sederhana ini gampang sekali ya! Kamu semua dapat menghidangkannya. Cara Membuat soto ayam santan Cocok sekali buat kita yang baru mau belajar memasak maupun untuk anda yang sudah hebat memasak.

Tertarik untuk mencoba membuat resep soto ayam santan lezat tidak ribet ini? Kalau kalian tertarik, yuk kita segera siapin alat-alat dan bahannya, kemudian bikin deh Resep soto ayam santan yang mantab dan tidak rumit ini. Sangat gampang kan. 

Maka, daripada kalian berfikir lama-lama, ayo kita langsung bikin resep soto ayam santan ini. Dijamin kalian gak akan nyesel sudah bikin resep soto ayam santan mantab tidak rumit ini! Selamat berkreasi dengan resep soto ayam santan mantab tidak ribet ini di rumah sendiri,oke!.

