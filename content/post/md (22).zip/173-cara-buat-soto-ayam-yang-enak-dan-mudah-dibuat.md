---
description: "Cara buat Soto ayam yang enak dan Mudah Dibuat"
title: "Cara buat Soto ayam yang enak dan Mudah Dibuat"
slug: 173-cara-buat-soto-ayam-yang-enak-dan-mudah-dibuat
date: 2021-02-16T10:37:35.353Z
image: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Jack Clayton
ratingvalue: 3.9
reviewcount: 14
recipeingredient:
- "1/2 kg ayam"
- " Bumbu halus "
- "5 siung bawang putih"
- "8 siung bawang merah"
- "4 buah kemiri"
- "2 ruas kunyit"
- " Tambahan "
- "2 batang sereh geprek"
- "3 lembar daun salam"
- "6 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "2 batang daun bawang iris"
- "1 batang seledri iris"
- "1 buah tomat iris sesuai selera"
- "1/2 jeruk nipis"
- "2 sdt Garam"
- "1/2 sdt Gula"
- "1 sdt Lada bubuk"
recipeinstructions:
- "Rebus ayam tidak usah lama2, lalu buang airnya. Rebus kembali."
- "Tumis bumbu halus di atas api sedang, jika sudah harum masukan daun salam, daun jeruk, sereh, lengkuas. Tambahkan 1 gelas belimbing air. Aduk sampai air mendidih. Matikan."
- "Jika rebusan ayam sudah mendidih, masukan bumbu yg sudah di tumis tadi. Aduk."
- "Tambahkan garam, lada, gula. Cek rasa. Matikan kompor."
- "Hidangkan soto di mangkuk, jangan lupa di beri irisan daun bawang, daun seledri, tomat dan perasan jeruk agar tambah segar."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 109 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Lunch

---


![Soto ayam](https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyediakan hidangan lezat buat keluarga merupakan hal yang memuaskan bagi kita sendiri. Peran seorang istri bukan sekadar mengurus rumah saja, tapi kamu pun wajib memastikan keperluan nutrisi tercukupi dan panganan yang disantap anak-anak harus sedap.

Di era  saat ini, anda sebenarnya bisa mengorder olahan praktis walaupun tidak harus susah memasaknya dulu. Tetapi banyak juga orang yang memang mau memberikan hidangan yang terbaik bagi keluarganya. Karena, menghidangkan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan kesukaan keluarga. 



Apakah anda merupakan salah satu penyuka soto ayam?. Asal kamu tahu, soto ayam merupakan makanan khas di Nusantara yang kini disenangi oleh orang-orang di hampir setiap tempat di Indonesia. Kalian bisa membuat soto ayam sendiri di rumahmu dan dapat dijadikan makanan kesenanganmu di hari liburmu.

Kita tak perlu bingung jika kamu ingin menyantap soto ayam, sebab soto ayam sangat mudah untuk didapatkan dan juga kita pun boleh mengolahnya sendiri di rumah. soto ayam bisa dimasak memalui beragam cara. Sekarang telah banyak resep modern yang menjadikan soto ayam semakin lebih mantap.

Resep soto ayam juga mudah untuk dibuat, lho. Kamu jangan ribet-ribet untuk memesan soto ayam, karena Kalian bisa menyiapkan ditempatmu. Untuk Kamu yang hendak menyajikannya, dibawah ini merupakan cara untuk menyajikan soto ayam yang mantab yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Soto ayam:

1. Ambil 1/2 kg ayam
1. Ambil  Bumbu halus :
1. Sediakan 5 siung bawang putih
1. Sediakan 8 siung bawang merah
1. Gunakan 4 buah kemiri
1. Sediakan 2 ruas kunyit
1. Siapkan  Tambahan :
1. Gunakan 2 batang sereh (geprek)
1. Sediakan 3 lembar daun salam
1. Siapkan 6 lembar daun jeruk
1. Sediakan 1 ruas lengkuas (geprek)
1. Sediakan 2 batang daun bawang (iris)
1. Sediakan 1 batang seledri (iris)
1. Sediakan 1 buah tomat (iris sesuai selera)
1. Siapkan 1/2 jeruk nipis
1. Ambil 2 sdt Garam
1. Gunakan 1/2 sdt Gula
1. Ambil 1 sdt Lada bubuk




<!--inarticleads2-->

##### Cara membuat Soto ayam:

1. Rebus ayam tidak usah lama2, lalu buang airnya. Rebus kembali.
1. Tumis bumbu halus di atas api sedang, jika sudah harum masukan daun salam, daun jeruk, sereh, lengkuas. Tambahkan 1 gelas belimbing air. Aduk sampai air mendidih. Matikan.
1. Jika rebusan ayam sudah mendidih, masukan bumbu yg sudah di tumis tadi. Aduk.
1. Tambahkan garam, lada, gula. Cek rasa. Matikan kompor.
1. Hidangkan soto di mangkuk, jangan lupa di beri irisan daun bawang, daun seledri, tomat dan perasan jeruk agar tambah segar.




Ternyata cara membuat soto ayam yang nikamt tidak rumit ini mudah sekali ya! Semua orang bisa mencobanya. Cara buat soto ayam Sesuai banget buat kita yang baru akan belajar memasak maupun juga untuk kalian yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba membikin resep soto ayam mantab simple ini? Kalau anda ingin, ayo kalian segera buruan siapin alat dan bahan-bahannya, lantas buat deh Resep soto ayam yang mantab dan simple ini. Sangat taidak sulit kan. 

Maka dari itu, ketimbang kamu diam saja, yuk langsung aja buat resep soto ayam ini. Dijamin kalian tiidak akan menyesal sudah bikin resep soto ayam lezat sederhana ini! Selamat mencoba dengan resep soto ayam lezat simple ini di tempat tinggal kalian masing-masing,ya!.

