---
description: "Cara buat Ayam Panggang Bumbu Kari yang enak Untuk Jualan"
title: "Cara buat Ayam Panggang Bumbu Kari yang enak Untuk Jualan"
slug: 304-cara-buat-ayam-panggang-bumbu-kari-yang-enak-untuk-jualan
date: 2021-01-19T03:37:42.333Z
image: https://img-global.cpcdn.com/recipes/55733f385b15bfce/680x482cq70/ayam-panggang-bumbu-kari-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55733f385b15bfce/680x482cq70/ayam-panggang-bumbu-kari-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55733f385b15bfce/680x482cq70/ayam-panggang-bumbu-kari-foto-resep-utama.jpg
author: Chester Rodriquez
ratingvalue: 3.7
reviewcount: 8
recipeingredient:
- "1/2 kg ayam bag paha"
- "1 buah jeruk nipis"
- "350 ml air"
- "1 sdt bumbu kari instan"
- "1 sdm santan instan"
- "1/4 sdt mujung asam jawa"
- "2 siung bawang putih geprek iris"
- "4 siung bawang merah"
- "2 ruas kunyit"
- "1 ruas jahe dan lengkuas"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 sdt kaldu jamur"
- "1/2 sdt garam"
- "1 sdt gula pasir"
- "1/8 sdt lada bubuk"
recipeinstructions:
- "Cuci ayam sampai bersih, lumuri jeruk nipis diamkan 15 menit, kemudian bilas dan tiriskan"
- "Siapakan bahan bumbu ungkep, iris semua bahan bumbu ungkep ya"
- "Didihkan air, masukan Bahan bumbu ungkep, masak 5 menit, masukan ayam, masukan bumbu kari instan, asam jawa dan semua bumbu penyedap juga santan, aduk rata"
- "Ungkep ayam sampai kandungan air kering, Matikan kompor, aduk ayam ungkep, diamkan 15 menit."
- "Panggang ayam di grill pan, sampai matang kecoklatan, sajikan ❤️"
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 160 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Panggang Bumbu Kari](https://img-global.cpcdn.com/recipes/55733f385b15bfce/680x482cq70/ayam-panggang-bumbu-kari-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan santapan mantab bagi keluarga tercinta adalah hal yang menggembirakan bagi kita sendiri. Tanggung jawab seorang  wanita bukan sekedar menangani rumah saja, tetapi anda juga harus memastikan kebutuhan nutrisi tercukupi dan juga masakan yang dimakan keluarga tercinta harus lezat.

Di masa  sekarang, kita memang bisa mengorder hidangan siap saji meski tidak harus ribet memasaknya dulu. Namun ada juga mereka yang selalu mau menghidangkan yang terbaik untuk orang yang dicintainya. Karena, menyajikan masakan sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan keluarga. 



Apakah anda adalah seorang penikmat ayam panggang bumbu kari?. Tahukah kamu, ayam panggang bumbu kari merupakan hidangan khas di Indonesia yang sekarang disukai oleh setiap orang di hampir setiap wilayah di Indonesia. Anda bisa memasak ayam panggang bumbu kari hasil sendiri di rumah dan boleh jadi hidangan kegemaranmu di akhir pekanmu.

Kita jangan bingung jika kamu ingin mendapatkan ayam panggang bumbu kari, lantaran ayam panggang bumbu kari sangat mudah untuk ditemukan dan juga anda pun bisa menghidangkannya sendiri di rumah. ayam panggang bumbu kari bisa dibuat lewat berbagai cara. Sekarang telah banyak cara modern yang menjadikan ayam panggang bumbu kari lebih enak.

Resep ayam panggang bumbu kari pun mudah sekali dibuat, lho. Kita tidak perlu ribet-ribet untuk memesan ayam panggang bumbu kari, tetapi Anda dapat menyajikan di rumahmu. Untuk Anda yang akan mencobanya, dibawah ini merupakan resep untuk membuat ayam panggang bumbu kari yang nikamat yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Panggang Bumbu Kari:

1. Ambil 1/2 kg ayam bag paha
1. Sediakan 1 buah jeruk nipis
1. Sediakan 350 ml air
1. Ambil 1 sdt bumbu kari instan
1. Ambil 1 sdm santan instan
1. Sediakan 1/4 sdt mujung asam jawa
1. Sediakan 2 siung bawang putih (geprek iris)
1. Siapkan 4 siung bawang merah
1. Gunakan 2 ruas kunyit
1. Gunakan 1 ruas jahe dan lengkuas
1. Siapkan 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Gunakan 1 sdt kaldu jamur
1. Gunakan 1/2 sdt garam
1. Sediakan 1 sdt gula pasir
1. Siapkan 1/8 sdt lada bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Panggang Bumbu Kari:

1. Cuci ayam sampai bersih, lumuri jeruk nipis diamkan 15 menit, kemudian bilas dan tiriskan
1. Siapakan bahan bumbu ungkep, iris semua bahan bumbu ungkep ya
1. Didihkan air, masukan Bahan bumbu ungkep, masak 5 menit, masukan ayam, masukan bumbu kari instan, asam jawa dan semua bumbu penyedap juga santan, aduk rata
1. Ungkep ayam sampai kandungan air kering, Matikan kompor, aduk ayam ungkep, diamkan 15 menit.
1. Panggang ayam di grill pan, sampai matang kecoklatan, sajikan ❤️




Wah ternyata cara membuat ayam panggang bumbu kari yang lezat sederhana ini mudah banget ya! Kita semua bisa membuatnya. Cara Membuat ayam panggang bumbu kari Sangat cocok banget untuk kalian yang baru akan belajar memasak ataupun juga untuk kamu yang telah pandai memasak.

Apakah kamu tertarik mulai mencoba membuat resep ayam panggang bumbu kari nikmat tidak ribet ini? Kalau kamu mau, ayo kalian segera menyiapkan alat dan bahannya, kemudian bikin deh Resep ayam panggang bumbu kari yang mantab dan sederhana ini. Betul-betul gampang kan. 

Maka dari itu, daripada kamu berlama-lama, hayo langsung aja bikin resep ayam panggang bumbu kari ini. Dijamin kamu tak akan menyesal membuat resep ayam panggang bumbu kari nikmat sederhana ini! Selamat mencoba dengan resep ayam panggang bumbu kari lezat tidak ribet ini di tempat tinggal sendiri,ya!.

